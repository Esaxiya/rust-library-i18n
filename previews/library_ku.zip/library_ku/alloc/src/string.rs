//! Rêzikek UTF-8 - şîfrekirî, mezinbar.
//!
//! Vê modulê ji bo veguheztina li têlan,[`String`] type, [`ToString`] trait û gelek celebên xeletiyê hene ku dibe ku ji xebata bi [`Têl`] s re hebin.
//!
//!
//! # Examples
//!
//! Gelek away hene ku meriv ji rêzê rasterast [`String`]-ya nû biafirîne:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Hûn dikarin bi yekkirina bi hev re [`String`]-ya nû ji ya heyî biafirînin
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Heke vector-yê UTF-8-byteyên weyên derbasdar hebin, hûn dikarin jê [`String`]-ê çêbikin.Hûn dikarin berevajî jî bikin.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Em dizanin van bayît derbasdar in, ji ber vê yekê em ê `unwrap()` bikar bînin.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// Rêzikek UTF-8 - şîfrekirî, mezinbar.
///
/// Tîpa `String` celebê herî têl e ku xwediyê xwediyê naverokên têl e.Têkiliyek wê ya nêzîk bi hevparê xwe yê deynkirî, [`str`]-a prîmîtîf re heye.
///
/// # Examples
///
/// Hûn dikarin bi [`String::from`] re `String` ji [a literal string][`str`] biafirînin:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Hûn dikarin bi rêbaza [`push`] [`char`] bi `String` ve girêbidin, û bi rêbaza [`push_str`] jî [`&str`] pêve bikin:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Ger vector-yê UTF-8-byte hebe, hûn dikarin bi rêbaza [`from_utf8`] jê re `String` biafirînin:
///
/// ```
/// // hin byte, di vector de
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Em dizanin van bayît derbasdar in, ji ber vê yekê em ê `unwrap()` bikar bînin.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `Têl herdem UTF-8 derbasdar e.Vê çend bandorên wê hene, ya yekem ew e ku heke hûn hewceyê têlek ne-UTF-8 bin, [`OsString`] bifikirin.Ew wekhev e, lê bêyî astengiya UTF-8.Wateya duyemîn ev e ku hûn nekarin nav `String` nîşan bikin:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Armanckirin armanc e ku operasyonek domdar-dem be, lê kodkirina UTF-8 nahêle ku em vê yekê bikin.Wekî din, ne diyar e ku divê index çi celeb tiştan vegerîne: bajarek, kodek, an komek grafemeyê.
/// Rêbazên [`bytes`] û [`chars`] bi rêzê ve dubareyên li ser du yekem vedigerin.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `String` sepandin [`Deref`]`<Target=str>`, û ji ber vê yekê hemî rêbazên [`str`] mîras digirin.Wekî din, ev tê vê wateyê ku hûn dikarin `String` bi karûbarek ku [`&str`] digire bi karanîna ampersand (`&`) derbas bikin:
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Ev dê [`&str`] ji `String` biafirîne û derbas bike. Ev veguherîn pir erzan e, û ji ber vê yekê bi gelemperî, fonksiyon dê [`&str`] s wekî argumanan qebûl bikin heya ku ji wan re sedemek taybetî ji wan re `String` ne hewce be.
///
/// Di hin rewşan de agahdariya Rust têr nake ku vê veguherînê bike, ku wekî zorê [`Deref`] tête zanîn.Di mînaka jêrîn de xelekek têl [`&'a str`][`&str`] trait `TraitExample` bicîh dike, û fonksiyona `example_func` her tiştê ku trait pêk tîne digire.
/// Di vê rewşê de Rust hewce dike ku du veguherînên berbiçav bike, ku wateya Rust tune ku bike.
/// Ji ber vê sedemê, dê mînaka jêrîn berhev neke.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Du vebijark hene ku dê li şûna wan bixebitin.Ya yekem dê guhertina rêza `example_func(&example_string);` bo `example_func(example_string.as_str());` be, bi karanîna rêbaza [`as_str()`] ku bi zelalî pelika têlê têda tê derxistin.
/// Awayê duyemîn `example_func(&example_string);` li `example_func(&*example_string);` diguheze.
/// Di vê rewşê de em `String` ji [`str`][`&str`] re vedigirin, paşê [`str`][`&str`] li [`&str`] vedigerînin.
/// Awayê duyemîn bêtir idiomatîkî ye, lêbelê her du jî dixebitin ku veguherînê bi eşkereyî bikin ji dêvla ku xwe bispêrin veguherîna veşartî.
///
/// # Representation
///
/// `String` ji sê pêkhateyan pêk tê: nîşanderê hin baytan, dirêjahî û kapasîteyek.Nîşan nîşanî tamponek navxweyî ye ku `String` ji bo tomarkirina daneyên xwe bikar tîne.Dirêjahî hejmara byteyên ku niha di tamponê de hatine hilanîn e, û kapasîte mezinahiya tampona di bajaran de ye.
///
/// Bi vî rengî, dirêjahî dê her dem ji kapasîteyê kêmtir be an jî wekhev be.
///
/// Ev tampon her gav li ser hep tê hilanîn.
///
/// Hûn dikarin bi rêbazên [`as_ptr`], [`len`], û [`capacity`] li van binêrin:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Dema ku vec_into_raw_parts sabit kirin vê yekê nû bikin.
/// // Asteng bikin ku jixweber daneyên Têlrê davêjin
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // çîrok nozdeh byte
/// assert_eq!(19, len);
///
/// // Em dikarin ji ptr, len, û kapasîteyê Têtekê ji nû ve çêbikin.
/// // Ev hemî ne ewledar e ji ber ku em berpirsiyar in ku pê ewle bin ku pêkhatan derbasdar in:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Ger kapasîteya `String` têra xwe hebe, hêmanên li ser wê zêde bikin dê ji nû ve venebe.Mînakî, vê bernameyê bifikirin:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Ev ê jêrîn derxe:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Di destpêkê de, bîra me tune ku em qet veqetandî ne, lê gava ku em li têlê vedigerin, ew kapasîteya xwe bi guncanî zêde dike.Heke em li şûna wê rêbaza [`with_capacity`] bikar bînin da ku di destpêkê de kapasîteya rast veqetînin:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Em bi encamek cûda diqedin:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Li vir, ne hewce ye ku meriv bêtir bîranîn di hundurê xelekê de veqetîne.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Dema ku `String` ji UTF-8 byte vector vedigire nirxek çewtiyê ya gengaz.
///
/// Ev celeb ji bo rêbaza [`from_utf8`] li ser [`String`] celebê çewtiyê ye.
/// Ew bi rengek hatiye sêwirandin ku bi baldarî ji nû ve veqetandinan dûr bikeve: rêbaza [`into_bytes`] dê byte vector ku di hewla veguherînê de hatî bikar anîn bide.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Tîpa [`Utf8Error`] ya ku ji hêla [`std::str`] ve hatî peyda kirin çewtiyek destnîşan dike ku dibe ku dema veguheztina perçek [`u8`] ji [`&str`].
/// Di vê wateyê de, ew analogek e ji `FromUtf8Error` re, û hûn dikarin bi rêbaza [`utf8_error`] yek ji `FromUtf8Error` bistînin.
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Bikaranîna bingehîn:
///
/// ```
/// // hin byteyên nederbasdar, di vector de
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Dema ku `String` ji parçeyek byte UTF-16 veguherîne nirxek çewtiyê ya gengaz.
///
/// Ev celeb ji bo rêbaza [`from_utf16`] li ser [`String`] celebê çewtiyê ye.
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Bikaranîna bingehîn:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// `String`-a vala ya nû diafirîne.
    ///
    /// Ji ber ku `String` vala ye, ev ê tamponek destpêkê ne veqetîne.Digel ku tê vê wateyê ku ev xebata destpêkê pir erzan e, dibe ku paşê gava ku hûn daneyê zêde bikin dibe sedema veqetandina zêde.
    ///
    /// Heke ramanek we heye ku `String` dê çiqas daneyê bigire, rêbaza [`with_capacity`] bifikirin da ku pêşî li veqetandina zêde neyê girtin.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Bi kapasîteyek taybetî `String`-a vala ya nû diafirîne.
    ///
    /// `String`s tamponek navxweyî heye ku daneyên wan bigire.
    /// Kapasîte dirêjahiya wê tamponê ye, û dikare bi rêbaza [`capacity`] were pirsîn.
    /// Ev rêbaz `String` vala diafirîne, lê yek bi tamponek destpêkê ku dikare `capacity` byte bigire.
    /// Vê kêrhatî ye dema ku hûn komek daneyan bi `String` ve girêdidin, hejmara reallocasyonên ku hewce dike kêm bike.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Heke kapasîteya dayîn `0` be, dê veqetînek çênebe, û vê rêbazê bi rêbazê [`new`] re yeksan e.
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // The String no chars չունի, her çend kapasîteya wê ya zêdetir jî hebe
    /// assert_eq!(s.len(), 0);
    ///
    /// // Van hemî bêyî ji nû ve veqetandinê têne kirin ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... lê ev dikare rêzê ji nû ve vehewîne
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): bi cfg(test) rêbaza xwerû `[T]::to_vec`, ku ji bo vê pênaseya rêbazê pêdivî ye, peyda nabe.
    // Ji ber ku ji bo mebestên ceribandinê me pêdivî bi vê rêbazê nîne, ez ê tenê wê stû bikim NB ji bo bêtir agahdarî moduleya slice::hack di slice.rs de bibîne
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// vector-ê byte veguherîne `String`.
    ///
    /// Têlika ([`String`]) ji byte ([`u8`]), û vector byte ([`Vec<u8>`]) ji byte tê çêkirin, ji ber vê yekê ev fonksiyon di navbera her duyan de vedigire.
    /// Ne ku hemî perçeyên byte `String` derbasdar in, lêbelê: `String` hewce dike ku ew UTF-8 derbasdar be.
    /// `from_utf8()` kontrol dike ku bayît UTF-8 derbasdar in, û paşê veguherînê dike.
    ///
    /// Heke hûn pê ewle ne ku beşa byte UTF-8 derbasdar e, û hûn naxwazin serê jorîn ê kontrola rastdariyê bistînin, guhertoyek ne ewle ya vê fonksiyonê heye, [`from_utf8_unchecked`], ku heman reftar heye lê venêrana kontrolê dike.
    ///
    ///
    /// Vê rêbazê dê balê bikişîne ku vector-ê, ji bo bandorkeriyê, kopî neke.
    ///
    /// Heke di şûna `String` de ji we re [`&str`] hewce be, [`str::from_utf8`] bifikirin.
    ///
    /// Berevajî vê rêbazê [`into_bytes`] e.
    ///
    /// # Errors
    ///
    /// Ger pişkek ne UTF-8 be bi vegotinê vedigere [`Err`] lê vedigere ka çima byteyên peyda ne UTF-8 ne.vector ya ku hûn lê bar kirin jî tê de ye.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// // hin byte, di vector de
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Em dizanin van bayît derbasdar in, ji ber vê yekê em ê `unwrap()` bikar bînin.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Bîtên çewt:
    ///
    /// ```
    /// // hin byteyên nederbasdar, di vector de
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Ji bo bêtir agahdariya ku hûn dikarin bi vê xeletiyê re bikin ji bo [`FromUtf8Error`] belgeyan bibînin.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Parçeyek byteyan veguherîne têlek, tîpên nederbasdar jî tê de.
    ///
    /// Têlên ji byteyên ([`u8`]) têne çêkirin, û perçeyek byteyên ([`&[u8]`][byteslice]) jî ji byte têne çêkirin, ji ber vê yekê ev fonksiyon di navbera her duyan de vedigire.Ne ku hemî perçeyên byte rêzikên derbasdar in, lêbelê: têl hewce ne ku UTF-8 derbasdar bin.
    /// Di dema vê veguherînê de, `from_utf8_lossy()` dê rêzikên UTF-8 yên nederbasdar bi [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] biguherîne, ku wusa xuya dike:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Heke hûn pê ewle ne ku beşa byte UTF-8 derbasdar e, û hûn naxwazin serê jorîn veguherînin, guhertoyek ne ewle ya vê fonksiyonê heye, [`from_utf8_unchecked`], ku heman reftar heye lê venêran ji kontrolê.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Vê fonksiyonê [`Cow<'a, str>`] vedigerîne.Ger pişka meya byte UTF-8 nederbasdar be, wê hingê pêdivî ye ku em tîpên cîgir, ku dê mezinahiya têlê biguhezin, têxin hundurê xwe û ji ber vê yekê, `String` hewce dike.
    /// Lê heke ew jixwe UTF-8 derbasdar e, ji me re veqetandek nû hewce nake.
    /// Vê celebê vegerê rê dide me ku em her du dozan jî birêve bibin.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// // hin byte, di vector de
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Bîtên çewt:
    ///
    /// ```
    /// // hin baytên nederbasdar
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// vector `v` a UTF-16 - şîfrekirî di `String` de şîfre bikin, ger `v` daneyên nederbasdar hebe [`Err`] vedigerîne.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Ev bi berhevkirinê nayê kirin: : <Result<_, _>> () ji ber sedemên karûbarê.
        // FIXME: dema ku #48994 girtî ye fonksiyon dikare dîsa hêsan bibe.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// `v` ya UTF-16 - şîfrekirî ya `v` di `String` deşîfre bike, daneya nederbasdar bi [the replacement character (`U+FFFD`)][U+FFFD] veguherîne.
    ///
    /// Berevajî [`from_utf8_lossy`] ku [`Cow<'a, str>`] vedigerîne, `from_utf16_lossy` `String` vedigerîne ji ber ku UTF-16 bo UTF-8 veguherîn pêdivî bi dabeşkirina bîranînê heye.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// `String` di nav pêkhateyên wê yên xav de xera dibe.
    ///
    /// Pointerê xav vedigere ser daneyên bingehîn, dirêjahiya rêzê (li byte), û kapasîteya veqetandî ya daneyê (li byte).
    /// Van heman argumanan di heman rêzê de wekî argumanên [`from_raw_parts`]-ê ne.
    ///
    /// Piştî banga vê fonksiyonê, bangker berpirsiyarê bîranînê ye ku berê ji hêla `String` ve hatibû rêvebirin.
    /// Awayê yekane ev e ku veguhezîne nîşander, dirêjahî, û kapasîteya rawe ya paşîn li `String` bi fonksiyona [`from_raw_parts`] veguherîne, da ku hilweşîner paqijiyê pêk bîne.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Ji dirêjahî, kapasîte û nîşangir `String` nû diafirîne.
    ///
    /// # Safety
    ///
    /// Ev ji ber jimara neguhêzbarên ku nayên kontrol kirin pir ewledar e:
    ///
    /// * Bîra li `buf` hewce dike ku berê ji hêla heman dabeşkerê ku pirtûkxaneya standard bikar tîne ve hatî veqetandin, bi rêzikek pêdivî ya tam 1.
    /// * `length` pêdivî ye ku ji `capacity` kêmtir an wekhev be.
    /// * `capacity` pêdivî ye ku nirxek rast be.
    /// * Pêdivî ye ku yekemîn byteyên `length` li `buf` UTF-8 derbasdar be.
    ///
    /// Binpêkirina vana dibe ku bibe sedema pirsgirêkên mîna xerakirina avahiyên daneyên navxweyî yên dabeşker.
    ///
    /// Xwedaniya `buf` bi bandor ji `String` re tête veguheztin ku dibe ku hingê naveroka bîranînê ya ku ji hêla pointer ve li gorî xwe nîşan dide veqetîne, vehewîne an biguheze.
    /// Piştrast bikin ku piştî banga vê fonksiyonê tiştek din nîşanker bikar nayne.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Dema ku vec_into_raw_parts sabit kirin vê yekê nû bikin.
    ///     // Asteng bikin ku jixweber daneyên Têlrê davêjin
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// vector byte veguherîne `String` bêyî ku kontrol bike ku têl UTF-8 derbasdar heye.
    ///
    /// Ji bo bêtir agahdariyê guhertoya ewledar, [`from_utf8`] bibînin.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Ev fonksiyon ne ewle ye ji ber ku ew venêran dike ku baytên ku jê re hatine derbas kirin UTF-8 derbasdar in.
    /// Ger ev astengî were binpê kirin, dibe ku ew bibe sedema pirsgirêkên bêewlehiya bîra bikarhênerên future yên `String`, ji ber ku pirtûkxaneya mayî ya mayî ferz dike ku `Têlîn UTF-8 derbasdar e.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// // hin byte, di vector de
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// `String` veguherîne bytek vector.
    ///
    /// Ev `String` dixwe, ji ber vê yekê em ne hewce ne ku naveroka wê kopî bikin.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Pelikek têlê ku tevahî `String` tê de vedigire.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// `String` veguherîne perçeyek têl a guherbar.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Rêzeyek têlê ya li dawiya vê `String` ve girêdide.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Kapasîteya vê `String`-ê, li byteyan vedigerîne.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Misoger dike ku kapasîteya vê `Têl`ê ji dirêjahiya wê herî kêm `additional` byte ye.
    ///
    /// Heke ew hilbijêre, kapasîte dikare ji hêla `additional` bayt zêdetir were zêdekirin, da ku pêşî li veguheztinên pir caran were girtin.
    ///
    ///
    /// Heke hûn vê tevgera "at least" naxwazin, rêbaza [`reserve_exact`] bibînin.
    ///
    /// # Panics
    ///
    /// Ger kapasîteya nû [`usize`] biherike Panics.
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Dibe ku ev kapasîteyê zêde neke:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s niha dirêjahiya wê 2 û kapasîteya wê jî 10 e
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Ji ber ku jixwe 8 kapasîteyek me ya zêde heye, bang li vê dikin ...
    /// s.reserve(8);
    ///
    /// // ... bi rastî zêde nabe.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Piştrast dike ku kapasîteya vê `Têl`ê ji dirêjahiya wê `additional` byte ye.
    ///
    /// Heya ku hûn bi tevahî ji dabeşker çêtir nizanin bifikirin ku hûn metoda [`reserve`] bikar bînin.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Ger kapasîteya nû `usize` biherike Panics.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Dibe ku ev kapasîteyê zêde neke:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s niha dirêjahiya wê 2 û kapasîteya wê jî 10 e
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Ji ber ku jixwe 8 kapasîteyek me ya zêde heye, bang li vê dikin ...
    /// s.reserve_exact(8);
    ///
    /// // ... bi rastî zêde nabe.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Hewil dide ku kapasîteyê ji bo kêmtirîn `additional` hêmanên din vehewîne ku di `String`-ya dayînê de were vehewandin.
    /// Dibe ku berhevok cîhê bêtir veqetîne da ku ji nû ve veqetandinan dûr nekeve.
    /// Piştî bangkirina `reserve`, kapasîte dê ji `self.len() + additional` mezintir an wekhev be.
    /// Heke kapasîte jixwe bes be tiştek nake.
    ///
    /// # Errors
    ///
    /// Ger kapasîte zêde bibe, an dabeşker têkçûnek ragihîne, wê hingê xeletiyek tê vegerandin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Berê bîranînê veqetînin, ger em nekarin derkevin
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Naha em dizanin ku ev nikare OOM di nîveka xebata meya tevlihev de
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Hewil dide ku kapasîteya herî kêm ji bo hêjayî `additional` hêmanên din ên ku di `String` dayîn de werin vehewandin veqetîne.
    ///
    /// Piştî bangkirina `reserve_exact`, kapasîte dê ji `self.len() + additional` mezintir an wekhev be.
    /// Heke kapasîte jixwe bes be tiştek nake.
    ///
    /// Zanibe ku dabeşker dikare ji berhevokê zêdetir ji ya ku ew daxwaz dike bide.
    /// Ji ber vê yekê, ji kapasîteyê re ne mimkun e ku meriv bi kêmasî be.
    /// Ger têkela future tê hêvîkirin `reserve` tercîh bikin.
    ///
    /// # Errors
    ///
    /// Ger kapasîte zêde bibe, an dabeşker têkçûnek ragihîne, wê hingê xeletiyek tê vegerandin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Berê bîranînê veqetînin, ger em nekarin derkevin
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Naha em dizanin ku ev nikare OOM di nîveka xebata meya tevlihev de
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Kapasîteya vê `String` kurt dike ku bi dirêjahiya wê re li hev bike.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Kapasîteya vê `String` bi bendek jêrîn şîn dike.
    ///
    /// Kapasîte dê herî kêm bi qasî dirêjahî û nirxa dabînkirî mezin bimîne.
    ///
    ///
    /// Heke kapasîteya heyî ji tixûbê jêrîn kêmtir e, ev ne-op e.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// [`char`]-ya hatî dayîn li dawiya vê `String`-ê ve girêdide.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Parçeyek byte ya naveroka vê `String` vedigerîne.
    ///
    /// Berevajî vê rêbazê [`from_utf8`] e.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Vê `String` bi dirêjahiya diyarkirî kurtir dike.
    ///
    /// Ger `new_len` ji dirêjahiya heyî ya têlê mezintir be, ev ti bandorek nîne.
    ///
    ///
    /// Zanibe ku vê rêbazê li ser kapasîteya veqetandî ya têlê bandor nake
    ///
    /// # Panics
    ///
    /// Panics heke `new_len` li ser sînorek [`char`] derewan neke.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Karaktera paşîn ji tampona têlê radike û vedigerîne.
    ///
    /// Ger ev `String` vala be vedigere [`None`].
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// X0 [`char`]-a ji vê `String`-ê di rewşek byte de radike û vedigerîne.
    ///
    /// Ev çalakiyek *O*(*n*) e, ji ber ku pêdivî bi kopîkirina her hêmana di tamponê de heye.
    ///
    /// # Panics
    ///
    /// Panics heke `idx` ji dirêjahiya ``String`` mezintir an wekhev e, an jî ew li ser sînorek [`char`] veneke.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Hemî pêşbirkên nimûneya `pat` di `String` de hilînin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Dê maç bi dubareyî bêne kifş kirin û rakirin, ji ber vê yekê di rewşên ku pêşnûma li hev dikin de, tenê nimûneya yekem dê were rakirin:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // EWLEH: destpêk û dawîn dê li ser sînorên utf8 byte per be
        // belgeyên Lêgerîn
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Tenê tîpên ku ji hêla pêşbend ve hatine diyar kirin vedihewîne.
    ///
    /// Bi gotinên din, hemî tîpên `c` derxistin da ku `f(c)` `false` vegerîne.
    /// Ev rêbaza hanê di cîh de kar dike, bi rêza yekem yek carek diçe serdana her tîpan, û rêza tîpên hatine parastin diparêze.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Rêziknameya rastîn dikare ji bo şopandina rewşa derveyî, mîna indexek bikêr be.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Idx nîşankirin ser char din
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Di vê `String`-ê de xalek kesek dixe rewşek baytê.
    ///
    /// Ev çalakiyek *O*(*n*) e ku ew hewce dike ku her elementek di tamponê de were kopî kirin.
    ///
    /// # Panics
    ///
    /// Panics heke `idx` ji dirêjahiya `String` mezintir be, an jî ew li ser sînorek [`char`] nekeve.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Qertafek têlê dixe nav vê `String` de di rewşek byte de.
    ///
    /// Ev çalakiyek *O*(*n*) e ku ew hewce dike ku her elementek di tamponê de were kopî kirin.
    ///
    /// # Panics
    ///
    /// Panics heke `idx` ji dirêjahiya `String` mezintir be, an jî ew li ser sînorek [`char`] nekeve.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Li naveroka vê `String` referansa guhêrbar vedigere.
    ///
    /// # Safety
    ///
    /// Ev fonksiyon ne ewle ye ji ber ku ew venêran dike ku baytên ku jê re hatine derbas kirin UTF-8 derbasdar in.
    /// Ger ev astengî were binpê kirin, dibe ku ew bibe sedema pirsgirêkên bêewlehiya bîra bikarhênerên future yên `String`, ji ber ku pirtûkxaneya mayî ya mayî ferz dike ku `Têlîn UTF-8 derbasdar e.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Dirêjiya vê `String`, li byte, ne [`char`] an grafemên vedigerîne.
    /// Bi gotinên din, dibe ku ya ku mirov dirêjahiya têlê dihesibîne nebe.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// `true` vedigerîne heke dirêjahiya vê `String` sifir be, û `false` wekî din.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Li benda danezan a byte têlê têl dike du parçe.
    ///
    /// `String`-a ku nû hatî veqetandin vedigerîne.
    /// `self` byteyên `[0, at)` vedigire, û `String` vegerandin byteyên `[at, len)` hene.
    /// `at` divê li ser sînorê xaleke kodê UTF-8 be.
    ///
    /// Têbînî ku kapasîteya `self` nayê guhertin.
    ///
    /// # Panics
    ///
    /// Panics heke `at` ne li ser sînorê xala kodê `UTF-8` be, an heke ew ji xala kodê ya paşîn a têl be.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Vê `String` kurt dike, hemî naverokan radike.
    ///
    /// Dema ku ev tê vê wateyê ku `String` dê dirêjahiya wê sifir be, ew kapasîteya wê nagire dest.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Iteratorê şûştinê diafirîne ku di `String`-ê de dora diyarkirî radike û `chars`-ya jêkirî dide.
    ///
    ///
    /// Note: Rêzeya hêmanê tê rakirin heke iterator heya dawiyê neyê xerckirin.
    ///
    /// # Panics
    ///
    /// Panics heke xala destpêkê an xala dawî li ser sînorek [`char`] nekeve, an heke ew ji sînor nebin.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Rêzeyê heya β ji têlê derxînin
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Rêzeyek tevahî têlê paqij dike
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Ewlekariya bîranînê
        //
        // Di guhertoya String ya Drain de pirsgirêkên ewlehiya bîra yên guhertoya vector tune.
        // Daneyên tenê byteyên sade ne.
        // Ji ber ku rakirina dorpêçê li Drop-ê çêdibe, heke iteratorê Drain lehî bibe, rakirin dê çênebe.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Du deynên hevdem derxînin.
        // &mut String dê neyê gihîştin heya ku dubare bi dawî bibe, li Drop.
        let self_ptr = self as *mut _;
        // EWLEH: : `slice::range` û `is_char_boundary` kontroleyên guncan dikin.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Rêzeya diyarkirî ya di têlê de ji holê radike, û têlê têxe şûna wê.
    /// Rêzika dayîn ne hewce ye ku bi dirêjahiya dirêjahiyê be.
    ///
    /// # Panics
    ///
    /// Panics heke xala destpêkê an xala dawî li ser sînorek [`char`] nekeve, an heke ew ji sînor nebin.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Rêzeyê heya β ji têlê biguhezînin
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Ewlekariya bîranînê
        //
        // Replace_range pirsgirêkên ewlehiya bîranîna vector Splice tune.
        // ya guhertoya vector.Daneyên tenê byteyên sade ne.

        // HINYAR: Xêzkirina vê guherbarê dê neheq be (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // HINYAR: Xêzkirina vê guherbarê dê neheq be (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // `range` carek din bikar bîne dê neheq be (#81138) Em texmîn dikin ku sînorên ji hêla `range` ve hatine ragihandin wek xwe dimînin, lê pêkanînek dijber dikare di navbera bangan de biguheze
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Vê `String` vediguhêzîne ["Box"] "<" ["str"] ">".
    ///
    /// Ev ê her kapasîteya zêde bavêje.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Parçeyek byteyên [`u8`] ên ku hewl dane veguherînin `String` vedigerîne.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// // hin byteyên nederbasdar, di vector de
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Bytesên ku hewl dane ku veguherînin `String` vedigerîne.
    ///
    /// Ev rêbaz bi baldarî tête çêkirin ku ji dabeşkirinê dernekeve.
    /// Ew ê çewtiyê bixwe, bayîtan bar dike, da ku hewce nebe ku kopiyek ji bayiyan were çêkirin.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// // hin byteyên nederbasdar, di vector de
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// `Utf8Error`-ê bistînin da ku der barê têkçûna veguherînê de bêtir agahdarî bistînin.
    ///
    /// Tîpa [`Utf8Error`] ya ku ji hêla [`std::str`] ve hatî peyda kirin çewtiyek destnîşan dike ku dibe ku dema veguheztina perçek [`u8`] ji [`&str`].
    /// Di vê wateyê de, ew analog a `FromUtf8Error` ye.
    /// Ji bo bêtir agahdariya li ser karanîna wê belgeya wê bibînin.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// // hin byteyên nederbasdar, di vector de
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // yekem byte li vir nederbasdar e
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Ji ber ku em li ser `String` ê dûbare dikin, em dikarin bi kêmtirîn rêzikek ji dabeşkirinê dûr bisekinin û rêza yekem ji iterator werbigirin û hemî têlên dûv re pêve bikin.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Ji ber ku em li ser CoW-ê dubare dikin, em dikarin (potentially) kêmtirîn veqetandekek bi dest bixin û bi destxistina tiştê yekem û pêve pê ve hemî hêmanên paşîn dûr bixin.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Baweriyek hêsanî ya ku ji bo `&str` vexwendinê vedihewîne.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// `String`-a vala diafirîne.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Ji bo lihevxistina du têlan operatorê `+` bicîh dike.
///
/// Ev `String` li milê çepê dixwe û tampona wê ji nû ve bikar tîne (ger hewce bike wê mezin dike).
/// Ev tê kirin da ku `String` nû dabeş neke û li ser her xebatê naverokê tev neyê kopî kirin, ku dema çêkirina têl *n*-bayte bi hevgirtina dubare dibe sedema *O*(*n*^ 2) dema xebitandinê.
///
///
/// Têla li milê rastê tenê deyn e;naveroka wê di nav `String` vegerandin de têne kopî kirin.
///
/// # Examples
///
/// Lihevkirina du `Têl` ê bi nirxê yekê digire û ya duyem jî digire:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` tê bar kirin û nema dikare li vir were bikar anîn.
/// ```
///
/// Heke hûn dixwazin `String`-a yekem bikar bînin, hûn dikarin wê klon bikin û li şûna wê klonê pêve bikin:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` li vir hîn jî derbasdar e.
/// ```
///
/// Lihevxistina pelên `&str` dikare bi veguheztina yekem li `String` bête kirin:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Ji bo pêvekirina `String` operatorê `+=` bicîh dike.
///
/// Vê reftara eynî wekî rêbaza [`push_str`][String::push_str] heye.
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Navnîşek celebek ji bo [`Infallible`].
///
/// Ev nasnav ji bo lihevhatina paşverû heye, û dibe ku di dawiyê de bête betal kirin.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// trait ji bo veguheztina nirxek bi `String`.
///
/// Ev trait bixweber ji bo her celebê ku [`Display`] trait bicîh dike bixwe tête bicîh kirin.
/// Bi vî rengî, pêdivî ye ku `ToString` rasterast neyê sepandin:
/// [`Display`] divê li şûna wê were bicîh kirin, û hûn pêkanîna `ToString` belaş bistînin.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Nirxa dayî veguherîne `String`.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// Di vê pêkanînê de, heke pêkanîna `Display` çewtiyek vegerîne rêbaza `to_string` panics.
/// Ev pêkanînek çewt a `Display` nîşan dide ji ber ku `fmt::Write for String` çu carî xeletiyek bixwe venagerîne.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Rêbernameyek hevbeş ev e ku fonksiyonên gelemperî nexşînin.
    // Lêbelê, derxistina `#[inline]` ji vê rêbazê dibe sedema paşverûtiyên ne-xemsar.
    // <https://github.com/rust-lang/rust/pull/74852> bibînin, hewldana dawîn ku hewl bidin ku wê rakin.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// `&mut str` veguherîne `String`.
    ///
    /// Encam li ser heapê tête veqetandin.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: test li libstd dikişîne, ku li vir dibe sedema xeletiyan
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Pelê `str` yê qutikê dayî veguherîne `String`.
    /// Nîşan e ku pişka `str` xwedan e.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// `String`-ya daneyî veguherîne pişkek `str`-a qutikî ya ku tê xwedîkirin.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Qertalek têl veguherîne cûrbecûr Borrowed.
    /// Dabeşandina heapê nayê kirin, û têl nayê kopî kirin.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Zencîreyek vediguherîne variyantek Xwedî.
    /// Dabeşandina heapê nayê kirin, û têl nayê kopî kirin.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Çavkaniyek Stringê veguherîne cûrbecûr Biryardar.
    /// Dabeşandina heapê nayê kirin, û têl nayê kopî kirin.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// `String`-a daneyî veguherîne vector `Vec`-ê ku nirxên celebê `u8` digire.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Ji bo `String` îteratorek dirijandî.
///
/// Ev strukture bi rêbaza [`drain`] li ser [`String`] tê afirandin.
/// Ji bo bêtir belgeya wê bibînin.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Dê wekî&'mut mutteqa di hilweşîner de were bikar anîn
    string: *mut String,
    /// Destpêka beşê jêbirin
    start: usize,
    /// Dawiya beşa ku jêbirin
    end: usize,
    /// Rêjeya mayî ya heyî ku were rakirin
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Vec::drain bikar bînin.
            // "Reaffirm" venêran kontrol dike da ku kodê panic careke din neyê danîn.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Rêzika mayî (bin) a vê iteratorê wekî perçeyek vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: dema ku aramî çêdibe AsRef li jêr xuya dike.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Dema ku `string_drain_as_str` aram dike bêkêmasî be.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>ji bo Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> ji bo Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}