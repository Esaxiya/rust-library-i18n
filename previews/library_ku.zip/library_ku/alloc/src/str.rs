//! Pelên têlên Unicode.
//!
//! *[See also the `str` primitive type](str).*
//!
//! Tîpa `&str` yek ji du celebên têlên sereke ye, ya din jî `String` ye.
//! Berevajî hevparê `String`, naveroka wê deynkirî ye.
//!
//! # Bikaranîna Bingehîn
//!
//! Danezana rêzika bingehîn a ji celebê `&str`:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! Li vir me têl bi peyvek ragihand, ku wekî têlek têl jî tê zanîn.
//! Wêjeyên têlê temenek statîk heye, ku tê vê wateyê ku têl `hello_world` ji bo domandina tevahiya bernameyê derbasdar e.
//!
//! Em dikarin bi zelalî jiyana `hello_world` jî diyar bikin:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// Di vê modulê de gelek karanîn tenê di veavakirina testê de têne bikar anîn.
// Paqijtir e ku meriv tenê hişyariya nexşedekirî ya bêserûber vemirîne ji serastkirina wan.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `str` di `Concat<str>` de li vir ne watedar e.
/// Ev parametreya celebê ya trait tenê heye ku têkelek din çalak bike.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // xelekên bi pîvanên hişkkirî pir zûtir dimeşin û rewşên bi dirêjahiyên piçûk ên veqetandinê pispor dikin
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // keyfî paşdaçûna mezinahiya ne-sifir
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Pêkanîna tevlêbûna çêtirîn ku ji bo her du Vec jî dixebite<T>(T: Kopîkirin) û vecê hundurîn ê Têlokê Naha (2018-05-13) li wir xeletiyek heye ku bi têgihiştin û pisporiya type re heye (li pirsgirêka #36262 binihêre) Ji ber vê sedemê SliceConcat<T>ji bo T ne pispor e: Kopî û SliceConcat<str>tenê bikarhênerê vê fonksiyonê ye.
// Ew ji bo dema ku ew sabît mayî maye.
//
// tixûbên String-join S: Deyn<str>û ji bo Vec-endambûna Borrow <[T]> [T] û str jî ji bo hin T AsRef <[T]> nîşan bide
// => s.borrow().as_ref() û her dem pelikên me hene
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // pişka yekem yekane ye ku bêyî wê veqetandek li pêş e
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // heke hejmartina `len` zêde bibe, dirêjahiya tevahî ya rastîn a Vec-a tevlîhev bihejmêrin, em ê panic bikin em ê bi her halî bîra xwe bidawî bikin û fonksiyona mayî ji bo ewlehiyê hewceyê tevahî Vec-ê ye
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // Tamponek uninitialized amade bikin
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // dabeşkerê kopî û dabeşên bêyî kontrolên sînoran ji bo veqetandekên piçûk çêtirîn çêtirkirinên gengaz çêdibin xelekên bi şîfreyên kodkirî (od x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // Pêkanîna deynek ecêb dikare ji bo hesabkirina dirêjahî û kopiya rastîn perçeyên cûda vegerîne.
        //
        // Pê ewle bine ku em byteyên uninitialized ji bangker re eşkere nakin.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// Rêbazên ji bo pelikên têl.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// `Box<str>` bêyî kopî kirin û veqetandin veguherîne `Box<[u8]>`.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// Hemî maçên şêweyekê bi têlek din vediguhêzîne.
    ///
    /// `replace` [`String`]-ya nû diafirîne, û daneyên ji vê têlê têl dike nav wê.
    /// Dema ku vî karî dike, ew hewl dide ku maçên qalibek peyda bike.
    /// Ger ew yekê bibîne, ew şûna wan qurmê têla vegêranê dide.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// Dema ku nimûneyek hev nagire:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Yekem N matchên nimûneyekê bi têlek din ve diguheze.
    ///
    /// `replacen` [`String`]-ya nû diafirîne, û daneyên ji vê têlê têl dike nav wê.
    /// Dema ku vî karî dike, ew hewl dide ku maçên qalibek peyda bike.
    /// Ger ew yekê bibîne, ew ê herî zêde `count` carî qiraxa têla veguherînê li şûna wan bide.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// Dema ku nimûneyek hev nagire:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // Hêvî dikim ku demên dabeşkirinê kêm bike
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Weke [`String`] nû, hevkêşeya piçûk a vê perçê têl vedigerîne.
    ///
    /// 'Lowercase' li gorî şertên Unicode Derived Core Property `Lowercase` tête diyar kirin.
    ///
    /// Ji ber ku hin tîp dema ku doz diguherin dikarin di gelek tîpan de berfireh bibin, ev fonksiyon li şûna ku parametreyê di cîh de biguherîne [`String`] vedigerîne.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// Mînakek zehf, bi sigma:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // lê li dawiya peyvekê, ew ς, ne σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// Zimanên bê keys nayên guhertin:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ nexşeya σ dike, ji bilî li dawiya peyvekê ku ew nexşe li ς dike.
                // Ev di `SpecialCasing.txt` de nexşeya tenê şert û merc (contextual) e lê ne-ziman-serbixwe ye, ji ber vê yekê wê şîfre bikin lê bila mekanîzmayek giştî ya "condition" hebe.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // ji bo danasîna `Final_Sigma`.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// Weke [`String`] nû hevoka mezin a vê perçê têl vedigerîne.
    ///
    /// 'Uppercase' li gorî şertên Unicode Derived Core Property `Uppercase` tête diyar kirin.
    ///
    /// Ji ber ku hin tîp dema ku doz diguherin dikarin di gelek tîpan de berfireh bibin, ev fonksiyon li şûna ku parametreyê di cîh de biguherîne [`String`] vedigerîne.
    ///
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// Nivîsên bêyî doz nayên guhertin:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// Karakterek dikare bibe pir:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// [`Box<str>`] bêyî kopî kirin û veqetandin veguherîne [`String`].
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// Bi dubarekirina rêzikek `n` carî [`String`] nû diafirîne.
    ///
    /// # Panics
    ///
    /// Ger kapasîteya wê zêde bibe ev fonksiyon dê panic be.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// panic li ser zêdebûnê:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// Kopiyek vê rêzê vedigerîne ku her karakter bi hevsengiya xweya mezin a ASCII re nexşandî ye.
    ///
    ///
    /// Nameyên ASCII 'a' bo 'z' bi 'A' bo 'Z' têne nexşekirin, lê tîpên ne-ASCII neguhêrîn.
    ///
    /// Ji bo ku nirxê di cîh de mezin bikin, [`make_ascii_uppercase`] bikar bînin.
    ///
    /// Ji bo tîpên ASCII mezin jî bila karakterên ne-ASCII, [`to_uppercase`] bikar bînin.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() neguhêzbariya UTF-8 diparêze.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// Kopiyek vê rêzê vedigerîne ku her karakter bi hevsengiya xweya piçûk a ASCII ve nexşandî ye.
    ///
    ///
    /// Nameyên ASCII 'A' bo 'Z' bi 'a' bo 'z' têne nexşekirin, lê tîpên ne-ASCII neguhêrîn.
    ///
    /// Ji bo ku nirxê di cîh de biçûk bikin, [`make_ascii_lowercase`] bikar bînin.
    ///
    /// Ji bo ku ji bilî tîpên ne-ASCII tîpên ASCII biçûk bin jî, [`to_lowercase`] bikar bînin.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() neguhêzbariya UTF-8 diparêze.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// Bêyî kontrol bike ku têl UTF-8-ya derbasdar heye, quncikek bayîtê ya baytkirî veguherîne qertek têl a qutikî.
///
///
/// # Examples
///
/// Bikaranîna bingehîn:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}