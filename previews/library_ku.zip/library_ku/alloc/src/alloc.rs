//! API-yên dabeşkirina bîranînê

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Ev sembolên efsûnî ne ku ji veqetandina gerdûnî re dibêjin.rustc wan diafirîne da ku bi `__rg_alloc` û hwd.
    // heke taybetmendiyek `#[global_allocator]` hebe (koda ku makroya taybetmendiyê berfireh dike wan fonksiyonan çêdike), an jî banga pêkanînên pêşkeftî yên li libstd (`__rdl_alloc` hwd.
    //
    // li `library/std/src/alloc.rs`) wekî din.
    // rustc fork ya LLVM jî di van navên fonksiyonan de-rewşên taybetî hene ku bikaribin wana wek `malloc`, `realloc`, û `free` baştir bikin, bi rêzê ve.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// Dabeşkerê bîrdariya cîhanî.
///
/// Ev celeb [`Allocator`] trait bi şandina bangên li dabeşkerê ku bi taybetmendiya `#[global_allocator]` hatî tomar kirin heke yek hebe, an jî default `std` crate bicîh tîne.
///
///
/// Note: dema ku ev celeb bêîstîkrar e, karbidestiya ku ew peyda dike bi [free functions in `alloc`](self#functions) ve tête peyda kirin.
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Bi dabeşkerê cîhanî re bîranîn veqetînin.
///
/// Heke hebe ev fonksiyon gazî rêbaza [`GlobalAlloc::alloc`] ya dabeşkerê dike ku bi taybetmendiya `#[global_allocator]` re hatî tomar kirin, an `std` crate ya xwerû ye.
///
///
/// Dema ku ew û [`Allocator`] trait aram bibin wê ev fonksiyon li hêviya rêbaza `alloc` ya celebê [`Global`] were betal kirin.
///
/// # Safety
///
/// [`GlobalAlloc::alloc`] bibînin.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Bi dabeşkerê cîhanî bîra xwe veqetînin.
///
/// Heke hebe ev fonksiyon gazî rêbaza [`GlobalAlloc::dealloc`] ya dabeşkerê dike ku bi taybetmendiya `#[global_allocator]` re hatî tomar kirin, an `std` crate ya xwerû ye.
///
///
/// Dema ku ew û [`Allocator`] trait aram bibin wê ev fonksiyon li hêviya rêbaza `dealloc` ya celebê [`Global`] were betal kirin.
///
/// # Safety
///
/// [`GlobalAlloc::dealloc`] bibînin.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Bi dabeşkerê gerdûnî re bîra xwe ji nû ve veqetînin.
///
/// Heke hebe ev fonksiyon gazî rêbaza [`GlobalAlloc::realloc`] ya dabeşkerê dike ku bi taybetmendiya `#[global_allocator]` re hatî tomar kirin, an `std` crate ya xwerû ye.
///
///
/// Dema ku ew û [`Allocator`] trait aram bibin wê ev fonksiyon li hêviya rêbaza `realloc` ya celebê [`Global`] were betal kirin.
///
/// # Safety
///
/// [`GlobalAlloc::realloc`] bibînin.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Bi dabeşkerê gerdûnî re bîranîna sifir-destpêkirî veqetînin.
///
/// Heke hebe ev fonksiyon gazî rêbaza [`GlobalAlloc::alloc_zeroed`] ya dabeşkerê dike ku bi taybetmendiya `#[global_allocator]` re hatî tomar kirin, an `std` crate ya xwerû ye.
///
///
/// Dema ku ew û [`Allocator`] trait aram bibin wê ev fonksiyon li hêviya rêbaza `alloc_zeroed` ya celebê [`Global`] were betal kirin.
///
/// # Safety
///
/// [`GlobalAlloc::alloc_zeroed`] bibînin.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // BELAW: `layout` di mezinahiyê de ne sifir e,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // EWLEH: : Eynî wekî `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // EWLEH: `new_size` ne sifir e lewra `old_size` ji `new_size` mezintir an wekhev e
            // wekî şertên ewlehiyê hewce dike.Pêdivî ye ku mercên din ji hêla bangker ve bêne pejirandin
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` dibe ku `new_size >= old_layout.size()` an tiştek mîna wê kontrol dike.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // EWLEH: ji ber ku `new_layout.size()` divê ji `old_size` mezintir an wekhev be,
            // hem dabeşkirina bîra kevn û hem jî ya nû ji bo xwendin û nivîsandina ji bo `old_size` byte derbasdar e.
            // Di heman demê de, ji ber ku dabeşkirina kevn hêj nehatiye veqetandin, ew nikare `new_ptr` li hev bike.
            // Ji ber vê yekê, banga `copy_nonoverlapping` ewledar e.
            // Divê peymana ewlehiyê ji bo `dealloc` ji hêla gazîvan ve were piştgirî kirin.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // BELAW: `layout` di mezinahiyê de ne sifir e,
            // şert û mercên din divê ji hêla bangker ve bêne pejirandin
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // EWLEH: divê hemî merc ji hêla bangker ve werin parastin
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // EWLEH: divê hemî merc ji hêla bangker ve werin parastin
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // EWLEH: TIN: divê şert û merc ji hêla bangdêr ve werin parastin
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // BELAW: : `new_size` ne sifir e.Pêdivî ye ku mercên din ji hêla bangker ve bêne pejirandin
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` dibe ku `new_size <= old_layout.size()` an tiştek mîna wê kontrol dike.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // EWLEH: ji ber ku `new_size` divê ji `old_layout.size()` piçûktir an wekhev be,
            // hem dabeşkirina bîra kevn û hem jî ya nû ji bo xwendin û nivîsandina ji bo `new_size` byte derbasdar e.
            // Di heman demê de, ji ber ku dabeşkirina kevn hêj nehatiye veqetandin, ew nikare `new_ptr` li hev bike.
            // Ji ber vê yekê, banga `copy_nonoverlapping` ewledar e.
            // Divê peymana ewlehiyê ji bo `dealloc` ji hêla gazîvan ve were piştgirî kirin.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// Dabeşkerê nîşankerên yekta.
// Divê ev fonksiyon venebe.Ger wiya bike, dê kodnasa MIR têk biçe.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Pêdivî ye ku ev îmze wek `Box` be, nexwe ICE dê pêk were.
// Gava ku pîvanek pêvek ji `Box` re were zêdekirin (mîna `A: Allocator`), ev pêdivî ye ku li vir jî were zêdekirin.
// Mînak heke `Box` bi `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)` were guhertin, pêdivî ye ku ev fonksiyon bi `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` jî were guhertin.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Berpirsyarê xeletiya dabeşkirinê

extern "Rust" {
    // Ev sembola efsûnî ye ku mirov bang li rêvebera xeletiyên dabeşkirina gerdûnî dike.
    // rustc wê diafirîne da ku heke `#[alloc_error_handler]` hebe gazî `__rg_oom` bike, an jî wekî din banga pêkanînên pêşîn ên li jêr (`__rdl_oom`) bike.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Li ser çewtî an têkçûna dabeşkirina bîranîn betal bikin.
///
/// Bangkerên API-yên dabeşkirina bîranînê yên ku dixwazin di bersiva xeletiyek dabeşkirinê de hesabê kurt bikin, têne şandin ku ji vê fonksiyonê re bang bikin, ji dêvla ku rasterast `panic!` an jî wekhev bang bikin.
///
///
/// Tevgerîna default ya vê fonksiyonê ev e ku hûn xeletiyek standard peyamek çap bikin û pêvajoyê betal bikin.
/// Ew dikare bi [`set_alloc_error_hook`] û [`take_alloc_error_hook`] were guhertin.
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Ji bo testa veqetandinê `std::alloc::handle_alloc_error` rasterast dikare were bikar anîn.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // bi navgîniya `__rust_alloc_error_handler` çêkirî tê bang kirin

    // heke `#[alloc_error_handler]` tune
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // heke `#[alloc_error_handler]` hebe
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Di bîranîna pêş-veqetandî, uninitialized de klonan pispor bikin.
/// Ji hêla `Box::clone` û `Rc`/`Arc::make_mut` ve tê bikar anîn.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Gava *yekem* veqetandî dibe ku destûrê bide optimizer ku nirxa klonkirî di cîh de biafirîne, herêmî biterikîne û bar bike.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Em dikarin hertim kopî bikin, bêyî ku tu carî nirxek herêmî têkildar bikin.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}