//! Dîtinek bi mezinahiya dînamîk a nav rêzek lihevhatî, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Slices dîmenek nav blokek bîranînê ye ku wekî pointer û dirêjahî tê nîşandan.
//!
//! ```
//! // perçek Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // bi zorê arrayek li perçeyek dike
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Slices an guhêrbar in an parvekirî ne.
//! Cureyê qurmê parvekirî `&[T]` e, dema ku qalikê guherbar `&mut [T]` e, ku `T` celebê hêmanê temsîl dike.
//! Mînakî, hûn dikarin bloka bîranînê ya ku perçeyek guhêrbar nîşan dide veguherînin:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Li vir çend tiştên ku ev modul tê de hene hene:
//!
//! ## Structs
//!
//! Çend kelûmêlên ku ji bo sliceyan bikêr in hene, wekî [`Iter`], ku dubarebûna li ser perçeyek temsîl dike.
//!
//! ## Trait Pêkanînên
//!
//! Ji bo slices gelek pêkanînên traits yên hevpar hene.Hin mînak hene:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], ji bo tebeqeyên ku celebê elementên wan [`Eq`] an [`Ord`] in.
//! * [`Hash`] - ji bo pelikên ku celebê elementê wan [`Hash`] ye.
//!
//! ## Iteration
//!
//! Pelikên `IntoIterator` bicîh dikin.Iterator referansên hêmanên perçeyê dide.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Pelê guhêrbar li ser hêmanan referansên guhêrbar dide:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Ev iterator referansên guhêrbar dide hêmanên perçeyê, ji ber vê yekê dema ku celebê elementê perçeyê `i32` e, celebê elementê veberhêner `&mut i32` ye.
//!
//!
//! * [`.iter`] û [`.iter_mut`] rêbazên eşkere ne ku vegerandinên pêşdibistanê vegerînin.
//! * Rêbazên din ên ku vegêran vedigerînin [`.split`], [`.splitn`], [`.chunks`], [`.windows`] û hêj bêtir in.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Di vê modulê de gelek karanîn tenê di veavakirina testê de têne bikar anîn.
// Paqijtir e ku meriv tenê hişyariya nexşedekirî ya bêserûber vemirîne ji serastkirina wan.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Rêbazên bingehîn ên dirêjkirina perçe
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) di dema ceribandina NB de ji bo pêkanîna makroya `vec!` pêdivî ye, ji bo bêtir agahdarî di vê pelê de moduleya `hack` bibînin.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) ji bo pêkanîna `Vec::clone` di dema ceribandina NB de pêdivî ye, ji bo bêtir agahdarî di vê pelê de moduleya `hack` bibînin.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Bi cfg(test) `impl [T]` tune, ev hersê fonksiyon bi rastî rêbazên ku di `impl [T]` de ne lê ne di `core::slice::SliceExt` de ne, em hewce ne ku van fonksiyonan ji bo testa `test_permutations` peyda bikin
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Pêdivî ye ku em taybetmendiya nexşandî li vê yekê zêde nekin ji ber ku ev di makroya `vec!` de bi piranî tê bikar anîn û dibe sedema paşvekişînê.
    // Ji bo nîqaş û encamên bêkêmasî li #71204 binêrin.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // Tiştên di xeleka li jêr de hatine destnîşankirin hatin nîşankirin
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) ji bo LLVM hewce ye ku venêranên sînoran derxe û ji zip-ê çêtir kodenas heye.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec li jor bi kêmî ve bi vê dirêjahiyê ve hate veqetandin û destpêkirin.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // li jor bi kapasîteya `s` hatî veqetandin, û li jêr `s.len()` li ptr::copy_to_non_overlapping destpê bike.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Qertê cûre dike.
    ///
    /// Ev celeb bi îstîqrar e (ango, hêmanên wekhev ji nû ve sererast nake) û *O*(*n*\*log(* n*)) rewşa xirab.
    ///
    /// Gava ku bikêr be, veqetandina bêîstîkrar tê tercîh kirin ji ber ku ew bi gelemperî ji dabeşkirina stabîl zûtir e û ew bîra alîkar naşîne.
    /// [`sort_unstable`](slice::sort_unstable) bibînin.
    ///
    /// # Pêkanîna heyî
    ///
    /// Algorîtmaya heyî ji hêla [timsort](https://en.wikipedia.org/wiki/Timsort) ve hatî îlhama kirin adapteyî ye, yekkirina dubare ye.
    /// Ew tête çêkirin ku di rewşên ku perçê hema hema rêzkirî ye, an ji du an zêdetir rêzikên rêzkirî yên li pey hev hatine girêdan de pir bilez be.
    ///
    ///
    /// Di heman demê de, ew depoya demkî ya nîv mezinahiya `self` veqetîne, lê ji bo perçeyên kurt li şûna wê rêzek navnîşê ya ne-veqetandek tê bikar anîn.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Pelê bi fonksiyonek berawirdkirinê rêz dike.
    ///
    /// Ev celeb bi îstîqrar e (ango, hêmanên wekhev ji nû ve sererast nake) û *O*(*n*\*log(* n*)) rewşa xirab.
    ///
    /// Divê fonksiyona berawirdê ji bo hêmanên di perçeyê de rêzikek tevahî diyar bike.Heke rêzkirin tevde nebe, rêza hêmanan nayê diyar kirin.
    /// Biryarek heke ew fermanek tevahî ye (ji bo hemî `a`, `b` û `c`):
    ///
    /// * tevde û antîsîmmetrîk: tam yek ji `a < b`, `a == b` an `a > b` rast e, û
    /// * gerguhêz, `a < b` û `b < c` `a < c` îfade dike.Divê heman tişt ji bo `==` û `>` jî hebe.
    ///
    /// Mînakî, dema ku [`f64`] ji ber ku `NaN != NaN` [`Ord`] bicîh nayne, em dikarin `partial_cmp` wekî fonksiyona xweya rêvekirinê bikar bînin dema ku em zanibin qutik `NaN` nagire.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Gava ku bikêr be, veqetandina bêîstîkrar tê tercîh kirin ji ber ku ew bi gelemperî ji dabeşkirina stabîl zûtir e û ew bîra alîkar naşîne.
    /// [`sort_unstable_by`](slice::sort_unstable_by) bibînin.
    ///
    /// # Pêkanîna heyî
    ///
    /// Algorîtmaya heyî ji hêla [timsort](https://en.wikipedia.org/wiki/Timsort) ve hatî îlhama kirin adapteyî ye, yekkirina dubare ye.
    /// Ew tête çêkirin ku di rewşên ku perçê hema hema rêzkirî ye, an ji du an zêdetir rêzikên rêzkirî yên li pey hev hatine girêdan de pir bilez be.
    ///
    /// Di heman demê de, ew depoya demkî ya nîv mezinahiya `self` veqetîne, lê ji bo perçeyên kurt li şûna wê rêzek navnîşê ya ne-veqetandek tê bikar anîn.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // berevajîkirina dabeşkirinê
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Pelê bi fonksiyonek derxistina kilîtê rêz dike.
    ///
    /// Vê cûreyek stabîl e (ango, hêmanên wekhev ji nû ve sererast nake) û *O*(*m*\* * n *\* log(*n*))-rewşa xirab, ku fonksiyona kilît *O*(*m*) e.
    ///
    /// Ji bo fonksiyonên sereke yên biha (mînakî
    /// fonksiyonên ku ne gihîştinên milkê sade an tevgerên bingehîn ne), [`sort_by_cached_key`](slice::sort_by_cached_key) dibe ku bi rengek zûtir be, ji ber ku tûşên hêmanê ji nû ve nade hesibandin.
    ///
    ///
    /// Gava ku bikêr be, veqetandina bêîstîkrar tê tercîh kirin ji ber ku ew bi gelemperî ji dabeşkirina stabîl zûtir e û ew bîra alîkar naşîne.
    /// [`sort_unstable_by_key`](slice::sort_unstable_by_key) binihêrin.
    ///
    /// # Pêkanîna heyî
    ///
    /// Algorîtmaya heyî ji hêla [timsort](https://en.wikipedia.org/wiki/Timsort) ve hatî îlhama kirin adapteyî ye, yekkirina dubare ye.
    /// Ew tête çêkirin ku di rewşên ku perçê hema hema rêzkirî ye, an ji du an zêdetir rêzikên rêzkirî yên li pey hev hatine girêdan de pir bilez be.
    ///
    /// Di heman demê de, ew depoya demkî ya nîv mezinahiya `self` veqetîne, lê ji bo perçeyên kurt li şûna wê rêzek navnîşê ya ne-veqetandek tê bikar anîn.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Pelê bi fonksiyonek derxistina kilîtê rêz dike.
    ///
    /// Di dema rêzkirinê de, ji fonksiyona mifteyê re her hêman tenê carek tê gotin.
    ///
    /// Ev celeb bi îstîqrar e (ango, hêmanên wekhev ji nû ve sererast nake) û *O*(*m*\* * n *+* n *\* log(*n*)) rewşa xirab, ku fonksiyona sereke *O*(*m*) e .
    ///
    /// Ji bo fonksiyonên sereke yên sade (mînakî, fonksiyonên ku destketiyên milkê an karûbarên bingehîn in), [`sort_by_key`](slice::sort_by_key) dibe ku zûtir be.
    ///
    /// # Pêkanîna heyî
    ///
    /// Algorîtmaya heyî li ser bingeha [pattern-defeating quicksort][pdqsort] ji hêla Orson Peters ve hatî damezrandin, ku doza navînî ya bilez a quicksort-a randomîzekirî digel doza bilez ya herî xirab a heapsortê re dike yek, dema ku li ser pelikên bi hin qalibên demî rêzê digihîne hev.
    /// Ew hin randombûnê bikar tîne da ku ji dozên dejenerebûyî dûr bikeve, lê digel seed sabît ku her gav tevgera diyarker peyda bike.
    ///
    /// Di rewşa herî xirab de, algorîtm di `Vec<(K, usize)>` de dirêjahiya perçeyê depoya demkî veqetîne.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Alîkarê makroyê ji bo indexkirina vector-ya me bi tîpa herî piçûk a gengaz, da ku veqetandinê kêm bike.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Hêmanên `indices` bêhempa ne, ji ber ku têne nîşankirin, ji ber vê yekê her cûre dê bi rêzgirtina perçeya orîjînal aram be.
                // Em li vir `sort_unstable` bikar tînin ji ber ku ew veqetandina bîranînê kêmtir hewce dike.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// `self` di `Vec` nû de kopî dike.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Li vir, `s` û `x` dikare serbixwe were guhertin.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// `self` bi veqetandek ve `Vec`-ya nû kopî dike.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Li vir, `s` û `x` dikare serbixwe were guhertin.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, ji bo bêtir agahdariyê di vê pelê de moduleya `hack` bibînin.
        hack::to_vec(self, alloc)
    }

    /// `self` bêyî klon û dabeşkirinê veguherîne vector.
    ///
    /// vector ya encam dikare bi rêya `Vec`ê vegere zeviyek<T>rêbaza `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` êdî nayê bikar anîn ji ber ku ew hatiye veguheztin `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, ji bo bêtir agahdariyê di vê pelê de moduleya `hack` bibînin.
        hack::into_vec(self)
    }

    /// Bi dubarekirina perçek `n` carî vector diafirîne.
    ///
    /// # Panics
    ///
    /// Ger kapasîteya wê zêde bibe ev fonksiyon dê panic be.
    ///
    /// # Examples
    ///
    /// Bikaranîna bingehîn:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// panic li ser zêdebûnê:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Ger `n` ji sifirê mezintir e, ew dikare wekî `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)` parçe bibe.
        // `2^expn` hejmar e ku bi hêla çepgirî ya '1' ya `n` ve tê nimînandin, û `rem` ya mayî ya `n` e.
        //
        //

        // `Vec` bikar tînin da ku xwe bigihînin `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` dubarekirin bi dubarekirina `buf` `demên expn` tê kirin.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Ger `m > 0`, heya '1'-ya herî çepê bîtên mayî hene.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` kapasîteya `self.len() * n` heye.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) dubarekirin bi kopîkirina yekem dubareyên `rem` ji `buf` bixwe tê kirin.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Ev ji `2^expn > rem` ve ne-li hevûdu ye.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` wekhevî `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Parçeyek `T` di nirxek yekbûyî `Self::Output` de nerm dike.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Parçeyek `T` di nirxek yekta `Self::Output` de nerm dike, di navbêna xwe de veqetandek danî.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Parçeyek `T` di nirxek yekta `Self::Output` de nerm dike, di navbêna xwe de veqetandek danî.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// vector-ê vedigerîne ku kopiyek vê perçeyê tê de heye ku her byte bi hevsengiya xweya mezin a ASCII re nexşe dike.
    ///
    ///
    /// Nameyên ASCII 'a' bo 'z' bi 'A' bo 'Z' têne nexşekirin, lê tîpên ne-ASCII neguhêrîn.
    ///
    /// Ji bo ku nirxê di cîh de mezin bikin, [`make_ascii_uppercase`] bikar bînin.
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// vector-ê vedigerîne ku kopiyek vê perçeyê tê de heye ku her byte li ser hevzayenda xweya piçûk a ASCII nexşandî ye.
    ///
    ///
    /// Nameyên ASCII 'A' bo 'Z' bi 'a' bo 'z' têne nexşekirin, lê tîpên ne-ASCII neguhêrîn.
    ///
    /// Ji bo ku nirxê di cîh de biçûk bikin, [`make_ascii_lowercase`] bikar bînin.
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// traits Zêdekirina ji bo pelikên li ser celebên taybetî yên daneyê
////////////////////////////////////////////////////////////////////////////////

/// Alîkarê trait ji bo [`[T]: : concat`](parçe::concat).
///
/// Note: parametreya type `Item` di vê trait de nayê bikar anîn, lê ew dihêle ku impls gelemperîtir bin.
/// Bêyî wê, em vê xeletiyê digirin:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Ji ber ku dibe ku celebên `V` bi pirrjimariyên `Borrow<[_]>` hebe, wusa ku gelek celebên `T` dê bikar bînin:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Tîpa encam piştî hevgirtinê
    type Output;

    /// Pêkanîna [`[T]: : concat`](parçe::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Helper trait ji bo [`[T]: : beşdarî`](parçe::beşdarî)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Tîpa encam piştî hevgirtinê
    type Output;

    /// Pêkanîna [`[T]: : beşdarî`](parçe::beşdarî)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Ji bo slices pêkanînên standard trait
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // tiştek bavêjin hedefa ku dê neyê nivîsandin
        target.truncate(self.len());

        // target.len <= self.len ji ber kurteya li jor, ji ber vê yekê pelikên li vir her gav di nav sînoran de ne.
        //
        let (init, tail) = self.split_at(target.len());

        // nirxên tê de allocations/resources ji nû ve bikar bînin.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// `v[0]` têxe nav rêza pêş-rêzkirî `v[1..]` da ku tevahiya `v[..]` bê rêzkirin.
///
/// Ev bine-rûtîna entegre ya celebê têxê ye.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Li vir sê awayên pêkanîna têvedanê hene:
            //
            // 1. Hêmanên teniştê biguhezînin heta ku yekem digihîje hedefa xweya dawî.
            //    Lêbelê, bi vî rengî em ji hewcedariya xwe bêtir daneyê li dora xwe kopî dikin.
            //    Heke hêmanên avahiyên mezin in (lêçûn lê kirin), dê ev rêbaz hêdî be.
            //
            // 2. Heya ku cîhê rast ji bo hêmana yekem neyê dîtin vedixwin.
            // Dûv re hêmanên serketî yên wê veguherînin da ku cîh jê re vekin û di dawiyê de wê têxin nav qulika mayî.
            // Ev rêbazek baş e.
            //
            // 3. Hêmana yekem kopî bikin nav guhêrbar a demkî.Heya ku cîhê guncan ji bo wê neyê dîtin dubare bikin.
            // Dema ku em diçin, her elementa derbazkirî di nav slota pêşiya xwe de kopî bikin.
            // Di dawiyê de, daneyên ji guhêrbar a demkî di qulika mayî de kopî bikin.
            // Ev rêbaz pir baş e.
            // Benchmarks ji rêbaza 2-emîn performansek hinekî baştir nîşan da.
            //
            // Hemî rêbaz têne pîvan kirin, û 3-an encamên çêtirîn nîşan dide.Ji ber vê yekê me ew yek hilbijart.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Dewleta navîn ya pêvajoya têketinê her dem ji hêla `hole` ve tête şopandin, ku du armanc bikar tîne:
            // 1. Yekitiya `v` ji panics di `is_less` de diparêze.
            // 2. Di dawiyê de qulika mayî ya `v` dagirtî.
            //
            // Panic ewlehî:
            //
            // Ger `is_less` panics di pêvajoyê de li her derê, `hole` dê hilweşe û qulika `v` bi `tmp` dagire, bi vî rengî dê piştrast bike ku `v` her tiştê ku di destpêkê de yekcar girtibû hildigire.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` dikeve û bi vî rengî `tmp` dixe nav qulika mayî ya `v`.
        }
    }

    // Dema ku daket, ji `src` nav `dest` kopî dike.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// `v[..mid]` û `v[mid..]`-ê wekî depoya demkî `v[..mid]` û `v[mid..]` bi rê ve dibe yek dike, û encamê di `v[..]` de vedigire.
///
/// # Safety
///
/// Divê du perçe ne vala bin û divê `mid` di nav sînoran de be.
/// Buffer `buf` divê têra xwe dirêj be ku kopiyek ji perçeya kurttir bigire.
/// Her weha, pêdivî ye ku `T` celebek nîv-sized nebe.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Pêvajoya yekbûnê pêşî kurteya kurteya `buf` kopî dike.
    // Dûv re ew şopa revê ya nû hatî kopî kirin û pêşdetir (an jî paşve) dirêje, hêmanên wan ên neçêkirî yên paşîn dide ber hev û ya piçûk (an mezintir) jî li `v` kopî dike.
    //
    // Hema ku dirêjahiya kurttir bi tevahî tê vexwarin, pêvajo tête kirin.Ger gava pêşîn dirêjtir were xerckirin, wê hingê divê em tiştê ku ji beşa kurttir mayî kopî bikin nav qulika mayî ya `v`.
    //
    // Dewleta navîn ya pêvajoyê her dem ji hêla `hole` ve tête şopandin, ku du armanc bikar tîne:
    // 1. Yekitiya `v` ji panics di `is_less` de diparêze.
    // 2. Ger gava pêşîn dirêjtir were xerckirin qulika mayî ya `v` dagirtî ye.
    //
    // Panic ewlehî:
    //
    // Ger `is_less` panics di pêvajoyê de li her derê, `hole` dê dakeve û qulika `v` bi `buf` ya bêserûber dagire, bi vî rengî wê piştrast bike ku `v` her tiştê ku di destpêkê de tam carekê digire hildigire.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Riya çepê kurttir e.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Di destpêkê de, van nîşangiran îşaret bi destpêka rêzikên xwe dikin.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Aliyê kêmtir bixwe.
            // Ger wekhev be, ji bo domandina aramiyê beza çep tercîh bikin.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Riya rast kurttir e.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Di destpêkê de, van nîşangiran dawiya rêzikên xwe nîşan didin.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Aliyê mezintir bixwe.
            // Ger wekhev be, ji bo domandina aramiyê runa rast tercîh bikin.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Di dawiyê de, `hole` dikeve.
    // Heke rêvekirina kurttir bi tevahî neyê xerckirin, ya ku jê bimîne dê nuha di qulika `v` de were kopî kirin.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Dema ku davêjin, rêzeya `start..end` li `dest..` kopî dike.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` ne celebek sifir-sized e, ji ber vê yekê baş e ku meriv bi mezinahiya xwe parve bike.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Vê cûreya merge hin (lê ne hemî) ramanan ji TimSort, ku bi berfirehî [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt) tête vegotin, deyn dike.
///
///
/// Algorîtm şemitînên bi şidandî yên daketin û ne-daketin, ku ji wan re tebeqeyên xwezayî têne gotin, nas dike.Dîsa rêgezek bendewar heye ku neyê yekkirin.
/// Her rêwîtiyek ku nû hatî dîtin li ser stackê tê xistin, û dûv re hin cot rêvekirinên cîran têne yek kirin heya ku ev her du navdar têr bibin:
///
/// 1. ji bo her `i` di `1..runs.len()` de: `runs[i - 1].len > runs[i].len`
/// 2. ji bo her `i` di `2..runs.len()` de: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Neguhêrbar piştrast dikin ku dema xebata tevahî *O*(*n*\*log(* n*)) rewşa xirab e).
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Pelên heta vê dirêjahiyê bi karanîna navnîşkirina dabeşkirinê têne rêz kirin.
    const MAX_INSERTION: usize = 20;
    // Runên pir kurt bi karanîna navnîşkirinê têne dirêj kirin ku bi kêmî ve ev gelek hêmanan dorpêç bikin.
    const MIN_RUN: usize = 10;

    // Sortkirin li ser celebên sifir-sized tevgerek watedar nîne.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Array-yên kurt ji bo ku ji dabeşkirinan dûr nekevin bi navgîniya navnîşkirinê li cîh têne rêz kirin.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Tamponek veqetînin da ku wekî bîra xêzikê bikar bînin.Em dirêjahiya 0 digirin da ku em karibin tê de kopiyên kûr ên naverokên `v` bigirin bêyî ku xeterê bikin ku doktor heke `is_less` panics li ser kopiyan bimeşin.
    //
    // Dema ku du rêdanên dabeşkirî dibin yek, ev tampon nusxeyek ji runa kurtir, ya ku dê timûtim herî zêde `len / 2` hebe, digire.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Ji bo ku em li `v` runên xwezayî nas bikin, em wê paşde derbas dikin.
    // Ew dibe ku wekî biryarek ecêb xuya dike, lê rastiya ku yek dibin pir caran ber bi berevajî (forwards) ve biçin binihêrin.
    // Li gorî pîvangehan, yekkirina pêşverû ji tevhevkirina paşverû hinekî zûtir e.
    // Ji bo encamgirtinê, destnîşankirina bezên bi şopandina paşverû performansê baştir dike.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Riya xwezayî ya paşîn bibînin, û heke ew bi hişkî dakêşin berevajî bikin.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Heke pir kurt be hin hêmanên din jî têxin dewrê.
        // Rêzkirina danasînê ji berhevdana li rêzikên kurt zûtir e, ji ber vê yekê ev performans bi girîngî baştir dike.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Vê bezê bikişînin ser pêlikê.
        runs.push(Run { start, len: end - start });
        end = start;

        // Ji bo têrkirina neguhêzbariyan hin cot meşên cîran bikin yek.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Di dawiyê de, tam yek bez divê di stackê de bimîne.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Pelê rêveyan vedikole û cotê rêveyên din ên ku dibin yek.
    // Bi taybetî, heke `Some(r)` were vegerandin, ew tê vê wateyê ku divê `runs[r]` û `runs[r + 1]` li paş werin yek kirin.
    // Ger pêdivî ye ku algorîtm li şûna wê avabûnek nû berdewam bike, `None` vedigere.
    //
    // TimSort ji bo sepandinên xwe yên çewt navdar e, wekî ku li vir hatî şirove kirin:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Bingeha çîrokê ev e: divê em neguhêrînên li ser çar rêşên jorîn ên li ser stackê bicîh bikin.
    // Bi zorê bicîhkirina wan tenê li ser sê hebên jorîn ne bes e ku bicîh bikin ku neguhêrbar hîn jî dê *hemî* bezên di stackê de bigirin.
    //
    // Ev fonksiyon ji bo çar rêgezên jorîn bi nerastî nemanan kontrol dike.
    // Wekî din, heke rêvekirina jorîn di index 0 de dest pê bike, ew ê her dem operasyona yekbûnê bixwaze heya ku stack bi tevahî hilweşe, ji bo ku rêzê biqedîne.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}