#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Naverokên bîranîna nû nayên destpekirin.
    Uninitialized,
    /// Bîra nû garantî dibe ku bê sifirkirin.
    Zeroed,
}

/// Kêrhatinek asta nizm a ji bo bêtir ergonomîkî veqetandin, ji nû ve veqetandin û veqetandina tamponek bîranînê ya li ser hepê bêyî ku xema hemî bûyerên quncikê têkildar bike.
///
/// Ev celeb ji bo avakirina avahiyên daneyên xwe yên mîna Vec û VecDeque baş e.
/// Gelek rindik:
///
/// * Li ser celebên sifir-mezinahî `Unique::dangling()` hilberîne.
/// * Li ser dabeşkirinên nîv-dirêj `Unique::dangling()` hilberîne.
/// * Ji azadkirina `Unique::dangling()` dûr dikeve.
/// * Di hesabên kapasîteyê de her serhildanan digire (wan ber bi "capacity overflow" panics ve dibe).
/// * Li hember pergalên 32-bit zêdeyî isize::MAX byte veqetandî cerdevan.
/// * Gardiyan li hember dirêjahiya we zêde nabe.
/// * Ji bo veqetandinên xelet bang li `handle_alloc_error` dike.
/// * `ptr::Unique`-ê vedigire û bi vî rengî hemî feydeyên pêwendîdar dide bikarhêner.
/// * Zêdebûna ku ji veqetandinê vegeriyaye bikar tîne da ku kapasîteya heyî ya herî mezin bikar bîne.
///
/// Ev celeb bi her awayî bîraya ku ew îdare dike venêran dike.Gava ku ew ket *wê* bîranîna xwe azad bike, lê ew *ê* hewl nede ku naveroka wê bavêje.
/// Ew bi bikarhênerê `RawVec` re ye ku tiştên rastîn ên * di hundurê `RawVec` de hatine hilanîn bi dest bixe.
///
/// Zanibe ku zêdeyî celebên sifir-mezinahî her dem bêdawî ye, ji ber vê yekê `capacity()` her dem `usize::MAX` vedigerîne.
/// Ev tê vê wateyê ku hûn hewce ne ku gava vî celebî bi `Box<[T]>`-dorpêç bikin hişyar bimînin, ji ber ku `capacity()` dê dirêjahî nede.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Ev heye ji ber ku `#[unstable]` `const fn` ne hewce ye ku bi `min_const_fn` re lihevhatî be û ji ber vê yekê ew nekarin li`min_const_fn` jî bêne gazîkirin.
    ///
    /// Ger hûn `RawVec<T>::new` an pêvekan biguherînin, ji kerema xwe lênihêrin ku hûn tiştek ku bi rastî `min_const_fn` binpê dike destnîşan nekin.
    ///
    /// NOTE: Em dikarin dev ji vê hackê berdin û lihevhatina bi hin taybetmendiyên `#[rustc_force_min_const_fn]` ku pêdivî bi lihevhatina `min_const_fn` hewce dike dûr bixin lê pêdivî ye ku destûr nade ku li `stable(...) const fn`/koda bikarhêner bang bike ku nehêle `foo` dema ku `#[rustc_const_unstable(feature = "foo", issue = "01234")]` heye bang bike.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Bêyî ku veqetîne `RawVec`-a herî mezin (li ser pergalê pergalê) gengaz diafirîne.
    /// Ger mezinahiya erênî ya `T` hebe, wê hingê ev bi kapasîteya `0` `RawVec` dike.
    /// Ger `T` sifir-mezinahî be, wê hingê ew bi kapasîteya `usize::MAX` `RawVec` dike.
    /// Ji bo bicihanîna dabeşkirina derengî bikêr e.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// `RawVec` (li ser heapa pergalê) bi tevahî pêdiviyên kapasîte û rêzkirinê ji bo `[T; capacity]` diafirîne.
    /// Ev wekhev e ku `RawVec::new` bang bikin dema ku `capacity` `0` be an `T` sifir-mezinahî be.
    /// Bala xwe bidinê ku heke `T`-sized sifir be ev tê vê wateyê ku hûn ê * kapasîteya ku tê xwestin `RawVec` nagirin.
    ///
    /// # Panics
    ///
    /// Heke kapasîteya daxwazkirî ji `isize::MAX` bayîtan derbas bike Panics.
    ///
    /// # Aborts
    ///
    /// Li ser OOM kurt dike.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Mîna `with_capacity`, lê garantî dike ku tampon sifir e.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// `RawVec` ji pointer û kapasîteyê ji nû ve saz dike.
    ///
    /// # Safety
    ///
    /// Divê `ptr` were veqetandin (li ser heap pergalê), û bi `capacity` dayîn.
    /// `capacity` ji bo celebên mezinahî nikare ji `isize::MAX` derbas bibe.(tenê xemgîniyek li ser pergalên 32-bit).
    /// Dibe ku kapasîteya ZST vectors heya `usize::MAX` hebe.
    /// Ger `ptr` û `capacity` ji `RawVec` were, wê hingê ev garantî ye.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Vecên piçûk lal in.Skip to:
    // - 8 heke mezinahiya hêmanê 1 be, ji ber ku her dabeşkerên heapê dibe ku daxwazek ji 8 bayt kêmtir bi kêmîve 8 byte dorpêç bikin.
    //
    // - 4 heke hêmanên bi mezinahî nerm bin (<=1 KiB).
    // - 1 wekî din, da ku hûn ji bo Vecên pir kurt pir cîh neyê wunda kirin.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Mîna `new`, lê li ser hilbijartina veqetandek ji bo `RawVec` vegerandin parametre kirin.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` tê wateya "unallocated".celebên sifir-sized têne paşguh kirin.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Mîna `with_capacity`, lê li ser hilbijartina veqetandek ji bo `RawVec` vegerandin parametre kirin.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Mîna `with_capacity_zeroed`, lê li ser hilbijartina veqetandek ji bo `RawVec` vegerandin parametre kirin.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// `Box<[T]>` veguherîne `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Hemî tampona bi `len` ya diyarkirî veguherîne `Box<[MaybeUninit<T>]>`.
    ///
    /// Bala xwe bidinê ku ev ê her guhertinên `cap` ên ku dibe ku hatibin kirin bi durustî ji nû ve saz bike.(Ji bo hûragahiyan li danasîna celebê binihêrin.)
    ///
    /// # Safety
    ///
    /// * `len` divê ji kapasîteya herî dawî ya hatî xwestin mezintir be an jî wekhev be, û
    /// * `len` divê ji `self.capacity()` kêmtir an wekhev be.
    ///
    /// Têbînî, ku kapasîteya daxwazkirî û `self.capacity()` dikare ji hev cûda bibin, ji ber ku dabeşker dikare blokek bîranînê ya ji daxwazê mezintir bi cî bike û vegerîne.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Sanity-nîvê hewcedariya ewlehiyê-kontrol bikin (em nikarin nîvê din jî kontrol bikin).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Em ji `unwrap_or_else` li vir dûr dixin ji ber ku ew mîqdara LLVM IR-ê çêkirî şil dike.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// `RawVec` ji pointer, kapasîte û dabeşkerê ji nû ve saz dike.
    ///
    /// # Safety
    ///
    /// Divê `ptr` were veqetandin (bi navgîniya dabeşkerê `alloc`), û bi `capacity` ve hatî dayîn.
    /// `capacity` ji bo celebên mezinahî nikare ji `isize::MAX` derbas bibe.
    /// (tenê xemgîniyek li ser pergalên 32-bit).
    /// Dibe ku kapasîteya ZST vectors heya `usize::MAX` hebe.
    /// Ger `ptr` û `capacity` ji `RawVec` ya ku bi rêya `alloc` hatî afirandin were, wê hingê ev garantî ye.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Destpêkek dabeşkirinê pêşekek raweyî digire.
    /// Zanibe ku ev `Unique::dangling()` e heke `capacity == 0` an `T` sifir-mezinahî be.
    /// Di rewşa berê de, divê hûn hay jê hebin.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Kapasîteya dabeşkirinê digire.
    ///
    /// Ger `T` sifir-mezinahî be ev dê her dem `usize::MAX` be.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Çavkaniyek hevpar vedigerîne dabeşkerê ku pişta xwe dide vê `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Me pişkek bîranînê ya veqetandî heye, ji ber vê yekê em dikarin ji kontrolên rûtînê dûr bixin da ku em pêşnumaya xweya nuha bistînin.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Misoger dike ku tampon bi kêmî ve têra xwe cîh digire ku hêmanên `len + additional` bigire.
    /// Heke jixwe kapasîteya wê têrê neke, dê têra xwe cîhek zêde bike û valahiya xweş a rehet ji nû ve veqetîne da ku tevgera *O*(1) amortîzekirî bistîne.
    ///
    /// Heke ew ê xwe bêserûber bibe sedema panic dê vê tevgerê bi sînor bike.
    ///
    /// Ger `len` ji `self.capacity()` derbas bibe, dibe ku ev nebe ku bi rastî cîhê daxwazkirî veqetîne.
    /// Ev ne bi rastî ne ewledar e, lê koda *ewle* ya ku hûn dinivîsin û xwe dispêre tevgera vê fonksiyonê dikare bişkîne.
    ///
    /// Ev ji bo bicihanîna tevgera pişkdariyê ya mîna `extend` îdeal e.
    ///
    /// # Panics
    ///
    /// Panics heke kapasîteya nû `isize::MAX` bayît derbas bike.
    ///
    /// # Aborts
    ///
    /// Li ser OOM kurt dike.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // rezervan dê betal bibûya an bihata panîk heke len ji `isize::MAX` derbas bikira ji ber vê yekê ewle ye ku naha bê kontrol kirin.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Heman wekî `reserve`, lê li şûna panîk an kurtajê li xeletiyan vedigere.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Misoger dike ku tampon bi kêmî ve têra xwe cîh digire ku hêmanên `len + additional` bigire.
    /// Heke ew jixwe neke, dê kêmtirîn bîranîna gengaz a hewceyê ji nû ve veqetîne.
    /// Bi gelemperî ev dê mîqdara bîranîna hewce be, lê di esasê de dabeşker azad e ku ji ya ku me xwestî bide.
    ///
    ///
    /// Ger `len` ji `self.capacity()` derbas bibe, dibe ku ev nebe ku bi rastî cîhê daxwazkirî veqetîne.
    /// Ev ne bi rastî ne ewledar e, lê koda *ewle* ya ku hûn dinivîsin û xwe dispêre tevgera vê fonksiyonê dikare bişkîne.
    ///
    /// # Panics
    ///
    /// Panics heke kapasîteya nû `isize::MAX` bayît derbas bike.
    ///
    /// # Aborts
    ///
    /// Li ser OOM kurt dike.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Heman wekî `reserve_exact`, lê li şûna panîk an kurtajê li xeletiyan vedigere.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Dabeşandinê daxîne mîqdara diyarkirî.
    /// Ger mîqdara dayîn 0 be, bi rastî bi tevahî tê deallokirin.
    ///
    /// # Panics
    ///
    /// Panics heke mîqdara dayîn ji kapasîteya heyî *mezintir* be.
    ///
    /// # Aborts
    ///
    /// Li ser OOM kurt dike.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Ger tampon pêdivî be mezin bibe vedigere da ku kapasîteya zêde ya hewce pêk bîne.
    /// Bi piranî ji bo ku navnîşkirina bangên rezerv bêyî navnîşkirina `grow` gengaz were bikar anîn.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Ev rêbaz bi gelemperî gelek caran tête saz kirin.Ji ber vê yekê em dixwazin ku ew gengaz hindik be, ku demên berhevkar baştir bibe.
    // Lê em di heman demê de dixwazin ku heya naveroka wê ji hêla statîkî ve mimkun be, da ku koda çêkirî zûtir bimeşe.
    // Ji ber vê yekê, ev rêbaz bi baldarî tête nivîsandin da ku hemî koda ku bi `T` ve girêdayî ye di hundurê wê de be, dema ku bi qasî koda ku bi `T` ve girêdayî nabe wekî fonksiyonên ku li ser `T` ne-gelemperî ne.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Ev ji hêla navendên gazî ve tête peyda kirin.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Ji ber ku em kapasîteya `usize::MAX` vedigerin dema ku `elem_size` e
            // 0, gihîştina vir pêdivî ye ku wateya `RawVec` pir e.
            return Err(CapacityOverflow);
        }

        // Tiştek ku em bi rastî nekarin li ser van kontrolan bikin, mixabin.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Ev mezinbûna pêşkeftî garantî dike.
        // Ducarbûn nikare zêde bibe ji ber ku `cap <= isize::MAX` û celebê `cap` `usize` e.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` li ser `T` ne-gelemperî ye.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Astengiyên li ser vê rêbazê pir in wekî yên li ser `grow_amortized`, lê ev rêbaz bi gelemperî kêmtir caran tête rast kirin ji ber vê yekê ew kêmtir krîtîk e.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Ji ber ku em kapasîteya `usize::MAX` vedigerin dema ku mezinahiya celebê ye
            // 0, gihîştina vir pêdivî ye ku wateya `RawVec` pir e.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` li ser `T` ne-gelemperî ye.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Ev fonksiyon li derveyî `RawVec` e ku demên berhevkirinê kêm bike.Ji bo hûrguliyan şîroveya li jor `RawVec::grow_amortized` bibînin.
// (Parametera `A` ne girîng e, ji ber ku hejmara celebên cûda `A` di pratîkê de têne dîtin ji hejmara `T` pir kêmtir e.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Li vir xeletiyê kontrol bikin da ku mezinahiya `RawVec::grow_*` kêm bikin.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Dabeşker wekheviya alignê kontrol dike
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Bêyî ku *hewl bide ku naveroka wê biavêje bîraya xwedan `RawVec`* azad dike.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Fonksiyona navendî ji bo karûbarê xeletiya rezervan.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Em hewce ne ku jêrîn garantî bikin:
// * Em tiştik tiştên Xweya Bite-size dabeş nakin.
// * Em ji `usize::MAX` zêde naherikin û bi rastî jî pir hindik dabeş dikin.
//
// Li ser 64-bit em tenê hewce ne ku ji bo zêdebûnê kontrol bikin ji ber ku hewildana veqetandina byteyên `> isize::MAX` dê bê guman têk biçe.
// Li ser 32-bit û 16-bit pêdivî ye ku em ji bo vê yekê cerdevanek zêde jî lê zêde bikin heke ku em li platformek ku dibe ku hemî 4GB-ê di nav-qada bikarhêner de bikar bînin, mînaka PAE an x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Yek fonksiyona navendî ya ku ji ragihandina kapasîteya zêde serûber dibe
// Ev ê piştrast bike ku nifşa kodê ya bi van panics ve têkildar kêm be ji ber ku tenê cîhek ku panics heye ji bilî komek li seranserê modulê heye.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}