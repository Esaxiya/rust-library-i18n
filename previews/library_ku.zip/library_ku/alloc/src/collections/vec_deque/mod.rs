//! Dûvek duduyan bi tamponek rîngê ya geşker ve hate pêkanîn.
//!
//! Di vê dorê de ji her du deviyên konteynir *O*(1) amortîzekirin û rakirin.
//! Di heman demê de tê de *O*(1) wekî vector endeksiyon heye.
//! Pêdivî ye ku hêmanên pêgirtî neyên kopî kirin, û heke celebê şandî bişîne dê rêz bê şandin.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // Hêza gengaz a herî mezin a du

/// Dûvek duduyan bi tamponek rîngê ya geşker ve hate pêkanîn.
///
/// Bikaranîna "default" ya vî rengî wekî dorê ew e ku [`push_back`] bikar bînin ku li dorê zêde bikin, û [`pop_front`] jî ji dorê rakin.
///
/// [`extend`] û [`append`] bi vî rengî li piştê dixin, û li `VecDeque` dubare dibe pêş bi paş.
///
/// Ji ber ku `VecDeque` tamponek zengilekê ye, hêmanên wê ne hewce ne ku di bîranînê de li pey hev bin.
/// Heke hûn dixwazin wekî perçek yekane bigihîjin hêmanan, mînakî ji bo dabeşandina bi bandor, hûn dikarin [`make_contiguous`] bikar bînin.
/// Ew `VecDeque` dizivire da ku hêmanên wê neqeliqin, û perçeyek mutabîl vegerîne rêzeya hêmana niha-lihevhatî.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // dûv û serî nîşangirên nav tamponê ne.
    // Dail her gav îşaret bi hêmana yekem a ku dikare were xwendin dike, Serê her gav nîşanî cihê ku divê dane were nivîsandin bide.
    //
    // Ger dûv==serî tampon vala ye.Dirêjahiya ringbuffer wekî mesafeya di navbera her duyan de tête diyar kirin.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// Dema ku hilweşîner (ji bo normal an jî di dema vebûnê) de hilweşîner ji bo hemî hêmanên di perçeyê de dimeşîne.
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // drop ji bo [T] bikar bînin
            ptr::drop_in_place(front);
        }
        // RawVec deallocation-ê digire dest
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// `VecDeque<T>`-a vala diafirîne.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// Bi marjînalî hêsantir
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// Bi marjînalî hêsantir
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // Ji bo celebên sifir, em her dem di kapasîteya herî zêde de ne
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// Ptr veguherînin perçeyek
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// Ptr veguherînin perçeyek mut
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// Hêmanek ji tamponê bar dike
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// Hêmanek di tamponê de dinivîse, wê digerîne.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// Ger tampon bi tevahî kapasîteya xwe be `true` vedigerîne.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// Indeksa di tampona bingehîn de vedigerîne ji bo danasîna hêmana hêmana mantiqî.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// Indeksa di tampona bingehîn de vedigerîne ji bo danasîna hêmana hêmana mantiqî + pêvek.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// Indeksa di tampona bingehîn de vedigerîne ji bo danasîna hêmana hêmana mantiqî, subrahend.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// Astengiya bîranînê ya lihevhatî ji src heta dst dirêj dirêj kopî dike
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Astengiya bîranînê ya lihevhatî ji src heta dst dirêj dirêj kopî dike
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Astengiya pêgirtê ya bîrê ya ku ji src heta dest dirêj dirêj dibe kopî dike.
    /// (abs(dst - src) + len) divê ji cap() ne mezintir be (Divê herî zêde di navbera src û dest de herêmek bi hev re ya domdar hebe).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src pêça nake, dst pêça nade
                //
                //        S..
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] D.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // dst berî src, src pêça nake, dst pêça
                //
                //
                //    S..
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. D.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // src berî dst, src pêça nake, dst pêça
                //
                //
                //              S..
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. D.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // dst berî src, src pêça, dst pêça nake
                //
                //
                //    .. S.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] D...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // src berî dst, src pêça, dst pêça nake
                //
                //
                //    .. S.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] D...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // dst berî src, src pêça, dst pêça
                //
                //
                //    ... S.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. D..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // src berî dst, src pêça, dst pêça
                //
                //
                //    .. S..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... D
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// Dabeşên serî û dûvikê li derdorê frobs dike da ku rastiya ku em tenê ji nû ve veqetandî bigire dest.
    /// Ne ewle ye ji ber ku ew bi kapasîteya_kevn bawer dike.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // Dabeşa herî kurt a lihevhatî ya tampona ring TH-ê bar bikin
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [...ooooooo......
        //          ] HT
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // Na
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// `VecDeque`-a vala diafirîne.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// Ji bo kêmtirîn hêmanên `capacity` bi cîh `VecDeque`-a vala diafirîne.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 ji ber ku ringbuffer her gav valahiyek vala dike
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// Di navnîşa dayîn de referansek ji hêmanê re peyda dike.
    ///
    /// Hêmana li nîşana 0 pêşiya rêzê ye.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Di nav indexa hanê de referansa guherbar a elementê peyda dike.
    ///
    /// Hêmana li nîşana 0 pêşiya rêzê ye.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Hêmanan li indexên `i` û `j` diguheze.
    ///
    /// `i` û `j` dibe ku wekhev bin.
    ///
    /// Hêmana li nîşana 0 pêşiya rêzê ye.
    ///
    /// # Panics
    ///
    /// Panics heke an index derveyî sînoran be.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// Hejmara hêmanên ku `VecDeque` dikare bêyî veqetandinê vehewîne vedigerîne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// Kapasîteya herî kêm ji bo hêjayî `additional` hêmanên din ên ku di `VecDeque`-ya dayînê de bêne hilanîn, diparêze.
    /// Heke kapasîte jixwe bes be tiştek nake.
    ///
    /// Zanibe ku dabeşker dikare ji berhevokê zêdetir ji ya ku ew daxwaz dike bide.
    /// Ji ber vê yekê ji kapasîteyê re ne mimkun e ku meriv bi kêmasî be.
    /// Ger têkela future tê hêvîkirin [`reserve`] tercîh bikin.
    ///
    /// # Panics
    ///
    /// Ger kapasîteya nû `usize` biherike Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// Kapasîteya rezervan ji bo kêmtirîn `additional` hêmanên din ên ku di `VecDeque` dane de werin vehewandin.
    /// Dibe ku berhevok cîhê bêtir veqetîne da ku ji nû ve veqetandinan dûr nekeve.
    ///
    /// # Panics
    ///
    /// Ger kapasîteya nû `usize` biherike Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// Hewil dide ku kapasîteya herî kêm ji bo hêjayî `additional` hêmanên din ên ku di `VecDeque<T>` dayîn de werin vehewandin veqetîne.
    ///
    /// Piştî bangkirina `try_reserve_exact`, kapasîte dê ji `self.len() + additional` mezintir an wekhev be.
    /// Heke kapasîte jixwe bes be tiştek nake.
    ///
    /// Zanibe ku dabeşker dikare ji berhevokê zêdetir ji ya ku ew daxwaz dike bide.
    /// Ji ber vê yekê, ji kapasîteyê re ne mimkun e ku meriv bi kêmasî be.
    /// Ger têkela future tê hêvîkirin `reserve` tercîh bikin.
    ///
    /// # Errors
    ///
    /// Ger kapasîteya `usize` zêde bibe, an dabeşker têkçûnek ragihîne, wê hingê xeletiyek tê vegerandin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Berê bîranînê veqetînin, ger em nekarin derkevin
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Naha em dizanin ku ev nikare OOM(Out-Of-Memory) di orta xebata meya tevlihev de
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // pir tevlihev
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// Hewil dide ku kapasîteyê ji bo kêmtirîn `additional` hêmanên din vehewîne ku di `VecDeque<T>`-ya dayînê de were vehewandin.
    /// Dibe ku berhevok cîhê bêtir veqetîne da ku ji nû ve veqetandinan dûr nekeve.
    /// Piştî bangkirina `try_reserve`, kapasîte dê ji `self.len() + additional` mezintir an wekhev be.
    /// Heke kapasîte jixwe bes be tiştek nake.
    ///
    /// # Errors
    ///
    /// Ger kapasîteya `usize` zêde bibe, an dabeşker têkçûnek ragihîne, wê hingê xeletiyek tê vegerandin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Berê bîranînê veqetînin, ger em nekarin derkevin
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Naha em dizanin ku ev nikare OOM di nîveka xebata meya tevlihev de
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // pir tevlihev
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// Qasî ku mimkûn e kapasîteya `VecDeque` kurt dike.
    ///
    /// Ew ê bi qasî mimkun bi dirêjahiyê dakeve lê veqetandek hîn jî dikare `VecDeque` agahdar bike ku ji bo çend hêmanên din cîh heye.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// Kapasîteya `VecDeque` bi bendek jêrîn şîn dike.
    ///
    /// Kapasîte dê herî kêm bi qasî dirêjahî û nirxa dabînkirî mezin bimîne.
    ///
    ///
    /// Heke kapasîteya heyî ji tixûbê jêrîn kêmtir e, ev ne-op e.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // Em ne hewce ne ku ji ber zêdebûnê xeman bikin ji ber ku ne `self.len()` ne jî `self.capacity()` carî nikarin `usize::MAX` bin.
        // +1 wekî ringbuffer her dem yek cîhek vala dihêle.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // Sê bûyerên balkêş hene:
            //   Hemî hêman ji sînorên xwestî ne Hêmanên lihevhatî ne, û serî ji tixûbên xwestî ne Hêmanên bêserûber in, û dûvik ji sînorên xwestî ye
            //
            //
            // Di her demên din de, helwestên hêmanê bê bandor dibin.
            //
            // Nîşan dide ku divê hêmanên li serî werin veguheztin.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // Hêmanên ji derveyî sînorên xwestin (helwestên piştî kepçê target) veguherînin
            if self.tail >= target_cap && head_outside {
                // TH
                //   [. . . . . . . . o o o o o o o . ]
                //    TH
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // TH
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// `VecDeque` kurt dike, hêmanên yekem `len` digire û yê mayî davêje.
    ///
    ///
    /// Ger `len` ji dirêjahiya ``VecDeque`` mezintir be, ev ti bandorek tune.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// Dema ku hilweşîner (ji bo normal an jî di dema vebûnê) de hilweşîner ji bo hemî hêmanên di perçeyê de dimeşîne.
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // Ewle ji ber ku:
        //
        // * Her perçeyek ku derbasî `drop_in_place` dibe derbasdar e;doza duyemîn `len <= front.len()` heye û vegera li `len > self.len()` di rewşa yekem de `begin <= back.len()` misoger dike
        //
        // * Serê VecDeque berî bangkirina `drop_in_place` tête barkirin, ji ber vê yekê heke `drop_in_place` panics du caran nirx neyê daketin
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // Piştrast bikin ku nîvê duyemîn jî tê avêtin dema ku hilweşînekek di yekem panics de be.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// Vedigereke pêş-paş vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// Vedigereke pêş-li-paş vedigerîne ku referansên guhêrbar vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // BELA: Ji ber ewlehiya navxweyî ya ewlehiya `IterMut` tête saz kirin
        // `ring` em diafirînin perçeyek dereferencable ya jiyanê ye '_.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Cotek pelikên ku bi rêzê, naveroka `VecDeque` vedigire vedigerîne.
    ///
    /// Heke berê ji [`make_contiguous`] re digotin, dê hemî hêmanên `VecDeque` di qulikê yekem de be û qurmê duyemîn jî dê vala be.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// Cotek pelikên ku bi rêzê, naveroka `VecDeque` vedigire vedigerîne.
    ///
    /// Heke berê ji [`make_contiguous`] re digotin, dê hemî hêmanên `VecDeque` di qulikê yekem de be û qurmê duyemîn jî dê vala be.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// Hejmara hêmanên di `VecDeque` de vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// Ger `VecDeque` vala be `true` vedigire.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// Iterator-ê ku di `VecDeque`-ê de dora diyarkirî vedihewîne diafirîne.
    ///
    /// # Panics
    ///
    /// Panics heke xala destpêkê ji xala dawî mezintir be an xala dawiyê ji dirêjahiya vector mezintir be.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // Rêzeyek tevahî hemî naverokan vedigire
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // Çavkaniya hevpar a ku me di &self de heye di '_ ya Iter de tê domandin.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// Iterator çêdike ku di `VecDeque`-ê de dorhêla guhêrbar a diyarkirî vedihewîne.
    ///
    /// # Panics
    ///
    /// Panics heke xala destpêkê ji xala dawî mezintir be an xala dawiyê ji dirêjahiya vector mezintir be.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // Rêzeyek tevahî hemî naverokan vedigire
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // BELA: Ji ber ewlehiya navxweyî ya ewlehiya `IterMut` tête saz kirin
        // `ring` em diafirînin perçeyek dereferencable ya jiyanê ye '_.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Iteratorek dravî diafirîne ku di `VecDeque`-ê de dora diyarkirî ji holê radike û hêmanên jêkirî dide.
    ///
    /// Nîşe 1: Heya ku iterator heya dawiyê neyê xerckirin jî rêzika hêmanê tê rakirin.
    ///
    /// Nîşe 2: Heke nirxa `Drain` neyê avêtin, lê deynê ku digire xilas dibe (mînakî, ji ber `mem::forget`) çend hêman ji deque têne derxistin nayê diyar kirin.
    ///
    ///
    /// # Panics
    ///
    /// Panics heke xala destpêkê ji xala dawî mezintir be an xala dawiyê ji dirêjahiya vector mezintir be.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // Rêzeyek tevahî hemî naverokan paqij dike
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // Ewlekariya bîranînê
        //
        // Gava ku Drain yekem tê afirandin, deque çavkaniyê kurt dibe da ku piştrast bike ku heke hilweşînerê Drain carî neçe rê tu elementên uninitialized an bar kirî tune.
        //
        //
        // Drain dê ptr::read nirxên ku derxîne derxîne.
        // Dema ku xilas bû, dê daneyên mayî ji nû ve werin kopî kirin da ku qulikê veşêre, û nirxên head/tail dê rast werin vegerandin.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // Hêmanên deque di sê beşan de têne veqetandin:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // T= self.tail;H= self.head;t=drain_tail;h=drain_head
        //
        // Em drain_tail wekî self.head, û drain_head û self.head wekî rêzika paşîn û paşê serê li ser Drain tomar dikin.
        // Ev jî rêzika bi bandor bi vî rengî kurt dike ku ger Drain derkeve, me piştî destpêkirina drain me nirxên potansiyel bar kirî ji bîr kir.
        //
        //
        //        T th H
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" li ser nirxên piştî destpêkirina drain heya piştî ku drain temam bû û hilweşînerê Drain hate xebitandin.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // Ya girîng, em tenê ji `self` li vir referansên hevpar çêdikin û jê dixwînin.
                // Em ne ji `self` re dinivîsin û ne jî referansa guhêrbar paşve dişînin.
                // Ji ber vê yekê pêşnumaya raweya ku me li jor, ji bo `deque`, afirandî derbasdar e.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// `VecDeque` paqij dike, hemî nirxan radike.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// `true` vedigerîne heke `VecDeque` hêmanek bi nirxa dayînê re hebe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// Ger `VecDeque` vala be referansek li hêmana pêş, an `None` peyda dike.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// Ger `VecDeque` vala be referansa guhêrbar li hêmana pêş, an `None` peyda dike.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// Ger `VecDeque` vala be referansek li hêmana paşîn, an `None` peyda dike.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// Ger `VecDeque` vala be referansa guhêrbar li hêmana paşîn, an `None` peyda dike.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// Hêmana yekem ji holê radike û vedigerîne, an heke `VecDeque` vala ye `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// Hêmana paşîn ji `VecDeque` radike û vedigerîne, an heke vala ye `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// Hêmanek bi `VecDeque` ve digire.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// Hêmanek li pişta `VecDeque` ve girêdide.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: Divê em wateya `head == 0` bihesibînin
        // ew `self` berdewam e?
        self.tail <= self.head
    }

    /// Di `VecDeque`-ê de hêmanekê radike û vedigerîne, li şûna wê hêmana yekem vedigire.
    ///
    ///
    /// Ev rêzkirinê nahêle, lê *O* ye (1).
    ///
    /// Ger `index` derveyî sînor be, `None` vedigerîne.
    ///
    /// Hêmana li nîşana 0 pêşiya rêzê ye.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// Di `VecDeque`-ê de hêmanekê radike û vedigerîne, li şûna wê hêmana paşîn vedigire.
    ///
    ///
    /// Ev rêzkirinê nahêle, lê *O* ye (1).
    ///
    /// Ger `index` derveyî sînor be, `None` vedigerîne.
    ///
    /// Hêmana li nîşana 0 pêşiya rêzê ye.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// Hêmanek li ser `index` dixe nav `VecDeque`, hemî hêmanên bi nîşanên `index` mezintir an wekhev ber bi paş ve vediguhêze.
    ///
    ///
    /// Hêmana li nîşana 0 pêşiya rêzê ye.
    ///
    /// # Panics
    ///
    /// Panics heke `index` ji dirêjahiya `VecDeque` mezintir be
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // Di nav tampona rîngê de hêjmara herî hindik tevger bikin û tişta dayîn têxin hundurê xwe
        //
        // Herî zêde len/2, dê 1 hêman werin veguheztin. O(min(n, n-i))
        //
        // Sê bûyerên sereke hene:
        //  Hêmanên lihevhatî ne
        //      - rewşa taybetî dema ku dûv e 0 Hêman neçar in û zeliqok di beşa dûvikê de Hêman qut in û qulpilok di beşa serî de ye
        //
        //
        // Ji bo her yekê du heb rewş hene:
        //  Insert nêzîkê dûvikê ye Insert nêzê serê ye
        //
        // Key: H, self.head
        //      T, self.tail o, Hêmana derbasdar I, Hêmana têketinê A, Hêmana ku divê piştî xala danînê M be, Nîşan dide ku hêman bar kir
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [A oooooo.......
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // berdewam, nêzê dûvikê têxin:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           TH
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // lihevhatî, nêzîkê dûvikê û dûvikê 0 ye:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       MM

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // Jixwe dûvikê bar kir, ji ber vê yekê em tenê hêmanên `index - 1` kopî dikin.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // berdewam, nêzê serê xwe têxin:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o I A o o . . . . .]
                    //                       MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // bêserûber, nêzîkê dûvikê, beşa dûvikê têxin:
                    //
                    //                   HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // bêserûber, nêzê serî, beşa dûvikê têxin:
                    //
                    //           HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       AWMMM

                    // hêmanên kopî bikin heya serê nû
                    self.copy(1, 0, self.head);

                    // hêmana paşîn li binê tamponê li cîhê vala kopî bike
                    self.copy(0, self.cap() - 1, 1);

                    // hêmanên ji idx ber bi pêş ve diçin ne tê de ^ hêman
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // discontiguous, insert nêzîkê dûvikê, beşa serî ye, û di tampona navxweyî de li sifirê sifir e:
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               MMM

                    // hêmanên kopî bikin heya dûvikê nû
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // hêmana paşîn li binê tamponê li cîhê vala kopî bike
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // bêserûber, nêzê dûvikê, beşa serî têxin:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       AWMMMM

                    // hêmanên kopî bikin heya dûvikê nû
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // hêmana paşîn li binê tamponê li cîhê vala kopî bike
                    self.copy(self.cap() - 1, 0, 1);

                    // hêmanan ji idx-1 bar bikin da ku bi pêş ve herin û ne jî ^ element
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // bêserûber, nêzê serî, beşa serî têxin:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // dûv dibe ku hatibe guhertin ji ber vê yekê em hewce dikin ku ji nû ve hesab bikin
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// Hêmana li `index` ji `VecDeque` radike û vedigerîne.
    /// Kîjan dawiya ku nêzîkê xala rakirinê be dê were veguheztin da ku cîh bigire, û hemî hêmanên bandorbûyî dê werin veguheztin mewziyên nû.
    ///
    /// Ger `index` derveyî sînor be, `None` vedigerîne.
    ///
    /// Hêmana li nîşana 0 pêşiya rêzê ye.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // Sê bûyerên sereke hene:
        //  Hêmanên lihevhatî ne Hêmanên bêserûber in û rakirin di beşa dûvikê de ye Hêmanên bêserûber in û rakirin di beşa serî de ye
        //
        //      - rewşa taybetî dema ku hêman bi teknîkî li pey hev in, lê self.head =0
        //
        // Ji bo her yekê du heb rewş hene:
        //  Insert nêzîkê dûvikê ye Insert nêzê serê ye
        //
        // Key: H, self.head
        //      T, self.tail o, hêmana derbasdar x, Hêmana ji bo rakirinê R nîşankirin, Hêmana ku tê rakirin nîşan dide, M, Hêmana nîşanê bar kir
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // li hevûdu, nêzîkê dûvikê bikişînin:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               TH
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // li hevûdu, nêzê serê xwe hilînin:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // bêserûber, nêzîkê dûvikê, beşa dûvikê jê bikin:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // bêserûber, nêzê serî, beşa serî rakin:
                    //
                    //               RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // bêserûber, nêzê serî, beşa dûvikê jê bikin:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       AWMMM
                    //
                    // an nîv-disotîne, li tenişta serî, beşa dûvikê rakin:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         TH
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // di beşa dûvikê de hêmanan bikişînin
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // Astengiya binavbûnê dike.
                    if self.head != 0 {
                        // hêmana yekem kopî cîhê vala bike
                        self.copy(self.cap() - 1, 0, 1);

                        // hêmanên di beşa serî de paşve bikişînin
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // bêserûber, nêzîkê dûvikê, beşa serî derxînin:
                    //
                    //           RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       AWMMM

                    // hêmanên heya idx bikişînin
                    self.copy(1, 0, idx);

                    // hêmana paşîn li cîhê vala kopî bikin
                    self.copy(0, self.cap() - 1, 1);

                    // êlêmêntên ji dûvikê ber bi pêş ve pêşve bibin, ji ya paşîn dûr bixin
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// Li nîşana dayîn `VecDeque` dabeş dike du.
    ///
    /// `VecDeque`-a ku nû hatî veqetandin vedigerîne.
    /// `self` hêmanên `[0, at)` vedigire, û `VecDeque` vedigere hêmanên `[at, len)` vedigire.
    ///
    /// Têbînî ku kapasîteya `self` nayê guhertin.
    ///
    /// Hêmana li nîşana 0 pêşiya rêzê ye.
    ///
    /// # Panics
    ///
    /// Panics heke `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` di nîvê yekem de radiweste.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // tenê hemî nîvê duyemîn bigirin.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` di nîvê duyemîn de radiweste, pêdivî ye ku hêmanên ku me di nîvê yekem de paşve kişandiye faktor bikin.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // Paqijkirina ku dawiya tamponan lê ne
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// Hemî hêmanên `other` dixe nav `self`, `other` vala dihêle.
    ///
    /// # Panics
    ///
    /// Panics heke di xwe de jimara nû ya hêmanan `usize` zêde bike.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // impl naîf
        self.extend(other.drain(..));
    }

    /// Tenê hêmanên ku ji hêla pêşbend ve hatine diyar kirin vedihewîne.
    ///
    /// Bi gotinên din, hemî hêmanên `e` derxistin ku `f(&e)` derewîn vegerîne.
    /// Ev rêbaza hanê di cîh de kar dike, her yek di rêza yekem de carekê diçe serdana her hêmanê, û rêza hêmanên ragirtî diparêze.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// Rêziknameya rastîn dikare ji bo şopandina rewşa derveyî, mîna indexek bikêr be.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // Ev dikare panic an betal bike
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // Mezinahiya tamponê duqat bikin.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// `VecDeque` di cîh de diguherîne da ku `len()` bi `new_len` re yeksan e, yan bi rakirina hêmanên zêdeyî ji paş ve an jî bi pêvekirina hêmanên ku bi banga `generator` li paş ve têne çêkirin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// Depoya navxweyî ya vê deqeyê ji nû ve saz dike ji ber vê yekê ew perçek lihevhatî ye, ku paşê tê vegerandin.
    ///
    /// Ev rêbaz rêza hêmanên têxe nayê veqetandin û naguheze.Çawa ku ew perçeyek guhêrbar vedigerîne, ev dikare ji bo dabeşkirina deque were bikar anîn.
    ///
    /// Gava ku barkirina navxweyî li pey hev be, dê rêbazên [`as_slices`] û [`as_mut_slices`] tevahiya naverokên `VecDeque` di yek perçeyek de vegerînin.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// Sortkirina naveroka deque.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // deque dabeş dike
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // wê bi rêzê berevajî rêz dike
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// Ketina gihîştina neguhêzbar a pargîdaniya domdar.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // em naha dikarin piştrast bin ku `slice` hemî hêmanên deque vedihewîne, di heman demê de ji `buf` re jî guhêrbar tune.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // valahiya vala ya bes heye ku dûv bi yek gozê kopî bike, ev tê vê wateyê ku em pêşî serî paşve bizivirînin, û dûv re dûvikê li cîhê rast kopî bikin.
            //
            //
            // ji: DEFGH .... ABC
            // to: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: Em naha nahesibînin .... ABCDEFGH
            // bênavber be ji ber ku `head` dê di vê rewşê de `0` be.
            // Her çend dibe ku em dixwazin vê yekê biguherînin jî ew ne girîng e lewra ku çend cîh hêvî dikin ku `is_contiguous` bêje ku em tenê dikarin `buf[tail..head]` bikar bînin.
            //
            //

            // valahiya vala ya bes heye ku serî di yek goşeyê de kopî bike, ev tê vê wateyê ku em pêşî dûvikê ber bi pêş ve veguherînin, û dûv re serê xwe li rewşa rast kopî bikin.
            //
            //
            // ji: FGH .... ABCDE
            // ku: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // belaş ji serî û dûvikê piçûktir e, ev tê vê wateyê ku divê em hêdî hêdî dûv û serî "swap" bikin.
            //
            //
            // ji: EFGHI ... ABCD an HIJK.ABCDEFG
            // ji: ABCDEFGHI ... an ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // Pirsgirêka gelemperî bi vî rengî xuya dike GHIJKLM ... ABCDEF, berî her swapê ABCDEFM ... GHIJKL, piştî 1 derbasbûna swapê ABCDEFGHIJM ... KL, biguhezîne heya ku edge ya çep bigihe depoya temp
                //                  - wê hingê algorîtmayê bi pargîdaniyek nû ya (smaller) ji nû ve bidin destpêkirin Carinan dema ku edge ya rastê di dawiya tamponê de be, depoya tempê digihîje, ev tê vê wateyê ku me bi swapên kêm rêza rast xist!
                //
                // E.g
                // EF..ABCD ABCDEF .., piştî çar tenê swap me xelas kir
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// Rêzeya `mid`-ya du-bidawîbûyî cîhên çepê vedigire.
    ///
    /// Equivalently,
    /// - Tişta `mid` vediguherîne pozîsyona yekem.
    /// - Tiştên yekem ên `mid` pops dike û wan ber bi dawiyê ve dikişîne.
    /// - Cihên `len() - mid` li rastê dizivire.
    ///
    /// # Panics
    ///
    /// Ger `mid` ji `len()` mezintir e.
    /// Têbînî ku `mid == len()` _not_ panic dike û zivirînek no-op ye.
    ///
    /// # Complexity
    ///
    /// Wextê `*O*(min(mid, len() - mid))` digire û cîhek zêde nagire.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// Rêzeya `k`-ya du-bidawîbûyî li cîhên rastê vedigire.
    ///
    /// Equivalently,
    /// - Tişta yekem vediguherîne pozîsyona `k`.
    /// - Tiştên `k`-yên paşîn dişopîne û wan ber bi pêş ve dikişîne.
    /// - `len() - k` deverên çepê vedigire.
    ///
    /// # Panics
    ///
    /// Ger `k` ji `len()` mezintir e.
    /// Têbînî ku `k == len()` _not_ panic dike û zivirînek no-op ye.
    ///
    /// # Complexity
    ///
    /// Wextê `*O*(min(k, len() - k))` digire û cîhek zêde nagire.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // EWLEH: : du rêbazên jêrîn hewce dike ku hejmar zivirî
    // ji nîvê dirêjahiya deque kêmtir be.
    //
    // `wrap_copy` hewce dike ku `min(x, cap() - x) + copy_len <= cap()`, lê ji `min` çu carî ji nîvê kapasîteyê zêdetir nîne, bêyî x, ji ber vê yekê ew deng e ku meriv li vir bang bike ji ber ku em bi tiştek ji nîvê dirêjahiyê kêmtir bang dikin, ku ew qet ji nîvê kapasîteyê nine.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// Binary li vê `VecDeque` rêzkirî ji bo hêmanek diyar digere.
    ///
    /// Heke nirx were dîtin wê hingê [`Result::Ok`] vedigere, tê de indexa hêmana lihevhatî heye.
    /// Ger pir maç hebin, wê hingê yek ji maçan dikare were vegerandin.
    /// Ger hêjayî neyê dîtin wê hingê [`Result::Err`] tê vegerandin, tê de index ku tê de hêmanek lihevhatî tê de tê de cih digire dema ku rêza rêzkirî diparêze.
    ///
    ///
    /// # Examples
    ///
    /// Li rêzeyek ji çar hêmanan digere.
    /// Ya yekem, bi helwestek taybetî ya diyarkirî tê dîtin;duyemîn û sêyemîn nayên dîtin;ya çaremîn dikare li `[1, 4]` bi her helwestê re têkeve.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// Heke hûn dixwazin hêmanek têxin nav `VecDeque` dabeşkirî, dema ku rêza dabeşkirinê bidomînin:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// Binary li vê `VecDeque` rêzkirî bi fonksiyonek berawirdî digere.
    ///
    /// Pêdivî ye ku fonksiyona berawirdkirinê fermanek li gorî rêza rêza ya `VecDeque` ya bingehîn bicîh bîne, kodek rêzê vegerîne ku nîşan dide ka argumana wê `Less`, `Equal` an `Greater` ji hedefa tê xwestin e.
    ///
    ///
    /// Heke nirx were dîtin wê hingê [`Result::Ok`] vedigere, tê de indexa hêmana lihevhatî heye.Ger pir maç hebin, wê hingê yek ji maçan dikare were vegerandin.
    /// Ger hêjayî neyê dîtin wê hingê [`Result::Err`] tê vegerandin, tê de index ku tê de hêmanek lihevhatî tê de tê de cih digire dema ku rêza rêzkirî diparêze.
    ///
    /// # Examples
    ///
    /// Li rêzeyek ji çar hêmanan digere.Ya yekem, bi helwestek taybetî ya diyarkirî tê dîtin;duyemîn û sêyemîn nayên dîtin;ya çaremîn dikare li `[1, 4]` bi her helwestê re têkeve hev.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// Binary li vê `VecDeque` rêzkirî bi fonksiyonek derxistina key digerin.
    ///
    /// Bawer dike ku `VecDeque` ji hêla mifteyê ve tête dabeş kirin, ji bo nimûne bi [`make_contiguous().sort_by_key()`](#method.make_contiguous) re fonksiyona derxistina mifteyê heman bikar tîne.
    ///
    ///
    /// Heke nirx were dîtin wê hingê [`Result::Ok`] vedigere, tê de indexa hêmana lihevhatî heye.
    /// Ger pir maç hebin, wê hingê yek ji maçan dikare were vegerandin.
    /// Ger hêjayî neyê dîtin wê hingê [`Result::Err`] tê vegerandin, tê de index ku tê de hêmanek lihevhatî tê de tê de cih digire dema ku rêza rêzkirî diparêze.
    ///
    /// # Examples
    ///
    /// Di rêzeyek çar hêmanan de li perçeyek cotan ku li gorî hêmanên wan ên duyemîn hatine rêzkirin digerin.
    /// Ya yekem, bi helwestek taybetî ya diyarkirî tê dîtin;duyemîn û sêyemîn nayên dîtin;ya çaremîn dikare li `[1, 4]` bi her helwestê re têkeve.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// `VecDeque` di cîh de diguhezîne da ku `len()` bi new_len re wekhev be, yan bi rakirina hêmanên zêdeyî ji piştê ve an jî bi pêvekirina klonên `value` li paş.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// Indeksa di tampona bingehîn de vedigerîne ji bo danasîna hêmana hêmana mantiqî.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // mezinahî her dem hêza 2-ê ye
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// Hejmara hêmanên ku di tamponê de têne xwendin hiştin hesab bikin
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // mezinahî her dem hêza 2-ê ye
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // Her dem di sê beşan de dabeş dibe, mînakî: xwe: [a b c|d e f] din: [0 1 2 3|4 5] pêş=3, navîn=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // Ne mimkûn e ku meriv li ser pelikên ku bi rêbaza as_slices hatine vegerandin Hash::hash_slice bikar bîne ji ber ku dirêjahiya wan dikare di deqên bi heman rengî de biguhere.
        //
        //
        // Hasher tenê ji bo heman koma bangên ku bi metodên xwe re dike yeksaniyê garantî dike.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// `VecDeque`-ê dixe nav veberhênerê pêş-bi-paş de ku ji hêla hêja ve hêmanan dide.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // Divê ev fonksiyon wekheviya manewî ya:
        //
        //      ji bo tiştê li iter.into_iter() {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// [`Vec<T>`] veguherînin [`VecDeque<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Ev ji nû ve dabeşkirina cîhê ku dibe gengaz e, lê şert û mercên ji bo wê hişk in, û dikarin bêne guhertin, û ji ber vê yekê nabe ku pê bawer be heya ku `Vec<T>` ji `From<VecDeque<T>>` nehatibe û ji nû ve neyê veqetandin.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // Ji bo ZST-ê dabeşkirinek rastîn tune ku li ser kapasîteyê bi fikar bin, lê `VecDeque` nikare bi qasî `Vec` dirêjahî birêve bibe.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // Ger kapasîte ne hêza du, pir piçûk e an jî bi kêmanî yek cîhek belaş tune divê em ji nû ve mezin bikin.
            // Em vê yekê dikin dema ku ew hîn jî di `Vec` de ye lewma dê hêman li panic bikevin.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// [`VecDeque<T>`] veguherînin [`Vec<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Vê carî hewce nake ku ji nû ve were veqetandin, lê hewce dike ku *O*(*n*) tevgera daneyê bike heke tampona dorpêçê di destpêka dabeşkirinê de nebe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // Ev yek *O*(1) ye.
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // Vê yekê ji nû ve verastkirina daneyê hewce dike.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}