use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Hemî cot-key key-nirxê ji yekbûna du dubareyên hilkişî ve girêdide, di rê de guhêrbarek `length` zêde dike.Ya paşîn dema ku karmendek dilopek panîk dibe ji gazî hêsantir dike ku xwe ji lehiyê dûr bixe.
    ///
    /// Heke her du tekrar heman mifteyê hilberînin, vê rêbazê cotê ji îteratora çepê davêje û cotê ji tewra rastê pêve dike.
    ///
    /// Heke hûn dixwazin darek di rêzikek hişk a hilkişînê de biqede, mîna ji bo `BTreeMap`, divê her du veberhêner keys bi rêkûpêk bi jor hilkişînin, her yek ji hemî kilîtên darê mezintir, di nav de her tûşên ku berê li darê ne jî bikevin.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Em amade dikin ku di dema xêzikî de `left` û `right` di nav rêzek rêzkirî de bikin yek.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Di vê navberê de, em ji rêzê rêzkirî di dema xêzik de darek çêdikin.
        self.bulk_push(iter, length)
    }

    /// Hemî cot-key-nirxê davêje dawiya darê, di rê de guhêrbarek `length` zêde dike.
    /// Ya paşîn dema bangker bang dike hêsan dike ku dema îteator panîkê bike ji lehiyê dûr bikeve.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Bi hemî cot-key-nirxê vedigerin, wan di asta rast de dixin nav girêkan.
        for (key, value) in iter {
            // Biceribînin ku cot-nirxa kilît bixin nav girêka pelê ya heyî.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Cih nemaye, herin jor û li wir bipelixin.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Nodeyek bi cîh mayî dît, li vir bişkînin.
                                open_node = parent;
                                break;
                            } else {
                                // Dîsa biçin jor.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Em li jor in, girêkek root a nû diafirînin û li wir dixin.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Push-key key-value and subtree new right push.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Dîsa daketin pelê herî rast-rast.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Her dubarebûnê zêde bikin, da ku piştrast bibin ku nexşe hêmanên pêvekirî davêje jî heke panzera iterator pêşve here.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Iterator ji bo yekkirina du rêzikên rêzkirî di yekê de
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Heke du keys wekhev bin, cot-key-nirxê ji çavkaniya rast vedigerîne.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}