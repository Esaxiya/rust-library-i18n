use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Bi rengek demkî hevkêşeyek din, ya neguhêrbar a heman rêzê derdixe.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Kevokên pelên diyar ên ku di darekê de qadek diyarkirî sînordar dike dibîne.
    /// An cotek destanên cûda vedigerîne heman darê an jî cotek vebijarkên vala.
    ///
    /// # Safety
    ///
    /// Heya ku `BorrowType` `Immut` ne be, destikên dubare bikar neynin ku du carî biçin heman KV-yê.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Hevwate `(root1.first_leaf_edge(), root2.last_leaf_edge())` lê jêhatîtir e.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Cotek keviyên pelên ku di darekê de qadek taybetî diyar dike dibîne.
    ///
    /// Encam bi tenê watedar e ku dar bi mifteyê hatî rêz kirin, mîna dara di `BTreeMap` de ye.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // EWLEH: : celebê deynê me neguhêrbar e.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Cotek keviyên pelên ku darekê tevahî sînor dike dibîne.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Çavkaniyek bêhempa dabeş dike nav cotek keviyên pelên ku sînorek diyarkirî sînordar dike.
    /// Encam çavkaniyên ne-yekta yên ku mutasyona (some) dihêlin, ku divê bi baldarî werin bikar anîn in.
    ///
    /// Encam bi tenê watedar e ku dar bi mifteyê hatî rêz kirin, mîna dara di `BTreeMap` de ye.
    ///
    ///
    /// # Safety
    /// Destên duplicate bikar neynin ku du carî biçin heman KV-yê.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Çavkaniyek bêhempa dabeş dike nav cotek keviyên pelên ku tixûbê darê tixûbdar dike.
    /// Encam çavkaniyên ne-yekta ne ku mutasyonê dihêlin (tenê ji nirxan re), ji ber vê yekê divê bi baldarî werin bikar anîn.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Em li vir root NodeRef dubare dikin-em ê çu carî neçin heman KV du carî, û carî bi referansên nirxê yên li hev nayên.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Çavkaniyek bêhempa dabeş dike nav cotek keviyên pelên ku tixûbê darê tixûbdar dike.
    /// Encam referansên ne-yekta ne ku destûrê dide mutasyonek bi girseyî wêranker, ji ber vê yekê divê bi baldarî herî zêde werin bikar anîn.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Em li vir root NodeRef dubare dikin-em ê carî bi rengek ku referansên ji kokê hatine girtin li hevûdu bigire, xwe negihînin wê.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Desteyek pelê edge tê dayîn, [`Result::Ok`] bi desteyek vedigere KV ya cîran a li milê rastê, ku ew di heman girêka pelê de ye an jî di girêkek bav û kalan de ye.
    ///
    /// Heke pel edge di darê de ya herî paşîn e, bi girêka rehê [`Result::Err`] vedigerîne.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Desteyek pelê edge tê dayîn, [`Result::Ok`] bi destan vedigere KV ya cîran a li milê çepê, ku ew di heman girêka pelê de ye an jî di girêkek bav û kalan de ye.
    ///
    /// Heke pel edge di darê de yekem e, [`Result::Err`] bi girêka root vedigerîne.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Jê re destek edge ya navxweyî, [`Result::Ok`] bi desteyek vedigerîne KV-ya cîran a li milê rastê, ya ku ew di heman girêka navxweyî de ye an jî di girêkek bav û kalan de ye.
    ///
    /// Heke edge ya navxweyî ya darê yeka paşîn be, [`Result::Err`] bi girêka root vedigerîne.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Pelê edge li nav darek mirî tê da, pelê din ê edge li milê rastê vedigerîne, û cot-key-nirx di navberê de, ku yan di heman girêka pelê de ye, di girêkek bav û kalan de ye, an tune ye.
    ///
    ///
    /// Ev rêbaz her node(s)-a ku digihîje dawiya wê jî deallocate dike.
    /// Ev tê wê wateyê ku heke êdî cot-nirxa key tune, dê tevahiya mayîna darê were veqetandin û tiştek nemaye ku vegere.
    ///
    /// # Safety
    /// Pêdivî ye ku edge hatî dayîn berê ji hêla hevpîşeyê `deallocating_next_back` ve nehatibe vegerandin.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Pelê edge li nav darek mirî tê da, pelê din ê edge li milê çepê vedigerîne, û cot-key-nirx di navberê de, ku yan di heman girêka pelê de ye, di girêkek bav û kalan de ye, an tune ye.
    ///
    ///
    /// Ev rêbaz her node(s)-a ku digihîje dawiya wê jî deallocate dike.
    /// Ev tê wê wateyê ku heke êdî cot-nirxa key tune, dê tevahiya mayîna darê were veqetandin û tiştek nemaye ku vegere.
    ///
    /// # Safety
    /// Pêdivî ye ku edge hatî dayîn berê ji hêla hevpîşeyê `deallocating_next` ve nehatibe vegerandin.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Ji pelê heya kokê komek girêkan vedihewîne.
    /// Piştî ku `deallocating_next` û `deallocating_next_back` li her du aliyên darê neçikandî, û tenê li heman edge xistine ev riya yekane ye ku meriv bermayiya darekê veqetîne.
    /// Ji ber ku tenê dema ku hemî keys û nirx hatin vegerandin tê xwestin ku were gazîkirin, li ser tu keys û nirxan tu paqijî nayê kirin.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Pelê edge ber bi pelê din edge ve digire û navnîşanan vegerîne ser kilît û nirxê navberê.
    ///
    ///
    /// # Safety
    /// Divê di rêça çûyî de KV-ya din hebe.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Pelê edge pelê ber bi pelê edge yê berê ve digire û navnîşanan vedigire key û nirxê navberê.
    ///
    ///
    /// # Safety
    /// Divê di rêça çûyî de KV-ya din hebe.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Pelê edge ber bi pelê din edge ve digire û navnîşanan vegerîne ser kilît û nirxê navberê.
    ///
    ///
    /// # Safety
    /// Divê di rêça çûyî de KV-ya din hebe.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Li gorî pîvanan, kirina vê paşîn zûtir e, zûtir e.
        kv.into_kv_valmut()
    }

    /// Pelê edge pelê ber bi pelê berê ve digire û navnîşanan vedigire ser kilît û nirxê navberê.
    ///
    ///
    /// # Safety
    /// Divê di rêça çûyî de KV-ya din hebe.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Li gorî pîvanan, kirina vê paşîn zûtir e, zûtir e.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Pelê edge ber bi pelê din edge ve digire û mifte û nirxê di navberê de vedigerîne, her girêkek li paş xwe hiştin û dema ku edge ya têkildar di girêka dêwiyê xwe de dihêle veqetîne.
    ///
    /// # Safety
    /// - Divê di rêça çûyî de KV-ya din hebe.
    /// - Ew KV berê ji hêla hevpîşeyê `next_back_unchecked` ve li tu kopiyek destanên ku ji bo derbaskirina darê têne bikar anîn nehatibû vegerandin.
    ///
    /// Awayê tenê ewledar ku meriv bi desta nûvekirî pêşve biçe ev e ku meriv wê bide ber hev, bavêje, vê rêbazê dîsa li gorî mercên ewlehiya xwe bi nav bike, an jî li gorî mercên ewlehiya xwe bang li hevtayê `next_back_unchecked` bike.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Pelê edge ber bi pelê berê edge ve digire û mifte û nirxê navberê vedigerîne, her girêyek li paş xwe hiştin veqetîne, dema ku edge ya têkildar di girêka xwe ya dangilandî de dihêle.
    ///
    /// # Safety
    /// - Divê di rêça çûyî de KV-ya din hebe.
    /// - Ew pel edge berê ji hêla hevpîşeyê `next_unchecked` ve li ti kopiyek destanên ku ji bo derbaskirina darê têne bikar anîn nehatibû vegerandin.
    ///
    /// Awayê tenê ewledar ku meriv bi desta nûvekirî pêşve biçe ev e ku meriv wê bide ber hev, bavêje, vê rêbazê dîsa li gorî mercên ewlehiya xwe bi nav bike, an jî li gorî mercên ewlehiya xwe bang li hevtayê `next_unchecked` bike.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// edge pelê herî çepê di bin girêkekê de an di binê wê de vedigerîne, bi gotinek din, edge dema ku hûn pêşve diçin (an jî dema ku paşde diçin paşîn) hûn hewceyê yekemin.
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Pelê herî rast edge li nav an girêkekê vedigerîne, bi gotinek din, edge ku hûn hewceyê paşîn in dema ku hûn pêşve diçin (an jî yekem gava ku hûn paşde digerin).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Bi rêza tûşên hilkişînê serdana girêkên pel û KV-yên hundurîn dike, û di heman demê de bi rêza yekem a kûr ve serdana girêkên navxweyî jî dike, wate ku girêkên navxweyî li pêşiya KV-yên wan ên şexsî û girêkên wan ên zarok in.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Hejmara hêmanên darek (bin) jimartin.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Pelê edge yê herî nêzikî KV-yê ji bo navîgasyonê pêşve vedigire.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Pelê edge yê herî nêz KV-yê ji bo navîgasyon paşde vedigerîne.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}