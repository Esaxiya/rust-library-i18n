use core::intrinsics;
use core::mem;
use core::ptr;

/// Ev bi gazîkirina fonksiyona têkildar, şûna nirxê paşiya referansa yekta `v` digire.
///
///
/// Ger panic di girtina `change` de pêk were, dê tevahiya pêvajoyê betal bibe.
#[allow(dead_code)] // wekî nîgar û ji bo karanîna future biparêzin
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Ev bi gazîkirina fonksiyona peywendîdar şûna nirxa paşiya referansa yekta `v` digire, û encama ku di rê de hatî bidestxistin vedigerîne.
///
///
/// Ger panic di girtina `change` de pêk were, dê tevahiya pêvajoyê betal bibe.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}