// Ev hewldanek pêkanîna li pey îdealê ye
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Ji ber ku Rust bi rastî ne xwediyê celebên pêvekirî û vegera pirzimanî ye, em bi gelek bêewlehiyê re hevrû dibin.
//

// Armancek sereke ya vê modulê ew e ku meriv ji tevliheviyê dûr bixe bi dermankirina darê re wekî konteynirek gelemperî (ger bi rengek ecêb teşe be) û xwe ji danûstendina bi piraniya neguhêzbarên B-Darê re bihêle.
//
// Bi vî rengî, vê modulê girîng nake ka navnîş têne dabeş kirin, kîjan girêk dikarin binpê bibin, an jî tê çi wateyê underfull.Lêbelê, em xwe dispêrin çend neguhêzbar:
//
// - Divê darên depth/height yeksan hebin.Ev tê vê wateyê ku her rêyek ber bi pelê ve ji girêkek diyar ve bi tevahî dirêjahiya wê heye.
// - Nodeyek dirêjahiya `n` xwedan keys `n`, nirxên `n`, û keviyên `n + 1` hene.
//   Ev tê wê wateyê ku di nodek vala de jî herî kêm edge heye.
//   Ji bo girêkek pel, "having an edge" tenê tê vê wateyê ku em dikarin di girêkê de helwestek nas bikin, ji ber ku keviyên pelên vala ne û hewceyê nimûneya daneyê ne.
// Di girêkalek navxweyî de, edge hem pozîsyonek destnîşan dike û hem jî nîşangirek girêkek zarok vedigire.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Nûnera bingehîn a girêkên pelan û beşek nûneratiya girêkên navxweyî.
struct LeafNode<K, V> {
    /// Em dixwazin di `K` û `V` de hevkar bin.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Indeksa vê girêkê di nav rêzika `edges` ya girêka dêûbav de ye.
    /// `*node.parent.edges[node.parent_idx]` divê heman tişt wekî `node` be.
    /// Ev tenê dema ku `parent` ne-betal e tê destnîşankirin.
    parent_idx: MaybeUninit<u16>,

    /// Hejmara mifte û nirxên vê girêkê tomar dike.
    len: u16,

    /// Rêzikên daneyên rastîn ên girêk tomar dikin.
    /// Tenê yekem hêmanên `len`-ê yên her array têne destpêkirin û derbasdar in.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Di cîh de `LeafNode` nû destpêdike.
    unsafe fn init(this: *mut Self) {
        // Wekî siyasetek gelemperî, heke ew zeviyan zeviyên uninitialized bihêlin, ji ber ku divê ev li Valgrind hem hinekî zûtir be û hem jî hêsantir were şopandin.
        //
        unsafe {
            // dêûbav_idx, keys, û vals hemî MaybeUninit in
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// `LeafNode`-a qutiyek nû diafirîne.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Nûnera bingehîn a girêkên navxweyî.Wekî `LeafNode`, divê ev li paş`BoxedNode``ê bêne veşartin da ku pêşî li daketina keys û nirxên uninitialized bigire.
/// Her nîşangirek ber bi `InternalNode` ve dikare rasterast bi pointerek ve girêdayî beşa `LeafNode` ya binî ya girêkê ve were rêve kirin, da ku kod li ser girê û pelên navxweyî tevbigere bêyî ku tewra kontrol bike ka kîjan ji du nîşangir nîşan dide.
///
/// Vê taybetmendiyê bi karanîna `repr(C)` ve tête çalak kirin.
///
#[repr(C)]
// gdb_providers.py vî navî ji bo hundurîniyê bikar tîne.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Nîşaneyên ji bo zarokên vê girêkê.
    /// `len + 1` ji van destpêkirî û derbasdar têne hesibandin, ji xeynî ku nêzê dawiyê, dema ku dar bi riya deyn type `Dying` tê girtin, hin ji van nîşangiran daleqandî ne.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// `InternalNode`-a qutiyek nû diafirîne.
    ///
    /// # Safety
    /// Nawerokek girêkên navxweyî ev e ku bi kêmî ve yek edge ya destpêkî û derbasdar heye.
    /// Ev fonksiyon edge-ya weha saz nake.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Em tenê hewce ne ku daneyan bidin destpêkirin;keviyên MaybeUninit in.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Nîşanek birêvekirî, ne-null a node-yê.Ev an nîşanderê xwedan `LeafNode<K, V>` ye an jî nîşanderê xwedan `InternalNode<K, V>` ye.
///
/// Lêbelê, `BoxedNode` agahdarî tune ku kîjan du celeb girêdan bi rastî tê de heye, û, qismî ji ber vê kêmbûna agahdariyê, ne celebek cûda ye û hilweşîner tune.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Koka root a darek xwedî.
///
/// Bala xwe bidinê ku ev hilweşîner nîne, û divê bi destan were paqij kirin.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Darek xwedîkirî ya nû, bi girêka xweya root a ku di destpêkê de vala ye vedigerîne.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` divê ne sifir be.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Bi guhêrbar girêka xwedan root hildigire.
    /// Berevajî `reborrow_mut`, ev ewle ye ji ber ku nirxa vegerê nayê bikar anîn ku root hilweşe, û nabe ku referansên din li darê hebin.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Hinekî bi mutabetî girêka xwedan root hildigire.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Bi neguhêrbar veguherîne referansek ku rêwîtiyê destûr dide û rêbazên hilweşîner û hindikek din jî pêşkêş dike.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Bi yek edge ya ku nîşangireya girêka berê dide girêkek navxweyî ya nû, wê girêka nû dike girêka bingehîn, û vedigerîne.
    /// Ev bilindahî 1 zêde dike û berevajî `pop_internal_level` ye.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, ji xeynî ku me nû ji bîr kir em naha navxwe ne:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Nokeya koka navxweyî radike, zaroka xweya yekem wekî girêka root a nû bikar tîne.
    /// Ji ber ku tenê dema ku di girêka root de tenê yek zarok hebe, tê xwestin ku bê gotin, li ser yek ji keys, nirxan û zarokên din paqijî nayê kirin.
    ///
    /// Ev bilindahî 1 kêm dike û berevajî `push_internal_level` ye.
    ///
    /// Pêdivî ye ku gihîştina taybetî ya tiştê `Root` lê ne girêka root be;
    /// ew ê destûrnameyên din an referansên li ser girêka root bêbandor neke.
    ///
    /// Panics heke asta navxweyî tune, ango ger girêka root pel be.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // EWLEH: me destnîşan kir ku em navxwe ne.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // EWLEH: me `self` bi taybetî deyn kir û celebê deynê wê jî taybetî ye.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // EWLEH: : edge ya yekem her gav destpêkirî ye.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` hergav di `K` û `V` de hevkar e, her çend `BorrowType` `Mut` be jî.
// Ev ji hêla teknîkî ve çewt e, lê ji ber karanîna navxweyî ya `NodeRef` ji ber ku em bi tevahî li ser `K` û `V` gener dimînin encamek çênabe.
//
// Lêbelê, her ku celebek gelemperî `NodeRef` dorpêç dike, bicîh bikin ku ew xwediyê cûdahiyek rast e.
//
/// A referansek ji bo girêkekê.
///
/// Vê celeb hejmarek parameteran hene ku çawaniya çalakiya wê kontrol dike:
/// - `BorrowType`: Cûreyek bedbext ku celebê deyn diyar dike û jiyanek hilgirtiye.
///    - Dema ku ev `Immut<'a>` be, `NodeRef` hema hema mîna `&'a Node` tevdigere.
///    - Gava ku ev `ValMut<'a>` be, `NodeRef` bi rêzgirtina mifteyan û avahiya darê ve hema hema mîna `&'a Node` tevdigere, lê di heman demê de dihêle ku gelek referansên guhêrbar ên nirxên li darê bi hev re bijîn.
///    - Dema ku ev `Mut<'a>` be, `NodeRef` hema hema mîna `&'a mut Node` tevdigere, her çend rêbazên têxê destûrê dide ku nîşangirek guhêrbar nirxek bi hev re bijîn.
///    - Dema ku ev `Owned` be, `NodeRef` hema hema mîna `Box<Node>` tevdigere, lê hilweşîner tune ye, û divê bi destan were paqij kirin.
///    - Dema ku ev `Dying` be, `NodeRef` hîn jî hema hema mîna `Box<Node>` tevdigere, lê rêbazên wê hene ku darê bit bi bit rûxandin, û rêbazên asayî, her çend ji bo gazîkirinê wekî ewledar neyên nîşankirin, heke çewt were bang kirin dikarin UB-yê vexwînin.
///
///   Ji ber ku her `NodeRef` di nav darê de gerînek dihêle, `BorrowType` bi bandor ji bo tevahî darê, ne tenê ji girêk bixwe re derbas dibe.
/// - `K` û `V`: Ev celebên mifte û nirxên ku di girêdan de hatine hilanîn in.
/// - `Type`: Ev dikare `Leaf`, `Internal`, an `LeafOrInternal` be.
/// Gava ku ev `Leaf` be, `NodeRef` nîşangirek pelê dide, gava ku ev `Internal` ye `NodeRef` nîşangirek navxweyî ye, û dema ku ev `LeafOrInternal` be `NodeRef` dikare nîşan bide an celebek girêk.
///   `Type` dema ku li derveyî `NodeRef` tê bikar anîn navê wî `NodeType` e.
///
/// `BorrowType` û `NodeType` ji bo ku ewlehiya celebê statîk bikar bînin em kîjan rêbazan bicîh dikin sînor dikin.Di awayê ku em dikarin van sînoran bikar bînin sînorkirin hene:
/// - Ji bo her parametreyek tîp, em tenê dikarin rêgezek an generîkî an jî ji bo celebek taybetî diyar bikin.
/// Mînakî, em nikarin rêbazek mîna `into_kv` bi gelemperî ji bo hemî `BorrowType`, an carek jî ji bo her cûreyên ku jiyanek hilgirin, diyar bikin, ji ber ku em dixwazin ew vegerin referansên `&'a`.
///   Ji ber vê yekê, em wê tenê ji bo celebê herî kêm hêzdar `Immut<'a>` diyar dikin.
/// - Em nekarin zorê bidin gotin ji `Mut<'a>` heya `Immut<'a>`.
///   Ji ber vê yekê, em neçar in ku bi zelalî `reborrow` li `NodeRef` bihêztir bang bikin da ku em bigihîjin rêbazek mîna `into_kv`.
///
/// Hemî rêbazên li ser `NodeRef` ku hin celeb referansê vedigirin, an:
/// - Bi nirxê `self` bigirin, û jiyana ku ji hêla `BorrowType` ve hatî hilberandin vegerînin.
///   Carcarinan, ji bo gazîkirina rêbazek wusa, pêdivî ye ku em bangî `reborrow_mut` bikin.
/// - `self` bi referansê bigirin, û (implicitly) li şûna jiyana ku ji hêla `BorrowType` ve hatî hilgirtin, jiyana wê referansê vegerîne.
/// Bi vî rengî, venêrana deyn garantî dike ku `NodeRef` heya ku referansa vegerandî tê bikar anîn deynkirî dimîne.
///   Rêbazên ku piştgiriyê didin insertê vê qaîdeyê vedigerînin bi vegerandina pointerek rawe, ango referansek bêyî temen.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Hejmara astên ku girêk û asta pelên ji hevûdu veqetandî ne, domdarek girêk e ku bi tevahî ji hêla `Type` ve nayê vegotin, û ku girêk bixwe nahêle.
    /// Em tenê hewce ne ku bilindahiya girêka root hilînin, û her bilindahiya girêka din jî jê bistînin.
    /// Ger `Type` `Leaf` be divê sifir be û heke `Type` `Internal` e bila ne sifir be.
    ///
    ///
    height: usize,
    /// Nîşankarê bergê an girêka navxweyî ye.
    /// Danasîna `InternalNode` piştrast dike ku nîşander bi her awayî derbasdar e.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Referensa girêkekê ku wekî `NodeRef::parent` hatî pakij kirin vekin.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Daneyên girêkek navxweyî radixe pêş çavan.
    ///
    /// Ptr-ya xav vedigerîne da ku referansên din ên li ser vê nodê bêbandor neke.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // EWLEH: : tîpa girêka statîk `Internal` e.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Destûra taybetî ya daneyên girêkek navxweyî ya Borrows.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Dirêjahiya girêkê dibîne.Ev hejmara keys an nirxan e.
    /// Hejmara keviran `len() + 1` e.
    /// Zanibe ku, her çend ewledar be jî, gazîkirina vê fonksiyonê dikare bibe sedema bandora betalkirina referansên guhêrbar ên ku koda ewledar çêkiriye.
    ///
    pub fn len(&self) -> usize {
        // Ya girîng, em li vir tenê digihin qada `len`.
        // Ger BorrowType marker::ValMut be, dibe ku li ser nirxên ku divê em wan neheq nekin, referansên guhêrbar ên berbiçav hebin.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Hejmara astên ku girêk û pel ji hevûdu vedigerin vedigerîne.
    /// Bilindbûna sifir tê vê wateyê ku girêk pel bixwe ye.
    /// Heke hûn daran bi reh li jor nîgar bikin, hejmar dibêje li kîjan bilindahiyê girê xuya dibe.
    /// Heke hûn daran bi pelên li jor wêne bikin, hejmar dibêje çiqas dar li jorê girêk dirêj dibe.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Bi rengek demkî referansek din, neguhêrbar a li ser heman girêkê derdixe.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Beşa pelê her pelê an girêkek navxweyî radixe ber çavan.
    ///
    /// Ptr-ya xav vedigerîne da ku referansên din ên li ser vê nodê bêbandor neke.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Node divê bi kêmî ve ji bo beşa LeafNode derbasdar be.
        // Ev di celebê NodeRef de ne referansek e ji ber ku em nizanin gerek ew yekta be an parvekirî be.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Dê û bavê girêka heyî dibîne.
    /// `Ok(handle)` vedigerîne heke girêka heyî bi rastî xwedan dêûbavek be, ku `handle` edge ya dêûbav nîşan dike ku nîşangirê heyî nîşan dike.
    ///
    /// Ger dêûbavek nodê tune, vedigere `Err(self)`, `NodeRef` ya orjînal dide paş.
    ///
    /// Navê rêbazê ferz dike ku hûn darên ku girêka root li jor in wêneyî bikin.
    ///
    /// `edge.descend().ascend().unwrap()` û `node.ascend().unwrap().descend()` divê herdu jî, li ser serfiraziyê, tiştek nekin.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Em hewce ne ku nîşangirên xav ji bo girêkan bikar bînin ji ber ku, heke BorrowType marker::ValMut be, dibe ku li ser nirxan referansên guhêrbar ên berbiçav hebin ku divê em wan nederbasdar bikin.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Zanibe ku divê `self` bêpaqij be.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Zanibe ku divê `self` bêpaqij be.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Parçeyek pelê her pelê an girêkek navxweyî di darek neguhêrbar de radixe ber çavan.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // EWLEH: : di vê dara ku wekî `Immut` hatî deyn kirin de çu referansên guhêrbar tune.
        unsafe { &*ptr }
    }

    /// Dîmenekê dixe nav kilîtên ku di girêkê de hatine hilanîn.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Mîna `ascend`, referansek digihîje girêka dêûbav, lê di heman demê de di pêvajoyê de girêka heyî jî dealok dike.
    /// Ev ne ewle ye ji ber ku girêka heyî tevî ku hate veqetandin dê hîn jî peyda bibe.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Bê ewlehî ji berhevkar re agahdariya statîk radigihîne ku ev girêk `Leaf` ye.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Bê ewlehî ji berhevkar re agahdariya statîk radigihîne ku ev girêk `Internal` ye.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Bi rengek demkî referansa din a mutable ji heman girêkê re digire.Hişyar bimînin, ji ber ku ev rêbaz pir xeternak e, du carî lewra dibe ku tavilê xeternak xuya neke.
    ///
    /// Ji ber ku nîşangirên guhêrbar dikarin li her deverê dora darê bigerin, nîşana vegeriyayî dikare bi hêsanî were bikar anîn da ku nîşanderê xwerû di bin qaîdeyên deynê stacked dangling, out of the areas, or invalid.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) lê zêde bike ku parametreyek celebek din li `NodeRef` zêde bike ku karanîna rêbazên navîgasyonê li ser nîşanên reborrowed sînordar dike, pêşî li vê bêewlehiyê digire.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Gihîştina taybetî ya beşa pelê ya her pelê an girêkek navxweyî.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // EWLEHIYA: gihîştina me ya taybetî bi tevahî girêkê heye.
        unsafe { &mut *ptr }
    }

    /// Gihîştina taybetî ya beşa pelê ya her pelê an girêkek navxweyî pêşkêş dike.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // EWLEHIYA: gihîştina me ya taybetî bi tevahî girêkê heye.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Têketina taybetî ya hêmanek ji devera hilanînê ya sereke digire.
    ///
    /// # Safety
    /// `index` di tixûbên 0..QAPACITY de ye
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // EWLEH: Y::bangker dê nikaribe li ser xwe rêbazên din jî bang bike
        // heya ku referansa perçeya kilît hilweşe, ji ber ku ji bo jiyana deyn em gihîştina bêhempa hene.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Têketina taybetî ya hêmanek an perçeyek ji qadê depokirina nirxa girêkê boro dike.
    ///
    /// # Safety
    /// `index` di tixûbên 0..QAPACITY de ye
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // EWLEH: Y::bangker dê nikaribe li ser xwe rêbazên din jî bang bike
        // heya ku referansa perçeya nirxê were avêtin, ji ber ku ji bo jiyana deyn em gihîştina bêhempa hene.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Ji bo naverokên edge gihîna taybetî ya hêmanek an perçeyek qada hilanînê ya girêkê.
    ///
    /// # Safety
    /// `index` di tixûbên 0..KAPATITYT + + 1 de ye
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // EWLEH: Y::bangker dê nikaribe li ser xwe rêbazên din jî bang bike
        // heya ku referansa perçeya edge neyê avêtin, ji ber ku ji bo jiyana deyn em gihîştina bêhempa hene.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Node ji `idx` hêmanên destpêkirî pirtir e.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Em tenê referansa yek hêmana ku me pê eleqedar dike diafirînin, da ku bi referansên berbiçav ên hêmanên din re, bi taybetî, yên ku di vegotinên berê de vegeriyane bangdêr, aliasing nekin.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Divê em ji ber z0Rust0Z pirsgirêka #74679 zorê bidin nîşangirên array yên bêserûber.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Têketina taybetî ya dirêjiya girêkê Borrows.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Zencîreya girêkê bi dê û bavê xwe edge re saz dike, bêyî ku referansên din ên li girêkê bêbandor bike.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Zencîreya root a bi bavê xwe edge re paqij dike.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Li dawiya girêkê cotek-key-nirx zêde dike.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Her tiştê ku ji hêla `range` ve hatî vegerandin ji bo girêkê nîşanek edge-ya derbasdar e.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Pêvek-key-nirxek, û edge zêde dike ku biçe rastê wê cotê, heya dawiya girêkê.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Kontrol dike gelo girêk girêkek `Internal` e an girêk `Leaf` ye.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Di nav girêkekê de referansek li cotek-nirxa kilît an edge ya taybetî.
/// Pêdivî ye ku pîvana `Node` `NodeRef` be, lê `Type` dikare `KV` be (nîşana desteyek li ser cotek-key-nirx) an `Edge` (nîşana desteyek li ser edge).
///
/// Zanibe ku hêj girêkên `Leaf` jî dikarin destên `Edge` hebin.
/// Li şûna ku nîşanderê nîşangirek zarok bin, vana qadên ku nîşankerên zarok dê biçin navbera cot-nirx-key nîşan dikin.
/// Mînakî, di girêkek bi dirêjahiya 2 de, dê 3 cihên edge gengaz hebin, yek li çepê girêkê, yek di navbera her du cotan de, û yek jî li rastê girêk.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Em ne hewceyê giştpirsiya tevahî ya `#[derive(Clone)]` in, ji ber ku tenê dema ku `Node` dê `Klone` bikêr be gava ku ew referansek neguhêrbar be û ji ber vê yekê jî `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Nîveya ku edge an cot-nirxa kilîtê ya ku ev destik nîşan dike vedigerîne.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Rewşa vê destanê di girêkê de vedigire.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Di `node` de ji cotek-key-nirxê re desteyek nû diafirîne.
    /// Ne ewle ye ji ber ku bangvan divê piştrast bike ku `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Dikare pêkanînek giştî ya PartialEq be, lê tenê di vê modulê de tê bikar anîn.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Bi demkî li heman cîhê desteyek din, neguhêrbar derdixe.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Em nikarin Handle::new_kv an Handle::new_edge bikar bînin ji ber ku em celebê xwe nizanin
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Bê ewlehî ji berhevkar re agahdariya statîk radigihîne ku girêka destikê `Leaf` ye.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Bi demkî li heman cîhê desteyek din, guhêrbar derdixe.
    /// Hişyar bimînin, ji ber ku ev rêbaz pir xeternak e, du carî lewra dibe ku tavilê xeternak xuya neke.
    ///
    ///
    /// Ji bo hûrguliyan, li `NodeRef::reborrow_mut` binihêrin.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Em nikarin Handle::new_kv an Handle::new_edge bikar bînin ji ber ku em celebê xwe nizanin
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Di `node` de ji edge re destûrek nû diafirîne.
    /// Ne ewle ye ji ber ku bangvan divê piştrast bike ku `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Bi navnîşek edge ve hatî dayîn ku em dixwazin têxin nav girêkek tijî kapasîte, ev index KV-ya hestiyar a xalek dabeşkirî û ku derê têxê cîbicî dike dihesibîne.
///
/// Armanca xala dabeşkirî ev e ku mifte û nirxa wê di girêkek dêûbavî de biqede;
/// keys, nirx û keviyên çepê xala dabeşbûnê dibin zarokê çep;
/// keys, nirx û deviyên li rastê xala dabeşkirî dibin zarokek rast.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Pirsgirêka Rust #74834 hewl dide ku van qaîdeyên hevdemî vebêje.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Di nav cotên key-nirxê de rast û çepê vê edge cotek-nirxa mifteyê ya nû dixe.
    /// Ev rêbaza hanê ferz dike ku di girêkê de bes cîh heye ku cotek nû lê bikeve.
    ///
    /// Nîşanera vegeriyayî nirxa têxistî nîşan dike.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Di nav cotên key-nirxê de rast û çepê vê edge cotek-nirxa mifteyê ya nû dixe.
    /// Heke cîh têrê neke ev rêbaza hanê parçe dike.
    ///
    /// Nîşanera vegeriyayî nirxa têxistî nîşan dike.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Nîqaş û nîşana dêûbavan di girêka zarokê de ya ku ev edge pê ve girêdide sererast dike.
    /// Ev kêrhatî ye dema ku rêzkirina qiraxan hate guherandin,
    fn correct_parent_link(self) {
        // Bêyî ku çavkanîyên din ên li nodê bêbandor bikin paşpirtûkê biafirînin.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Pêvek-keyek-nirxek nû û edge-ê dixe ku dê di navbera vê edge û cot-key-nirxê rastê vê edge de biçin rastê wê cotê nû.
    /// Ev rêbaza hanê ferz dike ku di girêkê de bes cîh heye ku cotek nû lê bikeve.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Pêvek-keyek-nirxek nû û edge-ê dixe ku dê di navbera vê edge û cot-key-nirxê rastê vê edge de biçin rastê wê cotê nû.
    /// Heke cîh têrê neke ev rêbaza hanê parçe dike.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Di nav cotên key-nirxê de rast û çepê vê edge cotek-nirxa mifteyê ya nû dixe.
    /// Ev cîh heke cîh bes tune, girêkê parçe dike, û hewil dide ku beşa veqetandî bi vegerînî, di nav girêka dêûbav de bavêje, heya ku root bigihîje.
    ///
    ///
    /// Ger encama vegeriyanî `Fit` be, girêka destikê wê dikare ev girêka edge an bav û kal be.
    /// Ger encama vegeriyanî `Split` be, qada `left` dê girêka root be.
    /// Nîşanera vegeriyayî nirxa têxistî nîşan dike.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Girêdana ku ji hêla vê edge ve hatî nîşankirin dibîne.
    ///
    /// Navê rêbazê ferz dike ku hûn darên ku girêka root li jor in wêneyî bikin.
    ///
    /// `edge.descend().ascend().unwrap()` û `node.ascend().unwrap().descend()` divê herdu jî, li ser serfiraziyê, tiştek nekin.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Em hewce ne ku nîşangirên xav ji bo girêkan bikar bînin ji ber ku, heke BorrowType marker::ValMut be, dibe ku li ser nirxan referansên guhêrbar ên berbiçav hebin ku divê em wan nederbasdar bikin.
        // Çu fikar tune ku xwe bigihînin qada bilindahiyê ji ber ku ew nirx tête kopî kirin.
        // Hişyar bimînin ku, gava ku nîşanderê girêk were paşguh kirin, em bi referansekê digihîjin rêzika qiraxan (Rust pirsgirêka #73987) û referansên din ên an an di hundurê rêzikê de betal dikin, divê hebe.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Em nikarin rêbazên mifte û nirxê yên cuda vebêjin, ji ber ku gazîkirina ya duyemîn referansa ku ji hêla yekem ve hatî vegerandin bêserûber e.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Mifte û nirxa ku desta KV tê de ye veguherînin.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Bi lênihêrîna daneyên pelê ve, ji bo `NodeType` taybetî, ji pêkanînên `split` re dibe alîkar.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Girêdana bingehîn dike sê beş:
    ///
    /// - Node tête kurtkirin ku tenê cotek-nirxa çepê ya vê çepê tê de heye.
    /// - Mifte û nirxa ku ji hêla vê destanê ve hatî nîşandin têne derxistin.
    /// - Hemî cot-nirxên kilît ên li rastê vê destanê têne avêtin nav girêkeke ku nû hatî veqetandin.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Pêveka key-nirxê ku ji hêla vê destanê ve hatî nîşankirin ji holê radike û wê vedigerîne, digel edge ku cot-nirxa key-ê têk çû.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Girêdana bingehîn dike sê beş:
    ///
    /// - Node tê qut kirin ku tenê qirax û cot-key-nirxa çepê ya vê desteyê tê de ye.
    /// - Mifte û nirxa ku ji hêla vê destanê ve hatî nîşandin têne derxistin.
    /// - Hemî qirax û cot-nirxê key-ê yên li rastê vê destanê têne avêtin nav girêkek nû veqetandî.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Danişînek ji bo nirxandin û pêkanîna operasyona hevsengiyê li dor cotek key-nirxa navxweyî temsîl dike.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Têkiliya hevsengiyê ku girêk wekî zarok tê de ye, hildibijêre, ji ber vê yekê di navbera KV-yê de yekser çepê an rastê di girêka bavî de.
    /// Ger dêûbav tune `Err` vedigere.
    /// Heke dêûbav vala be Panics.
    ///
    /// Aliyê çepê tercîh dike, heke girêka dayîn bi rengek kêm be, çêtir be, wate li vir tenê ev e ku ji xwişk û birayê xweyê çepê û ji xwişka wîya rastê, heke ew hebin hêmanên wê kêmtir in.
    /// Di wê rewşê de, yekbûna bi xwişk û birayê çep re zûtir e, ji ber ku em tenê hewce ne ku hêmanên N-ya girêkê bar bikin, li şûna ku wan veguherînin rastê û ji N-ê bêtir li pêş biçin.
    /// Diziya ji xwişk û birayê çepê jî bi gelemperî zûtir e, ji ber ku em tenê hewce ne ku li şûna ku bi kêmasî N ya hêmanên xwişk û bira ber bi çepê ve bibin, hêmanên N yên girêkê ber bi rastê ve veguherînin.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Vedigere ka yekbûn gengaz e, ango, gelo di girêkekê de têra xwe cîh heye ku KV-ya navendî û herdu girêkên zarok ên cîran bi hev re hebe.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Mergeyek pêk tîne û dihêle ku girtinek biryar bide ka dê çi vegerîne.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // EWLEHIY: : bilindahiya girêkên têne yekkirin yek di binê bilindahiyê de ye
                // ji girêka vê edge, bi vî rengî di ser sifirê re, ji ber vê yekê ew navxweyî ne.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Zewaca key-nirxa dêûbav û herdu girêkên zarok ên tenişt di nav girêka zarokê çepê de dike yek û girêka dêûbav a piçûkkirî vedigerîne.
    ///
    ///
    /// Heya ku em `.can_merge()` ne Panics.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Parêza dêûbav-key-nirx û her du girêkên zarok ên tenişt di nav girêka zarokê çep de dike yek û wê girêka zarok vedigerîne.
    ///
    ///
    /// Heya ku em `.can_merge()` ne Panics.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Parêza dêûbav-key-nirx û her du girêkên zarok ên cîran di nav girêka zarokê çepê de dike yek û desteka edge vedigire di wê girêka zarokê de ku zarokê şopandî edge lê xilas bû,
    ///
    ///
    /// Heya ku em `.can_merge()` ne Panics.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Ji zarokê çepê cotek key-nirxê radike û wê di embara key-nirxê dêûbav de bicîh dike, dema ku dêûbavê key-nirxa bavê kevn dixe nav zarokê rast.
    ///
    /// Li zaroka rast a ku li edge ya ku ji hêla `track_right_edge_idx` ve hatî diyarkirin ve hatî xilas kirin de desteyek vedigere edge.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Hevalek-key-nirxê ji zarokê rast radike û wî di embara key-value ya dêûbav de bicîh dike, dema ku dêûbavê key-nirxa dêûbav bavêje ser zarokê çep.
    ///
    /// Li zarokê çepê ku ji hêla `track_left_edge_idx` ve hatî diyarkirin, desteyek vedigerîne edge, ku neçû.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Ev dizî dişibihe `steal_left` lê di heman demê de gelek hêman didize.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Bawer bikin ku dibe ku em bi ewlehî diziyê bikin.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Daneyên pelê bar bikin.
            {
                // Di zarokê rast de cîhê hêmanên dizî vekin.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Hêmanên ji zarokê çep ber bi yê rast ve bikişînin.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Pêveka çep-herî dizîn bavêjin dêûbavê.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Zewaca key-nirxa dêûbav li zarokê rast bar bikin.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Ji qiraxên dizî re cîh bigirin.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Keviran didizin.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Klona hevsengî ya `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Bawer bikin ku dibe ku em bi ewlehî diziyê bikin.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Daneyên pelê bar bikin.
            {
                // Pêveka rast-herî dizîn bavêjin dêûbavê.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Pêveka key-nirxa dêûbavan li zarokê çep bar bikin.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Hêmanên ji zarokê rast ber bi yê çep ve bibin.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Valahiya ku berê hêmanên dizî bûne dagirin.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Keviran didizin.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Valahiya ku berê keviyên dizî lê bûne dagirin.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Agahdariya statîkî ya ku vê girêk girêkek `Leaf` e ji holê radike.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Agahdariya îstatîkî ya ku ev girêk girêkek `Internal` e ji holê radike.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Kontrol dike ka girêka bingehîn girêkek `Internal` ye an girêkek `Leaf` ye.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Paşgira piştî `self`-ê ji yek nodê veguherînin yeka din.`right` divê vala be.
    /// edge ya yekem a `right` nayê guhertin.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Encama danînê, dema ku girêkek hewce kir ku ji kapasîteya xwe berfireh bibe.
pub struct SplitResult<'a, K, V, NodeType> {
    // Di dara heyî de bi hêman û keviyên ku girêdayî çepê `kv` ne, girêka guherî.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Hin mifte û nirx dabeş dibin, ku li deverek din werin bicihkirin.
    pub kv: (K, V),
    // Bi hêman û qiraxên ku aîdî mafê `kv` ne, xwediyê, negirêdayî, girêk nû ye.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Ma referansên girêkên ji vî rengî deyn rê didin ku li darên din girêdan bigerin.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal ne hewce ye, ew bi karanîna encama `borrow_mut` pêk tê.
        // Bi sekinandina traversal, û tenê çêkirina referansên nû li ser kokan, em dizanin ku her referansa ji celebê `Owned` ji girêkek root re ye.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Nirxek dixe nav perçek hêmanên destpêkirî û li pey wan jî yek hêmana uninitialized.
///
/// # Safety
/// Di pirtûkê de ji hêmanên `idx` zêdetir hene.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Nirxek ji perçeyek ji hemî hêmanên destpêkirî ji holê radike û vedigerîne, û li paş xwe hêmanek uninitialized ya paşîn dihêle.
///
///
/// # Safety
/// Di pirtûkê de ji hêmanên `idx` zêdetir hene.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Hêmanan di çeperên `distance`-ê yên çepê de vediguhêzîne çepê.
///
/// # Safety
/// Qet nebe hêmanên `distance`-ê hene.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Hêmanan di çeperên `distance` yên perçeyî de vediguhêzîne rastê.
///
/// # Safety
/// Qet nebe hêmanên `distance`-ê hene.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Hemî nirxan ji perçeyek hêmanên destpêkî bar dike perçeyek hêmanên unenitialized, `src` wekî hemî uninitialized li paş xwe dihêle.
///
/// Mîna `dst.copy_from_slice(src)` dixebite lê hewce nake ku `T` `Copy` be.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;