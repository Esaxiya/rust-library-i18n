use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// Pêdivî ye ku lêgerînek lêgerîn, mîna `Bound::Included(T)`.
    Included(T),
    /// An exclusive ku lê digerin, mîna `Bound::Excluded(T)`.
    Excluded(T),
    /// Girêdayî tevlêbûnek bê şert û merc, mîna `Bound::Unbounded`.
    AllIncluded,
    /// Girêdanek taybetî ya bê şert û merc.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Di nav darek (bin) dara ku serê wê girêk e, vedigere, li mifteya dana digere.
    /// Ger yek hebe, `Found`-a bi desta KV-ya lihevhatî vedigerîne.
    /// Wekî din, `GoDown`-ê bi desta pelê edge vedigere ku kilît tê de ye.
    ///
    /// Encam bi tenê watedar e ku dar bi mifteyê hatî rêz kirin, mîna dara di `BTreeMap` de ye.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// Dakeve ser girêka herî nêz ku edge li benda jêrîn a rêzê digire ji edge li hevûdu ya jorîn cuda ye, ango girêka herî nêz ku bi kêmî ve yek keyek tê de heye.
    ///
    ///
    /// Heke were dîtin, bi wê girêkê ve `Ok` vedigere, cotek nîşanên edge di wê de veqetandina dorpêçê, û cotek pêwendîdar sînor ji bo domandina lêgerînê di girêkên zarok de, di rewşa ku girêk navxweyî be.
    ///
    /// Heke neyê dîtin, `Err` vedigere ku pel edge bi tevahî rêzê vedigere.
    ///
    /// Encam tenê ger dar bi mifteyê were rêz kirin watedar e.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Divê ji rêzkirina van guhêrbaran were dûrxistin.
        // Em texmîn dikin ku sînorên ji hêla `range` ve hatine ragihandin heman dimînin, lê pêkanînek dijber dikare di navbera bangên (#81138) de biguhere.
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// Di girêka ku sînorê jêrîn a rêzê sînor dike de edge dibîne.
    /// Di heman demê de bendera jêrîn vedigerîne ku ji bo domandina lêgerînê di girêka zarok a lihevhatî de tê bikar anîn, heke `self` girêkek navxweyî ye.
    ///
    ///
    /// Encam tenê ger dar bi mifteyê were rêz kirin watedar e.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// Clone of `find_lower_bound_edge` ji bo girêdana jorîn.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Bêyî paşde vegerîn, di girêkê de mifteyek dayî digere.
    /// Ger yek hebe, `Found`-a bi desta KV-ya lihevhatî vedigerîne.
    /// Wekî din, `GoDown`-ê bi desta edge vedigerîne ku dibe ku kilît were dîtin (heke girêk navxweyî be) an jî ku kilît dikare tê de were lêkirin.
    ///
    ///
    /// Encam bi tenê watedar e ku dar bi mifteyê hatî rêz kirin, mîna dara di `BTreeMap` de ye.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// An nîşana KV di girêka ku mifte (an hevseng) lê heye vedigerîne, an jî nîşana edge ku mifte tê de vedigerîne.
    ///
    ///
    /// Encam bi tenê watedar e ku dar bi mifteyê hatî rêz kirin, mîna dara di `BTreeMap` de ye.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// Di girêka ku sînorê jêrîn a rêzê sînor dike de indeksek edge dibîne.
    /// Di heman demê de bendera jêrîn vedigerîne ku ji bo domandina lêgerînê di girêka zarok a lihevhatî de tê bikar anîn, heke `self` girêkek navxweyî ye.
    ///
    ///
    /// Encam tenê ger dar bi mifteyê were rêz kirin watedar e.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// Clone of `find_lower_bound_index` ji bo girêdana jorîn.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}