use core::marker::PhantomData;
use core::ptr::NonNull;

/// Modelên reborrowa hin referansa bêhempa, gava ku hûn dizanin ku reborrow û hemî neviyên wê (ango, hemî nîşan û referansên jê hatine) dê di hin xalan de bêtir neyê bikar anîn, piştî ku hûn dixwazin dîsa referansa bêhempa ya eslî bikar bînin .
///
///
/// Checker deyn bi gelemperî ji bo we vê stacking deyn digire, lê hin herikên kontrolê yên ku vê stacking pêk tînin ji bo ku berhevkar li pey wan were pir tevlihev in.
/// A `DormantMutRef` dihêle hûn bi xwe deynan kontrol bikin, dema ku hê jî cewherê xwe yê stacked îfade dikin, û koda pêşnumayê ya raweyî bicîh dikin ku pêdivî ye ku bêyî tevgerek ne diyar vê yekê bike.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Deynek bêhempa bigirin, û tavilê wê paşve bikin.
    /// Ji bo berhevkar, temenê referansa nû wekî jiyana referansa orjînal e, lê hûn promise ne ku wê ji bo demek kurttir bikar bînin.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // EWLEH: em deyn li seranserê 'a bi `_marker` digirin, û em eşkere dikin
        // tenê ev referans, lewma jî bêhempa ye.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Vegere ser deynê bêhempa yê di destpêkê de hatî girtin.
    ///
    /// # Safety
    ///
    /// Pêdivî ye ku reborrow bidawî bibe, ango, referansa ku ji hêla `new` ve hatî vegerandin û hemî nîşan û referansên jê hatine girtin, divê êdî neyên bikar anîn.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // EWLEH: : mercên ewlehiya me bixwe ev referans dîsa bêhempa ye.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;