use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// trait-a pisporiyek din ji bo Vec::from_iter hewce ye ku bi destan pêşanî bide pisporiyên hevûdu ji bo hûragahiyan li [`SpecFromIter`](super::SpecFromIter) binêrin.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Dûbare dubarebûnê vekin, ji ber ku vector dê li ser vê dûbarebûnê were berfireh kirin her carê dema ku şûnda vala nebe, lê xelek di extend_desugared() de nabîne ku vector di çend dubareyên xeletiyên paşîn de tijî ye.
        //
        // Ji ber vê yekê em pêşbîniya branch çêtir dibin.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // divê ji spec_extend() re delegeyan bişîne ji ber ku extend() bixwe ji Vecsên vala re ji spec_from re şandiye
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // divê ji spec_extend() re delegeyan bişîne ji ber ku extend() bixwe ji Vecsên vala re ji spec_from re şandiye
        //
        vector.spec_extend(iterator);
        vector
    }
}