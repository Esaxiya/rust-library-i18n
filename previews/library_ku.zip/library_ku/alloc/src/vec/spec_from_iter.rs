use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Specialization trait ku ji bo Vec::from_iter tê bikar anîn
///
/// ## Grafîka şandeyê:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Dozek hevpar derbaskirina vector ye di fonksiyonekê de ku yekser ji nû ve kom dibe nav vector.
        // Ger IntoIter hîç pêş neketibe em dikarin viya kurt bikin.
        // Gava ku ew hate pêşvexistin Em dikarin bîranînê jî ji nû ve bikar bînin û danezan ber bi pêş ve bibin.
        // Lê em tenê wiya dikin gava ku Vec-ê dê kapasîteya wê ya bê-karanîn tune be ku ji afirandina bi navgîniya bicîhkirina FromIterator-ê bêtir.
        //
        // Ew tixûbdan bi zor ne hewce ye ji ber ku tevgera dabeşkirina Vec bi zanebûn tê diyar kirin.
        // Lê ew hilbijartinek kevneperest e.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // divê ji spec_extend() re delegeyan bişîne ji ber ku extend() bixwe ji Vecsên vala re ji spec_from re şandiye
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Ev `iterator.as_slice().to_vec()` bikar tîne ji ber ku spec_extend divê bêtir gav bavêje ku li ser kapasîteya dawîn + dirêjahî biaxive û bi vî rengî bêtir kar bike.
// `to_vec()` rasterast mîqdara rast veqetîne û wê tam dagire.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): bi cfg(test) rêbaza xwerû `[T]::to_vec`, ku ji bo vê pênaseya rêbazê pêdivî ye, peyda nabe.
    // Di şûna wê de fonksiyona `slice::to_vec` bikar bînin ku tenê bi cfg(test) NB heye, ji bo bêtir agahdariyê modula slice::hack li slice.rs bibînin.
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}