use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// Iterator ku girtinek bikar tîne da ku destnîşan bike gelo hêmanek divê were rakirin.
///
/// Ev strukture ji hêla [`Vec::drain_filter`] ve hatî afirandin.
/// Ji bo bêtir belgeya wê bibînin.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// Navnîşa tiştê ku dê ji hêla banga paşîn a `next` ve were kontrol kirin.
    pub(super) idx: usize,
    /// Hejmara hêmanên ku heya niha (removed) hatine derxistin.
    pub(super) del: usize,
    /// Dirêjahiya xwemalî ya `vec` berî şûştinê.
    pub(super) old_len: usize,
    /// Pêşniyara testa parzûnê.
    pub(super) pred: F,
    /// Alaya ku panic nîşan dide di pêşnumaya testa parzûnê de çêbû.
    /// Ev ji bo pêşîgirtina li ber vexwarina mayîna `DrainFilter` wekî rêşokek di pêkanîna dilopê de tê bikar anîn.
    /// Tiştên neçareserkirî dê di `vec` de paşde werin veguheztin, lê dê ji hêla pêşniyara parzûnê ve hêj tiştên din neyên avêtin an ceribandin.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// Vebijarkek vedigerîne dabeşkerê bingehîn.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Navnîşa * * paşîn * paşnavê nûve bikin nûve bikin.
                // Ger pêşnûma berî û nûveka panics were nûve kirin, dê hêmana li ser vê indexê derkeve.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // Ev dewletek xweş tevlihev e, û bi rastî tiştek eşkere nayê dîtin ku were kirin.
                        // Em naxwazin ku em berdewam bikin ku `pred` bidarizînin, ji ber vê yekê em tenê hemî hêmanên neçareserkirî paşve vediguhêzin û ji vec re dibêjin ku ew hîn jî hene.
                        //
                        // Veguhêrîna paşîn hewce ye ku pêşî li panic-ê ya di pêşîn de pêşî li daketina duçar a paşiya paşîn a ku bi serfirazî hate vekişandin, bigire.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Ger hêjmara parzûnê hêj neketiye panîkê hewl bidin ku hêmanên mayî bixwin.
        // Em ê hêmanên mayî paşde vegerînin gelo me berê xistiye panîkê an jî ger vexwarin li vir panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}