//! Cûreyek arke ya mezinbûyî ya lihevhatî ku bi naverokên heap-veqetandî, `Vec<T>` nivîsandî.
//!
//! Vectors xwedan navnîşkirina `O(1)`, pişka amortîzekirî `O(1)` (heya dawiyê) û `O(1)` pop (ji dawiya).
//!
//!
//! Vectors piştrast dikin ku ew qet ji `isize::MAX` bayt zêdetir veqetînin.
//!
//! # Examples
//!
//! Hûn dikarin bi eşkere [`Vec`] bi [`Vec::new`] biafirînin:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... an bi karanîna makroya [`vec!`]:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // deh sifir
//! ```
//!
//! Hûn dikarin nirxên [`push`] li dawiya vector (ku dê vector li gorî hewceyê mezin bibe) bidin:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Popping nirxan bi heman rengî dixebite:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors jî piştgiriyê dide endeksiyonê (bi [`Index`] û [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Cûreyek array ya mezinbûyî ya lihevkirî, ku wekî `Vec<T>` hatiye nivîsandin û 'vector' tê bilêv kirin.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// Makroya [`vec!`] tête peyda kirin ku destpêkirin hêsantir be:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Her weha dikare her hêmanek `Vec<T>`-ê bi nirxek dayî destpê bike.
/// Ev dibe ku ji pêkanîna dabeşkirin û destpêkirinê di gavên cuda de, nemaze dema destpêkirina vector ya sifir, jêhatîtir be:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Ya jêrîn wekhev e, lê potansiyel hêdîtir e:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Ji bo bêtir agahdarî, li [Capacity and Reallocation](#capacity-and-reallocation) binihêrin.
///
/// `Vec<T>` wekî stackek bandor bikar bînin:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // 3, 2, 1 çap dike
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Cureyê `Vec` dihêle ku bi endeksê bigihîje nirxan, ji ber ku ew [`Index`] trait bicîh dike.Mînakek wê eşkeretir be:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // ew ê '2' nîşan bide
/// ```
///
/// Lêbelê hay ji xwe hebin: heke hûn hewl bidin ku xwe bigihînin indexek ku di `Vec` de nîne, nermalava we dê panic be!Hûn nikarin vê yekê bikin:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// [`get`] û [`get_mut`] bikar bînin heke hûn dixwazin bipirsin ka index di `Vec` de ye an na.
///
/// # Slicing
///
/// `Vec` dikare guhêrbar be.Ji aliyê din ve, perçe tiştên tenê-xwendî ne.
/// Ji bo bidestxistina [slice][prim@slice], [`&`] bikar bînin.Mînak:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... û ew hemî!
/// // hûn jî dikarin wiya bikin:
/// let u: &[usize] = &v;
/// // an mîna vê:
/// let u: &[_] = &v;
/// ```
///
/// Di Rust de, gava ku hûn tenê dixwazin ku gihîştina xwendinê peyda bikin, pirtirîn e ku hûn pirtikan wekî argumanan derbas bikin ji vectors.Heman tişt ji bo [`String`] û [`&str`] jî derbas dibe.
///
/// # Kapasîte û ji nû ve veqetandin
///
/// Kapasîteya vector mîqdara valahiyê ye ku ji bo her hêmanên future ku dê li vector werin zêdekirin veqetandî ye.Ev bi *dirêjahiya* vector-ê, ku hejmara hêmanên rastîn ên di nav vector-ê de diyar dike, nayê xapandin.
/// Ger dirêjahiya vector ji kapasîteya wê zêdetir be, dê kapasîteya wê bixweber were zêdekirin, lê hêmanên wê dê ji nû ve werin veqetandin.
///
/// Mînakî, vector bi kapasîteya 10 û dirêjahiya 0 dê vector ya vala be ku ji bo 10 hêmanên din cîh bigire.10 an kêmtir hêmanên li ser vector bikişîne dê kapasîteya wê neguhere an nebe sedem ku ji nû ve veqetandin pêk were.
/// Lêbelê, heke dirêjahiya vector heya 11-ê were zêdekirin, ew ê neçar be ku ji nû ve vehewîne, ku dikare hêdî be.Ji ber vê sedemê, tê pêşniyar kirin ku kengê gengaz be [`Vec::with_capacity`] bikar bînin da ku diyar bikin ku vector çiqas mezin dibe ku were diyar kirin.
///
/// # Guarantees
///
/// Ji ber xwezaya xweya bêhempa ya bingehîn, `Vec` di derbarê sêwirana xwe de gelek mîsogeriyan dike.Ev piştrast dike ku ew di rewşa gelemperî de wekî mimkun kêm e, û dikare bi awayên prîmîtîf bi koda ne ewle were rêve kirin.Têbînî ku van garantî behsa `Vec<T>`-ya neçandî dikin.
/// Ger parametreyên celebê yên zêdek werin zêdekirin (mînakî, ji bo piştgirîkirina dabeşkerên xwerû), bipijiqandina pêşkeftinên wan dibe ku tevger biguheze.
///
/// Ya herî bingehîn, `Vec` e û her dem dê sêpîlek (pêşnîyar, kapasîte, dirêjahî) be.Ne zêde, ne kêm.Rêzeya van zeviyan bi tevahî ne diyar e, û hûn hewce ne ku rêbazên guncan bikar bînin ku vana biguherînin.
/// Nîşanek dê carî betal nebe, ji ber vê yekê ev celeb null-pointer-çêtirîn e.
///
/// Lêbelê, dibe ku nîşander rastî bîranîna veqetandî neyê.
/// Bi taybetî, heke hûn `Vec` bi kapasîteya 0 bi navgîniya [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], an bi gazîkirina [`shrink_to_fit`] re li ser Vec-a vala ava bikin, ew ê bîrayê veqetîne.Bi heman rengî, heke hûn celebên sifir-mezinahî di hundurê `Vec` de tomar bikin, ew ê ji wan re cîh veneqetîne.
/// *Zanibe ku di vê rewşê de dibe ku `Vec` [`capacity`] 0 0 rapor neke*.
/// `Vec` dê heke û tenê heke [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Bi gelemperî, hûrguliyên dabeşkirina `Vec` pir nazik in-heke hûn bixwazin bîranînê bi karanîna `Vec` veqetînin û ji bo tiştek din bikar bînin (an ji bo kodek ne ewle derbas bibin, an jî ji bo bîranîna xweya bîranîn-piştevanî ava bikin), bawer bin da ku vê bîranînê bi karanîna `from_raw_parts` vegerîne da ku `Vec` vegerîne û dûv re jî bavêje.
///
/// Heke `Vec`*bîranîn* veqetandibe, wê hingê bîranîna ku ew nîşan dike li ser hep e (wekî ku ji hêla dabeşker Rust ve hatî vesaz kirin ve hatî vesaz kirin ku ji hêla default ve were bikar anîn), û nîşana wê [`len`] destnîşan dike ku hêmanên destpêkirî, li pey hev (hûn ê çi bikin binihêrin ka we ew neçar kirî perçeyek), li pey [`kapasîte`]`,`[[`len`] bi mantiqî uninitialized, hêmanên berdewam.
///
///
/// vector ku hêmanên `'a'` û `'b'` bi kapasîteya 4 tê de heye dikare wekî jêrîn were xuyang kirin.Beşa jorîn `Vec` struktur e, ew tê de nîşanderê serê veqetandinê di heap, dirêjahî û kapasîteyê de heye.
/// Beşê jêrîn dabeşkirina li ser heapê, blokek bîranînê ya lihevhatî ye.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** bîranîna ku ne destpêkirî temsîl dike, li [`MaybeUninit`] binihêre.
/// - Note: ABI ne aram e û `Vec` di derbarê bîranîna xwe de (rêza zeviyan jî tê de) ti garantî nade.
///
/// `Vec` dê carî "small optimization" pêk neyne ku hêman bi rastî ji ber du sedeman li ser stokê hatine hilanîn:
///
/// * Ew ê ji bo kodek ne ewle dijwartir bibe ku `Vec` rast bi rêve bibe.Naveroka `Vec` heke tenê were veguhastin dê navnîşanek stabîl tune be, û vebirîn ka `Vec` bi rastî bîranîn veqetandî ye dê dijwartir be.
///
/// * Ew ê doza gelemperî ceza bike, li ser her gihiştinê branch-ya din jî hebe.
///
/// `Vec` dê carî bixweber xwe piçûk neke, heke bi tevahî vala be jî.Ev piştrast dike ku tu dabeşkirin an dealokasyonên nehewce rû nedin.Valakirina `Vec` û paşê tijîkirina wê heya [`len`] heman pêdivî ye ku tu bang li dabeşker neyê kirin.Heke hûn dixwazin bîranînek bêkêr azad bikin, [`shrink_to_fit`] an [`shrink_to`] bikar bînin.
///
/// [`push`] û [`insert`] heke kapasîteya ragihandî bes be dê carî (ji nû ve) veqetîne.[`push`] û [`insert`]*dê*(ji nû ve) veqetîne heke [`len`]`==`` `kapasîteya``.Ew e, kapasîteya ragihandî bi tevahî rast e, û dikare xwe bispêre wî.Heke bixwaze dikare bîraya ku ji hêla `Vec` ve hatî veqetandin bi destan were azad kirin jî tê bikar anîn.
/// Rêbazên xistina komê *dibe ku* ne hewce be jî, ji nû ve veqetîne.
///
/// `Vec` ne stratejiyek taybetî ya mezinbûnê garantî dike dema ku ji nû ve were veqetandin dema tijî be, û ne jî dema ku ji [`reserve`] re tê gotin.Stratejiya heyî bingehîn e û dibe ku ew tê xwestin ku faktoriyek mezinbûnê ya ne-domdar were bikar anîn.Çi stratejî tê bikar anîn bê guman dê *O*(1) [`push`] amortîzekirî garantî bike.
///
/// `vec![x; n]`, `vec![a, b, c, d]`, û [`Vec::with_capacity(n)`][`Vec::with_capacity`], dê hemî `Vec` bi tamî kapasîteya daxwazkirî hilberînin.
/// Ger [`len`]`==`` ``kapasîte``, (wek ku ji bo makroya [`vec!`] wiha ye), wê hingê `Vec<T>` dikare bê veguheztin an jî livandin hêmanan ji [`Box<[T]>`][owned slice] re were veguheztin.
///
/// `Vec` dê daneyên ku jê hatine derxistin bi taybetî ji nû ve nenivîsîne, lê di heman demê de wê bi taybetî jî neparêze.Bîra wê ya uninitialized cîhê xalî ye ku dibe ku lê bixwaze bikar tîne.Ew ê bi gelemperî her tiştê ku herî bikêrhatî ye an jî pêkanînek hêsan hêsan e.Baweriya xwe bi daneyên jêbirî neynin ku ji bo armancên ewlehiyê werin paqij kirin.
/// Heke hûn `Vec` bavêjin jî, tampona wê dibe ku bi tenê ji hêla `Vec` din ve were bikar anîn.
/// Hergê hûn pêşiyê bîreka `Vec`-ê sifir bikin, ew dibe ku bi rastî çênebe ji ber ku optimizer vê yekê wekî bandorek alî nafikire ku divê were parastin.
/// Yek doz heye ku em ê wê neşkînin, lêbelê: karanîna koda `unsafe` ku ji kapasîteya zêde re binivîse, û dûv re dirêjkirina hevberkirinê zêde dike, her dem derbasdar e.
///
/// Naha, `Vec` rêza ku hêman têne avêtin garantî nake.
/// Ferman di rabirdûyê de guheriye û dibe ku dîsa biguhere.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Rêbazên xwerû
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// `Vec<T>` nû, vala çêdike.
    ///
    /// vector dê veqetîne heya ku hêmanan li ser wê nexşînin.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Bi kapasîteya diyarkirî `Vec<T>` nû, vala ava dike.
    ///
    /// vector dê bêyî ku ji nû ve veqetîne hêmanên `capacity` rast bigire.
    /// Ger `capacity` 0 be, vector dê veqetîne.
    ///
    /// Girîng e ku meriv not bike ku her çend vector vegeriyayî *kapasîteya* diyar kirî jî hebe, lê vector dê * ** **wê sifir* be.
    ///
    /// Ji bo ravekirina cûdahiya di navbera dirêjahî û kapasîteyê de, li *[Kapasîte û ji nû ve veqetandin]* binihêrin.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector tevî ku kapasîteya wê ya zêdetir jî heye, ti tişt tune
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Van hemî bêyî ji nû ve veqetandinê têne kirin ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... lê ev dibe ku vector ji nû ve veqetîne
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// `Vec<T>` rasterast ji pêkhatên rawe yên vector-ya din diafirîne.
    ///
    /// # Safety
    ///
    /// Ev ji ber jimara neguhêzbarên ku nayên kontrol kirin pir ewledar e:
    ///
    /// * `ptr` pêdivî ye ku berê bi navgîniya [`String`]/`Vec hatibe veqetandin<T>`(qe nebe, pir zêde îhtîmal e ku ne rast be).
    /// * `T` pêdivî ye ku bi heman pîvan û rêzkirinê be ku `ptr` bi çi hatî veqetandin.
    ///   (`T` xwedîkirina rêzikek kêmtir hişk ne bes e, rêzkirin bi rastî hewce ye ku wekhev be da ku pêdiviya [`dealloc`] bicîh bîne ku divê bîranîn bi heman dîzaynê were veqetandin û veqetandin.)
    ///
    /// * `length` pêdivî ye ku ji `capacity` kêmtir an wekhev be.
    /// * `capacity` pêdivî ye ku kapasîteya ku nîşander pê re hatî veqetandin be.
    ///
    /// Binpêkirina vana dibe ku bibe sedema pirsgirêkên mîna xerakirina avahiyên daneyên navxweyî yên dabeşker.Mînakî ew ne ** ewledar e ku meriv `Vec<u8>` ji pointerê li rêzeyek C `char` bi dirêjahiya `size_t` ava bike.
    /// Di heman demê de ne ewle ye ku meriv ji `Vec<u16>` û dirêjahiya wê were çêkirin, ji ber ku dabeşker xêzkirinê li hevûdu dike, û van her du celeb rêzikên cûda hene.
    /// Tampon bi rêzkirin 2 (ji bo `u16`) hate veqetandin, lê piştî ku ew veguherand `Vec<u8>` ew ê bi risteya 1 were veqetandin.
    ///
    /// Xwedaniya `ptr` bi bandor ji `Vec<T>` re tête veguheztin ku dibe ku hingê naveroka bîranînê ya ku ji hêla pointer ve li gorî xwe nîşan dide veqetîne, vehewîne an biguheze.
    /// Piştrast bikin ku piştî banga vê fonksiyonê tiştek din nîşanker bikar nayne.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Dema ku vec_into_raw_parts sabit kirin vê yekê nû bikin.
    ///     // Rê li ber hilweşandina `v` bigire da ku em di veqetandinê de bi tevahî kontrol bikin.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Di derbarê `v` de agahdariyên cûda yên girîng derxînin
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Bîranînê bi 4, 5, 6 binivîse
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Her tişt li hev vegerînin nav Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// `Vec<T, A>` nû, vala çêdike.
    ///
    /// vector dê veqetîne heya ku hêmanan li ser wê nexşînin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Bi vebirrînerê veberhêneran re bi kapasîteya diyarkirî `Vec<T, A>` nû, vala ava dike.
    ///
    /// vector dê bêyî ku ji nû ve veqetîne hêmanên `capacity` rast bigire.
    /// Ger `capacity` 0 be, vector dê veqetîne.
    ///
    /// Girîng e ku meriv not bike ku her çend vector vegeriyayî *kapasîteya* diyar kirî jî hebe, lê vector dê * ** **wê sifir* be.
    ///
    /// Ji bo ravekirina cûdahiya di navbera dirêjahî û kapasîteyê de, li *[Kapasîte û ji nû ve veqetandin]* binihêrin.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector tevî ku kapasîteya wê ya zêdetir jî heye, ti tişt tune
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Van hemî bêyî ji nû ve veqetandinê têne kirin ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... lê ev dibe ku vector ji nû ve veqetîne
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// `Vec<T, A>` rasterast ji pêkhatên rawe yên vector-ya din diafirîne.
    ///
    /// # Safety
    ///
    /// Ev ji ber jimara neguhêzbarên ku nayên kontrol kirin pir ewledar e:
    ///
    /// * `ptr` pêdivî ye ku berê bi navgîniya [`String`]/`Vec hatibe veqetandin<T>`(qe nebe, pir zêde îhtîmal e ku ne rast be).
    /// * `T` pêdivî ye ku bi heman pîvan û rêzkirinê be ku `ptr` bi çi hatî veqetandin.
    ///   (`T` xwedîkirina rêzikek kêmtir hişk ne bes e, rêzkirin bi rastî hewce ye ku wekhev be da ku pêdiviya [`dealloc`] bicîh bîne ku divê bîranîn bi heman dîzaynê were veqetandin û veqetandin.)
    ///
    /// * `length` pêdivî ye ku ji `capacity` kêmtir an wekhev be.
    /// * `capacity` pêdivî ye ku kapasîteya ku nîşander pê re hatî veqetandin be.
    ///
    /// Binpêkirina vana dibe ku bibe sedema pirsgirêkên mîna xerakirina avahiyên daneyên navxweyî yên dabeşker.Mînakî ew ne ** ewledar e ku meriv `Vec<u8>` ji pointerê li rêzeyek C `char` bi dirêjahiya `size_t` ava bike.
    /// Di heman demê de ne ewle ye ku meriv ji `Vec<u16>` û dirêjahiya wê were çêkirin, ji ber ku dabeşker xêzkirinê li hevûdu dike, û van her du celeb rêzikên cûda hene.
    /// Tampon bi rêzkirin 2 (ji bo `u16`) hate veqetandin, lê piştî ku ew veguherand `Vec<u8>` ew ê bi risteya 1 were veqetandin.
    ///
    /// Xwedaniya `ptr` bi bandor ji `Vec<T>` re tête veguheztin ku dibe ku hingê naveroka bîranînê ya ku ji hêla pointer ve li gorî xwe nîşan dide veqetîne, vehewîne an biguheze.
    /// Piştrast bikin ku piştî banga vê fonksiyonê tiştek din nîşanker bikar nayne.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Dema ku vec_into_raw_parts sabit kirin vê yekê nû bikin.
    ///     // Rê li ber hilweşandina `v` bigire da ku em di veqetandinê de bi tevahî kontrol bikin.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Di derbarê `v` de agahdariyên cûda yên girîng derxînin
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Bîranînê bi 4, 5, 6 binivîse
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Her tişt li hev vegerînin nav Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// `Vec<T>` di nav pêkhateyên wê yên xav de xera dibe.
    ///
    /// Pointerê xav vedigere daneyên bingehîn, dirêjahiya vector (di hêmanan de), û kapasîteya veqetandî ya daneyê (di hêmanan de) vedigerîne.
    /// Van heman argumanan di heman rêzê de wekî argumanên [`from_raw_parts`]-ê ne.
    ///
    /// Piştî banga vê fonksiyonê, bangker berpirsiyarê bîranînê ye ku berê ji hêla `Vec` ve hatibû rêvebirin.
    /// Awayê yekane ev e ku veguhezîne nîşander, dirêjahî, û kapasîteya rawe ya paşîn li `Vec` bi fonksiyona [`from_raw_parts`] veguherîne, da ku hilweşîner paqijiyê pêk bîne.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Wedî em dikarin guhartinan li pêkhateyan bikin, wekî mînak veguheztina nîşanderê xav bo celebek lihevhatî.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// `Vec<T>` di nav pêkhateyên wê yên xav de xera dibe.
    ///
    /// Pointerê xav vedigere ser daneyên bingehîn, dirêjahiya vector (di hêmanan de), kapasîteya veqetandî ya daneyê (di hêmanan de), û dabeşker vedigerîne.
    /// Van heman argumanan di heman rêzê de wekî argumanên [`from_raw_parts_in`]-ê ne.
    ///
    /// Piştî banga vê fonksiyonê, bangker berpirsiyarê bîranînê ye ku berê ji hêla `Vec` ve hatibû rêvebirin.
    /// Awayê tenê ku meriv vê yekê bike ev e ku hûn pêşanderê dirêj, dirêjahî û kapasîteya raweyê bi fonksiyona [`from_raw_parts_in`] veguherînin `Vec`, da ku hilweşîner paqijiyê pêk bîne.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Wedî em dikarin guhartinan li pêkhateyan bikin, wekî mînak veguheztina nîşanderê xav bo celebek lihevhatî.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Hejmara hêmanên ku vector dikare bêyî ji nû ve veqetandinê ragire vedigerîne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Kapasîteya rezervan ji bo kêmtirîn `additional` hêmanên din ên ku di `Vec<T>` dane de werin vehewandin.
    /// Dibe ku berhevok cîhê bêtir veqetîne da ku ji nû ve veqetandinan dûr nekeve.
    /// Piştî bangkirina `reserve`, kapasîte dê ji `self.len() + additional` mezintir an wekhev be.
    /// Heke kapasîte jixwe bes be tiştek nake.
    ///
    /// # Panics
    ///
    /// Panics heke kapasîteya nû `isize::MAX` bayît derbas bike.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Kapasîteya herî kêm ji bo hêjayî `additional` hêmanên din ên ku di `Vec<T>`-ya dayînê de bêne hilanîn, diparêze.
    ///
    /// Piştî bangkirina `reserve_exact`, kapasîte dê ji `self.len() + additional` mezintir an wekhev be.
    /// Heke kapasîte jixwe bes be tiştek nake.
    ///
    /// Zanibe ku dabeşker dikare ji berhevokê zêdetir ji ya ku ew daxwaz dike bide.
    /// Ji ber vê yekê, ji kapasîteyê re ne mimkun e ku meriv bi kêmasî be.
    /// Ger têkela future tê hêvîkirin `reserve` tercîh bikin.
    ///
    /// # Panics
    ///
    /// Ger kapasîteya nû `usize` biherike Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Hewil dide ku kapasîteyê ji bo kêmtirîn `additional` hêmanên din vehewîne ku di `Vec<T>`-ya dayînê de were vehewandin.
    /// Dibe ku berhevok cîhê bêtir veqetîne da ku ji nû ve veqetandinan dûr nekeve.
    /// Piştî bangkirina `try_reserve`, kapasîte dê ji `self.len() + additional` mezintir an wekhev be.
    /// Heke kapasîte jixwe bes be tiştek nake.
    ///
    /// # Errors
    ///
    /// Ger kapasîte zêde bibe, an dabeşker têkçûnek ragihîne, wê hingê xeletiyek tê vegerandin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Berê bîranînê veqetînin, ger em nekarin derkevin
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Naha em dizanin ku ev nikare OOM di nîveka xebata meya tevlihev de
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // pir tevlihev
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Hewil dide ku kapasîteya herî kêm ji bo hêmanên `additional`-ê yên ku di `Vec<T>`-ya dayînê de werin vehewandin veqetîne.
    /// Piştî gazîkirina `try_reserve_exact`, heke ew `Ok(())` vegerîne dê kapasîte ji `self.len() + additional` mezintir an wekhev be.
    ///
    /// Heke kapasîte jixwe bes be tiştek nake.
    ///
    /// Zanibe ku dabeşker dikare ji berhevokê zêdetir ji ya ku ew daxwaz dike bide.
    /// Ji ber vê yekê, ji kapasîteyê re ne mimkun e ku meriv bi kêmasî be.
    /// Ger têkela future tê hêvîkirin `reserve` tercîh bikin.
    ///
    /// # Errors
    ///
    /// Ger kapasîte zêde bibe, an dabeşker têkçûnek ragihîne, wê hingê xeletiyek tê vegerandin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Berê bîranînê veqetînin, ger em nekarin derkevin
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Naha em dizanin ku ev nikare OOM di nîveka xebata meya tevlihev de
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // pir tevlihev
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Qasî ku pêkan e kapasîteya vector kurt dike.
    ///
    /// Ew ê heya ku mimkûn e bi dirêjahiyê dakeve lê veqetandek hîn jî dikare vector agahdar bike ku ji bo çend hêmanên din jî cîh heye.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Kapasîte carî ji dirêjahiyê kêm nabe, û dema ku ew wekhev in tiştek tune ku bikin, ji ber vê yekê em dikarin ji doza panic ya `RawVec::shrink_to_fit` dûr bisekinin û tenê bi kapasîteyek mezintir bang bikin.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Kapasîteya vector bi bendek jêrîn şîn dike.
    ///
    /// Kapasîte dê herî kêm bi qasî dirêjahî û nirxa dabînkirî mezin bimîne.
    ///
    ///
    /// Heke kapasîteya heyî ji tixûbê jêrîn kêmtir e, ev ne-op e.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// vector veguherîne [`Box<[T]>`][owned slice].
    ///
    /// Zanibe ku ev dê kapasîteya zêde bavêje.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Her kapasîteya zêde tête rakirin:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// vector kurt dike, hêmanên yekem `len` digire û yê mayî davêje.
    ///
    /// Ger `len` ji dirêjahiya heyî ya vector mezintir be, ev yek ti bandorekê nake.
    ///
    /// Rêbaza [`drain`] dikare `truncate` teqlîd bike, lê dibe sedem ku hêmanên zêde li şûna davêjin werin vegerandin.
    ///
    ///
    /// Zanibe ku ev rêbaz li ser kapasîteya veqetandî ya vector bandor nake.
    ///
    /// # Examples
    ///
    /// Kurtkirina pênc hêmana vector li du hêmanan:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Dema ku `len` ji dirêjahiya vector mezintir e tu qutbûn pêk nayê:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Kurtkirin dema ku `len == 0` wekhev e ku meriv banga rêbaza [`clear`] bike.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Ev ewle ye ji ber ku:
        //
        // * perçeya ku ji `drop_in_place` re hatî derbas kirin derbasdar e;doza `len > self.len` ji çêkirina perçek nederbasdar dûr dikeve, û
        // * `len` ya vector berî bangkirina `drop_in_place` tê şûştin, wusa ku dê du hejmar du carî neyê daketin ku `drop_in_place` carek panic be (ger ew panics du car be, bername betal dibe).
        //
        //
        //
        unsafe {
            // Note: Bi mebest e ku ev `>` be û ne `>=` be.
            //       Guhertina wê bi `>=` di hin rewşan de encamên çalakiyê yên neyînî hene.
            //       Ji bo bêtir #78884 bibînin.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Qertalek ku tev vector tê de derdixe.
    ///
    /// Bi `&s[..]` re wekhev e.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Parçeyek guhêrbar a tevahî vector-ê derdixe.
    ///
    /// Bi `&mut s[..]` re wekhev e.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Pointerek xav vedigerîne tampona vector.
    ///
    /// Divê bangker piştrast bike ku vector nîşanderê ku ev fonksiyon vedigere ji zindîtir e, an na ew ê dawî bibe û nîşana çopê bide.
    /// Guhertina vector dibe ku tampona wê ji nû ve were veqetandin, ku ev jî dê nîşanên li ser wê nederbasdar be.
    ///
    /// Her weha bangker divê piştrast bike ku bîra ku nîşana (non-transitively) nîşan dide qet neyê nivîsandin (ji xeynî hundurê `UnsafeCell`) bi karanîna vê pointer an jî nîşanderê ku jê tê der.
    /// Heke hûn hewce ne ku naveroka perçeyê mutas bikin, [`as_mut_ptr`] bikar bînin.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Em rêbaza slice ya bi heman navî di bin siyê de digirin da ku `deref` derbas neke, ku referansek navîn diafirîne.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Nîşanek guhêrbar a ewledar vegerîne tampona vector.
    ///
    /// Divê bangker piştrast bike ku vector nîşanderê ku ev fonksiyon vedigere ji zindîtir e, an na ew ê dawî bibe û nîşana çopê bide.
    ///
    /// Guhertina vector dibe ku tampona wê ji nû ve were veqetandin, ku ev jî dê nîşanên li ser wê nederbasdar be.
    ///
    /// # Examples
    ///
    /// ```
    /// // Ji bo 4 hêmanan vector têra xwe mezin veqetînin.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Destpêka hêmanên bi navgîniya nîşankerê rawe, piştre dirêjahiyê destnîşan dikin.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Em rêbaza slice ya bi heman navî di bin siyê de digirin da ku `deref_mut` derbas neke, ku referansek navîn diafirîne.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Vebijarkek vedigerîne dabeşkerê bingehîn.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Dirêjahiya vector heya `new_len` ferz dike.
    ///
    /// Ev operasyonek kêm-ast e ku yek ji nehêlên normal ên celebê diparêze.
    /// Bi gelemperî guhertina dirêjahiya vector li şûna yek ji karûbarên ewle tê bikar anîn, wekî [`truncate`], [`resize`], [`extend`], an [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` divê ji [`capacity()`] kêmtir an wekhev be.
    /// - Divê hêmanên li `old_len..new_len` werin destpêkirin.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Ev rêbaz dikare ji bo rewşên ku vector wekî tamponek ji bo koda din re xizmetê dike, nemaze li ser FFI bikêr be:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Ev ji bo mînaka doks tenê îskeletek kêmînîn e;
    /// # // vê yekê wekî xala destpêkek ji bo pirtûkxaneyek rastîn bikar neynin.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Li gorî belgeyên rêbaza FFI, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // BELAW: Gava `deflateGetDictionary` `Z_OK` vedigerîne, wê ev bigire dest:
    ///     // 1. `dict_length` hêman hatin destpêkirin.
    ///     // 2.
    ///     // `dict_length` <=kapasîteya (32_768) ya ku bangkirina `set_len` ewle dike.
    ///     unsafe {
    ///         // Banga FFI bikin ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... û dirêjahiya ku hate destpêkirin nûve bikin.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Dema ku mînaka jêrîn deng e, ji ber ku vectors-ya hundurîn berî banga `set_len` azad nebûne, bîhnek bîranînê heye:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` vala ye lewma hewce nake ku tu hêman werin destpêkirin.
    /// // 2. `0 <= capacity` her dem `capacity` çi ye tê de digire.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Bi gelemperî, li vir, meriv dê li şûna wê [`clear`] bikar bîne da ku naverokan bi rêkûpêk bavêje û bi vî rengî bîra xwe neşewitîne.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Hêmanek ji vector radike û vedigerîne.
    ///
    /// Hêmana ku hatî rakirin bi hêmana paşîn a vector ve tête şandin.
    ///
    /// Ev rêzkirinê nahêle, lê O(1) e.
    ///
    /// # Panics
    ///
    /// Panics heke `index` derveyî sînor be.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Em xweser [navnîş] bi hêmana paşîn veguherînin.
            // Bala xwe bidinê ku heke kontrola sînoran li jor bi ser keve divê elementek paşîn hebe (ku dikare bixwe [index] bixwe be).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Hêmanek di pozîsyona `index` de dixe hundurê vector, hemî hêmanan li dû xwe vediguhêzîne rastê.
    ///
    ///
    /// # Panics
    ///
    /// Panics heke `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // cîh ji bo hêmana nû
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // bêkêmasî Cihê danîna nirxa nû
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Her tişt veguherînin da ku cîh çêbike.
                // (Dabeşkirina hêmana `index`-ê li du cîhên li pey hev.)
                ptr::copy(p, p.offset(1), len - index);
                // Wê binivîsin, pêgirta yekem a hêmana `index`-ê binivîsînin.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Hêmana di pozîsyona `index` de ya di nav vector de radike û vedigerîne, hemî hêmanan piştî wî vediguhêzîne çepê.
    ///
    ///
    /// # Panics
    ///
    /// Panics heke `index` derveyî sînor be.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // cihê ku em jê digirin.
                let ptr = self.as_mut_ptr().add(index);
                // wê kopî bikî, di heman demê de bi ewlehî kopiyek nirxê li ser stack û di vector de hebe.
                //
                ret = ptr::read(ptr);

                // Her tişt veguherînin da ku wê cîh dagirin.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Tenê hêmanên ku ji hêla pêşbend ve hatine diyar kirin vedihewîne.
    ///
    /// Bi gotinên din, hemî hêmanên `e` derxistin ku `f(&e)` `false` vegerîne.
    /// Ev rêbaza hanê di cîh de kar dike, her yek di rêza yekem de carekê diçe serdana her hêmanê, û rêza hêmanên ragirtî diparêze.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Ji ber ku hêmanên di rêza yekem de tam carek têne ziyaret kirin, dibe ku dewleta derveyî were bikar anîn ku biryar bide kîjan hêmanan bigirin.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Heke parastina cerdevaniyê neyê darve kirin du qatan dûr bixin, ji ber ku dibe ku di pêvajoyê de em hin qulikan çêbikin.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-lenê pêvajoyê-> |^-li kêleka kontrolê
        //                  | <-cnt jêbirin-> |
        //      | <-orîjînal-> |Kept: Hêmanên ku pêşpirtik lê vedigerin rast in.
        //
        // Hole: Slotê hêmanê bar kir an daket.
        // Neçêkirî: Hêmanên derbasdar ên neçêkirî.
        //
        // Dema ku predîtat an `drop` hêman ket nav panîkê, ev parêzvanê dilopê dê were bang kirin.
        // Ew hêmanên neçêkirî vedigire da ku qulikan û `set_len` bi dirêjahiya rast veşêre.
        // Di rewşên ku predîtat û `drop` carî natirsin, ew ê çêtirîn were derxistin.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // EWLEHIY: : Tiştên şopandî yên neçêkirî divê derbasdar be ji ber ku em carî dest nadin wan.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // EWLEH: : Piştî dagirtina qulikan, hemî tişt di bîra hevûdu de ne.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // EWLEHIY: : Hêmana neçêkirî divê derbasdar be.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Ger `drop_in_place` panîk bike pêşî li pêş bikevin da ku ducar davêjin.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // EWLEH: : Em piştî daketinê carek din destê xwe nadin vê hêmanê.
                unsafe { ptr::drop_in_place(cur) };
                // Me berê counter pêşve xist.
                continue;
            }
            if g.deleted_cnt > 0 {
                // EWLEH: `deleted_cnt`> 0, ji ber vê yekê divê slota qulikê bi hêmana heyî re nexebite.
                // Em kopiyê ji bo bar bikar tînin, û carek din destê xwe nadin vê hêmanê.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Hemî tişt têne pêvajo kirin.Ev dikare ji hêla LLVM ve ji `set_len` re were optimîzekirin.
        drop(g);
    }

    /// Di vector-ê de ku bi heman mifteyê çareser dibin lê hemî yekem hêmanên li pey hev radike.
    ///
    ///
    /// Ger vector rêzkirî be, ev hemû dûpalokan radike.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Di vector-ê de têkiliyek wekheviya têra xwe têr dike lê ji yekem hêmanên li pey hev ji holê radike.
    ///
    /// Fonksiyona `same_bucket` ji vector re referansên du hêmanan derbas dibe û divê diyar bike ka hêman wekhev in an na.
    /// Hêmanên bi rêza berevajî ji rêza wan a li perçeyê derbas dibin, ji ber vê yekê heke `same_bucket(a, b)` `true` vegerîne, `a` tê rakirin.
    ///
    ///
    /// Ger vector rêzkirî be, ev hemû dûpalokan radike.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Hêmanek li pişta berhevokê ve girêdide.
    ///
    /// # Panics
    ///
    /// Panics heke kapasîteya nû `isize::MAX` bayît derbas bike.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Heke em ê> isize::MAX byte veqetînin an heke zêdebûna dirêjahiyê ji bo celebên sifir-sized zêde bibe ev dê panic an biqedîne.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Hêmana paşîn ji vector radike û vedigerîne, an heke V00X vala be [`None`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Hemî hêmanên `other` dixe nav `Self`, `other` vala dihêle.
    ///
    /// # Panics
    ///
    /// Panics heke hejmara hêmanên di vector de `usize` zêde bibe.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Ji tampona din hêmanan bi `Self` ve girêdide.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Iteratorê şûştinê diafirîne ku di vector-ê de rêzika diyarkirî ji holê radike û hêmanên jêkirî dide.
    ///
    /// Gava ku iterator **davêje**, hemî hêmanên di rêzê de ji vector têne derxistin, her çend iterator bi tevahî nehatibe vexwarin.
    /// Ger iterator ** nehatibe daxistin (bi mînakî [`mem::forget`]), ew nayê diyarkirin ka çend hêman têne rakirin.
    ///
    /// # Panics
    ///
    /// Panics heke xala destpêkê ji xala dawî mezintir be an xala dawiyê ji dirêjahiya vector mezintir be.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Rêzeyek tevahî vector paqij dike
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Ewlekariya bîranînê
        //
        // Gava ku Drain yekem tê afirandin, ew dirêjahiya çavkaniya vector kurtir dike da ku piştrast bike ku heke hilweşînerê Drain carî neçe rê tu elementên uninitialized an bargiran-çûn tune.
        //
        //
        // Drain dê ptr::read nirxên ku derxîne derxîne.
        // Dema ku xilas bû, dûvê mayî yê vecê paşve tête kopî kirin ku qulikê veşêre, û dirêjahiya vector bi dirêjahiya nû vedigere.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // Dirêjahiya self.vec destnîşan bikin ku dest pê bike, da ku ew di ewlehiyê de be ku Drain derkeve
            self.set_len(start);
            // Di IterMut de deyn bikar bînin da ku tevgera deynkirina tevgera tevgera Drain (wekî &mut T) nîşan bikin.
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// vector paqij dike, hemî nirxan radike.
    ///
    /// Zanibe ku ev rêbaz li ser kapasîteya veqetandî ya vector bandor nake.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Hejmara hêmanên li vector vedigerîne, wekî 'length' ya wê jî tê binavkirin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Ger vector hêman tunebe `true` vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Di navnîşa danehev de berhevokê dabeş dike.
    ///
    /// vector-ya nû veqetandî vedigerîne ku tê de hêmanên di rêza `[at, len)` de hene.
    /// Piştî bangê, dê vector ya orjînal hêmanên `[0, at)` bi kapasîteya xweya berê neguhêzbar bimîne.
    ///
    ///
    /// # Panics
    ///
    /// Panics heke `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // vector ya nû dikare tampona orîjînal bigire û ji pêgirtê dûr bikeve
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Bê ewlehî `set_len` û tiştan li `other` kopî bikin.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// `Vec` di cîh de mezin dike da ku `len` bi `new_len` re wekhev be.
    ///
    /// Ger `new_len` ji `len` mezintir e, `Vec` bi cûdahiyê tête dirêj kirin, her hêlînek din bi encama bangkirina girtina `f` ve tijî ye.
    ///
    /// Nirxên vegera ji `f` dê di rêza ku ew hatine hilberandin de di `Vec` de bi dawî bibe.
    ///
    /// Heke `new_len` ji `len` kêmtir e, `Vec` bi tenê tête kurt kirin.
    ///
    /// Ev rêbaz ji bo afirandina nirxên nû li ser her pişkê vegirtinek bikar tîne.Heke hûn nirxek dayînek li şûna [`Clone`] dixwazin, [`Vec::resize`] bikar bînin.
    /// Heke hûn dixwazin [`Default`] trait bikar bînin da ku nirxan hilberînin, hûn dikarin wekî argumana duyemîn [`Default::default`] derbas bikin.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// `Vec` dixwe û diherike, referansa guhêrbar vedigere ser naverokan, `&'a mut [T]`.
    /// Têbînî ku divê celebê `T` ji jiyana bijartî `'a` zêdetir bimîne.
    /// Heke celeb tenê referansên statîk hene, an jî tune, hingê dibe ku ev were hilbijartin ku bibe `'static`.
    ///
    /// Ev fonksiyon dişibe fonksiyona [`leak`][Box::leak] a li ser [`Box`] e ji bilî ku çu rê tune ku meriv bîra bîhndakî vegerîne.
    ///
    ///
    /// Ev fonksiyon bi taybetî ji bo daneyên ku ji bo mayîna jiyana bernameyê dijî kêrhatî ye.
    /// Daxistina referansa vegeriyayî dê bibe sedema lerizînek bîranînê.
    ///
    /// # Examples
    ///
    /// Bikaranîna hêsan:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Kapasîteya vala ya mayî ya vector wekî pişkek `MaybeUninit<T>` vedigerîne.
    ///
    /// Pelê vegerandî dikare were bikar anîn ku vector bi daneyan dagire (mînak
    /// bi xwendina ji pelê) berî nîşankirina daneyê wekî destpêkirina karanîna rêbaza [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Ji bo 10 hêmanan vector têra xwe mezin veqetînin.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // 3 hêmanên yekem dagirin.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // 3 hêmanên yekem ên vector wekî destpêkirî nîşan bikin.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Ev rêbaza di warê `split_at_spare_mut` de nayê sepandin, da ku pêşî li nederbasdarbûna nîşangirên li tampon bigire.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Naveroka vector wekî perçek `T`, digel kapasîteya vala ya mayî ya vector wekî perçek `MaybeUninit<T>` vedigerîne.
    ///
    /// Pelê kapasîteya yedek a vegeriyayî dikare were bikar anîn ku vector bi daneyan tijî bike (mînakî bi xwendina ji pelê) berî nîşankirina daneyên ku bi rêbaza [`set_len`] hatine destpêkirin.
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Zanibe ku ev API-asta nizm e, ku divê ji bo armancên optimîzasyonê bi baldarî were bikar anîn.
    /// Heke hûn hewce ne ku daneyan bi `Vec` ve girêbidin hûn dikarin li gorî hewcedariyên weyên rast [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] an [`resize_with`] bikar bînin.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Ji bo 10 hêmanan têra xwe mezin cîhê xwe veqetînin.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // 4 hêmanên din dagirin.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // 4 hêmanên vector wekî destpêkirî nîşan bikin.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len tê paşguh kirin û ji ber vê yekê qet nayê guhertin
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Ewlehî: guherandina vegeriyan .2 (&mut bikar anîn) wekî bangkirina `.set_len(_)` wekhev tête hesibandin.
    ///
    /// Ev rêbaza hanê tête bikar anîn ku di `extend_from_within` de yekcar bigihîje hemî beşên vec.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` misogerkirî ye ku ji bo hêmanên `len` derbasdar e
        // - `spare_ptr` yek hêmanê li ber tamponê nîşan dide, ji ber vê yekê ew bi `initialized` re li hev nayê
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// `Vec` di cîh de mezin dike da ku `len` bi `new_len` re wekhev be.
    ///
    /// Ger `new_len` ji `len` mezintir e, `Vec` bi cûdahiyê tête dirêj kirin, her hêlînek pêvek bi `value` dagirtî.
    ///
    /// Heke `new_len` ji `len` kêmtir e, `Vec` bi tenê tête kurt kirin.
    ///
    /// Vê rêbazê hewce dike ku `T` [`Clone`] bicîh bîne, da ku karibe nirxa derbasbûyî klon bike.
    /// Heke ji we re nermbûnek zêdetir hewce dike (an dixwazin li şûna [`Clone`] xwe bisipêrin [`Default`]), [`Vec::resize_with`] bikar bînin.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Hemî hêmanan di perçek `Vec`-ê de klon dike û pêve dike.
    ///
    /// Li ser perçê `other` vedigere, her hêmanê klon dike, û dûv re jî wê bi vê `Vec` ve girêdide.
    /// `other` vector di rêzê de derbas dibe.
    ///
    /// Têbînî ku ev fonksiyon wek [`extend`] e ji bilî ku ew pispor e ku li şûna wê bi sliceyan re bixebite.
    ///
    /// Ger û gava Rust pispor bibe dê ev fonksiyon bête betal kirin (lê hîn jî heye).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Hêmanên ji rêzê `src` heya dawiya vector kopî dike.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` garantî dike ku rêzika hatî dayîn ji bo xweserkirina navnîşkirinê derbasdar e
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Vê kodê `extend_with_{element,default}` gelemperî dike.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// vector bi nirxên `n` dirêj bikin, hilberînerê dayîn bikar bînin.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // SetLenOnDrop bikar bînin ku li dora xeletiyê bixebitin ku dibe ku berhevkar bi navgîniya `ptr` bi self.set_len() depo nas neke.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Ji bilî ya paşîn hemî hêmanan binivîsin
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Di rewşê next() panics de di her gavê de dirêjahiyê zêde bikin
                local_len.increment_len(1);
            }

            if n > 0 {
                // Em dikarin hêmana paşîn rasterast bêyî klonkirina bêserûber binivîsin
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len ji hêla cerdevaniyê ve hatî danîn
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Li gorî pêkanîna [`PartialEq`] trait hêmanên dubarekirî yên li vector ji holê radike.
    ///
    ///
    /// Ger vector rêzkirî be, ev hemû dûpalokan radike.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Rêbaz û fonksiyonên navxweyî
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` pêdivî ye ku indexek derbasdar be
    /// - `self.capacity() - self.len()` divê `>= src.len()` be
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len tenê piştî destpêkirina hêmanan zêde dibe
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - bangker garantî dike ku src navnîşek derbasdar e
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Element tenê bi `MaybeUninit::write` ve hate destpêkirin, ji ber vê yekê baş e ku lenê zêde bikin
            // - len piştî her elementê tê zêdekirin da ku pêşî li lehiyan bigire (li pirsgirêka #82533 binihêrin)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - bangker garantî dike ku `src` navnîşek derbasdar e
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Herdu nîşander ji çavkanîyên perçeyên yekta têne afirandin (`&mut [_]`) ji ber vê yekê ew derbasdar in û li hev nayên.
            //
            // - Hêman ev in: Kopî bikin ji ber vê yekê baş e ku meriv wana kopî bike, bêyî ku bi nirxên xwerû re tiştek bike
            // - `count` bi lenê `source` re wekhev e, ji ber vê yekê jêderk ji bo xwendinên `count` derbasdar e
            // - `.reserve(count)` garantî dike ku `spare.len() >= count` ji ber vê yekê vala ji bo `count` nivîsandinê derbasdar e
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Hêmanên tenê ji hêla `copy_nonoverlapping` ve hatin destpêkirin
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Ji bo Vec pêkanînên hevpar ên trait
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): bi cfg(test) rêbaza xwerû `[T]::to_vec`, ku ji bo vê pênaseya rêbazê pêdivî ye, peyda nabe.
    // Di şûna wê de fonksiyona `slice::to_vec` bikar bînin ku tenê bi cfg(test) NB heye, ji bo bêtir agahdariyê modula slice::hack li slice.rs bibînin.
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // tiştek bavêjin ku dê neyê nivîsandin
        self.truncate(other.len());

        // self.len <= other.len ji ber kurteya li jor, ji ber vê yekê pelikên li vir her gav di nav sînoran de ne.
        //
        let (init, tail) = other.split_at(self.len());

        // nirxên tê de allocations/resources ji nû ve bikar bînin.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Iteratorek xerîdar diafirîne, ango, yekê ku her nirxê ji vector (ji serî heya dawî) derdixe.
    /// vector piştî bangkirina vê nayê bikar anîn.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s tîpa Têl heye, ne &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // rêbaza pelê ya ku pêkanînên cihêreng ên SpecFrom/SpecExtend delege dikin dema ku ji wan re optimîzasyonên din tune ku bikar bînin
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Ev rewş ji bo iteratorek gelemperî ye.
        //
        // Divê ev fonksiyon wekheviya manewî ya:
        //
        //      ji bo tiştê di iterator de {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB ji ber ku em neçar man cîhê navnîşanê veqetînin nikare zêde bibe
                self.set_len(len + 1);
            }
        }
    }

    /// Iteratorê splicing-ê diafirîne ku di vector-ê de diyarkerê `replace_with`-ê dayîn rêzika diyarkirî diguhezîne û tiştên jêkirî dide.
    ///
    /// `replace_with` ne hewce ye ku bi dirêjahiya `range` be.
    ///
    /// `range` tê rakirin heke iterator heya dawiyê neyê xerckirin.
    ///
    /// Heke nirxa `Splice` derkeve tê diyar kirin ka çend hêman ji vector têne derxistin.
    ///
    /// Iteratorê input `replace_with` tenê dema ku nirxa `Splice` tê avêtin tê xerckirin.
    ///
    /// Ev çêtirîn e heke:
    ///
    /// * Dûv (hêmanên di vector de piştî `range`) vala ye,
    /// * an `replace_with` ji dirêjahiya `range` kêmtir an hêmanên yeksan dide
    /// * an bendera jêrîn a `size_hint()`-a wê rast e.
    ///
    /// Wekî din, vector-a demkî tê veqetandin û dûvik du caran tê veguheztin.
    ///
    /// # Panics
    ///
    /// Panics heke xala destpêkê ji xala dawî mezintir be an xala dawiyê ji dirêjahiya vector mezintir be.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Iterator-ê ku girtinekê bikar tîne destnîşan dike ku divê hêmanek were rakirin an na.
    ///
    /// Heke dorpêç rast vegere, wê hingê hêman tê derxistin û hilberandin.
    /// Ger girtinê derew vegerîne, hêman dê di vector de bimîne û ji hêla dahêner ve nayê derxistin.
    ///
    /// Bikaranîna vê rêbazê bi koda jêrîn re hevwate ye:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // koda we li vir e
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Lê `drain_filter` karanîn hêsantir e.
    /// `drain_filter` di heman demê de karîgertir e jî, ji ber ku ew dikare hêmanên array bi girseyî paşde vegerîne.
    ///
    /// Zanibe ku `drain_filter` di heman demê de dihêle ku hûn her hêmanê di girtina parzûnê de mutate bikin, bêyî ku hûn hilbijêrin wê hiltînin an jê dikin.
    ///
    ///
    /// # Examples
    ///
    /// Dabeşkirina rêzeyek li êvarî û astengiyan, dîsan dabeşkirina orjînal ji nû ve bikar bînin:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Parastina ji ber ku em diherikin (amplification leak)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Pêkanîna ku hêmanan ji referansan kopî dike berî ku wan nexe Vecê, dirêj bikin.
///
/// Ev pêkanîn ji bo vegêranên perçeyan pispor e, ku ew [`copy_from_slice`] bikar tîne da ku tevahî perçeyê bi carekê ve girêbide.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Danberhevkirina vectors bicîh dike, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Rêzkirina vectors bicîh tîne, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // daketin bikar bînin ji bo [T] perçek rawe bikar bînin da ku hêmanên vector wekî celebek pêdivî ya herî lawaz binav bikin;
            //
            // dikare di hin rewşan de ji pirsên rastdariyê dûr bikeve
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec deallocation-ê digire dest
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// `Vec<T>`-a vala diafirîne.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: test li libstd dikişîne, ku li vir dibe sedema xeletiyan
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: test li libstd dikişîne, ku li vir dibe sedema xeletiyan
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Tevahiya naveroka `Vec<T>`-ê wekî rêzikek werdigire, heke mezinahiya wê tam bi ya array-ya xwestin re hev dike.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Heke dirêjahî li hev neke, navnîş di `Err` de vedigere:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Heke hûn bi tenê stendina pêşpirtika `Vec<T>` baş in, hûn dikarin pêşî lê bigerin [`.truncate(N)`](Vec::truncate).
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // EWLEH: : `.set_len(0)` her gav saxlem e.
        unsafe { vec.set_len(0) };

        // EWLEHIY: : Nîşanek `Vec`-ê her gav bi rêkûpêk tête rastandin, û
        // lihevnêzîkbûna hewceyê array heman tiştan e.
        // Me berê kontrol kir ku tiştên me têr dikin.
        // Tiştên wekî `set_len` ji `Vec` re dibêje bila wan jî davêje du qat davêjin.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}