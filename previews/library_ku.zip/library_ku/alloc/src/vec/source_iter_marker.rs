use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Nîşaneya pisporiyê ji bo berhevkirina xeteka iteratorê li Vecê dema ku ji nû ve veqetandina çavkaniyê bikar tîne, ango
/// bicîhkirina boriyê di cîh de.
///
/// Dê û bavê SourceIter trait ji bo fonksiyona pispor pêdivî ye ku bigihîje dabeşkirina ku dê were bikar anîn.
/// Lê ne bes e ku pisporî derbasdar be.
/// Sînorên din li ser impl-ê bibînin.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-navxweyî SourceIter/InPlaceIterable traits tenê bi zincîrên Adapter têne pêkanîn <Adapter<Adapter<IntoIter>>> (hemî xwedan core/std).
// Sînorên zêdeyî pêkanînên adapterê (ji `impl<I: Trait> Trait for Adapter<I>` wêdetir) tenê bi traits-yên din ve girêdayî ye ku jixwe wekî pisporiya traits-ê hatine nîşankirin (Kopî, TrustedRandomAccess, FusedIterator).
//
// I.e. nîşanker bi jiyanên celebên bikarhêner-peyda ve girêdayî nine.Modulo qulika Kopiyê, ku gelek pisporiyên din jixwe pê ve girêdayî ne.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Pêdiviyên din ên ku bi trait bounds ve nayê vegotin.Em li şûna xwe pişta xwe bi const eval digirin:
        // a) ZST tune ji ber ku dabeşkirinek ji nû ve bikar anîn û arîtmetîka pointer dê panic hebe b) pîvana pîvana ku ji hêla peymana Alloc ve hewce dike c) hevrastkirinên ku peymana Alloc hewce dike
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // paşve vegerîna pêkanînên gelemperî
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // bikar bînin ji ber ku biceribînin
        // - ew ji bo hin adapterên îterator baştir vektorîze dike
        // - berevajî piraniya rêbazên dûbarebûna hundurîn, ew tenê &mut bixwe digire
        // - ew dihêle ku me nîşana nivîsandinê bi hundurê xwe ve bizeliqîne û di dawiyê de vegerîne
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // dubarekirin bi ser ket, serî netewînin
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // kontrol bikin ka peymana SourceIter bi hişyarî hate pejirandin: ger ew nebin dibe ku em heya vê derê jî nekin
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // peymana InPlaceIterable kontrol bikin.Ev tenê gengaz e ku heke iterator nîşana çavkaniyê li her tiştî pêşve bixe.
        // Heke ew bi rêya TrustedRandomAccess destûdanek neçêkirî bikar bîne wê hingê nîşanderê çavkanî dê di rewşa xweya destpêkê de bimîne û em nikarin wê wekî referans bikar bînin
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // heke nirxên mayî bavêjin li dûvikê çavkaniyê lê pêşî li daketina dabeşkirinê bigire gava ku IntoIter dernekeve heke daket panics wê hingê em ê hêmanên ku di dst_buf de hatine berhev kirin jî bişewitînin
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // peymana InPlaceIterable li vir bi duristî nayê pejirandin ji ber ku try_fold xwedan referansek taybetî ye li ser nîşana jêderkê ya ku em dikarin bikin ev e ku em kontrol bikin ka ew hîn jî di nav rêzê de ye
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}