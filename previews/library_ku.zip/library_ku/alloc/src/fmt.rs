//! Karûbarên ji bo formatkirin û çapkirina `String`.
//!
//! Di vê modulê de piştgiriya rûtînê ya ji bo dirêjkirina hevoksaziya [`format!`] heye.
//! Ev makro di berhevkar de tê pêkanîn da ku bangan li vê modulê biweşîne da ku argumanan di dema dirêjahiyê de li têlan format bike.
//!
//! # Usage
//!
//! Armanca makroya [`format!`] ew e ku ji wanên ku ji fonksiyonên C's `printf`/`fprintf` an jî fonksiyona Python ya `str.format` têne nas be.
//!
//! Hin mînakên dirêjkirina [`format!`] ev in:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" bi sifirên pêşeng
//! ```
//!
//! Ji vana, hûn dibînin ku argumana yekem rêzika formatê ye.Ji hêla berhevkar ve pêdivî ye ku ev têl bireser be;ew nabe ku guhêrbar di nav re derbas bibe (da ku kontrola rastdariyê pêk bîne).
//! Wê hingê berhevkar dê rêza formatê parçe bike û diyar bike ka navnîşa argumanên pêşkêşkirî guncan e ku derbasî vê rêzika formatê bibe.
//!
//! Ji bo ku nirxek yekgirtî veguherînin têlek, rêbaza [`to_string`] bikar bînin.Ev ê formatkirina [`Display`] trait bikar bîne.
//!
//! ## Parametreyên pozîsyonî
//!
//! Her argumana formatkirinê tête destûr kirin ku diyar bike ka kîjan argumana nirxê ew referans e, û heke jê were vebirin wê "the next argument" bête hesibandin.
//! Mînakî, têla formatê `{} {} {}` dê sê pîvanan bigire, û ew ê di heman rêzê de werin dayîn ku werin dayîn.
//! String format `{2} {1} {0}`, dê argumanan bi rêzê berevajî format bike.
//!
//! Gava ku hûn dest bi têkelkirina her du celeb diyarkerên pozîsyonê bikin, tişt dikarin hinekî aloz bibin.Diyarkerê "next argument" dikare wekî iteratorê li ser argumanê were fikirîn.
//! Her ku diyarker "next argument" tê dîtin, iterator pêşve diçe.Ev dibe sedema tevgerek bi vî rengî:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Dema ku `{}` yekem tê dîtin, iteratorê navxweyî yê li ser argumanê nehatiye pêşve xistin, ji ber vê yekê ew argumana yekem çap dike.Dûv re gava gihîşt `{}`-a duyemîn, iterator ber bi nîqaşa duyemîn ve pêşde çû.
//! Ya esasî, parametreyên ku bi zelalî navê argumana xwe didin, bandorê li parametreyên ku navê argumanekê nakin, di warê vebirên helwestê de nakin.
//!
//! Rêzek format pêdivî ye ku hemî argumanên xwe bikar bîne, nebe ku ew xeletiyek-dema berhevkirinê ye.Hûn dikarin di têla formatê de ji yekê zêdetir argûmanê binirxînin.
//!
//! ## Parametreyên bi nav kirin
//!
//! Rust bixwe ne xwediyê hevkêşeyek wek Python-ê ya pîvanên bi navê fonksiyonek e, lê makroya [`format!`] dirêjkirinek hevoksaziyê ye ku dihêle ew parametreyên navdar bi kar bîne.
//! Parametreyên navdar li dawiya lîsteya argumanan têne rêz kirin û hevoksaziya wan heye:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Mînakî, vegotinên [`format!`] yên jêrîn hemî argumanên navdar bikar tînin:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Ne derbasdar e ku meriv li pey argumanên ku navên wan hene, parametreyên helwestê (yên bê nav) bixe.Mîna bi parametreyên pozîsyonî, ne rast e ku meriv parametreyên binavkirî yên ku ji hêla rêzika formatê ve nehatine bikar anîn peyda bike.
//!
//! # Parametreyên Çêkirinê
//!
//! Her argumana ku tê format kirin dikare ji hêla gelek parametreyên formatkirinê ve were veguheztin (ku bi `format_spec` re di [the syntax](#syntax)) re têkildar in. Van parametreyan bandorê li temsîla têl a ku tê format kirin dike.)
//!
//! ## Width
//!
//! ```
//! // Van hemî "Hello x !" çap dikin
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Ev ji bo "minimum width" pîvanek e ku divê format bigire.
//! Heke rêzika nirxê ev gelek tîpan dagir neke, wê hingê padding-a ku ji hêla fill/alignment ve hatî diyarkirin dê were bikar anîn ku cîhê hewce bistîne (li jêr binihêrin).
//!
//! Nirxa ji bo firehiyê dikare wekî [`usize`] di navnîşa pîvanan de bi lêzêdekirina postfix `$` jî were peyda kirin, ev diyar dike ku argumana duyemîn [`usize`] ye ku firehî diyar dike.
//!
//! Meriv bi argûnek dolar re behs dike bandorê li ser x00X-ê nake, ji ber vê yekê bi gelemperî ramanek baş e ku meriv bi helwêstê argumanan bibîne, an jî argumanên bi navkirî bikar bîne.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Karakter û verastkirina vebijarkî bihevra bi parametreya [`width`](#width) re normal tête peyda kirin.Divê ew berî `width`, rast piştî `:` were terîf kirin.
//! Ev diyar dike ku heke nirxa ku tê formatkirin ji `width` piçûktir e, dê hin tîpên din li dora wê werin çap kirin.
//! Dagirtin ji bo rêzkirinên cûda di cûrbecûr ên jêrîn de tê:
//!
//! * `[fill]<` - nîqaş di stûnên `width` de çep-rêzkirî ye
//! * `[fill]^` - arguman di stûnên `width` de navendî ye
//! * `[fill]>` - nîqaş li stûnên `width` rast-rastkirî ye
//!
//! [fill/alignment](#fillalignment)-ya pêşdibistanê ji bo ne-hejmarê cîhek û çep-rêzkirî ye.Default ji bo formatterên hejmarî di heman demê de tîpek valahiyê ye lê bi rast-rastkirinê.
//! Ger ala `0` (li jêr binihêrin) ji bo jimareyê ve hatî diyar kirin, hingê tîpa dagirtî ya nependî `0` ye.
//!
//! Zanibe ku dibe ku rêzkirin ji hêla hin celeban ve neyê pêkanîn.Bi taybetî, ew bi gelemperî ji bo `Debug` trait nayê pêkanîn.
//! Awayek baş ji bo ku pêgirtî were sepandin ev e ku têkevtina xwe format bike, dûv re vê têla ku tê de ye bihurîne da ku derketina xwe bistîne:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Silav Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Van hemî alên ku tevgera formatter diguherînin in.
//!
//! * `+` - Ev ji bo celebên hejmarî tête armanc kirin û diyar dike ku divê nîşan her dem were çap kirin.Nîşaneyên erênî ji hêla default ve qet nayên çap kirin, û nîşana neyînî tenê ji hêla `Signed` trait ve ji hêla default ve tête çap kirin.
//! Ev al nîşan dike ku divê nîşana rast (`+` an `-`) her gav were çap kirin.
//! * `-` - Naha nayê bikar anîn
//! * `#` - Ev al nîşan dike ku divê forma çapkirinê "alternate" were bikar anîn.Formên alternatîf ev in:
//!     * `#?` - formatkirina [`Debug`] xweş-çap bike
//!     * `#x` - pêşî li argumana bi `0x` digire
//!     * `#X` - pêşî li argumana bi `0x` digire
//!     * `#b` - pêşî li argumana bi `0b` digire
//!     * `#o` - pêşî li argumana bi `0o` digire
//! * `0` - Ev tê bikar anîn ku ji bo formatên jimare diyar dike ku pêdivî ye ku bila `width` hem bi karakterê `0` were çêkirin û hem jî nîşana wê hebe.
//! Formatek mîna `{:08}` dê `00000001` ji bo jimara `1` bide, lê heman format dê `-0000001` ji bo jimara `-1` bide.
//! Bala xwe bidinê ku guhertoya negatîf ji guhertoya erênî yek sifir heye.
//!         Bala xwe bidinê ku sifirên pijandinê timî li dû nîşanê (heke hebe) û ber reqeman têne danîn.Dema ku bi ala `#` re bi hev re tê bikar anîn, rêgezek wekhev derbasdar e: sifirên paddankê piştî pêşgir lê li ber reqeman têne danîn.
//!         Pêşgir di nav firehiya tevahî de ye.
//!
//! ## Precision
//!
//! Ji bo celebên ne-hejmarî, ev dikare wekî "maximum width" were hesibandin.
//! Heke rêzika encam ji vê firehiyê dirêjtir e, wê hingê ew li ber vê gelek tîpan tê qutkirin û heke ew parametre werin danîn ew nirxa kurtkirî bi `fill`, `alignment` û `width` guncan re tê şandin.
//!
//! Ji bo celebên entegre, ev nayê paşguh kirin.
//!
//! Ji bo celebên xal-not, ev diyar dike ka divê çend reqemên piştî xala dehanî werin çap kirin.
//!
//! Sê awayên gengaz hene ku `precision`-ya xwestin diyar bikin:
//!
//! 1. Hejmarek `.N`:
//!
//!    yekser `N` bixwe teqez e.
//!
//! 2. Hejmarek an navek li pey wê nîşana dolar `.N$` tê:
//!
//!    format *arguman*`N` (ku divê `usize` be) wekî rastîn bikar bînin.
//!
//! 3. Asterisk `.*`:
//!
//!    `.*` tê vê wateyê ku ev `{...}` ji yekê pê ve bi *du* ketanên formatê re têkildar e: yekem ketina rastîniya `usize` digire, û ya duyem jî nirxa çapê digire.
//!    Bala xwe bidinê ku di vê rewşê de, heke yek rêzika formatê `{<arg>:<spec>.*}` bikar bîne, wê hingê beşa `<arg>` ji* çapkirinê *re qala* nirxê dike, û divê `precision` di têketina pêşiya `<arg>` de were.
//!
//! Mînakî, bangên jêrîn hemî heman tiştî `Hello x is 0.01000` çap dikin:
//!
//! ```
//! // Silav {arg 0 ("x")} {arg 1 (0.01) with precision specified inline (5)} e
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Silav {arg 1 ("x")} {arg 2 (0.01) with precision specified in arg 0 (5)} e
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Silav {arg 0 ("x")} {arg 2 (0.01) with precision specified in arg 1 (5)} e
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Silav {next arg ("x")} {second of next two args (0.01) with precision specified in first of next two args (5)} e
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Silav {next arg ("x")} {arg 2 (0.01) with precision specified in its predecessor (5)} e
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Silav {next arg ("x")} {arg "number" (0.01) with precision specified in arg "prec" (5)} e
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Dema ku ev:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! sê tiştên girîng ên cuda çap bikin:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Di hin zimanên bernamekirinê de, reftara fonksiyonên teşekirina stringê bi mîhengê herêmî yê pergala xebatê ve girêdayî ye.
//! Fonksiyonên formatê yên ku ji hêla pirtûkxaneya standard a Rust ve hatine peyda kirin, têgihiştinek wan a locale nîne û dê bêyî veavakirina bikarhêner li ser hemî pergalê heman encam derxînin.
//!
//! Mînakî, koda jêrîn dê hertim `1.5` çap bike her çend ku lokaliya pergalê ji bilî xalekê veqetandekek dehanî bikar bîne.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Karakterên xwerû `{` û `}` dibe ku di rêzê de cih bigirin ku pêşî li wan bi heman tîpî bigirin.Mînakî, karektera `{` bi `{{` û karektera `}` bi `}}` direve.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Ku bi kurtahî, li vir hûn dikarin rêzimana tevahî ya rêzikên formatê bibînin.
//! Hevoksaziya ji bo zimanê formatkirinê tê bikar anîn ji zimanên din tê kişandin, ji ber vê yekê divê ew pir biyanî nebe.Arguman bi hevoksaziya mîna Python têne format kirin, wateya ku arguman li şûna C-mîna `%` bi `{}` hatine dorpêç kirin.
//! Rêzimana rastîn a ji bo hevoksaziya formatkirinê ev e:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Di rêzimana jorîn de, dibe ku `text` tîpên `'{'` an `'}'` tune.
//!
//! # Formatkirina traits
//!
//! Gava ku hûn daxwaz dikin ku argûmanek bi celebek taybetî re were format kirin, hûn bi rastî daxwaz dikin ku argumanek ji trait-a taybetî re vebêje.
//! Ev dihêle ku gelek celebên rastîn bi `{:x}` (wekî [`i8`] û her weha [`isize`]) werin format kirin.Nexşeya heyî ya celebên li traits ev e:
//!
//! * *tiştek* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` 00 [`Debug`] bi jimareyên hexadecimalî yên piçûktir
//! * `X?` 00 [`Debug`] bi jimareyên hexadecimalî yên jorîn
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Wateya vê ev e ku her celeb argumana ku [`fmt::Binary`][`Binary`] trait bicîh tîne dikare piştre bi `{:b}` were format kirin.Ji bo van traits pêkanîn ji hêla pirtûkxaneya standard ve jî ji bo gelek celebên prîmîtîf têne peyda kirin.
//!
//! Heke formatek neyê diyar kirin (wekî di `{}` an `{:6}` de), wê hingê formata trait ya hatî bikar anîn [`Display`] trait ye.
//!
//! Dema ku ji bo celebê xwe formatek trait bicîh dikin, hûn ê hewce bibin ku rêbazek îmzeyê bicîh bikin:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // celebek xwerû ya me
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Dê celebê we wekî `self` ji hêla referansê ve were derbas kirin, û wê hingê pêdivî ye ku fonksiyon di nav devera `f.buf` de derket.Li gorî pêkanîna her formatê trait ye ku bi rêk û pêk pabendî parametreyên teşekirina xwestin bibe.
//! Nirxên van pîvanan dê di zeviyên [`Formatter`] struct de werin rêz kirin.Ji bo ku bi viya re bibe alîkar, [`Formatter`] struktur hin rêbazên alîkar jî peyda dike.
//!
//! Wekî din, nirxa vegera vê fonksiyonê [`fmt::Result`] e ku navnîşek celebek e ["Encam"] "<()," ["std: : fmt::Çewtî"] ">".
//! Pêkanînên formatkirinê divê piştrast bikin ku ew xeletiyên ji [`Formatter`] belav dikin (mînakî, dema ku gazî [`write!`] dikin).
//! Lêbelê, divê ew tu carî xeletiyan bi derewan vegerînin.
//! Ango, ger [`Formatter`]-ê derbasbûyî xeletiyekê vegerîne divê û tenê dibe ku çewtiyek vegerîne.
//! Ji ber ku, berevajî ya ku îmzeya fonksiyonê dikare pêşniyar bike, teşekirina string operasyonek bêkêmasî ye.
//! Ev fonksiyon tenê encamek vedigire ji ber ku nivîsandina ji bo herika bingehîn dibe ku têk biçe û divê ew awayek belav bike ku rastiyek çewtiyek çêbûye paşiya pelê.
//!
//! Mînakek pêkanîna formatkirina traits dê weha be:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Nirxa `f` `Write` trait bicîh dike, ya ku çi dinivîse!makro hêvî dike.
//!         // Bala xwe bidinê ku ev formatkirin alên cihêreng ên ji bo formatkirina têlan têne paşguh kirin, paşguh nake.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // traits-yên cihêreng rê dide awayên cûda yên derketina celebek.
//! // Wateya vê formatê çapkirina mezinahiya vector ye.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Ji alayên formatkirinê re rêza xwe bigirin û bi karanîna rêbaza alîkarê `pad_integral` ya li ser objeya Formatter.
//!         // Ji bo hûrguliyan belgekirina rêbazê bibînin, û fonksiyona `pad` dikare were bikar anîn da ku têlan dagirin.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Armancên van du traits yên formatkirinê hene:
//!
//! - [`fmt::Display`][`Display`] sepandinan destnîşan dikin ku celeb dikare bi dilsozî wekî xelekek UTF-8 her dem were temsîl kirin.Ew **nayê** hêvî kirin ku her celeb [`Display`] trait bicîh bikin.
//! - [`fmt::Debug`][`Debug`] pêkanîn divê ji bo **hemî** celebên gelemperî werin pêkanîn.
//!   Hilberîn dê bi gelemperî dewleta navxweyî bi qasî ku pêkan be bi temsîlî temsîl dike.
//!   Armanca [`Debug`] trait hêsankirina verastkirina kodê Rust ye.Di pir rewşan de, karanîna `#[derive(Debug)]` bes e û tête pêşniyar kirin.
//!
//! Hin nimûneyên derketina ji herdu traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Makroyên têkildar
//!
//! Di malbata [`format!`] de çend makroyên têkildar hene.Yên ku niha têne sepandin ev in:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Ev û [`writeln!`] du makro ne ku têne bikar anîn ku têla formatê li herikek diyarkirî belav dikin.Ev tê bikar anîn ku pêşî li veqetandinên navîn ên têlên formatê bigire û li şûna wê rasterast derketinê binivîse.
//! Di bin kulikê de, ev fonksiyon bi rastî fonksiyona [`write_fmt`] ya ku li ser [`std::io::Write`] trait hatî diyarkirin bang dike.
//! Bikaranîna mînak ev e:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Ev û [`println!`] derketina xwe ji stdout re diweşînin.Bi heman rengî makroya [`write!`], armanca van makroyan ew e ku dema derketina çapê ji veqetandinên navîn dûr bixin.Bikaranîna mînak ev e:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Makroyên [`eprint!`] û [`eprintln!`] bi [`print!`] û [`println!`] re yek in, ji bilî ku ew derketina xwe derdixin stderr.
//!
//! ### `format_args!`
//!
//! Ev makroyek meraqdar e ku tê de bi ewlehî li dora nesneyek şefaf ku têl formatê vedibêje derbas dibe.Vê tiştê ku hewce ne hewceyê veqetandinên heapê ye ku çêbike, û ew tenê referansa agahdariya li ser stackê dike.
//! Di bin dorpêçê de, hemî makroyên pêwendîdar di warê vê de têne bicîh kirin.
//! Ya yekem, karanîna hin mînak e:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Encama makroya [`format_args!`] nirxek celebê [`fmt::Arguments`] ye.
//! Dûv re ev avahî dikare ji fonksiyonên [`write`] û [`format`] re di hundurê vê modulê de were derbas kirin da ku rêzika formatê pêvajoyê bike.
//! Armanca vê makroyê ew e ku hêj bêtir pêşî li veqetandinên navbirî digire dema ku bi têlên formatkirinê re mijûl dibe.
//!
//! Mînakî, pirtûkxaneyek têketinê dikare hevoksaziya formatkirinê ya standard bikar bîne, lê ew ê hundurîn li dora vê sazûmanê derbas bibe heya ku ew neyê diyar kirin ku derûve divê biçe.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Fonksiyona `format` avahiyek [`Arguments`] digire û têla formatkirî ya encam vedigerîne.
///
///
/// Mînaka [`Arguments`] dikare bi makroya [`format_args!`] were afirandin.
///
/// # Examples
///
/// Bikaranîna bingehîn:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Ji kerema xwe not bikin ku karanîna [`format!`] çêtir e.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}