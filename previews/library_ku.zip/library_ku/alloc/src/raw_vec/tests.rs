use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Nivîsandina ceribandinek entegrasyonê di navbera dabeşkerên partiya sêyemîn û `RawVec` de hebkî zehf e ji ber ku `RawVec` API rêbazên dabeşkirina xelet eşkere nake, ji ber vê yekê em nekarin çi biqewime dema ku dabeşker xilas dibe (ji derveyî destnîşankirina panic).
    //
    //
    // Di şûna wê de, ev tenê kontrol dike ku rêbazên `RawVec` dema ku ew hilanînê vedihewîne bi kêmasî di Allocator API re derbas dibin.
    //
    //
    //
    //
    //

    // Dabeşkerekî lal ku mîqyasek sabit a sotemeniyê dixwe berî ku hewldanên veqetandinê dest pê bike têk diçe.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (dibe sedema reallokek, bi vî rengî 50 + 150=200 yekeyên sotemenî bikar tîne)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Ya yekem, `reserve` mîna `reserve_exact` veqetîne.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 ji du qatan 7 e, ji ber vê yekê divê `reserve` mîna `reserve_exact` bixebite.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 ji nîvê 12 kêmtir e, ji ber vê yekê divê `reserve` bi rengek mezin mezin bibe.
        // Di dema nivîsînê de ev test faktorê mezinbûnê 2 ye, ji ber vê yekê kapasîteya nû 24 e, lêbelê, faktorê mezinbûna 1.5 jî baş e.
        //
        // Ji ber vê yekê `>= 18` di daxuyaniyê de.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}