#![stable(feature = "rust1", since = "1.0.0")]

//! Nîşaneyên jimartina referansê yên ewle.
//!
//! Ji bo bêtir agahdarî li belgekirina [`Arc<T>`][Arc] binêrin.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Sînorek nerm li ser mîqyasa referansan ku dibe ku li ser `Arc` were çêkirin.
///
/// Ku li jor vê sînorê biçin dê bernameya we (her çend ne hewce be jî) li ser _exactly_ `MAX_REFCOUNT + 1` referansan betal bike.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer têlên bîranînê piştgirî nake.
// Ji bo ku di Arc/Pêkanîna lawaz de raporên erênî yên derewîn dûr nekevin şûna wê ji bo hevdemkirinê barên atomê bikar bînin.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Nîşanek hejmartina referansa-ewle ya têl.'Arc' tê wateya 'Atomîkî Reference Counted'.
///
/// Tîpa `Arc<T>` xwedan xwedan parvekirinek nirxa celebê `T`, ku di komikê de hatî veqetandin peyda dike.Bi vexwendina [`clone`][clone] li ser `Arc` mînakek nû ya `Arc` çêdibe, ku heman veqetandina li ser heapê wekî çavkaniya `Arc` nîşan dide, dema ku hejmarek referans zêde dike.
/// Gava ku nîşanderê `Arc`-ê ya paşîn li dabeşkirinek diyarkirî were rûxandin, nirxa ku di wê veqetandinê de hatî hilanîn (ku pir caran wekî "inner value" tête binavkirin) jî tê avêtin.
///
/// Çavkaniyên hevpar ên di Rust de mutasyonê ji hêla default ve nahêlin, û `Arc` ne veqetandek e: hûn nekarin bi gelemperî referansa guhêrbar a tiştek di hundurê `Arc` de bigirin.Heke hûn hewce ne ku bi `Arc` veguherînin, [`Mutex`][mutex], [`RwLock`][rwlock], an yek ji celebên [`Atomic`][atomic] bikar bînin.
///
/// ## Ewlekariya Mijarê
///
/// Berevajî [`Rc<T>`], `Arc<T>` ji bo jimartina referansa xwe karûbarên atomî bikar tîne.Ev tê vê wateyê ku ew bi têl-ewled e.Dezavantaj ev e ku operasyonên atomê ji gihiştinên bîrdariya adetî bihatir in.Heke hûn veqetandinên ku wekî referans hatine jimartin di navbera mijaran de parve nakin, ji bo serê jêrîn [`Rc<T>`] bikar bînin.
/// [`Rc<T>`] default ewle ye, ji ber ku berhevkar dê her hewildanek bişîne ku [`Rc<T>`] di navbera têlan de bişîne.
/// Lêbelê, pirtûkxaneyek dikare `Arc<T>` hilbijêre da ku ji bo xerîdarên pirtûkxaneyê nermbûnek zêdetir bide.
///
/// `Arc<T>` heya ku `T` [`Send`] û [`Sync`] bicîh tîne dê [`Send`] û [`Sync`] bicîh bîne.
/// Çima hûn nikarin celebek `T` ya ne-têl-ewle têxin nav `Arc<T>`-ê da ku ew bibe têl-ewled?Dibe ku ev di destpêkê de hinekî dij-bînbar be: jixwe, ma ne xala ewlehiya têl a `Arc<T>` e?Ya sereke ev e: `Arc<T>` ew xwedan têl ewledar e ku xwedan xwedan piralî ya heman daneyê be, lê ew ewlehiya têlê li daneyên xwe zêde nake.
///
/// `Arc <` ['RefCell bihesibînin<T>`]`> `.
/// [`RefCell<T>`] ne [`Sync`] e, û heke `Arc<T>` her gav [`Send`] bû, `Arc <` [`RefCell<T>`]`>`dê her weha be.
/// Lê hingê wê pirsgirêkek me hebe:
/// [`RefCell<T>`] têl ne ewledar e;ew bi karanîna karûbarên ne-atomî jimara deyn şop dike.
///
/// Di dawiyê de, ev tê vê wateyê ku dibe ku hûn hewce ne ku `Arc<T>` bi hin celebek celebê [`std::sync`], bi gelemperî [`Mutex<T>`][mutex] re bikin cot.
///
/// ## Bi `Weak` re çerxên şikestinê
///
/// Rêbaza [`downgrade`][downgrade] dikare were bikar anîn ku pêvekek ne-xwedî [`Weak`] were afirandin.Nîşanek [`Weak`] dikare [`nûvekirin`][nûvekirin] d bi `Arc` be, lê ev ê [`None`] vegerîne heke nirxa ku di veqetandinê de hatî hilanîn jixwe daket.
/// Bi gotinên din, nîşankerên `Weak` nirxa hundurê veqetandinê zindî nahêlin;lêbelê, ew *dikin* veqetandinê (dikana pişta nirxê) zindî dikin.
///
/// Çerxek di navbên `Arc` de dê carî neyê veqetandin.
/// Ji bo vê sedemê, [`Weak`] ji bo şikandina çerxan tê bikar anîn.Mînakî, darek dikare ji girêkên dêûbavan bigire heya zarokan, û nîşankerên [`Weak`] jî ji zarokan vegerin dêûbavên wan xwedan nîşangirên xurt `Arc`.
///
/// # Çavkaniyên klonîkirin
///
/// Afirandina referansek nû ji nîşanderê referansa-jimartî yê heyî bi karanîna `Clone` trait ya ji bo [`Arc<T>`][Arc] û [`Weak<T>`][Weak] hatî pêkanîn tête kirin.
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Du hevoksazên li jêr wekhev in.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b, û foo hemî Arc in ku heman cîhê bîranînê nîşan dikin
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` bixweber ji `T` (bi navgîniya [`Deref`][deref] trait) ve derebegî têne kirin, ji ber vê yekê hûn dikarin li ser nirxa tîpa `Arc<T>` bangî rêbazên `T` bikin.Ji bo ku bi rêbazên `T`-yê re pevçûn dernekeve, rêbazên `Arc<T>` bixwe fonksiyonên têkildar in, ku bi karanîna [fully qualified syntax] têne gotin:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>Dibe ku ji pêkanînên traits wekî `Clone` re jî hevoksaziyek bi tevahî kalîfîze were gotin.
/// Hin kes tercîh dikin ku hevoksaziya bi tevahî kalîfîze bikar bînin, lê hin jî tercîh dikin ku hevoksaziya rêbaz-bang bikar bînin.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Sentaksa mêtod-bang
/// let arc2 = arc.clone();
/// // Hevoksaziya bi tevahî kalîfîye
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] ji `T`-ê xweber venagerîne, ji ber ku dibe ku nirxa hundurîn berê hatibe avêtin.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Parvekirina hin daneyên neguhêrbar di navbera mijaran de:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Bala xwe bidinê ku em ** van ceribandinan li vir naşopînin.
// Avakirên windows super bextewar dibin heke têlek ji xeleka serekî sax bimîne û dûv re di heman demê de derkeve (xitimandinên tiştek) ji ber vê yekê em tenê vê yekê bi tevahî bi ne meşandina van testan dûr dixin.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Parvekirina [`AtomicUsize`] a mutable:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Ji bo bêtir nimûneyên hejmartina referansan bi gelemperî li [`rc` documentation][rc_examples] binihêrin.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` guhertoyek [`Arc`] e ku referansek ne-xwedî li veqetandina birêvekirî digire.
/// Dabeşandin bi banga [`upgrade`] li ser pêşnumaya `Weak`, ku vedigere ["Vebijêrk"] "<" ["Arc"]<T>> `
///
/// Ji ber ku referansek `Weak` ber bi xwedêbûnê ve nayê hesibandin, ew ê nehêle ku nirxê di veqetandinê de hatî hilanîn were avêtin, û `Weak` bixwe di derbarê nirxa ku hîn jî heye de ti garantî nade.
///
/// Bi vî rengî dibe ku ew [`None`] vegerîne dema ku [`nûvekirin`] d.
/// Lêbelê not bikin ku referansek `Weak`* * nahêle ku dabeşkirina xwe (pargîdaniya piştê) were veqetandin.
///
/// Nîşanek `Weak` bêyî ku pêşî li daketina nirxê hundurê wî bigire, ji bo parastina referansa demkî ya dabeşkirina ku ji hêla [`Arc`] ve tê rêve birin, kêrhatî ye.
/// Di heman demê de ew tê bikar anîn ku pêşî li referansên dorhêl ên di navbera [`Arc`] nîşanekan de bigire, ji ber ku çavkanîyên xwedan hevûdu qet nahêlin ku [`Arc`] were avêtin.
/// Mînakî, dibe ku darek ji girêkên dêûbavan bigire heya zarokan, û nîşankerên `Weak` jî ji zarokan vegerin dêûbavên xwe.
///
/// Awayê tîpîk ji bo peydakirina pêşnumayek `Weak` bangkirina [`Arc::downgrade`] ye.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Ev `NonNull` e ku destûrê dide ku mezinahiya vî rengî li enumê xweşbike, lê ew ne hewce ye ku pêşnumayek derbasdar be.
    //
    // `Weak::new` vê yekê li `usize::MAX` saz dike da ku ne hewce be ku cîhek li ser hepikê veqetîne.
    // Ew ne nirxek e ku pêşnîyarek rastîn dê her hebe, ji ber ku RcBox bi kêmî ve 2 rêzkirî ye.
    // Ev tenê dema `T: Sized` gengaz e;`T` bêserûber qet dangle nabe.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Ev ji repr(C) heya future-delîl e li hember re-rêwerzekirina gengaz a gerdûnî, ku dê bi [into|from]_raw()-an ên ewle celebên hundurîn ên veguherîner re têkeve navberê.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // nirxa usize::MAX ji bo bi demkî "locking" kapasîteya nûvekirina nîşangirên lawaz an dakêşandina hêzdaran wekî sentelek tevdigere;ev tête bikar anîn ku ji pêşbaziyên li `make_mut` û `get_mut` dûr bikeve.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// `Arc<T>`-ya nû çêdike.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Jimareya pointerê qels wekî 1 dest pê bikin ku ew pointer qels e ku ji hêla hemî nîşangirên xurt (kinda) ve tê girtin, ji bo bêtir agahdariyê li std/rc.rs binihêrin
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// `Arc<T>`-ya nû bi karanîna referansek lawaz ji xwe re çêdike.
    /// Hewldana nûvekirina referansa qels berî ku ev fonksiyon vegere dê di nirxek `None` de encam bide.
    /// Lêbelê, referansa qels dikare bi serbestî were klon kirin û ji bo demek paşê were bikar anîn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Di dewleta "uninitialized" de hundurîn bi referansek tenê qels ava bikin.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Girîng e ku em dev ji xwedîtîya pointerê qels bernedin, an na dema ku `data_fn` vedigere dibe ku bîranîn azad bibe.
        // Heke em bi rastî dixwestin xwedaniyê derbas bikin, me dikarî pêşnumayek qels a pêvek ji xwe re çêbikin, lê ev ê di encamên nûvekirina hejmarê referansa qels de encam bide ku dibe ku nebe ku ne hewce be.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Naha em dikarin hêjahiya hundurîn bi rêkûpêk bidin destpêkirin û referansa xweya qels veguherînin referansek xurt.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Ya jorîn ji qada daneyê re nivîsandî divê ji her têlên ku hejmarek xurt a ne-sifir dibînin re xuya bibe.
            // Ji ber vê yekê ji me re herî kêm rêzkirina "Release" hewce dike ku em bi `compare_exchange_weak` re di `Weak::upgrade` de hevdem bikin.
            //
            // "Acquire" ferman ne hewce ye.
            // Dema ku em tevgerên gengaz ên `data_fn` dihesibînin, em tenê hewce ne ku binihêrin ka ew dikare bi referansa `Weak` ya ku nayê nûvekirin re çi bike:
            //
            // - Ew dikare * `Weak` klon bike, hejmarek referansa qels zêde bike.
            // - Ew dikare wan klonan biavêje, jimara referansa lawaz kêm bibe (lê qet nebe sifir).
            //
            // Van bandorên neyînî bi ti awayî bandor li me nakin, û ne tenê bandekên din bi tenê bi kodek ewle mimkun e.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Pêdivî ye ku referansên bihêz bi hev re xwediyê referansek qels a hevpar bin, ji ber vê yekê hilweşînerê ji bo referansa meya kevn a lawaz nexebitînin.
        //
        mem::forget(weak);
        strong
    }

    /// `Arc`-ya nû bi naverokên nezanî saz dike.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Destpêkirina taloqkirî:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Bi bîranîna ku bi `0` byte tê dagirtin `Arc` nû bi naverokên nezanî saz dike.
    ///
    ///
    /// Ji bo nimûneyên karanîna rast û çewt a vê rêbazê li [`MaybeUninit::zeroed`][zeroed] binêrin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// `Pin<Arc<T>>`-ya nû çêdike.
    /// Ger `T` `Unpin` bicîh neyne, wê hingê `data` dê di bîra xwe de pîne bibe û nekaribe were bar kirin.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// `Arc<T>` nû çêdike, ger veqetandin têk diçe xeletiyekê vedigire.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Jimareya pointerê qels wekî 1 dest pê bikin ku ew pointer qels e ku ji hêla hemî nîşangirên xurt (kinda) ve tê girtin, ji bo bêtir agahdariyê li std/rc.rs binihêrin
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// `Arc`-ya nû bi naverokên uninitialized ava dike, heke veqetandin têk çû xeletiyek vedigerîne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Destpêkirina taloqkirî:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// `Arc`-ya nû bi naverokên nezanî saz dike, digel ku bîranîn bi `0` byte tijî ye, ger veqetandin têk bibe xeletiyek vedigerîne.
    ///
    ///
    /// Ji bo nimûneyên karanîna rast û çewt a vê rêbazê li [`MaybeUninit::zeroed`][zeroed] binêrin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Nirxa hundurîn vedigerîne, heke `Arc` bi rastî yek referansek xurt hebe.
    ///
    /// Wekî din, [`Err`] bi heman `Arc` ve hatî vegerandin.
    ///
    ///
    /// Ger referansên qels ên berbiçav hebin jî ev dê bi ser bikeve.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Nîşanek qels çêbikin ku referansa bihêz-qels a nepenî paqij bike
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Bi naverokên uninitialized perçek nû-atomîkî ya referans-jimartî ava dike.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Destpêkirina taloqkirî:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Bi naveroka uninitialized re, bi bîranîna ku bi `0` byte tê dagirtin, perçek nû-atomîkî ya referans-jimartî ava dike.
    ///
    ///
    /// Ji bo nimûneyên karanîna rast û çewt a vê rêbazê li [`MaybeUninit::zeroed`][zeroed] binêrin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// `Arc<T>` vedigire.
    ///
    /// # Safety
    ///
    /// Çawa ku bi [`MaybeUninit::assume_init`] re, ew bangker e ku garantî bike ku nirxa hundirîn bi rastî di rewşek destpêkirî de ye.
    ///
    /// Bangkirina viya dema ku naverok hîn bi tevahî neyê destpêkirin dibe sedema tevgera tavilê nediyarkirî.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Destpêkirina taloqkirî:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// `Arc<[T]>` vedigire.
    ///
    /// # Safety
    ///
    /// Çawa ku bi [`MaybeUninit::assume_init`] re, ew bangker e ku garantî bike ku nirxa hundirîn bi rastî di rewşek destpêkirî de ye.
    ///
    /// Bangkirina viya dema ku naverok hîn bi tevahî neyê destpêkirin dibe sedema tevgera tavilê nediyarkirî.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Destpêkirina taloqkirî:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// `Arc` dixwe, nîşana pêçayî vedigerîne.
    ///
    /// Ji bo ku ji leza bîranînê dernekeve divê nîşander bi karanîna [`Arc::from_raw`] vegere `Arc`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Nîşanek raweya daneyê peyda dike.
    ///
    /// Hejmartin bi rengek bandor nabin û `Arc` nayê xerckirin.
    /// Nîşanek heya ku hejmartinên xurt li `Arc` hebin derbasdar e.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // EWLEH: Ev ji Deref::deref an RcBoxPtr::inner derbas nabe lewra
        // ev pêdivî ye ku pêgirtiya raw/mut bimîne wusa ku mînak
        // `get_mut` piştî ku Rc bi `from_raw` vegeriya dikare bi navgînvanê binivîse.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// `Arc<T>` ji pêşnumayek rawe çêdike.
    ///
    /// Pêdivî ye ku pêşnumaya rawe berê bi bangek li [`Arc<U>::into_raw`][into_raw] hatibe vegerandin ku divê `U` xwedan eynî pîvan û rêzkirinê be wekî `T`.
    /// Ger `U` `T` be ev bi rastî rast e.
    /// Zanibe ku heke `U` ne `T` be lê xwedan heman pîvan û rêzkirinê be, ev di bingeh de mîna veguheztina referansên celebên cûda ye.
    /// Ji bo bêtir agahdarî li ser kîjan astengî di vê rewşê de derbas dibin [`mem::transmute`][transmute] bibînin.
    ///
    /// Bikarhênerê `from_raw` neçar e ku nirxek taybetî ya `T` tenê carekê bavêje.
    ///
    /// Ev fonksiyon ne ewle ye ji ber ku karanîna nerast dikare bibe sedema bêewlehîtiya bîranînê, her çend `Arc<T>` vegeriyayî qet neyê dîtin.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Vegere `Arc`-ê veguherîne ku ji ber derketinê nehêle.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Dê bêtir bangên `Arc::from_raw(x_ptr)`-ê bîranîn-ewledar bin.
    /// }
    ///
    /// // Dema ku `x` ji jor derket qada bîranînê hate azad kirin, ji ber vê yekê `x_ptr` nuha daleqandî ye!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Berevajî berevajî bikin ku bibînin ArcInner-ya orjînal.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Ji bo vê dabeşkirinê pêşnumayek nû [`Weak`] diafirîne.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Ev Relaxed baş e ji ber ku em nirxa li CAS a jêrîn kontrol dikin.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // kontrol bikin ka counter qels niha "locked" e;heke wusa be, bizivirin.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: ev kod niha îhtîmala zêdebûnê paşguh dike
            // nav usize::MAX;bi gelemperî hem Rc û hem Arc hewce ne ku werin sererast kirin ku bi zêdehiyê re mijûl bibin.
            //

            // Berevajî Clone(), ji me re pêdivî ye ku ev Xwendinek Acquire be ku ji bo nivîsandina ji `is_unique` were hevdemkirin, da ku bûyerên berî wê nivîsandinê berî vê xwendinê pêk werin.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Bawer bikin ku em Qelsiyek dangling neafirînin
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Ji bo vê veqetandinê hejmara nîşankerên [`Weak`] digire.
    ///
    /// # Safety
    ///
    /// Ev rêbaz bixwe ewledar e, lê rast bikar anîna wê lênihêrîna zêde hewce dike.
    /// Mijarek din dikare di her demê de jimara lawaz biguherîne, di nav de bi potansiyelî di navbera bangkirina vê rêbazê û tevgerîna li ser encam.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Ev îddîa diyarker e ji ber ku me `Arc` an `Weak` di navbera têlan de parve nekiriye.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Ger hejmartina lawaz aniha qefilandî be, hêjaya hejmartinê berî girtina qeflê 0 bû.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Ji bo vê veqetandinê hejmara pêşekên xurt (`Arc`) digire.
    ///
    /// # Safety
    ///
    /// Ev rêbaz bixwe ewledar e, lê rast bikar anîna wê lênihêrîna zêde hewce dike.
    /// Mijarek din dikare di her demê de hejmartina bihêz biguherîne, di nav de bi potansiyelî navbera banga vê rêbazê û tevgerîna li ser encamê.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Ev îddîa diyarker e ji ber ku me `Arc` di navbera têlan de parve nekiriye.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Hejmara referansa bihêz a li ser `Arc<T>` bi têkildarê pêşkêşî ve girêdayî yek zêde dike.
    ///
    /// # Safety
    ///
    /// Pêdivî ye ku nîşander bi `Arc::into_raw` hatibe stendin, û nimûneya `Arc` ya têkildar divê derbasdar be (ango
    /// hejmartina bihêz divê ji bo domandina vê rêbazê herî kêm 1) be.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Ev îddîa diyarker e ji ber ku me `Arc` di navbera têlan de parve nekiriye.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Arc diparêze, lê bi pêvekirina ManualDrop ve hesabê xwe nedin jimartinê
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Naha hejmartina zêde bikin, lê hesabê nû jî nekin
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Qewirandina hejmartina referansa bihêz a li ser `Arc<T>` bi têkildarê pêşnumayê ve girêdayî ye.
    ///
    /// # Safety
    ///
    /// Pêdivî ye ku nîşander bi `Arc::into_raw` hatibe stendin, û nimûneya `Arc` ya têkildar divê derbasdar be (ango
    /// dema bihîstina vê rêbazê divê hijmara bihêz herî kêm 1 be).
    /// Ev rêbaza hanê dikare were bikar anîn ku `Arc`-ya paşîn û depoya paşîn serbest were berdan, lê **ne hewce ye** piştî ku `Arc`-ya dawî serbest hat berdan bang lê were kirin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Ew vebawer diyarker in ji ber ku me `Arc` di navbera têlan de parve nekiriye.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Vê bêewlehî baş e ji ber ku dema ku ev kevan zindî ye em garantî dibin ku nîşanderê hundurîn derbasdar e.
        // Wekî din, em dizanin ku avahiya `ArcInner` bi xwe `Sync` e ji ber ku daneya hundurîn jî `Sync` e, ji ber vê yekê em baş in ku ji van naverokan re pointerek neguhêrbar deyn dikin.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Beşek ne-xêzkirî ya `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Di vê demê de daneyê hilweşînin, her çend dibe ku em ji xwe dabeşkirina qutiyê azad nekin (dibe ku hîn jî nîşanên qels li dora derewan hebin).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Refa qels bavêjin hev û di nav hemî referansên xurt de girtin
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// `true` vedigerîne heke her du `Arc` xalek li ser dabeşkirinê yek bikin (bi rengek dişibe [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// `ArcInner<T>`-ê bi cîhê bes ji bo nirxê hundurîn ê dibe-ne-mezinkirî veqetîne li cihê ku di nirxê de pêşnumayek peydakirî veqetîne.
    ///
    /// Fonksiyona `mem_to_arcinner` bi nîşangirê daneyê tê vexwendin û divê ji bo `ArcInner<T>` vegerekê (potansiyelî qelew) vegerîne.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Dabeşandina nirxa dayînê bi karanîna nirxê dayînê hesab bikin.
        // Berê, teşe li ser vegotina `&*(ptr as* const ArcInner<T>)` dihat hesibandin, lê vê yekê referansek bêserûber çêkir (li #54908 binihêre).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// `ArcInner<T>`-ê bi cîhê bes ji bo nirxê hundurîn ê dibe-ne-mezinkirî veqetandî dike ku nirxa wê pêşnumayê pêşkêşkirî ye, ger veqetandin têk biçe xeletiyek vedigerîne.
    ///
    ///
    /// Fonksiyona `mem_to_arcinner` bi nîşangirê daneyê tê vexwendin û divê ji bo `ArcInner<T>` vegerekê (potansiyelî qelew) vegerîne.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Dabeşandina nirxa dayînê bi karanîna nirxê dayînê hesab bikin.
        // Berê, teşe li ser vegotina `&*(ptr as* const ArcInner<T>)` dihat hesibandin, lê vê yekê referansek bêserûber çêkir (li #54908 binihêre).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // ArcInner destpê bikin
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Ji bo nirxek hundurîn a nevekirî `ArcInner<T>` bi cîhê bes veqetîne.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Ji bo `ArcInner<T>` bi karanîna nirxê veqetandî veqetînin.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Nirxê wekî byte kopî bikin
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Bêyî ku naveroka wê bavêjin dabeşkirinê azad bikin
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// `ArcInner<[T]>` bi dirêjahiya dayîn veqetîne.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Hêmanên ji perçê li Arc-a nû veqetandî kopî bikin <\[T\]>
    ///
    /// Ne ewle ye ji ber ku bangker an divê xwediyê xwe be an `T: Copy` girêbide.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Ji iteratorê ku ji mezinahiyek diyar e `Arc<[T]>` çêdike.
    ///
    /// Tevger nayê diyarkirin divê mezinahî çewt be.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Dema ku hêmanên T klon dike Panic diparêze.
        // Di bûyera panic de, hêmanên ku di ArcInner-a nû de hatine nivîsandin dê werin avêtin, paşê bîranîn azad bibe.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Nîşaneyê hêmana yekem
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Hemî zelal.Cerdevan ji bîr bikin da ku ew ArcInner-a nû azad neke.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specialization trait ku ji bo `From<&[T]>` tê bikar anîn.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Klonek nîşanderê `Arc` çêdike.
    ///
    /// Ev pointerek din a ji bo heman veqetandinê diafirîne, hejmara referansa bihêz zêde dike.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Bikaranîna rêzkirinek rehet li vir baş e, lewra ku zanîna referansa orjînal nahêle têlên din bi xeletî tiştê jêbirin.
        //
        // Wekî ku di [Boost documentation][1] de hatî şirove kirin, Zêdekirina jimareya referansê her gav dikare bi bîranîn_order_relaxed re bête kirin: Çavkanîyên nû yên li ser tiştikê tenê ji referansek heyî çêdibe, û derbaskirina referansek heyî ji yek têl derbasî ya din dibe ku jixwe pêdivî ye ku hevdemkirina pêdivî hebe.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Lêbelê pêdivî ye ku em li hember hejmartinên girseyî xwe biparêzin di rewşa ku kesek Arkan ji bîr dike û ji bîr dike.
        // Heke em vê nekin jimartin dikare zêde bibe û bikarhêner dê-piştî belaş bikar bînin.
        // Em bi nijadî bi `isize::MAX` têr dibin li ser wê ferqê ku ne mîlyar ~2 têl hene ku bi carekê hejmartina referansê zêde dikin.
        //
        // Ev branch dê tu carî di bernameyek realîst de neyê girtin.
        //
        // Em kurtaj dikin ji ber ku bernameyek wusa bêhempa dejenere ye, û xema me nîne ku em piştgiriyê lê bikin.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Di nav `Arc` ya hatî dayîn de referansek guherbar çêdike.
    ///
    /// Heke `Arc` an [`Weak`] nîşanên din li ser veqetandinê hebin, wê hingê `make_mut` dabeşkirinek nû biafirîne û [`clone`][clone] li nirxa hundurîn vexwendin da ku xwedaniya yekta misoger bike.
    /// Ev wekî klon-li-nivîsandinê jî tête binav kirin.
    ///
    /// Bala xwe bidinê ku ev ji tevgera [`Rc::make_mut`] ya ku nîşanderên mayî `Weak` veqetîne ji hev cûda dike.
    ///
    /// Her weha [`get_mut`][get_mut] binihêrin, ku dê bêtir ji klonkirinê têk biçe.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Dê tiştek klon neke
    /// let mut other_data = Arc::clone(&data); // Dê daneyên hundurîn klon nekin
    /// *Arc::make_mut(&mut data) += 1;         // Daneyên hundurîn klon dike
    /// *Arc::make_mut(&mut data) += 1;         // Dê tiştek klon neke
    /// *Arc::make_mut(&mut other_data) *= 2;   // Dê tiştek klon neke
    ///
    /// // Naha `data` û `other_data` veqetandinên cihêreng nîşan dikin.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Bala xwe bidinê ku em hem referansek xurt û hem jî referansek lawaz digirin.
        // Ji ber vê yekê, serbestberdana referansa meya bihêz tenê dê nebe, bi tena serê xwe nabe sedem ku bîr were veqetandin.
        //
        // Acquire bikar bînin da ku pêbawer bin ku em dibînin ku ji `weak` re nivîsên ku berî derketinê (ango kêmkirinan) li `strong` dinivîsin çêdibin.
        // Ji ber ku me hejmarek qels girtiye, çu şans tune ku ArcInner bixwe were veqetandin.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Pêşniyarek din a bihêz heye, ji ber vê yekê divê em klon bikin.
            // Berî bîranînê veqetînin da ku hûn rasterast nirxa klonkirî binivîsin.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Di yên jorîn de Relaxed têr dike ji ber ku ev di bingeh de optimîzasyonek e: em her dem bi nîşanên qels têne avêtin pêşbaz dibin.
            // Rewşa xirabtirîn, em di dawîyê de Arcek nû bêyî hewceyî veqetandin.
            //

            // Me refa dawîn a bihêz rakir, lê refên qels ên din jî mane.
            // Em ê naverokan veguherînin Arcek nû, û refên qels ên din jî betal bikin.
            //

            // Têbînî ku ji bo xwendina `weak` ne mimkûn e ku usize::MAX bide (ango, girtî ye), ji ber ku hejmartina qels tenê ji hêla têlekek bi referansek bihêz ve tê girtin.
            //
            //

            // Xwerûya xwerû ya qels a xweya berbiçav bikin, da ku ew hewceyê ArcInner paqij bike.
            //
            let _weak = Weak { ptr: this.ptr };

            // Tenê dikare danezanan bidize, ya ku maye Qelsî ye
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Em ji her celebî re referansa tenê bûn;dîsa vegerin jimartina refa bihêz.
            //
            this.inner().strong.store(1, Release);
        }

        // Wekî `get_mut()`, neewlehî baş e ji ber ku referansa me an destpêkek yekta bû, an jî li ser klonkirina naverokê bû yek.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Heke ji bo dabeşkirina heman `Arc` an [`Weak`] nîşanên din tune, referansa guhêrbar vedigerîne nav `Arc` ya hatî dayîn.
    ///
    ///
    /// Wekî din [`None`] vedigerîne, ji ber ku ew ne ewle ye ku nirxek parvekirî mutate bike.
    ///
    /// [`make_mut`][make_mut] jî binihêrin, ku gava nîşankerên din hebin dê nirxa hundirîn [`clone`][clone] bike.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Ev bêewlehî baş e, çimkî em garantî ne ku pêvek vegeriyaye nîşana *tenê* ye ku dê carî vegere T.
            // Hejmara referansa me di vê nuqteyê de mîsogerkirî ye ku 1 be, û me hewce kir ku Arc bi xwe `mut` be, ji ber vê yekê em vegera tenê referansa gengaz a daneyên hundurîn dikin.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Bêyî ku kontrol bike, referansa guhêrbar vedigerîne nav `Arc` ya hatî dayîn.
    ///
    /// [`get_mut`] jî bibînin, ku ewledar e û kontrolên guncan dike.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Pêdivî ye ku nîşangirên `Arc` an [`Weak`] yên din ên ji bo heman veqetandinê ji bo domandina deynê vegerandin neyên paşguh kirin.
    ///
    /// Ger nişanvanek wusa tune be, bi mînakî piştî `Arc::new` yekser ev rewş e.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Em hay ji xwe hene ku *ne* referansek ku zeviyên "count" vedigire biafirîne, ji ber ku ev ê bi nasnav bi gihîştina hevdem a hejmarên referansê re (wek mînak
        // ji hêla `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Diyar bikin ka ev referansa bêhempa ye (refên qels jî tê de) ji daneyên bingehîn re.
    ///
    ///
    /// Zanibe ku ji bo vê yekê pêdivî ye ku jimartina refa qels were girtin.
    fn is_unique(&mut self) -> bool {
        // heke em xuya dikin ku em xwediyê tekane pointer ê qels in, hêjmara pêşnumaya lawaz kilît bikin.
        //
        // Li vir etîketa destkeftinê pêwendiya qewimîn-pêşîn a bi her nivîsandina ji `strong` re (bi taybetî di `Weak::upgrade`) de berî daxistinên hejmartina `weak` (bi rêya `Weak::drop`, ku weşanê bikar tîne) misoger dike.
        // Ger refa lawaz a nûvekirî carî neyê avêtin, dê CAS li vir têk biçe ji ber vê yekê em nahêlin ku hevdem bikin.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Pêdivî ye ku ev `Acquire` be ku bi kêmbûna jimarvanê `strong` li `drop` re hevdem bike-tenê gihîştina ku dema ku hebe lê referansa paşîn tê avêtin pêk tê.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Li vir nivîsa berdanê bi xwendina li `downgrade` re hevdem dibe, bi bandor nahêle ku xwendina li jor a `strong` piştî nivîsandinê pêk were.
            //
            //
            self.inner().weak.store(1, Release); // qeflê berdin
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// `Arc` davêje.
    ///
    /// Ev ê jimartina referansa bihêz kêm bike.
    /// Ger jimareya referansa bihêz bigihîje sifirê wê hingê tenê referansên din (heke hebe) [`Weak`] in, ji ber vê yekê em nirxa hundurîn `drop` dikin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Tiştekî çap nake
    /// drop(foo2);   // "dropped!" çap dike
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Ji ber ku `fetch_sub` jixwe atomî ye, ne hewce ye ku em bi mijarên din re hevdem bikin heya ku em neçin ku tiştê jêbirin.
        // Heman mantiqa hanê ji `fetch_sub` ya jêrîn re heya hejmartina `weak` derbas dibe.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Ev dorpêç pêdivî ye ku pêşî li ji nû ve karanîna daneyê û jêbirina daneyê bigire.
        // Ji ber ku ew `Release` tête nîşankirin, kêmbûna jimareya referansê bi vê dorpêça `Acquire` re hevdem dibe.
        // Ev tê vê wateyê ku karanîna daneyê berî kêmbûna jimartina referansê, ya ku berî vê dorhêlê, ku berî rakirina daneyê dibe, pêk tê.
        //
        // Wekî ku di [Boost documentation][1] de hatî şirove kirin,
        //
        // > Girîng e ku meriv bigihîje gihîştina mimkun a tişti di yekê de
        // > têl (bi navgîniyek referansa heyî) ku *berî* jêbirinê biqewime
        // > tişt di têlek cûda de.Ev ji hêla "release" ve tête peyda kirin
        // > operasyona piştî daketina referansekê (her gihîştina tiştê
        // > bi riya vê referansê divê eşkere berê qewimîbe), û an
        // > "acquire" operasyona berî jêbirina tiştê.
        //
        // Bi taybetî, dema ku naverokên Arc bi gelemperî neguhêrbar in, gengaz e ku meriv hundurîn ji tiştek mîna Mutex re binivîse<T>.
        // Ji ber ku Mutex dema ku tê jêbirin nayê stendin, em nekarin xwe bisipêrin mantiqa hevdemkirinê ku em di rûpela A-yê de binivîsin da ku hilweşînerê ku di mijara B de dimeşe xuya bike.
        //
        //
        // Di heman demê de not bikin ku dorhêla Acquire li vir dibe ku bi barkirina Acquire were veguheztin, ku dikare di rewşên pir-minaqeşe de performansê baştir bike.[2] bibînin.
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Hewldana dakêşandina `Arc<dyn Any + Send + Sync>` bi celebek betonî.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Bêyî ku bîranînek veqetîne, `Weak<T>` nû çêdike.
    /// Li ser nirxa vegerê bangkirina [`upgrade`] her gav dide [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Tîpa alîkar ku destûrê dide ku bigihîje hejmartinên referansê bêyî ku li ser qada daneyê tu îdîa bike.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Pointerek xav vedigere tişta `T` ya ku ji hêla vê `Weak<T>` ve hatî nîşankirin.
    ///
    /// Nîşanger heke hin referansên xurt hebin jî derbasdar e.
    /// Nîşanek bi rengek din dangling, bêserûber an jî heya [`null`] be.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Herdu jî heman tiştî nîşan dikin
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Hêza li vir wê zindî dihêle, ji ber vê yekê em hîn jî dikarin xwe bigihînin tiştê.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Lê ne bêtir.
    /// // Em dikarin weak.as_ptr() bikin, lê gihîştina pointer dê bibe sedema reftarek nediyarkirî.
    /// // assert_eq! ("silav", ne ewle {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Ger nîşander dangling be, em sentînel rasterast vedigerin.
            // Ev nikare navnîşanek barbar a derbasdar be, ji ber ku barkêş bi kêmasî bi ArcInner (usize) ve wekhev e.
            ptr as *const T
        } else {
            // EWLEH: : ger is_dangling derewîn vegerîne, wê hingê nîşander dereferî ye.
            // Dibe ku di vê nuqteyê de payload were daxistin, û em neçar in ku pê re peydabûna xwe bidomînin, ji ber vê yekê manîpulasyona nîşana xav bikar bînin.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// `Weak<T>` dixwe û wê vediguherîne pêşnumayek rawe.
    ///
    /// Ev nîşanderê qels veguherîne pêşekek rawe, di heman demê de hîn jî xwedaniya referansek qels diparêze (jimara qels ji hêla vê operasyonê ve nayê guherandin).
    /// Ew dikare bi [`from_raw`] vegere `Weak<T>`.
    ///
    /// Heman sînorkirinên gihîştina hedefa nîşanderê wekî bi [`as_ptr`] re derbas dibe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Nîşanek raweya ku berê ji hêla [`into_raw`] ve hatî afirandin vedigerîne `Weak<T>`.
    ///
    /// Ev dikare were bikar anîn ku bi ewlehî referansek bihêz werbigire (bi bangkirina paşê [`upgrade`]) an jî daketina jimara qels a `Weak<T>` were avêtin.
    ///
    /// Ew xwediyê referansek qels e (ji xeynî nîşangirên ku ji hêla [`new`] ve hatine afirandin, ji ber ku ev ne xwediyê tiştekî ne; rêbaz hîn jî li ser wan dixebite).
    ///
    /// # Safety
    ///
    /// Pêdivî ye ku nîşander ji [`into_raw`] dest pê kiribe û hîn jî xwediyê referansa xweya qels a potansiyel be.
    ///
    /// Destûr tête dayîn ku jimartina bihêz di dema bangkirina vê de 0 be.
    /// Lêbelê, ev xwediyê referansek qels a ku niha wekî pêşnumayek rawe tê temsîl kirin digire (hejmarê qels ji hêla vê operasyonê ve nayê guherandin) û ji ber vê yekê divê ew bi banga berê ya [`into_raw`] re were hevber kirin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Hejmara qels a paşîn paşde bixin.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Weak::as_ptr binihêrin ji bo kontekstê ka nîşanderê têketinê çawa tête derxistin.

        let ptr = if is_dangling(ptr as *mut T) {
            // Ev Qelsek dangling e.
            ptr as *mut ArcInner<T>
        } else {
            // Wekî din, ji me re misoger e ku pointer ji lawaziyek tinebûyî hat.
            // EWLEHIYA: daneya_offset ji bo bangkirinê ewledar e, ji ber ku referansên ptr rastîn (potansiyel ketî) T ye.
            let offset = unsafe { data_offset(ptr) };
            // Wiha, em berevajî berevajî dikin ku tevahiya RcBox bistînin.
            // EWLEHIYA: pointer ji Qelsiyek çêbû, lewma ev berdêl ewledar e.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // EWLEH: me nuha pêşnumaya Qels a xwerû peyda kir, ji ber vê yekê em dikarin Qelsê biafirînin.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Hewldanên ku nûvekerê `Weak` bi [`Arc`] nûve dikin, heke serfiraz daketina nirxa hundurîn taloq dike.
    ///
    ///
    /// Ger nirxa hundurîn ji wê paşde ketibe [`None`] vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Hemî nîşanên xurt hilweşînin.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Em xelekek CAS-ê bikar tînin ku li şûna fetch_add hejmartina bihêz zêde bikin ji ber ku divê ev fonksiyon carî jimara referansê ji sifirê nede yekê.
        //
        //
        let inner = self.inner()?;

        // Barkirina rehet, ji ber ku her nivîsandina 0-ya ku em dikarin lê binihêrin zevî di rewşek domdar de sifir dihêle (ji ber vê yekê "stale"-a xwendina 0-ê baş e), û her nirxek din bi CAS-a jêrîn tête pejirandin.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Li `Arc::clone` şîroveyan bibînin ka çima em vê yekê dikin (ji bo `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Relax ji bo doza têkçûnê baş e ji ber ku di derbarê dewleta nû de hêviyên me tune.
            // Wergirtin ji bo doza serketinê pêdivî ye ku bi `Arc::new_cyclic` re hevdem bike, dema ku nirxa hundirîn dikare bê destpêkirin piştî ku referansên `Weak` jixwe hatine afirandin.
            // Di wê rewşê de, em hêvî dikin ku nirxa bi tevahî destpêkirî bibînin.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null li jor hatî kontrol kirin
                Err(old) => n = old,
            }
        }
    }

    /// Hejmara nîşangirên xurt (`Arc`) yên ku vê veqetandinê îşaret dikin digire.
    ///
    /// Ger `self` bi karanîna [`Weak::new`] hate afirandin, ev ê 0 vegerîne.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Nêzîkî hejmarê `Weak` nîşangirên ku vê veqetandinê nîşan dikin dibe.
    ///
    /// Ger `self` bi karanîna [`Weak::new`] hate afirandin, an heke nîşanên bihêz ên mayî tune bin, ev ê 0 vegerîne.
    ///
    /// # Accuracy
    ///
    /// Ji ber ku hûrguliyên pêkanînê, nirxa vegeriyayî dikare ji hêla 1-ê ve di her du aliyan de be dema ku têlên din manîpulekirina her `Arc` an`Weq` ya ku dabeşkirina heman nîşan dikin dike.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Ji ber ku me mêze kir ku piştî xwendina jimara qels bi kêmî ve yekê nîşanderê bihêz hebû, em dizanin ku referansa qels a berbiçav (dema ku her referansên xurt zindî bin) dema ku me jimara qels dît hîn jî dor bû, û ji ber vê yekê em dikarin bi ewlehî jê derxin.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// `None` vedigerîne dema ku nîşander dangling e û `ArcInner` veqetandî tune, (ango, dema ku ev `Weak` ji hêla `Weak::new` ve hate afirandin).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Em hay ji xwe hene ku *ne* referansek ku qada "data" vedigire biafirînin, ji ber ku dibe ku zevî bi hev re were guhertin (ji bo nimûne, heke `Arc`-a paşîn were avêtin, dê qada daneyê di cîh de were avêtin).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// `true` vedigerîne heke her du `Weq` s li ser dabeşkirinek yek nîşan bikin (dişibe [`ptr::eq`]), an heke her du jî li ser dabeşkirinekê venagerînin (ji ber ku ew bi `Weak::new()`) hatine afirandin.
    ///
    ///
    /// # Notes
    ///
    /// Ji ber ku ev nîşangiran dide ber hev ev tê vê wateyê ku `Weak::new()` dê hevûdu wekhev be, her çend ew nexşeya veqetandinê nîşan nedin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Berawirdkirina `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Klonek nîşanderê `Weak` çêdike ku îşaret bi heman veqetandinê dike.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Li Arc::clone() şîroveyan bibînin ka çima ev rehet e.
        // Ev dikare fetch_add bikar bîne (guh nede qeflê) ji ber ku jimartina lawaz tenê li cîhê ku hebkî nîşanên lawaz ên * din tunîne tê girtin.
        //
        // (Ji ber vê yekê em nikarin di vê rewşê de vê kodê bimeşînin).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Li Arc::clone() şîroveyan bibînin ka çima em vê yekê dikin (ji bo mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Bêyî ku bîranîn veqetîne, `Weak<T>` nû çêdike.
    /// Li ser nirxa vegerê bangkirina [`upgrade`] her gav dide [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Xwerûya `Weak` davêje.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Tiştekî çap nake
    /// drop(foo);        // "dropped!" çap dike
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Ger em fêr bibin ku em pêşanderê lawaz ê herî paşîn in, wê hingê dema wê ye ku daneyan bi tevahî veqetîne.Di Arc::drop() de li ser rêzikên bîranînê nîqaşê bibînin
        //
        // Ne hewce ye ku li vir rewşa qefilandî were kontrol kirin, ji ber ku jimartina qels tenê dikare were qefilandin heke birastî refek qels hebe, tê wateya ku daket tenê paşê dikare li ser wê refa qels a mayî bimeşe, ku tenê piştî ku qefil serbest be dikare pêk were.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Em vê pisporiyê li vir dikin, û ne wekî optimîzasyonek gelemperî li ser `&T`, ji ber ku ew ê wekî din lêçûnek li hemî venêranên wekheviyê li refan zêde bike.
/// Em texmîn dikin ku `Arc` s ji bo depokirina nirxên mezin, ên ku hêdî hêdî têne klon kirin, lê di heman demê de giran e ku ji bo wekheviyê kontrol bikin jî têne bikar anîn, dibe sedem ku ev lêçûn hêsantir bide.
///
/// Di heman demê de dibe ku du klonên `Arc` hebin, ku heman nirxê nîşan dikin, ji du `&T`yan.
///
/// Em tenê dikarin vê yekê pêk bînin dema ku `T: Eq` wekî `PartialEq` dibe ku bi zanebûn bêveger be.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Wekheviya du `Arc`ê.
    ///
    /// Du `Arc` heke nirxên wan ên hundurîn wekhev bin, heke ew jî di veqetandek cuda de werin hilanîn.
    ///
    /// Ger `T` `Eq` jî bicîh bike (tê wateya refleksîfbûna wekheviyê), du `Arc`ên ku heman veqetandinê nîşan dikin her dem wekhev in.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Neheqî ji bo du `Arc` s.
    ///
    /// Du `Arc`s neheq in heke nirxên wan ên hundurîn neyeksan bin.
    ///
    /// Ger `T` `Eq` jî bicîh bike (tê wateya refleksîfbûna wekheviyê), du `Arc`ên ku bi heman nirxê radiwestin qet neheq in.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Beramberkirina qismî ya du `Arc`ê.
    ///
    /// Herdu bi gazîkirina `partial_cmp()` li ser nirxên xweyên hundurîn têne berawird kirin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Berawirdekirina kêmtir-ji bo du `Arc` ê.
    ///
    /// Herdu bi gazîkirina `<` li ser nirxên xweyên hundurîn têne berawird kirin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'Ji kêmtir an wekhev' berawirdkirina du `Arc` ê.
    ///
    /// Herdu bi gazîkirina `<=` li ser nirxên xweyên hundurîn têne berawird kirin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Beramberî ji du`Arc`ê mezintir.
    ///
    /// Herdu bi gazîkirina `>` li ser nirxên xweyên hundurîn têne berawird kirin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'Ji wan mezintir an wekhev' berawirdkirina du `Arc`-ê.
    ///
    /// Herdu bi gazîkirina `>=` li ser nirxên xweyên hundurîn têne berawird kirin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Beramberî du `Arc`ê.
    ///
    /// Herdu bi gazîkirina `cmp()` li ser nirxên xweyên hundurîn têne berawird kirin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Bi nirxa `Default` ji bo `T`, `Arc<T>` nû diafirîne.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Parçeyek navnîşkirî veqetînin û bi klonkirina hêmanên `v` dagirin.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// `str`-a ku wekî jimare tê hejmartin veqetînin û `v`-ê tê de kopî bikin.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// `str`-a ku wekî jimare tê hejmartin veqetînin û `v`-ê tê de kopî bikin.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Tiştek sindoqkirî bikişînin ser veqetandekek nû, ku ji hêla referansê ve tête hejmartin.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Parçeyek referans-jimartî veqetînin û hêmanên `v`-ê têxin nav wê.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Vec bihêlin ku bîranîna xwe azad bike, lê naveroka wê hilweşe
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Her hêmanê di `Iterator` de digire û dixe nav `Arc<[T]>`.
    ///
    /// # Taybetmendiyên performansê
    ///
    /// ## Doza giştî
    ///
    /// Di rewşa gelemperî de, berhevkirina nav `Arc<[T]>` bi komkirina yekem a `Vec<T>` ve tête kirin.Ango, dema nivîsandina jêrîn:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ev tevdigere mîna ku me nivîsandibe:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Koma yekem a veqetandinan li vir çêdibe.
    ///     .into(); // Dabeşandina duyemîn ji bo `Arc<[T]>` li vir çêdibe.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Ev dê ji bo çêkirina `Vec<T>` bi qasî ku hewce be veqetîne û dûv re ew ê carek ji bo veguherandina `Vec<T>` nav `Arc<[T]>` veqetîne.
    ///
    ///
    /// ## Iteratorên dirêjahiya têne zanîn
    ///
    /// Gava ku `Iterator` we `TrustedLen` bicîh dike û ji mezinahiyek rastîn e, dê ji bo `Arc<[T]>` veqetandekek yek were çêkirin.Bo nimûne:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Tenê veqetandinek tenê li vir çêdibe.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Specialization trait ji bo berhevkirina nav `Arc<[T]>` tê bikar anîn.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Ev rewş ji bo Xeberxebatkarek `TrustedLen` e.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // BELAW: Em hewce ne ku pê ewle bine ku dirêjahiya rastîn a iterator heye û em jî hene.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Li pêkanîna normal vegerin.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Di nav `ArcInner` de ji bo dravdana li paş pointer pêşkêşî bikin.
///
/// # Safety
///
/// Pêdivî ye ku pêşnîyar mînakek T-ya berê derbasdar nîşan bide (û ji bo vê yekê jî metadata derbasdar hebe), lê T destûr tê dayin.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Nirxa nevekirî bi dawiya ArcInner re hevûdu bikin.
    // Ji ber ku RcBox repr(C) e, ew ê herdem di bîranînê de qada herî dawî be.
    // EWLEH: ji ber ku tenê celebên bêserûber ên gengaz qut in, tiştên trait ne,
    // û celebên derveyî, hewcedariya ewlehiya navnîşê nuha bes e ku daxwazên align_of_val_raw razî bike;ev hûrgulî ya pêkanînê ya zimên e ku dibe ku li derveyî std nayê bawer kirin.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}