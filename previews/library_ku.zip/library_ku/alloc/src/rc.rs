//! Nîşaneyên jimartina referansa yek-têl.'Rc' tê wateya 'Reference
//! Counted'.
//!
//! Tîpa [`Rc<T>`][`Rc`] xwedan xwedan parvekirinek nirxê celebê `T`, ku di komikê de hatî veqetandin peyda dike.
//! Bi vexwendina [`clone`][clone] li ser [`Rc`] pointerek nû çêdike ku bi heman veqetandinê re di heapê de ye.
//! Gava ku nîşanderê [`Rc`]-ê ya paşîn li dabeşkirinek diyarkirî were rûxandin, nirxa ku di wê veqetandinê de hatî hilanîn (ku pir caran wekî "inner value" tête binavkirin) jî tê avêtin.
//!
//! Çavkaniyên hevpar ên di Rust de mutasyonê ji hêla default ve nahêlin, û [`Rc`] ne veqetandek e: hûn bi gelemperî nikarin referansa guhêrbar a tiştek di hundurê [`Rc`] de bistînin.
//! Heke hûn guhêrbariyê hewce dikin, [`Cell`] an [`RefCell`] têxin hundurê [`Rc`];[an example of mutability inside an `Rc`][mutability] bibînin.
//!
//! [`Rc`] jimartina referansa ne-atomî bikar tîne.
//! Ev tê vê wateyê ku serûber pir kêm e, lê [`Rc`] nikare di navbera têlan de were şandin, û di encamê de [`Rc`] [`Send`][send] bicîh nake.
//! Wekî encamek, berhevkarê Rust dê *di dema berhevokê de* kontrol bike ku hûn ['Rc`]-yên di navbera têlan de naşînin.
//! Heke hûn hewceyê jimartina referansa atomî ya pir-têl in, [`sync::Arc`][arc] bikar bînin.
//!
//! Metoda [`downgrade`][downgrade] dikare were bikar anîn da ku pêşnumayek ne-xwedan [`Weak`] were afirandin.
//! Nîşanek [`Weak`] dikare [`nûvekirin`][nûvekirin] d bi [`Rc`] be, lê ev ê [`None`] vegerîne heke nirxa ku di veqetandinê de hatî hilanîn jixwe daket.
//! Bi gotinên din, nîşankerên `Weak` nirxa hundurê veqetandinê zindî nahêlin;lêbelê, ew *dikin* dabeşkirinê (dikana pişta ji bo nirxa hundurîn) zindî dihêlin.
//!
//! Çerxek di navbên [`Rc`] de dê carî neyê veqetandin.
//! Ji bo vê sedemê, [`Weak`] ji bo şikandina çerxan tê bikar anîn.
//! Mînakî, dibe ku darek ji girêkên dêûbavan bigire heya zarokan, û nîşankerên [`Weak`] jî ji zarokan vegerin dêûbavên xwe.
//!
//! `Rc<T>` jixweber dereweyên `T` (bi rêya [`Deref`] trait) vedigerin, ji ber vê yekê hûn dikarin li ser nirxa tîpa [`Rc<T>`][`Rc`] bangî rêbazên `T` bikin.
//! Ji bo ku bi rêbazên `T`-yê re pevçûn dernekeve, rêbazên [`Rc<T>`][`Rc`] bixwe fonksiyonên têkildar in, ku bi karanîna [fully qualified syntax] têne gotin:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>Dibe ku ji pêkanînên traits wekî `Clone` re jî hevoksaziyek bi tevahî kalîfîze were gotin.
//! Hin kes tercîh dikin ku hevoksaziya bi tevahî kalîfîze bikar bînin, lê hin jî tercîh dikin ku hevoksaziya rêbaz-bang bikar bînin.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Sentaksa mêtod-bang
//! let rc2 = rc.clone();
//! // Hevoksaziya bi tevahî kalîfîye
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] ji `T`-ê xweber venagerîne, ji ber ku dibe ku nirxa hundurîn berê hatibe avêtin.
//!
//! # Çavkaniyên klonîkirin
//!
//! Afirandina referansek nû ji bo dabeşkirina eynî wek nîşanderê hejmartî referansa heyî bi karanîna `Clone` trait ya ji bo [`Rc<T>`][`Rc`] û [`Weak<T>`][`Weak`] hatî pêkanîn tête kirin.
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Du hevoksazên li jêr wekhev in.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a û b herdû cihên bîra heman foo-yê nîşan dikin.
//! ```
//!
//! Hevoksaziya `Rc::clone(&from)` herî idiomatîkî ye ji ber ku ew wateya kodê bi zelalî radigihîne.
//! Di nimûneya jorîn de, ev hevoksazî hêsantir dike ku mirov bibîne ku ev kod ji bil kopîkirina naveroka tevahî ya foo-yê, referansek nû diafirîne.
//!
//! # Examples
//!
//! Senaryoyek bihesibînin ku komek ji `Gadget``ê ji hêla `Owner` ve hatî xwedîkirin in.
//! Em dixwazin xala `Gadget` a `Owner`-a wan hebe.Em nekarin vê yekê bi xwedaniyek yekta bikin, ji ber ku dibe ku ji yekê zêdetir gadget aîdî `Owner` heman bin.
//! [`Rc`] rê dide me ku em `Owner` di navbera pirjimar `Gadget` ê de parve bikin, û bila `Owner` heya ku `Gadget` li ser wê xalan tê veqetandin bimîne.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... warên din
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... warên din
//! }
//!
//! fn main() {
//!     // `Owner`-a ku wekî jimare tê hejmartin biafirînin.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // `Gadget` ya ku girêdayî `gadget_owner` ye biafirînin.
//!     // Klonkirina `Rc<Owner>` ji bo heman veqetandinê `Owner` pointerek nû dide me, di pêvajoyê de jimara referansê zêde dike.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Guhêrbariya meya herêmî `gadget_owner` bavêjin.
//!     drop(gadget_owner);
//!
//!     // Tevî ku `gadget_owner` davêjin jî, em hîn jî dikarin navê `Owner` ya `Gadget` çap bikin.
//!     // Ji ber ku me tenê `Rc<Owner>`-yek tenê avêtiye, ne `Owner`-ê ku ew nîşan dike.
//!     // Heya ku `Rc<Owner>` yên din hene ku li heman dabeşkirina `Owner` nîşan dikin, ew ê zindî bimîne.
//!     // Pêşnûmeya zeviyê `gadget1.owner.name` dixebite ji ber ku `Rc<Owner>` bixweber ji `Owner` re vedigere.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Di dawiya fonksiyonê de, `gadget1` û `gadget2` têne hilweşandin, û digel wan re referansên paşîn ên `Owner`-ya me têne hesibandin.
//!     // Gadget Man naha jî wêran dibe.
//!     //
//! }
//! ```
//!
//! Ger hewcedariyên me biguherin, û em jî hewce ne ku karibin ji `Owner` heya `Gadget` derbaz bibin, em ê pirsgirêkan bikişînin.
//! Nîşanek [`Rc`] ji `Owner` heya `Gadget` çerxek destnîşan dike.
//! Ev tê vê wateyê ku hejmarên referansa wan tu carî nagihîje 0-yê, û dabeşkirin dê carî tune nebe:
//! lebatek bîranînê.Ji bo ku em vê yekê dorpêç bikin, em dikarin nîşangirên [`Weak`] bikar bînin.
//!
//! Rust bi rastî di rêza yekem de hilberandina vê loopê hinekî dijwar dike.Ji bo ku di encamê de du nirxên ku hevûdu nîşan dikin, hewce dike ku yek ji wan guherbar be.
//! Ev dijwar e ji ber ku [`Rc`] ewlehiya bîranînê bi tenê dayîna çavkanîyên parvekirî yên li ser nirxa ku pêça, zor dike û ev rê nadin mutasyona rasterast.
//! Em hewce ne ku beşa nirxa ku em dixwazin li [`RefCell`] veguherînin, ku *guhêrîna hundurîn* peyda dike, dorpêç bikin: rêbazek ku bi navgîniyek parvekirî ve mutabîlî peyda bibe.
//! [`RefCell`] rêgezên deynkirina Rust di dema kar de bicîh tîne.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... warên din
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... warên din
//! }
//!
//! fn main() {
//!     // `Owner`-a ku wekî jimare tê hejmartin biafirînin.
//!     // Têbînî ku me vector ya `Xwedî` ya`Gadget``ê xistiye hundurê `RefCell` da ku em bi navgîniya referansek hevpar ve wê mutate bikin.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // `Gadget` a ku girêdayî `gadget_owner` ye, wekî berê biafirînin.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // `Gadget` li `Owner` wan zêde bikin.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` deynê dînamîk li vir xilas dibe.
//!     }
//!
//!     // Li ser `Gadget` a me tevnegerin, hûrguliyên wan çap bikin.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` `Weak<Gadget>` e.
//!         // Ji ber ku nîşangirên `Weak` nekarin garantî bikin ku dabeşkirin hîn jî heye, pêdivî ye ku em bangî `upgrade` bikin, ku `Option<Rc<Gadget>>` vedigerîne.
//!         //
//!         //
//!         // Di vê rewşê de em dizanin veqetandin hîn jî heye, ji ber vê yekê em bi tenê `unwrap` `Option` dikin.
//!         // Di bernameyek tevlihevtir de, dibe ku hûn ji bo encamek `None` hewceyê karûbarê xeletiya dilnizm bin.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Di dawiya fonksiyonê de, `gadget_owner`, `gadget1`, û `gadget2` têne hilweşandin.
//!     // Vêga li ser gadgetoran xuyangên xurt (`Rc`) tune, ji ber vê yekê ew têne tunekirin.
//!     // Ev hejmartina referansê li ser Gadget Man sifir dike, ji ber vê yekê ew jî xera dibe.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Ev ji repr(C) heya future-delîl e li hember re-rêwerzekirina gengaz a gerdûnî, ku dê bi [into|from]_raw()-an ên ewle celebên hundurîn ên veguherîner re têkeve navberê.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Nîşanek referans-jimartina yek-têl.'Rc' tê wateya 'Reference
/// Counted'.
///
/// Ji bo bêtir agahdarî li [module-level documentation](./index.html) binêrin.
///
/// Rêbazên xwerû yên `Rc` hemî fonksiyonên têkildar in, ku tê vê wateyê ku hûn neçar in ku li şûna `value.get_mut()` bangî wan bikin wek mînak, [`Rc::get_mut(&mut value)`][get_mut].
/// Ev ji rêbazên ji celebê hundurîn `T` ji pevçûnan dûr dikeve.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Ev bêewlehî baş e ji ber ku dema ku ev Rc sax e em garantî dibin ku nîşanderê hundurîn derbasdar e.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// `Rc<T>`-ya nû çêdike.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Nîşanek qels a berbiçav heye ku xwedan hemî nîşangirên bihêz e, ku piştrast dike ku hilweşînerê qels qet dabeşkirinê azad nake dema ku hilweşînerê bihêz dimeşe, her çend ku pêşnumaya lawaz jî di hundurê ya bihêz de were hilanîn.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// `Rc<T>`-ya nû bi karanîna referansek lawaz ji xwe re çêdike.
    /// Hewldana nûvekirina referansa qels berî ku ev fonksiyon vegere dê di nirxek `None` de encam bide.
    ///
    /// Lêbelê, referansa qels dikare bi serbestî were klon kirin û ji bo demek paşê were bikar anîn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... zeviyên bêtir
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Di dewleta "uninitialized" de hundurîn bi referansek tenê qels ava bikin.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Girîng e ku em dev ji xwedîtîya pointerê qels bernedin, an na dema ku `data_fn` vedigere dibe ku bîranîn azad bibe.
        // Heke em bi rastî dixwestin xwedaniyê derbas bikin, me dikarî pêşnumayek qels a pêvek ji xwe re çêbikin, lê ev ê di encamên nûvekirina hejmarê referansa qels de encam bide ku dibe ku nebe ku ne hewce be.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Pêdivî ye ku referansên bihêz bi hev re xwediyê referansek qels a hevpar bin, ji ber vê yekê hilweşînerê ji bo referansa meya kevn a lawaz nexebitînin.
        //
        mem::forget(weak);
        strong
    }

    /// `Rc`-ya nû bi naverokên nezanî saz dike.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Destpêkirina taloqkirî:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Bi bîranîna ku bi `0` byte tê dagirtin `Rc` nû bi naverokên nezanî saz dike.
    ///
    ///
    /// Ji bo nimûneyên karanîna rast û çewt a vê rêbazê li [`MaybeUninit::zeroed`][zeroed] binêrin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// `Rc<T>` nû çêdike, ger veqetandin têk bibe xeletiyek vedigerîne
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Nîşanek qels a berbiçav heye ku xwedan hemî nîşangirên bihêz e, ku piştrast dike ku hilweşînerê qels qet dabeşkirinê azad nake dema ku hilweşînerê bihêz dimeşe, her çend ku pêşnumaya lawaz jî di hundurê ya bihêz de were hilanîn.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// `Rc`-ya nû bi naverokên uninitialized-ê çêdike, heke veqetandin têk diçe xeletiyek vedigire
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Destpêkirina taloqkirî:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// `Rc` ya nû bi naverokên nezanî saz dike, digel ku bîranîn bi `0` byte tê dagirtin, heke veqetandin bi ser nekeve xeletiyek vedigire
    ///
    ///
    /// Ji bo nimûneyên karanîna rast û çewt a vê rêbazê li [`MaybeUninit::zeroed`][zeroed] binêrin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// `Pin<Rc<T>>`-ya nû çêdike.
    /// Ger `T` `Unpin` bicîh neyne, wê hingê `value` dê di bîra xwe de pîne bibe û nekaribe were bar kirin.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Nirxa hundurîn vedigerîne, heke `Rc` bi rastî yek referansek xurt hebe.
    ///
    /// Wekî din, [`Err`] bi heman `Rc` ve hatî vegerandin.
    ///
    ///
    /// Ger referansên qels ên berbiçav hebin jî ev dê bi ser bikeve.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // tiştê tê de kopî bikin

                // Ji Weakan re diyar bikin ku ew bi kêmkirina hejmartina hêzdar nayên pêşve xistin, û dûv re nîşanderê nexşandî yê "strong weak" derxistin û di heman demê de mantiqa dilopê jî bi tenê çêkirina Zehfek derewîn.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Bi naverokên nezewacekirî perçeyek nû-ya jimartî çêdike.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Destpêkirina taloqkirî:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Bi naveroka uninitialized re, bi bîranîna ku bi `0` byte tê dagirtin, perçeyek nû-jimartî ya çêkirî çêdike.
    ///
    ///
    /// Ji bo nimûneyên karanîna rast û çewt a vê rêbazê li [`MaybeUninit::zeroed`][zeroed] binêrin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// `Rc<T>` vedigire.
    ///
    /// # Safety
    ///
    /// Çawa ku bi [`MaybeUninit::assume_init`] re, ew bangker e ku garantî bike ku nirxa hundirîn bi rastî di rewşek destpêkirî de ye.
    ///
    /// Bangkirina viya dema ku naverok hîn bi tevahî neyê destpêkirin dibe sedema tevgera tavilê nediyarkirî.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Destpêkirina taloqkirî:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// `Rc<[T]>` vedigire.
    ///
    /// # Safety
    ///
    /// Çawa ku bi [`MaybeUninit::assume_init`] re, ew bangker e ku garantî bike ku nirxa hundirîn bi rastî di rewşek destpêkirî de ye.
    ///
    /// Bangkirina viya dema ku naverok hîn bi tevahî neyê destpêkirin dibe sedema tevgera tavilê nediyarkirî.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Destpêkirina taloqkirî:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// `Rc` dixwe, nîşanderê pêçayî vedigerîne.
    ///
    /// Ji bo ku ji leza bîranînê dernekeve divê nîşander bi karanîna [`Rc::from_raw`][from_raw] vegere `Rc`.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Nîşanek raweya daneyê peyda dike.
    ///
    /// Hejmartin bi rengek bandor nabin û `Rc` nayê xerckirin.
    /// Nîşanek heya ku hejmartinên bihêz ên `Rc` hebin derbasdar e.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // EWLEH: Ev ji Deref::deref an Rc::inner derbas nabe lewra
        // ev pêdivî ye ku pêgirtiya raw/mut bimîne wusa ku mînak
        // `get_mut` piştî ku Rc bi `from_raw` vegeriya dikare bi navgînvanê binivîse.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// `Rc<T>` ji pêşnumayek rawe çêdike.
    ///
    /// Pêdivî ye ku pêşnumaya rawe berê bi bangek li [`Rc<U>::into_raw`][into_raw] hatibe vegerandin ku divê `U` xwedan eynî pîvan û rêzkirinê be wekî `T`.
    /// Ger `U` `T` be ev bi rastî rast e.
    /// Zanibe ku heke `U` ne `T` be lê xwedan heman pîvan û rêzkirinê be, ev di bingeh de mîna veguheztina referansên celebên cûda ye.
    /// Ji bo bêtir agahdarî li ser kîjan astengî di vê rewşê de derbas dibin [`mem::transmute`][transmute] bibînin.
    ///
    /// Bikarhênerê `from_raw` neçar e ku nirxek taybetî ya `T` tenê carekê bavêje.
    ///
    /// Ev fonksiyon ne ewle ye ji ber ku karanîna nerast dikare bibe sedema bêewlehîtiya bîranînê, her çend `Rc<T>` vegeriyayî qet neyê dîtin.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Vegere `Rc`-ê veguherîne ku ji ber derketinê nehêle.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Dê bêtir bangên `Rc::from_raw(x_ptr)`-ê bîranîn-ewledar bin.
    /// }
    ///
    /// // Dema ku `x` ji jor derket qada bîranînê hate azad kirin, ji ber vê yekê `x_ptr` nuha daleqandî ye!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Berevajî berevajî bikin ku RcBox-ya xwerû bibînin.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Ji bo vê dabeşkirinê pêşnumayek nû [`Weak`] diafirîne.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Bawer bikin ku em Qelsiyek dangling neafirînin
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Ji bo vê veqetandinê hejmara nîşankerên [`Weak`] digire.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Ji bo vê veqetandinê hejmara pêşekên xurt (`Rc`) digire.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Heke ji bo vê veqetandinê `Rc` an [`Weak`] nîşanên din tunebin `true` vedigerîne.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Heke ji bo dabeşkirina heman `Rc` an [`Weak`] nîşanên din tune, referansa guhêrbar vedigerîne nav `Rc` ya hatî dayîn.
    ///
    ///
    /// Wekî din [`None`] vedigerîne, ji ber ku ew ne ewle ye ku nirxek parvekirî mutate bike.
    ///
    /// [`make_mut`][make_mut] jî binihêrin, ku gava nîşankerên din hebin dê nirxa hundirîn [`clone`][clone] bike.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Bêyî ku kontrol bike, referansa guhêrbar vedigerîne nav `Rc` ya hatî dayîn.
    ///
    /// [`get_mut`] jî bibînin, ku ewledar e û kontrolên guncan dike.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Pêdivî ye ku nîşangirên `Rc` an [`Weak`] yên din ên ji bo heman veqetandinê ji bo domandina deynê vegerandin neyên paşguh kirin.
    ///
    /// Ger nişanvanek wusa tune be, bi mînakî piştî `Rc::new` yekser ev rewş e.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Em hişyar in ku *ne* referansek ku zeviyên "count" vedigire biafirînin, ji ber ku ev dê bi gihîştina hejmarên referansê re nakok be (mînakî
        // ji hêla `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// `true` vedigerîne heke her du `Rc` li dabeşkirinek yek nîşan bikin (di reh de dişibe [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Di nav `Rc` ya hatî dayîn de referansek guherbar çêdike.
    ///
    /// Ger nîşanderên `Rc` yên din li ser heman veqetandinê hebin, wê hingê `make_mut` dê nirxa hundirîn a veqetandek nû [`clone`] bike da ku xwedaniya yekta misoger bike.
    /// Ev wekî klon-li-nivîsandinê jî tête binav kirin.
    ///
    /// Heke ji vê dabeşkirinê re nîşangirên `Rc` yên din tune, wê hingê nîşankerên [`Weak`] yên vê veqetandinê dê werin veqetandin.
    ///
    /// Her weha [`get_mut`] binihêrin, ku dê bêtir ji klonkirinê têk biçe.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Dê tiştek klon neke
    /// let mut other_data = Rc::clone(&data);    // Dê daneyên hundurîn klon nekin
    /// *Rc::make_mut(&mut data) += 1;        // Daneyên hundurîn klon dike
    /// *Rc::make_mut(&mut data) += 1;        // Dê tiştek klon neke
    /// *Rc::make_mut(&mut other_data) *= 2;  // Dê tiştek klon neke
    ///
    /// // Naha `data` û `other_data` veqetandinên cihêreng nîşan dikin.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] dê nîşander bên veqetandin:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Gotta daneyê klon dike, Rcyên din jî hene.
            // Berî bîranînê veqetînin da ku hûn rasterast nirxa klonkirî binivîsin.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Tenê dikare danezanan bidize, ya ku maye Qelsî ye
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Ref-a berbiçav-qels a berbiçav derxînin (ne hewce ye ku hûn li vir Qelsiyek derewîn çêbikin-em dizanin ku Qelsên din dikarin ji me re paqij bikin)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Ev bêewlehî baş e, çimkî em garantî ne ku pêvek vegeriyaye nîşana *tenê* ye ku dê carî vegere T.
        // Hejmara referansa me di vê nuqteyê de mîsogerkirî ye ku 1 be, û me hewce kir ku `Rc<T>` bi xwe `mut` be, ji ber vê yekê em tenê referansa gengaz a veqetandinê vedigerînin.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Hewldana dakêşandina `Rc<dyn Any>` bi celebek betonî.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// `RcBox<T>`-ê bi cîhê bes ji bo nirxê hundurîn ê dibe-ne-mezinkirî veqetîne li cihê ku di nirxê de pêşnumayek peydakirî veqetîne.
    ///
    /// Fonksiyona `mem_to_rcbox` bi nîşangirê daneyê tê vexwendin û divê ji bo `RcBox<T>` vegerekê (potansiyelî qelew) vegerîne.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Dabeşandina nirxa dayînê bi karanîna nirxê dayînê hesab bikin.
        // Berê, teşe li ser vegotina `&*(ptr as* const RcBox<T>)` dihat hesibandin, lê vê yekê referansek bêserûber çêkir (li #54908 binihêre).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// `RcBox<T>`-ê bi cîhê bes ji bo nirxê hundurîn ê dibe-ne-mezinkirî veqetandî dike ku nirxa wê pêşnumayê pêşkêşkirî ye, ger veqetandin têk biçe xeletiyek vedigerîne.
    ///
    ///
    /// Fonksiyona `mem_to_rcbox` bi nîşangirê daneyê tê vexwendin û divê ji bo `RcBox<T>` vegerekê (potansiyelî qelew) vegerîne.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Dabeşandina nirxa dayînê bi karanîna nirxê dayînê hesab bikin.
        // Berê, teşe li ser vegotina `&*(ptr as* const RcBox<T>)` dihat hesibandin, lê vê yekê referansek bêserûber çêkir (li #54908 binihêre).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Ji bo verastkirinê veqetînin.
        let ptr = allocate(layout)?;

        // RcBox-ê destpê bikin
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Ji bo nirxek hundurîn a nevekirî `RcBox<T>` bi cîhê bes veqetîne
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Ji bo `RcBox<T>` bi karanîna nirxê veqetandî veqetînin.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Nirxê wekî byte kopî bikin
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Bêyî ku naveroka wê bavêjin dabeşkirinê azad bikin
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// `RcBox<[T]>` bi dirêjahiya dayîn veqetîne.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Hêmanên ji perçê li Rc-ya nû veqetandî kopî bikin <\[T\]>
    ///
    /// Ne ewle ye ji ber ku bangker an divê xwediyê xwe be an `T: Copy` girêbide
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Ji iteratorê ku ji mezinahiyek diyar e `Rc<[T]>` çêdike.
    ///
    /// Tevger nayê diyarkirin divê mezinahî çewt be.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Dema ku hêmanên T klon dike Panic diparêze.
        // Di bûyera panic de, hêmanên ku di RcBox-a nû de hatine nivîsandin dê werin avêtin, paşê bîranîn azad bibe.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Nîşaneyê hêmana yekem
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Hemî zelal.Cerdevan ji bîr bikin da ku ew RcBox-a nû azad neke.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specialization trait ku ji bo `From<&[T]>` tê bikar anîn.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// `Rc` davêje.
    ///
    /// Ev ê jimartina referansa bihêz kêm bike.
    /// Ger jimareya referansa bihêz bigihîje sifirê wê hingê tenê referansên din (heke hebe) [`Weak`] in, ji ber vê yekê em nirxa hundurîn `drop` dikin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Tiştekî çap nake
    /// drop(foo2);   // "dropped!" çap dike
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // tişta tê de hilweşe
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // Nîşaneya nexşeya "strong weak"-ê ya ku me naverok hilweşand hilweşînin.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Klonek nîşanderê `Rc` çêdike.
    ///
    /// Ev pointerek din a ji bo heman veqetandinê diafirîne, hejmara referansa bihêz zêde dike.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Bi nirxa `Default` ji bo `T`, `Rc<T>` nû diafirîne.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack ku destûrê dide pisporiya li ser `Eq` her çend rêbazek `Eq` hebe jî.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Em vê pisporiyê li vir dikin, û ne wekî optimîzasyonek gelemperî li ser `&T`, ji ber ku ew ê wekî din lêçûnek li hemî venêranên wekheviyê li refan zêde bike.
/// Em texmîn dikin ku `Rc` ji bo depokirina nirxên mezin, ên ku hêdî hêdî têne klon kirin, lê di heman demê de giran e ku ji bo wekheviyê kontrol bikin, têne bikar anîn ku dibe sedema vê lêçûnê ku hêsantir bide.
///
/// Di heman demê de dibe ku du klonên `Rc` hebin, ku eynî nirxê nîşan dikin, ji du `&T`yan.
///
/// Em tenê dikarin vê yekê pêk bînin dema ku `T: Eq` wekî `PartialEq` dibe ku bi zanebûn bêveger be.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Wekheviya du `Rc` s.
    ///
    /// Du `Rc` heke nirxên wan ên hundurîn wekhev bin, heke ew jî di veqetandek cuda de werin hilanîn.
    ///
    /// Ger `T` `Eq` jî bicîh bike (tê wateya refleksîfbûna wekheviyê), du `Rc`ên ku heman veqetandinê nîşan dikin her dem wekhev in.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Neheqî ji bo du `Rc` ê.
    ///
    /// Du `Rc` neheq in heke nirxên wan ên hundurîn nebin.
    ///
    /// Ger `T` `Eq` jî bicîh bike (tê wateya refleksîfbûna wekheviyê), du `Rc`ên ku heman veqetandinê nîşan dikin, tu carî newekhev in.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Beramberkirina qismî ji bo du `Rc` ê.
    ///
    /// Herdu bi gazîkirina `partial_cmp()` li ser nirxên xweyên hundurîn têne berawird kirin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Berawirdekirina kêmtir-ji bo du `Rc` s.
    ///
    /// Herdu bi gazîkirina `<` li ser nirxên xweyên hundurîn têne berawird kirin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// 'Ji kêmtir an wekhev' berawirdkirina du `Rc`yan.
    ///
    /// Herdu bi gazîkirina `<=` li ser nirxên xweyên hundurîn têne berawird kirin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Beramberî ji ya du `Rc`ê mezintir.
    ///
    /// Herdu bi gazîkirina `>` li ser nirxên xweyên hundurîn têne berawird kirin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 'Ji wan mezintir an wekhev' berawirdkirina du `Rc`yan.
    ///
    /// Herdu bi gazîkirina `>=` li ser nirxên xweyên hundurîn têne berawird kirin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Beramberî her du `Rc` s.
    ///
    /// Herdu bi gazîkirina `cmp()` li ser nirxên xweyên hundurîn têne berawird kirin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Parçeyek navnîşkirî veqetînin û bi klonkirina hêmanên `v` dagirin.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Dabeşek rêzê ya ku ji we re referans têne hejmartin veqetînin û `v` tê de kopî bikin.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Dabeşek rêzê ya ku ji we re referans têne hejmartin veqetînin û `v` tê de kopî bikin.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Tiştek sindoqkirî veguherînin dabeşkirinek nû, referansa jimartî.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Parçeyek referans-jimartî veqetînin û hêmanên `v`-ê têxin nav wê.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Vec bihêlin ku bîranîna xwe azad bike, lê naveroka wê hilweşe
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Her hêmanê di `Iterator` de digire û dixe nav `Rc<[T]>`.
    ///
    /// # Taybetmendiyên performansê
    ///
    /// ## Doza giştî
    ///
    /// Di rewşa gelemperî de, berhevkirina nav `Rc<[T]>` bi komkirina yekem a `Vec<T>` ve tête kirin.Ango, dema nivîsandina jêrîn:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ev tevdigere mîna ku me nivîsandibe:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Koma yekem a veqetandinan li vir çêdibe.
    ///     .into(); // Dabeşandina duyemîn ji bo `Rc<[T]>` li vir çêdibe.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Ev dê ji bo çêkirina `Vec<T>` bi qasî ku hewce be veqetîne û dûv re ew ê carek ji bo veguherandina `Vec<T>` nav `Rc<[T]>` veqetîne.
    ///
    ///
    /// ## Iteratorên dirêjahiya têne zanîn
    ///
    /// Gava ku `Iterator` we `TrustedLen` bicîh dike û ji mezinahiyek rastîn e, dê ji bo `Rc<[T]>` veqetandekek yek were çêkirin.Bo nimûne:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Tenê veqetandinek tenê li vir çêdibe.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Specialization trait ji bo berhevkirina nav `Rc<[T]>` tê bikar anîn.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Ev rewş ji bo Xeberxebatkarek `TrustedLen` e.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // BELAW: Em hewce ne ku pê ewle bine ku dirêjahiya rastîn a iterator heye û em jî hene.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Li pêkanîna normal vegerin.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` guhertoyek [`Rc`] e ku referansek ne-xwedî li veqetandina birêvekirî digire.Dabeşandin bi bangkirina [`upgrade`] li ser pêşnumaya `Weak`, ku vedigere ["Vebijêrk"] ""<"["Rc"]"tête peyda kirin<T>>`
///
/// Ji ber ku referansek `Weak` ber bi xwedêbûnê ve nayê hesibandin, ew ê nehêle ku nirxê di veqetandinê de hatî hilanîn were avêtin, û `Weak` bixwe di derbarê nirxa ku hîn jî heye de ti garantî nade.
/// Bi vî rengî dibe ku ew [`None`] vegerîne dema ku [`nûvekirin`] d.
/// Lêbelê not bikin ku referansek `Weak`* * nahêle ku dabeşkirina xwe (pargîdaniya piştê) were veqetandin.
///
/// Nîşanek `Weak` bêyî ku pêşî li daketina nirxê hundurê wî bigire, ji bo parastina referansa demkî ya dabeşkirina ku ji hêla [`Rc`] ve tê rêve birin, kêrhatî ye.
/// Di heman demê de ew tê bikar anîn ku pêşî li referansên dorhêl ên di navbera [`Rc`] nîşanekan de bigire, ji ber ku çavkanîyên xwedan hevûdu qet nahêlin ku [`Rc`] were avêtin.
/// Mînakî, dibe ku darek ji girêkên dêûbavan bigire heya zarokan, û nîşankerên `Weak` jî ji zarokan vegerin dêûbavên xwe.
///
/// Awayê tîpîk ji bo peydakirina pêşnumayek `Weak` bangkirina [`Rc::downgrade`] ye.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Ev `NonNull` e ku destûrê dide ku mezinahiya vî rengî li enumê xweşbike, lê ew ne hewce ye ku pêşnumayek derbasdar be.
    //
    // `Weak::new` vê yekê li `usize::MAX` saz dike da ku ne hewce be ku cîhek li ser hepikê veqetîne.
    // Ew ne nirxek e ku pêşnîyarek rastîn dê her hebe, ji ber ku RcBox bi kêmî ve 2 rêzkirî ye.
    // Ev tenê dema `T: Sized` gengaz e;`T` bêserûber qet dangle nabe.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Bêyî ku bîranînek veqetîne, `Weak<T>` nû çêdike.
    /// Li ser nirxa vegerê bangkirina [`upgrade`] her gav dide [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Tîpa alîkar ku destûrê dide ku bigihîje hejmartinên referansê bêyî ku li ser qada daneyê tu îdîa bike.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Pointerek xav vedigere tişta `T` ya ku ji hêla vê `Weak<T>` ve hatî nîşankirin.
    ///
    /// Nîşanger heke hin referansên xurt hebin jî derbasdar e.
    /// Nîşanek bi rengek din dangling, bêserûber an jî heya [`null`] be.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Herdu jî heman tiştî nîşan dikin
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Hêza li vir wê zindî dihêle, ji ber vê yekê em hîn jî dikarin xwe bigihînin tiştê.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Lê ne bêtir.
    /// // Em dikarin weak.as_ptr() bikin, lê gihîştina pointer dê bibe sedema reftarek nediyarkirî.
    /// // assert_eq! ("silav", ne ewle {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Ger nîşander dangling be, em sentînel rasterast vedigerin.
            // Ev ne dikare navnîşanek barbar a derbasdar be, ji ber ku barkêş herî kêm bi qasî RcBox (usize) li hev hatî ye.
            ptr as *const T
        } else {
            // EWLEH: : ger is_dangling derewîn vegerîne, wê hingê nîşander dereferî ye.
            // Dibe ku di vê nuqteyê de payload were daxistin, û em neçar in ku pê re peydabûna xwe bidomînin, ji ber vê yekê manîpulasyona nîşana xav bikar bînin.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// `Weak<T>` dixwe û wê vediguherîne pêşnumayek rawe.
    ///
    /// Ev nîşanderê qels veguherîne pêşekek rawe, di heman demê de hîn jî xwedaniya referansek qels diparêze (jimara qels ji hêla vê operasyonê ve nayê guherandin).
    /// Ew dikare bi [`from_raw`] vegere `Weak<T>`.
    ///
    /// Heman sînorkirinên gihîştina hedefa nîşanderê wekî bi [`as_ptr`] re derbas dibe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Nîşanek raweya ku berê ji hêla [`into_raw`] ve hatî afirandin vedigerîne `Weak<T>`.
    ///
    /// Ev dikare were bikar anîn ku bi ewlehî referansek bihêz werbigire (bi bangkirina paşê [`upgrade`]) an jî daketina jimara qels a `Weak<T>` were avêtin.
    ///
    /// Ew xwediyê referansek qels e (ji xeynî nîşangirên ku ji hêla [`new`] ve hatine afirandin, ji ber ku ev ne xwediyê tiştekî ne; rêbaz hîn jî li ser wan dixebite).
    ///
    /// # Safety
    ///
    /// Pêdivî ye ku nîşander ji [`into_raw`] dest pê kiribe û hîn jî xwediyê referansa xweya qels a potansiyel be.
    ///
    /// Destûr tête dayîn ku jimartina bihêz di dema bangkirina vê de 0 be.
    /// Lêbelê, ev xwediyê referansek qels a ku niha wekî pêşnumayek rawe tê temsîl kirin digire (hejmarê qels ji hêla vê operasyonê ve nayê guherandin) û ji ber vê yekê divê ew bi banga berê ya [`into_raw`] re were hevber kirin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Hejmara qels a paşîn paşde bixin.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Weak::as_ptr binihêrin ji bo kontekstê ka nîşanderê têketinê çawa tête derxistin.

        let ptr = if is_dangling(ptr as *mut T) {
            // Ev Qelsek dangling e.
            ptr as *mut RcBox<T>
        } else {
            // Wekî din, ji me re misoger e ku pointer ji lawaziyek tinebûyî hat.
            // EWLEHIYA: daneya_offset ji bo bangkirinê ewledar e, ji ber ku referansên ptr rastîn (potansiyel ketî) T ye.
            let offset = unsafe { data_offset(ptr) };
            // Wiha, em berevajî berevajî dikin ku tevahiya RcBox bistînin.
            // EWLEHIYA: pointer ji Qelsiyek çêbû, lewma ev berdêl ewledar e.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // EWLEH: me nuha pêşnumaya Qels a xwerû peyda kir, ji ber vê yekê em dikarin Qelsê biafirînin.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Hewldanên ku nûvekerê `Weak` bi [`Rc`] nûve dikin, heke serfiraz daketina nirxa hundurîn taloq dike.
    ///
    ///
    /// Ger nirxa hundurîn ji wê paşde ketibe [`None`] vedigerîne.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Hemî nîşanên xurt hilweşînin.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Hejmara nîşangirên xurt (`Rc`) yên ku vê veqetandinê îşaret dikin digire.
    ///
    /// Ger `self` bi karanîna [`Weak::new`] hate afirandin, ev ê 0 vegerîne.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Hejmara nîşangirên `Weak` yên ku vê veqetandinê nîşan didin digire.
    ///
    /// Heke nîşanderên xurt nemînin, ev ê sifir vegerîne.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // ptr-ya qels a nepenî derxînin
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// `None` vedigerîne dema ku nîşander dangling e û `RcBox` veqetandî tune, (ango, dema ku ev `Weak` ji hêla `Weak::new` ve hate afirandin).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Em hişyar in ku *ne* referansek ku qada "data" vedigire biafirînin, ji ber ku dibe ku zevî bi hev re were guhertin (ji bo nimûne, heke `Rc` ya paşîn were avêtin, qada daneyê dê di cîh de were avêtin).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// `true` vedigerîne heke her du `Weq` s li ser dabeşkirinek yek nîşan bikin (dişibe [`ptr::eq`]), an heke her du jî li ser dabeşkirinekê venagerînin (ji ber ku ew bi `Weak::new()`) hatine afirandin.
    ///
    ///
    /// # Notes
    ///
    /// Ji ber ku ev nîşangiran dide ber hev ev tê vê wateyê ku `Weak::new()` dê hevûdu wekhev be, her çend ew nexşeya veqetandinê nîşan nedin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Berawirdkirina `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Xwerûya `Weak` davêje.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Tiştekî çap nake
    /// drop(foo);        // "dropped!" çap dike
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // hejmartina qels di 1-ê de dest pê dike, û dê tenê heke heke hemî nîşanên bihêz winda bibin dê biçin sifirê.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Klonek nîşanderê `Weak` çêdike ku îşaret bi heman veqetandinê dike.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// `Weak<T>` nû çêdike, bêyî destpêkirina bîranînê ji bo `T` veqetîne.
    /// Li ser nirxa vegerê bangkirina [`upgrade`] her gav dide [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Me li vir_kar kir ku em bi ewlehî bi mem::forget re mijûl bibin.Gelek rindik
// heke hûn mem::forget Rcs (an Weaks) bin, ref-jimartin dikare zêde bibe, û hingê hûn dikarin veqetandinê azad bikin dema ku Rcs (an Qels) ên berbiçav hene.
//
// Em kurtaj dikin ji ber ku ev senaryoyek wusa dejenerekirî ye ku em ji tiştê ku diqewime ne xema me ne-nabe ku tu bernameyek rastîn vê yekê biceribîne.
//
// Pêdivî ye ku ev serê we hindik be ji ber ku hûn ne hewce ne ku bi saya xwedaniyê û tevgera-semantîk van pir li Rust klon bikin.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Em dixwazin li şûna daketina nirxê li ser zêdebûnê kurt bikin.
        // Dema ku ji vê re were gotin hêjmara referansê dê carî sifir nebe;
        // Lêbelê, em li vir kurtajek têxin hundurê xwe da ku ji bo LLVM-ê optimîzasyonek bi vî rengî winda bibe.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Em dixwazin li şûna daketina nirxê li ser zêdebûnê kurt bikin.
        // Dema ku ji vê re were gotin hêjmara referansê dê carî sifir nebe;
        // Lêbelê, em li vir kurtajek têxin hundurê xwe da ku ji bo LLVM-ê optimîzasyonek bi vî rengî winda bibe.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Di nav `RcBox` de ji bo dravdana li paş pointer pêşkêşî bikin.
///
/// # Safety
///
/// Pêdivî ye ku pêşnîyar mînakek T-ya berê derbasdar nîşan bide (û ji bo vê yekê jî metadata derbasdar hebe), lê T destûr tê dayin.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Nirxa nevekirî bi dawiya RcBox-ê re rast bikin.
    // Ji ber ku RcBox repr(C) e, ew ê herdem di bîranînê de qada herî dawî be.
    // EWLEH: ji ber ku tenê celebên bêserûber ên gengaz qut in, tiştên trait ne,
    // û celebên derveyî, hewcedariya ewlehiya navnîşê nuha bes e ku daxwazên align_of_val_raw razî bike;ev hûrgulî ya pêkanînê ya zimên e ku dibe ku li derveyî std nayê bawer kirin.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}