#![stable(feature = "wake_trait", since = "1.51.0")]
//! Cure û Traits ji bo xebata bi erkên asinkron.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Pêkanîna şiyarbûna wezîfeyek li ser îcrakar.
///
/// Ev trait dikare were bikar anîn ku [`Waker`] were afirandin.
/// Pêkanînek dikare pêkanînek vê trait diyar bike, û wê bikar bîne ku Waker-ê ava bike da ku biçe ser erkên ku li ser wê îcraker têne meşandin.
///
/// Ev trait ji bo avakirina [`RawWaker`] alternatîfek bîranîn û ergonomîk e.
/// Ew piştgiriyê dide sêwirana cîbecîkar a hevpar ku tê de daneyên ku ji bo hişyarbûna karekî têne bikar anîn di [`Arc`] de têne hilanîn.
/// Hin darveker (nemaze yên ji bo pergalên bicîhkirî) nikarin vê API-yê bikar bînin, ji ber vê yekê jî [`RawWaker`] ji bo wan pergalê wekî alternatîf heye.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Fonksiyonek bingehîn a `block_on` ku future digire û li ser têleka heyî biqedîne.
///
/// **Note:** Ev mînak ji bo sadebûnê rastdariya bazirganiyê dike.
/// Ji bo pêşîgirtina li dorpêçan, pêkanînên pola hilberînê jî hewce dike ku bangên navbirî yên `thread::unpark` û hem jî bangên hêlînê bikin.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Akeriyariyek ku dema têlefonê têla heyî şiyar dibe.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Li ser mijara heyî future biqedînin û biqedînin.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // future pin bikin da ku were pirsîn.
///     let mut fut = Box::pin(fut);
///
///     // Naverokek nû biafirînin da ku derbasî future bibe.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // future biqedînin û biqedînin.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Vî erkê şiyar bikin.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Vê peywirê xwe bişewitînin bêyî ku waker vexwin.
    ///
    /// Ger îcrakar piştgirî dide awayek erzantir a şiyarbûnê bêyî ku waker vexwar, divê ew vê rêbazê ji holê rabike.
    /// Wekî standard, ew [`Arc`] klon dike û li klone [`wake`] bang dike.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // EWLEH: : Ji ber ku raw_waker bi ewlehî çêdike ev ewle ye
        // RawWaker ji Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Ev fonksiyona taybetî ji bo avakirina RawWaker, ji dêvla wê tê bikar anîn
// vê nav `From<Arc<W>> for RawWaker` impl bike, da ku ewlekariya `From<Arc<W>> for Waker` bi şandina rast trait ve ne girêdayî be, li şûna her du impls rasterast û eşkere vê fonksiyonê dibêjin.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Hejmara referansa arcê zêde bikin da ku wê klon bikin.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Ji hêla nirxê ve şiyar dibin, Arc dixe nav fonksiyona Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Bi referansê şiyar bibin, şûşê bi ManallyDrop ve girêdin da ku davêjin
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Li ser daketinê jimara referansa Arc kêm bikin
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}