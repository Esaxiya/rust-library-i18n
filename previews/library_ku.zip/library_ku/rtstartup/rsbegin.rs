// rsbegin.o û rsend.o bi navê "compiler runtime startup objects" in.
// Ew koda pêdivî ne ku bi rêkûpêk dema karûbarê berhevkar destpê dike.
//
// Dema ku wêneyek bicîhker an dylib ve girêdayî ye, hemî koda bikarhêner û pirtûkxaneyan di navbera van her du pelan de "sandwiched" hene, ji ber vê yekê koda an daneyên ji rsbegin.o di beşên pêwendîdar ên wêneyê de dibin yekem, lê kod û daneyên ji rsend.o dibin yên herî paşîn.
// Ev bandor dikare were bikar anîn ku sembolên li destpêkê an li dawiya beşek werin bicihkirin, û her weha ji bo têkela sernavan an pêpelokên hewce.
//
// Bala xwe bidinê ku xala ketina modulê ya rastîn di tişta destpêkirina C ya demjimêr de ye (bi gelemperî `crtX.o` tê gotin), ku paşê bangên destpêkirina pêkhateyên din ên demjimêranê (bi rêya beşa wêneya taybetî ya din ve hatî tomar kirin) bang dike.
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Destpêka çerxa stakê beşa agahdariyê vedikin
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Cihê diruşmeyê ji bo xwedîkirina pirtûkên navxweyî ya bêhempa.
    // Ev wekî `struct object` di $ GCC/unwind-dw2-fde.h de tête diyar kirin.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Rûtinên agahdariya registration/deregistration vekin.
    // Docs of libpanic_unwind binihêrin.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // li ser destpêkirina modulê agahdariyê vekin
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // li ser girtinê ji nû ve qeyd bikin
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Tomarbûna rûtîn a init/uninit-ya taybetî ya MinGW
    pub mod mingw_init {
        // Tiştên destpêkirina MinGW (crt0.o/dllcrt0.o) dê li beşên .ctors û .dtors li ser destpêkirin û derketinê avakarên cîhanî vexwendin.
        // Di mijara DLL-an de, dema ku DLL tête barkirin û barkirin, ev tête kirin.
        //
        // Zencîre dê beşan rêz bike, ku piştrast dike ku vegerên me li dawiya lîsteyê ne.
        // Ji ber ku çêker di rêza berevajî de têne xebitandin, ev piştrast dike ku vegerên me yên yekem û paşîn in.
        //
        //

        #[link_section = ".ctors.65535"] // .ktor. *: C bangên destpêkirina
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .doktor. *: C bangên bidawîbûna C
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}