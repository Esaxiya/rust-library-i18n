#![feature(no_core)]
#![no_core]

// Li rustc-std-workspace-core binihêrin ka çima ev crate hewce ye.

// Navê crate biguherînin da ku bi modulê dabeşkerê re liballoc nakok nebe.
extern crate alloc as foo;

pub use foo::*;