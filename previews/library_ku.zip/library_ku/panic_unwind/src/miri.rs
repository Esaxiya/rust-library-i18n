//! panics ji Miri re vekin.
use alloc::boxed::Box;
use core::any::Any;

// Cûreyek mûçeya ku motora Mîrî bi riya venekirinê ji bo me belav dike.
// Pêdivî ye ku pîvana pointer be.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Fonksiyona derveyî ya ji hêla Miri ve hatî peyda kirin da ku dest bi vebûnê bike.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Barkirina ku em ji `miri_start_panic` re derbas dibin dê bi rastî argumana ku em li jêr li `cleanup` bigirin.
    // Ji ber vê yekê em tenê carekê wê têxin stûyê xwe, da ku tiştek bi mezinahiya pointer bistînin.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // `Box` ya bingehîn vegerînin.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}