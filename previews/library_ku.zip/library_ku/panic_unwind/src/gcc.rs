//! Pêkanîna panics ku ji hêla libgcc/libunwind ve tê piştgirî kirin (bi rengek).
//!
//! Ji bo paşnavê karûbarê îstîsna û vekirina stack ji kerema xwe "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) û belgeyên ku jê ve girêdayî ne bibînin.
//! Vana jî xwendinên baş in:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## Kurtayiyek kurt
//!
//! Karanîna awarte di du qonaxan de dibe: qonaxek lêgerînê û qonaxek paqijkirinê.
//!
//! Di her du qonaxan de nexşerê bi karanîna agahdariya ji çerxa stackê ve beşa modulên pêvajoya niha (ji "module" li vir behsa moduleke OS-yê dike, ango pirtûkxaneya bicîhker an dînamîk) ji jor ber bi jêr ve dimeşe.
//!
//!
//! Ji bo her çerxa stakê, ew "personality routine"-ya têkildar, ya ku navnîşa wê jî di beşa agahdariya veneşartî de hatî hilanîn vedixwîne.
//!
//! Di qonaxa lêgerînê de, karê rûtînek kesayetiyê ev e ku tişta ku tê avêtin were vekolîn, û biryar bide ka ew ê di wê çerxa stakê de were girtin.Gava ku çarçovê kargêr hate destnîşankirin, qonaxa paqijkirinê dest pê dike.
//!
//! Di qonaxa paqijkirinê de, bêxîret her rûtînek kesayetiyê dîsa vedixwîne.
//! Vê carê ew biryar dide ka kîjan (heke hebe) koda paqijkirinê pêdivî ye ku ji bo çarçoveya stackê ya heyî were xebitandin.Ger wusa be, kontrol di laşê fonksiyonê de, li branch-ya taybetî tê veguheztin, "landing pad", ku hilweşîner bang dike, bîranînê azad dike, û hwd.
//! Di dawiya zeviyê dakêşanê de, kontrola paşîn veguhestin nûvekirinên nexşandî û nehêl.
//!
//! Gava ku stack heya asta çerxa kargêr bê vekirin, rawestandin vedibe û rûtîna kesayetiya paşîn kontrola xwe digihîne bloka nêçîrê.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Nasnameya çîna îstîsna ya Rust.
// Ev ji hêla rûtînên kesayetiyê ve tête bikar anîn da ku diyar bike ka îstîsna ji hêla dirêjahiya wan ve hatiye avêtin.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-firoşyar, ziman
    0x4d4f5a_00_52555354
}

// Nasnameyên tomarê ji bo her mîmariyê ji LLVM's TargetLowering::getExceptionPointerRegister() û TargetLowering::getExceptionSelectorRegister() hatin rakirin, dûv re bi navgîniya danasînên danasîna tomarê ji bo hejmarên tomara DWARF nexşe kirin (bi gelemperî<arch>RegisterInfo.td, li "DwarfRegNum" bigerin).
//
// http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register jî bibînin.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// Koda jêrîn li ser rûtînên kesayetiya C û C++ ya GCC ye.Ji bo referansê, binihêrin:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM Rûtîniya kesayetiya EHABI.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS ji ber ku ew SjLj bêhnvedanê bikar tîne şûna xweya rûtîn bikar tîne.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // Paşvegerînên li ser ARM dê rûtîna kesayetiyê ya bi dewlet binav bikin==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // Di wan rewşan de em dixwazin berdewamkirina neqandina stackê bimînin, nebe ku hemî paşde vekişandinên me dê bi __ bawerî_mal biqedin
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // DWARF bêhêvî difikire ku_Unwind_Context tiştên wekî fonksiyon û nîşankerên LSDA digire, lêbelê ARM EHABI wan dixe nav tiştê îstîsna.
            // Ji bo parastina îmzeyên fonksiyonên mîna _Unwind_GetLanguageSpecificData(), ku tenê nîşana kontekstê digire, rûtinên kesayetiyê yên GCC nîşangirekê vedişêrin da ku li naverastê_biber, di cîhê ku ji bo ARM's "scratch register" (r12) hatî veqetandin de veberhênerek veşêre.
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... Nêzîkatiyek prensîptir dê ew be ku di nav girêdanên me yên libunwind de pênasekirina tevahî ya_Unwind_Contera ARM-ê peyda bike û daneyên hewce ji wir rasterast bistîne, ji hêla fonksiyonên lihevhatina DWARF ve.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI hewce dike ku rûtîna kesayetiyê ji bo nûvekirina nirxa SP-ê di kaşka astenga tişta îstîsna de.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // Li ser ARM EHABI rûtîniya kesayetiyê berpirsiyar e ku berî vegerê vedibe ku çarçovê stakek yekpare veke (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // di libgcc de hatî diyarkirin
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // Rûtîniya kesayetiya nehf, ku rasterast li ser piraniya hedefan û neyekser li ser Windows x86_64 bi riya SEH tê bikar anîn.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // Li ser hedefên x86_64 MinGW, mekanîzmaya vekişînê SEH e lêbelê daneya hilkêşkerê vexwarinê (ango LSDA) şîfrekirina lihevhatî ya GCC bikar tîne.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // Rûtîna kesayetiyê ji bo piraniya armancên me.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // Navnîşana vegerê xala 1 byte ya borî talîmata bangê ye, ku dikare di rêzeya IP-ya din de di maseya rêzeya LSDA de be.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// Frame qeydkirina agahdariyê vekin
//
// Di wêneya her modulê de beşa agahdariyê ya vekirina çarçoveyê heye (bi gelemperî ".eh_frame").Dema ku modulek loaded/unloaded di pêvajoyê de ye, divê nexşer der barê cîhê vê beşê de di bîranînê de bê agahdarkirin.Rêbazên gihîştina ku ji hêla platformê ve têne guhertin.
// Li ser hinekan (mînakî, Linux), neçêker dikare bi serê xwe beşên agahdariyê vebîne kifş bike (bi jimartina dînamîkî modulên ku niha bi dl_iterate_phdr() API and finding their ".eh_frame" sections) barkirî ne; yên din jî, wekî Windows, pêdivî bi modulan heye ku bi navgîniya API-ya nederbasdar beşên agahdariya xweyên neçalak bi awayekî çalak tomar bikin.
//
//
// Vê modulê du sembolên ku ji rsbegin.rs têne referansandin û gazî kirin diyar dike ku agahdariya me bi dema xebata GCC re tomar bike.
// Pêkanîna rakirina stackê (ji bo naha) ji libgcc_eh re tê taloq kirin, lêbelê Rust crates van nuqteyên ketinê yên taybetî Rust bikar tîne da ku ji pevçûnên potansiyel ên bi demek GCC re dûr bikeve.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}