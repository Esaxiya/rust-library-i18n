//! Pêkanîna panics bi riya vekêşana stack
//!
//! Ev crate pêkanîna panics ye li Rust bi karanîna mekanîzmaya neqandina "most native" stacka platforma ku ji bo vê tê berhev kirin.
//! Ev bi piranî di nav sê kepçeyan de dabeş dibe:
//!
//! 1. Armancên MSVC di pelê `seh.rs` de SEH bikar tînin.
//! 2. Emscripten di pelê `emcc.rs` de îstisnayên C++ bikar tîne.
//! 3. Hemî armancên din di pelê `gcc.rs` de libunwind/libgcc bikar tînin.
//!
//! Di derbarê her bicîhkirinê de bêtir belgekirin di modulê peywendîdar de têne dîtin.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` bi Miri re nayê bikar anîn, ji ber vê yekê hişyariyên bêdengiyê.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Rust tiştên destpêkirinê yên rûtînê bi van sembolan ve girêdayî ne, ji ber vê yekê wan eşkere bikin.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Armancên ku piştgirî nadin vekirinê.
        // - arch=wasm32
        // - os=tune (armancên "bare metal")
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Runtime Miri bikar bînin.
        // Em hîn jî hewce ne ku demjimêra normal li jor jî barkirin, ji ber ku rustc hêvî dike ku hin tiştên lang ji wir werin diyar kirin.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Dema rastîn bikar bînin.
        use real_imp as imp;
    }
}

extern "C" {
    /// Handler di libstd de gazî dike dema ku tiştek panic li derveyî `catch_unwind` tê avêtin.
    ///
    fn __rust_drop_panic() -> !;

    /// Handler di libstd de gazî kir dema ku îstisnayek biyanî tê girtin.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Xala têketinê ya ji bo mezinkirina îstîsnayekê, tenê ji bo pêkanîna platform-taybetî delegeyan dike.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}