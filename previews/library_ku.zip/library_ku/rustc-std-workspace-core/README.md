# `rustc-std-workspace-core` crate

Ev crate crate şemitok û vala ye ku bi tenê bi `libcore` ve girêdayî ye û hemî naveroka wê ji nû ve dişîne.
crate bingeha bihêzkirina pirtûkxaneya standard e ku ji 0crates ji crates.io ve girêdayî ye

Crates li ser crates.io ku pirtûkxaneya standard bi hewceyê ve girêdayî ye ku bi `rustc-std-workspace-core` crate ji crates.io ve girêdayî be, ku vala ye.

Em `[patch]` bikar tînin da ku wê li vê crate-ê li vê depoyê derbas bikin.
Wekî encamek, crates li ser crates.io dê girêdana edge bi `libcore` ve bikişîne, guhertoya ku li vê depoyê hatî diyarkirin.
Divê ew hemî deviyên girêdanê bikişînin da ku Cargo crates bi serkeftî ava bike!

Zanibe ku crates li ser crates.io hewce ye ku bi vê crate ya bi navê `core` ve girêdayî be ku her tişt rast bixebite.Ji bo vê yekê ew dikarin bikar bînin:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Bi navgîniya karanîna kilîta `package` navê crate li `core` tê guhertin, ango wê wusa xuya bike

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

dema Cargo berhevkar bang dike, rêwerzê nehfî ya `extern crate core` ya ku ji hêla berhevkar ve hatî derzandin têr dike.




