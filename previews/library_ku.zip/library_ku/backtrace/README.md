# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Pirtûkxaneyek ku ji bo Rust di dema karûbarê de paşde vedigere.
Vê pirtûkxaneyê armanc dike ku bi pêşkêşkirina navgînek bernameyek ku pê re bixebite, piştgiriya pirtûkxaneya standard zêde bike, lê ew di heman demê de piştgirî dide ku bi hêsanî çapkirina paşdeçûna heyî ya mîna panics ya libstd.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Ji bo ku bi hêsanî vegerek paşde bikişînin û danûstendina bi wê re taloq bikin heya demek paşê, hûn dikarin tîpa `Backtrace`-asta jor bikar bînin.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Lêbelê, hûn dixwazin bêtir gihîştina rahijmendiyê ya karbidestiya şopandina rastîn, hûn dikarin fonksiyonên `trace` û `resolve` rasterast bikar bînin.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Vê nîşana talîmatê bi navekî sembolan çareser bikin
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // herin çerçova paşîn
    });
}
```

# License

Ev proje di bin yan ji

 * Lîsansa Apache, Guhertoya 2.0, ([LICENSE-APACHE](LICENSE-APACHE) an http://www.apache.org/licenses/LICENSE-2.0)
 * Lîsansa MIT ([LICENSE-MIT](LICENSE-MIT) an http://opensource.org/licenses/MIT)

li vebijarka we.

### Contribution

Heya ku hûn bi zelalî berevajî vê yekê nebêjin, her tevkariyek ku ji hêla we ve ji bo tevlêbûnê di vegeriyan-rs de hatî şandin, wekî ku di lîsansa Apache-2.0 de hatî diyarkirin, dê wekî jorîn, bêyî şert û mercên din, du destûr hebe.







