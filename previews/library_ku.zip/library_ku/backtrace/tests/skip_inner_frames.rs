use backtrace::Backtrace;

// Vê ceribandinê tenê li ser platformên ku fonksiyona wan `symbol_address` dixebite ji bo çerxên ku navnîşana destpêkirina sembolê radigihîne dixebite.
// Wekî encamek ew tenê li ser çend platforman tête çalak kirin.
//
const ENABLED: bool = cfg!(all(
    // Windows bi rastî nehatiye ceribandin, û OSX piştgirî nake bi rastî dîtina çarçoveyek dorpêçkirî, lewma vê yekê neçalak bike
    //
    target_os = "linux",
    // Li ser ARM dîtina fonksiyona dorpêçê tenê vegerandina ip-ê bixwe ye.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}