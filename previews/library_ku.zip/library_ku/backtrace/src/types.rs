//! Cûreyên girêdayî platformê.

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// Nûneriyek serbixwe ya platformê ya têlek.
/// Dema ku bi `std`-ê re çalak xebitandin ji bo peydakirina veguherînan li celebên `std`-ê ji bo rêbazên hêsantir tê pêşniyar kirin.
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// Parçeyek, bi gelemperî li ser platformên Unix tête peyda kirin.
    Bytes(&'a [u8]),
    /// Têlên fireh bi gelemperî ji Windows.
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// Lossy veguherîne `Cow<str>`, dê veqetîne heke `Bytes` UTF-8 ne derbasdar e an `BytesOrWideString` `Wide` e.
    ///
    /// # Taybetmendiyên pêdivî
    ///
    /// Vê fonksiyonê hewce dike ku taybetmendiya `std` ya `backtrace` crate were çalak kirin, û taybetmendiya `std` bi default ve hatî çalak kirin.
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// Nûnerê `Path` ya `BytesOrWideString` peyda dike.
    ///
    /// # Taybetmendiyên pêdivî
    ///
    /// Vê fonksiyonê hewce dike ku taybetmendiya `std` ya `backtrace` crate were çalak kirin, û taybetmendiya `std` bi default ve hatî çalak kirin.
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}