#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Formatorek ji bo paşde vegerandin.
///
/// Ev celeb dikare bê karanîn ka paşde veger ji kuderê tê ji bo çapkirina paşmayek tê bikar anîn.
/// Ger celebek weya `Backtrace` hebe wê hingê pêkanîna `Debug` jixwe vê formata çapkirinê bikar tîne.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Theêwazên çapkirinê ku em dikarin çap bikin
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Vegerekî terser ku bi îdeal tenê agahdariya pêwendîdar tê de heye çap dike
    Short,
    /// Vegerekî ku hemî agahdariya gengaz tê de heye çap dike
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// `BacktraceFmt`-ya nû çêbikin ku dê encam ji `fmt`-ya dabînkirî re binivîse.
    ///
    /// Nîqaşa `format` dê şêwazê ku paşnav hatî çap kirin kontrol bike, û argumana `print_path` dê were bikar anîn ku nimûneyên pelên navnîşên `BytesOrWideString` çap bike.
    /// Vê celeb bixwe ti çapkirina navên pelan nake, lê ji bo vê yekê ev vegerandin hewce ye.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Pêşgotinek ji bo paşperdeya ku dê were çap kirin çap dike.
    ///
    /// Vê yekê li ser hin platforman hewce dike ku paşverû paşê bi tevahî bêne sembolîkirin, û wekî din ev tenê pêdivî ye ku yekem rêbaza ku hûn bang dikin piştî afirandina `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Çarçûvekê li derketina paşverû zêde dike.
    ///
    /// Vê peywirê nimûneyek RAII ya `BacktraceFrameFmt` vedigerîne ku dikare were bikar anîn ku bi rastî çarçoveyek çap bike, û li ser hilweşînê ew ê jimara çarçoveyê zêde bike.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Derketina paşvemayînê temam dike.
    ///
    /// Vêga naha vebijarkek tune lê ji bo lihevhatina future bi formatên paşde vezêde kirin.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Naha na-op-- ev hook jî tê de ye ku destûr bide lêzêdekirinên future.
        Ok(())
    }
}

/// A formatter ji bo tenê yek frame of a backtrace.
///
/// Ev celeb ji hêla fonksiyona `BacktraceFmt::frame` ve tê afirandin.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// `BacktraceFrame` bi vê formatkirina çarçoveyê çap dike.
    ///
    /// Ev dê bi vegerînî hemî nimûneyên `BacktraceSymbol` di nav `BacktraceFrame` de çap bike.
    ///
    /// # Taybetmendiyên pêdivî
    ///
    /// Vê fonksiyonê hewce dike ku taybetmendiya `std` ya `backtrace` crate were çalak kirin, û taybetmendiya `std` bi default ve hatî çalak kirin.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Di nav `BacktraceFrame` de `BacktraceSymbol` çap dike.
    ///
    /// # Taybetmendiyên pêdivî
    ///
    /// Vê fonksiyonê hewce dike ku taybetmendiya `std` ya `backtrace` crate were çalak kirin, û taybetmendiya `std` bi default ve hatî çalak kirin.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: ev ne baş e ku em di encamê de tiştek çap nakin
            // bi navên pelên ne-utf8.
            // Ji kerema xwe hema hema her tişt utf8 e ji ber vê yekê divê ne pir xerab be.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// `Frame` û `Symbol` a şopandî ya xav çap dike, bi gelemperî ji nav paşvegerên paşîn ên vê crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Çarçûvek raweyî li derketina paşverû zêde dike.
    ///
    /// Ev rêbaz, berevajî ya berê, argumanên raweyî digire heke ew ji deverên cûda werin jêder kirin.
    /// Zanibe ku ev ji bo yek çarçoveyê dikare gelek caran were gotin.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Di nav de agahdariya stûnê de çarçoveyek xav li derketina paşmayiyê zêde dike.
    ///
    /// Ev rêbaza hanê, mîna ya berê, argumanên raweyî digire heke ew ji deverên cûda werin jêder kirin.
    /// Zanibe ku ev ji bo yek çarçoveyê dikare gelek caran were gotin.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia nekare di nav pêvajoyekê de sembolîze bike ji ber vê yekê ew xwedan formatek taybetî ye ku dikare paşê were sembolîzekirin.
        // Li şûna çapkirina navnîşanên di formata xweya xwe de li vir çap bikin.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Ne hewce ye ku çarçovên "null" çap bikin, ew di bingeh de tenê tê vê wateyê ku vegera pergalê hinekî dilxwaz bû ku super dûr bişopîne.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Ji bo ku mezinkirina TCB-ê di dorpêça Sgx-ê de kêm bikin, em naxwazin karbidestiya çareseriya sembolê pêk bînin.
        // Belê, em dikarin li vir navnîşana navnîşanê çap bikin, ku paşê dikare ji bo rastkirina fonksiyonê were nexşekirin.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Indeksa çarçoveyê û her weha nîşana rahijmendiya vebijarkî ya çarçoveyê çap bikin.
        // Ger em li derveyî sembola yekem a vê çarçoveyê ne her çend em tenê qada spî ya guncan çap dikin.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Dûv re navê sembolê binivîsin, ji bo bêtir agahdarî karanîna formata alternatîf bikar bînin heke em vegerek paşîn in.
        // Li vir em sembolên ku navê wan tune jî digirin dest,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Last dom bikin, heke hebin hejmar filename/line çap bikin.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line di bin navê sembolê de li ser rêzikan têne çap kirin, ji ber vê yekê hin cîhê spî guncan çap bikin da ku xwe rast-rast bikin.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Delegeyê vegera meya navxweyî bikin da ku navê pelê çap bikin û dûv re jî hejmara rêzê çap bikin.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Heke hebe hebe, hejmara stûnê zêde bikin.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Em tenê tenê li ser sembolê yekem a çarçoveyê difikirin
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}