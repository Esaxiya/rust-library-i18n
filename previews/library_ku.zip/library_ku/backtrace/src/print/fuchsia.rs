use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr vexwendinek digire ku dê ji bo her DSO-yê ku bi pêvajoyê ve hatî girêdan pêşnumayek dl_phdr_info bistîne.
    // dl_iterate_phdr di heman demê de piştrast dike ku girêdana dînamîk ji destpêk heya dawî ya dubarekirinê girtî ye.
    // Ger veger bangek ne-sifir vegerîne dubarekirin zû bi dawî dibe.
    // 'data' dê wekî argumana sêyemîn ji bo vegera li ser her bangê re were derbas kirin.
    // 'size' mezinahiya dl_phdr_info dide.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Em hewce ne ku nasnameya avahiyê û hin daneyên sernavê bernameya bingehîn ku ev tê wê wateyê ku ji me re piçek tişt ji pisporiya ELF-ê jî hewce dike.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Naha em neçar in ku, bit bi bit, avahiya celebê dl_phdr_info ku ji hêla girêdana dînamîk a fuchsia-ya heyî ve tê bikar anîn dubare bikin.
// Chromium jî ev tixûbê ABI-ê û hem jî qeşayê heye.
// Di dawiyê de em dixwazin van dozan bar bikin da ku elf-lêgerînê bikar bînin lê em ê hewce bikin ku ew di SDK de peyda bikin û ew hîn nehatiye kirin.
//
// Ji ber vê yekê em (û ew) neçar in ku vê rêbaza ku bi fuchsia libc re têkildariyek teng bikar tîne bikar bînin.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Çu awayek me tune ku em bizanibin ka e_phoff û e_phnum derbasdar in an na.
    // divê libc vê yekê ji me re misoger bike lê ji ber vê yekê ewle ye ku meriv li vir perçeyek çêbike.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr di dawiya endeziya mîmariya hedef de sernavek bernameyek ELF 64-bit nîşan dike.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr sernavek bernameya derbasdar a ELF û naveroka wê temsîl dike.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Çu awayek me tune ku em kontrol bikin ka p_addr an p_memsz derbasdar in.
    // Libc-a Fuchsia-yê yekem notan parsek dike lêbelê ji ber vê yekê ji ber ku li vir in divê ev sernav derbasdar bin.
    //
    // NoteIter hewce nake ku daneya bingehîn derbasdar be lê ew hewce dike ku sînor derbasdar bin.
    // Em bawer dikin ku libc piştrast kiriye ku li vir rewşa me ev e.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Ji bo nasnameyên avahiyê celebê nîşeyê.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr di dawiya dawîn a hedefê de sernavek nîşeyek ELF temsîl dike.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Nîşe nîşeyek ELF (sernav + naverok) temsîl dike.
// Nav wekî pişkek u8 tê hiştin ji ber ku her dem betal nayê qedandin û rust têra xwe hêsan dike ku kontrol bike ka her ku diçe bayît têne hev.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter dihêle hûn bi ewlehî li ser perçeyek nîşeyê dubare bikin.
// Ew zû xelas dibe ku çewtiyek çêdibe an jî bêtir not hene.
// Heke hûn li ser daneyên nederbasdar dubare bikin ew ê fonksiyon bike wekî ku notek nehatine dîtin.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Ew fonksiyonek neguhêrbar e ku nîşander û mezinahiya hatî dayîn rêzeyek derbasdar a bayîtan destnîşan dike ku hemî dikarin werin xwendin.
    // Naveroka van byteyan dikare her tişt be lê divê rêze ji bo ku ewledar be derbasdar be.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to aligns 'x' to 'to'-byte alignment ku 'to' hêza 2-ê ye.
// Ev li şîfreya standard a C/C ++ ELF koda parsekirinê ya ku (x + ber, 1)&-to tê bikar anîn dişopîne.
// Rust nahêle hûn karanîna xwe înkar bikin ji ber vê yekê ez bikar tînim
// Zivirandina 2-têrker ku wê ji nû ve çêbike.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 hejmarek byteyan ji perçeyê dixwe (heke hebe) û ji bilî vê yekê jî piştrast dike ku perçeya dawîn bi rêkûpêk hatî rastandin.
// Heke an jî hejmara baytên ku hatine xwestin pir mezin e an jî pişk ji ber ku bayîtên mayî ne mayî ne dikarin ji nû ve werin rastandin, Yek nayê vegerandin û perçe nayê guherandin.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Vê fonksiyonê neguhêrînên rastîn tune ku bangvan divê piştgirî bike ji xeynî ku divê 'bytes' ji bo performansê were yekalîkirin (û li ser rastbûna hin avahiyan).
// Nirxên di zeviyên Elf_Nhdr de dibe ku pûç bin lê ev fonksiyon tiştek wusa piştrast nake.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Ev ewledar e heya ku cîh bes hebe û me tenê piştrast kir ku di daxuyaniya if a li jor de ji ber vê yekê divê ew ne ewledar be.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Zanibe ku sice_of: :<Elf_Nhdr>() her dem bi 4-byte tête rêz kirin.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Kontrol bikin ka em gihîştine dawiyê.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Em nhdr transmute dikin lê em bi hûrgulî struktura encam digirin ber çavan.
        // Em bi namesz an descsz bawer nakin û li gorî celebê em biryarên ewledar nadin.
        //
        // Ji ber vê yekê heke em zibilên tevahî derxînin jî divê em hîna ewle bin.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Nîşan dide ku perçeyek darveker e.
const PERM_X: u32 = 0b00000001;
/// Nîşan dide ku beşek nivîsandî ye.
const PERM_W: u32 = 0b00000010;
/// Nîşan dide ku beşek tê xwendin.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Di dema demdirêjê de beşek ELF-ê temsîl dike.
struct Segment {
    /// Navnîşana rastîn a rûnteyê ya naverokên vê beşê dide.
    addr: usize,
    /// Mezinahiya bîranîna naverokên vê beşê dide.
    size: usize,
    /// Navnîşana virtual a vê beşê ya module bi pelê ELF dide.
    mod_rel_addr: usize,
    /// Destûrên ku di pelê ELF de hatine dîtin dide.
    /// Lêbelê ev destûr ne hewce ne ku destûrên di dema dirêsînê de hene.
    flags: Perm,
}

/// Bila yek li ser Dabeşên ji DSO dubare bike.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// ELF DSO (Tiştek Dînamîk Parvekirî) Nûner dike.
/// Ev celeb ji dêvla ku kopiyek xwe çêbike, referansa daneyên ku di DSO-ya rastîn de hatine hilanîn dide.
struct Dso<'a> {
    /// Zencîreya dînamîk hertim navek dide me, heke nav vala be jî.
    /// Di mijara darvekerê sereke de ev nav dê vala be.
    /// Di mijara tiştek hevpar de ew ê soname be (li DT_SONAME binihêrin).
    name: &'a str,
    /// Li ser Fuchsia bi rastî hemî binary xwedî nasname ne lê ev daxwazek hişk nine.
    /// Çu rê tune ku meriv agahdariya DSO bi pelê ELF-yê rastîn re hev bike heke avahî_av tune be ji ber vê yekê em hewce dikin ku her DSO li vir hebe.
    ///
    /// DSO'yên bêyî avahî_bar têne paşguh kirin.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Iterator li ser Dabeşên vê DSO vedigerîne.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Van çewtî pirsgirêkên ku derdikevin holê dema ku agahî li ser her DSO têne parsekirin.
///
enum Error {
    /// Wateya NameError ev e ku çewtiyek çêdibe dema ku têl C şêwazî têl rust veguherîne.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError tê vê wateyê ku me nasnameyek avahiyê nedît.
    /// Ev dibe yan ji ber ku nasnameya avahiyê ya DSO tune bû an jî ji ber ku beşa ku nasnameya avahiyê tê de bû çewt bû.
    ///
    BuildIDError,
}

/// Ji bo her DSO ji hêla pêveka dînamîk ve girêdayî pêvajoyê an 'dso' an 'error' bang dike.
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter-ê ku yek ji wan rêbazên ku jê re foreach DSO tê gotin heye.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr piştrast dike ku info.name dê cîhek derbasdar nîşan bide.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Ev fonksiyon ji bo hemî agahdariyên ku di DSO de ne, nîşana sembola Fuchsia çap dike.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}