use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Navnîşanek ji sembolek re çareser bikin, û sembola xwe digirin ber girtina diyarkirî.
///
/// Ev fonksiyon dê li navnîşana hatî dayîn li deverên wekî tabloya sembola herêmî, tabloya sembola dînamîk, an agahdariya xeletiya DWARF (li gorî pêkanîna aktîfkirî ye) bigere da ku sembolên hilberînê bibîne.
///
///
/// Heke çareserî neyê pêkanîn dibe ku girtî neyê gazîkirin, û her weha dibe ku di mijara fonksiyonên rêzkirî de ji yekê zêdetir carek jî bê gotin.
///
/// Simbêlên hatine hilberandin darvekirina li `addr` ya diyarkirî temsîl dikin, ji bo wê navnîşanê cotên file/line vedigirin (heke hebe).
///
/// Zanibe ku heke `Frame`-a te hebe wê hingê tê pêşniyarkirin ku li şûna vê yekê fonksiyona `resolve_frame`-ê bikar bînin.
///
/// # Taybetmendiyên pêdivî
///
/// Vê fonksiyonê hewce dike ku taybetmendiya `std` ya `backtrace` crate were çalak kirin, û taybetmendiya `std` bi default ve hatî çalak kirin.
///
/// # Panics
///
/// Ev fonksiyon hewl dide ku tu carî panic neke, lê heke `cb` panics peyda kir wê hingê hin platform dê panic du qat zorê bidin pêvajoyê.
/// Hin platform pirtûkxaneya C bikar tînin ku di hundurê xwe de paşnavên ku bi navgîniya wan nayê vedan bikar tîne, ji ber vê yekê panîkirina ji `cb` dikare pêvajoyê betal bike.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // tenê li çarçoveya jorîn binihêrin
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Çarçuvek girtinê ya berê bi sembolek çareser bikin, sembolê derbasê girtina diyarkirî bikin.
///
/// Ev functin heman fonksiyonê wekî `resolve` pêk tîne ji bilî ku ew li şûna navnîşanek wekî argumanek digire `Frame`.
/// Ev dikare bihêle ku hin pêkanînên platformê yên paşvekêşandinê ji bo nimûne agahdariya sembolê an agahdariya der barê çarçoveyên inline de rasttir peyda bikin.
///
/// Ger hûn bikaribin pêşniyar dikin ku vê yekê bikar bînin.
///
/// # Taybetmendiyên pêdivî
///
/// Vê fonksiyonê hewce dike ku taybetmendiya `std` ya `backtrace` crate were çalak kirin, û taybetmendiya `std` bi default ve hatî çalak kirin.
///
/// # Panics
///
/// Ev fonksiyon hewl dide ku tu carî panic neke, lê heke `cb` panics peyda kir wê hingê hin platform dê panic du qat zorê bidin pêvajoyê.
/// Hin platform pirtûkxaneya C bikar tînin ku di hundurê xwe de paşnavên ku bi navgîniya wan nayê vedan bikar tîne, ji ber vê yekê panîkirina ji `cb` dikare pêvajoyê betal bike.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // tenê li çarçoveya jorîn binihêrin
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Nirxên IP-ê ji çarçoveyên stackê bi gelemperî (always?) talîmata *piştî* banga ku şopa stackê ya rastîn e.
// Vê li ser sembolîzekirin dibe sedema ku hejmara filename/line li pêş be û dibe ku li valahiyê be ger ew nêzê dawiya fonksiyonê be.
//
// Ev xuya dike ku di bingeh de her gav li ser hemî platforman wiha ye, ji ber vê yekê em her dem yek ji ip-a çareserkirî dadigirin da ku wê li şûna talîmata ku lê vedigere wê bi talîmata banga berê re çareser bikin.
//
//
// Bi îdeal em ê vê yekê nekin.
// Bi îdeal em ê ji bangkerên API-yên `resolve` li vir hewce bikin ku bi destan -1 bikin û hesab bikin ku ew ji bo talîmata *berê*, ne ya heyî, agahdariya cîhê dixwazin.
// Bi îdeal em ê `Frame` jî derxînin holê heke em bi rastî navnîşana talîmata paşîn an a niha ne.
//
// Ji bo naha her çend ev xemgîniyek xweşik e ji ber vê yekê em tenê di hundurê xwe de hertim yekê jê dikin.
// Pêdivî ye ku serfkar bixebitin û encamên xweş baş bistînin, ji ber vê yekê divê em têra xwe baş bin.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Heman wekî `resolve`, tenê ne ewle ye ku ew ne-hevdemkirî ye.
///
/// Vê fonksiyonê garantorên hevdemkirinê tune lê dema ku taybetmendiya `std` ya vê crate neyê berhev kirin heye.
/// Ji bo bêtir belgekirin û mînakan fonksiyona `resolve` bibînin.
///
/// # Panics
///
/// Agahdariya li ser `resolve` ji bo hişyariyên li ser panîkirina `cb` bibînin.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Heman wekî `resolve_frame`, tenê ne ewle ye ku ew ne-hevdemkirî ye.
///
/// Vê fonksiyonê garantorên hevdemkirinê tune lê dema ku taybetmendiya `std` ya vê crate neyê berhev kirin heye.
/// Ji bo bêtir belgekirin û mînakan fonksiyona `resolve_frame` bibînin.
///
/// # Panics
///
/// Agahdariya li ser `resolve_frame` ji bo hişyariyên li ser panîkirina `cb` bibînin.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait çareseriya sembolek di pelê de temsîl dike.
///
/// Ev trait ji ber girtina ku ji fonksiyona `backtrace::resolve` re hatî dayîn wekî tiştek trait tête hilberandin, û ew bi rastî tête şandin ji ber ku nayê zanîn ka kîjan pêkanîn li pişta wê ye.
///
///
/// Nîşanek dikare di derheqê fonksiyonekê de agahdariya çarçoveyî bide, mînakî nav, navê pelê, hejmara rêzê, navnîşa rastîn, hwd.
/// Ne ku hemî agahdarî her dem di sembolek de hene, lêbelê, ji ber vê yekê hemî rêbaz `Option` vedigerin.
///
///
pub struct Symbol {
    // TODO: ev girêdana jiyanê pêdivî ye ku heya `Symbol` were domandin,
    // lê ew naha guherînek şkestî ye.
    // Çimkî naha ewle ewle ye ji ber ku `Symbol` tenê bi referansê ve hatî desteser kirin û nayê klon kirin.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Navê vê fonksiyonê vedigire.
    ///
    /// Avahiya vegeriyayî dikare were bikar anîn ku ji taybetmendiyên cihêreng ên li ser navê sembolê bipirsin:
    ///
    ///
    /// * Pêkanîna `Display` dê sembola demangled çap bike.
    /// * Nirxa xav a sembola xav dikare were destgirtin (heke ew utf-8 derbasdar be).
    /// * Bîtên raweyên ji bo navê sembolê têne peyda kirin.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Navnîşana destpêkê ya vê fonksiyonê vedigire.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Navê pelê xav wekî perçeyek vedigerîne.
    /// Ev bi taybetî ji bo derdorên `no_std` bikêr e.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Hejmara stûnê vedigerîne cihê ku ev sembol niha lê bicîh tîne.
    ///
    /// Tenê gimli nuha li vir nirxek peyda dike û wê hingê jî tenê heke `filename` `Some` vegerîne, û ji ber vê yekê jî wê hingê bi şopên bi vî rengî re têkildar dibe.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Hejmara rêzê ji bo ku ev sembol niha lê bicîh tîne vedigerîne.
    ///
    /// Vê nirxa vegerê bi gelemperî `Some` e heke `filename` `Some` vegerîne, û di encamê de bi vegotinên bi vî rengî re têkildar e.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Navê pelê ku ev fonksiyon lê diyar bû vedigerîne.
    ///
    /// Ev naha tenê dema ku libbacktrace an gimli tê bikar anîn heye (mînak
    /// unix platformên din) û dema ku binaryek digel debuginfo tête berhev kirin.
    /// Ger yek ji van mercan pêk neyê wê hingê ev ê gengaz vegere `None`.
    ///
    /// # Taybetmendiyên pêdivî
    ///
    /// Vê fonksiyonê hewce dike ku taybetmendiya `std` ya `backtrace` crate were çalak kirin, û taybetmendiya `std` bi default ve hatî çalak kirin.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Dibe ku sembolek parsekirî ya C++ , heke parsekkirina sembola mangled wekî Rust têk çû.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Vê guman bikin ku hûn vê sifirê-sized biparêzin, da ku taybetmendiya `cpp_demangle` dema betal nebe lêçûn tune.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Dorpêçek li dora navnîşek sembolê da ku peydakirên ergonomîk bi navê demangled, byteyên xav, têla xav û hwd peyda bikin.
///
// Dema ku taybetmendiya `cpp_demangle` ne çalak be bila kodê mirî bihêle.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Navê sembolê nû ji bytên binyadê yên xav diafirîne.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Ger sembola utf-8 derbasdar be navê sembola (mangled) ya xav vedigerîne wekî `str`.
    ///
    /// Heke hûn guhertoya demangled dixwazin, pêkanîna `Display` bikar bînin.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Navê sembola xav wekî lîsteyek byteyan vedigerîne
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Ev dibe ku were çapkirin heke sembola demangled ne rast derbasdar be, ji ber vê yekê xeletiyê li vir bi nermî rêve bikin û li derveyî belav nakin.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Hewldana vegerandina wê bîra kaşkirî ku ji bo sembolîkirina navnîşanan tê bikar anîn.
///
/// Ev rêbaz dê hewl bide ku avahiyên daneyên gerdûnî yên ku bi awayek din li seranserê cîhanê an jî di têlên ku bi gelemperî agahdariya parsekirî ya DWARF-an an wekî din temsîl kirine de, were vekişandin.
///
///
/// # Caveats
///
/// Dema ku ev fonksiyon hertim heye ew bi rastî li ser pir pêkanînan tiştek nake.
/// Pirtûkxaneyên mîna dbghelp an libbacktrace ji bo veqetandina dewletê û birêvebirina bîranîna veqetandî ve hêsankarî peyda nakin.
/// Ji bo naha taybetmendiya `gimli-symbolize` ya vê crate tenê taybetmendiyek e ku li vê fonksiyonê bandorek heye.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}