// tenê niha li ser Linux tê bikar anîn, ji ber vê yekê kodê mirî li cîhek din bihêle
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Dabeşkerê arene yê hêsan ji bo tamponên byte.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Tamponek bi mezinahiya diyarkirî veqetîne û referansa guherbar jê re vegerîne.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // EWLEH: ev fonksiyona yekane ye ku her gav mutabileyek çêdike
        // referansa `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // EWLEH: em çu caran hêmanan ji `self.buffers` nakin, ji ber vê yekê jî referans
        // ji bo daneyên hundurê her tampon dê heya ku `self` dijî bimîne.
        &mut buffers[i]
    }
}