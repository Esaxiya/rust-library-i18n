use core::ffi::c_void;
use core::fmt;

/// Banga-stacka heyî kontrol dike, hemî çarçewên çalak di hundurê dorpêçê de derbas kirî da ku şopek stackê hesab bike.
///
/// Ev fonksiyon di hesibandina şopên stackê ji bo bernameyekê de xebata vê pirtûkxaneyê ye.`cb` dorpêçê hatî dayîn ji nimûneyên `Frame`-ê tête agahdar kirin ku agahdariya di derbarê wê çerxa bangê ya li ser stackê de temsîl dike.
/// Girtîgeh bi rengek ji jor-jor ve çarçoveyan dide (ya herî dawî herî pêşîn ji fonksiyonan re tê gotin).
///
/// Nirxa vegera girtinê nîşana wê yekê ye ku gelo paşve gav divê berdewam bike.Nirxek vegera `false` dê paşvekişînê biqedîne û tavilê vegere.
///
/// Gava ku `Frame` hate stendin hûn ê gengaz bixwazin ku li `backtrace::resolve` bigerin da ku `ip` (nîşana talîmatê) an navnîşana sembolê bi `Symbol` veguherîne ku bi navnîşê navnîş û/an navnîşa pelê/rêzê ve tête fêr kirin.
///
///
/// Bala xwe bidinê ku ev fonksiyonek kêm-astî ye û heke hûn dixwazin, ji bo nimûne, vegerandinek paşde bikişînin ku paşê were kontrol kirin, hingê dibe ku celebê `Backtrace` guncantir be.
///
/// # Taybetmendiyên pêdivî
///
/// Vê fonksiyonê hewce dike ku taybetmendiya `std` ya `backtrace` crate were çalak kirin, û taybetmendiya `std` bi default ve hatî çalak kirin.
///
/// # Panics
///
/// Ev fonksiyon hewl dide ku tu carî panic neke, lê heke `cb` panics peyda kir wê hingê hin platform dê panic du qat zorê bidin pêvajoyê.
/// Hin platform pirtûkxaneya C bikar tînin ku di hundurê xwe de paşnavên ku bi navgîniya wan nayê vedan bikar tîne, ji ber vê yekê panîkirina ji `cb` dikare pêvajoyê betal bike.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // paşvemayînê bidomînin
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Heman wekî `trace`, tenê ne ewle ye ku ew ne-hevdemkirî ye.
///
/// Vê fonksiyonê garantorên hevdemkirinê tune lê dema ku taybetmendiya `std` ya vê crate neyê berhev kirin heye.
/// Ji bo bêtir belgekirin û mînakan fonksiyona `trace` bibînin.
///
/// # Panics
///
/// Agahdariya li ser `trace` ji bo hişyariyên li ser panîkirina `cb` bibînin.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// trait ku yek çarçoveyek paşverû temsîl dike, bi fonksiyona `trace` ya vê crate ve derket.
///
/// Girtîgeha fonksiyona şopandinê dê çarçove bêne hilberandin, û çarçov bi rastî tê şandin ji ber ku pêkanîna bingehîn her dem heya dema xebitandinê nayê zanîn.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Vê nîşana talîmata heyî ya vê çarçoveyê vedigerîne.
    ///
    /// Ev bi gelemperî talîmata paşîn e ku di çarçovê de tê meşandin, lê ne ku hemî pêkanîn bi 100% durustî vê navnîşê dikin (lê bi gelemperî pir nêzik e).
    ///
    ///
    /// Tête pêşniyar kirin ku vê nirxê ji `backtrace::resolve` re derbas bikin da ku ew bibe navek sembolek.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Vê çarçoveyê nîşana stakê ya niha vegerîne.
    ///
    /// Di rewşa ku paşpirtûkek nikaribe nîşana stackê ji bo vê çarçoveyê vegerîne, nîşana null vedigere.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Navnîşana sembola destpêkê ya çarçoveya vê fonksiyonê vedigire.
    ///
    /// Ev ê hewl bide ku nîşanderê talîmatê ku ji hêla `ip` ve vegeriya destpêka fonksiyonê, wê nirxê vegerîne.
    ///
    /// Lêbelê, di hin rewşan de, paşde dê tenê `ip` ji vê fonksiyonê vegerin.
    ///
    /// Heke `backtrace::resolve` li ser `ip` ya ku li jor hatî dayîn têk çû, carinan nirxa vegerî dikare were bikar anîn.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Navnîşana bingeha modulê ya ku çarçove tê de vedigere.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Pêdivî ye ku ev yekem were, da ku Miri pêşî li platforma mêvandar bigire
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // tenê di dbghelp sembolîzekirin de tê bikar anîn
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}