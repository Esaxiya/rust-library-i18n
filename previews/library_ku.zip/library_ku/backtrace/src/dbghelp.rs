//! Modulek ku di birêvebirina girêdanên dbghelp li Windows de bibe alîkar
//!
//! Paşvegerên li ser Windows (bi kêmî ve ji bo MSVC) bi piranî bi `dbghelp.dll` û fonksiyonên cihêreng ên ku ew vedihewîne têne hêz kirin.
//! Van fonksiyonên hanê ji dêvla ku bi statîkî ve bi `dbghelp.dll` ve neyên girêdan *bi dînamîkî* têne barkirin.
//! Vêga nuha ji hêla pirtûkxaneya standard ve tête kirin (û di teoriyê de li wir pêdivî ye), lê ew hewlek e ku bibe alîkar ku girêdanên statîk dll ên pirtûkxaneyê kêm bibin ji ber ku paşvekêşan bi gelemperî pir vebijarkî ne.
//!
//! Dema ku tê gotin, `dbghelp.dll` hema hema her gav bi serfirazî li Windows bar dike.
//!
//! Lêbelê binihêrin ku ji ber ku me ev hemî piştgirî bi dînamîkî barkiriye em nekarin di `winapi` de ravekên rawe bikar bînin, lê ji bilî vê pêdivî ye ku em celebên nîşangirê fonksiyonê bi xwe diyar bikin û wê bikar bînin.
//! Em bi rastî naxwazin ku di karsaziya dubarekirina winapi de bin, ji ber vê yekê taybetmendiyek me ya Cargo heye `verify-winapi` ku îddîa dike ku hemî girêdan bi yên di winapi de li hev dikin û ev taybetmendî li ser CI vekirî ye.
//!
//! Di dawiyê de, hûn ê li vir not bikin ku dll ji bo `dbghelp.dll` carî nayê barkirin, û ew naha bi mebest e.
//! Fikir ev e ku em dikarin bi gelemperî wê kaş bikin û wê di navbera bangên API-yê de bikar bînin, xwe ji loads/unloads-ya giranbuha dûr bixin.
//! Ger ev pirsgirêkek ji bo detektorên lehiyê an tiştek wusa be dema ku em bigihîjin wir em dikarin ji pirê derbas bibin.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Li dora `SymGetOptions` û `SymSetOptions` bixebitin ku di winapi bi xwe de tune ne.
// Wekî din ev tenê dema ku em cûreyên li dijî winapi du caran venêrin tê bikar anîn.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Di winapi de hîn nehatiye diyarkirin
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Ev di winapi de tête diyar kirin, lê ew nerast e (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Di winapi de hîn nehatiye diyarkirin
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Ev makro ji bo danasîna avahiyek `Dbghelp` tê bikar anîn ku di hundur de hemî nîşanderên fonksiyonê hene ku em dikarin bar bikin.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// Ji bo `dbghelp.dll` DLL barkirî
            dll: HMODULE,

            // Ji bo her fonksiyonê ku em dikarin bikar bînin her pointer fonksiyonê
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Di destpêkê de me DLL bar nekiriye
            dll: 0 as *mut _,
            // Di destpêkê de hemî fonksiyon sifir têne saz kirin da ku bêjin ew hewce ne ku bi dînamîkî werin barkirin.
            //
            $($name: 0,)*
        };

        // Ji bo her celebê fonksiyonê typedef-a hêsan.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Hewldanên vekirina `dbghelp.dll`.
            /// Ger `LoadLibraryW` têk biçe an xeletî serfiraziyê vedigire.
            ///
            /// Heke pirtûkxane jixwe barkirî ye Panics.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Fonksiyon ji bo her rêbaza ku em dixwazin bikar bînin.
            // Dema ku jê re tê gotin dê yan nîşana fonksiyona kaşkirî bixwîne an jî wê bar bike û nirxa barkirî vegerîne.
            // Ji bo serfiraziyê barkêş têne destnîşankirin.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Pêxemberê hêsaniyê ku kilîtên paqijkirinê bikar bînin da ku fonksiyonên dbghelp bikar bînin.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Ji bo gihîştina fonksiyonên `dbghelp` API ji vê crate pêdivî ye ku hemî piştevanî hewce bike.
///
///
/// Bala xwe bidinê ku ev fonksiyon **ewle** e, di hundurê wê de hevdemkirina xwe heye.
/// Di heman demê de bîr bînin ku ew ewle ye ku hûn vê fonksiyonê pir caran bi paşve bang bikin.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Yekem tiştê ku divê em bikin ev e ku em vê fonksiyonê hevdem bikin.Ev dikare bi hevdemî ji têlên din an paşde di nav yek xelekekê de were gazî kirin.
        // Bala xwe bidinê ku ew ji wiya aloztir e her çend ji ber ku ya ku em li vir bikar tînin, `dbghelp`,*jî* pêdivî ye ku di vê pêvajoyê de bi hemî bangkarên din re `dbghelp` were senkronîzekirin.
        //
        // Bi gelemperî di heman pêvajoyê de ew qas bangên li `dbghelp` tune û em dikarin bi ewlehî bifikirin ku em tenê yên ku digihîjin wê ye.
        // Lêbelê, bikarhênerek din ê bingehîn heye ku divê em xemgîn bibin ku bi îronî bixwe ye, lê di pirtûkxaneya standard de.
        // Pirtûkxaneya standard Rust ji bo piştgiriya paşde ve girêdayî vê crate ye, û ev crate jî li ser crates.io heye.
        // Ev tê vê wateyê ku heke pirtûkxaneya standard vedigere ku panic vedigere çap dike dibe ku ew bi vê crate ya ku ji crates.io tê, pêşbaziyê bike, bibe sedema segfaultan.
        //
        // Ji bo ku em vê pirsgirêka senkronîzekirinê çareser bikin em li vir hîleyek taybetî-ya Windows-ê bikar tînin (ew, paşiya paşîn, di derbarê senkronîzekirinê de sînorkirina taybetî-ya Windows-ê ye).
        // Em ji bo parastina vê bangê mutexek *rûniştinê-herêmî* bi nav dikin.
        // Armanc li vir ew e ku pirtûkxaneya standard û ev crate ne hewce ye ku API-yên asta Rust parve bikin ku li vir hevdem bikin lê li şûna wê dikarin li pişt perdê bixebitin da ku bicîh bikin ku ew bi hevûdu re hevdem dikin.
        //
        // Bi vî rengî gava ku ev fonksiyon bi nav pirtûkxaneya standard an jî bi crates.io tê vexwendin em dikarin pê ewle bin ku heman mutex tê stendin.
        //
        // Ji ber vê yekê hemî ev e ku em bibêjin yekem tiştê ku em li vir dikin ev e ku em bi atomî `HANDLE`-ê ku li ser Windows navê mutex e, diafirînin.
        // Em bi mijarên din ên ku vê fonksiyonê bi taybetî parve dikin re hinekî hevdem dikin û piştrast dikin ku tenê yek destan ji bo mînaka vê fonksiyonê tê afirandin.
        // Bala xwe bidinê ku despêk carî nayê girtin ku ew li cîhanî were hilanîn.
        //
        // Piştî ku em rastî kilîtê hatin, em wê bi hêsanî bi dest xwe dixin, û destê me yê `Init` ku em radest dikin dê berpirsiyar be ku wê di dawiyê de bavêje.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, phew!Naha ku em gişkî bi ewlehî hatine senkronîze kirin, ka em di rastiyê de dest bi pêvajoykirina her tiştî bikin.
        // Pêşî divê em piştrast bikin ku `dbghelp.dll` di vê pêvajoyê de rastî barkirî ye.
        // Em vê yekê bi dînamîkî dikin da ku ji girêdanek statîk dûr nekevin.
        // Ev di dîrokê de ji bo ku li dor pirsgirêkên girêdana xerîb bixebite hatiye çêkirin û armanc ew e ku biner hinekî veguhêztir be ji ber ku ev bi piranî tenê kêrhatiyek çewtkirinê ye.
        //
        //
        // Gava ku me `dbghelp.dll` vekir, pêdivî ye ku em tê de hin fonksiyonên destpêkirinê bi nav bikin, û ya ku li jêrê hûrgulîtir e.
        // Lêbelê, em tenê carekê viya dikin, ji ber vê yekê me gulokek gerdûnî heye ku diyar dike gelo em hîn jî xelas bûne an na.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Piştrast bikin ku ala `SYMOPT_DEFERRED_LOADS` hatiye danîn, ji ber ku li gorî belgeyên xweyên MSVC yên di derbarê vê yekê de: "This is the fastest, most efficient way to use the symbol handler.", da em wiya bikin!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Bi rastî bi MSVC sembol têne destpêkirin.Bala xwe bidinê ku ev dikare têk biçe, lê em wê paşguh dikin.
        // Jixwe ji bo vê yekê tonek hunera pêşîn tune, lê LLVM navxweyî xuya dike ku li vir nirxa vegerê paşguh dike û yek ji pirtûkxaneyên paqijker di LLVM de heke ev têk nebe hişyariyek tirsnak çap dike lê di bingeh de ew di dirêj-demê de paşguh dike.
        //
        //
        // Meseleyek ev ji Rust re pir derdikeve pêş ev e ku pirtûkxaneya standard û ev crate li crates.io hem dixwazin ji bo `SymInitializeW` pêşbaziyê bikin.
        // Pirtûkxaneya standard di dîrokê de dixwest piranî dema paqijkirinê dest pê bike, lê naha ku ew vê crate bikar tîne tê vê wateyê ku kesek dê pêşî li destpêkirinê bigire û yê din jî wê destpêkirinê hilbijêre.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}