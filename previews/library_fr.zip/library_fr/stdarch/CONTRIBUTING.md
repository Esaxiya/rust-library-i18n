# Contribuer à stdarch

Le `stdarch` crate est plus que disposé à accepter des contributions!Tout d'abord, vous voudrez probablement vérifier le référentiel et vous assurer que les tests réussissent pour vous:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Où `<your-target-arch>` est le triple cible tel qu'utilisé par `rustup`, par exemple `x86_x64-unknown-linux-gnu` (sans `nightly-` précédent ou similaire).
Rappelez-vous également que ce référentiel nécessite le canal nocturne de Rust!
Les tests ci-dessus nécessitent en fait que rust nocturne soit la valeur par défaut sur votre système, pour définir cette utilisation `rustup default nightly` (et `rustup default stable` pour revenir).

Si l'une des étapes ci-dessus ne fonctionne pas, [please let us know][new]!

Ensuite, vous pouvez aider [find an issue][issues], nous en avons sélectionné quelques-uns avec les balises [`help wanted`][help] et [`impl-period`][impl] qui pourraient en particulier utiliser un peu d'aide. 
Vous serez peut-être plus intéressé par [#40][vendor], implémentant tous les composants intrinsèques du fournisseur sur x86.Ce problème vous indique par où commencer!

Si vous avez des questions générales, n'hésitez pas à [join us on gitter][gitter] et demandez autour de vous!N'hésitez pas à envoyer une requête ping à@BurntSushi ou@alexcrichton avec des questions.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Comment écrire des exemples pour les intrinsèques stdarch

Certaines fonctionnalités doivent être activées pour que l'intrinsèque donnée fonctionne correctement et l'exemple ne doit être exécuté par `cargo test --doc` que lorsque la fonctionnalité est prise en charge par le processeur.

Par conséquent, le `fn main` par défaut généré par `rustdoc` ne fonctionnera pas (dans la plupart des cas).
Pensez à utiliser ce qui suit comme guide pour vous assurer que votre exemple fonctionne comme prévu.

```rust
/// # // Nous avons besoin de cfg_target_feature pour nous assurer que l'exemple est uniquement
/// # // exécuté par `cargo test --doc` lorsque le processeur prend en charge la fonction
/// # #![feature(cfg_target_feature)]
/// # // Nous avons besoin de target_feature pour que l'intrinsèque fonctionne
/// # #![feature(target_feature)]
/// #
/// # // rustdoc utilise par défaut `extern crate stdarch`, mais nous avons besoin du
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // La vraie fonction principale
/// # fn main() {
/// #     // N'exécutez ceci que si `<target feature>` est pris en charge
/// #     si cfg_feature_enabled! ("<target feature>"){
/// #         // Créez une fonction `worker` qui ne sera exécutée que si la fonction cible
/// #         // est pris en charge et assurez-vous que `target_feature` est activé pour votre travailleur
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         unsafe fn worker() {
/// // Écrivez votre exemple ici.Les caractéristiques intrinsèques spécifiques aux fonctionnalités fonctionneront ici!Devenir fou!
///
/// #         }
///
/// #         dangereux { worker(); }
/// #     }
/// # }
```

Si une partie de la syntaxe ci-dessus ne vous semble pas familière, la section [Documentation as tests] du [Rust Book] décrit assez bien la syntaxe `rustdoc`.
Comme toujours, n'hésitez pas à [join us on gitter][gitter] et demandez-nous si vous rencontrez des problèmes, et merci d'avoir aidé à améliorer la documentation de `stdarch`!

# Instructions de test alternatives

Il est généralement recommandé d'utiliser `ci/run.sh` pour exécuter les tests.
Cependant, cela peut ne pas fonctionner pour vous, par exemple si vous êtes sur Windows.

Dans ce cas, vous pouvez revenir à l'exécution de `cargo +nightly test` et `cargo +nightly test --release -p core_arch` pour tester la génération de code.
Notez que ceux-ci nécessitent l'installation de la chaîne d'outils nocturne et que `rustc` connaisse votre triple cible et son processeur.
En particulier, vous devez définir la variable d'environnement `TARGET` comme vous le feriez pour `ci/run.sh`.
En outre, vous devez définir `RUSTCFLAGS` (besoin du `C`) pour indiquer les fonctionnalités cibles, par exemple `RUSTCFLAGS="-C -target-features=+avx2"`.
Vous pouvez également définir `-C -target-cpu=native` si vous développez "just" par rapport à votre processeur actuel.

Soyez averti que lorsque vous utilisez ces instructions alternatives, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], par exemple
les tests de génération d'instructions peuvent échouer car le désassembleur les a nommés différemment, par exemple
il peut générer des instructions `vaesenc` au lieu d'instructions `aesenc` même si elles se comportent de la même manière.
De plus, ces instructions exécutent moins de tests que ce qui serait normalement fait, alors ne soyez pas surpris que lorsque vous finirez par faire une demande d'extraction, des erreurs puissent apparaître pour des tests non traités ici.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






