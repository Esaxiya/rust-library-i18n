use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Utilisé pour dire à nos annotations `#[assert_instr]` que tous les intrinsèques simd sont disponibles pour tester leur codegen, car certains sont fermés derrière un `-Ctarget-feature=+unimplemented-simd128` supplémentaire qui n'a pas d'équivalent dans `#[target_feature]` pour le moment.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}