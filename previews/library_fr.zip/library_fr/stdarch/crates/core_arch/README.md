`core::arch` - Les intrinsèques spécifiques à l'architecture de la bibliothèque principale de Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Le module `core::arch` implémente des éléments intrinsèques dépendant de l'architecture (par exemple SIMD).

# Usage 

`core::arch` est disponible dans le cadre de `libcore` et est réexporté par `libstd`.Préférez l'utiliser via `core::arch` ou `std::arch` que via ce crate.
Des fonctionnalités instables sont souvent disponibles dans le Rust nocturne via le `feature(stdsimd)`.

L'utilisation de `core::arch` via ce crate nécessite un Rust nocturne, et il peut (et le fait) souvent casser.Les seuls cas dans lesquels vous devriez envisager de l'utiliser via ce crate sont:

* si vous avez besoin de recompiler `core::arch` vous-même, par exemple avec des fonctionnalités cibles particulières activées qui ne sont pas activées pour `libcore`/`libstd`.
Note: si vous avez besoin de le recompiler pour une cible non standard, veuillez préférer utiliser `xargo` et recompiler `libcore`/`libstd` selon le cas au lieu d'utiliser ce crate.
  
* en utilisant certaines fonctionnalités qui pourraient ne pas être disponibles même derrière des fonctionnalités Rust instables.Nous essayons de les réduire au minimum.
Si vous avez besoin d'utiliser certaines de ces fonctionnalités, veuillez ouvrir un problème afin que nous puissions les exposer dans Rust de nuit et que vous puissiez les utiliser à partir de là.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` est principalement distribué sous les termes de la licence MIT et de la licence Apache (version 2.0), avec des parties couvertes par diverses licences de type BSD.

Voir LICENSE-APACHE et LICENSE-MIT pour plus de détails.

# Contribution

Sauf indication contraire explicite de votre part, toute contribution soumise intentionnellement pour inclusion dans `core_arch` par vous, telle que définie dans la licence Apache-2.0, fera l'objet d'une double licence comme ci-dessus, sans aucune condition supplémentaire.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












