# Le `rustc-std-workspace-core` crate

Ce crate est un shim et un crate vide qui dépend simplement de `libcore` et réexporte tout son contenu.
Le crate est le nœud de l'autonomisation de la bibliothèque standard pour qu'elle dépende de crates de crates.io

Crates sur crates.io dont dépend la bibliothèque standard doit dépendre du `rustc-std-workspace-core` crate de crates.io, qui est vide.

Nous utilisons `[patch]` pour le remplacer par ce crate dans ce référentiel.
En conséquence, crates sur crates.io dessinera une dépendance edge vers `libcore`, la version définie dans ce référentiel.
Cela devrait dessiner toutes les arêtes de dépendance pour garantir que Cargo construise crates avec succès!

Notez que crates sur crates.io doit dépendre de ce crate avec le nom `core` pour que tout fonctionne correctement.Pour ce faire, ils peuvent utiliser:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Grâce à l'utilisation de la clé `package`, le crate est renommé `core`, ce qui signifie qu'il ressemblera à

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

lorsque Cargo appelle le compilateur, satisfaisant la directive implicite `extern crate core` injectée par le compilateur.




