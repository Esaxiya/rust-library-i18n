#![feature(no_core)]
#![no_core]

// Voir rustc-std-workspace-core pour savoir pourquoi ce crate est nécessaire.

// Renommez le crate pour éviter tout conflit avec le module alloc dans liballoc.
extern crate alloc as foo;

pub use foo::*;