# Le `rustc-std-workspace-std` crate

Voir la documentation du `rustc-std-workspace-core` crate.