use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Spécialisation trait utilisée pour Vec::from_iter
///
/// ## Le graphique de délégation:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Un cas courant est de passer un vector dans une fonction qui se recueille immédiatement dans un vector.
        // Nous pouvons court-circuiter cela si l'IntoIter n'a pas du tout été avancé.
        // Lorsqu'il a été avancé, nous pouvons également réutiliser la mémoire et déplacer les données vers l'avant.
        // Mais nous ne le faisons que lorsque le Vec résultant n'aurait pas plus de capacité inutilisée que de le créer via l'implémentation générique de FromIterator.
        //
        // Cette limitation n'est pas strictement nécessaire car le comportement d'allocation de Vec est intentionnellement non spécifié.
        // Mais c'est un choix conservateur.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // doit déléguer à spec_extend() puisque extend() lui-même délègue à spec_from pour les Vecs vides
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Cela utilise `iterator.as_slice().to_vec()` car spec_extend doit prendre plus d'étapes pour raisonner sur la capacité finale + la longueur et donc faire plus de travail.
// `to_vec()` alloue directement le montant correct et le remplit exactement.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): avec cfg(test), la méthode `[T]::to_vec` inhérente, qui est requise pour cette définition de méthode, n'est pas disponible.
    // Utilisez plutôt la fonction `slice::to_vec` qui n'est disponible qu'avec cfg(test) NB voir le module slice::hack dans slice.rs pour plus d'informations
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}