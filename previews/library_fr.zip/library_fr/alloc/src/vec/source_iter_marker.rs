use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Marqueur de spécialisation pour collecter un pipeline d'itérateur dans un Vec tout en réutilisant l'allocation de source, c'est-à-dire
/// exécution du pipeline en place.
///
/// Le parent SourceIter trait est nécessaire pour que la fonction de spécialisation accède à l'allocation qui doit être réutilisée.
/// Mais il ne suffit pas que la spécialisation soit valable.
/// Voir les limites supplémentaires sur l'impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// Les std-interne SourceIter/InPlaceIterable traits ne sont implémentés que par des chaînes d'adaptateur <Adapter<Adapter<IntoIter>>> (tous appartenant à core/std).
// Les limites supplémentaires sur les implémentations de l'adaptateur (au-delà de `impl<I: Trait> Trait for Adapter<I>`) dépendent uniquement des autres traits déjà marqués comme spécialisation traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. le marqueur ne dépend pas de la durée de vie des types fournis par l'utilisateur.Modulo le trou de copie, dont dépendent déjà plusieurs autres spécialisations.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Exigences supplémentaires qui ne peuvent pas être exprimées via trait bounds.Nous nous appuyons sur const eval à la place:
        // a) pas de ZST car il n'y aurait pas d'allocation pour la réutilisation et l'arithmétique du pointeur serait panic b) la taille correspondrait comme requis par le contrat Alloc c) les alignements correspondent comme requis par le contrat Alloc
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // retour vers des implémentations plus génériques
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // utiliser try-fold depuis
        // - il vectorise mieux pour certains adaptateurs d'itérateur
        // - contrairement à la plupart des méthodes d'itération internes, cela ne prend qu'un &mut self
        // - il nous permet de faire passer le pointeur d'écriture à travers ses entrailles et de le récupérer à la fin
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // l'itération a réussi, ne lâchez pas la tête
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // vérifier si le contrat SourceIter a été respecté mise en garde: s'ils ne l'étaient pas, nous pourrions même ne pas arriver à ce point
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // Vérifiez le contrat InPlaceIterable.Cela n'est possible que si l'itérateur a avancé du tout le pointeur source.
        // S'il utilise un accès non vérifié via TrustedRandomAccess, le pointeur source restera dans sa position initiale et nous ne pouvons pas l'utiliser comme référence
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // supprimez toutes les valeurs restantes à la fin de la source mais empêchez la suppression de l'allocation elle-même une fois que IntoIter est hors de portée si la suppression panics, nous perdons également tous les éléments collectés dans dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // le contrat InPlaceIterable ne peut pas être vérifié précisément ici car try_fold a une référence exclusive au pointeur source, tout ce que nous pouvons faire est de vérifier s'il est toujours à portée
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}