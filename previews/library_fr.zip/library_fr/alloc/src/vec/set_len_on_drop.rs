// Définissez la longueur du vec lorsque la valeur `SetLenOnDrop` est hors de portée.
//
// L'idée est la suivante: le champ de longueur dans SetLenOnDrop est une variable locale que l'optimiseur verra ne s'alias avec aucun magasin via le pointeur de données du Vec.
// Il s'agit d'une solution de contournement pour le problème d'analyse d'alias #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}