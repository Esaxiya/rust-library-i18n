//! Un type de tableau évolutif contigu avec un contenu alloué au tas, écrit `Vec<T>`.
//!
//! Les Vectors ont l'indexation `O(1)`, le push `O(1)` amorti (jusqu'à la fin) et le pop `O(1)` (à partir de la fin).
//!
//!
//! Vectors garantit qu'ils n'allouent jamais plus de `isize::MAX` octets.
//!
//! # Examples
//!
//! Vous pouvez créer explicitement un [`Vec`] avec [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... ou en utilisant la macro [`vec!`]:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // dix zéros
//! ```
//!
//! Vous pouvez [`push`] valeurs à la fin d'un vector (qui augmentera le vector au besoin):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Les valeurs pop-up fonctionnent à peu près de la même manière:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors prend également en charge l'indexation (via le [`Index`] et le [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Un type de tableau évolutif contigu, écrit sous la forme `Vec<T>` et prononcé 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// La macro [`vec!`] est fournie pour rendre l'initialisation plus pratique:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Il peut également initialiser chaque élément d'un `Vec<T>` avec une valeur donnée.
/// Cela peut être plus efficace que d'effectuer l'allocation et l'initialisation en étapes séparées, en particulier lors de l'initialisation d'un vector de zéros:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Ce qui suit est équivalent, mais potentiellement plus lent:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Pour plus d'informations, consultez [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Utilisez un `Vec<T>` comme une pile efficace:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Tirages 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Le type `Vec` permet d'accéder aux valeurs par index, car il implémente le [`Index`] trait.Un exemple sera plus explicite:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // il affichera '2'
/// ```
///
/// Attention cependant: si vous essayez d'accéder à un index qui n'est pas dans le `Vec`, votre logiciel sera panic!Tu ne peux pas faire ça:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Utilisez [`get`] et [`get_mut`] si vous souhaitez vérifier si l'index se trouve dans le `Vec`.
///
/// # Slicing
///
/// Un `Vec` peut être mutable.En revanche, les tranches sont des objets en lecture seule.
/// Pour obtenir un [slice][prim@slice], utilisez [`&`].Exemple:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... et c'est tout!
/// // vous pouvez également le faire comme ceci:
/// let u: &[usize] = &v;
/// // ou comme ça:
/// let u: &[_] = &v;
/// ```
///
/// Dans Rust, il est plus courant de passer des tranches en tant qu'arguments que vectors lorsque vous souhaitez simplement fournir un accès en lecture.Il en va de même pour [`String`] et [`&str`].
///
/// # Capacité et réaffectation
///
/// La capacité d'un vector est la quantité d'espace allouée pour tout élément future qui sera ajouté sur le vector.Cela ne doit pas être confondu avec la *longueur* d'un vector, qui spécifie le nombre d'éléments réels dans le vector.
/// Si la longueur d'un vector dépasse sa capacité, sa capacité sera automatiquement augmentée, mais ses éléments devront être réaffectés.
///
/// Par exemple, un vector avec une capacité 10 et une longueur 0 serait un vector vide avec un espace pour 10 éléments supplémentaires.Le fait de pousser 10 éléments ou moins sur le vector ne changera pas sa capacité et ne provoquera pas de réallocation.
/// Cependant, si la longueur du vector est augmentée à 11, il devra réallouer, ce qui peut être lent.Pour cette raison, il est recommandé d'utiliser [`Vec::with_capacity`] chaque fois que possible pour spécifier la taille attendue du vector.
///
/// # Guarantees
///
/// En raison de sa nature incroyablement fondamentale, `Vec` offre de nombreuses garanties sur sa conception.Cela garantit qu'il est aussi faible que possible dans le cas général, et peut être correctement manipulé de manière primitive par un code non sécurisé.Notez que ces garanties se réfèrent à un `Vec<T>` non qualifié.
/// Si des paramètres de type supplémentaires sont ajoutés (par exemple, pour prendre en charge les allocateurs personnalisés), le remplacement de leurs valeurs par défaut peut changer le comportement.
///
/// Plus fondamentalement, `Vec` est et sera toujours un triplet (pointeur, capacité, longueur).Ni plus ni moins.L'ordre de ces champs n'est absolument pas spécifié et vous devez utiliser les méthodes appropriées pour les modifier.
/// Le pointeur ne sera jamais nul, donc ce type est optimisé pour le pointeur nul.
///
/// Toutefois, le pointeur peut ne pas pointer réellement vers la mémoire allouée.
/// En particulier, si vous construisez un `Vec` de capacité 0 via [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], ou en appelant [`shrink_to_fit`] sur un Vec vide, il n'allouera pas de mémoire.De même, si vous stockez des types de taille nulle dans un `Vec`, il ne leur allouera pas d'espace.
/// *Notez que dans ce cas, le `Vec` peut ne pas signaler un [`capacity`] de 0*.
/// `Vec` allouera si et seulement si [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// En général, les détails d'allocation de `Vec` sont très subtils-si vous avez l'intention d'allouer de la mémoire à l'aide d'un `Vec` et de l'utiliser pour autre chose (soit pour passer à un code non sécurisé, soit pour créer votre propre collection sauvegardée en mémoire), assurez-vous pour désallouer cette mémoire en utilisant `from_raw_parts` pour récupérer le `Vec` puis en le supprimant.
///
/// Si un `Vec`*a* de la mémoire allouée, alors la mémoire vers laquelle il pointe est sur le tas (comme défini par l'allocateur Rust est configuré pour utiliser par défaut), et son pointeur pointe vers [`len`] initialisé, éléments contigus dans l'ordre (ce que vous feriez voir si vous l'avez forcé à une tranche), suivi de [`capacity`]`,`[`len`] éléments contigus logiquement non initialisés.
///
///
/// Un vector contenant les éléments `'a'` et `'b'` de capacité 4 peut être visualisé comme ci-dessous.La partie supérieure est la structure `Vec`, elle contient un pointeur vers la tête de l'allocation dans le tas, la longueur et la capacité.
/// La partie inférieure est l'allocation sur le tas, un bloc de mémoire contigu.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** représente la mémoire qui n'est pas initialisée, voir [`MaybeUninit`].
/// - Note: l'ABI n'est pas stable et `Vec` ne donne aucune garantie sur la disposition de sa mémoire (y compris l'ordre des champs).
///
/// `Vec` n'effectuera jamais un "small optimization" où les éléments sont réellement stockés sur la pile pour deux raisons:
///
/// * Cela rendrait plus difficile pour le code non sécurisé de manipuler correctement un `Vec`.Le contenu d'un `Vec` n'aurait pas d'adresse stable s'il était seulement déplacé, et il serait plus difficile de déterminer si un `Vec` avait effectivement alloué de la mémoire.
///
/// * Cela pénaliserait le cas général, encourant un branch supplémentaire à chaque accès.
///
/// `Vec` ne se rétrécira jamais automatiquement, même s'il est complètement vide.Cela garantit qu'aucune allocation ou désallocation inutile ne se produira.Vider un `Vec` puis le remplir avec le même [`len`] ne devrait entraîner aucun appel à l'allocateur.Si vous souhaitez libérer de la mémoire inutilisée, utilisez [`shrink_to_fit`] ou [`shrink_to`].
///
/// [`push`] et [`insert`] ne (ré) allouera jamais si la capacité rapportée est suffisante.[`push`] et [`insert`]*vont*(ré) allouer si [`len`]`==`[`capacité`].Autrement dit, la capacité rapportée est tout à fait précise et peut être invoquée.Il peut même être utilisé pour libérer manuellement la mémoire allouée par un `Vec` si vous le souhaitez.
/// Les méthodes d'insertion en masse *peuvent* réallouer, même si cela n'est pas nécessaire.
///
/// `Vec` ne garantit aucune stratégie de croissance particulière lors de la réallocation en cas de saturation, ni lors de l'appel de [`reserve`].La stratégie actuelle est basique et il peut s'avérer souhaitable d'utiliser un facteur de croissance non constant.Quelle que soit la stratégie utilisée, elle garantira bien sûr *O*(1) amorti [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]` et [`Vec::with_capacity(n)`][`Vec::with_capacity`] produiront tous un `Vec` avec exactement la capacité demandée.
/// Si [`len`]`==`[`capacity`], (comme c'est le cas pour la macro [`vec!`]), alors un `Vec<T>` peut être converti vers et depuis un [`Box<[T]>`][owned slice] sans réallouer ou déplacer les éléments.
///
/// `Vec` n'écrasera pas spécifiquement les données qui en sont supprimées, mais ne les conservera pas non plus spécifiquement.Sa mémoire non initialisée est un espace de travail qu'il peut utiliser comme bon lui semble.Il fera généralement tout ce qui est le plus efficace ou le plus facile à mettre en œuvre.Ne comptez pas sur les données supprimées à effacer à des fins de sécurité.
/// Même si vous déposez un `Vec`, son tampon peut simplement être réutilisé par un autre `Vec`.
/// Même si vous mettez d'abord à zéro la mémoire d'un `Vec`, cela peut ne pas se produire car l'optimiseur ne considère pas cela comme un effet secondaire qui doit être préservé.
/// Il y a un cas que nous ne casserons pas, cependant: utiliser du code `unsafe` pour écrire sur la capacité excédentaire, puis augmenter la longueur pour correspondre, est toujours valide.
///
/// Actuellement, `Vec` ne garantit pas l'ordre dans lequel les éléments sont déposés.
/// L'ordre a changé dans le passé et peut changer à nouveau.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Méthodes inhérentes
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Construit un nouveau `Vec<T>` vide.
    ///
    /// Le vector n'allouera pas tant que les éléments ne seront pas poussés dessus.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Construit un nouveau `Vec<T>` vide avec la capacité spécifiée.
    ///
    /// Le vector pourra contenir exactement des éléments `capacity` sans réallocation.
    /// Si `capacity` vaut 0, le vector n'allouera pas.
    ///
    /// Il est important de noter que bien que le vector renvoyé ait la *capacité* spécifiée, le vector aura une *longueur* nulle.
    ///
    /// Pour une explication de la différence entre la longueur et la capacité, voir *[Capacité et réallocation]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // Le vector ne contient aucun élément, même s'il a une capacité pour plus
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Tout cela se fait sans réallocation ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... mais cela peut entraîner la réallocation du vector
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Crée un `Vec<T>` directement à partir des composants bruts d'un autre vector.
    ///
    /// # Safety
    ///
    /// Ceci est très dangereux, en raison du nombre d'invariants qui ne sont pas vérifiés:
    ///
    /// * `ptr` doit avoir été préalablement alloué via [`String`]/` Vec<T>(au moins, il est fort probable que ce soit incorrect si ce n'était pas le cas).
    /// * `T` doit avoir la même taille et le même alignement que ceux avec lesquels `ptr` a été alloué.
    ///   (`T` ayant un alignement moins strict n'est pas suffisant, l'alignement doit vraiment être égal pour satisfaire l'exigence [`dealloc`] selon laquelle la mémoire doit être allouée et désallouée avec la même disposition.)
    ///
    /// * `length` doit être inférieur ou égal à `capacity`.
    /// * `capacity` doit être la capacité avec laquelle le pointeur a été alloué.
    ///
    /// Le non-respect de ces règles peut entraîner des problèmes tels que la corruption des structures de données internes de l'allocateur.Par exemple, il n'est **pas** sûr de créer un `Vec<u8>` à partir d'un pointeur vers un tableau C `char` de longueur `size_t`.
    /// Il n'est pas non plus sûr d'en construire un à partir d'un `Vec<u16>` et de sa longueur, car l'allocateur se soucie de l'alignement et ces deux types ont des alignements différents.
    /// Le tampon a été alloué avec l'alignement 2 (pour `u16`), mais après l'avoir transformé en `Vec<u8>`, il sera désalloué avec l'alignement 1.
    ///
    /// La propriété de `ptr` est effectivement transférée au `Vec<T>` qui peut alors désallouer, réallouer ou changer le contenu de la mémoire pointé par le pointeur à volonté.
    /// Assurez-vous que rien d'autre n'utilise le pointeur après avoir appelé cette fonction.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Mettez à jour ceci lorsque vec_into_raw_parts est stabilisé.
    ///     // Empêchez d'exécuter le destructeur de `v` pour que nous contrôlions totalement l'allocation.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Extrayez les différentes informations importantes sur `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Écraser la mémoire avec 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Remettez tout dans un Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Construit un nouveau `Vec<T, A>` vide.
    ///
    /// Le vector n'allouera pas tant que les éléments ne seront pas poussés dessus.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Construit un nouveau `Vec<T, A>` vide avec la capacité spécifiée avec l'allocateur fourni.
    ///
    /// Le vector pourra contenir exactement des éléments `capacity` sans réallocation.
    /// Si `capacity` vaut 0, le vector n'allouera pas.
    ///
    /// Il est important de noter que bien que le vector renvoyé ait la *capacité* spécifiée, le vector aura une *longueur* nulle.
    ///
    /// Pour une explication de la différence entre la longueur et la capacité, voir *[Capacité et réallocation]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // Le vector ne contient aucun élément, même s'il a une capacité pour plus
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Tout cela se fait sans réallocation ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... mais cela peut entraîner la réallocation du vector
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Crée un `Vec<T, A>` directement à partir des composants bruts d'un autre vector.
    ///
    /// # Safety
    ///
    /// Ceci est très dangereux, en raison du nombre d'invariants qui ne sont pas vérifiés:
    ///
    /// * `ptr` doit avoir été préalablement alloué via [`String`]/` Vec<T>(au moins, il est fort probable que ce soit incorrect si ce n'était pas le cas).
    /// * `T` doit avoir la même taille et le même alignement que ceux avec lesquels `ptr` a été alloué.
    ///   (`T` ayant un alignement moins strict n'est pas suffisant, l'alignement doit vraiment être égal pour satisfaire l'exigence [`dealloc`] selon laquelle la mémoire doit être allouée et désallouée avec la même disposition.)
    ///
    /// * `length` doit être inférieur ou égal à `capacity`.
    /// * `capacity` doit être la capacité avec laquelle le pointeur a été alloué.
    ///
    /// Le non-respect de ces règles peut entraîner des problèmes tels que la corruption des structures de données internes de l'allocateur.Par exemple, il n'est **pas** sûr de créer un `Vec<u8>` à partir d'un pointeur vers un tableau C `char` de longueur `size_t`.
    /// Il n'est pas non plus sûr d'en construire un à partir d'un `Vec<u16>` et de sa longueur, car l'allocateur se soucie de l'alignement et ces deux types ont des alignements différents.
    /// Le tampon a été alloué avec l'alignement 2 (pour `u16`), mais après l'avoir transformé en `Vec<u8>`, il sera désalloué avec l'alignement 1.
    ///
    /// La propriété de `ptr` est effectivement transférée au `Vec<T>` qui peut alors désallouer, réallouer ou changer le contenu de la mémoire pointé par le pointeur à volonté.
    /// Assurez-vous que rien d'autre n'utilise le pointeur après avoir appelé cette fonction.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Mettez à jour ceci lorsque vec_into_raw_parts est stabilisé.
    ///     // Empêchez d'exécuter le destructeur de `v` pour que nous contrôlions totalement l'allocation.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Extrayez les différentes informations importantes sur `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Écraser la mémoire avec 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Remettez tout dans un Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Décompose un `Vec<T>` en ses composants bruts.
    ///
    /// Renvoie le pointeur brut vers les données sous-jacentes, la longueur du vector (en éléments) et la capacité allouée des données (en éléments).
    /// Ce sont les mêmes arguments dans le même ordre que les arguments de [`from_raw_parts`].
    ///
    /// Après avoir appelé cette fonction, l'appelant est responsable de la mémoire précédemment gérée par le `Vec`.
    /// La seule façon de le faire est de reconvertir le pointeur brut, la longueur et la capacité en un `Vec` avec la fonction [`from_raw_parts`], ce qui permet au destructeur d'effectuer le nettoyage.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Nous pouvons maintenant apporter des modifications aux composants, comme la transmutation du pointeur brut en un type compatible.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Décompose un `Vec<T>` en ses composants bruts.
    ///
    /// Renvoie le pointeur brut vers les données sous-jacentes, la longueur du vector (en éléments), la capacité allouée des données (en éléments) et l'allocateur.
    /// Ce sont les mêmes arguments dans le même ordre que les arguments de [`from_raw_parts_in`].
    ///
    /// Après avoir appelé cette fonction, l'appelant est responsable de la mémoire précédemment gérée par le `Vec`.
    /// La seule façon de le faire est de reconvertir le pointeur brut, la longueur et la capacité en un `Vec` avec la fonction [`from_raw_parts_in`], permettant au destructeur d'effectuer le nettoyage.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Nous pouvons maintenant apporter des modifications aux composants, comme la transmutation du pointeur brut en un type compatible.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Renvoie le nombre d'éléments que le vector peut contenir sans réallocation.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Réserve de la capacité pour au moins `additional` éléments supplémentaires à insérer dans le `Vec<T>` donné.
    /// La collection peut réserver plus d'espace pour éviter de fréquentes réaffectations.
    /// Après avoir appelé `reserve`, la capacité sera supérieure ou égale à `self.len() + additional`.
    /// Ne fait rien si la capacité est déjà suffisante.
    ///
    /// # Panics
    ///
    /// Panics si la nouvelle capacité dépasse `isize::MAX` octets.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Réserve la capacité minimale pour exactement `additional` plus d'éléments à insérer dans le `Vec<T>` donné.
    ///
    /// Après avoir appelé `reserve_exact`, la capacité sera supérieure ou égale à `self.len() + additional`.
    /// Ne fait rien si la capacité est déjà suffisante.
    ///
    /// Notez que l'allocateur peut donner à la collection plus d'espace qu'il n'en demande.
    /// Par conséquent, on ne peut pas considérer que la capacité est précisément minimale.
    /// Préférez `reserve` si des insertions future sont attendues.
    ///
    /// # Panics
    ///
    /// Panics si la nouvelle capacité dépasse `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Tente de réserver de la capacité pour au moins `additional` éléments supplémentaires à insérer dans le `Vec<T>` donné.
    /// La collection peut réserver plus d'espace pour éviter de fréquentes réaffectations.
    /// Après avoir appelé `try_reserve`, la capacité sera supérieure ou égale à `self.len() + additional`.
    /// Ne fait rien si la capacité est déjà suffisante.
    ///
    /// # Errors
    ///
    /// Si la capacité dépasse ou si l'allocateur signale un échec, une erreur est renvoyée.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Pré-réserver la mémoire, en sortant si nous ne pouvons pas
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Maintenant, nous savons que cela ne peut pas OOM au milieu de notre travail complexe
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // très compliqué
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Tente de réserver la capacité minimale pour les éléments `additional` exactement à insérer dans le `Vec<T>` donné.
    /// Après avoir appelé `try_reserve_exact`, la capacité sera supérieure ou égale à `self.len() + additional` si elle renvoie `Ok(())`.
    ///
    /// Ne fait rien si la capacité est déjà suffisante.
    ///
    /// Notez que l'allocateur peut donner à la collection plus d'espace qu'il n'en demande.
    /// Par conséquent, on ne peut pas considérer que la capacité est précisément minimale.
    /// Préférez `reserve` si des insertions future sont attendues.
    ///
    /// # Errors
    ///
    /// Si la capacité dépasse ou si l'allocateur signale un échec, une erreur est renvoyée.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Pré-réserver la mémoire, en sortant si nous ne pouvons pas
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Maintenant, nous savons que cela ne peut pas OOM au milieu de notre travail complexe
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // très compliqué
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Réduit au maximum la capacité du vector.
    ///
    /// Il descendra aussi près que possible de la longueur mais l'allocateur peut toujours informer le vector qu'il y a de la place pour quelques éléments supplémentaires.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // La capacité n'est jamais inférieure à la longueur, et il n'y a rien à faire quand elles sont égales, nous pouvons donc éviter le cas panic dans `RawVec::shrink_to_fit` en l'appelant uniquement avec une capacité supérieure.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Réduit la capacité du vector avec une limite inférieure.
    ///
    /// La capacité restera au moins aussi grande que la longueur et la valeur fournie.
    ///
    ///
    /// Si la capacité actuelle est inférieure à la limite inférieure, il s'agit d'un no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Convertit le vector en [`Box<[T]>`][owned slice].
    ///
    /// Notez que cela réduira toute capacité excédentaire.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Toute capacité excédentaire est supprimée:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Raccourcit le vector, en conservant les premiers éléments `len` et en laissant tomber le reste.
    ///
    /// Si `len` est supérieur à la longueur actuelle du vector, cela n'a aucun effet.
    ///
    /// La méthode [`drain`] peut émuler `truncate`, mais provoque le retour des éléments en excès au lieu de la suppression.
    ///
    ///
    /// Notez que cette méthode n'a aucun effet sur la capacité allouée du vector.
    ///
    /// # Examples
    ///
    /// Tronquer un vector à cinq éléments en deux éléments:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Aucune troncature ne se produit lorsque `len` est supérieur à la longueur actuelle du vector:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Tronquer lorsque `len == 0` équivaut à appeler la méthode [`clear`].
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Ceci est sûr parce que:
        //
        // * la tranche passée à `drop_in_place` est valide;le cas `len > self.len` évite de créer une tranche invalide, et
        // * le `len` du vector est rétréci avant d'appeler `drop_in_place`, de sorte qu'aucune valeur ne sera supprimée deux fois dans le cas où `drop_in_place` serait à panic une fois (s'il panics deux fois, le programme abandonne).
        //
        //
        //
        unsafe {
            // Note: Il est intentionnel que ce soit `>` et non `>=`.
            //       Le changer en `>=` a des implications négatives sur les performances dans certains cas.
            //       Voir #78884 pour plus.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Extrait une tranche contenant le vector entier.
    ///
    /// Équivalent à `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Extrait une tranche mutable de l'ensemble du vector.
    ///
    /// Équivalent à `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Renvoie un pointeur brut vers le tampon du vector.
    ///
    /// L'appelant doit s'assurer que le vector survit au pointeur renvoyé par cette fonction, sinon il finira par pointer vers des déchets.
    /// La modification du vector peut entraîner la réallocation de sa mémoire tampon, ce qui rendrait également les pointeurs vers lui invalides.
    ///
    /// L'appelant doit également s'assurer que la mémoire vers laquelle pointe le pointeur (non-transitively) n'est jamais écrite (sauf à l'intérieur d'un `UnsafeCell`) à l'aide de ce pointeur ou de tout pointeur dérivé de celui-ci.
    /// Si vous devez muter le contenu de la tranche, utilisez [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Nous observons la méthode slice du même nom pour éviter de passer par `deref`, ce qui crée une référence intermédiaire.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Renvoie un pointeur mutable unsafe vers le tampon du vector.
    ///
    /// L'appelant doit s'assurer que le vector survit au pointeur renvoyé par cette fonction, sinon il finira par pointer vers des déchets.
    ///
    /// La modification du vector peut entraîner la réallocation de sa mémoire tampon, ce qui rendrait également les pointeurs vers lui invalides.
    ///
    /// # Examples
    ///
    /// ```
    /// // Allouez vector assez grand pour 4 éléments.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Initialisez les éléments via les écritures de pointeur brutes, puis définissez la longueur.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Nous observons la méthode slice du même nom pour éviter de passer par `deref_mut`, ce qui crée une référence intermédiaire.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Renvoie une référence à l'allocateur sous-jacent.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Force la longueur du vector à `new_len`.
    ///
    /// Il s'agit d'une opération de bas niveau qui ne conserve aucun des invariants normaux du type.
    /// Normalement, la modification de la longueur d'un vector est effectuée en utilisant à la place l'une des opérations sûres, telles que [`truncate`], [`resize`], [`extend`] ou [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` doit être inférieur ou égal à [`capacity()`].
    /// - Les éléments à `old_len..new_len` doivent être initialisés.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Cette méthode peut être utile pour les situations dans lesquelles le vector sert de tampon pour un autre code, en particulier sur FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Ceci est juste un squelette minimal pour l'exemple doc;
    /// # // ne l'utilisez pas comme point de départ pour une vraie bibliothèque.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Selon la documentation de la méthode FFI, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // SÉCURITÉ: lorsque `deflateGetDictionary` renvoie `Z_OK`, il tient que:
    ///     // 1. `dict_length` les éléments ont été initialisés.
    ///     // 2.
    ///     // `dict_length` <=la capacité (32_768) qui rend l'appel `set_len` sûr.
    ///     unsafe {
    ///         // Passer l'appel FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... et mettez à jour la longueur à ce qui a été initialisé.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Bien que l'exemple suivant soit valable, il y a une fuite de mémoire car les vectors internes n'ont pas été libérés avant l'appel `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` est vide donc aucun élément n'a besoin d'être initialisé.
    /// // 2. `0 <= capacity` détient toujours ce que `capacity` est.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Normalement, ici, on utiliserait [`clear`] à la place pour déposer correctement le contenu et donc ne pas fuir de mémoire.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Supprime un élément du vector et le renvoie.
    ///
    /// L'élément supprimé est remplacé par le dernier élément du vector.
    ///
    /// Cela ne préserve pas la commande, mais c'est O(1).
    ///
    /// # Panics
    ///
    /// Panics si `index` est hors limites.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Nous remplaçons self [index] par le dernier élément.
            // Notez que si la vérification des limites ci-dessus réussit, il doit y avoir un dernier élément (qui peut être self [index] lui-même).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Insère un élément à la position `index` dans le vector, en décalant tous les éléments après celui-ci vers la droite.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // espace pour le nouvel élément
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // infaillible Le spot pour mettre la nouvelle valeur
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Déplacez tout pour faire de la place.
                // (Duplication de l'élément `index`th en deux endroits consécutifs.)
                ptr::copy(p, p.offset(1), len - index);
                // Écrivez-le en écrasant la première copie de l'élément `index`th.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Supprime et renvoie l'élément à la position `index` dans le vector, en décalant tous les éléments après celui-ci vers la gauche.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `index` est hors limites.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // l'endroit d'où nous venons.
                let ptr = self.as_mut_ptr().add(index);
                // copiez-le, en ayant en toute sécurité une copie de la valeur sur la pile et dans le vector en même temps.
                //
                ret = ptr::read(ptr);

                // Décalez tout vers le bas pour remplir cet endroit.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Conserve uniquement les éléments spécifiés par le prédicat.
    ///
    /// En d'autres termes, supprimez tous les éléments `e` de telle sorte que `f(&e)` renvoie `false`.
    /// Cette méthode fonctionne en place, visitant chaque élément exactement une fois dans l'ordre d'origine et préserve l'ordre des éléments conservés.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Étant donné que les éléments sont visités exactement une fois dans l'ordre d'origine, l'état externe peut être utilisé pour décider des éléments à conserver.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Évitez la double chute si le drop guard n'est pas exécuté, car nous pouvons faire des trous pendant le processus.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-len traité-> |^-à côté de vérifier
        //                  | <-supprimé cnt-> |
        //      | <-original_len-> |Conservé: éléments sur lesquels le prédicat renvoie vrai.
        //
        // Trou: emplacement d'élément déplacé ou abandonné.
        // Non coché: éléments valides non cochés.
        //
        // Ce drop guard sera invoqué lorsque le prédicat ou `drop` de l'élément paniqué.
        // Il décale les éléments non contrôlés pour couvrir les trous et `set_len` à la bonne longueur.
        // Dans les cas où le prédicat et `drop` ne paniquent jamais, il sera optimisé.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // SÉCURITÉ: Les éléments non cochés à la fin doivent être valides car nous ne les touchons jamais.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // SÉCURITÉ: après avoir rempli les trous, tous les éléments sont dans une mémoire contiguë.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // SÉCURITÉ: l'élément non coché doit être valide.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Avancez tôt pour éviter une double chute si `drop_in_place` paniquait.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // SÉCURITÉ: Nous ne touchons plus jamais cet élément après une chute.
                unsafe { ptr::drop_in_place(cur) };
                // Nous avons déjà avancé le compteur.
                continue;
            }
            if g.deleted_cnt > 0 {
                // SÉCURITÉ: `deleted_cnt`> 0, de sorte que la fente du trou ne doit pas chevaucher l'élément courant.
                // Nous utilisons la copie pour déplacer et ne touchons plus jamais cet élément.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Tous les articles sont traités.Cela peut être optimisé pour `set_len` par LLVM.
        drop(g);
    }

    /// Supprime tous les éléments consécutifs du vector, sauf le premier, qui se résolvent à la même clé.
    ///
    ///
    /// Si le vector est trié, cela supprime tous les doublons.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Supprime tous les éléments consécutifs sauf le premier dans le vector satisfaisant une relation d'égalité donnée.
    ///
    /// La fonction `same_bucket` reçoit des références à deux éléments du vector et doit déterminer si les éléments se comparent égaux.
    /// Les éléments sont passés dans l'ordre inverse de leur ordre dans la tranche, donc si `same_bucket(a, b)` renvoie `true`, `a` est supprimé.
    ///
    ///
    /// Si le vector est trié, cela supprime tous les doublons.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Ajoute un élément à l'arrière d'une collection.
    ///
    /// # Panics
    ///
    /// Panics si la nouvelle capacité dépasse `isize::MAX` octets.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Cela panic ou abandonnera si nous allouons> isize::MAX octets ou si l'incrément de longueur débordera pour les types de taille zéro.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Supprime le dernier élément d'un vector et le renvoie, ou [`None`] s'il est vide.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Déplace tous les éléments de `other` dans `Self`, laissant `other` vide.
    ///
    /// # Panics
    ///
    /// Panics si le nombre d'éléments dans le vector dépasse un `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Ajoute des éléments à `Self` à partir d'un autre tampon.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Crée un itérateur de drainage qui supprime la plage spécifiée dans le vector et renvoie les éléments supprimés.
    ///
    /// Lorsque l'itérateur **est** supprimé, tous les éléments de la plage sont supprimés du vector, même si l'itérateur n'a pas été entièrement consommé.
    /// Si l'itérateur **n'est pas** supprimé (avec [`mem::forget`] par exemple), le nombre d'éléments supprimés n'est pas spécifié.
    ///
    /// # Panics
    ///
    /// Panics si le point de départ est supérieur au point final ou si le point final est supérieur à la longueur du vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Une gamme complète efface le vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Sécurité de la mémoire
        //
        // Lorsque le Drain est créé pour la première fois, il raccourcit la longueur du vector source pour s'assurer qu'aucun élément non initialisé ou déplacé n'est accessible du tout si le destructeur du Drain ne s'exécute jamais.
        //
        //
        // Drain sortira ptr::read les valeurs à supprimer.
        // Une fois terminé, la queue restante du vec est recopiée pour couvrir le trou, et la longueur vector est restaurée à la nouvelle longueur.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // régler la longueur de self.vec pour démarrer, pour être sûr en cas de fuite de Drain
            self.set_len(start);
            // Utilisez l'emprunt dans IterMut pour indiquer le comportement d'emprunt de l'ensemble de l'itérateur Drain (comme &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Efface le vector, en supprimant toutes les valeurs.
    ///
    /// Notez que cette méthode n'a aucun effet sur la capacité allouée du vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Renvoie le nombre d'éléments dans le vector, également appelé son 'length'.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Renvoie `true` si le vector ne contient aucun élément.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Divise la collection en deux à l'index donné.
    ///
    /// Renvoie un vector nouvellement alloué contenant les éléments de la plage `[at, len)`.
    /// Après l'appel, le vector d'origine sera laissé contenant les éléments `[0, at)` avec sa capacité précédente inchangée.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // le nouveau vector peut reprendre le tampon d'origine et éviter la copie
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Non sécurisé `set_len` et copiez les éléments vers `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Redimensionne le `Vec` sur place afin que `len` soit égal à `new_len`.
    ///
    /// Si `new_len` est supérieur à `len`, le `Vec` est étendu de la différence, chaque emplacement supplémentaire étant rempli avec le résultat de l'appel de la fermeture `f`.
    ///
    /// Les valeurs de retour de `f` se retrouveront dans le `Vec` dans l'ordre où elles ont été générées.
    ///
    /// Si `new_len` est inférieur à `len`, le `Vec` est simplement tronqué.
    ///
    /// Cette méthode utilise une fermeture pour créer de nouvelles valeurs à chaque poussée.Si vous préférez [`Clone`] une valeur donnée, utilisez [`Vec::resize`].
    /// Si vous souhaitez utiliser le [`Default`] trait pour générer des valeurs, vous pouvez passer [`Default::default`] comme deuxième argument.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Consomme et fuit le `Vec`, renvoyant une référence mutable au contenu, `&'a mut [T]`.
    /// Notez que le type `T` doit survivre à la durée de vie choisie `'a`.
    /// Si le type n'a que des références statiques, ou aucune du tout, alors cela peut être choisi pour être `'static`.
    ///
    /// Cette fonction est similaire à la fonction [`leak`][Box::leak] sur [`Box`] sauf qu'il n'y a aucun moyen de récupérer la mémoire perdue.
    ///
    ///
    /// Cette fonction est principalement utile pour les données qui durent le reste de la vie du programme.
    /// La suppression de la référence renvoyée entraînera une fuite de mémoire.
    ///
    /// # Examples
    ///
    /// Utilisation simple:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Renvoie la capacité de réserve restante du vector sous la forme d'une tranche de `MaybeUninit<T>`.
    ///
    /// La tranche retournée peut être utilisée pour remplir le vector avec des données (par exemple
    /// en lisant un fichier) avant de marquer les données comme initialisées à l'aide de la méthode [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Allouez vector assez grand pour 10 éléments.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Remplissez les 3 premiers éléments.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Marquez les 3 premiers éléments du vector comme étant initialisés.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Cette méthode n'est pas implémentée en termes de `split_at_spare_mut`, pour empêcher l'invalidation des pointeurs vers le tampon.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Renvoie le contenu de vector sous forme de tranche de `T`, ainsi que la capacité de réserve restante du vector sous forme de tranche de `MaybeUninit<T>`.
    ///
    /// La tranche de capacité de réserve renvoyée peut être utilisée pour remplir le vector avec des données (par exemple en lisant un fichier) avant de marquer les données comme initialisées à l'aide de la méthode [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Notez qu'il s'agit d'une API de bas niveau, qui doit être utilisée avec précaution à des fins d'optimisation.
    /// Si vous devez ajouter des données à un `Vec`, vous pouvez utiliser [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] ou [`resize_with`], en fonction de vos besoins exacts.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Réservez un espace supplémentaire assez grand pour 10 éléments.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Remplissez les 4 éléments suivants.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Marquez les 4 éléments du vector comme étant initialisés.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len est ignoré et donc jamais changé
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Sécurité: le changement de .2 renvoyé (&mut usize) est considéré comme un appel à `.set_len(_)`.
    ///
    /// Cette méthode est utilisée pour avoir un accès unique à toutes les pièces vec à la fois dans `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` est garanti valable pour les éléments `len`
        // - `spare_ptr` pointe un élément au-delà du tampon, donc il ne chevauche pas `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Redimensionne le `Vec` sur place afin que `len` soit égal à `new_len`.
    ///
    /// Si `new_len` est supérieur à `len`, le `Vec` est étendu de la différence, chaque emplacement supplémentaire étant rempli de `value`.
    ///
    /// Si `new_len` est inférieur à `len`, le `Vec` est simplement tronqué.
    ///
    /// Cette méthode nécessite que `T` implémente [`Clone`], afin de pouvoir cloner la valeur transmise.
    /// Si vous avez besoin de plus de flexibilité (ou si vous souhaitez vous fier à [`Default`] au lieu de [`Clone`]), utilisez [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Clone et ajoute tous les éléments d'une tranche au `Vec`.
    ///
    /// Itère sur la tranche `other`, clone chaque élément, puis l'ajoute à ce `Vec`.
    /// Le `other` vector est traversé dans l'ordre.
    ///
    /// Notez que cette fonction est identique à [`extend`] sauf qu'elle est spécialisée pour travailler avec des tranches à la place.
    ///
    /// Si et quand Rust obtient une spécialisation, cette fonction sera probablement obsolète (mais toujours disponible).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Copie les éléments de la gamme `src` à la fin du vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` garantit que la plage donnée est valide pour l'indexation de soi
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Ce code généralise `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Étendez le vector par des valeurs `n`, en utilisant le générateur donné.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Utilisez SetLenOnDrop pour contourner le bogue où le compilateur peut ne pas réaliser le magasin via `ptr` à self.set_len() sans alias.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Ecrire tous les éléments sauf le dernier
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Incrémentez la longueur à chaque étape dans le cas next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // On peut écrire le dernier élément directement sans cloner inutilement
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len fixé par le garde de la lunette
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Supprime les éléments répétés consécutifs dans le vector selon l'implémentation [`PartialEq`] trait.
    ///
    ///
    /// Si le vector est trié, cela supprime tous les doublons.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Méthodes et fonctions internes
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` doit être un index valide
    /// - `self.capacity() - self.len()` doit être `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len est augmenté uniquement après l'initialisation des éléments
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - l'appelant garantit que src est un index valide
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - L'élément vient d'être initialisé avec `MaybeUninit::write`, il est donc possible d'augmenter le nombre de fois
            // - len est augmenté après chaque élément pour éviter les fuites (voir numéro #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - l'appelant garantit que `src` est un index valide
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Les deux pointeurs sont créés à partir de références de tranche uniques (`&mut [_]`) afin qu'ils soient valides et ne se chevauchent pas.
            //
            // - Les éléments sont: Copier donc il est possible de les copier, sans rien faire avec les valeurs d'origine
            // - `count` est égal au len de `source`, donc la source est valide pour les lectures `count`
            // - `.reserve(count)` garantit que `spare.len() >= count` ainsi de rechange est valide pour les écritures `count`
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Les éléments viennent d'être initialisés par `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Implémentations communes de trait pour Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): avec cfg(test), la méthode `[T]::to_vec` inhérente, qui est requise pour cette définition de méthode, n'est pas disponible.
    // Utilisez plutôt la fonction `slice::to_vec` qui n'est disponible qu'avec cfg(test) NB voir le module slice::hack dans slice.rs pour plus d'informations
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // laissez tomber tout ce qui ne sera pas écrasé
        self.truncate(other.len());

        // self.len <= other.len en raison de la troncature ci-dessus, donc les tranches ici sont toujours dans les limites.
        //
        let (init, tail) = other.split_at(self.len());

        // réutiliser les valeurs contenues allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Crée un itérateur consommateur, c'est-à-dire un itérateur qui déplace chaque valeur hors du vector (du début à la fin).
    /// Le vector ne peut pas être utilisé après l'appel.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s a le type String, pas &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // méthode leaf à laquelle diverses implémentations SpecFrom/SpecExtend délèguent lorsqu'elles n'ont plus d'autres optimisations à appliquer
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // C'est le cas d'un itérateur général.
        //
        // Cette fonction doit être l'équivalent moral de:
        //
        //      pour l'élément dans l'itérateur {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB ne peut pas déborder car nous aurions dû allouer l'espace d'adressage
                self.set_len(len + 1);
            }
        }
    }

    /// Crée un itérateur d'épissage qui remplace la plage spécifiée dans le vector par l'itérateur `replace_with` donné et renvoie les éléments supprimés.
    ///
    /// `replace_with` n'a pas besoin d'être de la même longueur que `range`.
    ///
    /// `range` est supprimé même si l'itérateur n'est pas consommé jusqu'à la fin.
    ///
    /// Le nombre d'éléments supprimés du vector en cas de fuite de la valeur `Splice` n'est pas spécifié.
    ///
    /// L'itérateur d'entrée `replace_with` n'est consommé que lorsque la valeur `Splice` est supprimée.
    ///
    /// Ceci est optimal si:
    ///
    /// * La queue (éléments dans le vector après `range`) est vide,
    /// * ou `replace_with` donne des éléments inférieurs ou égaux à la longueur de la plage
    /// * ou la borne inférieure de son `size_hint()` est exacte.
    ///
    /// Sinon, un vector temporaire est alloué et la queue est déplacée deux fois.
    ///
    /// # Panics
    ///
    /// Panics si le point de départ est supérieur au point final ou si le point final est supérieur à la longueur du vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Crée un itérateur qui utilise une fermeture pour déterminer si un élément doit être supprimé.
    ///
    /// Si la fermeture renvoie true, l'élément est supprimé et produit.
    /// Si la fermeture renvoie false, l'élément restera dans le vector et ne sera pas produit par l'itérateur.
    ///
    /// L'utilisation de cette méthode équivaut au code suivant:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // votre code ici
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Mais `drain_filter` est plus facile à utiliser.
    /// `drain_filter` est également plus efficace, car il peut rétrograder les éléments du tableau en masse.
    ///
    /// Notez que `drain_filter` vous permet également de muter chaque élément de la fermeture du filtre, que vous choisissiez de le conserver ou de le supprimer.
    ///
    ///
    /// # Examples
    ///
    /// Diviser un tableau en unités et des cotes, en réutilisant l'allocation d'origine:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Protégez-vous contre les fuites (amplification des fuites)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Étendez l'implémentation qui copie les éléments des références avant de les pousser sur le Vec.
///
/// Cette implémentation est spécialisée pour les itérateurs de tranche, où elle utilise [`copy_from_slice`] pour ajouter la tranche entière à la fois.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Met en œuvre la comparaison de vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Met en œuvre la commande de vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // utiliser drop pour [T] utiliser une tranche brute pour désigner les éléments du vector comme le type nécessaire le plus faible;
            //
            // pourrait éviter des questions de validité dans certains cas
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec gère la désallocation
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Crée un `Vec<T>` vide.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: test tire dans libstd, ce qui provoque des erreurs ici
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: test tire dans libstd, ce qui provoque des erreurs ici
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Obtient l'intégralité du contenu du `Vec<T>` sous forme de tableau, si sa taille correspond exactement à celle du tableau demandé.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Si la longueur ne correspond pas, l'entrée revient dans `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Si vous êtes d'accord pour obtenir simplement un préfixe du `Vec<T>`, vous pouvez d'abord appeler [`.truncate(N)`](Vec::truncate).
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // SÉCURITÉ: `.set_len(0)` est toujours sonore.
        unsafe { vec.set_len(0) };

        // SÉCURITÉ: le pointeur d'un `Vec` est toujours correctement aligné, et
        // l'alignement dont la matrice a besoin est le même que les éléments.
        // Nous avons vérifié plus tôt que nous avions suffisamment d'articles.
        // Les éléments ne seront pas supprimés deux fois car le `set_len` dit au `Vec` de ne pas les supprimer également.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}