//! Utilitaires pour le formatage et l'impression des chaînes de caractères.
//!
//! Ce module contient le support d'exécution de l'extension de syntaxe [`format!`].
//! Cette macro est implémentée dans le compilateur pour émettre des appels à ce module afin de formater les arguments à l'exécution en chaînes.
//!
//! # Usage
//!
//! La macro [`format!`] est destinée à être familière à ceux provenant des fonctions `printf`/`fprintf` de C ou de la fonction `str.format` de Python.
//!
//! Quelques exemples de l'extension [`format!`] sont:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" avec des zéros non significatifs
//! ```
//!
//! À partir de ceux-ci, vous pouvez voir que le premier argument est une chaîne de format.Il est requis par le compilateur pour que ce soit une chaîne littérale;il ne peut pas s'agir d'une variable transmise (pour effectuer un contrôle de validité).
//! Le compilateur analysera ensuite la chaîne de format et déterminera si la liste d'arguments fournie est appropriée pour passer à cette chaîne de format.
//!
//! Pour convertir une valeur unique en chaîne, utilisez la méthode [`to_string`].Cela utilisera le formatage [`Display`] trait.
//!
//! ## Paramètres de position
//!
//! Chaque argument de mise en forme est autorisé à spécifier l'argument de valeur auquel il fait référence, et s'il est omis, il est supposé être "the next argument".
//! Par exemple, la chaîne de format `{} {} {}` prendrait trois paramètres, et ils seraient formatés dans le même ordre que celui indiqué.
//! La chaîne de format `{2} {1} {0}`, cependant, formaterait les arguments dans l'ordre inverse.
//!
//! Les choses peuvent devenir un peu délicates une fois que vous commencez à mélanger les deux types de spécificateurs positionnels.Le spécificateur "next argument" peut être considéré comme un itérateur sur l'argument.
//! Chaque fois qu'un spécificateur "next argument" est vu, l'itérateur avance.Cela conduit à un comportement comme celui-ci:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! L'itérateur interne sur l'argument n'a pas été avancé au moment où le premier `{}` est vu, il imprime donc le premier argument.Puis, en atteignant le deuxième `{}`, l'itérateur est passé au deuxième argument.
//! Essentiellement, les paramètres qui nomment explicitement leur argument n'affectent pas les paramètres qui ne nomment pas d'argument en termes de spécificateurs de position.
//!
//! Une chaîne de format est requise pour utiliser tous ses arguments, sinon il s'agit d'une erreur de compilation.Vous pouvez faire référence au même argument plusieurs fois dans la chaîne de format.
//!
//! ## Paramètres nommés
//!
//! Rust lui-même n'a pas d'équivalent Python de paramètres nommés pour une fonction, mais la macro [`format!`] est une extension de syntaxe qui lui permet d'exploiter les paramètres nommés.
//! Les paramètres nommés sont répertoriés à la fin de la liste des arguments et ont la syntaxe:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Par exemple, les expressions [`format!`] suivantes utilisent toutes un argument nommé:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Il n'est pas valide de placer des paramètres de position (ceux sans noms) après des arguments qui ont des noms.Comme avec les paramètres de position, il n'est pas valide de fournir des paramètres nommés qui ne sont pas utilisés par la chaîne de format.
//!
//! # Paramètres de formatage
//!
//! Chaque argument en cours de formatage peut être transformé par un certain nombre de paramètres de formatage (correspondant à `format_spec` dans [the syntax](#syntax)). Ces paramètres affectent la représentation sous forme de chaîne de ce qui est formaté.
//!
//! ## Width
//!
//! ```
//! // Tous ces imprimés "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! C'est un paramètre pour le "minimum width" que le format doit prendre.
//! Si la chaîne de la valeur ne remplit pas autant de caractères, le remplissage spécifié par fill/alignment sera utilisé pour occuper l'espace requis (voir ci-dessous).
//!
//! La valeur de la largeur peut également être fournie en tant que [`usize`] dans la liste des paramètres en ajoutant un suffixe `$`, indiquant que le deuxième argument est un [`usize`] spécifiant la largeur.
//!
//! Faire référence à un argument avec la syntaxe dollar n'affecte pas le compteur "next argument", c'est donc généralement une bonne idée de faire référence aux arguments par position ou d'utiliser des arguments nommés.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Le caractère de remplissage et l'alignement facultatifs sont fournis normalement en conjonction avec le paramètre [`width`](#width).Il doit être défini avant `width`, juste après le `:`.
//! Cela indique que si la valeur formatée est inférieure à `width`, des caractères supplémentaires seront imprimés autour d'elle.
//! Le remplissage est disponible dans les variantes suivantes pour différents alignements:
//!
//! * `[fill]<` - l'argument est aligné à gauche dans les colonnes `width`
//! * `[fill]^` - l'argument est aligné au centre dans les colonnes `width`
//! * `[fill]>` - l'argument est aligné à droite dans les colonnes `width`
//!
//! Le [fill/alignment](#fillalignment) par défaut pour les non-numériques est un espace et aligné à gauche.La valeur par défaut pour les formateurs numériques est également un caractère d'espace mais avec un alignement à droite.
//! Si l'indicateur `0` (voir ci-dessous) est spécifié pour les valeurs numériques, le caractère de remplissage implicite est `0`.
//!
//! Notez que l'alignement peut ne pas être implémenté par certains types.En particulier, il n'est généralement pas implémenté pour le `Debug` trait.
//! Un bon moyen de s'assurer que le remplissage est appliqué est de formater votre entrée, puis de remplir cette chaîne résultante pour obtenir votre sortie:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Bonjour Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Ce sont tous des indicateurs modifiant le comportement du formateur.
//!
//! * `+` - Ceci est destiné aux types numériques et indique que le signe doit toujours être imprimé.Les signes positifs ne sont jamais imprimés par défaut et le signe négatif n'est imprimé par défaut que pour le `Signed` trait.
//! Cet indicateur indique que le signe correct (`+` ou `-`) doit toujours être imprimé.
//! * `-` - Actuellement non utilisé
//! * `#` - Cet indicateur indique que la forme d'impression "alternate" doit être utilisée.Les formes alternatives sont:
//!     * `#?` - pretty-print le formatage [`Debug`]
//!     * `#x` - précède l'argument avec un `0x`
//!     * `#X` - précède l'argument avec un `0x`
//!     * `#b` - précède l'argument avec un `0b`
//!     * `#o` - précède l'argument avec un `0o`
//! * `0` - Ceci est utilisé pour indiquer pour les formats d'entiers que le remplissage de `width` doit être à la fois fait avec un caractère `0` et être conscient des signes.
//! Un format comme `{:08}` produirait `00000001` pour l'entier `1`, tandis que le même format produirait `-0000001` pour l'entier `-1`.
//! Notez que la version négative a un zéro de moins que la version positive.
//!         Notez que les zéros de remplissage sont toujours placés après le signe (le cas échéant) et avant les chiffres.Lorsqu'il est utilisé avec l'indicateur `#`, une règle similaire s'applique: les zéros de remplissage sont insérés après le préfixe mais avant les chiffres.
//!         Le préfixe est inclus dans la largeur totale.
//!
//! ## Precision
//!
//! Pour les types non numériques, cela peut être considéré comme un "maximum width".
//! Si la chaîne résultante est plus longue que cette largeur, alors elle est tronquée à autant de caractères et cette valeur tronquée est émise avec les bons `fill`, `alignment` et `width` si ces paramètres sont définis.
//!
//! Pour les types intégraux, ceci est ignoré.
//!
//! Pour les types à virgule flottante, cela indique combien de chiffres après la virgule décimale doivent être imprimés.
//!
//! Il existe trois manières de spécifier le `precision` souhaité:
//!
//! 1. Un entier `.N`:
//!
//!    l'entier `N` lui-même est la précision.
//!
//! 2. Un entier ou un nom suivi du signe dollar `.N$`:
//!
//!    utilisez l'argument format * *`N` (qui doit être un `usize`) comme précision.
//!
//! 3. Un astérisque `.*`:
//!
//!    `.*` signifie que ce `{...}` est associé à *deux* entrées au format plutôt qu'à une: la première entrée contient la précision `usize` et la seconde la valeur à imprimer.
//!    Notez que dans ce cas, si l'on utilise la chaîne de format `{<arg>:<spec>.*}`, alors la partie `<arg>` fait référence à la* valeur * à imprimer, et le `precision` doit venir dans l'entrée précédant `<arg>`.
//!
//! Par exemple, les appels suivants impriment tous la même chose `Hello x is 0.01000`:
//!
//! ```
//! // Bonjour {arg 0 ("x")} est {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Bonjour {arg 1 ("x")} est {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Bonjour {arg 0 ("x")} est {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Bonjour {next arg ("x")} est {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Bonjour {next arg ("x")} est {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Bonjour {next arg ("x")} est {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Alors que ceux-ci:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! imprimez trois choses très différentes:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Dans certains langages de programmation, le comportement des fonctions de formatage de chaîne dépend du paramètre régional du système d'exploitation.
//! Les fonctions de format fournies par la bibliothèque standard de Rust n'ont aucun concept de locale et produiront les mêmes résultats sur tous les systèmes quelle que soit la configuration de l'utilisateur.
//!
//! Par exemple, le code suivant imprimera toujours `1.5` même si les paramètres régionaux du système utilisent un séparateur décimal autre qu'un point.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Les caractères littéraux `{` et `}` peuvent être inclus dans une chaîne en les précédant du même caractère.Par exemple, le caractère `{` est échappé avec `{{` et le caractère `}` est échappé avec `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Pour résumer, vous trouverez ici la grammaire complète des chaînes de format.
//! La syntaxe du langage de formatage utilisé est tirée d'autres langues, elle ne doit donc pas être trop étrangère.Les arguments sont formatés avec une syntaxe de type Python, ce qui signifie que les arguments sont entourés par `{}` au lieu du `%` de type C.
//! La grammaire réelle de la syntaxe de formatage est:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Dans la grammaire ci-dessus, `text` ne peut contenir aucun caractère `'{'` ou `'}'`.
//!
//! # Formatage de traits
//!
//! Lorsque vous demandez qu'un argument soit formaté avec un type particulier, vous demandez en fait qu'un argument soit attribué à un trait particulier.
//! Cela permet à plusieurs types réels d'être formatés via `{:x}` (comme [`i8`] ainsi que [`isize`]).Le mappage actuel des types vers traits est:
//!
//! * *rien* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] avec des entiers hexadécimaux minuscules
//! * `X?` ⇒ [`Debug`] avec des entiers hexadécimaux majuscules
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Cela signifie que tout type d'argument qui implémente le [`fmt::Binary`][`Binary`] trait peut alors être formaté avec `{:b}`.Des implémentations sont également fournies pour ces traits pour un certain nombre de types primitifs par la bibliothèque standard.
//!
//! Si aucun format n'est spécifié (comme dans `{}` ou `{:6}`), alors le format trait utilisé est le [`Display`] trait.
//!
//! Lors de l'implémentation d'un format trait pour votre propre type, vous devrez implémenter une méthode de signature:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // notre type personnalisé
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Votre type sera passé en tant que référence `self`, puis la fonction doit émettre une sortie dans le flux `f.buf`.Il appartient à chaque implémentation de format trait de bien adhérer aux paramètres de formatage demandés.
//! Les valeurs de ces paramètres seront répertoriées dans les champs de la structure [`Formatter`].Pour vous aider, la structure [`Formatter`] fournit également des méthodes d'assistance.
//!
//! De plus, la valeur de retour de cette fonction est [`fmt::Result`] qui est un alias de type de [`Result`]`<(),`[`std: : fmt::Error`] `>`.
//! Les implémentations de formatage doivent garantir qu'elles propagent les erreurs à partir du [`Formatter`] (par exemple, lors de l'appel de [`write!`]).
//! Cependant, ils ne doivent jamais renvoyer des erreurs par erreur.
//! Autrement dit, une implémentation de mise en forme doit et ne peut renvoyer une erreur que si le [`Formatter`] transmis renvoie une erreur.
//! En effet, contrairement à ce que pourrait suggérer la signature de la fonction, le formatage des chaînes est une opération infaillible.
//! Cette fonction renvoie uniquement un résultat car l'écriture dans le flux sous-jacent peut échouer et elle doit fournir un moyen de propager le fait qu'une erreur s'est produite pour sauvegarder la pile.
//!
//! Un exemple d'implémentation du formatage traits ressemblerait à ceci:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // La valeur `f` implémente le `Write` trait, qui est ce que l'écriture!la macro attend.
//!         // Notez que ce formatage ignore les divers indicateurs fournis pour formater les chaînes.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Différents traits permettent différentes formes de sortie d'un type.
//! // La signification de ce format est d'imprimer la magnitude d'un vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Respectez les indicateurs de mise en forme à l'aide de la méthode d'assistance `pad_integral` sur l'objet Formatter.
//!         // Consultez la documentation de la méthode pour plus de détails et la fonction `pad` peut être utilisée pour remplir des chaînes.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` contre `fmt::Debug`
//!
//! Ces deux mises en forme traits ont des finalités distinctes:
//!
//! - [`fmt::Display`][`Display`] Les implémentations affirment que le type peut être fidèlement représenté sous la forme d'une chaîne UTF-8 à tout moment.Il n'est **pas** prévu que tous les types implémentent le [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] les implémentations doivent être implémentées pour **tous les** types publics.
//!   La sortie représentera généralement l'état interne aussi fidèlement que possible.
//!   Le but du [`Debug`] trait est de faciliter le débogage du code Rust.Dans la plupart des cas, l'utilisation de `#[derive(Debug)]` est suffisante et recommandée.
//!
//! Quelques exemples de la sortie des deux traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Macros associées
//!
//! Il existe un certain nombre de macros associées dans la famille [`format!`].Ceux qui sont actuellement mis en œuvre sont:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Ceci et [`writeln!`] sont deux macros qui sont utilisées pour émettre la chaîne de format vers un flux spécifié.Ceci est utilisé pour empêcher les allocations intermédiaires de chaînes de format et à la place écrire directement la sortie.
//! Sous le capot, cette fonction appelle en fait la fonction [`write_fmt`] définie sur le [`std::io::Write`] trait.
//! Exemple d'utilisation:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Celui-ci et [`println!`] émettent leur sortie vers stdout.Comme pour la macro [`write!`], le but de ces macros est d'éviter les allocations intermédiaires lors de l'impression de la sortie.Exemple d'utilisation:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Les macros [`eprint!`] et [`eprintln!`] sont identiques à [`print!`] et [`println!`], respectivement, sauf qu'elles émettent leur sortie vers stderr.
//!
//! ### `format_args!`
//!
//! Il s'agit d'une curieuse macro utilisée pour faire passer en toute sécurité un objet opaque décrivant la chaîne de format.Cet objet ne nécessite aucune allocation de tas pour être créé et il fait uniquement référence aux informations sur la pile.
//! Sous le capot, toutes les macros associées sont implémentées en ce sens.
//! Tout d'abord, voici un exemple d'utilisation:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Le résultat de la macro [`format_args!`] est une valeur de type [`fmt::Arguments`].
//! Cette structure peut ensuite être transmise aux fonctions [`write`] et [`format`] à l'intérieur de ce module afin de traiter la chaîne de format.
//! Le but de cette macro est d'empêcher encore plus les allocations intermédiaires lors de la mise en forme des chaînes.
//!
//! Par exemple, une bibliothèque de journalisation pourrait utiliser la syntaxe de formatage standard, mais elle transmettrait en interne cette structure jusqu'à ce qu'il ait été déterminé où la sortie doit aller.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// La fonction `format` prend une structure [`Arguments`] et renvoie la chaîne formatée résultante.
///
///
/// L'instance [`Arguments`] peut être créée avec la macro [`format_args!`].
///
/// # Examples
///
/// Utilisation de base:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Veuillez noter que l'utilisation de [`format!`] peut être préférable.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}