// Il s'agit d'une tentative d'implémentation suivant l'idéal
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Étant donné que Rust n'a pas réellement de types dépendants et de récursivité polymorphe, nous nous contentons de beaucoup d'insécurité.
//

// Un objectif majeur de ce module est d'éviter la complexité en traitant l'arbre comme un conteneur générique (bien que de forme étrange) et en évitant de traiter la plupart des invariants de l'arbre-B.
//
// En tant que tel, ce module ne se soucie pas de savoir si les entrées sont triées, quels nœuds peuvent être insuffisants, ou même ce que signifie trop bas.Cependant, nous nous appuyons sur quelques invariants:
//
// - Les arbres doivent avoir un depth/height uniforme.Cela signifie que chaque chemin jusqu'à une feuille à partir d'un nœud donné a exactement la même longueur.
// - Un nœud de longueur `n` a des clés `n`, des valeurs `n` et des arêtes `n + 1`.
//   Cela implique que même un nœud vide a au moins un edge.
//   Pour un nœud feuille, "having an edge" signifie uniquement que nous pouvons identifier une position dans le nœud, car les bords de feuille sont vides et n'ont pas besoin de représentation de données.
// Dans un nœud interne, un edge identifie à la fois une position et contient un pointeur vers un nœud enfant.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Représentation sous-jacente des nœuds feuilles et partie de la représentation des nœuds internes.
struct LeafNode<K, V> {
    /// Nous voulons être covariants dans `K` et `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// L'index de ce nœud dans le tableau `edges` du nœud parent.
    /// `*node.parent.edges[node.parent_idx]` devrait être la même chose que `node`.
    /// L'initialisation est garantie uniquement lorsque `parent` est non nul.
    parent_idx: MaybeUninit<u16>,

    /// Le nombre de clés et de valeurs stockées par ce nœud.
    len: u16,

    /// Les tableaux stockant les données réelles du nœud.
    /// Seuls les premiers éléments `len` de chaque tableau sont initialisés et valides.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Initialise un nouveau `LeafNode` sur place.
    unsafe fn init(this: *mut Self) {
        // En règle générale, nous laissons les champs non initialisés s'ils le peuvent, car cela devrait être à la fois légèrement plus rapide et plus facile à suivre dans Valgrind.
        //
        unsafe {
            // parent_idx, keys et vals sont tous MaybeUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Crée un nouveau `LeafNode` en boîte.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// La représentation sous-jacente des nœuds internes.Comme pour les `LeafNode`s, ceux-ci doivent être cachés derrière les`BoxedNode`s pour éviter de laisser tomber des clés et des valeurs non initialisées.
/// Tout pointeur vers un `InternalNode` peut être directement converti en un pointeur vers la partie `LeafNode` sous-jacente du nœud, permettant au code d'agir sur les nœuds feuilles et internes de manière générique sans même avoir à vérifier lequel des deux pointe un pointeur.
///
/// Cette propriété est activée par l'utilisation de `repr(C)`.
///
#[repr(C)]
// gdb_providers.py utilise ce nom de type pour l'introspection.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Les pointeurs vers les enfants de ce nœud.
    /// `len + 1` de ceux-ci sont considérés comme initialisés et valides, sauf que vers la fin, alors que l'arbre est maintenu via le type d'emprunt `Dying`, certains de ces pointeurs sont suspendus.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Crée un nouveau `InternalNode` en boîte.
    ///
    /// # Safety
    /// Un invariant des nœuds internes est qu'ils ont au moins un edge initialisé et valide.
    /// Cette fonction ne met pas en place un tel edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Nous avons seulement besoin d'initialiser les données;les bords sont MaybeUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Pointeur non nul managé vers un nœud.Il s'agit d'un pointeur appartenant à `LeafNode<K, V>` ou d'un pointeur appartenant à `InternalNode<K, V>`.
///
/// Cependant, `BoxedNode` ne contient aucune information sur lequel des deux types de nœuds qu'il contient réellement et, en partie à cause de ce manque d'informations, n'est pas un type distinct et n'a pas de destructeur.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Le nœud racine d'un arbre possédé.
///
/// Notez que cela n'a pas de destructeur et doit être nettoyé manuellement.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Renvoie une nouvelle arborescence possédée, avec son propre nœud racine initialement vide.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` ne doit pas être nul.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Emprunte mutuellement le nœud racine possédé.
    /// Contrairement à `reborrow_mut`, cela est sûr car la valeur de retour ne peut pas être utilisée pour détruire la racine et il ne peut pas y avoir d'autres références à l'arborescence.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Emprunt légèrement mutuellement le nœud racine possédé.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Transitions irréversiblement vers une référence qui permet la traversée et offre des méthodes destructrices et rien d'autre.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Ajoute un nouveau nœud interne avec un seul edge pointant vers le nœud racine précédent, fait de ce nouveau nœud le nœud racine et le renvoie.
    /// Cela augmente la hauteur de 1 et est le contraire de `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, sauf que nous avons juste oublié que nous sommes internes maintenant:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Supprime le nœud racine interne, en utilisant son premier enfant comme nouveau nœud racine.
    /// Comme il est destiné à être appelé uniquement lorsque le nœud racine n'a qu'un seul enfant, aucun nettoyage n'est effectué sur les clés, valeurs et autres enfants.
    ///
    /// Cela diminue la hauteur de 1 et est l'opposé de `push_internal_level`.
    ///
    /// Nécessite un accès exclusif à l'objet `Root` mais pas au nœud racine;
    /// cela n'invalidera pas les autres poignées ou références au nœud racine.
    ///
    /// Panics s'il n'y a pas de niveau interne, c'est-à-dire si le nœud racine est une feuille.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // SÉCURITÉ: nous avons affirmé être internes.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // SÉCURITÉ: nous avons emprunté le `self` exclusivement et son type d'emprunt est exclusif.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // SÉCURITÉ: le premier edge est toujours initialisé.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` est toujours covariant dans `K` et `V`, même lorsque `BorrowType` est `Mut`.
// Ceci est techniquement faux, mais ne peut entraîner aucune insécurité en raison de l'utilisation interne de `NodeRef` car nous restons complètement génériques sur `K` et `V`.
//
// Cependant, chaque fois qu'un type public encapsule `NodeRef`, assurez-vous qu'il a la variance correcte.
//
/// Une référence à un nœud.
///
/// Ce type a un certain nombre de paramètres qui contrôlent la façon dont il agit:
/// - `BorrowType`: Un type factice qui décrit le type d'emprunt et porte toute une vie.
///    - Lorsqu'il s'agit de `Immut<'a>`, le `NodeRef` agit à peu près comme `&'a Node`.
///    - Lorsqu'il s'agit de `ValMut<'a>`, le `NodeRef` agit à peu près comme `&'a Node` en ce qui concerne les clés et la structure de l'arborescence, mais permet également à de nombreuses références mutables à des valeurs dans l'arborescence de coexister.
///    - Lorsqu'il s'agit de `Mut<'a>`, le `NodeRef` agit à peu près comme `&'a mut Node`, bien que les méthodes d'insertion permettent à un pointeur mutable vers une valeur de coexister.
///    - Lorsqu'il s'agit de `Owned`, le `NodeRef` agit à peu près comme `Box<Node>`, mais n'a pas de destructeur et doit être nettoyé manuellement.
///    - Lorsqu'il s'agit de `Dying`, le `NodeRef` agit toujours à peu près comme `Box<Node>`, mais dispose de méthodes pour détruire l'arborescence bit par bit, et les méthodes ordinaires, même si elles ne sont pas marquées comme dangereuses à appeler, peuvent invoquer UB si elles sont appelées de manière incorrecte.
///
///   Étant donné que n'importe quel `NodeRef` permet de naviguer dans l'arborescence, `BorrowType` s'applique effectivement à l'ensemble de l'arborescence, pas seulement au nœud lui-même.
/// - `K` et `V`: ce sont les types de clés et de valeurs stockées dans les nœuds.
/// - `Type`: Cela peut être `Leaf`, `Internal` ou `LeafOrInternal`.
/// Lorsqu'il s'agit de `Leaf`, le `NodeRef` pointe vers un nœud feuille, lorsqu'il s'agit de `Internal`, le `NodeRef` pointe vers un nœud interne, et lorsqu'il s'agit de `LeafOrInternal`, le `NodeRef` peut pointer vers l'un ou l'autre type de nœud.
///   `Type` est nommé `NodeType` lorsqu'il est utilisé en dehors de `NodeRef`.
///
/// Les deux `BorrowType` et `NodeType` limitent les méthodes que nous implémentons, pour exploiter la sécurité de type statique.Il y a des limites à la façon dont nous pouvons appliquer de telles restrictions:
/// - Pour chaque paramètre de type, nous ne pouvons définir une méthode que de manière générique ou pour un type particulier.
/// Par exemple, nous ne pouvons pas définir une méthode comme `into_kv` de manière générique pour tous les `BorrowType`, ou une fois pour tous les types qui portent une durée de vie, car nous voulons qu'elle renvoie des références `&'a`.
///   Par conséquent, nous ne le définissons que pour le type le moins puissant `Immut<'a>`.
/// - Nous ne pouvons pas obtenir de coercition implicite de `Mut<'a>` à `Immut<'a>`.
///   Par conséquent, nous devons appeler explicitement `reborrow` sur un `NodeRef` plus puissant afin d'atteindre une méthode comme `into_kv`.
///
/// Toutes les méthodes sur `NodeRef` qui renvoient une sorte de référence, soit:
/// - Prenez `self` par valeur et renvoyez la durée de vie portée par `BorrowType`.
///   Parfois, pour invoquer une telle méthode, nous devons appeler `reborrow_mut`.
/// - Prenez `self` par référence, et (implicitly) renvoie la durée de vie de cette référence, au lieu de la durée de vie portée par `BorrowType`.
/// De cette façon, le vérificateur d'emprunt garantit que le `NodeRef` reste emprunté tant que la référence retournée est utilisée.
///   Les méthodes supportant l'insertion plient cette règle en renvoyant un pointeur brut, c'est-à-dire une référence sans durée de vie.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Le nombre de niveaux que le nœud et le niveau de feuilles sont séparés, une constante du nœud qui ne peut pas être entièrement décrite par `Type`, et que le nœud lui-même ne stocke pas.
    /// Nous avons seulement besoin de stocker la hauteur du nœud racine et d'en déduire la hauteur de tous les autres nœuds.
    /// Doit être zéro si `Type` est `Leaf` et différent de zéro si `Type` est `Internal`.
    ///
    ///
    height: usize,
    /// Le pointeur vers la feuille ou le nœud interne.
    /// La définition de `InternalNode` garantit que le pointeur est valide dans les deux cas.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Décompressez une référence de nœud qui a été compressée en tant que `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Expose les données d'un nœud interne.
    ///
    /// Renvoie un ptr brut pour éviter d'invalider d'autres références à ce nœud.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // SÉCURITÉ: le type de nœud statique est `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Emprunte l'accès exclusif aux données d'un nœud interne.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Recherche la longueur du nœud.Il s'agit du nombre de clés ou de valeurs.
    /// Le nombre d'arêtes est `len() + 1`.
    /// Notez que, bien que sûr, l'appel de cette fonction peut avoir pour effet secondaire d'invalider les références mutables créées par un code non sécurisé.
    ///
    pub fn len(&self) -> usize {
        // Surtout, nous n'accédons qu'au champ `len` ici.
        // Si BorrowType est marker::ValMut, il peut y avoir des références mutables en suspens à des valeurs que nous ne devons pas invalider.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Renvoie le nombre de niveaux séparés par le nœud et les feuilles.
    /// La hauteur zéro signifie que le nœud est une feuille elle-même.
    /// Si vous imaginez des arbres avec la racine en haut, le nombre indique à quelle altitude le nœud apparaît.
    /// Si vous imaginez des arbres avec des feuilles sur le dessus, le nombre indique la hauteur de l'arbre au-dessus du nœud.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Supprime temporairement une autre référence immuable au même nœud.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Expose la partie feuille de tout nœud feuille ou interne.
    ///
    /// Renvoie un ptr brut pour éviter d'invalider d'autres références à ce nœud.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Le nœud doit être valide pour au moins la partie LeafNode.
        // Ce n'est pas une référence dans le type NodeRef car nous ne savons pas s'il doit être unique ou partagé.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Recherche le parent du nœud actuel.
    /// Renvoie `Ok(handle)` si le nœud actuel a en fait un parent, où `handle` pointe vers le edge du parent qui pointe vers le nœud actuel.
    ///
    /// Renvoie `Err(self)` si le nœud actuel n'a pas de parent, ce qui rend le `NodeRef` d'origine.
    ///
    /// Le nom de la méthode suppose que vous imaginez des arbres avec le nœud racine en haut.
    ///
    /// `edge.descend().ascend().unwrap()` et `node.ascend().unwrap().descend()` devraient tous les deux, en cas de succès, ne rien faire.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Nous devons utiliser des pointeurs bruts vers des nœuds car, si BorrowType est marker::ValMut, il peut y avoir des références mutables exceptionnelles à des valeurs que nous ne devons pas invalider.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Notez que `self` doit être non vide.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Notez que `self` doit être non vide.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Expose la partie feuille de toute feuille ou nœud interne dans un arbre immuable.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // SÉCURITÉ: il ne peut y avoir aucune référence mutable dans cet arbre emprunté comme `Immut`.
        unsafe { &*ptr }
    }

    /// Emprunte une vue des clés stockées dans le nœud.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Similaire à `ascend`, obtient une référence au nœud parent d'un nœud, mais désalloue également le nœud actuel dans le processus.
    /// Ceci n'est pas sûr car le nœud actuel sera toujours accessible malgré sa désallocation.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Unsafely affirme au compilateur les informations statiques que ce nœud est un `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Unsafely affirme au compilateur les informations statiques que ce nœud est un `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Supprime temporairement une autre référence mutable au même nœud.Attention, car cette méthode est très dangereuse, doublement car elle peut ne pas paraître immédiatement dangereuse.
    ///
    /// Étant donné que les pointeurs mutables peuvent se déplacer n'importe où dans l'arborescence, le pointeur renvoyé peut facilement être utilisé pour rendre le pointeur d'origine suspendu, hors limites ou invalide selon les règles d'emprunt empilées.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) envisagez d'ajouter encore un autre paramètre de type à `NodeRef` qui restreint l'utilisation des méthodes de navigation sur les pointeurs réempruntés, évitant ainsi cette insécurité.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Emprunte l'accès exclusif à la partie feuille de n'importe quel nœud feuille ou interne.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // SÉCURITÉ: nous avons un accès exclusif à l'ensemble du nœud.
        unsafe { &mut *ptr }
    }

    /// Offre un accès exclusif à la partie feuille de n'importe quel nœud feuille ou interne.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // SÉCURITÉ: nous avons un accès exclusif à l'ensemble du nœud.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Emprunt un accès exclusif à un élément de la zone de stockage des clés.
    ///
    /// # Safety
    /// `index` est dans les limites de 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // SÉCURITÉ: l'appelant ne pourra pas appeler d'autres méthodes sur lui-même
        // jusqu'à ce que la référence de tranche de clé soit supprimée, car nous avons un accès unique pour la durée de vie de l'emprunt.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Emprunte l'accès exclusif à un élément ou à une tranche de la zone de stockage de valeur du nœud.
    ///
    /// # Safety
    /// `index` est dans les limites de 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // SÉCURITÉ: l'appelant ne pourra pas appeler d'autres méthodes sur lui-même
        // jusqu'à ce que la référence de tranche de valeur soit supprimée, car nous avons un accès unique pour la durée de vie de l'emprunt.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Emprunte l'accès exclusif à un élément ou à une tranche de la zone de stockage du nœud pour le contenu edge.
    ///
    /// # Safety
    /// `index` est dans les limites de 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // SÉCURITÉ: l'appelant ne pourra pas appeler d'autres méthodes sur lui-même
        // jusqu'à ce que la référence de tranche edge soit supprimée, car nous avons un accès unique pour la durée de vie de l'emprunt.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Le nœud a plus de `idx` éléments initialisés.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Nous créons uniquement une référence à l'élément qui nous intéresse, pour éviter les alias avec des références exceptionnelles à d'autres éléments, en particulier, ceux renvoyés à l'appelant dans les itérations précédentes.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Nous devons forcer les pointeurs de tableau non dimensionnés à cause du problème Rust #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Emprunt un accès exclusif à la longueur du nœud.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Définit le lien du nœud vers son parent edge, sans invalider les autres références au nœud.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Efface le lien de la racine vers son parent edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Ajoute une paire clé-valeur à la fin du nœud.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Chaque élément renvoyé par `range` est un index edge valide pour le nœud.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Ajoute une paire clé-valeur et un edge pour aller à droite de cette paire, à la fin du nœud.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Vérifie si un nœud est un nœud `Internal` ou un nœud `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Une référence à une paire clé-valeur spécifique ou edge dans un nœud.
/// Le paramètre `Node` doit être un `NodeRef`, tandis que le `Type` peut être soit `KV` (signifiant un handle sur une paire clé-valeur) ou `Edge` (signifiant un handle sur un edge).
///
/// Notez que même les nœuds `Leaf` peuvent avoir des poignées `Edge`.
/// Au lieu de représenter un pointeur vers un nœud enfant, ils représentent les espaces où les pointeurs enfants iraient entre les paires clé-valeur.
/// Par exemple, dans un nœud de longueur 2, il y aurait 3 emplacements edge possibles, un à gauche du nœud, un entre les deux paires et un à droite du nœud.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Nous n'avons pas besoin de la généralité complète de `#[derive(Clone)]`, car le seul moment où `Node` sera "Clonable" est lorsqu'il s'agit d'une référence immuable et donc `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Récupère le nœud qui contient le edge ou la paire clé-valeur vers laquelle pointe cette poignée.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Renvoie la position de cette poignée dans le nœud.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Crée un nouveau handle vers une paire clé-valeur dans `node`.
    /// Non sécurisé car l'appelant doit s'assurer que `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Il peut s'agir d'une implémentation publique de PartialEq, mais uniquement utilisée dans ce module.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Prend temporairement une autre poignée immuable au même emplacement.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Nous ne pouvons pas utiliser Handle::new_kv ou Handle::new_edge car nous ne connaissons pas notre type
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Unsafely affirme au compilateur les informations statiques que le nœud du handle est un `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Supprime temporairement une autre poignée mutable au même emplacement.
    /// Attention, car cette méthode est très dangereuse, doublement car elle peut ne pas paraître immédiatement dangereuse.
    ///
    ///
    /// Pour plus de détails, consultez `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Nous ne pouvons pas utiliser Handle::new_kv ou Handle::new_edge car nous ne connaissons pas notre type
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Crée une nouvelle poignée pour un edge dans `node`.
    /// Non sécurisé car l'appelant doit s'assurer que `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Étant donné un index edge où nous voulons insérer dans un nœud rempli à pleine capacité, calcule un indice KV sensible d'un point de partage et où effectuer l'insertion.
///
/// Le but du point de partage est que sa clé et sa valeur se retrouvent dans un nœud parent;
/// les clés, les valeurs et les arêtes à gauche du point de partage deviennent l'enfant gauche;
/// les clés, les valeurs et les arêtes à droite du point de partage deviennent le bon enfant.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Problème Rust #74834 tente d'expliquer ces règles symétriques.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Insère une nouvelle paire clé-valeur entre les paires clé-valeur à droite et à gauche de ce edge.
    /// Cette méthode suppose qu'il y a suffisamment d'espace dans le nœud pour que la nouvelle paire s'adapte.
    ///
    /// Le pointeur renvoyé pointe vers la valeur insérée.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Insère une nouvelle paire clé-valeur entre les paires clé-valeur à droite et à gauche de ce edge.
    /// Cette méthode divise le nœud s'il n'y a pas assez de place.
    ///
    /// Le pointeur renvoyé pointe vers la valeur insérée.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Corrige le pointeur et l'index parent dans le nœud enfant auquel ce edge est lié.
    /// Ceci est utile lorsque l'ordre des arêtes a été modifié,
    fn correct_parent_link(self) {
        // Créez un backpointer sans invalider les autres références au nœud.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Insère une nouvelle paire clé-valeur et un edge qui iront à droite de cette nouvelle paire entre ce edge et la paire clé-valeur à droite de ce edge.
    /// Cette méthode suppose qu'il y a suffisamment d'espace dans le nœud pour que la nouvelle paire s'adapte.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Insère une nouvelle paire clé-valeur et un edge qui iront à droite de cette nouvelle paire entre ce edge et la paire clé-valeur à droite de ce edge.
    /// Cette méthode divise le nœud s'il n'y a pas assez de place.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Insère une nouvelle paire clé-valeur entre les paires clé-valeur à droite et à gauche de ce edge.
    /// Cette méthode divise le nœud s'il n'y a pas assez de place et essaie d'insérer la partie séparée dans le nœud parent de manière récursive, jusqu'à ce que la racine soit atteinte.
    ///
    ///
    /// Si le résultat renvoyé est un `Fit`, le nœud de son handle peut être le nœud de ce edge ou un ancêtre.
    /// Si le résultat renvoyé est un `Split`, le champ `left` sera le nœud racine.
    /// Le pointeur renvoyé pointe vers la valeur insérée.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Recherche le nœud pointé par ce edge.
    ///
    /// Le nom de la méthode suppose que vous imaginez des arbres avec le nœud racine en haut.
    ///
    /// `edge.descend().ascend().unwrap()` et `node.ascend().unwrap().descend()` devraient tous les deux, en cas de succès, ne rien faire.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Nous devons utiliser des pointeurs bruts vers des nœuds car, si BorrowType est marker::ValMut, il peut y avoir des références mutables exceptionnelles à des valeurs que nous ne devons pas invalider.
        // Il n'y a aucun souci d'accéder au champ de hauteur car cette valeur est copiée.
        // Attention, une fois que le pointeur de nœud est déréférencé, nous accédons au tableau d'arêtes avec une référence (Rust issue #73987) et annulons toute autre référence vers ou à l'intérieur du tableau, devrait-elle être autour.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Nous ne pouvons pas appeler des méthodes clé et valeur séparées, car l'appel de la seconde invalide la référence renvoyée par la première.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Remplacez la clé et la valeur auxquelles le descripteur KV fait référence.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Aide à la mise en œuvre de `split` pour un `NodeType` particulier, en prenant soin des données feuille.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Divise le nœud sous-jacent en trois parties:
    ///
    /// - Le nœud est tronqué pour ne contenir que les paires clé-valeur à gauche de cette poignée.
    /// - La clé et la valeur pointées par cette poignée sont extraites.
    /// - Toutes les paires clé-valeur à droite de cette poignée sont placées dans un nœud nouvellement alloué.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Supprime la paire clé-valeur pointée par cette poignée et la renvoie, ainsi que le edge dans lequel la paire clé-valeur s'est réduite.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Divise le nœud sous-jacent en trois parties:
    ///
    /// - Le nœud est tronqué pour ne contenir que les arêtes et les paires clé-valeur à gauche de cette poignée.
    /// - La clé et la valeur pointées par cette poignée sont extraites.
    /// - Toutes les arêtes et les paires clé-valeur à droite de cette poignée sont placées dans un nœud nouvellement alloué.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Représente une session d'évaluation et d'exécution d'une opération d'équilibrage autour d'une paire clé-valeur interne.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Choisit un contexte d'équilibrage impliquant le nœud en tant qu'enfant, donc entre le KV immédiatement à gauche ou à droite dans le nœud parent.
    /// Renvoie un `Err` s'il n'y a pas de parent.
    /// Panics si le parent est vide.
    ///
    /// Préfère le côté gauche, pour être optimal si le nœud donné est en quelque sorte insuffisant, ce qui signifie ici seulement qu'il a moins d'éléments que son frère gauche et que son frère droit, s'ils existent.
    /// Dans ce cas, la fusion avec le frère gauche est plus rapide, car il suffit de déplacer les N éléments du nœud, au lieu de les déplacer vers la droite et de déplacer plus de N éléments devant.
    /// Le vol du frère gauche est également généralement plus rapide, car il suffit de déplacer les N éléments du nœud vers la droite, au lieu de déplacer au moins N des éléments du frère vers la gauche.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Renvoie si la fusion est possible, c'est-à-dire s'il y a suffisamment de place dans un nœud pour combiner le KV central avec les deux nœuds enfants adjacents.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Effectue une fusion et laisse une fermeture décider quoi renvoyer.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // SÉCURITÉ: la hauteur des nœuds à fusionner est inférieure à la hauteur
                // du nœud de ce edge, donc au-dessus de zéro, donc ils sont internes.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Fusionne la paire clé-valeur du parent et les deux nœuds enfants adjacents dans le nœud enfant gauche et renvoie le nœud parent réduit.
    ///
    ///
    /// Panics sauf si nous `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Fusionne la paire clé-valeur du parent et les deux nœuds enfants adjacents dans le nœud enfant gauche et renvoie ce nœud enfant.
    ///
    ///
    /// Panics sauf si nous `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Fusionne la paire clé-valeur du parent et les deux nœuds enfants adjacents dans le nœud enfant gauche et renvoie le handle edge dans ce nœud enfant où l'enfant suivi edge s'est retrouvé,
    ///
    ///
    /// Panics sauf si nous `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Supprime une paire clé-valeur de l'enfant gauche et la place dans le stockage clé-valeur du parent, tout en poussant l'ancienne paire clé-valeur parent vers l'enfant droit.
    ///
    /// Renvoie un handle vers le edge dans le bon enfant correspondant à l'endroit où le edge d'origine spécifié par `track_right_edge_idx` s'est terminé.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Supprime une paire clé-valeur de l'enfant droit et la place dans le stockage clé-valeur du parent, tout en poussant l'ancienne paire clé-valeur parent vers l'enfant gauche.
    ///
    /// Renvoie un handle vers le edge dans l'enfant gauche spécifié par `track_left_edge_idx`, qui n'a pas bougé.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Cela fait un vol similaire à `steal_left` mais vole plusieurs éléments à la fois.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Assurez-vous que nous pouvons voler en toute sécurité.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Déplacer les données de feuille.
            {
                // Faites de la place pour les éléments volés chez le bon enfant.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Déplacez les éléments de l'enfant gauche vers celui de droite.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Déplacez la paire volée la plus à gauche vers le parent.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Déplacez la paire clé-valeur du parent vers le bon enfant.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Faites de la place pour les bords volés.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Volez les bords.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Le clone symétrique de `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Assurez-vous que nous pouvons voler en toute sécurité.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Déplacer les données de feuille.
            {
                // Déplacez la paire volée la plus à droite vers le parent.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Déplacez la paire clé-valeur du parent vers l'enfant de gauche.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Déplacez les éléments de l'enfant droit vers celui de gauche.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Remplissez le vide là où se trouvaient les éléments volés.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Volez les bords.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Remplissez l'espace là où se trouvaient les bords volés.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Supprime toutes les informations statiques affirmant que ce nœud est un nœud `Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Supprime toute information statique affirmant que ce nœud est un nœud `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Vérifie si le nœud sous-jacent est un nœud `Internal` ou un nœud `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Déplacez le suffixe après `self` d'un nœud à un autre.`right` doit être vide.
    /// Le premier edge de `right` reste inchangé.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Résultat de l'insertion, lorsqu'un nœud a besoin de s'étendre au-delà de sa capacité.
pub struct SplitResult<'a, K, V, NodeType> {
    // Nœud modifié dans l'arborescence existante avec des éléments et des arêtes qui appartiennent à la gauche de `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Certaines clés et valeurs se séparent, à insérer ailleurs.
    pub kv: (K, V),
    // Nouveau nœud propriétaire, non attaché, avec des éléments et des arêtes qui appartiennent à la droite de `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Indique si les références de nœuds de ce type d'emprunt autorisent la traversée vers d'autres nœuds de l'arborescence.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // La traversée n'est pas nécessaire, elle se produit en utilisant le résultat de `borrow_mut`.
        // En désactivant la traversée, et en ne créant que de nouvelles références aux racines, nous savons que chaque référence de type `Owned` est à un nœud racine.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Insère une valeur dans une tranche d'éléments initialisés suivie d'un élément non initialisé.
///
/// # Safety
/// La tranche contient plus de `idx` éléments.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Supprime et renvoie une valeur d'une tranche de tous les éléments initialisés, laissant derrière un élément non initialisé de fin.
///
///
/// # Safety
/// La tranche contient plus de `idx` éléments.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Décale les éléments d'une tranche `distance` vers la gauche.
///
/// # Safety
/// La tranche a au moins `distance` éléments.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Décale les éléments d'une tranche `distance` vers la droite.
///
/// # Safety
/// La tranche a au moins `distance` éléments.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Déplace toutes les valeurs d'une tranche d'éléments initialisés vers une tranche d'éléments non initialisés, laissant derrière `src` comme tous non initialisés.
///
/// Fonctionne comme `dst.copy_from_slice(src)` mais n'exige pas que `T` soit `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;