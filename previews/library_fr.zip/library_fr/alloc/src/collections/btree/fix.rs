use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef, Root};

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Stocke un nœud éventuellement insuffisant en fusionnant ou en volant un frère ou une sœur.
    /// En cas de succès, mais au prix de la réduction du nœud parent, renvoie ce nœud parent réduit.
    /// Renvoie un `Err` si le nœud est une racine vide.
    ///
    fn fix_node_through_parent(
        self,
    ) -> Result<Option<NodeRef<marker::Mut<'a>, K, V, marker::Internal>>, Self> {
        let len = self.len();
        if len >= MIN_LEN {
            Ok(None)
        } else {
            match self.choose_parent_kv() {
                Ok(Left(mut left_parent_kv)) => {
                    if left_parent_kv.can_merge() {
                        let parent = left_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        left_parent_kv.bulk_steal_left(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Ok(Right(mut right_parent_kv)) => {
                    if right_parent_kv.can_merge() {
                        let parent = right_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        right_parent_kv.bulk_steal_right(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Err(root) => {
                    if len > 0 {
                        Ok(None)
                    } else {
                        Err(root)
                    }
                }
            }
        }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Stocke un nœud éventuellement insuffisant, et si cela entraîne la réduction de son nœud parent, stocke le parent de manière récursive.
    /// Renvoie `true` s'il a corrigé l'arborescence, `false` s'il ne le peut pas car le nœud racine est devenu vide.
    ///
    /// Cette méthode ne s'attend pas à ce que les ancêtres soient déjà insuffisants à l'entrée et panics s'il rencontre un ancêtre vide.
    ///
    ///
    ///
    pub fn fix_node_and_affected_ancestors(mut self) -> bool {
        loop {
            match self.fix_node_through_parent() {
                Ok(Some(parent)) => self = parent.forget_type(),
                Ok(None) => return true,
                Err(_) => return false,
            }
        }
    }
}

impl<K, V> Root<K, V> {
    /// Supprime les niveaux vides sur le dessus, mais garde une feuille vide si tout l'arbre est vide.
    pub fn fix_top(&mut self) {
        while self.height() > 0 && self.len() == 0 {
            self.pop_internal_level();
        }
    }

    /// Stocke ou fusionne tous les nœuds sous-pleins sur la bordure droite de l'arbre.
    /// Les autres nœuds, ceux qui ne sont ni la racine ni un edge le plus à droite, doivent déjà avoir au moins MIN_LEN éléments.
    ///
    pub fn fix_right_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().last_kv().fix_right_border_of_right_edge();
            self.fix_top();
        }
    }

    /// Le clone symétrique de `fix_right_border`.
    pub fn fix_left_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().first_kv().fix_left_border_of_left_edge();
            self.fix_top();
        }
    }

    /// Stockez tous les nœuds sous-pleins sur la bordure droite de l'arbre.
    /// Les autres nœuds, ceux qui ne sont ni la racine ni le edge le plus à droite, doivent être prêts à avoir jusqu'à MIN_LEN éléments volés.
    ///
    pub fn fix_right_border_of_plentiful(&mut self) {
        let mut cur_node = self.borrow_mut();
        while let Internal(internal) = cur_node.force() {
            // Vérifiez si l'enfant le plus à droite est insuffisant.
            let mut last_kv = internal.last_kv().consider_for_balancing();
            debug_assert!(last_kv.left_child_len() >= MIN_LEN * 2);
            let right_child_len = last_kv.right_child_len();
            if right_child_len < MIN_LEN {
                // Nous devons voler.
                last_kv.bulk_steal_left(MIN_LEN - right_child_len);
            }

            // Allez plus bas.
            cur_node = last_kv.into_right_child();
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    fn fix_left_border_of_left_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_left_child().first_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }

    fn fix_right_border_of_right_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_right_child().last_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Stocke l'enfant gauche, en supposant que l'enfant droit n'est pas insuffisant, et fournit un élément supplémentaire pour permettre de fusionner ses enfants à son tour sans devenir insuffisant.
    ///
    /// Renvoie l'enfant gauche.
    ///
    fn fix_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let left_len = internal_kv.left_child_len();
        debug_assert!(internal_kv.right_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` pour éviter de réajuster si la fusion se produit au niveau suivant.
            let count = (MIN_LEN + 1).saturating_sub(left_len);
            if count > 0 {
                internal_kv.bulk_steal_right(count);
            }
            internal_kv.into_left_child()
        }
    }

    /// Stocke l'enfant droit, en supposant que l'enfant gauche n'est pas insuffisant, et fournit un élément supplémentaire pour permettre de fusionner ses enfants à son tour sans devenir insuffisant.
    ///
    /// Retourne là où le bon enfant s'est retrouvé.
    ///
    fn fix_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let right_len = internal_kv.right_child_len();
        debug_assert!(internal_kv.left_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` pour éviter de réajuster si la fusion se produit au niveau suivant.
            let count = (MIN_LEN + 1).saturating_sub(right_len);
            if count > 0 {
                internal_kv.bulk_steal_left(count);
            }
            internal_kv.into_right_child()
        }
    }
}