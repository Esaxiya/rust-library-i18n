use core::cmp::Ordering;
use core::fmt::{self, Debug};
use core::iter::FusedIterator;

/// Noyau d'un itérateur qui fusionne la sortie de deux itérateurs strictement ascendants, par exemple une union ou une différence symétrique.
///
pub struct MergeIterInner<I: Iterator> {
    a: I,
    b: I,
    peeked: Option<Peeked<I>>,
}

/// Benchmarks plus rapides que d'encapsuler les deux itérateurs dans un Peekable, probablement parce que nous pouvons nous permettre d'imposer une borne FusedIterator.
///
#[derive(Clone, Debug)]
enum Peeked<I: Iterator> {
    A(I::Item),
    B(I::Item),
}

impl<I: Iterator> Clone for MergeIterInner<I>
where
    I: Clone,
    I::Item: Clone,
{
    fn clone(&self) -> Self {
        Self { a: self.a.clone(), b: self.b.clone(), peeked: self.peeked.clone() }
    }
}

impl<I: Iterator> Debug for MergeIterInner<I>
where
    I: Debug,
    I::Item: Debug,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("MergeIterInner").field(&self.a).field(&self.b).field(&self.peeked).finish()
    }
}

impl<I: Iterator> MergeIterInner<I> {
    /// Crée un nouveau noyau pour un itérateur fusionnant une paire de sources.
    pub fn new(a: I, b: I) -> Self {
        MergeIterInner { a, b, peeked: None }
    }

    /// Renvoie la prochaine paire d'éléments issus de la paire de sources en cours de fusion.
    /// Si les deux options renvoyées contiennent une valeur, cette valeur est égale et se produit dans les deux sources.
    /// Si l'une des options renvoyées contient une valeur, cette valeur n'apparaît pas dans l'autre source (ou les sources ne sont pas strictement ascendantes).
    ///
    /// Si aucune des options renvoyées ne contient de valeur, l'itération est terminée et les appels suivants renverront la même paire vide.
    ///
    ///
    pub fn nexts<Cmp: Fn(&I::Item, &I::Item) -> Ordering>(
        &mut self,
        cmp: Cmp,
    ) -> (Option<I::Item>, Option<I::Item>)
    where
        I: FusedIterator,
    {
        let mut a_next;
        let mut b_next;
        match self.peeked.take() {
            Some(Peeked::A(next)) => {
                a_next = Some(next);
                b_next = self.b.next();
            }
            Some(Peeked::B(next)) => {
                b_next = Some(next);
                a_next = self.a.next();
            }
            None => {
                a_next = self.a.next();
                b_next = self.b.next();
            }
        }
        if let (Some(ref a1), Some(ref b1)) = (&a_next, &b_next) {
            match cmp(a1, b1) {
                Ordering::Less => self.peeked = b_next.take().map(Peeked::B),
                Ordering::Greater => self.peeked = a_next.take().map(Peeked::A),
                Ordering::Equal => (),
            }
        }
        (a_next, b_next)
    }

    /// Renvoie une paire de limites supérieures pour le `size_hint` de l'itérateur final.
    pub fn lens(&self) -> (usize, usize)
    where
        I: ExactSizeIterator,
    {
        match self.peeked {
            Some(Peeked::A(_)) => (1 + self.a.len(), self.b.len()),
            Some(Peeked::B(_)) => (self.a.len(), 1 + self.b.len()),
            _ => (self.a.len(), self.b.len()),
        }
    }
}