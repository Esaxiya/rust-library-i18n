use core::marker::PhantomData;
use core::ptr::NonNull;

/// Modélise un réemprunt d'une référence unique, lorsque vous savez que le réemprunt et tous ses descendants (c'est-à-dire tous les pointeurs et références qui en dérivent) ne seront plus utilisés à un moment donné, après quoi vous souhaitez réutiliser la référence unique d'origine .
///
///
/// Le vérificateur d'emprunt gère généralement cet empilement d'emprunts à votre place, mais certains flux de contrôle qui accomplissent cet empilement sont trop compliqués à suivre pour le compilateur.
/// Un `DormantMutRef` vous permet de vérifier vous-même l'emprunt, tout en exprimant sa nature empilée et en encapsulant le code du pointeur brut nécessaire pour le faire sans comportement indéfini.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Capturez un emprunt unique et réempruntez-le immédiatement.
    /// Pour le compilateur, la durée de vie de la nouvelle référence est la même que la durée de vie de la référence d'origine, mais vous promise pour l'utiliser pendant une période plus courte.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // SÉCURITÉ: nous détenons l'emprunt tout au long d'un via `_marker`, et nous exposons
        // seulement cette référence, donc elle est unique.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Revenez à l'emprunt unique initialement capturé.
    ///
    /// # Safety
    ///
    /// Le reborrow doit être terminé, c'est-à-dire que la référence renvoyée par `new` et tous les pointeurs et références qui en dérivent ne doivent plus être utilisés.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // SÉCURITÉ: nos propres conditions de sécurité impliquent que cette référence est à nouveau unique.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;