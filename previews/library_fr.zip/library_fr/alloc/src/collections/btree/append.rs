use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Ajoute toutes les paires clé-valeur de l'union de deux itérateurs ascendants, en incrémentant une variable `length` en cours de route.Ce dernier permet à l'appelant d'éviter plus facilement une fuite lorsqu'un gestionnaire de drop panique.
    ///
    /// Si les deux itérateurs produisent la même clé, cette méthode supprime la paire de l'itérateur gauche et ajoute la paire de l'itérateur droit.
    ///
    /// Si vous voulez que l'arborescence se termine dans un ordre strictement croissant, comme pour un `BTreeMap`, les deux itérateurs doivent produire des clés dans un ordre strictement croissant, chacune supérieure à toutes les clés de l'arborescence, y compris toutes les clés déjà présentes dans l'arborescence lors de l'entrée.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Nous nous préparons à fusionner `left` et `right` en une séquence triée en temps linéaire.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Pendant ce temps, nous construisons un arbre à partir de la séquence triée en temps linéaire.
        self.bulk_push(iter, length)
    }

    /// Pousse toutes les paires clé-valeur à la fin de l'arborescence, incrémentant une variable `length` en cours de route.
    /// Ce dernier permet à l'appelant d'éviter plus facilement une fuite lorsque l'itérateur panique.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Parcourez toutes les paires clé-valeur, en les poussant dans les nœuds au bon niveau.
        for (key, value) in iter {
            // Essayez de pousser la paire clé-valeur dans le nœud feuille actuel.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Plus de place, montez et poussez-y.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Vous avez trouvé un nœud avec de l'espace à gauche, appuyez ici.
                                open_node = parent;
                                break;
                            } else {
                                // Remontez.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Nous sommes au sommet, créons un nouveau nœud racine et y poussons.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Poussez la paire clé-valeur et le nouveau sous-arbre droit.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Redescendez à la feuille la plus à droite.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Incrémentez la longueur à chaque itération, pour vous assurer que la carte supprime les éléments ajoutés même si l'avancement de l'itérateur panique.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Un itérateur pour fusionner deux séquences triées en une seule
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Si deux clés sont égales, renvoie la paire clé-valeur de la bonne source.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}