use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Prend temporairement un autre équivalent immuable de la même plage.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Recherche les arêtes de feuille distinctes délimitant une plage spécifiée dans une arborescence.
    /// Renvoie soit une paire de poignées différentes dans le même arbre, soit une paire d'options vides.
    ///
    /// # Safety
    ///
    /// À moins que `BorrowType` soit `Immut`, n'utilisez pas les poignées en double pour visiter le même KV deux fois.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Équivalent à `(root1.first_leaf_edge(), root2.last_leaf_edge())` mais plus efficace.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Recherche la paire d'arêtes de feuille délimitant une plage spécifique dans un arbre.
    ///
    /// Le résultat n'a de sens que si l'arborescence est triée par clé, comme l'arborescence d'un `BTreeMap`.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // SÉCURITÉ: notre type d'emprunt est immuable.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Recherche la paire de bords de feuille délimitant un arbre entier.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Divise une référence unique en une paire d'arêtes de feuille délimitant une plage spécifiée.
    /// Le résultat sont des références non uniques permettant la mutation (some), qui doivent être utilisées avec précaution.
    ///
    /// Le résultat n'a de sens que si l'arborescence est triée par clé, comme l'arborescence d'un `BTreeMap`.
    ///
    ///
    /// # Safety
    /// N'utilisez pas les poignées en double pour visiter le même KV deux fois.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Divise une référence unique en une paire d'arêtes de feuille délimitant la plage complète de l'arbre.
    /// Les résultats sont des références non uniques permettant la mutation (de valeurs uniquement), doivent donc être utilisées avec précaution.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Nous dupliquons ici le NodeRef racine-nous ne visiterons jamais le même KV deux fois et ne nous retrouverons jamais avec des références de valeurs qui se chevauchent.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Divise une référence unique en une paire d'arêtes de feuille délimitant la plage complète de l'arbre.
    /// Les résultats sont des références non uniques permettant une mutation massivement destructrice et doivent donc être utilisées avec le plus grand soin.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Nous dupliquons ici le NodeRef racine-nous n'y accéderons jamais d'une manière qui chevauche les références obtenues à partir de la racine.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Étant donné un handle edge feuille, renvoie [`Result::Ok`] avec un handle vers le KV voisin sur le côté droit, qui se trouve soit dans le même nœud feuille, soit dans un nœud ancêtre.
    ///
    /// Si la feuille edge est la dernière de l'arborescence, renvoie [`Result::Err`] avec le nœud racine.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Étant donné un handle edge feuille, renvoie [`Result::Ok`] avec un handle vers le KV voisin sur le côté gauche, qui se trouve soit dans le même nœud feuille, soit dans un nœud ancêtre.
    ///
    /// Si la feuille edge est la première de l'arborescence, renvoie [`Result::Err`] avec le nœud racine.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Étant donné un handle edge interne, renvoie [`Result::Ok`] avec un handle vers le KV voisin sur le côté droit, qui se trouve soit dans le même nœud interne, soit dans un nœud ancêtre.
    ///
    /// Si le edge interne est le dernier de l'arborescence, renvoie [`Result::Err`] avec le nœud racine.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Étant donné une poignée edge feuille dans un arbre mourant, renvoie la feuille suivante edge sur le côté droit, et la paire clé-valeur entre les deux, qui se trouve soit dans le même nœud feuille, dans un nœud ancêtre, soit inexistante.
    ///
    ///
    /// Cette méthode désalloue également tout node(s) dont il atteint la fin.
    /// Cela implique que s'il n'y a plus de paire clé-valeur, tout le reste de l'arbre aura été désalloué et il ne restera plus rien à retourner.
    ///
    /// # Safety
    /// Le edge donné ne doit pas avoir été précédemment retourné par son homologue `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Étant donné une poignée edge feuille dans un arbre mourant, renvoie la feuille suivante edge sur le côté gauche et la paire clé-valeur entre les deux, qui se trouve soit dans le même nœud feuille, dans un nœud ancêtre, soit inexistante.
    ///
    ///
    /// Cette méthode désalloue également tout node(s) dont il atteint la fin.
    /// Cela implique que s'il n'y a plus de paire clé-valeur, tout le reste de l'arbre aura été désalloué et il ne restera plus rien à retourner.
    ///
    /// # Safety
    /// Le edge donné ne doit pas avoir été précédemment retourné par son homologue `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Désalloue un tas de nœuds de la feuille jusqu'à la racine.
    /// C'est la seule façon de désallouer le reste d'un arbre après que `deallocating_next` et `deallocating_next_back` ont grignoté des deux côtés de l'arbre et ont atteint le même edge.
    /// Comme il est destiné à être appelé uniquement lorsque toutes les clés et valeurs ont été renvoyées, aucun nettoyage n'est effectué sur aucune des clés ou valeurs.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Déplace la poignée edge de la feuille vers la feuille suivante edge et renvoie des références à la clé et à la valeur intermédiaires.
    ///
    ///
    /// # Safety
    /// Il doit y avoir un autre KV dans la direction parcourue.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Déplace la poignée edge de la feuille vers la feuille précédente edge et renvoie des références à la clé et à la valeur intermédiaires.
    ///
    ///
    /// # Safety
    /// Il doit y avoir un autre KV dans la direction parcourue.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Déplace la poignée edge de la feuille vers la feuille suivante edge et renvoie des références à la clé et à la valeur intermédiaires.
    ///
    ///
    /// # Safety
    /// Il doit y avoir un autre KV dans la direction parcourue.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Faire ce dernier est plus rapide, selon les benchmarks.
        kv.into_kv_valmut()
    }

    /// Déplace le handle edge de la feuille vers la feuille précédente et renvoie des références à la clé et à la valeur intermédiaires.
    ///
    ///
    /// # Safety
    /// Il doit y avoir un autre KV dans la direction parcourue.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Faire ce dernier est plus rapide, selon les benchmarks.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Déplace la poignée edge de la feuille vers la feuille suivante edge et renvoie la clé et la valeur entre les deux, libérant tout nœud laissé derrière tout en laissant le edge correspondant dans son nœud parent pendant.
    ///
    /// # Safety
    /// - Il doit y avoir un autre KV dans la direction parcourue.
    /// - Ce KV n'a pas été précédemment renvoyé par son homologue `next_back_unchecked` sur une copie des poignées utilisées pour traverser l'arborescence.
    ///
    /// Le seul moyen sûr de procéder avec la poignée mise à jour est de la comparer, de la supprimer, de rappeler cette méthode sous réserve de ses conditions de sécurité ou d'appeler son homologue `next_back_unchecked` sous réserve de ses conditions de sécurité.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Déplace la poignée edge de la feuille vers la feuille précédente edge et renvoie la clé et la valeur entre les deux, libérant tout nœud laissé en arrière tout en laissant le edge correspondant dans son nœud parent pendant.
    ///
    /// # Safety
    /// - Il doit y avoir un autre KV dans la direction parcourue.
    /// - Cette feuille edge n'a pas été précédemment renvoyée par son homologue `next_unchecked` sur une copie des poignées utilisées pour traverser l'arborescence.
    ///
    /// Le seul moyen sûr de procéder avec la poignée mise à jour est de la comparer, de la supprimer, de rappeler cette méthode sous réserve de ses conditions de sécurité ou d'appeler son homologue `next_unchecked` sous réserve de ses conditions de sécurité.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Renvoie la feuille la plus à gauche edge dans ou sous un nœud, en d'autres termes, le edge dont vous avez besoin en premier lors de la navigation vers l'avant (ou en dernier lors de la navigation vers l'arrière).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Renvoie la feuille la plus à droite edge dans ou sous un nœud, en d'autres termes, le edge dont vous avez besoin en dernier lors de la navigation vers l'avant (ou en premier lors de la navigation vers l'arrière).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Visite les nœuds feuilles et les KV internes par ordre croissant de clés, et visite également les nœuds internes dans leur ensemble dans un premier ordre en profondeur, ce qui signifie que les nœuds internes précèdent leurs KV individuels et leurs nœuds enfants.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Calcule le nombre d'éléments dans un (sous) arbre.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Renvoie la feuille edge la plus proche d'un KV pour la navigation vers l'avant.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Renvoie la feuille edge la plus proche d'un KV pour la navigation vers l'arrière.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}