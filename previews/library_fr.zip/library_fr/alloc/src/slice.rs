//! Une vue à taille dynamique dans une séquence contiguë, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Les tranches sont une vue dans un bloc de mémoire représenté par un pointeur et une longueur.
//!
//! ```
//! // trancher un Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // forcer un tableau à une tranche
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Les tranches sont mutables ou partagées.
//! Le type de tranche partagée est `&[T]`, tandis que le type de tranche mutable est `&mut [T]`, où `T` représente le type d'élément.
//! Par exemple, vous pouvez muter le bloc de mémoire vers lequel pointe une tranche mutable:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Voici quelques éléments que contient ce module:
//!
//! ## Structs
//!
//! Il existe plusieurs structures utiles pour les tranches, telles que [`Iter`], qui représente l'itération sur une tranche.
//!
//! ## Implémentations Trait
//!
//! Il existe plusieurs implémentations de traits communs pour les tranches.Quelques exemples incluent:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], pour les tranches dont le type d'élément est [`Eq`] ou [`Ord`].
//! * [`Hash`] - pour les tranches dont le type d'élément est [`Hash`].
//!
//! ## Iteration
//!
//! Les tranches implémentent `IntoIterator`.L'itérateur renvoie des références aux éléments de tranche.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! La tranche mutable produit des références mutables aux éléments:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Cet itérateur produit des références mutables aux éléments de la tranche. Ainsi, alors que le type d'élément de la tranche est `i32`, le type d'élément de l'itérateur est `&mut i32`.
//!
//!
//! * [`.iter`] et [`.iter_mut`] sont les méthodes explicites pour renvoyer les itérateurs par défaut.
//! * D'autres méthodes qui renvoient des itérateurs sont [`.split`], [`.splitn`], [`.chunks`], [`.windows`] et plus.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// La plupart des utilisations de ce module ne sont utilisées que dans la configuration de test.
// Il est plus simple de désactiver l'avertissement non utilisé_imports que de le corriger.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Méthodes d'extension de tranche de base
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) nécessaire pour l'implémentation de la macro `vec!` lors des tests NB, voir le module `hack` dans ce fichier pour plus de détails.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) nécessaire pour l'implémentation de `Vec::clone` lors des tests NB, voir le module `hack` dans ce fichier pour plus de détails.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Avec cfg(test) `impl [T]` n'est pas disponible, ces trois fonctions sont en fait des méthodes qui sont dans `impl [T]` mais pas dans `core::slice::SliceExt`, nous devons fournir ces fonctions pour le test `test_permutations`
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Nous ne devrions pas ajouter d'attribut en ligne à cela car il est principalement utilisé dans la macro `vec!` et provoque une régression de perf.
    // Voir #71204 pour la discussion et les résultats des performances.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // les éléments ont été marqués comme initialisés dans la boucle ci-dessous
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) est nécessaire pour que LLVM supprime les vérifications de limites et a un meilleur codegen que zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // le vec a été alloué et initialisé ci-dessus à au moins cette longueur.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // alloué ci-dessus avec la capacité de `s`, et initialisez à `s.len()` dans ptr::copy_to_non_overlapping ci-dessous.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Trie la tranche.
    ///
    /// Ce tri est stable (c'est-à-dire qu'il ne réorganise pas les éléments égaux) et *O*(*n*\*log(* n*)) dans le pire des cas.
    ///
    /// Le cas échéant, le tri instable est préférable car il est généralement plus rapide que le tri stable et n'alloue pas de mémoire auxiliaire.
    /// Voir [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Implémentation actuelle
    ///
    /// L'algorithme actuel est un tri de fusion adaptatif et itératif inspiré de [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Il est conçu pour être très rapide dans les cas où la tranche est presque triée ou se compose de deux séquences triées ou plus concaténées l'une après l'autre.
    ///
    ///
    /// En outre, il alloue un stockage temporaire la moitié de la taille de `self`, mais pour les tranches courtes, un tri d'insertion sans allocation est utilisé à la place.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Trie la tranche avec une fonction de comparaison.
    ///
    /// Ce tri est stable (c'est-à-dire qu'il ne réorganise pas les éléments égaux) et *O*(*n*\*log(* n*)) dans le pire des cas.
    ///
    /// La fonction comparateur doit définir un ordre total pour les éléments de la tranche.Si la commande n'est pas totale, l'ordre des éléments n'est pas spécifié.
    /// Une commande est une commande totale si elle l'est (pour tous les `a`, `b` et `c`):
    ///
    /// * total et antisymétrique: exactement l'un des `a < b`, `a == b` ou `a > b` est vrai, et
    /// * transitive, `a < b` et `b < c` implique `a < c`.Il en va de même pour `==` et `>`.
    ///
    /// Par exemple, alors que [`f64`] n'implémente pas [`Ord`] parce que `NaN != NaN`, nous pouvons utiliser `partial_cmp` comme fonction de tri lorsque nous savons que la tranche ne contient pas de `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Le cas échéant, le tri instable est préférable car il est généralement plus rapide que le tri stable et n'alloue pas de mémoire auxiliaire.
    /// Voir [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Implémentation actuelle
    ///
    /// L'algorithme actuel est un tri de fusion adaptatif et itératif inspiré de [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Il est conçu pour être très rapide dans les cas où la tranche est presque triée ou se compose de deux séquences triées ou plus concaténées l'une après l'autre.
    ///
    /// En outre, il alloue un stockage temporaire la moitié de la taille de `self`, mais pour les tranches courtes, un tri d'insertion sans allocation est utilisé à la place.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // tri inversé
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Trie la tranche avec une fonction d'extraction de clé.
    ///
    /// Ce tri est stable (c'est-à-dire qu'il ne réorganise pas les éléments égaux) et *O*(*m*\* * n *\* log(*n*)) dans le pire des cas, où la fonction clé est *O*(*m*).
    ///
    /// Pour des fonctions clés coûteuses (par ex.
    /// fonctions qui ne sont pas de simples accès aux propriétés ou des opérations de base), [`sort_by_cached_key`](slice::sort_by_cached_key) est probablement beaucoup plus rapide, car il ne recalcule pas les clés d'élément.
    ///
    ///
    /// Le cas échéant, le tri instable est préférable car il est généralement plus rapide que le tri stable et n'alloue pas de mémoire auxiliaire.
    /// Voir [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Implémentation actuelle
    ///
    /// L'algorithme actuel est un tri de fusion adaptatif et itératif inspiré de [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Il est conçu pour être très rapide dans les cas où la tranche est presque triée ou se compose de deux séquences triées ou plus concaténées l'une après l'autre.
    ///
    /// En outre, il alloue un stockage temporaire la moitié de la taille de `self`, mais pour les tranches courtes, un tri d'insertion sans allocation est utilisé à la place.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Trie la tranche avec une fonction d'extraction de clé.
    ///
    /// Lors du tri, la fonction clé n'est appelée qu'une seule fois par élément.
    ///
    /// Ce tri est stable (c'est-à-dire qu'il ne réorganise pas les éléments égaux) et *O*(*m*\* * n *+* n *\* log(*n*)) dans le pire des cas, où la fonction clé est *O*(*m*) .
    ///
    /// Pour les fonctions clés simples (par exemple, les fonctions qui sont des accès aux propriétés ou des opérations de base), [`sort_by_key`](slice::sort_by_key) est susceptible d'être plus rapide.
    ///
    /// # Implémentation actuelle
    ///
    /// L'algorithme actuel est basé sur [pattern-defeating quicksort][pdqsort] par Orson Peters, qui combine le cas moyen rapide de tri rapide aléatoire avec le pire cas rapide de tri en tas, tout en obtenant un temps linéaire sur des tranches avec certains modèles.
    /// Il utilise une certaine randomisation pour éviter les cas dégénérés, mais avec un seed fixe pour toujours fournir un comportement déterministe.
    ///
    /// Dans le pire des cas, l'algorithme alloue un stockage temporaire dans un `Vec<(K, usize)>` de la longueur de la tranche.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Macro d'aide pour indexer notre vector par le plus petit type possible, afin de réduire l'allocation.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Les éléments de `indices` sont uniques, car ils sont indexés, donc tout tri sera stable par rapport à la tranche d'origine.
                // Nous utilisons `sort_unstable` ici car il nécessite moins d'allocation de mémoire.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Copie `self` dans un nouveau `Vec`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Ici, `s` et `x` peuvent être modifiés indépendamment.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Copie `self` dans un nouveau `Vec` avec un allocateur.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Ici, `s` et `x` peuvent être modifiés indépendamment.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, voir le module `hack` dans ce fichier pour plus de détails.
        hack::to_vec(self, alloc)
    }

    /// Convertit le `self` en un vector sans clones ni allocation.
    ///
    /// Le vector résultant peut être reconverti en une boîte via `Vec<T>'' méthode `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` ne peut plus être utilisé car il a été converti en `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, voir le module `hack` dans ce fichier pour plus de détails.
        hack::into_vec(self)
    }

    /// Crée un vector en répétant une tranche `n` fois.
    ///
    /// # Panics
    ///
    /// Cette fonction sera panic si la capacité débordait.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// Un panic en cas de débordement:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Si `n` est supérieur à zéro, il peut être divisé en `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` est le nombre représenté par le bit '1' le plus à gauche de `n`, et `rem` est la partie restante de `n`.
        //
        //

        // Utilisation de `Vec` pour accéder à `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` la répétition est effectuée en doublant `buf` "expn"-times.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Si `m > 0`, il reste des bits jusqu'au '1' le plus à gauche.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` a une capacité de `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) la répétition est effectuée en copiant les premières répétitions `rem` de `buf` lui-même.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Cela ne se chevauche pas depuis `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` équivaut à `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Aplatit une tranche de `T` en une seule valeur `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Aplatit une tranche de `T` en une seule valeur `Self::Output`, en plaçant un séparateur donné entre chacune.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Aplatit une tranche de `T` en une seule valeur `Self::Output`, en plaçant un séparateur donné entre chacune.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Renvoie un vector contenant une copie de cette tranche où chaque octet est mappé à son équivalent majuscule ASCII.
    ///
    ///
    /// Les lettres ASCII 'a' à 'z' sont mappées entre 'A' et 'Z', mais les lettres non ASCII restent inchangées.
    ///
    /// Pour mettre en majuscule la valeur sur place, utilisez [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Renvoie un vector contenant une copie de cette tranche où chaque octet est mappé à son équivalent en minuscules ASCII.
    ///
    ///
    /// Les lettres ASCII 'A' à 'Z' sont mappées entre 'a' et 'z', mais les lettres non ASCII restent inchangées.
    ///
    /// Pour mettre en minuscule la valeur sur place, utilisez [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Extension traits pour des tranches sur des types de données spécifiques
////////////////////////////////////////////////////////////////////////////////

/// Aide trait pour [`[T]: : concat`](slice::concat).
///
/// Note: le paramètre de type `Item` n'est pas utilisé dans ce trait, mais il permet à impls d'être plus générique.
/// Sans cela, nous obtenons cette erreur:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// En effet, il pourrait exister des types `V` avec plusieurs impls `Borrow<[_]>`, de sorte que plusieurs types `T` s'appliqueraient:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Le type résultant après concaténation
    type Output;

    /// Implémentation de [`[T]: : concat`](slice::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Aide trait pour [`[T]: : join`](slice::join)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Le type résultant après concaténation
    type Output;

    /// Implémentation de [`[T]: : join`](slice::join)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Implémentations standard trait pour les tranches
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // déposer tout ce qui ne sera pas écrasé dans la cible
        target.truncate(self.len());

        // target.len <= self.len en raison de la troncature ci-dessus, donc les tranches ici sont toujours dans les limites.
        //
        let (init, tail) = self.split_at(target.len());

        // réutiliser les valeurs contenues allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Insère `v[0]` dans la séquence pré-triée `v[1..]` afin que tout `v[..]` soit trié.
///
/// C'est le sous-programme intégral du tri par insertion.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Il existe trois façons d'implémenter l'insertion ici:
            //
            // 1. Échangez les éléments adjacents jusqu'à ce que le premier atteigne sa destination finale.
            //    Cependant, de cette façon, nous copions les données plus que nécessaire.
            //    Si les éléments sont de grandes structures (coûteuses à copier), cette méthode sera lente.
            //
            // 2. Itérez jusqu'à ce que le bon endroit pour le premier élément soit trouvé.
            // Puis décalez les éléments qui lui succèdent pour lui faire de la place et placez-le enfin dans le trou restant.
            // C'est une bonne méthode.
            //
            // 3. Copiez le premier élément dans une variable temporaire.Itérez jusqu'à ce que le bon endroit soit trouvé.
            // Au fur et à mesure, copiez chaque élément traversé dans la fente qui le précède.
            // Enfin, copiez les données de la variable temporaire dans le trou restant.
            // Cette méthode est très bonne.
            // Les benchmarks ont démontré des performances légèrement meilleures qu'avec la 2ème méthode.
            //
            // Toutes les méthodes ont été comparées et la troisième a donné les meilleurs résultats.Nous avons donc choisi celui-là.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // L'état intermédiaire du processus d'insertion est toujours suivi par `hole`, qui sert à deux fins:
            // 1. Protège l'intégrité de `v` de panics dans `is_less`.
            // 2. Remplit le trou restant dans `v` à la fin.
            //
            // Sécurité Panic:
            //
            // Si `is_less` panics à un moment quelconque du processus, `hole` sera abandonné et remplira le trou de `v` avec `tmp`, garantissant ainsi que `v` contienne toujours chaque objet qu'il détenait initialement exactement une fois.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` est abandonné et copie ainsi `tmp` dans le trou restant de `v`.
        }
    }

    // Une fois déposé, copie de `src` vers `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Fusionne les exécutions non décroissantes `v[..mid]` et `v[mid..]` en utilisant `buf` comme stockage temporaire et stocke le résultat dans `v[..]`.
///
/// # Safety
///
/// Les deux tranches doivent être non vides et `mid` doit être dans les limites.
/// Le tampon `buf` doit être suffisamment long pour contenir une copie de la tranche la plus courte.
/// En outre, `T` ne doit pas être un type de taille zéro.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Le processus de fusion copie d'abord le tirage le plus court dans `buf`.
    // Ensuite, il retrace l'exécution nouvellement copiée et l'exécution la plus longue en avant (ou en arrière), en comparant leurs prochains éléments non consommés et en copiant le plus petit (ou plus grand) dans `v`.
    //
    // Dès que le tirage le plus court est entièrement consommé, le processus est terminé.Si la partie la plus longue est consommée en premier, nous devons copier ce qui reste de la partie la plus courte dans le trou restant de `v`.
    //
    // L'état intermédiaire du processus est toujours suivi par `hole`, qui sert à deux fins:
    // 1. Protège l'intégrité de `v` de panics dans `is_less`.
    // 2. Remplit le trou restant dans `v` si la partie la plus longue est consommée en premier.
    //
    // Sécurité Panic:
    //
    // Si `is_less` panics à un moment quelconque du processus, `hole` sera abandonné et remplira le trou de `v` avec la plage non consommée de `buf`, garantissant ainsi que `v` contienne toujours chaque objet qu'il détenait initialement exactement une fois.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // La course de gauche est plus courte.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Initialement, ces pointeurs pointent vers les débuts de leurs tableaux.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Consommez le petit côté.
            // Si égal, préférez la course de gauche pour maintenir la stabilité.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // La bonne course est plus courte.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Initialement, ces pointeurs pointent au-delà des extrémités de leurs tableaux.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Consommez le plus grand côté.
            // Si égal, préférez la bonne course pour maintenir la stabilité.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Enfin, `hole` est abandonné.
    // Si le tirage le plus court n'a pas été entièrement consommé, tout ce qui en reste sera maintenant copié dans le trou de `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Lorsqu'elle est déposée, copie la plage `start..end` dans `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` n'est pas un type de taille zéro, donc vous pouvez diviser par sa taille.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Ce tri de fusion emprunte certaines idées (mais pas toutes) de TimSort, qui est décrit en détail [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// L'algorithme identifie les sous-séquences strictement descendantes et non descendantes, appelées exécutions naturelles.Il y a une pile d'exécutions en attente qui n'ont pas encore été fusionnées.
/// Chaque exécution nouvellement trouvée est poussée sur la pile, puis certaines paires de courses adjacentes sont fusionnées jusqu'à ce que ces deux invariants soient satisfaits:
///
/// 1. pour chaque `i` dans `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. pour chaque `i` dans `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Les invariants garantissent que la durée totale de fonctionnement est de *O*(*n*\*log(* n*)) dans le pire des cas.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Les tranches jusqu'à cette longueur sont triées à l'aide du tri par insertion.
    const MAX_INSERTION: usize = 20;
    // Les tirages très courts sont étendus à l'aide du tri par insertion pour couvrir au moins autant d'éléments.
    const MIN_RUN: usize = 10;

    // Le tri n'a pas de comportement significatif sur les types de taille zéro.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Les tableaux courts sont triés sur place via le tri par insertion pour éviter les allocations.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Allouez un tampon à utiliser comme mémoire de travail.Nous gardons la longueur 0 afin de pouvoir y conserver des copies superficielles du contenu de `v` sans risquer les détecteurs s'exécutant sur des copies si `is_less` panics.
    //
    // Lors de la fusion de deux analyses triées, ce tampon contient une copie de l'analyse la plus courte, qui aura toujours une longueur d'au plus `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Afin d'identifier les courses naturelles dans `v`, nous la parcourons à l'envers.
    // Cela peut sembler une décision étrange, mais considérez le fait que les fusions vont plus souvent dans la direction opposée (forwards).
    // Selon les benchmarks, la fusion vers l'avant est légèrement plus rapide que la fusion vers l'arrière.
    // Pour conclure, l'identification des exécutions en parcourant en arrière améliore les performances.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Trouvez la prochaine course naturelle et inversez-la si elle est strictement descendante.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Insérez quelques éléments supplémentaires dans la course si elle est trop courte.
        // Le tri par insertion est plus rapide que le tri par fusion sur des séquences courtes, ce qui améliore considérablement les performances.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Poussez cette course sur la pile.
        runs.push(Run { start, len: end - start });
        end = start;

        // Fusionnez quelques paires d'exécutions adjacentes pour satisfaire les invariants.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Enfin, exactement une exécution doit rester dans la pile.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Examine la pile d'exécutions et identifie la prochaine paire d'exécutions à fusionner.
    // Plus précisément, si `Some(r)` est renvoyé, cela signifie que `runs[r]` et `runs[r + 1]` doivent être fusionnés ensuite.
    // Si l'algorithme doit continuer à créer une nouvelle exécution à la place, `None` est renvoyé.
    //
    // TimSort est tristement célèbre pour ses implémentations boguées, comme décrit ici:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // L'essentiel de l'histoire est le suivant: nous devons appliquer les invariants sur les quatre premières courses de la pile.
    // Les appliquer uniquement sur les trois premiers n'est pas suffisant pour garantir que les invariants seront toujours valables pour *toutes* les exécutions dans la pile.
    //
    // Cette fonction vérifie correctement les invariants pour les quatre premières exécutions.
    // En outre, si l'exécution supérieure commence à l'index 0, elle exigera toujours une opération de fusion jusqu'à ce que la pile soit entièrement réduite, afin de terminer le tri.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}