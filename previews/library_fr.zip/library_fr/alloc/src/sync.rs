#![stable(feature = "rust1", since = "1.0.0")]

//! Pointeurs de comptage de références sans fil.
//!
//! Consultez la documentation du [`Arc<T>`][Arc] pour plus de détails.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Une limite souple sur le nombre de références qui peuvent être faites à un `Arc`.
///
/// Dépasser cette limite annulera votre programme (mais pas nécessairement) aux références _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer ne prend pas en charge les clôtures de mémoire.
// Pour éviter les faux rapports positifs dans l'implémentation Arc/Weak, utilisez plutôt des charges atomiques pour la synchronisation.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Un pointeur de comptage de références thread-safe.'Arc' signifie «Atomically Reference Counted».
///
/// Le type `Arc<T>` fournit la propriété partagée d'une valeur de type `T`, allouée dans le tas.L'appel de [`clone`][clone] sur `Arc` produit une nouvelle instance `Arc`, qui pointe vers la même allocation sur le tas que la source `Arc`, tout en augmentant le nombre de références.
/// Lorsque le dernier pointeur `Arc` vers une allocation donnée est détruit, la valeur stockée dans cette allocation (souvent appelée "inner value") est également supprimée.
///
/// Les références partagées dans Rust interdisent la mutation par défaut, et `Arc` ne fait pas exception: vous ne pouvez généralement pas obtenir une référence mutable à quelque chose à l'intérieur d'un `Arc`.Si vous devez muter via un `Arc`, utilisez [`Mutex`][mutex], [`RwLock`][rwlock] ou l'un des types [`Atomic`][atomic].
///
/// ## Sécurité du fil
///
/// Contrairement à [`Rc<T>`], `Arc<T>` utilise des opérations atomiques pour son comptage de références.Cela signifie qu'il est thread-safe.L'inconvénient est que les opérations atomiques sont plus coûteuses que les accès mémoire ordinaires.Si vous ne partagez pas les allocations comptées par référence entre les threads, envisagez d'utiliser [`Rc<T>`] pour réduire la surcharge.
/// [`Rc<T>`] est une valeur par défaut sûre, car le compilateur interceptera toute tentative d'envoi d'un [`Rc<T>`] entre les threads.
/// Cependant, une bibliothèque peut choisir `Arc<T>` afin de donner plus de flexibilité aux consommateurs de bibliothèque.
///
/// `Arc<T>` implémentera [`Send`] et [`Sync`] tant que le `T` implémentera [`Send`] et [`Sync`].
/// Pourquoi ne pouvez-vous pas mettre un type `T` non thread-safe dans un `Arc<T>` pour le rendre thread-safe?Cela peut être un peu contre-intuitif au début: après tout, n'est-ce pas le but de la sécurité des threads `Arc<T>`?La clé est la suivante: `Arc<T>` fait en sorte qu'il soit sûr pour les threads d'avoir plusieurs propriétaires des mêmes données, mais il n'ajoute pas de sécurité de thread à ses données.
///
/// Considérez `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] n'est pas [`Sync`], et si `Arc<T>` était toujours [`Send`], `Arc <` [`RefCell<T>`]`>`le serait aussi.
/// Mais alors nous aurions un problème:
/// [`RefCell<T>`] n'est pas thread-safe;il garde la trace du nombre d'emprunts à l'aide d'opérations non atomiques.
///
/// En fin de compte, cela signifie que vous devrez peut-être coupler `Arc<T>` avec une sorte de type [`std::sync`], généralement [`Mutex<T>`][mutex].
///
/// ## Cycles de rupture avec `Weak`
///
/// La méthode [`downgrade`][downgrade] peut être utilisée pour créer un pointeur [`Weak`] non propriétaire.Un pointeur [`Weak`] peut être [`upgrade`][upgrade] d vers un `Arc`, mais cela renverra [`None`] si la valeur stockée dans l'allocation a déjà été supprimée.
/// En d'autres termes, les pointeurs `Weak` ne conservent pas la valeur à l'intérieur de l'allocation active;cependant, ils *font* garder l'allocation (le magasin de sauvegarde pour la valeur) en vie.
///
/// Un cycle entre des pointeurs `Arc` ne sera jamais désalloué.
/// Pour cette raison, [`Weak`] est utilisé pour interrompre les cycles.Par exemple, une arborescence peut avoir des pointeurs `Arc` puissants des nœuds parents vers les enfants et des pointeurs [`Weak`] des enfants vers leurs parents.
///
/// # Références de clonage
///
/// La création d'une nouvelle référence à partir d'un pointeur compté de références existant se fait à l'aide du `Clone` trait implémenté pour [`Arc<T>`][Arc] et [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Les deux syntaxes ci-dessous sont équivalentes.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b et foo sont tous des arcs qui pointent vers le même emplacement mémoire
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` déréférence automatiquement à `T` (via le [`Deref`][deref] trait), vous pouvez donc appeler les méthodes de `T` sur une valeur de type `Arc<T>`.Pour éviter les conflits de noms avec les méthodes de `T`, les méthodes de `Arc<T>` lui-même sont des fonctions associées, appelées à l'aide de [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>Les implémentations de traits comme `Clone` peuvent également être appelées en utilisant une syntaxe pleinement qualifiée.
/// Certaines personnes préfèrent utiliser une syntaxe pleinement qualifiée, tandis que d'autres préfèrent utiliser la syntaxe d'appel de méthode.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Syntaxe d'appel de méthode
/// let arc2 = arc.clone();
/// // Syntaxe entièrement qualifiée
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] ne déréférencera pas automatiquement à `T`, car la valeur interne a peut-être déjà été supprimée.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Partage de données immuables entre les threads:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Notez que nous **n'exécutons pas** ces tests ici.
// Les constructeurs windows sont très mécontents si un thread survit au thread principal puis se termine en même temps (quelque chose de bloquant) donc nous évitons complètement cela en n'exécutant pas ces tests.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Partage d'un [`AtomicUsize`] mutable:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Voir le [`rc` documentation][rc_examples] pour plus d'exemples de comptage de références en général.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` est une version de [`Arc`] qui contient une référence non propriétaire à l'allocation gérée.
/// L'allocation est accessible en appelant [`upgrade`] sur le pointeur `Weak`, qui renvoie une [`Option`]`<`[`Arc`] `<T>>`.
///
/// Puisqu'une référence `Weak` ne compte pas dans la propriété, elle n'empêchera pas la valeur stockée dans l'allocation d'être supprimée, et `Weak` lui-même ne donne aucune garantie quant à la valeur toujours présente.
///
/// Ainsi, il peut renvoyer [`None`] lorsque [`upgrade`] d.
/// Notez cependant qu'une référence `Weak`*n'empêche* pas l'allocation elle-même (le magasin de sauvegarde) d'être désallouée.
///
/// Un pointeur `Weak` est utile pour conserver une référence temporaire à l'allocation gérée par [`Arc`] sans empêcher la suppression de sa valeur interne.
/// Il est également utilisé pour empêcher les références circulaires entre les pointeurs [`Arc`], car les références de propriété mutuelle ne permettraient jamais de supprimer l'un ou l'autre de [`Arc`].
/// Par exemple, une arborescence peut avoir des pointeurs [`Arc`] puissants des nœuds parents vers les enfants et des pointeurs `Weak` des enfants vers leurs parents.
///
/// La méthode classique pour obtenir un pointeur `Weak` consiste à appeler [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Il s'agit d'un `NonNull` pour permettre d'optimiser la taille de ce type dans les énumérations, mais ce n'est pas forcément un pointeur valide.
    //
    // `Weak::new` définit ceci sur `usize::MAX` afin qu'il n'ait pas besoin d'allouer d'espace sur le tas.
    // Ce n'est pas une valeur qu'un vrai pointeur aura jamais car RcBox a un alignement d'au moins 2.
    // Ceci n'est possible que lorsque `T: Sized`;`T` non dimensionné ne pend jamais.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Il s'agit d'une protection repr(C) à future contre d'éventuelles réorganisations de champ, qui interféreraient avec des [into|from]_raw() autrement sûrs de types internes transmutables.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // la valeur usize::MAX agit comme une sentinelle pour "locking" temporairement la capacité de mettre à niveau les pointeurs faibles ou de rétrograder les pointeurs forts;ceci est utilisé pour éviter les courses dans `make_mut` et `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Construit un nouveau `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Commencez le nombre de pointeurs faibles à 1, qui est le pointeur faible détenu par tous les pointeurs forts (kinda), voir std/rc.rs pour plus d'informations
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Construit un nouveau `Arc<T>` en utilisant une référence faible à lui-même.
    /// Tenter de mettre à niveau la référence faible avant le retour de cette fonction entraînera une valeur `None`.
    /// Cependant, la référence faible peut être clonée librement et stockée pour une utilisation ultérieure.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Construisez l'intérieur dans l'état "uninitialized" avec une seule référence faible.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Il est important que nous n'abandonnions pas la propriété du pointeur faible, sinon la mémoire pourrait être libérée au retour de `data_fn`.
        // Si nous voulions vraiment transmettre la propriété, nous pourrions créer un pointeur faible supplémentaire pour nous-mêmes, mais cela entraînerait des mises à jour supplémentaires du nombre de références faibles qui pourraient ne pas être nécessaires autrement.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Maintenant, nous pouvons correctement initialiser la valeur interne et transformer notre référence faible en une référence forte.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // L'écriture ci-dessus dans le champ de données doit être visible par tous les threads qui observent un nombre fort différent de zéro.
            // Par conséquent, nous avons besoin d'au moins une commande "Release" afin de synchroniser avec le `compare_exchange_weak` dans `Weak::upgrade`.
            //
            // "Acquire" la commande n'est pas requise.
            // Lors de l'examen des comportements possibles de `data_fn`, il suffit de regarder ce qu'il pourrait faire avec une référence à un `Weak` non évolutif:
            //
            // - Il peut *cloner* le `Weak`, augmentant ainsi le nombre de références faibles.
            // - Il peut supprimer ces clones, réduisant le nombre de références faibles (mais jamais à zéro).
            //
            // Ces effets secondaires ne nous impactent en aucune façon, et aucun autre effet secondaire n'est possible avec le code sécurisé seul.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Les références fortes doivent collectivement posséder une référence faible partagée, alors ne lancez pas le destructeur pour notre ancienne référence faible.
        //
        mem::forget(weak);
        strong
    }

    /// Construit un nouveau `Arc` avec un contenu non initialisé.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Initialisation différée:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Construit un nouveau `Arc` avec un contenu non initialisé, la mémoire étant remplie d'octets `0`.
    ///
    ///
    /// Voir [`MaybeUninit::zeroed`][zeroed] pour des exemples d'utilisation correcte et incorrecte de cette méthode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Construit un nouveau `Pin<Arc<T>>`.
    /// Si `T` n'implémente pas `Unpin`, alors `data` sera épinglé en mémoire et ne pourra pas être déplacé.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Construit un nouveau `Arc<T>`, renvoyant une erreur si l'allocation échoue.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Commencez le nombre de pointeurs faibles à 1, qui est le pointeur faible détenu par tous les pointeurs forts (kinda), voir std/rc.rs pour plus d'informations
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Construit un nouveau `Arc` avec un contenu non initialisé, renvoyant une erreur si l'allocation échoue.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Initialisation différée:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Construit un nouveau `Arc` avec un contenu non initialisé, la mémoire étant remplie d'octets `0`, renvoyant une erreur si l'allocation échoue.
    ///
    ///
    /// Voir [`MaybeUninit::zeroed`][zeroed] pour des exemples d'utilisation correcte et incorrecte de cette méthode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Renvoie la valeur interne, si le `Arc` a exactement une référence forte.
    ///
    /// Sinon, un [`Err`] est renvoyé avec le même `Arc` qui a été transmis.
    ///
    ///
    /// Cela réussira même s'il y a des références faibles exceptionnelles.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Créer un pointeur faible pour nettoyer la référence implicite fort-faible
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Construit une nouvelle tranche comptée par référence atomique avec un contenu non initialisé.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Initialisation différée:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Construit une nouvelle tranche comptée par référence atomique avec un contenu non initialisé, la mémoire étant remplie d'octets `0`.
    ///
    ///
    /// Voir [`MaybeUninit::zeroed`][zeroed] pour des exemples d'utilisation correcte et incorrecte de cette méthode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Se convertit en `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Comme avec [`MaybeUninit::assume_init`], il appartient à l'appelant de garantir que la valeur interne est vraiment dans un état initialisé.
    ///
    /// L'appeler lorsque le contenu n'est pas encore complètement initialisé entraîne un comportement indéfini immédiat.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Initialisation différée:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Se convertit en `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Comme avec [`MaybeUninit::assume_init`], il appartient à l'appelant de garantir que la valeur interne est vraiment dans un état initialisé.
    ///
    /// L'appeler lorsque le contenu n'est pas encore complètement initialisé entraîne un comportement indéfini immédiat.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Initialisation différée:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Consomme le `Arc`, renvoyant le pointeur encapsulé.
    ///
    /// Pour éviter une fuite de mémoire, le pointeur doit être reconverti en `Arc` à l'aide de [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Fournit un pointeur brut vers les données.
    ///
    /// Les décomptes ne sont en aucun cas affectés et le `Arc` n'est pas consommé.
    /// Le pointeur est valide tant qu'il y a des comptages forts dans le `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // SÉCURITÉ: Cela ne peut pas passer par Deref::deref ou RcBoxPtr::inner car
        // ceci est nécessaire pour conserver la provenance raw/mut telle que par exemple
        // `get_mut` peut écrire via le pointeur après la récupération du Rc via `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Construit un `Arc<T>` à partir d'un pointeur brut.
    ///
    /// Le pointeur brut doit avoir été précédemment renvoyé par un appel à [`Arc<U>::into_raw`][into_raw] où `U` doit avoir la même taille et le même alignement que `T`.
    /// C'est trivialement vrai si `U` est `T`.
    /// Notez que si `U` n'est pas `T` mais a la même taille et le même alignement, cela revient essentiellement à transmuter des références de types différents.
    /// Voir [`mem::transmute`][transmute] pour plus d'informations sur les restrictions qui s'appliquent dans ce cas.
    ///
    /// L'utilisateur de `from_raw` doit s'assurer qu'une valeur spécifique de `T` n'est supprimée qu'une seule fois.
    ///
    /// Cette fonction n'est pas sûre car une utilisation incorrecte peut conduire à une insécurité de la mémoire, même si le `Arc<T>` renvoyé n'est jamais accédé.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Reconvertissez-le en `Arc` pour éviter les fuites.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // D'autres appels à `Arc::from_raw(x_ptr)` seraient dangereux pour la mémoire.
    /// }
    ///
    /// // La mémoire a été libérée lorsque `x` est sorti de la portée ci-dessus, donc `x_ptr` est maintenant suspendu!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Inversez le décalage pour trouver l'ArcInner d'origine.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Crée un nouveau pointeur [`Weak`] vers cette allocation.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Cette Relaxed est OK car nous vérifions la valeur dans le CAS ci-dessous.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // vérifier si le compteur faible est actuellement "locked";si c'est le cas, faites tourner.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: ce code ignore actuellement la possibilité de débordement
            // dans usize::MAX;en général, Rc et Arc doivent être ajustés pour faire face au débordement.
            //

            // Contrairement à Clone(), nous avons besoin que ce soit une lecture d'acquisition pour se synchroniser avec l'écriture provenant de `is_unique`, de sorte que les événements précédant cette écriture se produisent avant cette lecture.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Assurez-vous que nous ne créons pas un faible pendant
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Obtient le nombre de pointeurs [`Weak`] vers cette allocation.
    ///
    /// # Safety
    ///
    /// Cette méthode en elle-même est sûre, mais son utilisation correcte nécessite des précautions supplémentaires.
    /// Un autre thread peut modifier le nombre faible à tout moment, y compris potentiellement entre l'appel de cette méthode et l'action sur le résultat.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Cette assertion est déterministe car nous n'avons pas partagé le `Arc` ou `Weak` entre les threads.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Si le décompte faible est actuellement verrouillé, la valeur du décompte était 0 juste avant de prendre le verrou.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Obtient le nombre de pointeurs (`Arc`) puissants vers cette allocation.
    ///
    /// # Safety
    ///
    /// Cette méthode en elle-même est sûre, mais son utilisation correcte nécessite des précautions supplémentaires.
    /// Un autre thread peut modifier le nombre fort à tout moment, y compris potentiellement entre l'appel de cette méthode et l'action sur le résultat.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Cette assertion est déterministe car nous n'avons pas partagé le `Arc` entre les threads.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Incrémente de un le nombre de références fortes sur le `Arc<T>` associé au pointeur fourni.
    ///
    /// # Safety
    ///
    /// Le pointeur doit avoir été obtenu via `Arc::into_raw` et l'instance `Arc` associée doit être valide (c.-à-d.
    /// le nombre fort doit être d'au moins 1) pendant la durée de cette méthode.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Cette assertion est déterministe car nous n'avons pas partagé le `Arc` entre les threads.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Conserver l'arc, mais ne touchez pas refcount en enveloppant dans ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Augmentez maintenant le nombre de refcount, mais ne supprimez pas non plus de nouveau refcount
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Décrémente de un le nombre de références fortes sur le `Arc<T>` associé au pointeur fourni.
    ///
    /// # Safety
    ///
    /// Le pointeur doit avoir été obtenu via `Arc::into_raw` et l'instance `Arc` associée doit être valide (c.-à-d.
    /// le nombre fort doit être au moins 1) lors de l'appel de cette méthode.
    /// Cette méthode peut être utilisée pour libérer le `Arc` final et le stockage de sauvegarde, mais **ne doit pas** être appelé après la publication du `Arc` final.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Ces affirmations sont déterministes car nous n'avons pas partagé le `Arc` entre les threads.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Cette insécurité est acceptable car tant que cet arc est vivant, nous sommes assurés que le pointeur interne est valide.
        // De plus, nous savons que la structure `ArcInner` elle-même est `Sync` parce que les données internes sont également `Sync`, nous pouvons donc prêter un pointeur immuable vers ces contenus.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Partie non intégrée de `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Détruisez les données à ce moment, même si nous ne pouvons pas libérer l'allocation de boîte elle-même (il peut encore y avoir des pointeurs faibles).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Abandonnez la référence faible détenue collectivement par toutes les références fortes
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Renvoie `true` si les deux `Arc`s pointent vers la même allocation (dans une veine similaire à [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Alloue un `ArcInner<T>` avec un espace suffisant pour une valeur interne éventuellement non dimensionnée où la valeur a la disposition fournie.
    ///
    /// La fonction `mem_to_arcinner` est appelée avec le pointeur de données et doit renvoyer un pointeur (potentiellement gros) pour le `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Calculez la disposition en utilisant la disposition de valeur donnée.
        // Auparavant, la mise en page était calculée sur l'expression `&*(ptr as* const ArcInner<T>)`, mais cela créait une référence mal alignée (voir #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Alloue un `ArcInner<T>` avec un espace suffisant pour une valeur interne éventuellement non dimensionnée où la valeur a la disposition fournie, renvoyant une erreur si l'allocation échoue.
    ///
    ///
    /// La fonction `mem_to_arcinner` est appelée avec le pointeur de données et doit renvoyer un pointeur (potentiellement gros) pour le `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Calculez la disposition en utilisant la disposition de valeur donnée.
        // Auparavant, la mise en page était calculée sur l'expression `&*(ptr as* const ArcInner<T>)`, mais cela créait une référence mal alignée (voir #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Initialiser l'ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Alloue un `ArcInner<T>` avec un espace suffisant pour une valeur interne non dimensionnée.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Allouez pour le `ArcInner<T>` en utilisant la valeur donnée.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Copier la valeur sous forme d'octets
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Libérez l'allocation sans laisser tomber son contenu
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Alloue un `ArcInner<[T]>` avec la longueur donnée.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Copier les éléments de la tranche dans l`arc nouvellement alloué <\[T\]>
    ///
    /// Non sécurisé car l'appelant doit s'approprier ou lier `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Construit un `Arc<[T]>` à partir d'un itérateur connu pour être d'une certaine taille.
    ///
    /// Le comportement n'est pas défini si la taille est incorrecte.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Garde Panic lors du clonage des éléments T.
        // Dans le cas d'un panic, les éléments qui ont été écrits dans le nouvel ArcInner seront supprimés, puis la mémoire sera libérée.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Pointeur vers le premier élément
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Tout est clair.Oubliez la garde pour qu'elle ne libère pas le nouvel ArcInner.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Spécialisation trait utilisée pour `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Crée un clone du pointeur `Arc`.
    ///
    /// Cela crée un autre pointeur vers la même allocation, augmentant le nombre de références fortes.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // L'utilisation d'un ordre détendu est acceptable ici, car la connaissance de la référence d'origine empêche les autres threads de supprimer par erreur l'objet.
        //
        // Comme expliqué dans le [Boost documentation][1], l'augmentation du compteur de références peut toujours être effectuée avec memory_order_relaxed: les nouvelles références à un objet ne peuvent être formées qu'à partir d'une référence existante, et le passage d'une référence existante d'un thread à un autre doit déjà fournir toute synchronisation requise.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Cependant, nous devons nous prémunir contre des refcount massifs au cas où quelqu'un serait `mem: : forget`ing Arcs.
        // Si nous ne le faisons pas, le nombre peut déborder et les utilisateurs utiliseront gratuitement.
        // Nous saturons rageusement à `isize::MAX` en supposant qu'il n'y a pas ~2 milliards de threads incrémentant le nombre de références à la fois.
        //
        // Ce branch ne sera jamais pris dans aucun programme réaliste.
        //
        // Nous abandonnons parce qu'un tel programme est incroyablement dégénéré, et nous ne nous soucions pas de le soutenir.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Crée une référence mutable dans le `Arc` donné.
    ///
    /// S'il existe d'autres pointeurs `Arc` ou [`Weak`] vers la même allocation, `make_mut` créera une nouvelle allocation et invoquera [`clone`][clone] sur la valeur interne pour garantir une propriété unique.
    /// Ceci est également appelé clone-on-write.
    ///
    /// Notez que cela diffère du comportement de [`Rc::make_mut`] qui dissocie tous les pointeurs `Weak` restants.
    ///
    /// Voir aussi [`get_mut`][get_mut], qui échouera plutôt que le clonage.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Ne clonera rien
    /// let mut other_data = Arc::clone(&data); // Ne clonera pas les données internes
    /// *Arc::make_mut(&mut data) += 1;         // Clone les données internes
    /// *Arc::make_mut(&mut data) += 1;         // Ne clonera rien
    /// *Arc::make_mut(&mut other_data) *= 2;   // Ne clonera rien
    ///
    /// // Désormais, `data` et `other_data` pointent vers des allocations différentes.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Notez que nous détenons à la fois une référence forte et une référence faible.
        // Ainsi, ne libérer que notre référence forte ne provoquera pas en soi la désallocation de la mémoire.
        //
        // Utilisez Acquire pour vous assurer que nous voyons toutes les écritures sur `weak` qui se produisent avant les écritures de version (c'est-à-dire les décrémentations) sur `strong`.
        // Puisque nous avons un nombre faible, il n'y a aucune chance que l'ArcInner lui-même puisse être désalloué.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Un autre pointeur fort existe, nous devons donc cloner.
            // Pré-allouez de la mémoire pour permettre l'écriture directe de la valeur clonée.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Relaxed suffit dans ce qui précède car il s'agit fondamentalement d'une optimisation: nous courons toujours avec des pointeurs faibles qui sont abandonnés.
            // Dans le pire des cas, nous finissons par attribuer un nouvel arc inutilement.
            //

            // Nous avons supprimé la dernière référence forte, mais il reste des références faibles supplémentaires.
            // Nous allons déplacer le contenu vers un nouvel arc et invalider les autres références faibles.
            //

            // Notez qu'il n'est pas possible que la lecture de `weak` donne usize::MAX (c'est-à-dire verrouillé), car le nombre faible ne peut être verrouillé que par un thread avec une référence forte.
            //
            //

            // Matérialisez notre propre pointeur faible implicite, afin qu'il puisse nettoyer l'ArcInner si nécessaire.
            //
            let _weak = Weak { ptr: this.ptr };

            // Je peux juste voler les données, il ne reste que des faiblesses
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Nous étions la seule référence de l'un ou l'autre type;remontez le nombre de ref.
            //
            this.inner().strong.store(1, Release);
        }

        // Comme pour `get_mut()`, l'insécurité est acceptable car notre référence était soit unique au départ, soit devenue une lors du clonage du contenu.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Renvoie une référence mutable dans le `Arc` donné, s'il n'y a pas d'autres pointeurs `Arc` ou [`Weak`] vers la même allocation.
    ///
    ///
    /// Renvoie [`None`] dans le cas contraire, car il n'est pas sûr de muter une valeur partagée.
    ///
    /// Voir aussi [`make_mut`][make_mut], qui [`clone`][clone] la valeur interne lorsqu'il y a d'autres pointeurs.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Cette non-sécurité est acceptable car nous sommes assurés que le pointeur retourné est le *seul* pointeur qui sera jamais retourné à T.
            // Notre nombre de références est garanti à 1 à ce stade, et nous avons exigé que l'Arc lui-même soit `mut`, nous retournons donc la seule référence possible aux données internes.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Renvoie une référence mutable dans le `Arc` donné, sans aucune vérification.
    ///
    /// Voir aussi [`get_mut`], qui est sûr et effectue les vérifications appropriées.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Les autres pointeurs `Arc` ou [`Weak`] vers la même allocation ne doivent pas être déréférencés pendant la durée de l'emprunt retourné.
    ///
    /// C'est trivialement le cas si de tels pointeurs n'existent pas, par exemple immédiatement après `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Nous prenons soin de ne *pas* créer une référence couvrant les champs "count", car cela ferait un alias avec un accès simultané aux décomptes de références (par exemple
        // par `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Déterminez s'il s'agit de la référence unique (y compris les références faibles) aux données sous-jacentes.
    ///
    ///
    /// Notez que cela nécessite de verrouiller le nombre de références faibles.
    fn is_unique(&mut self) -> bool {
        // verrouille le nombre de pointeurs faibles si nous semblons être le seul détenteur de pointeurs faibles.
        //
        // Le libellé d'acquisition ici garantit une relation qui se produit avant avec toute écriture sur `strong` (en particulier dans `Weak::upgrade`) avant les décrémentations du compte `weak` (via `Weak::drop`, qui utilise release).
        // Si la référence faible mise à jour n'a jamais été abandonnée, le CAS échouera ici et nous ne nous soucions pas de synchroniser.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Cela doit être un `Acquire` pour se synchroniser avec le décrément du compteur `strong` dans `drop`-le seul accès qui se produit lorsqu'une référence sauf la dernière est supprimée.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // L'écriture de version ici se synchronise avec une lecture dans `downgrade`, empêchant effectivement la lecture ci-dessus de `strong` de se produire après l'écriture.
            //
            //
            self.inner().weak.store(1, Release); // relâchez le verrou
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Supprime le `Arc`.
    ///
    /// Cela diminuera le nombre de références fortes.
    /// Si le nombre de références fortes atteint zéro, les seules autres références (le cas échéant) sont [`Weak`], donc nous `drop` la valeur interne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // N'imprime rien
    /// drop(foo2);   // Imprime "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Parce que `fetch_sub` est déjà atomique, nous n'avons pas besoin de nous synchroniser avec d'autres threads à moins que nous n'allions supprimer l'objet.
        // Cette même logique s'applique au `fetch_sub` ci-dessous au compte `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Cette clôture est nécessaire pour empêcher la réorganisation de l'utilisation des données et la suppression des données.
        // Comme il est marqué `Release`, la diminution du nombre de références se synchronise avec cette clôture `Acquire`.
        // Cela signifie que l'utilisation des données se produit avant de diminuer le nombre de références, ce qui se produit avant cette clôture, ce qui se produit avant la suppression des données.
        //
        // Comme expliqué dans le [Boost documentation][1],
        //
        // > Il est important d'appliquer tout accès possible à l'objet en un
        // > thread (via une référence existante) à *se produire avant* la suppression
        // > l'objet dans un fil différent.Ceci est réalisé par un "release"
        // > opération après avoir déposé une référence (tout accès à l'objet
        // > à travers cette référence doit évidemment se produire avant), et un
        // > "acquire" opération avant de supprimer l'objet.
        //
        // En particulier, alors que le contenu d'un Arc est généralement immuable, il est possible d'avoir des écritures intérieures sur quelque chose comme un Mutex<T>.
        // Puisqu'un Mutex n'est pas acquis lorsqu'il est supprimé, nous ne pouvons pas nous fier à sa logique de synchronisation pour rendre les écritures dans le thread A visibles par un destructeur s'exécutant dans le thread B.
        //
        //
        // Notez également que la clôture Acquérir ici pourrait probablement être remplacée par une charge Acquérir, ce qui pourrait améliorer les performances dans des situations très controversées.Voir [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Essayez de réduire le `Arc<dyn Any + Send + Sync>` à un type concret.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Construit un nouveau `Weak<T>`, sans allouer de mémoire.
    /// L'appel de [`upgrade`] sur la valeur de retour donne toujours [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Type d'assistance pour permettre l'accès aux décomptes de références sans faire aucune affirmation sur le champ de données.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Renvoie un pointeur brut vers l'objet `T` pointé par ce `Weak<T>`.
    ///
    /// Le pointeur n'est valide que s'il existe des références fortes.
    /// Le pointeur peut être suspendu, non aligné ou même [`null`] dans le cas contraire.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Les deux pointent vers le même objet
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Le fort ici le maintient en vie, de sorte que nous pouvons toujours accéder à l'objet.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Mais plus maintenant.
    /// // Nous pouvons faire weak.as_ptr(), mais accéder au pointeur entraînerait un comportement indéfini.
    /// // assert_eq! ("bonjour", unsafe {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Si le pointeur est suspendu, nous renvoyons directement la sentinelle.
            // Il ne peut pas s'agir d'une adresse de charge utile valide, car la charge utile est au moins aussi alignée que ArcInner (usize).
            ptr as *const T
        } else {
            // SÉCURITÉ: si is_dangling renvoie false, alors le pointeur est déréférencable.
            // La charge utile peut être supprimée à ce stade, et nous devons maintenir la provenance, utilisez donc la manipulation brute du pointeur.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Consomme le `Weak<T>` et le transforme en un pointeur brut.
    ///
    /// Cela convertit le pointeur faible en un pointeur brut, tout en préservant la propriété d'une référence faible (le nombre faible n'est pas modifié par cette opération).
    /// Il peut être reconverti en `Weak<T>` avec [`from_raw`].
    ///
    /// Les mêmes restrictions d'accès à la cible du pointeur qu'avec [`as_ptr`] s'appliquent.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Convertit un pointeur brut précédemment créé par [`into_raw`] en `Weak<T>`.
    ///
    /// Cela peut être utilisé pour obtenir en toute sécurité une référence forte (en appelant [`upgrade`] plus tard) ou pour désallouer le nombre faible en supprimant le `Weak<T>`.
    ///
    /// Il prend possession d'une référence faible (à l'exception des pointeurs créés par [`new`], car ceux-ci ne possèdent rien; la méthode fonctionne toujours sur eux).
    ///
    /// # Safety
    ///
    /// Le pointeur doit provenir du [`into_raw`] et doit toujours posséder sa référence faible potentielle.
    ///
    /// Il est permis que le nombre fort soit égal à 0 au moment de l'appel.
    /// Néanmoins, cela s'approprie une référence faible actuellement représentée comme un pointeur brut (le décompte faible n'est pas modifié par cette opération) et doit donc être couplé avec un appel précédent à [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Décrémentez le dernier décompte faible.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Voir Weak::as_ptr pour le contexte sur la façon dont le pointeur d'entrée est dérivé.

        let ptr = if is_dangling(ptr as *mut T) {
            // C'est un faible pendantes.
            ptr as *mut ArcInner<T>
        } else {
            // Sinon, nous sommes assurés que le pointeur provient d'un faible non enchevêtré.
            // SÉCURITÉ: data_offset peut être appelé en toute sécurité, car ptr fait référence à un T.
            let offset = unsafe { data_offset(ptr) };
            // Ainsi, nous inversons le décalage pour obtenir l'ensemble de la RcBox.
            // SÉCURITÉ: le pointeur provient d'un faible, donc ce décalage est sûr.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SÉCURITÉ: nous avons maintenant récupéré le pointeur faible d'origine, nous pouvons donc créer le pointeur faible.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Tente de mettre à niveau le pointeur `Weak` vers un [`Arc`], retardant la suppression de la valeur interne en cas de succès.
    ///
    ///
    /// Renvoie [`None`] si la valeur interne a depuis été supprimée.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Détruisez tous les pointeurs forts.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Nous utilisons une boucle CAS pour incrémenter le nombre fort au lieu d'un fetch_add car cette fonction ne devrait jamais prendre le nombre de références de zéro à un.
        //
        //
        let inner = self.inner()?;

        // Charge relâchée car toute écriture de 0 que nous pouvons observer laisse le champ dans un état de zéro en permanence (donc une lecture "stale" de 0 est correcte), et toute autre valeur est confirmée via le CAS ci-dessous.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Voir les commentaires dans `Arc::clone` pour savoir pourquoi nous faisons cela (pour `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Relaxed est bien pour le cas d'échec car nous n'avons aucune attente concernant le nouvel état.
            // L'acquisition est nécessaire pour que le cas de réussite se synchronise avec `Arc::new_cyclic`, lorsque la valeur interne peut être initialisée après la création des références `Weak`.
            // Dans ce cas, nous nous attendons à observer la valeur entièrement initialisée.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // nul vérifié ci-dessus
                Err(old) => n = old,
            }
        }
    }

    /// Obtient le nombre de pointeurs (`Arc`) forts pointant vers cette allocation.
    ///
    /// Si `self` a été créé à l'aide de [`Weak::new`], cela renverra 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Obtient une approximation du nombre de pointeurs `Weak` pointant vers cette allocation.
    ///
    /// Si `self` a été créé à l'aide de [`Weak::new`], ou s'il n'y a plus de pointeurs forts restants, cela renverra 0.
    ///
    /// # Accuracy
    ///
    /// En raison des détails d'implémentation, la valeur renvoyée peut être décalée de 1 dans les deux sens lorsque d'autres threads manipulent des "Arc" ou des "Weak" pointant vers la même allocation.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Puisque nous avons observé qu'il y avait au moins un pointeur fort après la lecture du décompte faible, nous savons que la référence faible implicite (présente chaque fois que des références fortes sont vivantes) était toujours là lorsque nous avons observé le décompte faible, et pouvons donc la soustraire en toute sécurité.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Renvoie `None` lorsque le pointeur est suspendu et qu'il n'y a pas de `ArcInner` alloué, (c'est-à-dire lorsque ce `Weak` a été créé par `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Nous prenons soin de ne *pas* créer une référence couvrant le champ "data", car le champ peut être muté simultanément (par exemple, si le dernier `Arc` est supprimé, le champ de données sera supprimé sur place).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Renvoie `true` si les deux `Weak`s pointent vers la même allocation (similaire à [`ptr::eq`]), ou si les deux ne pointent vers aucune allocation (car ils ont été créés avec `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Puisque cela compare les pointeurs, cela signifie que `Weak::new()` s'égalisera, même s'ils ne pointent vers aucune allocation.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Comparaison de `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Crée un clone du pointeur `Weak` qui pointe vers la même allocation.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Voir les commentaires dans Arc::clone() pour savoir pourquoi cela est assoupli.
        // Cela peut utiliser un fetch_add (en ignorant le verrou) car le nombre faible n'est verrouillé que là où il n'y a *aucun autre* pointeur faible existant.
        //
        // (Nous ne pouvons donc pas exécuter ce code dans ce cas).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Voir les commentaires dans Arc::clone() pour savoir pourquoi nous faisons cela (pour mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Construit un nouveau `Weak<T>`, sans allouer de mémoire.
    /// L'appel de [`upgrade`] sur la valeur de retour donne toujours [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Supprime le pointeur `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // N'imprime rien
    /// drop(foo);        // Imprime "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Si nous découvrons que nous étions le dernier pointeur faible, alors il est temps de désallouer entièrement les données.Voir la discussion dans Arc::drop() sur les ordres de mémoire
        //
        // Il n'est pas nécessaire de vérifier l'état verrouillé ici, car le décompte faible ne peut être verrouillé que s'il y avait précisément une référence faible, ce qui signifie que la chute ne pourrait ensuite s'exécuter que sur cette référence faible restante, ce qui ne peut se produire qu'après le relâchement du verrou.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Nous faisons cette spécialisation ici, et non comme une optimisation plus générale sur `&T`, car cela ajouterait autrement un coût à tous les contrôles d'égalité sur les références.
/// Nous supposons que les `Arc`s sont utilisés pour stocker de grandes valeurs, qui sont lentes à cloner, mais aussi lourdes à vérifier pour l'égalité, ce qui rend ce coût plus rentable.
///
/// Il est également plus probable d'avoir deux clones `Arc`, qui pointent vers la même valeur, que deux `&T`s.
///
/// Nous ne pouvons le faire que lorsque `T: Eq` en tant que `PartialEq` peut être délibérément irréfléchi.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Égalité pour deux «Arc».
    ///
    /// Deux «Arc» sont égaux si leurs valeurs internes sont égales, même s'ils sont stockés dans une allocation différente.
    ///
    /// Si `T` implémente également `Eq` (impliquant la réflexivité d'égalité), deux `Arc`s qui pointent vers la même allocation sont toujours égaux.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Inégalité pour deux «Arc».
    ///
    /// Deux «Arc» sont inégaux si leurs valeurs internes sont inégales.
    ///
    /// Si `T` implémente également `Eq` (impliquant la réflexivité d'égalité), deux `Arc`s qui pointent vers la même valeur ne sont jamais inégaux.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Comparaison partielle pour deux "Arc".
    ///
    /// Les deux sont comparés en appelant `partial_cmp()` sur leurs valeurs internes.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Moins que comparaison pour deux "Arc".
    ///
    /// Les deux sont comparés en appelant `<` sur leurs valeurs internes.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Comparaison "Inférieur ou égal à" pour deux "Arc".
    ///
    /// Les deux sont comparés en appelant `<=` sur leurs valeurs internes.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Comparaison supérieure à deux "Arc".
    ///
    /// Les deux sont comparés en appelant `>` sur leurs valeurs internes.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Comparaison "Supérieur ou égal à" pour deux "Arc".
    ///
    /// Les deux sont comparés en appelant `>=` sur leurs valeurs internes.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Comparaison pour deux «Arc».
    ///
    /// Les deux sont comparés en appelant `cmp()` sur leurs valeurs internes.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Crée un nouveau `Arc<T>`, avec la valeur `Default` pour `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Allouez une tranche comptée par référence et remplissez-la en clonant les éléments de `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Attribuez un `str` compté par référence et copiez-y `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Attribuez un `str` compté par référence et copiez-y `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Déplacez un objet encadré vers une nouvelle allocation comptée par référence.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Allouez une tranche comptée par référence et déplacez-y les éléments de `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Permettre au Vec de libérer sa mémoire, mais pas de détruire son contenu
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Prend chaque élément du `Iterator` et le rassemble dans un `Arc<[T]>`.
    ///
    /// # Caractéristiques de performance
    ///
    /// ## Le cas général
    ///
    /// Dans le cas général, la collecte dans `Arc<[T]>` se fait en collectant d'abord dans un `Vec<T>`.Autrement dit, lors de l'écriture de ce qui suit:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// cela se comporte comme si nous écrivions:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Le premier ensemble d'allocations se produit ici.
    ///     .into(); // Une deuxième allocation pour `Arc<[T]>` se produit ici.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Cela allouera autant de fois que nécessaire pour construire le `Vec<T>`, puis il allouera une fois pour transformer le `Vec<T>` en `Arc<[T]>`.
    ///
    ///
    /// ## Itérateurs de longueur connue
    ///
    /// Lorsque votre `Iterator` implémente `TrustedLen` et est d'une taille exacte, une seule allocation sera faite pour le `Arc<[T]>`.Par example:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Une seule allocation se produit ici.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Spécialisation trait utilisée pour la collecte dans `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // C'est le cas d'un itérateur `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SÉCURITÉ: Nous devons nous assurer que l'itérateur a une longueur exacte et nous l'avons fait.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Revenez à une mise en œuvre normale.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Obtenez le décalage dans un `ArcInner` pour la charge utile derrière un pointeur.
///
/// # Safety
///
/// Le pointeur doit pointer vers (et avoir des métadonnées valides pour) une instance précédemment valide de T, mais le T est autorisé à être supprimé.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Alignez la valeur non dimensionnée sur la fin de l'ArcInner.
    // Étant donné que RcBox est repr(C), ce sera toujours le dernier champ en mémoire.
    // SÉCURITÉ: puisque les seuls types non dimensionnés possibles sont des tranches, des objets trait,
    // et les types extern, l'exigence de sécurité d'entrée est actuellement suffisante pour satisfaire les exigences de align_of_val_raw;il s'agit d'un détail d'implémentation du langage sur lequel on ne peut pas se fier en dehors de std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}