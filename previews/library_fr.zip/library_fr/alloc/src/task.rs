#![stable(feature = "wake_trait", since = "1.51.0")]
//! Types et Traits pour travailler avec des tâches asynchrones.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// La mise en œuvre de réveiller une tâche sur un exécuteur testamentaire.
///
/// Ce trait peut être utilisé pour créer un [`Waker`].
/// Un exécuteur peut définir une implémentation de ce trait, et l'utiliser pour construire un Waker à passer aux tâches qui sont exécutées sur cet exécuteur.
///
/// Ce trait est une alternative ergonomique et sûre pour la mémoire à la construction d'un [`RawWaker`].
/// Il prend en charge la conception d'exécuteur commun dans laquelle les données utilisées pour réveiller une tâche sont stockées dans un [`Arc`].
/// Certains exécuteurs (en particulier ceux pour les systèmes embarqués) ne peuvent pas utiliser cette API, c'est pourquoi [`RawWaker`] existe comme une alternative pour ces systèmes.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Une fonction `block_on` de base qui prend un future et l'exécute jusqu'à la fin sur le thread actuel.
///
/// **Note:** Cet exemple troque l'exactitude pour la simplicité.
/// Afin d'éviter les blocages, les implémentations de niveau production devront également gérer les appels intermédiaires vers `thread::unpark` ainsi que les appels imbriqués.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Un waker qui réveille le thread actuel lorsqu'il est appelé.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Exécutez un future jusqu'à la fin sur le thread actuel.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Épinglez le future pour qu'il puisse être interrogé.
///     let mut fut = Box::pin(fut);
///
///     // Créez un nouveau contexte à transmettre au future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Exécutez le future jusqu'à la fin.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Réveillez cette tâche.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Réveillez cette tâche sans consommer le waker.
    ///
    /// Si un exécuteur prend en charge un moyen moins coûteux de se réveiller sans consommer le waker, il doit remplacer cette méthode.
    /// Par défaut, il clone le [`Arc`] et appelle [`wake`] sur le clone.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // SÉCURITÉ: Ceci est sûr car raw_waker construit en toute sécurité
        // un RawWaker d'Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Cette fonction privée de construction d'un RawWaker est utilisée, plutôt que
// en incorporant ceci dans l'implément `From<Arc<W>> for RawWaker`, pour s'assurer que la sécurité de `From<Arc<W>> for Waker` ne dépend pas de la distribution trait correcte, à la place les deux impls appellent cette fonction directement et explicitement.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Incrémentez le nombre de références de l'arc pour le cloner.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Réveil par valeur, en déplaçant l'Arc dans la fonction Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Réveillez-vous par référence, enveloppez le waker dans ManuallyDrop pour éviter de le laisser tomber
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Décrémenter le décompte de référence de l'arc en chute
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}