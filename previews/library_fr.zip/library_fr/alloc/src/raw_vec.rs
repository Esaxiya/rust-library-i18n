#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Le contenu de la nouvelle mémoire n'est pas initialisé.
    Uninitialized,
    /// La nouvelle mémoire est garantie d'être remise à zéro.
    Zeroed,
}

/// Un utilitaire de bas niveau pour allouer, réallouer et désallouer de manière plus ergonomique un tampon de mémoire sur le tas sans avoir à se soucier de tous les cas secondaires impliqués.
///
/// Ce type est excellent pour créer vos propres structures de données comme Vec et VecDeque.
/// En particulier:
///
/// * Produit `Unique::dangling()` sur les types de taille zéro.
/// * Produit `Unique::dangling()` sur des allocations de longueur nulle.
/// * Évite de libérer `Unique::dangling()`.
/// * Attrape tous les débordements dans les calculs de capacité (les promeut vers "capacity overflow" panics).
/// * Protège contre les systèmes 32 bits allouant plus de isize::MAX octets.
/// * Protège contre le débordement de votre longueur.
/// * Appelle `handle_alloc_error` pour les allocations faillibles.
/// * Contient un `ptr::Unique` et confère ainsi à l'utilisateur tous les avantages connexes.
/// * Utilise l'excédent retourné par l'allocateur pour utiliser la plus grande capacité disponible.
///
/// Ce type n'inspecte en aucun cas la mémoire qu'il gère.Lorsqu'il est déposé, il *libérera* sa mémoire, mais il *n'essaiera* pas de supprimer son contenu.
/// C'est à l'utilisateur de `RawVec` de gérer les choses réelles *stockées* à l'intérieur d'un `RawVec`.
///
/// Notez que l'excès d'un type de taille zéro est toujours infini, donc `capacity()` renvoie toujours `usize::MAX`.
/// Cela signifie que vous devez être prudent lors de l'aller-retour de ce type avec un `Box<[T]>`, car `capacity()` ne donnera pas la longueur.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Cela existe parce que `#[unstable]` `const fn`s n'a pas besoin d'être conforme à `min_const_fn` et donc ils ne peuvent pas non plus être appelés dans`min_const_fn`s.
    ///
    /// Si vous modifiez `RawVec<T>::new` ou des dépendances, veillez à ne rien introduire qui enfreindrait vraiment `min_const_fn`.
    ///
    /// NOTE: Nous pourrions éviter ce hack et vérifier la conformité avec un attribut `#[rustc_force_min_const_fn]` qui nécessite la conformité avec `min_const_fn` mais ne permet pas nécessairement de l'appeler en `stable(...) const fn`/code utilisateur n'activant pas `foo` lorsque `#[rustc_const_unstable(feature = "foo", issue = "01234")]` est présent.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Crée le plus grand `RawVec` possible (sur le tas système) sans allouer.
    /// Si `T` a une taille positive, alors cela fait un `RawVec` avec une capacité `0`.
    /// Si `T` est de taille nulle, alors il crée un `RawVec` avec une capacité `usize::MAX`.
    /// Utile pour mettre en œuvre une allocation différée.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Crée un `RawVec` (sur le tas système) avec exactement les exigences de capacité et d'alignement pour un `[T; capacity]`.
    /// Cela équivaut à appeler `RawVec::new` lorsque `capacity` est `0` ou `T` est de taille zéro.
    /// Notez que si `T` est de taille zéro, cela signifie que vous n'obtiendrez *pas* un `RawVec` avec la capacité demandée.
    ///
    /// # Panics
    ///
    /// Panics si la capacité demandée dépasse `isize::MAX` octets.
    ///
    /// # Aborts
    ///
    /// Abandonne sur MOO.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Comme `with_capacity`, mais garantit que le tampon est remis à zéro.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Reconstitue un `RawVec` à partir d'un pointeur et d'une capacité.
    ///
    /// # Safety
    ///
    /// Le `ptr` doit être alloué (sur le tas système) et avec le `capacity` donné.
    /// Le `capacity` ne peut pas dépasser `isize::MAX` pour les types dimensionnés.(un problème uniquement sur les systèmes 32 bits).
    /// ZST vectors peut avoir une capacité allant jusqu'à `usize::MAX`.
    /// Si le `ptr` et le `capacity` proviennent d'un `RawVec`, cela est garanti.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Les minuscules Vecs sont stupides.Passer:
    // - 8 si la taille de l'élément est 1, car tout allocateur de tas est susceptible d'arrondir une demande de moins de 8 octets à au moins 8 octets.
    //
    // - 4 si les éléments sont de taille moyenne (<=1 Kio).
    // - 1 sinon, pour éviter de gaspiller trop d'espace pour des Vecs très courts.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Comme `new`, mais paramétré sur le choix de l'allocateur pour le `RawVec` renvoyé.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` signifie "unallocated".les types de taille zéro sont ignorés.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Comme `with_capacity`, mais paramétré sur le choix de l'allocateur pour le `RawVec` renvoyé.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Comme `with_capacity_zeroed`, mais paramétré sur le choix de l'allocateur pour le `RawVec` renvoyé.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Convertit un `Box<[T]>` en `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Convertit le tampon entier en `Box<[MaybeUninit<T>]>` avec le `len` spécifié.
    ///
    /// Notez que cela reconstituera correctement toutes les modifications `cap` qui peuvent avoir été effectuées.(Voir la description du type pour plus de détails.)
    ///
    /// # Safety
    ///
    /// * `len` doit être supérieur ou égal à la capacité la plus récemment demandée, et
    /// * `len` doit être inférieur ou égal à `self.capacity()`.
    ///
    /// Notez que la capacité demandée et `self.capacity()` peuvent différer, car un allocateur peut surallouer et renvoyer un bloc de mémoire plus grand que celui demandé.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Vérifiez la santé mentale d'une moitié de l'exigence de sécurité (nous ne pouvons pas vérifier l'autre moitié).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Nous évitons `unwrap_or_else` ici car il gonfle la quantité de LLVM IR générée.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Reconstitue un `RawVec` à partir d'un pointeur, d'une capacité et d'un allocateur.
    ///
    /// # Safety
    ///
    /// Le `ptr` doit être alloué (via l'allocateur `alloc` donné), et avec le `capacity` donné.
    /// Le `capacity` ne peut pas dépasser `isize::MAX` pour les types dimensionnés.
    /// (un problème uniquement sur les systèmes 32 bits).
    /// ZST vectors peut avoir une capacité allant jusqu'à `usize::MAX`.
    /// Si le `ptr` et le `capacity` proviennent d'un `RawVec` créé via `alloc`, cela est garanti.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Obtient un pointeur brut vers le début de l'allocation.
    /// Notez qu'il s'agit de `Unique::dangling()` si `capacity == 0` ou `T` est de taille zéro.
    /// Dans le premier cas, vous devez être prudent.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Obtient la capacité de l'allocation.
    ///
    /// Ce sera toujours `usize::MAX` si `T` est de taille zéro.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Renvoie une référence partagée à l'allocateur qui soutient ce `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Nous avons un morceau de mémoire alloué, nous pouvons donc contourner les vérifications d'exécution pour obtenir notre disposition actuelle.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Garantit que le tampon contient au moins suffisamment d'espace pour contenir des éléments `len + additional`.
    /// S'il n'a pas déjà assez de capacité, réallouera suffisamment d'espace plus un espace libre confortable pour obtenir un comportement amorti *O*(1).
    ///
    /// Limitera ce comportement s'il se causait inutilement à panic.
    ///
    /// Si `len` dépasse `self.capacity()`, cela peut ne pas allouer réellement l'espace demandé.
    /// Ce n'est pas vraiment dangereux, mais le code dangereux *que vous* écrivez qui repose sur le comportement de cette fonction peut se rompre.
    ///
    /// Ceci est idéal pour mettre en œuvre une opération push en masse comme `extend`.
    ///
    /// # Panics
    ///
    /// Panics si la nouvelle capacité dépasse `isize::MAX` octets.
    ///
    /// # Aborts
    ///
    /// Abandonne sur MOO.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // reserve aurait abandonné ou paniqué si le len dépassait `isize::MAX`, il est donc prudent de le faire maintenant.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Identique à `reserve`, mais retourne sur des erreurs au lieu de paniquer ou d'abandonner.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Garantit que le tampon contient au moins suffisamment d'espace pour contenir des éléments `len + additional`.
    /// Si ce n'est pas déjà fait, réallouera la quantité minimale de mémoire nécessaire.
    /// Généralement, ce sera exactement la quantité de mémoire nécessaire, mais en principe, l'allocateur est libre de rendre plus que ce que nous avons demandé.
    ///
    ///
    /// Si `len` dépasse `self.capacity()`, cela peut ne pas allouer réellement l'espace demandé.
    /// Ce n'est pas vraiment dangereux, mais le code dangereux *que vous* écrivez qui repose sur le comportement de cette fonction peut se rompre.
    ///
    /// # Panics
    ///
    /// Panics si la nouvelle capacité dépasse `isize::MAX` octets.
    ///
    /// # Aborts
    ///
    /// Abandonne sur MOO.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Identique à `reserve_exact`, mais retourne sur des erreurs au lieu de paniquer ou d'abandonner.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Réduit l'allocation au montant spécifié.
    /// Si le montant donné est égal à 0, il est en fait complètement désalloué.
    ///
    /// # Panics
    ///
    /// Panics si le montant donné est *supérieur* à la capacité actuelle.
    ///
    /// # Aborts
    ///
    /// Abandonne sur MOO.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Renvoie si la mémoire tampon doit augmenter pour remplir la capacité supplémentaire nécessaire.
    /// Principalement utilisé pour rendre possible les appels de réserve intégrés sans inclure `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Cette méthode est généralement instanciée plusieurs fois.Nous voulons donc qu'il soit aussi petit que possible, pour améliorer les temps de compilation.
    // Mais nous voulons également que son contenu soit calculable statiquement autant que possible, pour que le code généré s'exécute plus rapidement.
    // Par conséquent, cette méthode est soigneusement écrite afin que tout le code qui dépend de `T` y soit, tandis que le plus grand nombre possible de code qui ne dépend pas de `T` se trouve dans des fonctions non génériques sur `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Ceci est assuré par les contextes d'appel.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Puisque nous retournons une capacité de `usize::MAX` lorsque `elem_size` est
            // 0, arriver ici signifie nécessairement que le `RawVec` est saturé.
            return Err(CapacityOverflow);
        }

        // Nous ne pouvons vraiment rien faire contre ces contrôles, malheureusement.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Cela garantit une croissance exponentielle.
        // Le doublement ne peut pas déborder car `cap <= isize::MAX` et le type de `cap` est `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` n'est pas générique sur `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Les contraintes de cette méthode sont sensiblement les mêmes que celles de `grow_amortized`, mais cette méthode est généralement instanciée moins souvent, elle est donc moins critique.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Puisque nous retournons une capacité de `usize::MAX` lorsque la taille du type est
            // 0, arriver ici signifie nécessairement que le `RawVec` est saturé.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` n'est pas générique sur `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Cette fonction est en dehors de `RawVec` pour minimiser les temps de compilation.Voir le commentaire ci-dessus `RawVec::grow_amortized` pour plus de détails.
// (Le paramètre `A` n'est pas significatif, car le nombre de types `A` différents observés dans la pratique est beaucoup plus petit que le nombre de types `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Recherchez l'erreur ici pour minimiser la taille de `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // L'allocateur vérifie l'égalité d'alignement
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Libère la mémoire appartenant au `RawVec`*sans* essayer de supprimer son contenu.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Fonction centrale de gestion des erreurs de réserve.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Nous devons garantir ce qui suit:
// * Nous n'allouons jamais d'objets de taille octet `> isize::MAX`.
// * Nous ne débordons pas de `usize::MAX` et en allouons trop peu.
//
// Sur 64 bits, nous devons juste vérifier le débordement car essayer d'allouer des octets `> isize::MAX` échouera sûrement.
// Sur 32 bits et 16 bits, nous devons ajouter une protection supplémentaire pour cela au cas où nous fonctionnerions sur une plate-forme qui peut utiliser les 4 Go de l'espace utilisateur, par exemple PAE ou x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Une fonction centrale chargée de signaler les dépassements de capacité.
// Cela garantira que la génération de code liée à ces panics est minimale car il n'y a qu'un seul emplacement qui panics plutôt qu'un tas dans le module.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}