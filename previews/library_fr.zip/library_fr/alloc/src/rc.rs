//! Pointeurs de comptage de références à thread unique.'Rc' signifie `` référence
//! Counted'.
//!
//! Le type [`Rc<T>`][`Rc`] fournit la propriété partagée d'une valeur de type `T`, allouée dans le tas.
//! L'appel de [`clone`][clone] sur [`Rc`] produit un nouveau pointeur vers la même allocation dans le tas.
//! Lorsque le dernier pointeur [`Rc`] vers une allocation donnée est détruit, la valeur stockée dans cette allocation (souvent appelée "inner value") est également supprimée.
//!
//! Les références partagées dans Rust interdisent la mutation par défaut, et [`Rc`] ne fait pas exception: vous ne pouvez généralement pas obtenir une référence mutable à quelque chose à l'intérieur d'un [`Rc`].
//! Si vous avez besoin de mutabilité, placez un [`Cell`] ou [`RefCell`] dans le [`Rc`];voir [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] utilise le comptage de références non atomiques.
//! Cela signifie que la surcharge est très faible, mais un [`Rc`] ne peut pas être envoyé entre les threads et, par conséquent, [`Rc`] n'implémente pas [`Send`][send].
//! En conséquence, le compilateur Rust vérifiera *au moment de la compilation* que vous n'envoyez pas de [`Rc`] s entre les threads.
//! Si vous avez besoin d'un comptage de référence atomique multithread, utilisez [`sync::Arc`][arc].
//!
//! La méthode [`downgrade`][downgrade] peut être utilisée pour créer un pointeur [`Weak`] non propriétaire.
//! Un pointeur [`Weak`] peut être [`upgrade`][upgrade] d vers un [`Rc`], mais cela renverra [`None`] si la valeur stockée dans l'allocation a déjà été supprimée.
//! En d'autres termes, les pointeurs `Weak` ne conservent pas la valeur à l'intérieur de l'allocation active;cependant, ils *font* garder l'allocation (le magasin de sauvegarde pour la valeur interne) en vie.
//!
//! Un cycle entre des pointeurs [`Rc`] ne sera jamais désalloué.
//! Pour cette raison, [`Weak`] est utilisé pour interrompre les cycles.
//! Par exemple, une arborescence peut avoir des pointeurs [`Rc`] puissants des nœuds parents vers les enfants et des pointeurs [`Weak`] des enfants vers leurs parents.
//!
//! `Rc<T>` déréférencent automatiquement vers `T` (via le [`Deref`] trait), vous pouvez donc appeler les méthodes de `T` sur une valeur de type [`Rc<T>`][`Rc`].
//! Pour éviter les conflits de noms avec les méthodes de `T`, les méthodes de [`Rc<T>`][`Rc`] lui-même sont des fonctions associées, appelées à l'aide de [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>Les implémentations de traits comme `Clone` peuvent également être appelées en utilisant une syntaxe pleinement qualifiée.
//! Certaines personnes préfèrent utiliser une syntaxe pleinement qualifiée, tandis que d'autres préfèrent utiliser la syntaxe d'appel de méthode.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Syntaxe d'appel de méthode
//! let rc2 = rc.clone();
//! // Syntaxe entièrement qualifiée
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] ne déréférencera pas automatiquement à `T`, car la valeur interne a peut-être déjà été supprimée.
//!
//! # Références de clonage
//!
//! La création d'une nouvelle référence à la même allocation qu'un pointeur compté de référence existant se fait à l'aide du `Clone` trait implémenté pour [`Rc<T>`][`Rc`] et [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Les deux syntaxes ci-dessous sont équivalentes.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a et b pointent tous les deux vers le même emplacement mémoire que foo.
//! ```
//!
//! La syntaxe `Rc::clone(&from)` est la plus idiomatique car elle transmet plus explicitement la signification du code.
//! Dans l'exemple ci-dessus, cette syntaxe permet de voir plus facilement que ce code crée une nouvelle référence plutôt que de copier tout le contenu de foo.
//!
//! # Examples
//!
//! Considérez un scénario où un ensemble de «gadgets» appartient à un `Owner` donné.
//! Nous voulons que nos «gadgets» pointent vers leur `Owner`.Nous ne pouvons pas faire cela avec une propriété unique, car plusieurs gadgets peuvent appartenir au même `Owner`.
//! [`Rc`] nous permet de partager un `Owner` entre plusieurs `Gadget`s, et de laisser le `Owner` alloué tant que n'importe quel `Gadget` pointe dessus.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... autres domaines
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... autres domaines
//! }
//!
//! fn main() {
//!     // Créez un `Owner` compté par référence.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Créez un gadget appartenant à `gadget_owner`.
//!     // Le clonage du `Rc<Owner>` nous donne un nouveau pointeur vers la même allocation `Owner`, incrémentant le nombre de références dans le processus.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Supprimez notre variable locale `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Malgré l'abandon de `gadget_owner`, nous sommes toujours en mesure d'imprimer le nom du `Owner` du `Gadget`s.
//!     // C'est parce que nous n'avons laissé tomber qu'un seul `Rc<Owner>`, pas le `Owner` vers lequel il pointe.
//!     // Tant qu'il y aura d'autres `Rc<Owner>` pointant vers la même allocation `Owner`, il restera actif.
//!     // La projection de champ `gadget1.owner.name` fonctionne car `Rc<Owner>` déréférence automatiquement vers `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // A la fin de la fonction, `gadget1` et `gadget2` sont détruits, et avec eux les dernières références comptées à notre `Owner`.
//!     // Gadget Man est également détruit.
//!     //
//! }
//! ```
//!
//! Si nos exigences changent et que nous devons également pouvoir passer de `Owner` à `Gadget`, nous rencontrerons des problèmes.
//! Un pointeur [`Rc`] de `Owner` à `Gadget` introduit un cycle.
//! Cela signifie que leurs nombres de références ne peuvent jamais atteindre 0 et que l'allocation ne sera jamais détruite:
//! une fuite de mémoire.Pour contourner cela, nous pouvons utiliser des pointeurs [`Weak`].
//!
//! Rust rend en fait quelque peu difficile la production de cette boucle en premier lieu.Pour aboutir à deux valeurs pointant l'une vers l'autre, l'une d'elles doit être modifiable.
//! Ceci est difficile car [`Rc`] applique la sécurité de la mémoire en ne donnant que des références partagées à la valeur qu'il encapsule, et celles-ci n'autorisent pas la mutation directe.
//! Nous devons envelopper la partie de la valeur que nous souhaitons muter dans un [`RefCell`], qui fournit *la mutabilité intérieure*: une méthode pour atteindre la mutabilité via une référence partagée.
//! [`RefCell`] applique les règles d'emprunt de Rust au moment de l'exécution.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... autres domaines
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... autres domaines
//! }
//!
//! fn main() {
//!     // Créez un `Owner` compté par référence.
//!     // Notez que nous avons mis le vector du `Owner`s du`Gadget`s dans un `RefCell` afin que nous puissions le muter via une référence partagée.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Créez un gadget appartenant à `gadget_owner`, comme auparavant.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Ajoutez les `Gadget`s à leur `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` l'emprunt dynamique se termine ici.
//!     }
//!
//!     // Parcourez nos `Gadget`s, en imprimant leurs détails.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` est un `Weak<Gadget>`.
//!         // Étant donné que les pointeurs `Weak` ne peuvent pas garantir que l'allocation existe toujours, nous devons appeler `upgrade`, qui renvoie un `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // Dans ce cas, nous savons que l'allocation existe toujours, donc nous avons simplement `unwrap` le `Option`.
//!         // Dans un programme plus compliqué, vous pourriez avoir besoin d'une gestion des erreurs gracieuse pour un résultat `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // A la fin de la fonction, `gadget_owner`, `gadget1` et `gadget2` sont détruits.
//!     // Il n'y a plus de pointeurs (`Rc`) puissants vers les gadgets, ils sont donc détruits.
//!     // Cela remet à zéro le décompte de références sur Gadget Man, donc il est également détruit.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Il s'agit d'une protection repr(C) à future contre d'éventuelles réorganisations de champ, qui interféreraient avec des [into|from]_raw() autrement sûrs de types internes transmutables.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Un pointeur de comptage de références à thread unique.'Rc' signifie `` référence
/// Counted'.
///
/// Voir le [module-level documentation](./index.html) pour plus de détails.
///
/// Les méthodes inhérentes à `Rc` sont toutes des fonctions associées, ce qui signifie que vous devez les appeler comme par exemple [`Rc::get_mut(&mut value)`][get_mut] au lieu de `value.get_mut()`.
/// Cela évite les conflits avec les méthodes du type interne `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Cette insécurité est acceptable car tant que ce Rc est vivant, nous sommes assurés que le pointeur interne est valide.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Construit un nouveau `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Il existe un pointeur faible implicite appartenant à tous les pointeurs forts, ce qui garantit que le destructeur faible ne libère jamais l'allocation pendant que le destructeur fort est en cours d'exécution, même si le pointeur faible est stocké dans le pointeur fort.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Construit un nouveau `Rc<T>` en utilisant une référence faible à lui-même.
    /// Tenter de mettre à niveau la référence faible avant le retour de cette fonction entraînera une valeur `None`.
    ///
    /// Cependant, la référence faible peut être clonée librement et stockée pour une utilisation ultérieure.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... plus de champs
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Construisez l'intérieur dans l'état "uninitialized" avec une seule référence faible.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Il est important que nous n'abandonnions pas la propriété du pointeur faible, sinon la mémoire pourrait être libérée au retour de `data_fn`.
        // Si nous voulions vraiment transmettre la propriété, nous pourrions créer un pointeur faible supplémentaire pour nous-mêmes, mais cela entraînerait des mises à jour supplémentaires du nombre de références faibles qui pourraient ne pas être nécessaires autrement.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Les références fortes doivent collectivement posséder une référence faible partagée, alors ne lancez pas le destructeur pour notre ancienne référence faible.
        //
        mem::forget(weak);
        strong
    }

    /// Construit un nouveau `Rc` avec un contenu non initialisé.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Initialisation différée:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Construit un nouveau `Rc` avec un contenu non initialisé, la mémoire étant remplie d'octets `0`.
    ///
    ///
    /// Voir [`MaybeUninit::zeroed`][zeroed] pour des exemples d'utilisation correcte et incorrecte de cette méthode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Construit un nouveau `Rc<T>`, renvoyant une erreur si l'allocation échoue
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Il existe un pointeur faible implicite appartenant à tous les pointeurs forts, ce qui garantit que le destructeur faible ne libère jamais l'allocation pendant que le destructeur fort est en cours d'exécution, même si le pointeur faible est stocké dans le pointeur fort.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Construit un nouveau `Rc` avec un contenu non initialisé, renvoyant une erreur si l'allocation échoue
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Initialisation différée:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Construit un nouveau `Rc` avec un contenu non initialisé, la mémoire étant remplie d'octets `0`, renvoyant une erreur si l'allocation échoue
    ///
    ///
    /// Voir [`MaybeUninit::zeroed`][zeroed] pour des exemples d'utilisation correcte et incorrecte de cette méthode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Construit un nouveau `Pin<Rc<T>>`.
    /// Si `T` n'implémente pas `Unpin`, alors `value` sera épinglé en mémoire et ne pourra pas être déplacé.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Renvoie la valeur interne, si le `Rc` a exactement une référence forte.
    ///
    /// Sinon, un [`Err`] est renvoyé avec le même `Rc` qui a été transmis.
    ///
    ///
    /// Cela réussira même s'il y a des références faibles exceptionnelles.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // copier l'objet contenu

                // Indiquez aux faibles qu'ils ne peuvent pas être promus en décrémentant le nombre fort, puis supprimez le pointeur "strong weak" implicite tout en gérant la logique de suppression en créant simplement un faux faible.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Construit une nouvelle tranche comptée par référence avec un contenu non initialisé.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Initialisation différée:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Construit une nouvelle tranche comptée par référence avec un contenu non initialisé, la mémoire étant remplie d'octets `0`.
    ///
    ///
    /// Voir [`MaybeUninit::zeroed`][zeroed] pour des exemples d'utilisation correcte et incorrecte de cette méthode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Se convertit en `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Comme avec [`MaybeUninit::assume_init`], il appartient à l'appelant de garantir que la valeur interne est vraiment dans un état initialisé.
    ///
    /// L'appeler lorsque le contenu n'est pas encore complètement initialisé entraîne un comportement indéfini immédiat.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Initialisation différée:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Se convertit en `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Comme avec [`MaybeUninit::assume_init`], il appartient à l'appelant de garantir que la valeur interne est vraiment dans un état initialisé.
    ///
    /// L'appeler lorsque le contenu n'est pas encore complètement initialisé entraîne un comportement indéfini immédiat.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Initialisation différée:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Consomme le `Rc`, renvoyant le pointeur encapsulé.
    ///
    /// Pour éviter une fuite de mémoire, le pointeur doit être reconverti en `Rc` à l'aide de [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Fournit un pointeur brut vers les données.
    ///
    /// Les décomptes ne sont en aucun cas affectés et le `Rc` n'est pas consommé.
    /// Le pointeur est valide tant qu'il y a des comptages forts dans le `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // SÉCURITÉ: Cela ne peut pas passer par Deref::deref ou Rc::inner car
        // ceci est nécessaire pour conserver la provenance raw/mut telle que par exemple
        // `get_mut` peut écrire via le pointeur après la récupération du Rc via `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Construit un `Rc<T>` à partir d'un pointeur brut.
    ///
    /// Le pointeur brut doit avoir été précédemment renvoyé par un appel à [`Rc<U>::into_raw`][into_raw] où `U` doit avoir la même taille et le même alignement que `T`.
    /// C'est trivialement vrai si `U` est `T`.
    /// Notez que si `U` n'est pas `T` mais a la même taille et le même alignement, cela revient essentiellement à transmuter des références de types différents.
    /// Voir [`mem::transmute`][transmute] pour plus d'informations sur les restrictions qui s'appliquent dans ce cas.
    ///
    /// L'utilisateur de `from_raw` doit s'assurer qu'une valeur spécifique de `T` n'est supprimée qu'une seule fois.
    ///
    /// Cette fonction n'est pas sûre car une utilisation incorrecte peut conduire à une insécurité de la mémoire, même si le `Rc<T>` renvoyé n'est jamais accédé.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Reconvertissez-le en `Rc` pour éviter les fuites.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // D'autres appels à `Rc::from_raw(x_ptr)` seraient dangereux pour la mémoire.
    /// }
    ///
    /// // La mémoire a été libérée lorsque `x` est sorti de la portée ci-dessus, donc `x_ptr` est maintenant suspendu!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Inversez le décalage pour trouver la RcBox d'origine.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Crée un nouveau pointeur [`Weak`] vers cette allocation.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Assurez-vous que nous ne créons pas un faible pendant
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Obtient le nombre de pointeurs [`Weak`] vers cette allocation.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Obtient le nombre de pointeurs (`Rc`) puissants vers cette allocation.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Renvoie `true` s'il n'y a pas d'autres pointeurs `Rc` ou [`Weak`] vers cette allocation.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Renvoie une référence mutable dans le `Rc` donné, s'il n'y a pas d'autres pointeurs `Rc` ou [`Weak`] vers la même allocation.
    ///
    ///
    /// Renvoie [`None`] dans le cas contraire, car il n'est pas sûr de muter une valeur partagée.
    ///
    /// Voir aussi [`make_mut`][make_mut], qui [`clone`][clone] la valeur interne lorsqu'il y a d'autres pointeurs.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Renvoie une référence mutable dans le `Rc` donné, sans aucune vérification.
    ///
    /// Voir aussi [`get_mut`], qui est sûr et effectue les vérifications appropriées.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Les autres pointeurs `Rc` ou [`Weak`] vers la même allocation ne doivent pas être déréférencés pendant la durée de l'emprunt retourné.
    ///
    /// C'est trivialement le cas si de tels pointeurs n'existent pas, par exemple immédiatement après `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Nous veillons à ne *pas* créer une référence couvrant les champs "count", car cela entrerait en conflit avec les accès aux décomptes de références (par exemple
        // par `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Renvoie `true` si les deux `Rc`s pointent vers la même allocation (dans une veine similaire à [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Crée une référence mutable dans le `Rc` donné.
    ///
    /// S'il y a d'autres pointeurs `Rc` vers la même allocation, alors `make_mut` va [`clone`] la valeur interne vers une nouvelle allocation pour garantir une propriété unique.
    /// Ceci est également appelé clone-on-write.
    ///
    /// S'il n'y a pas d'autres pointeurs `Rc` vers cette allocation, les pointeurs [`Weak`] vers cette allocation seront dissociés.
    ///
    /// Voir aussi [`get_mut`], qui échouera plutôt que le clonage.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Ne clonera rien
    /// let mut other_data = Rc::clone(&data);    // Ne clonera pas les données internes
    /// *Rc::make_mut(&mut data) += 1;        // Clone les données internes
    /// *Rc::make_mut(&mut data) += 1;        // Ne clonera rien
    /// *Rc::make_mut(&mut other_data) *= 2;  // Ne clonera rien
    ///
    /// // Désormais, `data` et `other_data` pointent vers des allocations différentes.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] les pointeurs seront dissociés:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Je dois cloner les données, il y a d'autres Rcs.
            // Pré-allouez de la mémoire pour permettre l'écriture directe de la valeur clonée.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Je peux juste voler les données, il ne reste que des faiblesses
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Supprimez la référence implicite forte-faible (pas besoin de créer un faux faible ici-nous savons que d'autres faibles peuvent nettoyer pour nous)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Cette non-sécurité est acceptable car nous sommes assurés que le pointeur retourné est le *seul* pointeur qui sera jamais retourné à T.
        // Notre nombre de références est garanti à 1 à ce stade, et nous avons exigé que le `Rc<T>` lui-même soit `mut`, nous retournons donc la seule référence possible à l'allocation.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Essayez de réduire le `Rc<dyn Any>` à un type concret.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Alloue un `RcBox<T>` avec un espace suffisant pour une valeur interne éventuellement non dimensionnée où la valeur a la disposition fournie.
    ///
    /// La fonction `mem_to_rcbox` est appelée avec le pointeur de données et doit renvoyer un pointeur (potentiellement gros) pour le `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Calculez la disposition en utilisant la disposition de valeur donnée.
        // Auparavant, la mise en page était calculée sur l'expression `&*(ptr as* const RcBox<T>)`, mais cela créait une référence mal alignée (voir #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Alloue un `RcBox<T>` avec un espace suffisant pour une valeur interne éventuellement non dimensionnée où la valeur a la disposition fournie, renvoyant une erreur si l'allocation échoue.
    ///
    ///
    /// La fonction `mem_to_rcbox` est appelée avec le pointeur de données et doit renvoyer un pointeur (potentiellement gros) pour le `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Calculez la disposition en utilisant la disposition de valeur donnée.
        // Auparavant, la mise en page était calculée sur l'expression `&*(ptr as* const RcBox<T>)`, mais cela créait une référence mal alignée (voir #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Allouez pour la mise en page.
        let ptr = allocate(layout)?;

        // Initialiser la RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Alloue un `RcBox<T>` avec un espace suffisant pour une valeur interne non dimensionnée
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Allouez pour le `RcBox<T>` en utilisant la valeur donnée.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Copier la valeur sous forme d'octets
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Libérez l'allocation sans laisser tomber son contenu
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Alloue un `RcBox<[T]>` avec la longueur donnée.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Copier les éléments de la tranche dans le Rc nouvellement alloué <\[T\]>
    ///
    /// Non sécurisé car l'appelant doit s'approprier ou lier `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Construit un `Rc<[T]>` à partir d'un itérateur connu pour être d'une certaine taille.
    ///
    /// Le comportement n'est pas défini si la taille est incorrecte.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Garde Panic lors du clonage des éléments T.
        // En cas de panic, les éléments qui ont été écrits dans la nouvelle RcBox seront supprimés, puis la mémoire libérée.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Pointeur vers le premier élément
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Tout est clair.Oubliez la garde pour qu'elle ne libère pas la nouvelle RcBox.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Spécialisation trait utilisée pour `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Supprime le `Rc`.
    ///
    /// Cela diminuera le nombre de références fortes.
    /// Si le nombre de références fortes atteint zéro, les seules autres références (le cas échéant) sont [`Weak`], donc nous `drop` la valeur interne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // N'imprime rien
    /// drop(foo2);   // Imprime "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // détruire l'objet contenu
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // supprimez le pointeur "strong weak" implicite maintenant que nous avons détruit le contenu.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Crée un clone du pointeur `Rc`.
    ///
    /// Cela crée un autre pointeur vers la même allocation, augmentant le nombre de références fortes.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Crée un nouveau `Rc<T>`, avec la valeur `Default` pour `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack pour permettre de se spécialiser sur `Eq` même si `Eq` a une méthode.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Nous faisons cette spécialisation ici, et non comme une optimisation plus générale sur `&T`, car cela ajouterait autrement un coût à tous les contrôles d'égalité sur les références.
/// Nous supposons que les `Rc`s sont utilisés pour stocker de grandes valeurs, qui sont lentes à cloner, mais également lourdes à vérifier pour l'égalité, ce qui rend ce coût plus rentable.
///
/// Il est également plus probable d'avoir deux clones `Rc`, qui pointent vers la même valeur, que deux `&T`s.
///
/// Nous ne pouvons le faire que lorsque `T: Eq` en tant que `PartialEq` peut être délibérément irréfléchi.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Egalité pour deux «Rc».
    ///
    /// Deux «Rc» sont égaux si leurs valeurs internes sont égales, même s'ils sont stockés dans une allocation différente.
    ///
    /// Si `T` implémente également `Eq` (impliquant la réflexivité d'égalité), deux `Rc`s qui pointent vers la même allocation sont toujours égaux.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Inégalité pour deux «Rc».
    ///
    /// Deux «Rc» sont inégaux si leurs valeurs internes sont inégales.
    ///
    /// Si `T` implémente également `Eq` (impliquant la réflexivité d'égalité), deux `Rc`s qui pointent vers la même allocation ne sont jamais inégaux.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Comparaison partielle pour deux `Rc`s.
    ///
    /// Les deux sont comparés en appelant `partial_cmp()` sur leurs valeurs internes.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Moins que comparaison pour deux `Rc`s.
    ///
    /// Les deux sont comparés en appelant `<` sur leurs valeurs internes.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Comparaison "Inférieur ou égal à" pour deux "Rc".
    ///
    /// Les deux sont comparés en appelant `<=` sur leurs valeurs internes.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Comparaison supérieure à deux «Rc».
    ///
    /// Les deux sont comparés en appelant `>` sur leurs valeurs internes.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Comparaison "Supérieur ou égal à" pour deux "Rc".
    ///
    /// Les deux sont comparés en appelant `>=` sur leurs valeurs internes.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Comparaison pour deux `Rc`s.
    ///
    /// Les deux sont comparés en appelant `cmp()` sur leurs valeurs internes.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Allouez une tranche comptée par référence et remplissez-la en clonant les éléments de `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Allouez une tranche de chaîne comptée par référence et copiez-y `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Allouez une tranche de chaîne comptée par référence et copiez-y `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Déplacer un objet encadré vers une nouvelle allocation comptée par référence.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Allouez une tranche comptée par référence et déplacez-y les éléments de `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Permettre au Vec de libérer sa mémoire, mais pas de détruire son contenu
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Prend chaque élément du `Iterator` et le rassemble dans un `Rc<[T]>`.
    ///
    /// # Caractéristiques de performance
    ///
    /// ## Le cas général
    ///
    /// Dans le cas général, la collecte dans `Rc<[T]>` se fait en collectant d'abord dans un `Vec<T>`.Autrement dit, lors de l'écriture de ce qui suit:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// cela se comporte comme si nous écrivions:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Le premier ensemble d'allocations se produit ici.
    ///     .into(); // Une deuxième allocation pour `Rc<[T]>` se produit ici.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Cela allouera autant de fois que nécessaire pour construire le `Vec<T>`, puis il allouera une fois pour transformer le `Vec<T>` en `Rc<[T]>`.
    ///
    ///
    /// ## Itérateurs de longueur connue
    ///
    /// Lorsque votre `Iterator` implémente `TrustedLen` et est d'une taille exacte, une seule allocation sera faite pour le `Rc<[T]>`.Par example:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Une seule allocation se produit ici.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Spécialisation trait utilisée pour la collecte dans `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // C'est le cas d'un itérateur `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SÉCURITÉ: Nous devons nous assurer que l'itérateur a une longueur exacte et nous l'avons fait.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Revenez à une mise en œuvre normale.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` est une version de [`Rc`] qui contient une référence non propriétaire à l'allocation gérée.L'allocation est accessible en appelant [`upgrade`] sur le pointeur `Weak`, qui renvoie une [`Option`]`<`[`Rc`] `<T>>`.
///
/// Puisqu'une référence `Weak` ne compte pas dans la propriété, elle n'empêchera pas la valeur stockée dans l'allocation d'être supprimée, et `Weak` lui-même ne donne aucune garantie quant à la valeur toujours présente.
/// Ainsi, il peut renvoyer [`None`] lorsque [`upgrade`] d.
/// Notez cependant qu'une référence `Weak`*n'empêche* pas l'allocation elle-même (le magasin de sauvegarde) d'être désallouée.
///
/// Un pointeur `Weak` est utile pour conserver une référence temporaire à l'allocation gérée par [`Rc`] sans empêcher la suppression de sa valeur interne.
/// Il est également utilisé pour empêcher les références circulaires entre les pointeurs [`Rc`], car les références de propriété mutuelle ne permettraient jamais de supprimer l'un ou l'autre de [`Rc`].
/// Par exemple, une arborescence peut avoir des pointeurs [`Rc`] puissants des nœuds parents vers les enfants et des pointeurs `Weak` des enfants vers leurs parents.
///
/// La méthode classique pour obtenir un pointeur `Weak` consiste à appeler [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Il s'agit d'un `NonNull` pour permettre d'optimiser la taille de ce type dans les énumérations, mais ce n'est pas forcément un pointeur valide.
    //
    // `Weak::new` définit ceci sur `usize::MAX` afin qu'il n'ait pas besoin d'allouer d'espace sur le tas.
    // Ce n'est pas une valeur qu'un vrai pointeur aura jamais car RcBox a un alignement d'au moins 2.
    // Ceci n'est possible que lorsque `T: Sized`;`T` non dimensionné ne pend jamais.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Construit un nouveau `Weak<T>`, sans allouer de mémoire.
    /// L'appel de [`upgrade`] sur la valeur de retour donne toujours [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Type d'assistance pour permettre l'accès aux décomptes de références sans faire aucune affirmation sur le champ de données.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Renvoie un pointeur brut vers l'objet `T` pointé par ce `Weak<T>`.
    ///
    /// Le pointeur n'est valide que s'il existe des références fortes.
    /// Le pointeur peut être suspendu, non aligné ou même [`null`] dans le cas contraire.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Les deux pointent vers le même objet
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Le fort ici le maintient en vie, de sorte que nous pouvons toujours accéder à l'objet.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Mais plus maintenant.
    /// // Nous pouvons faire weak.as_ptr(), mais accéder au pointeur entraînerait un comportement indéfini.
    /// // assert_eq! ("bonjour", unsafe {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Si le pointeur est suspendu, nous renvoyons directement la sentinelle.
            // Cela ne peut pas être une adresse de charge utile valide, car la charge utile est au moins aussi alignée que RcBox (usize).
            ptr as *const T
        } else {
            // SÉCURITÉ: si is_dangling renvoie false, alors le pointeur est déréférencable.
            // La charge utile peut être supprimée à ce stade, et nous devons maintenir la provenance, utilisez donc la manipulation brute du pointeur.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Consomme le `Weak<T>` et le transforme en un pointeur brut.
    ///
    /// Cela convertit le pointeur faible en un pointeur brut, tout en préservant la propriété d'une référence faible (le nombre faible n'est pas modifié par cette opération).
    /// Il peut être reconverti en `Weak<T>` avec [`from_raw`].
    ///
    /// Les mêmes restrictions d'accès à la cible du pointeur qu'avec [`as_ptr`] s'appliquent.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Convertit un pointeur brut précédemment créé par [`into_raw`] en `Weak<T>`.
    ///
    /// Cela peut être utilisé pour obtenir en toute sécurité une référence forte (en appelant [`upgrade`] plus tard) ou pour désallouer le nombre faible en supprimant le `Weak<T>`.
    ///
    /// Il prend possession d'une référence faible (à l'exception des pointeurs créés par [`new`], car ceux-ci ne possèdent rien; la méthode fonctionne toujours sur eux).
    ///
    /// # Safety
    ///
    /// Le pointeur doit provenir du [`into_raw`] et doit toujours posséder sa référence faible potentielle.
    ///
    /// Il est permis que le nombre fort soit égal à 0 au moment de l'appel.
    /// Néanmoins, cela s'approprie une référence faible actuellement représentée comme un pointeur brut (le décompte faible n'est pas modifié par cette opération) et doit donc être couplé avec un appel précédent à [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Décrémentez le dernier décompte faible.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Voir Weak::as_ptr pour le contexte sur la façon dont le pointeur d'entrée est dérivé.

        let ptr = if is_dangling(ptr as *mut T) {
            // C'est un faible pendantes.
            ptr as *mut RcBox<T>
        } else {
            // Sinon, nous sommes assurés que le pointeur provient d'un faible non enchevêtré.
            // SÉCURITÉ: data_offset peut être appelé en toute sécurité, car ptr fait référence à un T.
            let offset = unsafe { data_offset(ptr) };
            // Ainsi, nous inversons le décalage pour obtenir l'ensemble de la RcBox.
            // SÉCURITÉ: le pointeur provient d'un faible, donc ce décalage est sûr.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SÉCURITÉ: nous avons maintenant récupéré le pointeur faible d'origine, nous pouvons donc créer le pointeur faible.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Tente de mettre à niveau le pointeur `Weak` vers un [`Rc`], retardant la suppression de la valeur interne en cas de succès.
    ///
    ///
    /// Renvoie [`None`] si la valeur interne a depuis été supprimée.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Détruisez tous les pointeurs forts.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Obtient le nombre de pointeurs (`Rc`) forts pointant vers cette allocation.
    ///
    /// Si `self` a été créé à l'aide de [`Weak::new`], cela renverra 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Obtient le nombre de pointeurs `Weak` pointant vers cette allocation.
    ///
    /// S'il ne reste aucun pointeur fort, cela renverra zéro.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // soustraire le ptr faible implicite
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Renvoie `None` lorsque le pointeur est suspendu et qu'il n'y a pas de `RcBox` alloué, (c'est-à-dire lorsque ce `Weak` a été créé par `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Nous prenons soin de ne *pas* créer une référence couvrant le champ "data", car le champ peut être muté simultanément (par exemple, si le dernier `Rc` est supprimé, le champ de données sera supprimé sur place).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Renvoie `true` si les deux `Weak`s pointent vers la même allocation (similaire à [`ptr::eq`]), ou si les deux ne pointent vers aucune allocation (car ils ont été créés avec `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Puisque cela compare les pointeurs, cela signifie que `Weak::new()` s'égalisera, même s'ils ne pointent vers aucune allocation.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Comparaison de `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Supprime le pointeur `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // N'imprime rien
    /// drop(foo);        // Imprime "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // le nombre faible commence à 1 et ne passera à zéro que si tous les pointeurs forts ont disparu.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Crée un clone du pointeur `Weak` qui pointe vers la même allocation.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Construit un nouveau `Weak<T>`, allouant de la mémoire pour `T` sans l'initialiser.
    /// L'appel de [`upgrade`] sur la valeur de retour donne toujours [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Nous avons vérifié_add ici pour traiter mem::forget en toute sécurité.En particulier
// si vous mem::forget Rcs (ou Weaks), le ref-count peut déborder, et alors vous pouvez libérer l'allocation alors que des Rcs (ou Weaks) exceptionnels existent.
//
// Nous abandonnons parce que c'est un scénario tellement dégénéré que nous ne nous soucions pas de ce qui se passe-aucun programme réel ne devrait jamais en faire l'expérience.
//
// Cela devrait avoir une surcharge négligeable car vous n'avez pas vraiment besoin de les cloner dans Rust grâce à la propriété et à la sémantique du mouvement.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Nous voulons abandonner en cas de dépassement au lieu de supprimer la valeur.
        // Le nombre de références ne sera jamais égal à zéro lors de l'appel;
        // néanmoins, nous insérons ici un abandon pour indiquer à LLVM une optimisation autrement manquée.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Nous voulons abandonner en cas de dépassement au lieu de supprimer la valeur.
        // Le nombre de références ne sera jamais égal à zéro lors de l'appel;
        // néanmoins, nous insérons ici un abandon pour indiquer à LLVM une optimisation autrement manquée.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Obtenez le décalage dans un `RcBox` pour la charge utile derrière un pointeur.
///
/// # Safety
///
/// Le pointeur doit pointer vers (et avoir des métadonnées valides pour) une instance précédemment valide de T, mais le T est autorisé à être supprimé.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Alignez la valeur non dimensionnée à la fin de la RcBox.
    // Étant donné que RcBox est repr(C), ce sera toujours le dernier champ en mémoire.
    // SÉCURITÉ: puisque les seuls types non dimensionnés possibles sont des tranches, des objets trait,
    // et les types extern, l'exigence de sécurité d'entrée est actuellement suffisante pour satisfaire les exigences de align_of_val_raw;il s'agit d'un détail d'implémentation du langage sur lequel on ne peut pas se fier en dehors de std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}