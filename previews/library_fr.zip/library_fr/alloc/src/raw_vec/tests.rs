use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Écrire un test d'intégration entre les allocateurs tiers et `RawVec` est un peu délicat car l'API `RawVec` n'expose pas de méthodes d'allocation faillibles, nous ne pouvons donc pas vérifier ce qui se passe lorsque l'allocateur est épuisé (au-delà de la détection d'un panic).
    //
    //
    // Au lieu de cela, cela vérifie simplement que les méthodes `RawVec` passent au moins par l'API Allocator lorsqu'elle réserve du stockage.
    //
    //
    //
    //
    //

    // Un allocateur stupide qui consomme une quantité fixe de carburant avant que les tentatives d'allocation ne commencent à échouer.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (provoque une réallocation, utilisant ainsi 50 + 150=200 unités de carburant)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Tout d'abord, `reserve` alloue comme `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 est plus du double de 7, donc `reserve` devrait fonctionner comme `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 est inférieur à la moitié de 12, donc `reserve` doit croître de manière exponentielle.
        // Au moment de la rédaction de cet article, ce facteur de croissance de test est de 2, donc la nouvelle capacité est de 24, cependant, le facteur de croissance de 1.5 est également OK.
        //
        // D'où `>= 18` dans assert.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}