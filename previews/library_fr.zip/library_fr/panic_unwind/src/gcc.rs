//! Implémentation de panics soutenu par libgcc/libunwind (sous une forme ou une autre).
//!
//! Pour en savoir plus sur la gestion des exceptions et le déroulement de la pile, veuillez consulter "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) et les documents qui y sont liés.
//! Ce sont également de bonnes lectures:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## Un bref résumé
//!
//! La gestion des exceptions se déroule en deux phases: une phase de recherche et une phase de nettoyage.
//!
//! Dans les deux phases, le dérouleur parcourt les cadres de la pile de haut en bas en utilisant les informations des sections de déroulement des cadres de pile des modules du processus courant ("module" fait ici référence à un module OS, c'est-à-dire un exécutable ou une bibliothèque dynamique).
//!
//!
//! Pour chaque frame de pile, il appelle le "personality routine" associé, dont l'adresse est également stockée dans la section d'informations de déroulement.
//!
//! Dans la phase de recherche, le travail d'une routine de personnalité est d'examiner l'objet d'exception lancé et de décider s'il doit être intercepté au niveau de cette image de pile.Une fois la trame du gestionnaire identifiée, la phase de nettoyage commence.
//!
//! Dans la phase de nettoyage, le dérouleur invoque à nouveau chaque routine de personnalité.
//! Cette fois, il décide quel code de nettoyage (le cas échéant) doit être exécuté pour le cadre de pile actuel.Si tel est le cas, le contrôle est transféré vers un branch spécial dans le corps de la fonction, le "landing pad", qui invoque des destructeurs, libère de la mémoire, etc.
//! À la fin de la piste d'atterrissage, le contrôle est transféré vers le dérouleur et le déroulement reprend.
//!
//! Une fois que la pile a été déroulée jusqu'au niveau de la trame du gestionnaire, le déroulement s'arrête et la dernière routine de personnalité transfère le contrôle au bloc catch.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Identificateur de classe d'exception de Rust.
// Ceci est utilisé par les routines de personnalité pour déterminer si l'exception a été levée par leur propre environnement d'exécution.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-fournisseur, langue
    0x4d4f5a_00_52555354
}

// Les identifiants de registre ont été retirés des TargetLowering::getExceptionPointerRegister() et TargetLowering::getExceptionSelectorRegister() de LLVM pour chaque architecture, puis mappés aux numéros de registre DWARF via des tables de définition de registre (généralement<arch>RegisterInfo.td, recherchez "DwarfRegNum").
//
// Voir également http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// Le code suivant est basé sur les routines de personnalité C et C++ de GCC.Pour référence, voir:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM Routine de personnalité EHABI.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS utilise la routine par défaut à la place car elle utilise le déroulement SjLj.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // Les backtraces sur ARM appelleront la routine de personnalité avec l'état==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // Dans ces cas, nous voulons continuer à dérouler la pile, sinon toutes nos traces se termineraient à __rust_try
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // Le dérouleur DWARF suppose que_Unwind_Context contient des éléments tels que la fonction et les pointeurs LSDA, mais ARM EHABI les place dans l'objet d'exception.
            // Pour conserver les signatures de fonctions telles que _Unwind_GetLanguageSpecificData(), qui ne prennent que le pointeur de contexte, les routines de personnalité GCC placent un pointeur vers exception_object dans le contexte, en utilisant l'emplacement réservé au "scratch register" (r12) d'ARM.
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... Une approche plus raisonnée serait de fournir la définition complète du_Unwind_Context d'ARM dans nos liaisons libunwind et de récupérer directement les données requises à partir de là, en contournant les fonctions de compatibilité DWARF.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI requiert que la routine de personnalité mette à jour la valeur SP dans le cache de barrière de l'objet d'exception.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // Sur ARM EHABI, la routine de personnalité est responsable du déroulement d'une seule trame de pile avant de revenir (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // défini dans libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // Routine de personnalité par défaut, qui est utilisée directement sur la plupart des cibles et indirectement sur Windows x86_64 via SEH.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // Sur les cibles x86_64 MinGW, le mécanisme de déroulement est SEH, mais les données du gestionnaire de déroulement (aka LSDA) utilisent un codage compatible GCC.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // La routine de personnalité pour la plupart de nos cibles.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // L'adresse de retour pointe 1 octet après l'instruction d'appel, qui pourrait être dans la plage IP suivante dans la table de plage LSDA.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// Enregistrement des informations de déroulement du cadre
//
// L'image de chaque module contient une section d'informations sur le déroulement du cadre (généralement ".eh_frame").Lorsqu'un module est loaded/unloaded dans le processus, le dérouleur doit être informé de l'emplacement de cette section en mémoire.Les méthodes pour y parvenir varient selon la plate-forme.
// Sur certains (par exemple, Linux), le dérouleur peut découvrir lui-même les sections d'informations de déroulement (en énumérant dynamiquement les modules actuellement chargés via le dl_iterate_phdr() API and finding their ".eh_frame" sections); D'autres, comme Windows, nécessitent que les modules enregistrent activement leurs sections d'informations de déroulement via l'API de déroulement.
//
//
// Ce module définit deux symboles qui sont référencés et appelés depuis rsbegin.rs pour enregistrer nos informations avec le runtime GCC.
// L'implémentation du déroulement de la pile est (pour l'instant) reportée à libgcc_eh, cependant Rust crates utilise ces points d'entrée spécifiques à Rust pour éviter les conflits potentiels avec n'importe quel runtime GCC.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}