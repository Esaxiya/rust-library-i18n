//! Windows SEH
//!
//! Sur Windows (actuellement uniquement sur MSVC), le mécanisme de gestion des exceptions par défaut est la gestion structurée des exceptions (SEH).
//! Ceci est assez différent de la gestion des exceptions basée sur Dwarf (par exemple, ce que les autres plates-formes unix utilisent) en termes de composants internes du compilateur, donc LLVM doit avoir une bonne prise en charge supplémentaire pour SEH.
//!
//! En un mot, ce qui se passe ici est:
//!
//! 1. La fonction `panic` appelle la fonction Windows standard `_CxxThrowException` pour lancer une exception de type C++ , déclenchant le processus de déroulement.
//! 2.
//! Tous les landing pads générés par le compilateur utilisent la fonction de personnalité `__CxxFrameHandler3`, une fonction dans le CRT, et le code de déroulement dans Windows utilisera cette fonction de personnalité pour exécuter tout le code de nettoyage sur la pile.
//!
//! 3. Tous les appels à `invoke` générés par le compilateur ont une zone d'atterrissage définie en tant qu'instruction `cleanuppad` LLVM, qui indique le début de la routine de nettoyage.
//! La personnalité (à l'étape 2, définie dans le CRT) est responsable de l'exécution des routines de nettoyage.
//! 4. Finalement, le code "catch" dans l'intrinsèque `try` (généré par le compilateur) est exécuté et indique que le contrôle doit revenir à Rust.
//! Cela se fait via une instruction `catchswitch` plus une instruction `catchpad` en termes LLVM IR, renvoyant enfin le contrôle normal au programme avec une instruction `catchret`.
//!
//! Certaines différences spécifiques par rapport à la gestion des exceptions basée sur gcc sont:
//!
//! * Rust n'a pas de fonction de personnalité personnalisée, c'est à la place *toujours*`__CxxFrameHandler3`.De plus, aucun filtrage supplémentaire n'est effectué, nous finissons donc par attraper toutes les exceptions C++ qui ressemblent au type que nous lançons.
//! Notez que lancer une exception dans Rust est de toute façon un comportement indéfini, donc cela devrait être bien.
//! * Nous avons des données à transmettre à travers la limite de déroulement, en particulier un `Box<dyn Any + Send>`.Comme avec les exceptions Dwarf, ces deux pointeurs sont stockés en tant que charge utile dans l'exception elle-même.
//! Sur MSVC, cependant, il n'y a pas besoin d'une allocation de tas supplémentaire car la pile d'appels est conservée pendant l'exécution des fonctions de filtrage.
//! Cela signifie que les pointeurs sont passés directement à `_CxxThrowException` qui sont ensuite récupérés dans la fonction de filtre pour être écrits dans la trame de pile de l'intrinsèque `try`.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Cela doit être une option car nous interceptons l'exception par référence et son destructeur est exécuté par le runtime C++ .
    // Lorsque nous sortons la boîte de l'exception, nous devons laisser l'exception dans un état valide pour que son destructeur s'exécute sans double-abandonner la boîte.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Tout d'abord, tout un tas de définitions de type.Il y a quelques bizarreries spécifiques à la plate-forme ici, et beaucoup sont simplement copiées de manière flagrante à partir de LLVM.Le but de tout cela est d'implémenter la fonction `panic` ci-dessous via un appel à `_CxxThrowException`.
//
// Cette fonction prend deux arguments.Le premier est un pointeur vers les données que nous transmettons, qui dans ce cas est notre objet trait.Assez facile à trouver!Le suivant, cependant, est plus compliqué.
// Il s'agit d'un pointeur vers une structure `_ThrowInfo`, et il est généralement destiné uniquement à décrire l'exception levée.
//
// Actuellement, la définition de ce type [1] est un peu poilue, et la principale bizarrerie (et la différence par rapport à l'article en ligne) est que sur 32 bits, les pointeurs sont des pointeurs, mais sur 64 bits, les pointeurs sont exprimés sous forme de décalages de 32 bits à partir du Symbole `__ImageBase`.
//
// Les macros `ptr_t` et `ptr!` dans les modules ci-dessous sont utilisées pour exprimer cela.
//
// Le labyrinthe des définitions de type suit également de près ce que LLVM émet pour ce type d'opération.Par exemple, si vous compilez ce code C++ sur MSVC et émettez le LLVM IR:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      vide foo() { rust_panic a = {0, 1};
//          jeter un;}
//
// C'est essentiellement ce que nous essayons d'imiter.La plupart des valeurs constantes ci-dessous ont été simplement copiées à partir de LLVM,
//
// Dans tous les cas, ces structures sont toutes construites de la même manière, et c'est juste un peu verbeux pour nous.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Notez que nous ignorons intentionnellement les règles de transformation des noms ici: nous ne voulons pas que C++ puisse attraper Rust panics en déclarant simplement un `struct rust_panic`.
//
//
// Lors de la modification, assurez-vous que la chaîne de nom de type correspond exactement à celle utilisée dans `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // L'octet `\x01` de tête ici est en fait un signal magique à LLVM pour ne *pas* appliquer tout autre découpage comme le préfixe avec un caractère `_`.
    //
    //
    // Ce symbole est la vtable utilisée par le `std::type_info` de C++ .
    // Les objets de type `std::type_info`, descripteurs de type, ont un pointeur vers cette table.
    // Les descripteurs de type sont référencés par les structures C++ EH définies ci-dessus et que nous construisons ci-dessous.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Ce descripteur de type n'est utilisé que lors de la levée d'une exception.
// La partie catch est gérée par l'intrinsèque try, qui génère son propre TypeDescriptor.
//
// C'est très bien car le runtime MSVC utilise la comparaison de chaînes sur le nom du type pour faire correspondre TypeDescriptors plutôt que l'égalité de pointeur.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destructor utilisé si le code C++ décide de capturer l'exception et de la supprimer sans la propager.
// La partie catch de l'intrinsèque try définit le premier mot de l'objet d'exception sur 0 afin qu'il soit ignoré par le destructeur.
//
// Notez que x86 Windows utilise la convention d'appel "thiscall" pour les fonctions membres C++ au lieu de la convention d'appel "C" par défaut.
//
// La fonction exception_copy est un peu spéciale ici: elle est appelée par le runtime MSVC sous un bloc try/catch et le panic que nous générons ici sera utilisé comme résultat de la copie d'exception.
//
// Ceci est utilisé par le runtime C++ pour prendre en charge la capture d'exceptions avec std::exception_ptr, ce que nous ne pouvons pas prendre en charge car Box<dyn Any>n'est pas clonable.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException s'exécute entièrement sur cette trame de pile, il n'est donc pas nécessaire de transférer autrement `data` vers le tas.
    // Nous passons simplement un pointeur de pile vers cette fonction.
    //
    // Le ManuallyDrop est nécessaire ici car nous ne voulons pas que l'exception soit supprimée lors du déroulement.
    // Au lieu de cela, il sera supprimé par exception_cleanup qui est appelé par le runtime C++ .
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Cela ... peut paraître surprenant, et à juste titre.Sur MSVC 32 bits, les pointeurs entre ces structures ne sont que des pointeurs.
    // Sur MSVC 64 bits, cependant, les pointeurs entre les structures sont plutôt exprimés sous forme de décalages 32 bits à partir de `__ImageBase`.
    //
    // Par conséquent, sur MSVC 32 bits, nous pouvons déclarer tous ces pointeurs dans les «statiques» ci-dessus.
    // Sur MSVC 64 bits, nous devrions exprimer la soustraction de pointeurs en statique, ce que Rust n'autorise pas actuellement, nous ne pouvons donc pas le faire.
    //
    // La prochaine meilleure chose est alors de remplir ces structures au moment de l'exécution (la panique est déjà le "slow path" de toute façon).
    // Donc, ici, nous réinterprétons tous ces champs de pointeur sous forme d'entiers 32 bits, puis nous y stockons la valeur appropriée (de manière atomique, car des panics simultanés peuvent se produire).
    //
    // Techniquement, le runtime effectuera probablement une lecture non atomique de ces champs, mais en théorie, ils ne liront jamais la *mauvaise* valeur donc cela ne devrait pas être trop mauvais ...
    //
    // Dans tous les cas, nous devons essentiellement faire quelque chose comme ça jusqu'à ce que nous puissions exprimer plus d'opérations en statique (et nous ne pourrons peut-être jamais le faire).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Une charge utile NULL ici signifie que nous sommes arrivés ici à partir de la capture (...) de __rust_try.
    // Cela se produit lorsqu'une exception étrangère non-Rust est interceptée.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Ceci est requis par le compilateur pour exister (par exemple, c'est un élément lang), mais il n'est jamais réellement appelé par le compilateur car __C_specific_handler ou_except_handler3 est la fonction de personnalité qui est toujours utilisée.
//
// Il ne s'agit donc que d'un stub avorté.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}