//! Dérouler panics pour Miri.
use alloc::boxed::Box;
use core::any::Any;

// Le type de charge utile que le moteur Miri propage à travers le déroulement pour nous.
// Doit être de la taille d'un pointeur.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Fonction externe fournie par Miri pour commencer le déroulement.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // La charge utile que nous transmettons à `miri_start_panic` sera exactement l'argument que nous obtenons dans `cleanup` ci-dessous.
    // Donc, nous l'avons simplement mis en boîte une fois, pour obtenir quelque chose de la taille d'un pointeur.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Récupérez le `Box` sous-jacent.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}