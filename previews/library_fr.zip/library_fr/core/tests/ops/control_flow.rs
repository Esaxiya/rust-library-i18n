use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Ce n'est pas une surface stable, mais cela permet de garder `?` bon marché entre eux, même si LLVM ne peut pas toujours en profiter pour le moment.
    //
    // (Malheureusement, le résultat et l'option sont incohérents, donc ControlFlow ne peut pas correspondre aux deux.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}