use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri est trop lente
fn exact_sanity_test() {
    // Ce test finit par exécuter ce que je ne peux que supposer être un cas de coin de la fonction de bibliothèque `exp2`, défini dans le runtime C que nous utilisons.
    // Dans VS 2013, cette fonction avait apparemment un bogue car ce test échoue lorsqu'il est lié, mais avec VS 2015, le bogue semble corrigé car le test fonctionne très bien.
    //
    // Le bogue semble être une différence dans la valeur de retour de `exp2(-1057)`, où dans VS 2013, il renvoie un double avec le motif de bits 0x2 et dans VS 2015, il renvoie 0x20000.
    //
    //
    // Pour l'instant, ignorez complètement ce test sur MSVC car il est testé ailleurs de toute façon et nous ne sommes pas très intéressés par le test de l'implémentation exp2 de chaque plate-forme.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}