//! Prise en charge de Panic pour libcore
//!
//! La bibliothèque principale ne peut pas définir la panique, mais elle *déclare* paniquer.
//! Cela signifie que les fonctions à l'intérieur de libcore sont autorisées à panic, mais pour être utile, un crate en amont doit définir la panique pour que libcore puisse l'utiliser.
//! L'interface actuelle pour paniquer est:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Cette définition permet de paniquer avec n'importe quel message général, mais elle ne permet pas d'échouer avec une valeur `Box<Any>`.
//! (`PanicInfo` contient juste un `&(dyn Any + Send)`, pour lequel nous remplissons une valeur factice dans `PanicInfo: : internal_constructor`.) La raison en est que libcore n'est pas autorisé à allouer.
//!
//!
//! Ce module contient quelques autres fonctions de panique, mais ce ne sont que les éléments lang nécessaires pour le compilateur.Tous les panics sont canalisés à travers cette fonction unique.
//! Le symbole réel est déclaré via l'attribut `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// L'implémentation sous-jacente de la macro `panic!` de libcore lorsqu'aucun formatage n'est utilisé.
#[cold]
// jamais en ligne sauf si panic_immediate_abort pour éviter autant que possible le gonflement du code sur les sites d'appel
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // nécessaire par codegen pour panic en cas de débordement et autres terminateurs MIR `Assert`
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Utilisez Arguments::new_v1 au lieu de format_args! ("{}", Expr) pour réduire potentiellement la surcharge de taille.
    // Le format_args!macro utilise l'affichage trait de str pour écrire expr, qui appelle Formatter::pad, qui doit prendre en charge la troncature et le remplissage de chaînes (même si aucun n'est utilisé ici).
    //
    // L'utilisation de Arguments::new_v1 peut permettre au compilateur d'omettre Formatter::pad du binaire de sortie, économisant jusqu'à quelques kilo-octets.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // nécessaire pour panics évalué par const
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // nécessaire par codegen pour panic sur l'accès OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// L'implémentation sous-jacente de la macro `panic!` de libcore lors du formatage est utilisée.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // REMARQUE Cette fonction ne franchit jamais la frontière FFI;c'est un appel Rust-to-Rust qui est résolu en fonction `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // SÉCURITÉ: `panic_impl` est défini dans le code sûr Rust et peut donc être appelé en toute sécurité.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Fonction interne pour les macros `assert_eq!` et `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}