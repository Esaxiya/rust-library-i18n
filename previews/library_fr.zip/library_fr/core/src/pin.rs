//! Types qui épinglent les données à leur emplacement en mémoire.
//!
//! Il est parfois utile d'avoir des objets garantis de ne pas bouger, dans le sens où leur placement en mémoire ne change pas, et peut donc être invoqué.
//! Un excellent exemple d'un tel scénario serait la construction de structures auto-référentielles, car déplacer un objet avec des pointeurs vers lui-même les invalidera, ce qui pourrait entraîner un comportement indéfini.
//!
//! À un niveau élevé, un [`Pin<P>`] garantit que la pointe de tout type de pointeur `P` a un emplacement stable dans la mémoire, ce qui signifie qu'elle ne peut pas être déplacée ailleurs et que sa mémoire ne peut pas être désallouée jusqu'à ce qu'elle soit abandonnée.On dit que la pointee est "pinned".Les choses deviennent plus subtiles lors de la discussion des types qui combinent des données épinglées avec des données non épinglées;[see below](#projections-and-structural-pinning) pour plus de détails.
//!
//! Par défaut, tous les types de Rust sont mobiles.
//! Rust permet de passer tous les types par valeur, et les types de pointeurs intelligents courants tels que [`Box<T>`] et `&mut T` permettent de remplacer et de déplacer les valeurs qu'ils contiennent: vous pouvez sortir d'un [`Box<T>`], ou vous pouvez utiliser [`mem::swap`].
//! [`Pin<P>`] enveloppe un pointeur de type `P`, donc [`Pin`]`<`[`Box`] `<T>>`fonctionne un peu comme un
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Box`] `<T>>`est abandonné, ainsi que son contenu, et la mémoire obtient
//!
//! désalloué.De même, [`Pin`]`<&mut T>`ressemble beaucoup à `&mut T`.Cependant, [`Pin<P>`] ne permet pas aux clients d'obtenir réellement un [`Box<T>`] ou `&mut T` sur des données épinglées, ce qui implique que vous ne pouvez pas utiliser d'opérations telles que [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` a besoin de `&mut T`, mais nous ne pouvons pas l'obtenir.
//!     // Nous sommes bloqués, nous ne pouvons pas échanger le contenu de ces références.
//!     // Nous pourrions utiliser `Pin::get_unchecked_mut`, mais c'est dangereux pour une raison:
//!     // nous ne sommes pas autorisés à l'utiliser pour déplacer des objets hors du `Pin`.
//! }
//! ```
//!
//! Il convient de rappeler que [`Pin<P>`] ne change *pas* le fait qu'un compilateur Rust considère tous les types comme mobiles.[`mem::swap`] reste appelable pour n'importe quel `T`.Au lieu de cela, [`Pin<P>`] empêche certaines *valeurs*(pointées par des pointeurs encapsulés dans [`Pin<P>`]) d'être déplacées en rendant impossible d'appeler des méthodes qui nécessitent `&mut T` sur elles (comme [`mem::swap`]).
//!
//! [`Pin<P>`] peut être utilisé pour envelopper tout type de pointeur `P`, et en tant que tel, il interagit avec [`Deref`] et [`DerefMut`].Un [`Pin<P>`] où `P: Deref` doit être considéré comme un "`P`-style pointer" à un `P::Target` épinglé-donc, un [`Pin`]`<`[`Box`] `<T>>`est un pointeur appartenant à un `T` épinglé, et un [`Pin`] `<` [`Rc`]`<T>>`est un pointeur compté par référence vers un `T` épinglé.
//! Par souci d'exactitude, [`Pin<P>`] s'appuie sur les implémentations de [`Deref`] et [`DerefMut`] pour ne pas sortir de leur paramètre `self`, et uniquement pour renvoyer un pointeur vers des données épinglées lorsqu'elles sont appelées sur un pointeur épinglé.
//!
//! # `Unpin`
//!
//! De nombreux types sont toujours librement déplaçables, même lorsqu'ils sont épinglés, car ils ne reposent pas sur une adresse stable.Cela inclut tous les types de base (comme [`bool`], [`i32`] et les références) ainsi que les types composés uniquement de ces types.Les types qui ne se soucient pas de l'épinglage implémentent le [`Unpin`] auto-trait, qui annule l'effet de [`Pin<P>`].
//! Pour `T: Unpin`, [`Pin`]`<`[`Box`] `<T>>`et [`Box<T>`] fonctionnent de la même manière, tout comme [`Pin`] `<&mut T>` et `&mut T`.
//!
//! Notez que l'épinglage et [`Unpin`] n'affectent que le type pointé `P::Target`, pas le type de pointeur `P` lui-même qui a été encapsulé dans [`Pin<P>`].Par exemple, que [`Box<T>`] soit ou non [`Unpin`] n'a aucun effet sur le comportement de [`Pin`]`<`[`Box`] `<T>>`(ici, `T` est le type pointé).
//!
//! # Exemple: structure auto-référentielle
//!
//! Avant d'entrer dans plus de détails pour expliquer les garanties et les choix associés à `Pin<T>`, nous discutons quelques exemples de la façon dont il pourrait être utilisé.
//! N'hésitez pas à [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Il s'agit d'une structure auto-référentielle car le champ de tranche pointe vers le champ de données.
//! // Nous ne pouvons pas en informer le compilateur avec une référence normale, car ce modèle ne peut pas être décrit avec les règles d'emprunt habituelles.
//! //
//! // Au lieu de cela, nous utilisons un pointeur brut, bien qu'il soit connu pour ne pas être nul, car nous savons qu'il pointe sur la chaîne.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Pour nous assurer que les données ne bougent pas lorsque la fonction retourne, nous les plaçons dans le tas où elles resteront pour la durée de vie de l'objet, et le seul moyen d'y accéder serait via un pointeur vers celui-ci.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // nous ne créons le pointeur qu'une fois que les données sont en place sinon il aura déjà bougé avant même que nous ayons commencé
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // nous savons que c'est sûr car la modification d'un champ ne déplace pas toute la structure
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Le pointeur doit pointer vers l'emplacement correct, tant que la structure n'a pas été déplacée.
//! //
//! // En attendant, nous sommes libres de déplacer le pointeur.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Étant donné que notre type n'implémente pas Unpin, la compilation échouera:
//! // laissez mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Exemple: liste intrusive à double lien
//!
//! Dans une liste intrusive à double lien, la collection n'alloue pas réellement la mémoire pour les éléments eux-mêmes.
//! L'allocation est contrôlée par les clients et les éléments peuvent vivre sur un cadre de pile plus court que la collection.
//!
//! Pour que cela fonctionne, chaque élément a des pointeurs vers son prédécesseur et son successeur dans la liste.Les éléments ne peuvent être ajoutés que lorsqu'ils sont épinglés, car le déplacement des éléments invaliderait les pointeurs.De plus, l'implémentation [`Drop`] d'un élément de liste liée corrigera les pointeurs de son prédécesseur et de son successeur pour se retirer de la liste.
//!
//! Fondamentalement, nous devons pouvoir compter sur l'appel de [`drop`].Si un élément pouvait être désalloué ou autrement invalidé sans appeler [`drop`], les pointeurs qu'il contient à partir de ses éléments voisins deviendraient invalides, ce qui briserait la structure de données.
//!
//! Par conséquent, l'épinglage est également assorti d'une garantie liée à [`drop`].
//!
//! # `Drop` guarantee
//!
//! Le but de l'épinglage est de pouvoir s'appuyer sur le placement de certaines données en mémoire.
//! Pour que cela fonctionne, il n'y a pas que le déplacement des données;la désallocation, la réaffectation ou l'invalidation de la mémoire utilisée pour stocker les données est également restreinte.
//! Concrètement, pour les données épinglées, vous devez maintenir l'invariant que *sa mémoire ne sera pas invalidée ou réutilisée à partir du moment où elle est épinglée jusqu'au moment où [`drop`] est appelé*.Une fois que [`drop`] revient ou panics, la mémoire peut être réutilisée.
//!
//! La mémoire peut être "invalidated" par désallocation, mais aussi en remplaçant un [`Some(v)`] par [`None`], ou en appelant [`Vec::set_len`] à "kill" certains éléments d'un vector.Il peut être réutilisé en utilisant [`ptr::write`] pour l'écraser sans appeler le destructeur au préalable.Rien de tout cela n'est autorisé pour les données épinglées sans appeler [`drop`].
//!
//! C'est exactement le genre de garantie que la liste chaînée intrusive de la section précédente a besoin pour fonctionner correctement.
//!
//! Notez que cette garantie ne signifie *pas* que la mémoire ne fuit pas!Il est toujours tout à fait correct de ne jamais appeler [`drop`] sur un élément épinglé (par exemple, vous pouvez toujours appeler [`mem::forget`] sur un [`Pin`]`<`[`Box`] `<T>>`).Dans l'exemple de la liste à double lien, cet élément resterait simplement dans la liste.Cependant, vous ne pouvez pas libérer ou réutiliser le stockage *sans appeler [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Si votre type utilise l'épinglage (comme les deux exemples ci-dessus), vous devez être prudent lors de l'implémentation de [`Drop`].La fonction [`drop`] prend `&mut self`, mais cela s'appelle *même si votre type a été précédemment épinglé*!C'est comme si le compilateur appelait automatiquement [`Pin::get_unchecked_mut`].
//!
//! Cela ne peut jamais poser de problème dans le code sécurisé car l'implémentation d'un type qui repose sur l'épinglage nécessite un code non sécurisé, mais sachez que décider d'utiliser l'épinglage dans votre type (par exemple en implémentant une opération sur [`Pin`]`<&Self>`ou [`Pin`] `<&mut Self>`) a également des conséquences sur votre implémentation [`Drop`]: si un élément de votre type aurait pu être épinglé, vous devez traiter [`Drop`] comme prenant implicitement [`Pin`]`<&mut Soi>`.
//!
//!
//! Par exemple, vous pouvez implémenter `Drop` comme suit:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` est correct car nous savons que cette valeur n'est plus jamais utilisée après avoir été supprimée.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Le code de dépôt réel va ici.
//!         }
//!     }
//! }
//! ```
//!
//! La fonction `inner_drop` a le type que [`drop`]*devrait* avoir, ce qui garantit que vous n'utilisez pas accidentellement `self`/`this` d'une manière qui est en conflit avec l'épinglage.
//!
//! De plus, si votre type est `#[repr(packed)]`, le compilateur déplacera automatiquement les champs pour pouvoir les supprimer.Il pourrait même le faire pour des domaines qui se trouvent être suffisamment alignés.Par conséquent, vous ne pouvez pas utiliser l'épinglage avec un type `#[repr(packed)]`.
//!
//! # Projections et épinglage structurel
//!
//! Lorsque vous travaillez avec des structures épinglées, la question se pose de savoir comment accéder aux champs de cette structure dans une méthode qui ne prend que [`Pin`]`<&mut Struct>`.
//! L'approche habituelle est d'écrire des méthodes d'assistance (appelées *projections*) qui transforment [`Pin`]`<&mut Struct>`en une référence au champ, mais quel type devrait avoir cette référence?Est-ce [`Pin`]`<&mut Field>`ou `&mut Field`?
//! La même question se pose avec les champs d'un `enum`, et aussi lors de l'examen des types container/wrapper tels que [`Vec<T>`], [`Box<T>`] ou [`RefCell<T>`].
//! (Cette question s'applique à la fois aux références mutables et partagées, nous utilisons simplement le cas plus courant des références mutables ici à titre d'illustration.)
//!
//! Il s'avère que c'est en fait à l'auteur de la structure de données de décider si la projection épinglée pour un champ particulier transforme [`Pin`]`<&mut Struct>`en [`Pin`] `<&mut Field>` ou `&mut Field`.Il y a cependant quelques contraintes, et la contrainte la plus importante est la *cohérence*:
//! chaque champ peut être *soit* projeté sur une référence épinglée,*soit* avoir l'épinglage supprimé dans le cadre de la projection.
//! Si les deux sont faits pour le même champ, ce sera probablement malsain!
//!
//! En tant qu'auteur d'une structure de données, vous décidez pour chaque champ d'épingler "propagates" à ce champ ou non.
//! L'épinglage qui se propage est également appelé "structural", car il suit la structure du type.
//! Dans les sous-sections suivantes, nous décrivons les considérations qui doivent être prises pour l'un ou l'autre choix.
//!
//! ## L'épinglage *n'est pas* structurel pour `field`
//!
//! Il peut sembler contre-intuitif que le champ d'une structure épinglée ne soit pas épinglé, mais c'est en fait le choix le plus simple: si un [`Pin`]`<&mut Field>`n'est jamais créé, rien ne peut mal tourner!Ainsi, si vous décidez qu'un champ n'a pas d'épinglage structurel, tout ce que vous devez vous assurer est de ne jamais créer de référence épinglée à ce champ.
//!
//! Les champs sans épinglage structurel peuvent avoir une méthode de projection qui transforme [`Pin`]`<&mut Struct>`en `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Ce n'est pas grave car `field` n'est jamais considéré comme épinglé.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Vous pouvez également `impl Unpin for Struct`*même si* le type de `field` n'est pas [`Unpin`].Ce que ce type pense de l'épinglage n'est pas pertinent lorsqu'aucun [`Pin`]`<&mut Field>`n'est jamais créé.
//!
//! ## L'épinglage *est* structurel pour `field`
//!
//! L'autre option est de décider que l'épinglage est "structural" pour `field`, ce qui signifie que si la structure est épinglée, le champ l'est aussi.
//!
//! Cela permet d'écrire une projection qui crée un [`Pin`]`<&mut Field>`, témoignant ainsi que le champ est épinglé:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Ce n'est pas grave car `field` est épinglé lorsque `self` l'est.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Cependant, l'épinglage structurel comporte quelques exigences supplémentaires:
//!
//! 1. La structure ne doit être [`Unpin`] que si tous les champs structurels sont [`Unpin`].C'est la valeur par défaut, mais [`Unpin`] est un trait sûr, donc en tant qu'auteur de la structure, il est de votre responsabilité *pas* d'ajouter quelque chose comme `impl<T> Unpin for Struct<T>`.
//! (Notez que l'ajout d'une opération de projection nécessite un code non sécurisé, donc le fait que [`Unpin`] soit un trait sûr ne rompt pas le principe selon lequel vous n'avez à vous soucier de tout cela que si vous utilisez `unsafe`.)
//! 2. Le destructeur de la structure ne doit pas déplacer les champs structurels hors de son argument.C'est le point exact qui a été soulevé dans le [previous section][drop-impl]: `drop` prend `&mut self`, mais la structure (et donc ses champs) peut avoir été épinglée auparavant.
//!     Vous devez garantir que vous ne déplacez pas de champ dans votre implémentation [`Drop`].
//!     En particulier, comme expliqué précédemment, cela signifie que votre structure ne doit *pas* être `#[repr(packed)]`.
//!     Consultez cette section pour savoir comment écrire [`drop`] de manière à ce que le compilateur puisse vous aider à ne pas interrompre accidentellement l'épinglage.
//! 3. Vous devez vous assurer que vous respectez le [`Drop` guarantee][drop-guarantee]:
//!     une fois votre structure épinglée, la mémoire qui contient le contenu n'est pas écrasée ou désallouée sans appeler les destructeurs du contenu.
//!     Cela peut être délicat, comme en témoigne [`VecDeque<T>`]: le destructeur de [`VecDeque<T>`] peut échouer à appeler [`drop`] sur tous les éléments si l'un des destructeurs panics.Cela viole la garantie [`Drop`], car cela peut conduire à la désallocation d'éléments sans que leur destructeur ne soit appelé.([`VecDeque<T>`] n'a pas de projections d'épinglage, donc cela ne cause pas de dysfonctionnement.)
//! 4. Vous ne devez proposer aucune autre opération susceptible d'entraîner le déplacement de données hors des champs structurels lorsque votre type est épinglé.Par exemple, si la structure contient un [`Option<T>`] et qu'il y a une opération de type `take` avec le type `fn(Pin<&mut Struct<T>>) -> Option<T>`, cette opération peut être utilisée pour déplacer un `T` hors d'un `Struct<T>` épinglé-ce qui signifie que l'épinglage ne peut pas être structurel pour le champ contenant ce Les données.
//!
//!     Pour un exemple plus complexe de déplacement de données hors d'un type épinglé, imaginez si [`RefCell<T>`] avait une méthode `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Ensuite, nous pourrions faire ce qui suit:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     C'est catastrophique, cela signifie que nous pouvons d'abord épingler le contenu du [`RefCell<T>`] (en utilisant `RefCell::get_pin_mut`), puis déplacer ce contenu en utilisant la référence mutable que nous avons obtenue plus tard.
//!
//! ## Examples
//!
//! Pour un type comme [`Vec<T>`], les deux possibilités (épinglage structurel ou non) ont du sens.
//! Un [`Vec<T>`] avec épinglage structurel peut avoir des méthodes `get_pin`/`get_pin_mut` pour obtenir des références épinglées à des éléments.Cependant, il ne pouvait *pas* permettre d'appeler [`pop`][Vec::pop] sur un [`Vec<T>`] épinglé car cela déplacerait le contenu (structurellement épinglé)!Il ne pouvait pas non plus autoriser [`push`][Vec::push], qui pourrait réallouer et donc déplacer le contenu.
//!
//! Un [`Vec<T>`] sans épinglage structurel pourrait `impl<T> Unpin for Vec<T>`, car le contenu n'est jamais épinglé et le [`Vec<T>`] lui-même peut également être déplacé.
//! À ce stade, l'épinglage n'a aucun effet sur le vector.
//!
//! Dans la bibliothèque standard, les types de pointeurs n'ont généralement pas d'épinglage structurel et n'offrent donc pas de projections d'épinglage.C'est pourquoi `Box<T>: Unpin` est valable pour tous les `T`.
//! Il est logique de le faire pour les types de pointeurs, car déplacer le `Box<T>` ne déplace pas réellement le `T`: le [`Box<T>`] peut être librement déplaçable (alias `Unpin`) même si le `T` ne l'est pas.En fait, même [`Pin`]`<`[`Box`] `<T>>`et [`Pin`] `<&mut T>` sont toujours [`Unpin`] eux-mêmes, pour la même raison: leur contenu (le `T`) est épinglé, mais les pointeurs eux-mêmes peuvent être déplacés sans déplacer les données épinglées.
//! Pour [`Box<T>`] et [`Pin`]`<`[`Box`] `<T>>`, si le contenu est épinglé est entièrement indépendant du fait que le pointeur soit épinglé, ce qui signifie que l'épinglage n'est *pas* structurel.
//!
//! Lors de l'implémentation d'un combinateur [`Future`], vous aurez généralement besoin d'un épinglage structurel pour le futures imbriqué, car vous devez obtenir des références épinglées pour appeler [`poll`].
//! Mais si votre combinateur contient d'autres données qui n'ont pas besoin d'être épinglées, vous pouvez rendre ces champs non structurels et donc y accéder librement avec une référence mutable même si vous avez juste [`Pin`]`<&mut Self>`(tel comme dans votre propre implémentation [`poll`]).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Un pointeur épinglé.
///
/// Il s'agit d'un wrapper autour d'une sorte de pointeur qui fait de ce pointeur "pin" sa valeur en place, empêchant la valeur référencée par ce pointeur d'être déplacée à moins qu'elle n'implémente [`Unpin`].
///
///
/// *Consultez la documentation du [`pin` module] pour une explication de l'épinglage.*
///
/// [`pin` module]: self
///
// Note: le dérivé `Clone` ci-dessous cause des problèmes car il est possible de mettre en œuvre
// `Clone` pour les références mutables.
// Voir <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> pour plus de détails.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Les implémentations suivantes ne sont pas dérivées afin d'éviter les problèmes de solidité.
// `&self.pointer` ne doit pas être accessible aux implémentations trait non approuvées.
//
// Voir <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> pour plus de détails.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Construisez un nouveau `Pin<P>` autour d'un pointeur vers des données d'un type qui implémente [`Unpin`].
    ///
    /// Contrairement à `Pin::new_unchecked`, cette méthode est sûre car le pointeur `P` déréférence à un type [`Unpin`], ce qui annule les garanties d'épinglage.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // SÉCURITÉ: la valeur pointée est `Unpin`, et n'a donc aucune exigence
        // autour de l'épinglage.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Développe ce `Pin<P>` en retournant le pointeur sous-jacent.
    ///
    /// Cela nécessite que les données à l'intérieur de ce `Pin` soient [`Unpin`] afin que nous puissions ignorer les invariants d'épinglage lors du déballage.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Construisez un nouveau `Pin<P>` autour d'une référence à certaines données d'un type qui peut implémenter ou non `Unpin`.
    ///
    /// Si `pointer` déréférence à un type `Unpin`, `Pin::new` doit être utilisé à la place.
    ///
    /// # Safety
    ///
    /// Ce constructeur est dangereux car nous ne pouvons pas garantir que les données pointées par `pointer` sont épinglées, ce qui signifie que les données ne seront pas déplacées ou leur stockage invalidé jusqu'à ce qu'elles soient supprimées.
    /// Si le `Pin<P>` construit ne garantit pas que les données pointées par `P` sont épinglées, cela constitue une violation du contrat d'API et peut conduire à un comportement indéfini dans les opérations (safe) ultérieures.
    ///
    /// En utilisant cette méthode, vous créez un promise sur les implémentations `P::Deref` et `P::DerefMut`, si elles existent.
    /// Plus important encore, ils ne doivent pas sortir de leurs arguments `self`: `Pin::as_mut` et `Pin::as_ref` appelleront `DerefMut::deref_mut` et `Deref::deref`*sur le pointeur épinglé* et s'attendront à ce que ces méthodes respectent les invariants d'épinglage.
    /// De plus, en appelant cette méthode, vous promise que la référence `P` ne sera pas déplacée à nouveau;en particulier, il ne doit pas être possible d'obtenir un `&mut P::Target` puis de sortir de cette référence (en utilisant par exemple [`mem::swap`]).
    ///
    ///
    /// Par exemple, appeler `Pin::new_unchecked` sur un `&'a mut T` n'est pas sûr car, bien que vous puissiez l'épingler pour la durée de vie donnée `'a`, vous n'avez aucun contrôle sur le fait qu'il soit maintenu épinglé une fois que `'a` se termine:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Cela devrait signifier que la pointee `a` ne pourra plus jamais bouger.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // L'adresse de `a` a été changée en l'emplacement de pile de `b`, donc `a` a été déplacé même si nous l'avons précédemment épinglé!Nous avons violé le contrat de l'API d'épinglage.
    /////
    /// }
    /// ```
    ///
    /// Une valeur, une fois épinglée, doit rester épinglée pour toujours (sauf si son type implémente `Unpin`).
    ///
    /// De même, appeler `Pin::new_unchecked` sur un `Rc<T>` n'est pas sûr car il peut y avoir des alias vers les mêmes données qui ne sont pas soumis aux restrictions d'épinglage:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Cela devrait signifier que la pointee ne pourra plus jamais bouger.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Maintenant, si `x` était la seule référence, nous avons une référence mutable aux données que nous avons épinglées ci-dessus, que nous pourrions utiliser pour la déplacer comme nous l'avons vu dans l'exemple précédent.
    ///     // Nous avons violé le contrat de l'API d'épinglage.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Obtient une référence partagée épinglée à partir de ce pointeur épinglé.
    ///
    /// Il s'agit d'une méthode générique pour passer de `&Pin<Pointer<T>>` à `Pin<&T>`.
    /// C'est sûr car, dans le cadre du contrat de `Pin::new_unchecked`, la pointee ne peut pas bouger après la création de `Pin<Pointer<T>>`.
    ///
    /// "Malicious" les implémentations de `Pointer::Deref` sont également exclues par le contrat de `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // SÉCURITÉ: voir la documentation sur cette fonction
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Développe ce `Pin<P>` en retournant le pointeur sous-jacent.
    ///
    /// # Safety
    ///
    /// Cette fonction n'est pas sûre.Vous devez garantir que vous continuerez à traiter le pointeur `P` comme épinglé après avoir appelé cette fonction, afin que les invariants du type `Pin` puissent être maintenus.
    /// Si le code utilisant le `P` résultant ne continue pas à conserver les invariants d'épinglage, cela constitue une violation du contrat d'API et peut entraîner un comportement indéfini dans les opérations (safe) ultérieures.
    ///
    ///
    /// Si les données sous-jacentes sont [`Unpin`], [`Pin::into_inner`] doit être utilisé à la place.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Obtient une référence mutable épinglée à partir de ce pointeur épinglé.
    ///
    /// Il s'agit d'une méthode générique pour passer de `&mut Pin<Pointer<T>>` à `Pin<&mut T>`.
    /// C'est sûr car, dans le cadre du contrat de `Pin::new_unchecked`, la pointee ne peut pas bouger après la création de `Pin<Pointer<T>>`.
    ///
    /// "Malicious" les implémentations de `Pointer::DerefMut` sont également exclues par le contrat de `Pin::new_unchecked`.
    ///
    /// Cette méthode est utile lors de plusieurs appels à des fonctions qui utilisent le type épinglé.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // faire quelque chose
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` consomme `self`, donc réemprunter le `Pin<&mut Self>` via `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // SÉCURITÉ: voir la documentation sur cette fonction
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Attribue une nouvelle valeur à la mémoire derrière la référence épinglée.
    ///
    /// Cela écrase les données épinglées, mais ce n'est pas grave: son destructeur est exécuté avant d'être écrasé, donc aucune garantie d'épinglage n'est violée.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Construit une nouvelle broche en mappant la valeur intérieure.
    ///
    /// Par exemple, si vous souhaitez obtenir un `Pin` d'un champ de quelque chose, vous pouvez l'utiliser pour accéder à ce champ dans une ligne de code.
    /// Cependant, il y a plusieurs pièges avec ces "pinning projections";
    /// voir la documentation [`pin` module] pour plus de détails sur ce sujet.
    ///
    /// # Safety
    ///
    /// Cette fonction n'est pas sûre.
    /// Vous devez garantir que les données que vous renvoyez ne bougeront pas tant que la valeur de l'argument ne bougera pas (par exemple, parce que c'est l'un des champs de cette valeur), et aussi que vous ne sortez pas de l'argument que vous recevez. la fonction intérieure.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // SÉCURITÉ: le contrat de sécurité du `new_unchecked` doit être
        // confirmé par l'appelant.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Obtient une référence partagée à partir d'une épingle.
    ///
    /// Ceci est sûr car il n'est pas possible de sortir d'une référence partagée.
    /// Il peut sembler qu'il y a un problème ici avec la mutabilité intérieure: en fait, il *est* possible de déplacer un `T` hors d'un `&RefCell<T>`.
    /// Cependant, ce n'est pas un problème tant qu'il n'existe pas également de `Pin<&T>` pointant vers les mêmes données, et `RefCell<T>` ne vous permet pas de créer une référence épinglée à son contenu.
    ///
    /// Voir la discussion sur ["pinning projections"] pour plus de détails.
    ///
    /// Note: `Pin` implémente également `Deref` sur la cible, qui peut être utilisée pour accéder à la valeur interne.
    /// Cependant, `Deref` ne fournit qu'une référence qui dure aussi longtemps que l'emprunt du `Pin`, et non la durée de vie du `Pin` lui-même.
    /// Cette méthode permet de transformer le `Pin` en une référence avec la même durée de vie que le `Pin` d'origine.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Convertit ce `Pin<&mut T>` en un `Pin<&T>` avec la même durée de vie.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Obtient une référence mutable aux données à l'intérieur de ce `Pin`.
    ///
    /// Cela nécessite que les données à l'intérieur de ce `Pin` soient `Unpin`.
    ///
    /// Note: `Pin` implémente également `DerefMut` aux données, qui peuvent être utilisées pour accéder à la valeur interne.
    /// Cependant, `DerefMut` ne fournit qu'une référence qui dure aussi longtemps que l'emprunt du `Pin`, et non la durée de vie du `Pin` lui-même.
    ///
    /// Cette méthode permet de transformer le `Pin` en une référence avec la même durée de vie que le `Pin` d'origine.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Obtient une référence mutable aux données à l'intérieur de ce `Pin`.
    ///
    /// # Safety
    ///
    /// Cette fonction n'est pas sûre.
    /// Vous devez garantir que vous ne déplacerez jamais les données hors de la référence mutable que vous recevez lorsque vous appelez cette fonction, afin que les invariants du type `Pin` puissent être maintenus.
    ///
    ///
    /// Si les données sous-jacentes sont `Unpin`, `Pin::get_mut` doit être utilisé à la place.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Construisez une nouvelle épingle en mappant la valeur intérieure.
    ///
    /// Par exemple, si vous souhaitez obtenir un `Pin` d'un champ de quelque chose, vous pouvez l'utiliser pour accéder à ce champ dans une ligne de code.
    /// Cependant, il y a plusieurs pièges avec ces "pinning projections";
    /// voir la documentation [`pin` module] pour plus de détails sur ce sujet.
    ///
    /// # Safety
    ///
    /// Cette fonction n'est pas sûre.
    /// Vous devez garantir que les données que vous renvoyez ne bougeront pas tant que la valeur de l'argument ne bougera pas (par exemple, parce que c'est l'un des champs de cette valeur), et aussi que vous ne sortez pas de l'argument que vous recevez. la fonction intérieure.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // SÉCURITÉ: l'appelant est responsable de ne pas déplacer le
        // valeur hors de cette référence.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // SÉCURITÉ: car la valeur de `this` est garantie de ne pas avoir
        // été déplacé, cet appel à `new_unchecked` est sûr.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Obtenez une référence épinglée à partir d'une référence statique.
    ///
    /// C'est sûr, car `T` est emprunté pour la durée de vie du `'static`, qui ne se termine jamais.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // SÉCURITÉ: L'emprunt statique garantit que les données ne seront pas
        // moved/invalidated jusqu'à ce qu'il soit abandonné (ce qui n'est jamais).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Obtenez une référence mutable épinglée à partir d'une référence mutable statique.
    ///
    /// C'est sûr, car `T` est emprunté pour la durée de vie du `'static`, qui ne se termine jamais.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // SÉCURITÉ: L'emprunt statique garantit que les données ne seront pas
        // moved/invalidated jusqu'à ce qu'il soit abandonné (ce qui n'est jamais).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: cela signifie que toute implémentation de `CoerceUnsized` qui permet de contraindre
// un type qui implique `Deref<Target=impl !Unpin>` dans un type qui implique `Deref<Target=Unpin>` est défectueux.
// Un tel implément serait probablement défectueux pour d'autres raisons, cependant, nous devons juste faire attention à ne pas permettre à de tels impls d'atterrir dans std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}