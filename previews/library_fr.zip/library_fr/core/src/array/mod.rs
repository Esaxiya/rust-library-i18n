//! Implémentations de choses comme `Eq` pour des tableaux de longueur fixe jusqu'à une certaine longueur.
//! À terme, nous devrions pouvoir généraliser à toutes les longueurs.
//!
//! *[See also the array primitive type](array).*
//!

#![stable(feature = "core_array", since = "1.36.0")]

use crate::borrow::{Borrow, BorrowMut};
use crate::cmp::Ordering;
use crate::convert::{Infallible, TryFrom};
use crate::fmt;
use crate::hash::{self, Hash};
use crate::iter::TrustedLen;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{Index, IndexMut};
use crate::slice::{Iter, IterMut};

mod iter;

#[stable(feature = "array_value_iter", since = "1.51.0")]
pub use iter::IntoIter;

/// Convertit une référence à `T` en une référence à un tableau de longueur 1 (sans copie).
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_ref<T>(s: &T) -> &[T; 1] {
    // SÉCURITÉ: La conversion de `&T` en `&[T; 1]` est saine.
    unsafe { &*(s as *const T).cast::<[T; 1]>() }
}

/// Convertit une référence mutable à `T` en une référence mutable à un tableau de longueur 1 (sans copie).
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_mut<T>(s: &mut T) -> &mut [T; 1] {
    // SÉCURITÉ: La conversion de `&mut T` en `&mut [T; 1]` est saine.
    unsafe { &mut *(s as *mut T).cast::<[T; 1]>() }
}

/// Utilitaire trait implémenté uniquement sur des tableaux de taille fixe
///
/// Ce trait peut être utilisé pour implémenter d'autres traits sur des tableaux de taille fixe sans causer beaucoup de gonflement des métadonnées.
///
/// Le trait est marqué comme dangereux afin de restreindre les implémenteurs à des tableaux de taille fixe.
/// Un utilisateur de ce trait peut supposer que les implémenteurs ont la disposition exacte en mémoire d'un tableau de taille fixe (par exemple, pour une initialisation non sécurisée).
///
///
/// Notez que les traits [`AsRef`] et [`AsMut`] fournissent des méthodes similaires pour les types qui peuvent ne pas être des tableaux de taille fixe.
/// Les développeurs devraient préférer ces traits à la place.
///
///
///
#[unstable(feature = "fixed_size_array", issue = "27778")]
pub unsafe trait FixedSizeArray<T> {
    /// Convertit le tableau en tranche immuable
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_slice(&self) -> &[T];
    /// Convertit le tableau en tranche mutable
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_mut_slice(&mut self) -> &mut [T];
}

#[unstable(feature = "fixed_size_array", issue = "27778")]
unsafe impl<T, A: Unsize<[T]>> FixedSizeArray<T> for A {
    #[inline]
    fn as_slice(&self) -> &[T] {
        self
    }
    #[inline]
    fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }
}

/// Le type d'erreur renvoyé lorsqu'une conversion d'une tranche à un tableau échoue.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone)]
pub struct TryFromSliceError(());

#[stable(feature = "core_array", since = "1.36.0")]
impl fmt::Display for TryFromSliceError {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self.__description(), f)
    }
}

impl TryFromSliceError {
    #[unstable(
        feature = "array_error_internals",
        reason = "available through Error trait and this method should not \
                     be exposed publicly",
        issue = "none"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "could not convert slice to array"
    }
}

#[stable(feature = "try_from_slice_error", since = "1.36.0")]
impl From<Infallible> for TryFromSliceError {
    fn from(x: Infallible) -> TryFromSliceError {
        match x {}
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsRef<[T]> for [T; N] {
    #[inline]
    fn as_ref(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsMut<[T]> for [T; N] {
    #[inline]
    fn as_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> Borrow<[T]> for [T; N] {
    fn borrow(&self) -> &[T] {
        self
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> BorrowMut<[T]> for [T; N] {
    fn borrow_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<T, const N: usize> TryFrom<&[T]> for [T; N]
where
    T: Copy,
{
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<[T; N], TryFromSliceError> {
        <&Self>::try_from(slice).map(|r| *r)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a [T]> for &'a [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<&[T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_ptr() as *const [T; N];
            // SÉCURITÉ: ok car nous venons de vérifier que la longueur correspond
            unsafe { Ok(&*ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a mut [T]> for &'a mut [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &mut [T]) -> Result<&mut [T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_mut_ptr() as *mut [T; N];
            // SÉCURITÉ: ok car nous venons de vérifier que la longueur correspond
            unsafe { Ok(&mut *ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, const N: usize> Hash for [T; N] {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        Hash::hash(&self[..], state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for [T; N] {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&&self[..], f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a [T; N] {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a mut [T; N] {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> Index<I> for [T; N]
where
    [T]: Index<I>,
{
    type Output = <[T] as Index<I>>::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(self as &[T], index)
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> IndexMut<I> for [T; N]
where
    [T]: IndexMut<I>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(self as &mut [T], index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B; N]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &[B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&mut [B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&mut [B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&mut [B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &mut [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

// NOTE: certains impls moins importants sont omis pour réduire le gonflement du code
// __impl_slice_eq2!{ [A; $N], &'b [B; $N] } __impl_slice_eq2! { [A; $N], &'b mut [B; $N] }
//

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, const N: usize> Eq for [T; N] {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, const N: usize> PartialOrd for [T; N] {
    #[inline]
    fn partial_cmp(&self, other: &[T; N]) -> Option<Ordering> {
        PartialOrd::partial_cmp(&&self[..], &&other[..])
    }
    #[inline]
    fn lt(&self, other: &[T; N]) -> bool {
        PartialOrd::lt(&&self[..], &&other[..])
    }
    #[inline]
    fn le(&self, other: &[T; N]) -> bool {
        PartialOrd::le(&&self[..], &&other[..])
    }
    #[inline]
    fn ge(&self, other: &[T; N]) -> bool {
        PartialOrd::ge(&&self[..], &&other[..])
    }
    #[inline]
    fn gt(&self, other: &[T; N]) -> bool {
        PartialOrd::gt(&&self[..], &&other[..])
    }
}

/// Implémente la comparaison des tableaux [lexicographically](Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, const N: usize> Ord for [T; N] {
    #[inline]
    fn cmp(&self, other: &[T; N]) -> Ordering {
        Ord::cmp(&&self[..], &&other[..])
    }
}

// Les impls par défaut ne peuvent pas être effectués avec des génériques const car `[T; 0]` ne nécessite pas l'implémentation de Default et le fait d'avoir différents blocs d'impl pour différents nombres n'est pas encore pris en charge.
//
//

macro_rules! array_impl_default {
    {$n:expr, $t:ident $($ts:ident)*} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] where T: Default {
            fn default() -> [T; $n] {
                [$t::default(), $($ts::default()),*]
            }
        }
        array_impl_default!{($n - 1), $($ts)*}
    };
    {$n:expr,} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] {
            fn default() -> [T; $n] { [] }
        }
    };
}

array_impl_default! {32, T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T}

#[lang = "array"]
impl<T, const N: usize> [T; N] {
    /// Renvoie un tableau de la même taille que `self`, avec la fonction `f` appliquée à chaque élément dans l'ordre.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_map)]
    /// let x = [1, 2, 3];
    /// let y = x.map(|v| v + 1);
    /// assert_eq!(y, [2, 3, 4]);
    ///
    /// let x = [1, 2, 3];
    /// let mut temp = 0;
    /// let y = x.map(|v| { temp += 1; v * temp });
    /// assert_eq!(y, [1, 4, 9]);
    ///
    /// let x = ["Ferris", "Bueller's", "Day", "Off"];
    /// let y = x.map(|v| v.len());
    /// assert_eq!(y, [6, 9, 3, 3]);
    /// ```
    #[unstable(feature = "array_map", issue = "75243")]
    pub fn map<F, U>(self, f: F) -> [U; N]
    where
        F: FnMut(T) -> U,
    {
        // SÉCURITÉ: nous savons avec certitude que cet itérateur donnera exactement `N`
        // items.
        unsafe { collect_into_array_unchecked(&mut IntoIter::new(self).map(f)) }
    }

    /// «Zippe» deux tableaux en un seul tableau de paires.
    ///
    /// `zip()` renvoie un nouveau tableau où chaque élément est un tuple où le premier élément provient du premier tableau et le deuxième élément du deuxième tableau.
    ///
    /// En d'autres termes, il zippe deux tableaux ensemble, en un seul.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_zip)]
    /// let x = [1, 2, 3];
    /// let y = [4, 5, 6];
    /// let z = x.zip(y);
    /// assert_eq!(z, [(1, 4), (2, 5), (3, 6)]);
    /// ```
    ///
    #[unstable(feature = "array_zip", issue = "80094")]
    pub fn zip<U>(self, rhs: [U; N]) -> [(T, U); N] {
        let mut iter = IntoIter::new(self).zip(IntoIter::new(rhs));

        // SÉCURITÉ: nous savons avec certitude que cet itérateur donnera exactement `N`
        // items.
        unsafe { collect_into_array_unchecked(&mut iter) }
    }

    /// Renvoie une tranche contenant le tableau entier.Équivalent à `&s[..]`.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Renvoie une tranche modifiable contenant le tableau entier.
    /// Équivalent à `&mut s[..]`.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Emprunte chaque élément et renvoie un tableau de références de même taille que `self`.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&f64; 3] = floats.each_ref();
    /// assert_eq!(float_refs, [&3.1, &2.7, &-1.0]);
    /// ```
    ///
    /// Cette méthode est particulièrement utile si elle est combinée avec d'autres méthodes, comme [`map`](#method.map).
    /// De cette façon, vous pouvez éviter de déplacer le tableau d'origine si ses éléments ne sont pas `Copy`.
    ///
    /// ```
    /// #![feature(array_methods, array_map)]
    ///
    /// let strings = ["Ferris".to_string(), "♥".to_string(), "Rust".to_string()];
    /// let is_ascii = strings.each_ref().map(|s| s.is_ascii());
    /// assert_eq!(is_ascii, [true, false, true]);
    ///
    /// // On peut toujours accéder au tableau d'origine: il n'a pas été déplacé.
    /// assert_eq!(strings.len(), 3);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_ref(&self) -> [&T; N] {
        // SÉCURITÉ: nous savons avec certitude que cet itérateur donnera exactement `N`
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter()) }
    }

    /// Emprunte chaque élément mutuellement et renvoie un tableau de références mutables de la même taille que `self`.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let mut floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&mut f64; 3] = floats.each_mut();
    /// *float_refs[0] = 0.0;
    /// assert_eq!(float_refs, [&mut 0.0, &mut 2.7, &mut -1.0]);
    /// assert_eq!(floats, [0.0, 2.7, -1.0]);
    /// ```
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_mut(&mut self) -> [&mut T; N] {
        // SÉCURITÉ: nous savons avec certitude que cet itérateur donnera exactement `N`
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter_mut()) }
    }
}

/// Extrait les éléments `N` de `iter` et les renvoie sous forme de tableau.
/// Si l'itérateur produit moins de `N` éléments, cette fonction présente un comportement indéfini.
///
///
/// Voir [`collect_into_array`] pour plus d'informations.
///
/// # Safety
///
/// Il appartient à l'appelant de garantir que `iter` produit au moins `N` articles.
/// Le non-respect de cette condition entraîne un comportement indéfini.
unsafe fn collect_into_array_unchecked<I, const N: usize>(iter: &mut I) -> [I::Item; N]
where
    // Note: `TrustedLen` ici est en quelque sorte une expérience.C'est juste un
    // fonction interne, alors n'hésitez pas à supprimer si cette borne s'avère être une mauvaise idée.
    // Dans ce cas, n'oubliez pas de supprimer également la limite inférieure `debug_assert!` ci-dessous!
    //
    I: Iterator + TrustedLen,
{
    debug_assert!(N <= iter.size_hint().1.unwrap_or(usize::MAX));
    debug_assert!(N <= iter.size_hint().0);

    match collect_into_array(iter) {
        Some(array) => array,
        // SÉCURITÉ: couvert par le contrat de fonction.
        None => unsafe { crate::hint::unreachable_unchecked() },
    }
}

/// Extrait les éléments `N` de `iter` et les renvoie sous forme de tableau.Si l'itérateur produit moins d'éléments `N`, `None` est renvoyé et tous les éléments déjà générés sont supprimés.
///
/// Étant donné que l'itérateur est passé en tant que référence mutable et que cette fonction appelle `next` au plus `N` fois, l'itérateur peut toujours être utilisé par la suite pour récupérer les éléments restants.
///
///
/// Si `iter.next()` panique, tous les éléments déjà générés par l'itérateur sont supprimés.
///
///
///
///
fn collect_into_array<I, const N: usize>(iter: &mut I) -> Option<[I::Item; N]>
where
    I: Iterator,
{
    if N == 0 {
        // SÉCURITÉ: un tableau vide est toujours habité et n'a aucun invariant de validité.
        return unsafe { Some(mem::zeroed()) };
    }

    struct Guard<T, const N: usize> {
        ptr: *mut T,
        initialized: usize,
    }

    impl<T, const N: usize> Drop for Guard<T, N> {
        fn drop(&mut self) {
            debug_assert!(self.initialized <= N);

            let initialized_part = crate::ptr::slice_from_raw_parts_mut(self.ptr, self.initialized);

            // SÉCURITÉ: cette tranche brute ne contiendra que des objets initialisés.
            unsafe {
                crate::ptr::drop_in_place(initialized_part);
            }
        }
    }

    let mut array = MaybeUninit::uninit_array::<N>();
    let mut guard: Guard<_, N> =
        Guard { ptr: MaybeUninit::slice_as_mut_ptr(&mut array), initialized: 0 };

    while let Some(item) = iter.next() {
        // SÉCURITÉ: `guard.initialized` commence à 0, est augmenté de un dans le
        // boucle et la boucle est abandonnée une fois qu'elle atteint N (qui est `array.len()`).
        //
        unsafe {
            array.get_unchecked_mut(guard.initialized).write(item);
        }
        guard.initialized += 1;

        // Vérifiez si l'ensemble de la baie a été initialisé.
        if guard.initialized == N {
            mem::forget(guard);

            // SÉCURITÉ: la condition ci-dessus affirme que tous les éléments sont
            // initialized.
            let out = unsafe { MaybeUninit::array_assume_init(array) };
            return Some(out);
        }
    }

    // Ceci n'est atteint que si l'itérateur est épuisé avant que `guard.initialized` n'atteigne `N`.
    //
    // Notez également que `guard` est déposé ici, supprimant tous les éléments déjà initialisés.
    None
}