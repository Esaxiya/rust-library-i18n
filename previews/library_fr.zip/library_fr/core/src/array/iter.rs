//! Définit l'itérateur appartenant à `IntoIter` pour les tableaux.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Un itérateur [array] par valeur.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// C'est le tableau sur lequel nous itérons.
    ///
    /// Les éléments avec l'index `i` où `alive.start <= i < alive.end` n'ont pas encore été générés et sont des entrées de tableau valides.
    /// Les éléments avec les indices `i < alive.start` ou `i >= alive.end` ont déjà été générés et ne doivent plus être accédés!Ces éléments morts pourraient même être dans un état complètement non initialisé!
    ///
    ///
    /// Les invariants sont donc:
    /// - `data[alive]` est vivant (c'est-à-dire contient des éléments valides)
    /// - `data[..alive.start]` et `data[alive.end..]` sont morts (c'est-à-dire que les éléments ont déjà été lus et ne doivent plus être touchés!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Les éléments de `data` qui n'ont pas encore été cédés.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Crée un nouvel itérateur sur le `array` donné.
    ///
    /// *Remarque*: cette méthode peut être obsolète dans le future, après [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Le type de `value` est un `i32` ici, au lieu de `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // SÉCURITÉ: La transmutation ici est en fait sûre.La documentation de `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` est garanti d'avoir la même taille et le même alignement
        // > comme `T`.
        //
        // Les documents montrent même une transmutation d'un tableau de `MaybeUninit<T>` à un tableau de `T`.
        //
        //
        // Avec cela, cette initialisation satisfait les invariants.

        // FIXME(LukasKalbertodt): utilisez en fait `mem::transmute` ici, une fois que cela fonctionne avec les génériques const:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Jusque-là, nous pouvons utiliser `mem::transmute_copy` pour créer une copie au niveau du bit comme un type différent, puis oublier `array` pour qu'il ne soit pas supprimé.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Renvoie une tranche immuable de tous les éléments qui n'ont pas encore été générés.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // SÉCURITÉ: Nous savons que tous les éléments de `alive` sont correctement initialisés.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Renvoie une tranche modifiable de tous les éléments qui n'ont pas encore été générés.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // SÉCURITÉ: Nous savons que tous les éléments de `alive` sont correctement initialisés.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Obtenez l'index suivant de l'avant.
        //
        // L'augmentation de `alive.start` de 1 maintient l'invariant concernant `alive`.
        // Cependant, en raison de ce changement, pendant une courte période, la zone active n'est plus `data[alive]`, mais `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Lisez l'élément du tableau.
            // SÉCURITÉ: `idx` est un index dans l'ancienne région "alive" du
            // déployer.La lecture de cet élément signifie que `data[idx]` est maintenant considéré comme mort (c'est-à-dire ne pas toucher).
            // Comme `idx` était le début de la zone vivante, la zone vivante est maintenant à nouveau `data[alive]`, restaurant tous les invariants.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Obtenez le prochain index de l'arrière.
        //
        // La diminution de `alive.end` de 1 maintient l'invariant par rapport à `alive`.
        // Cependant, en raison de ce changement, pendant une courte période, la zone active n'est plus `data[alive]`, mais `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Lisez l'élément du tableau.
            // SÉCURITÉ: `idx` est un index dans l'ancienne région "alive" du
            // déployer.La lecture de cet élément signifie que `data[idx]` est maintenant considéré comme mort (c'est-à-dire ne pas toucher).
            // Comme `idx` était la fin de la zone vivante, la zone vivante est maintenant à nouveau `data[alive]`, restaurant tous les invariants.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // SÉCURITÉ: c'est sûr: `as_mut_slice` renvoie exactement la sous-tranche
        // d'éléments qui n'ont pas encore été déplacés et qui doivent encore l'être.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Ne débordera jamais en raison de l'invariant `alive.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// L'itérateur rapporte en effet la longueur correcte.
// Le nombre d'éléments "alive" (qui seront toujours générés) est la longueur de la plage `alive`.
// Cette plage est décrémentée en longueur dans `next` ou `next_back`.
// Il est toujours décrémenté de 1 dans ces méthodes, mais uniquement si `Some(_)` est renvoyé.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Notez que nous n'avons pas vraiment besoin de faire correspondre exactement la même plage active, nous pouvons donc simplement cloner dans l'offset 0, quel que soit l'endroit où se trouve `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Clonez tous les éléments vivants.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Écrivez un clone dans le nouveau tableau, puis mettez à jour sa plage active.
            // Si vous clonez panics, nous supprimerons correctement les éléments précédents.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // N'imprimez que les éléments qui n'ont pas encore été générés: nous ne pouvons plus accéder aux éléments générés.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}