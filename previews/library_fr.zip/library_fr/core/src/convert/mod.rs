//! Traits pour les conversions entre les types.
//!
//! Le traits dans ce module fournit un moyen de convertir d'un type à un autre type.
//! Chaque trait a un objectif différent:
//!
//! - Implémentez le [`AsRef`] trait pour des conversions de référence à référence bon marché
//! - Implémentez le [`AsMut`] trait pour des conversions mutables à mutables bon marché
//! - Implémentez le [`From`] trait pour consommer des conversions de valeur en valeur
//! - Implémentez le [`Into`] trait pour consommer des conversions de valeur en valeur vers des types en dehors du crate actuel
//! - Les [`TryFrom`] et [`TryInto`] traits se comportent comme [`From`] et [`Into`], mais doivent être implémentés lorsque la conversion peut échouer.
//!
//! Les traits dans ce module sont souvent utilisés comme trait bounds pour des fonctions génériques telles que les arguments de plusieurs types sont pris en charge.Voir la documentation de chaque trait pour des exemples.
//!
//! En tant qu'auteur de bibliothèque, vous devriez toujours préférer implémenter [`From<T>`][`From`] ou [`TryFrom<T>`][`TryFrom`] plutôt que [`Into<U>`][`Into`] ou [`TryInto<U>`][`TryInto`], car [`From`] et [`TryFrom`] offrent une plus grande flexibilité et offrent des implémentations équivalentes [`Into`] ou [`TryInto`] gratuitement, grâce à une implémentation globale dans la bibliothèque standard.
//! Lors du ciblage d'une version antérieure à Rust 1.41, il peut être nécessaire d'implémenter directement [`Into`] ou [`TryInto`] lors de la conversion vers un type en dehors du crate actuel.
//!
//! # Implémentations génériques
//!
//! - [`AsRef`] et [`AsMut`] auto-déréférencement si le type interne est une référence
//! - [`From`]`<U>for T` implique [`Into`]`</u><T><U>pour U`</u>
//! - [`TryFrom`]`<U>pour T` implique [`TryInto`]`</u><T><U>pour U`</u>
//! - [`From`] et [`Into`] sont réflexifs, ce qui signifie que tous les types peuvent `into` eux-mêmes et `from` eux-mêmes
//!
//! Voir chaque trait pour des exemples d'utilisation.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// La fonction d'identité.
///
/// Deux choses sont importantes à noter à propos de cette fonction:
///
/// - Ce n'est pas toujours équivalent à une fermeture comme `|x| x`, car la fermeture peut contraindre `x` à un type différent.
///
/// - Il déplace l'entrée `x` passée à la fonction.
///
/// Bien qu'il puisse sembler étrange d'avoir une fonction qui renvoie simplement l'entrée, il y a des utilisations intéressantes.
///
///
/// # Examples
///
/// Utiliser `identity` pour ne rien faire dans une séquence d'autres fonctions intéressantes:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Supposons que l'ajout d'un est une fonction intéressante.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Utilisation de `identity` comme cas de base "do nothing" dans un conditionnel:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Faites des choses plus intéressantes ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Utilisation de `identity` pour conserver les variantes `Some` d'un itérateur de `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Utilisé pour effectuer une conversion de référence en référence bon marché.
///
/// Ce trait est similaire à [`AsMut`] qui est utilisé pour la conversion entre des références mutables.
/// Si vous devez effectuer une conversion coûteuse, il est préférable d'implémenter [`From`] avec le type `&T` ou d'écrire une fonction personnalisée.
///
/// `AsRef` a la même signature que [`Borrow`], mais [`Borrow`] est différent à certains égards:
///
/// - Contrairement à `AsRef`, [`Borrow`] a une couverture impl pour tout `T`, et peut être utilisé pour accepter une référence ou une valeur.
/// - [`Borrow`] exige également que [`Hash`], [`Eq`] et [`Ord`] pour la valeur empruntée soient équivalents à ceux de la valeur détenue.
/// Pour cette raison, si vous ne souhaitez emprunter qu'un seul champ d'une structure, vous pouvez implémenter `AsRef`, mais pas [`Borrow`].
///
/// **Note: Ce trait ne doit pas échouer **.Si la conversion peut échouer, utilisez une méthode dédiée qui renvoie un [`Option<T>`] ou un [`Result<T, E>`].
///
/// # Implémentations génériques
///
/// - `AsRef` auto-déréférences si le type interne est une référence ou une référence mutable (par exemple: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// En utilisant trait bounds, nous pouvons accepter des arguments de types différents tant qu'ils peuvent être convertis dans le type spécifié `T`.
///
/// Par exemple: en créant une fonction générique qui prend un `AsRef<str>`, nous exprimons que nous voulons accepter toutes les références qui peuvent être converties en [`&str`] comme argument.
/// Puisque [`String`] et [`&str`] implémentent `AsRef<str>`, nous pouvons accepter les deux comme argument d'entrée.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Effectue la conversion.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Utilisé pour effectuer une conversion de référence mutable à mutable bon marché.
///
/// Ce trait est similaire à [`AsRef`] mais utilisé pour la conversion entre des références mutables.
/// Si vous devez effectuer une conversion coûteuse, il est préférable d'implémenter [`From`] avec le type `&mut T` ou d'écrire une fonction personnalisée.
///
/// **Note: Ce trait ne doit pas échouer **.Si la conversion peut échouer, utilisez une méthode dédiée qui renvoie un [`Option<T>`] ou un [`Result<T, E>`].
///
/// # Implémentations génériques
///
/// - `AsMut` auto-déréférences si le type interne est une référence mutable (par exemple: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// En utilisant `AsMut` comme trait bound pour une fonction générique, nous pouvons accepter toutes les références mutables qui peuvent être converties en type `&mut T`.
/// Parce que [`Box<T>`] implémente `AsMut<T>`, nous pouvons écrire une fonction `add_one` qui prend tous les arguments qui peuvent être convertis en `&mut u64`.
/// Étant donné que [`Box<T>`] implémente `AsMut<T>`, `add_one` accepte également les arguments de type `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Effectue la conversion.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Une conversion de valeur en valeur qui consomme la valeur d'entrée.Le contraire de [`From`].
///
/// Il faut éviter d'implémenter [`Into`] et implémenter [`From`] à la place.
/// L'implémentation de [`From`] fournit automatiquement une implémentation de [`Into`] grâce à l'implémentation globale dans la bibliothèque standard.
///
/// Préférez utiliser [`Into`] plutôt que [`From`] lorsque vous spécifiez trait bounds sur une fonction générique pour vous assurer que les types qui implémentent uniquement [`Into`] peuvent également être utilisés.
///
/// **Note: Ce trait ne doit pas échouer **.Si la conversion échoue, utilisez [`TryInto`].
///
/// # Implémentations génériques
///
/// - [`De`]`<T>pour U` implique `Into<U> for T`
/// - [`Into`] est réflexif, ce qui signifie que `Into<T> for T` est implémenté
///
/// # Implémentation de [`Into`] pour les conversions en types externes dans les anciennes versions de Rust
///
/// Avant Rust 1.41, si le type de destination ne faisait pas partie du crate actuel, vous ne pouviez pas implémenter directement [`From`].
/// Par exemple, prenez ce code:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// La compilation échouera dans les anciennes versions du langage car les règles orphelines de Rust étaient un peu plus strictes.
/// Pour contourner cela, vous pouvez implémenter directement [`Into`]:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Il est important de comprendre que [`Into`] ne fournit pas d'implémentation [`From`] (comme [`From`] le fait avec [`Into`]).
/// Par conséquent, vous devez toujours essayer d'implémenter [`From`], puis revenir à [`Into`] si [`From`] ne peut pas être implémenté.
///
/// # Examples
///
/// [`String`] implémente [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Afin d'exprimer que nous voulons qu'une fonction générique prenne tous les arguments qui peuvent être convertis en un type spécifié `T`, nous pouvons utiliser un trait bound de [`Into`]`<T>».
///
/// Par exemple: La fonction `is_hello` prend tous les arguments qui peuvent être convertis en un [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Effectue la conversion.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Utilisé pour effectuer des conversions de valeur en valeur tout en consommant la valeur d'entrée.C'est l'inverse de [`Into`].
///
/// Il faut toujours préférer implémenter `From` sur [`Into`] car l'implémentation de `From` fournit automatiquement une implémentation de [`Into`] grâce à l'implémentation globale dans la bibliothèque standard.
///
///
/// N'implémentez [`Into`] que lorsque vous ciblez une version antérieure à Rust 1.41 et que vous la convertissez en un type en dehors du crate actuel.
/// `From` n'a pas pu effectuer ces types de conversions dans les versions antérieures en raison des règles orphelines de Rust.
/// Voir [`Into`] pour plus de détails.
///
/// Préférez utiliser [`Into`] plutôt que `From` lorsque vous spécifiez trait bounds sur une fonction générique.
/// De cette façon, les types qui implémentent directement [`Into`] peuvent également être utilisés comme arguments.
///
/// Le `From` est également très utile lors de la gestion des erreurs.Lors de la construction d'une fonction susceptible d'échouer, le type de retour sera généralement de la forme `Result<T, E>`.
/// Le `From` trait simplifie la gestion des erreurs en permettant à une fonction de renvoyer un seul type d'erreur qui encapsule plusieurs types d'erreur.Voir la section "Examples" et [the book][book] pour plus de détails.
///
/// **Note: Ce trait ne doit pas échouer **.Si la conversion échoue, utilisez [`TryFrom`].
///
/// # Implémentations génériques
///
/// - `From<T> for U` implique [`Into`]`<U>pour T`</u>
/// - `From` est réflexif, ce qui signifie que `From<T> for T` est implémenté
///
/// # Examples
///
/// [`String`] implémente `From<&str>`:
///
/// Une conversion explicite d'un `&str` en une chaîne se fait comme suit:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Lors de la gestion des erreurs, il est souvent utile d'implémenter `From` pour votre propre type d'erreur.
/// En convertissant les types d'erreur sous-jacents en notre propre type d'erreur personnalisé qui encapsule le type d'erreur sous-jacent, nous pouvons renvoyer un seul type d'erreur sans perdre d'informations sur la cause sous-jacente.
/// L'opérateur '?' convertit automatiquement le type d'erreur sous-jacent en notre type d'erreur personnalisé en appelant `Into<CliError>::into` qui est automatiquement fourni lors de l'implémentation de `From`.
/// Le compilateur déduit ensuite quelle implémentation de `Into` doit être utilisée.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Effectue la conversion.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Une tentative de conversion qui consomme `self`, qui peut être coûteuse ou non.
///
/// Les auteurs de bibliothèques ne devraient généralement pas implémenter directement ce trait, mais devraient préférer implémenter le [`TryFrom`] trait, qui offre une plus grande flexibilité et fournit une implémentation `TryInto` équivalente gratuitement, grâce à une implémentation globale dans la bibliothèque standard.
/// Pour plus d'informations à ce sujet, consultez la documentation de [`Into`].
///
/// # Implémentation de `TryInto`
///
/// Cela souffre des mêmes restrictions et du même raisonnement que la mise en œuvre de [`Into`], voir ici pour plus de détails.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Le type renvoyé en cas d'erreur de conversion.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Effectue la conversion.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Conversions de type simples et sûres qui peuvent échouer de manière contrôlée dans certaines circonstances.C'est l'inverse de [`TryInto`].
///
/// Ceci est utile lorsque vous effectuez une conversion de type qui peut réussir de manière triviale mais qui peut également nécessiter un traitement spécial.
/// Par exemple, il n'y a aucun moyen de convertir un [`i64`] en [`i32`] en utilisant le [`From`] trait, car un [`i64`] peut contenir une valeur qu'un [`i32`] ne peut pas représenter et ainsi la conversion perdrait des données.
///
/// Cela peut être géré en tronquant le [`i64`] en [`i32`] (donnant essentiellement la valeur modulo [`i32::MAX`] du [`i64`]] ou en renvoyant simplement [`i32::MAX`], ou par une autre méthode.
/// Le [`From`] trait est destiné à des conversions parfaites, donc le `TryFrom` trait informe le programmeur lorsqu'une conversion de type peut mal tourner et lui permet de décider comment la gérer.
///
/// # Implémentations génériques
///
/// - `TryFrom<T> for U` implique [`TryInto`]`<U>pour T`</u>
/// - [`try_from`] est réflexif, ce qui signifie que `TryFrom<T> for T` est implémenté et ne peut pas échouer-le type `Error` associé pour appeler `T::try_from()` sur une valeur de type `T` est [`Infallible`].
/// Lorsque le type [`!`] est stabilisé, [`Infallible`] et [`!`] seront équivalents.
///
/// `TryFrom<T>` peut être implémenté comme suit:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Comme décrit, [`i32`] implémente `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Tronque silencieusement `big_number`, nécessite la détection et la gestion de la troncature après coup.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Renvoie une erreur car `big_number` est trop grand pour tenir dans un `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Renvoie `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Le type renvoyé en cas d'erreur de conversion.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Effectue la conversion.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS GÉNÉRIQUES
////////////////////////////////////////////////////////////////////////////////

// Alors que se soulève et
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Comme monte sur &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): remplacez les impls ci-dessus pour&/&mut par le suivant plus général:
// // Comme soulève Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Sized> AsRef <U>pour D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut passe au-dessus du &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): remplacez l'impl ci-dessus pour &mut par le suivant plus général:
// // AsMut soulève DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Sized> AsMut <U>pour D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// De implique en
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// De (et donc en) est réflexif
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Note de stabilité:** Cet impl n'existe pas encore, mais nous sommes "reserving space" pour l'ajouter dans le future.
/// Voir [rust-lang/rust#64715][#64715] pour plus de détails.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): faites plutôt une solution de principe.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom implique TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Les conversions infaillibles sont sémantiquement équivalentes aux conversions faillibles avec un type d'erreur inhabité.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS EN BÉTON
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// LE TYPE D'ERREUR SANS ERREUR
////////////////////////////////////////////////////////////////////////////////

/// Le type d'erreur pour les erreurs qui ne peuvent jamais se produire.
///
/// Étant donné que cette énumération n'a pas de variante, une valeur de ce type ne peut jamais exister.
/// Cela peut être utile pour les API génériques qui utilisent [`Result`] et paramétrent le type d'erreur, pour indiquer que le résultat est toujours [`Ok`].
///
/// Par exemple, le [`TryFrom`] trait (conversion qui renvoie un [`Result`]) a une implémentation générale pour tous les types où une implémentation [`Into`] inversée existe.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Compatibilité Future
///
/// Cette énumération a le même rôle que [the `!`“never”type][never], qui est instable dans cette version de Rust.
/// Lorsque `!` est stabilisé, nous prévoyons de faire de `Infallible` un alias de type:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Et finalement désapprouver `Infallible`.
///
/// Cependant, il existe un cas où la syntaxe `!` peut être utilisée avant que `!` ne soit stabilisé en tant que type à part entière: à la position du type de retour d'une fonction.
/// Plus précisément, il est possible d'implémenter deux types de pointeurs de fonction différents:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Avec `Infallible` étant une énumération, ce code est valide.
/// Cependant, lorsque `Infallible` devient un alias pour le never type, les deux `impl`s commenceront à se chevaucher et seront donc interdits par les règles de cohérence trait du langage.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}