//! Intrinsèques du compilateur.
//!
//! Les définitions correspondantes sont dans `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Les implémentations const correspondantes sont en `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const intrinsèques
//!
//! Note: toute modification de la constance des intrinsèques doit être discutée avec l'équipe linguistique.
//! Cela inclut les changements dans la stabilité de la constness.
//!
//! Afin de rendre un intrinsèque utilisable au moment de la compilation, il faut copier l'implémentation de <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> vers `compiler/rustc_mir/src/interpret/intrinsics.rs` et ajouter un `#[rustc_const_unstable(feature = "foo", issue = "01234")]` à l'intrinsèque.
//!
//!
//! Si un intrinsèque est censé être utilisé à partir d'un `const fn` avec un attribut `rustc_const_stable`, l'attribut de l'intrinsèque doit également être `rustc_const_stable`.
//! Un tel changement ne doit pas être effectué sans consultation de T-lang, car il intègre une fonctionnalité dans le langage qui ne peut pas être répliqué dans le code utilisateur sans la prise en charge du compilateur.
//!
//! # Volatiles
//!
//! Les intrinsèques volatiles fournissent des opérations destinées à agir sur la mémoire I/O, qui sont garanties de ne pas être réorganisées par le compilateur sur d'autres intrinsèques volatiles.Consultez la documentation LLVM sur [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Les intrinsèques atomiques fournissent des opérations atomiques communes sur des mots-machines, avec plusieurs ordres de mémoire possibles.Ils obéissent à la même sémantique que C++ 11.Consultez la documentation LLVM sur [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Un rappel rapide sur la commande de mémoire:
//!
//! * Acquérir, une barrière pour acquérir une serrure.Les lectures et écritures suivantes ont lieu après la barrière.
//! * Libération, une barrière pour libérer une serrure.Les lectures et écritures précédentes ont lieu avant la barrière.
//! * Des opérations séquentiellement cohérentes et séquentiellement cohérentes sont garanties dans l'ordre.C'est le mode standard pour travailler avec les types atomiques et équivaut au `volatile` de Java.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Ces importations sont utilisées pour simplifier les liens intra-doc
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // SÉCURITÉ: voir `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, ces intrinsèques prennent des pointeurs bruts car ils mutent la mémoire aliasée, ce qui n'est valable ni pour `&` ni pour `&mut`.
    //

    /// Stocke une valeur si la valeur actuelle est la même que la valeur `old`.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `compare_exchange` en passant [`Ordering::SeqCst`] en tant que paramètres `success` et `failure`.
    ///
    /// Par example, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stocke une valeur si la valeur actuelle est la même que la valeur `old`.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `compare_exchange` en passant [`Ordering::Acquire`] en tant que paramètres `success` et `failure`.
    ///
    /// Par example, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stocke une valeur si la valeur actuelle est la même que la valeur `old`.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `compare_exchange` en passant [`Ordering::Release`] comme `success` et [`Ordering::Relaxed`] comme paramètres `failure`.
    /// Par example, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stocke une valeur si la valeur actuelle est la même que la valeur `old`.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `compare_exchange` en passant [`Ordering::AcqRel`] comme `success` et [`Ordering::Acquire`] comme paramètres `failure`.
    /// Par example, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stocke une valeur si la valeur actuelle est la même que la valeur `old`.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `compare_exchange` en passant [`Ordering::Relaxed`] en tant que paramètres `success` et `failure`.
    ///
    /// Par example, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stocke une valeur si la valeur actuelle est la même que la valeur `old`.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `compare_exchange` en passant [`Ordering::SeqCst`] comme `success` et [`Ordering::Relaxed`] comme paramètres `failure`.
    /// Par example, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stocke une valeur si la valeur actuelle est la même que la valeur `old`.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `compare_exchange` en passant [`Ordering::SeqCst`] comme `success` et [`Ordering::Acquire`] comme paramètres `failure`.
    /// Par example, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stocke une valeur si la valeur actuelle est la même que la valeur `old`.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `compare_exchange` en passant [`Ordering::Acquire`] comme `success` et [`Ordering::Relaxed`] comme paramètres `failure`.
    /// Par example, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stocke une valeur si la valeur actuelle est la même que la valeur `old`.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `compare_exchange` en passant [`Ordering::AcqRel`] comme `success` et [`Ordering::Relaxed`] comme paramètres `failure`.
    /// Par example, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Stocke une valeur si la valeur actuelle est la même que la valeur `old`.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `compare_exchange_weak` en passant [`Ordering::SeqCst`] en tant que paramètres `success` et `failure`.
    ///
    /// Par example, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stocke une valeur si la valeur actuelle est la même que la valeur `old`.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `compare_exchange_weak` en passant [`Ordering::Acquire`] en tant que paramètres `success` et `failure`.
    ///
    /// Par example, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stocke une valeur si la valeur actuelle est la même que la valeur `old`.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `compare_exchange_weak` en passant [`Ordering::Release`] comme `success` et [`Ordering::Relaxed`] comme paramètres `failure`.
    /// Par example, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stocke une valeur si la valeur actuelle est la même que la valeur `old`.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `compare_exchange_weak` en passant [`Ordering::AcqRel`] comme `success` et [`Ordering::Acquire`] comme paramètres `failure`.
    /// Par example, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stocke une valeur si la valeur actuelle est la même que la valeur `old`.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `compare_exchange_weak` en passant [`Ordering::Relaxed`] en tant que paramètres `success` et `failure`.
    ///
    /// Par example, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stocke une valeur si la valeur actuelle est la même que la valeur `old`.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `compare_exchange_weak` en passant [`Ordering::SeqCst`] comme `success` et [`Ordering::Relaxed`] comme paramètres `failure`.
    /// Par example, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stocke une valeur si la valeur actuelle est la même que la valeur `old`.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `compare_exchange_weak` en passant [`Ordering::SeqCst`] comme `success` et [`Ordering::Acquire`] comme paramètres `failure`.
    /// Par example, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stocke une valeur si la valeur actuelle est la même que la valeur `old`.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `compare_exchange_weak` en passant [`Ordering::Acquire`] comme `success` et [`Ordering::Relaxed`] comme paramètres `failure`.
    /// Par example, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stocke une valeur si la valeur actuelle est la même que la valeur `old`.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `compare_exchange_weak` en passant [`Ordering::AcqRel`] comme `success` et [`Ordering::Relaxed`] comme paramètres `failure`.
    /// Par example, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Charge la valeur actuelle du pointeur.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `load` en passant [`Ordering::SeqCst`] comme `order`.
    /// Par example, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Charge la valeur actuelle du pointeur.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `load` en passant [`Ordering::Acquire`] comme `order`.
    /// Par example, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Charge la valeur actuelle du pointeur.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `load` en passant [`Ordering::Relaxed`] comme `order`.
    /// Par example, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Stocke la valeur à l'emplacement de mémoire spécifié.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `store` en passant [`Ordering::SeqCst`] comme `order`.
    /// Par example, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Stocke la valeur à l'emplacement de mémoire spécifié.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `store` en passant [`Ordering::Release`] comme `order`.
    /// Par example, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Stocke la valeur à l'emplacement de mémoire spécifié.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `store` en passant [`Ordering::Relaxed`] comme `order`.
    /// Par example, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Stocke la valeur à l'emplacement de mémoire spécifié, en renvoyant l'ancienne valeur.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `swap` en passant [`Ordering::SeqCst`] comme `order`.
    /// Par example, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Stocke la valeur à l'emplacement de mémoire spécifié, en renvoyant l'ancienne valeur.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `swap` en passant [`Ordering::Acquire`] comme `order`.
    /// Par example, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Stocke la valeur à l'emplacement de mémoire spécifié, en renvoyant l'ancienne valeur.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `swap` en passant [`Ordering::Release`] comme `order`.
    /// Par example, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Stocke la valeur à l'emplacement de mémoire spécifié, en renvoyant l'ancienne valeur.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `swap` en passant [`Ordering::AcqRel`] comme `order`.
    /// Par example, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Stocke la valeur à l'emplacement de mémoire spécifié, en renvoyant l'ancienne valeur.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `swap` en passant [`Ordering::Relaxed`] comme `order`.
    /// Par example, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// S'ajoute à la valeur actuelle, renvoyant la valeur précédente.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `fetch_add` en passant [`Ordering::SeqCst`] comme `order`.
    /// Par example, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// S'ajoute à la valeur actuelle, renvoyant la valeur précédente.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `fetch_add` en passant [`Ordering::Acquire`] comme `order`.
    /// Par example, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// S'ajoute à la valeur actuelle, renvoyant la valeur précédente.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `fetch_add` en passant [`Ordering::Release`] comme `order`.
    /// Par example, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// S'ajoute à la valeur actuelle, renvoyant la valeur précédente.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `fetch_add` en passant [`Ordering::AcqRel`] comme `order`.
    /// Par example, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// S'ajoute à la valeur actuelle, renvoyant la valeur précédente.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `fetch_add` en passant [`Ordering::Relaxed`] comme `order`.
    /// Par example, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Soustraire de la valeur actuelle, renvoyant la valeur précédente.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `fetch_sub` en passant [`Ordering::SeqCst`] comme `order`.
    /// Par example, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Soustraire de la valeur actuelle, renvoyant la valeur précédente.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `fetch_sub` en passant [`Ordering::Acquire`] comme `order`.
    /// Par example, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Soustraire de la valeur actuelle, renvoyant la valeur précédente.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `fetch_sub` en passant [`Ordering::Release`] comme `order`.
    /// Par example, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Soustraire de la valeur actuelle, renvoyant la valeur précédente.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `fetch_sub` en passant [`Ordering::AcqRel`] comme `order`.
    /// Par example, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Soustraire de la valeur actuelle, renvoyant la valeur précédente.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `fetch_sub` en passant [`Ordering::Relaxed`] comme `order`.
    /// Par example, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Au niveau du bit et avec la valeur actuelle, renvoyant la valeur précédente.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `fetch_and` en passant [`Ordering::SeqCst`] comme `order`.
    /// Par example, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Au niveau du bit et avec la valeur actuelle, renvoyant la valeur précédente.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `fetch_and` en passant [`Ordering::Acquire`] comme `order`.
    /// Par example, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Au niveau du bit et avec la valeur actuelle, renvoyant la valeur précédente.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `fetch_and` en passant [`Ordering::Release`] comme `order`.
    /// Par example, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Au niveau du bit et avec la valeur actuelle, renvoyant la valeur précédente.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `fetch_and` en passant [`Ordering::AcqRel`] comme `order`.
    /// Par example, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Au niveau du bit et avec la valeur actuelle, renvoyant la valeur précédente.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `fetch_and` en passant [`Ordering::Relaxed`] comme `order`.
    /// Par example, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Nand au niveau du bit avec la valeur actuelle, renvoyant la valeur précédente.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur le type [`AtomicBool`] via la méthode `fetch_nand` en passant [`Ordering::SeqCst`] comme `order`.
    /// Par example, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nand au niveau du bit avec la valeur actuelle, renvoyant la valeur précédente.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur le type [`AtomicBool`] via la méthode `fetch_nand` en passant [`Ordering::Acquire`] comme `order`.
    /// Par example, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nand au niveau du bit avec la valeur actuelle, renvoyant la valeur précédente.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur le type [`AtomicBool`] via la méthode `fetch_nand` en passant [`Ordering::Release`] comme `order`.
    /// Par example, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nand au niveau du bit avec la valeur actuelle, renvoyant la valeur précédente.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur le type [`AtomicBool`] via la méthode `fetch_nand` en passant [`Ordering::AcqRel`] comme `order`.
    /// Par example, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nand au niveau du bit avec la valeur actuelle, renvoyant la valeur précédente.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur le type [`AtomicBool`] via la méthode `fetch_nand` en passant [`Ordering::Relaxed`] comme `order`.
    /// Par example, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Au niveau du bit ou avec la valeur actuelle, renvoyant la valeur précédente.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `fetch_or` en passant [`Ordering::SeqCst`] comme `order`.
    /// Par example, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Au niveau du bit ou avec la valeur actuelle, renvoyant la valeur précédente.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `fetch_or` en passant [`Ordering::Acquire`] comme `order`.
    /// Par example, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Au niveau du bit ou avec la valeur actuelle, renvoyant la valeur précédente.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `fetch_or` en passant [`Ordering::Release`] comme `order`.
    /// Par example, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Au niveau du bit ou avec la valeur actuelle, renvoyant la valeur précédente.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `fetch_or` en passant [`Ordering::AcqRel`] comme `order`.
    /// Par example, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Au niveau du bit ou avec la valeur actuelle, renvoyant la valeur précédente.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `fetch_or` en passant [`Ordering::Relaxed`] comme `order`.
    /// Par example, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Xor au niveau du bit avec la valeur actuelle, renvoyant la valeur précédente.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `fetch_xor` en passant [`Ordering::SeqCst`] comme `order`.
    /// Par example, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Xor au niveau du bit avec la valeur actuelle, renvoyant la valeur précédente.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `fetch_xor` en passant [`Ordering::Acquire`] comme `order`.
    /// Par example, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Xor au niveau du bit avec la valeur actuelle, renvoyant la valeur précédente.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `fetch_xor` en passant [`Ordering::Release`] comme `order`.
    /// Par example, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Xor au niveau du bit avec la valeur actuelle, renvoyant la valeur précédente.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `fetch_xor` en passant [`Ordering::AcqRel`] comme `order`.
    /// Par example, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Xor au niveau du bit avec la valeur actuelle, renvoyant la valeur précédente.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types [`atomic`] via la méthode `fetch_xor` en passant [`Ordering::Relaxed`] comme `order`.
    /// Par example, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maximum avec la valeur actuelle en utilisant une comparaison signée.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types d'entiers signés [`atomic`] via la méthode `fetch_max` en passant [`Ordering::SeqCst`] comme `order`.
    /// Par example, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum avec la valeur actuelle en utilisant une comparaison signée.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types d'entiers signés [`atomic`] via la méthode `fetch_max` en passant [`Ordering::Acquire`] comme `order`.
    /// Par example, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum avec la valeur actuelle en utilisant une comparaison signée.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types d'entiers signés [`atomic`] via la méthode `fetch_max` en passant [`Ordering::Release`] comme `order`.
    /// Par example, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum avec la valeur actuelle en utilisant une comparaison signée.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types d'entiers signés [`atomic`] via la méthode `fetch_max` en passant [`Ordering::AcqRel`] comme `order`.
    /// Par example, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum avec la valeur actuelle.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types d'entiers signés [`atomic`] via la méthode `fetch_max` en passant [`Ordering::Relaxed`] comme `order`.
    /// Par example, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum avec la valeur actuelle à l'aide d'une comparaison signée.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types d'entiers signés [`atomic`] via la méthode `fetch_min` en passant [`Ordering::SeqCst`] comme `order`.
    /// Par example, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum avec la valeur actuelle à l'aide d'une comparaison signée.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types d'entiers signés [`atomic`] via la méthode `fetch_min` en passant [`Ordering::Acquire`] comme `order`.
    /// Par example, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum avec la valeur actuelle à l'aide d'une comparaison signée.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types d'entiers signés [`atomic`] via la méthode `fetch_min` en passant [`Ordering::Release`] comme `order`.
    /// Par example, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum avec la valeur actuelle à l'aide d'une comparaison signée.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types d'entiers signés [`atomic`] via la méthode `fetch_min` en passant [`Ordering::AcqRel`] comme `order`.
    /// Par example, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum avec la valeur actuelle à l'aide d'une comparaison signée.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types d'entiers signés [`atomic`] via la méthode `fetch_min` en passant [`Ordering::Relaxed`] comme `order`.
    /// Par example, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum avec la valeur actuelle en utilisant une comparaison non signée.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types d'entiers non signés [`atomic`] via la méthode `fetch_min` en passant [`Ordering::SeqCst`] comme `order`.
    /// Par example, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum avec la valeur actuelle en utilisant une comparaison non signée.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types d'entiers non signés [`atomic`] via la méthode `fetch_min` en passant [`Ordering::Acquire`] comme `order`.
    /// Par example, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum avec la valeur actuelle en utilisant une comparaison non signée.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types d'entiers non signés [`atomic`] via la méthode `fetch_min` en passant [`Ordering::Release`] comme `order`.
    /// Par example, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum avec la valeur actuelle en utilisant une comparaison non signée.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types d'entiers non signés [`atomic`] via la méthode `fetch_min` en passant [`Ordering::AcqRel`] comme `order`.
    /// Par example, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum avec la valeur actuelle en utilisant une comparaison non signée.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types d'entiers non signés [`atomic`] via la méthode `fetch_min` en passant [`Ordering::Relaxed`] comme `order`.
    /// Par example, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maximum avec la valeur actuelle en utilisant une comparaison non signée.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types d'entiers non signés [`atomic`] via la méthode `fetch_max` en passant [`Ordering::SeqCst`] comme `order`.
    /// Par example, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum avec la valeur actuelle en utilisant une comparaison non signée.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types d'entiers non signés [`atomic`] via la méthode `fetch_max` en passant [`Ordering::Acquire`] comme `order`.
    /// Par example, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum avec la valeur actuelle en utilisant une comparaison non signée.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types d'entiers non signés [`atomic`] via la méthode `fetch_max` en passant [`Ordering::Release`] comme `order`.
    /// Par example, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum avec la valeur actuelle en utilisant une comparaison non signée.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types d'entiers non signés [`atomic`] via la méthode `fetch_max` en passant [`Ordering::AcqRel`] comme `order`.
    /// Par example, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum avec la valeur actuelle en utilisant une comparaison non signée.
    ///
    /// La version stabilisée de cet intrinsèque est disponible sur les types d'entiers non signés [`atomic`] via la méthode `fetch_max` en passant [`Ordering::Relaxed`] comme `order`.
    /// Par example, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Le `prefetch` intrinsèque est un conseil au générateur de code pour insérer une instruction de prélecture si elle est prise en charge;sinon, c'est un no-op.
    /// Les prélèvements n'ont aucun effet sur le comportement du programme mais peuvent modifier ses caractéristiques de performance.
    ///
    /// L'argument `locality` doit être un entier constant et est un spécificateur de localité temporelle allant de (0), aucune localité, à (3), conservation extrêmement locale dans le cache.
    ///
    ///
    /// Cet intrinsèque n'a pas d'équivalent stable.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Le `prefetch` intrinsèque est un conseil au générateur de code pour insérer une instruction de prélecture si elle est prise en charge;sinon, c'est un no-op.
    /// Les prélèvements n'ont aucun effet sur le comportement du programme mais peuvent modifier ses caractéristiques de performance.
    ///
    /// L'argument `locality` doit être un entier constant et est un spécificateur de localité temporelle allant de (0), aucune localité, à (3), conservation extrêmement locale dans le cache.
    ///
    ///
    /// Cet intrinsèque n'a pas d'équivalent stable.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Le `prefetch` intrinsèque est un conseil au générateur de code pour insérer une instruction de prélecture si elle est prise en charge;sinon, c'est un no-op.
    /// Les prélèvements n'ont aucun effet sur le comportement du programme mais peuvent modifier ses caractéristiques de performance.
    ///
    /// L'argument `locality` doit être un entier constant et est un spécificateur de localité temporelle allant de (0), aucune localité, à (3), conservation extrêmement locale dans le cache.
    ///
    ///
    /// Cet intrinsèque n'a pas d'équivalent stable.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Le `prefetch` intrinsèque est un conseil au générateur de code pour insérer une instruction de prélecture si elle est prise en charge;sinon, c'est un no-op.
    /// Les prélèvements n'ont aucun effet sur le comportement du programme mais peuvent modifier ses caractéristiques de performance.
    ///
    /// L'argument `locality` doit être un entier constant et est un spécificateur de localité temporelle allant de (0), aucune localité, à (3), conservation extrêmement locale dans le cache.
    ///
    ///
    /// Cet intrinsèque n'a pas d'équivalent stable.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Une clôture atomique.
    ///
    /// La version stabilisée de cet intrinsèque est disponible dans [`atomic::fence`] en passant [`Ordering::SeqCst`] comme `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Une clôture atomique.
    ///
    /// La version stabilisée de cet intrinsèque est disponible dans [`atomic::fence`] en passant [`Ordering::Acquire`] comme `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Une clôture atomique.
    ///
    /// La version stabilisée de cet intrinsèque est disponible dans [`atomic::fence`] en passant [`Ordering::Release`] comme `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Une clôture atomique.
    ///
    /// La version stabilisée de cet intrinsèque est disponible dans [`atomic::fence`] en passant [`Ordering::AcqRel`] comme `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Une barrière mémoire réservée au compilateur.
    ///
    /// Les accès mémoire ne seront jamais réorganisés à travers cette barrière par le compilateur, mais aucune instruction ne sera émise pour cela.
    /// Ceci est approprié pour les opérations sur le même thread qui peuvent être préemptées, comme lors de l'interaction avec les gestionnaires de signaux.
    ///
    /// La version stabilisée de cet intrinsèque est disponible dans [`atomic::compiler_fence`] en passant [`Ordering::SeqCst`] comme `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Une barrière mémoire réservée au compilateur.
    ///
    /// Les accès mémoire ne seront jamais réorganisés à travers cette barrière par le compilateur, mais aucune instruction ne sera émise pour cela.
    /// Ceci est approprié pour les opérations sur le même thread qui peuvent être préemptées, comme lors de l'interaction avec les gestionnaires de signaux.
    ///
    /// La version stabilisée de cet intrinsèque est disponible dans [`atomic::compiler_fence`] en passant [`Ordering::Acquire`] comme `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Une barrière mémoire réservée au compilateur.
    ///
    /// Les accès mémoire ne seront jamais réorganisés à travers cette barrière par le compilateur, mais aucune instruction ne sera émise pour cela.
    /// Ceci est approprié pour les opérations sur le même thread qui peuvent être préemptées, comme lors de l'interaction avec les gestionnaires de signaux.
    ///
    /// La version stabilisée de cet intrinsèque est disponible dans [`atomic::compiler_fence`] en passant [`Ordering::Release`] comme `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Une barrière mémoire réservée au compilateur.
    ///
    /// Les accès mémoire ne seront jamais réorganisés à travers cette barrière par le compilateur, mais aucune instruction ne sera émise pour cela.
    /// Ceci est approprié pour les opérations sur le même thread qui peuvent être préemptées, comme lors de l'interaction avec les gestionnaires de signaux.
    ///
    /// La version stabilisée de cet intrinsèque est disponible dans [`atomic::compiler_fence`] en passant [`Ordering::AcqRel`] comme `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Magie intrinsèque qui tire sa signification des attributs attachés à la fonction.
    ///
    /// Par exemple, le flux de données l'utilise pour injecter des assertions statiques afin que `rustc_peek(potentially_uninitialized)` revérifie réellement que le flux de données a bien calculé qu'il n'est pas initialisé à ce stade du flux de contrôle.
    ///
    ///
    /// Cet intrinsèque ne doit pas être utilisé en dehors du compilateur.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Annule l'exécution du processus.
    ///
    /// Une version plus conviviale et stable de cette opération est [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Informe l'optimiseur que ce point du code n'est pas accessible, ce qui permet d'autres optimisations.
    ///
    /// NB, ceci est très différent de la macro `unreachable!()`: contrairement à la macro, qui panics lorsqu'elle est exécutée, il est *comportement indéfini* d'atteindre le code marqué avec cette fonction.
    ///
    ///
    /// La version stabilisée de cet intrinsèque est [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Informe l'optimiseur qu'une condition est toujours vraie.
    /// Si la condition est fausse, le comportement n'est pas défini.
    ///
    /// Aucun code n'est généré pour cet élément intrinsèque, mais l'optimiseur essaiera de le préserver (ainsi que sa condition) entre les passes, ce qui peut interférer avec l'optimisation du code environnant et réduire les performances.
    /// Il ne doit pas être utilisé si l'invariant peut être découvert par l'optimiseur seul ou s'il n'autorise aucune optimisation significative.
    ///
    /// Cet intrinsèque n'a pas d'équivalent stable.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Indique au compilateur que la condition branch est probablement vraie.
    /// Renvoie la valeur qui lui a été transmise.
    ///
    /// Toute utilisation autre que les instructions `if` n'aura probablement aucun effet.
    ///
    /// Cet intrinsèque n'a pas d'équivalent stable.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Indique au compilateur que la condition branch est probablement fausse.
    /// Renvoie la valeur qui lui a été transmise.
    ///
    /// Toute utilisation autre que les instructions `if` n'aura probablement aucun effet.
    ///
    /// Cet intrinsèque n'a pas d'équivalent stable.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Exécute une interruption de point d'arrêt, pour inspection par un débogueur.
    ///
    /// Cet intrinsèque n'a pas d'équivalent stable.
    pub fn breakpoint();

    /// La taille d'un type en octets.
    ///
    /// Plus précisément, il s'agit du décalage en octets entre les éléments successifs du même type, y compris le remplissage d'alignement.
    ///
    ///
    /// La version stabilisée de cet intrinsèque est [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// L'alignement minimum d'un type.
    ///
    /// La version stabilisée de cet intrinsèque est [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// L'alignement préféré d'un type.
    ///
    /// Cet intrinsèque n'a pas d'équivalent stable.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// La taille de la valeur référencée en octets.
    ///
    /// La version stabilisée de cet intrinsèque est [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// L'alignement requis de la valeur référencée.
    ///
    /// La version stabilisée de cet intrinsèque est [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Obtient une tranche de chaîne statique contenant le nom d'un type.
    ///
    /// La version stabilisée de cet intrinsèque est [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Obtient un identificateur globalement unique pour le type spécifié.
    /// Cette fonction renverra la même valeur pour un type quel que soit le crate dans lequel il est appelé.
    ///
    ///
    /// La version stabilisée de cet intrinsèque est [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Un garde pour les fonctions dangereuses qui ne peuvent jamais être exécutées si `T` est inhabité:
    /// Cela sera statiquement soit panic, soit ne fera rien.
    ///
    /// Cet intrinsèque n'a pas d'équivalent stable.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Une protection pour les fonctions non sécurisées qui ne peuvent jamais être exécutées si `T` ne permet pas l'initialisation à zéro: cela sera statiquement soit panic, soit ne fera rien.
    ///
    ///
    /// Cet intrinsèque n'a pas d'équivalent stable.
    pub fn assert_zero_valid<T>();

    /// Une protection pour les fonctions non sécurisées qui ne peuvent jamais être exécutées si `T` a des modèles de bits non valides: cela sera statiquement soit panic, soit ne fera rien.
    ///
    ///
    /// Cet intrinsèque n'a pas d'équivalent stable.
    pub fn assert_uninit_valid<T>();

    /// Obtient une référence à un `Location` statique indiquant où il a été appelé.
    ///
    /// Pensez à utiliser [`core::panic::Location::caller`](crate::panic::Location::caller) à la place.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Déplace une valeur hors de portée sans exécuter drop glue.
    ///
    /// Cela n'existe que pour [`mem::forget_unsized`];`forget` normal utilise à la place `ManuallyDrop`.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Réinterprète les bits d'une valeur d'un type comme un autre type.
    ///
    /// Les deux types doivent avoir la même taille.
    /// Ni l'original, ni le résultat ne peuvent être un [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` est sémantiquement équivalent à un déplacement au niveau du bit d'un type vers un autre.Il copie les bits de la valeur source dans la valeur de destination, puis oublie l'original.
    /// C'est équivalent au `memcpy` de C sous le capot, tout comme `transmute_copy`.
    ///
    /// Étant donné que `transmute` est une opération par valeur, l'alignement des *valeurs transmutées elles-mêmes* n'est pas un problème.
    /// Comme pour toute autre fonction, le compilateur garantit déjà que `T` et `U` sont correctement alignés.
    /// Cependant, lors de la transmutation de valeurs qui *pointent ailleurs*(telles que des pointeurs, des références, des boîtes…), l'appelant doit assurer un alignement correct des valeurs pointées.
    ///
    /// `transmute` est **incroyablement** dangereux.Il existe un grand nombre de façons de provoquer [undefined behavior][ub] avec cette fonction.`transmute` devrait être le dernier recours absolu.
    ///
    /// Le [nomicon](../../nomicon/transmutes.html) a une documentation supplémentaire.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Il y a plusieurs choses pour lesquelles `transmute` est vraiment utile.
    ///
    /// Transformer un pointeur en un pointeur de fonction.Ceci n'est *pas* portable pour les machines où les pointeurs de fonction et les pointeurs de données ont des tailles différentes.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Prolonger une durée de vie ou raccourcir une durée de vie invariante.Ceci est avancé, très dangereux Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Ne désespérez pas: de nombreuses utilisations du `transmute` peuvent être réalisées par d'autres moyens.
    /// Vous trouverez ci-dessous des applications courantes de `transmute` qui peuvent être remplacées par des constructions plus sûres.
    ///
    /// Transformation du bytes(`&[u8]`) brut en `u32`, `f64`, etc.:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // utilisez plutôt `u32::from_ne_bytes`
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // ou utilisez `u32::from_le_bytes` ou `u32::from_be_bytes` pour spécifier l'endianness
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Transformer un pointeur en un `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Utilisez plutôt une distribution `as`
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Transformer un `*mut T` en un `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Utilisez plutôt un réemprunt
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Transformer un `&mut T` en un `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Maintenant, assemblez `as` et réempruntant, notez que le chaînage de `as` `as` n'est pas transitif
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Transformer un `&str` en un `&[u8]`:
    ///
    /// ```
    /// // ce n'est pas une bonne façon de faire cela.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Vous pouvez utiliser `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Ou, utilisez simplement une chaîne d'octets, si vous avez le contrôle sur la chaîne littérale
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Transformer un `Vec<&T>` en un `Vec<Option<&T>>`.
    ///
    /// Pour transmuter le type interne du contenu d'un conteneur, vous devez vous assurer de ne violer aucun des invariants du conteneur.
    /// Pour `Vec`, cela signifie que la taille *et l'alignement* des types internes doivent correspondre.
    /// D'autres conteneurs peuvent dépendre de la taille du type, de l'alignement ou même du `TypeId`, auquel cas la transmutation ne serait pas possible du tout sans violer les invariants du conteneur.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // clonez le vector car nous les réutiliserons plus tard
    /// let v_clone = v_orig.clone();
    ///
    /// // Utilisation de la transmutation: cela repose sur la disposition des données non spécifiée de `Vec`, ce qui est une mauvaise idée et pourrait entraîner un comportement indéfini.
    /////
    /// // Cependant, ce n'est pas une copie.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // C'est la manière suggérée et sûre.
    /// // Cependant, il copie le vector entier dans un nouveau tableau.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Il s'agit de la méthode appropriée sans copie et non sécurisée de "transmuting" a `Vec`, sans se fier à la mise en page des données.
    /// // Au lieu d'appeler littéralement `transmute`, nous effectuons un cast de pointeur, mais en termes de conversion du type interne d'origine (`&i32`) en le nouveau (`Option<&i32>`), cela comporte toutes les mêmes mises en garde.
    /////
    /// // Outre les informations fournies ci-dessus, consultez également la documentation du [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Mettez à jour ceci lorsque vec_into_raw_parts est stabilisé.
    ///     // Assurez-vous que le vector d'origine n'est pas tombé.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Implémentation de `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Il existe plusieurs façons de procéder, et il existe plusieurs problèmes avec la méthode (transmute) suivante.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // d'abord: la transmutation n'est pas de type sûr;tout ce qu'il vérifie, c'est que T et
    ///         // U sont de la même taille.
    ///         // Deuxièmement, ici, vous avez deux références mutables pointant vers la même mémoire.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Cela élimine les problèmes de sécurité de type;`&mut *` vous donnera* seulement *un `&mut T` d'un `&mut T` ou `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // cependant, vous avez toujours deux références mutables pointant vers la même mémoire.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // C'est ainsi que la bibliothèque standard le fait.
    /// // C'est la meilleure méthode, si vous devez faire quelque chose comme ça
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Celui-ci a maintenant trois références mutables pointant vers la même mémoire.`slice`, la rvalue ret.0 et la rvalue ret.1.
    ///         // `slice` n'est jamais utilisé après `let ptr = ...`, on peut donc le traiter comme "dead", et par conséquent, vous n'avez que deux vraies tranches mutables.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Bien que cela rende le const intrinsèque stable, nous avons du code personnalisé dans const fn
    // vérifications qui empêchent son utilisation dans `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Renvoie `true` si le type réel donné sous la forme `T` nécessite une goutte de colle;renvoie `false` si le type réel fourni pour `T` implémente `Copy`.
    ///
    ///
    /// Si le type réel ne nécessite ni drop glue ni implémente `Copy`, la valeur de retour de cette fonction n'est pas spécifiée.
    ///
    /// La version stabilisée de cet intrinsèque est [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Calcule le décalage à partir d'un pointeur.
    ///
    /// Ceci est implémenté en tant qu'intrinsèque pour éviter la conversion vers et depuis un entier, car la conversion rejetterait les informations d'alias.
    ///
    /// # Safety
    ///
    /// Le pointeur de départ et le pointeur résultant doivent être soit dans les limites, soit un octet après la fin d'un objet alloué.
    /// Si l'un des pointeurs est hors limites ou si un dépassement arithmétique se produit, toute utilisation ultérieure de la valeur renvoyée entraînera un comportement indéfini.
    ///
    ///
    /// La version stabilisée de cet intrinsèque est [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Calcule le décalage à partir d'un pointeur, potentiellement enveloppant.
    ///
    /// Ceci est implémenté en tant qu'intrinsèque pour éviter la conversion vers et à partir d'un entier, car la conversion inhibe certaines optimisations.
    ///
    /// # Safety
    ///
    /// Contrairement à l'intrinsèque `offset`, cet intrinsèque ne limite pas le pointeur résultant à pointer vers ou un octet après la fin d'un objet alloué, et il s'enroule avec l'arithmétique du complément à deux.
    /// La valeur résultante n'est pas nécessairement valide pour être utilisée pour accéder réellement à la mémoire.
    ///
    /// La version stabilisée de cet intrinsèque est [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Équivalent au `llvm.memcpy.p0i8.0i8.*` intrinsèque approprié, avec une taille de `count`*`size_of::<T>()` et un alignement de
    ///
    /// `min_align_of::<T>()`
    ///
    /// Le paramètre volatile est défini sur `true`, il ne sera donc pas optimisé sauf si la taille est égale à zéro.
    ///
    /// Cet intrinsèque n'a pas d'équivalent stable.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Équivalent au `llvm.memmove.p0i8.0i8.*` intrinsèque approprié, avec une taille de `count* size_of::<T>()` et un alignement de
    ///
    /// `min_align_of::<T>()`
    ///
    /// Le paramètre volatile est défini sur `true`, il ne sera donc pas optimisé sauf si la taille est égale à zéro.
    ///
    /// Cet intrinsèque n'a pas d'équivalent stable.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Équivalent à l'intrinsèque `llvm.memset.p0i8.*` approprié, avec une taille de `count* size_of::<T>()` et un alignement de `min_align_of::<T>()`.
    ///
    ///
    /// Le paramètre volatile est défini sur `true`, il ne sera donc pas optimisé sauf si la taille est égale à zéro.
    ///
    /// Cet intrinsèque n'a pas d'équivalent stable.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Effectue une charge volatile à partir du pointeur `src`.
    ///
    /// La version stabilisée de cet intrinsèque est [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Effectue un stockage volatil sur le pointeur `dst`.
    ///
    /// La version stabilisée de cet intrinsèque est [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Effectue une charge volatile à partir du pointeur `src` Le pointeur n'a pas besoin d'être aligné.
    ///
    ///
    /// Cet intrinsèque n'a pas d'équivalent stable.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Effectue un stockage volatil sur le pointeur `dst`.
    /// Il n'est pas nécessaire que le pointeur soit aligné.
    ///
    /// Cet intrinsèque n'a pas d'équivalent stable.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Renvoie la racine carrée d'un `f32`
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Renvoie la racine carrée d'un `f64`
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Élève un `f32` à une puissance entière.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Élève un `f64` à une puissance entière.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Renvoie le sinus d'un `f32`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Renvoie le sinus d'un `f64`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Renvoie le cosinus d'un `f32`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Renvoie le cosinus d'un `f64`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Élève un `f32` à une puissance `f32`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Élève un `f64` à une puissance `f64`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Renvoie l'exponentielle d'un `f32`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Renvoie l'exponentielle d'un `f64`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Renvoie 2 élevé à la puissance d'un `f32`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Renvoie 2 élevé à la puissance d'un `f64`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Renvoie le logarithme naturel d'un `f32`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Renvoie le logarithme naturel d'un `f64`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Renvoie le logarithme de base 10 d'un `f32`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Renvoie le logarithme de base 10 d'un `f64`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Renvoie le logarithme de base 2 d'un `f32`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Renvoie le logarithme de base 2 d'un `f64`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Renvoie `a * b + c` pour les valeurs `f32`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Renvoie `a * b + c` pour les valeurs `f64`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Renvoie la valeur absolue d'un `f32`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Renvoie la valeur absolue d'un `f64`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Renvoie le minimum de deux valeurs `f32`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Renvoie le minimum de deux valeurs `f64`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Renvoie le maximum de deux valeurs `f32`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Renvoie le maximum de deux valeurs `f64`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Copie le signe de `y` vers `x` pour les valeurs `f32`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Copie le signe de `y` vers `x` pour les valeurs `f64`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Renvoie le plus grand entier inférieur ou égal à `f32`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Renvoie le plus grand entier inférieur ou égal à `f64`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Renvoie le plus petit entier supérieur ou égal à `f32`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Renvoie le plus petit entier supérieur ou égal à `f64`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Renvoie la partie entière d'un `f32`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Renvoie la partie entière d'un `f64`.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Renvoie l'entier le plus proche d'un `f32`.
    /// Peut déclencher une exception à virgule flottante inexacte si l'argument n'est pas un entier.
    pub fn rintf32(x: f32) -> f32;
    /// Renvoie l'entier le plus proche d'un `f64`.
    /// Peut déclencher une exception à virgule flottante inexacte si l'argument n'est pas un entier.
    pub fn rintf64(x: f64) -> f64;

    /// Renvoie l'entier le plus proche d'un `f32`.
    ///
    /// Cet intrinsèque n'a pas d'équivalent stable.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Renvoie l'entier le plus proche d'un `f64`.
    ///
    /// Cet intrinsèque n'a pas d'équivalent stable.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Renvoie l'entier le plus proche d'un `f32`.Arrondit les cas à mi-chemin de zéro.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Renvoie l'entier le plus proche d'un `f64`.Arrondit les cas à mi-chemin de zéro.
    ///
    /// La version stabilisée de cet intrinsèque est
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Ajout de float qui permet des optimisations basées sur des règles algébriques.
    /// Peut supposer que les intrants sont finis.
    ///
    /// Cet intrinsèque n'a pas d'équivalent stable.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Soustraction flottante qui permet des optimisations basées sur des règles algébriques.
    /// Peut supposer que les intrants sont finis.
    ///
    /// Cet intrinsèque n'a pas d'équivalent stable.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Multiplication de flotteurs qui permet des optimisations basées sur des règles algébriques.
    /// Peut supposer que les intrants sont finis.
    ///
    /// Cet intrinsèque n'a pas d'équivalent stable.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Division flottante qui permet des optimisations basées sur des règles algébriques.
    /// Peut supposer que les intrants sont finis.
    ///
    /// Cet intrinsèque n'a pas d'équivalent stable.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Reste flottant qui permet des optimisations basées sur des règles algébriques.
    /// Peut supposer que les intrants sont finis.
    ///
    /// Cet intrinsèque n'a pas d'équivalent stable.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Conversion avec fptoui/fptosi de LLVM, qui peut renvoyer undef pour les valeurs hors limites
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Stabilisé comme [`f32::to_int_unchecked`] et [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Renvoie le nombre de bits définis dans un type entier `T`
    ///
    /// Les versions stabilisées de cet intrinsèque sont disponibles sur les primitives entières via la méthode `count_ones`.
    /// Par example,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Renvoie le nombre de bits non définis non définis (zeroes) dans un type entier `T`.
    ///
    /// Les versions stabilisées de cet intrinsèque sont disponibles sur les primitives entières via la méthode `leading_zeros`.
    /// Par example,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// Un `x` avec la valeur `0` renverra la largeur en bits de `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Comme `ctlz`, mais extrêmement dangereux car il renvoie `undef` lorsqu'il est donné un `x` avec la valeur `0`.
    ///
    ///
    /// Cet intrinsèque n'a pas d'équivalent stable.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Renvoie le nombre de bits non définis de fin (zeroes) dans un type entier `T`.
    ///
    /// Les versions stabilisées de cet intrinsèque sont disponibles sur les primitives entières via la méthode `trailing_zeros`.
    /// Par example,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// Un `x` avec la valeur `0` renverra la largeur en bits de `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Comme `cttz`, mais extrêmement dangereux car il renvoie `undef` lorsqu'il est donné un `x` avec la valeur `0`.
    ///
    ///
    /// Cet intrinsèque n'a pas d'équivalent stable.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Inverse les octets dans un type entier `T`.
    ///
    /// Les versions stabilisées de cet intrinsèque sont disponibles sur les primitives entières via la méthode `swap_bytes`.
    /// Par example,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Inverse les bits dans un type entier `T`.
    ///
    /// Les versions stabilisées de cet intrinsèque sont disponibles sur les primitives entières via la méthode `reverse_bits`.
    /// Par example,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Effectue une addition d'entiers vérifiée.
    ///
    /// Les versions stabilisées de cet intrinsèque sont disponibles sur les primitives entières via la méthode `overflowing_add`.
    /// Par example,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Effectue une soustraction d'entiers vérifiés
    ///
    /// Les versions stabilisées de cet intrinsèque sont disponibles sur les primitives entières via la méthode `overflowing_sub`.
    /// Par example,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Effectue une multiplication d'entiers vérifiée
    ///
    /// Les versions stabilisées de cet intrinsèque sont disponibles sur les primitives entières via la méthode `overflowing_mul`.
    /// Par example,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Effectue une division exacte, ce qui entraîne un comportement indéfini où `x % y != 0` ou `y == 0` ou `x == T::MIN && y == -1`
    ///
    ///
    /// Cet intrinsèque n'a pas d'équivalent stable.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Effectue une division non vérifiée, ce qui entraîne un comportement indéfini où `y == 0` ou `x == T::MIN && y == -1`
    ///
    ///
    /// Des wrappers sûrs pour cet intrinsèque sont disponibles sur les primitives entières via la méthode `checked_div`.
    /// Par example,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Renvoie le reste d'une division non vérifiée, ce qui entraîne un comportement indéfini lorsque `y == 0` ou `x == T::MIN && y == -1`
    ///
    ///
    /// Des wrappers sûrs pour cet intrinsèque sont disponibles sur les primitives entières via la méthode `checked_rem`.
    /// Par example,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Effectue un décalage vers la gauche non coché, ce qui entraîne un comportement indéfini lorsque `y < 0` ou `y >= N`, où N est la largeur de T en bits.
    ///
    ///
    /// Des wrappers sûrs pour cet intrinsèque sont disponibles sur les primitives entières via la méthode `checked_shl`.
    /// Par example,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Effectue un décalage à droite non vérifié, ce qui entraîne un comportement indéfini lorsque `y < 0` ou `y >= N`, où N est la largeur de T en bits.
    ///
    ///
    /// Des wrappers sûrs pour cet intrinsèque sont disponibles sur les primitives entières via la méthode `checked_shr`.
    /// Par example,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Renvoie le résultat d'un ajout non vérifié, entraînant un comportement indéfini lorsque `x + y > T::MAX` ou `x + y < T::MIN`.
    ///
    ///
    /// Cet intrinsèque n'a pas d'équivalent stable.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Renvoie le résultat d'une soustraction non vérifiée, entraînant un comportement indéfini lorsque `x - y > T::MAX` ou `x - y < T::MIN`.
    ///
    ///
    /// Cet intrinsèque n'a pas d'équivalent stable.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Renvoie le résultat d'une multiplication non vérifiée, entraînant un comportement indéfini lorsque `x *y > T::MAX` ou `x* y < T::MIN`.
    ///
    ///
    /// Cet intrinsèque n'a pas d'équivalent stable.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Effectue une rotation à gauche.
    ///
    /// Les versions stabilisées de cet intrinsèque sont disponibles sur les primitives entières via la méthode `rotate_left`.
    /// Par example,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Effectue une rotation à droite.
    ///
    /// Les versions stabilisées de cet intrinsèque sont disponibles sur les primitives entières via la méthode `rotate_right`.
    /// Par example,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Renvoie (a + b) mod 2 <sup>N</sup>, où N est la largeur de T en bits.
    ///
    /// Les versions stabilisées de cet intrinsèque sont disponibles sur les primitives entières via la méthode `wrapping_add`.
    /// Par example,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Renvoie (a, b) mod 2 <sup>N</sup>, où N est la largeur de T en bits.
    ///
    /// Les versions stabilisées de cet intrinsèque sont disponibles sur les primitives entières via la méthode `wrapping_sub`.
    /// Par example,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Renvoie (a * b) mod 2 <sup>N</sup>, où N est la largeur de T en bits.
    ///
    /// Les versions stabilisées de cet intrinsèque sont disponibles sur les primitives entières via la méthode `wrapping_mul`.
    /// Par example,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Calcule `a + b`, saturant aux limites numériques.
    ///
    /// Les versions stabilisées de cet intrinsèque sont disponibles sur les primitives entières via la méthode `saturating_add`.
    /// Par example,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Calcule `a - b`, saturant aux limites numériques.
    ///
    /// Les versions stabilisées de cet intrinsèque sont disponibles sur les primitives entières via la méthode `saturating_sub`.
    /// Par example,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Renvoie la valeur du discriminant pour la variante dans 'v';
    /// si `T` n'a pas de discriminant, renvoie `0`.
    ///
    /// La version stabilisée de cet intrinsèque est [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Renvoie le nombre de variantes de type `T` converties en `usize`;
    /// si `T` n'a pas de variantes, renvoie `0`.Les variantes inhabitées seront comptées.
    ///
    /// La version à stabiliser de cet intrinsèque est [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// La construction "try catch" de Rust qui invoque le pointeur de fonction `try_fn` avec le pointeur de données `data`.
    ///
    /// Le troisième argument est une fonction appelée si un panic se produit.
    /// Cette fonction prend le pointeur de données et un pointeur vers l'objet d'exception spécifique à la cible qui a été intercepté.
    ///
    /// Pour plus d'informations, consultez la source du compilateur ainsi que l'implémentation catch de std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Émet un magasin `!nontemporal` selon LLVM (voir leur documentation).
    /// Ne deviendra probablement jamais stable.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Voir la documentation de `<*const T>::offset_from` pour plus de détails.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Voir la documentation de `<*const T>::guaranteed_eq` pour plus de détails.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Voir la documentation de `<*const T>::guaranteed_ne` pour plus de détails.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Allouer au moment de la compilation.Ne doit pas être appelé lors de l'exécution.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Certaines fonctions sont définies ici car elles ont été accidentellement rendues disponibles dans ce module sur stable.
// Voir <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` entre également dans cette catégorie, mais il ne peut pas être emballé car il est vérifié que `T` et `U` ont la même taille.)
//

/// Vérifie si `ptr` est correctement aligné par rapport à `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Copie les octets `count *size_of::<T>()` de `src` vers `dst`.La source et la destination ne doivent* pas * se chevaucher.
///
/// Pour les régions de mémoire susceptibles de se chevaucher, utilisez plutôt [`copy`].
///
/// `copy_nonoverlapping` est sémantiquement équivalent au [`memcpy`] de C, mais avec l'ordre des arguments inversé.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Le comportement n'est pas défini si l'une des conditions suivantes n'est pas respectée:
///
/// * `src` doit être [valid] pour les lectures d'octets `count * size_of::<T>()`.
///
/// * `dst` doit être [valid] pour les écritures d'octets `count * size_of::<T>()`.
///
/// * Les `src` et `dst` doivent être correctement alignés.
///
/// * La région de mémoire commençant à `src` avec une taille de `count *
///   taille de: :<T>() `les octets ne doivent *pas* chevaucher la région de la mémoire commençant à `dst` avec la même taille.
///
/// Comme [`read`], `copy_nonoverlapping` crée une copie au niveau du bit de `T`, que `T` soit ou non [`Copy`].
/// Si `T` n'est pas [`Copy`], utiliser *les deux* les valeurs dans la région commençant à `*src` et la région commençant à `* dst` peut [violate memory safety][read-ownership].
///
///
/// Notez que même si la taille effectivement copiée (`count * size_of: :<T>()`) est `0`, les pointeurs doivent être non NULL et correctement alignés.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Implémentez manuellement [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Déplace tous les éléments de `src` dans `dst`, laissant `src` vide.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Assurez-vous que `dst` a une capacité suffisante pour contenir tous les `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // L'appel à offset est toujours sûr car `Vec` n'allouera jamais plus de `isize::MAX` octets.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Tronquez `src` sans supprimer son contenu.
///         // Nous faisons cela en premier, pour éviter les problèmes au cas où quelque chose plus bas panics.
///         src.set_len(0);
///
///         // Les deux régions ne peuvent pas se chevaucher car les références mutables ne sont pas alias et deux vectors différents ne peuvent pas posséder la même mémoire.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Avertissez `dst` qu'il contient désormais le contenu de `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Effectuer ces vérifications uniquement au moment de l'exécution
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Pas de panique pour réduire l'impact du codegen.
        abort();
    }*/

    // SÉCURITÉ: le contrat de sécurité du `copy_nonoverlapping` doit être
    // confirmé par l'appelant.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Copie les octets `count * size_of::<T>()` de `src` vers `dst`.La source et la destination peuvent se chevaucher.
///
/// Si la source et la destination ne se chevauchent *jamais*, [`copy_nonoverlapping`] peut être utilisé à la place.
///
/// `copy` est sémantiquement équivalent au [`memmove`] de C, mais avec l'ordre des arguments inversé.
/// La copie a lieu comme si les octets avaient été copiés de `src` vers un tableau temporaire, puis copiés du tableau vers `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Le comportement n'est pas défini si l'une des conditions suivantes n'est pas respectée:
///
/// * `src` doit être [valid] pour les lectures d'octets `count * size_of::<T>()`.
///
/// * `dst` doit être [valid] pour les écritures d'octets `count * size_of::<T>()`.
///
/// * Les `src` et `dst` doivent être correctement alignés.
///
/// Comme [`read`], `copy` crée une copie au niveau du bit de `T`, que `T` soit ou non [`Copy`].
/// Si `T` n'est pas [`Copy`], utiliser à la fois les valeurs de la région commençant à `*src` et la région commençant à `* dst` peut [violate memory safety][read-ownership].
///
///
/// Notez que même si la taille effectivement copiée (`count * size_of: :<T>()`) est `0`, les pointeurs doivent être non NULL et correctement alignés.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Créez efficacement un Rust vector à partir d'un tampon non sécurisé:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` doit être correctement aligné pour son type et non nul.
/// /// * `ptr` doit être valide pour les lectures d'éléments contigus `elts` de type `T`.
/// /// * Ces éléments ne doivent pas être utilisés après l'appel de cette fonction à moins que `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // SÉCURITÉ: Notre condition préalable garantit que la source est alignée et valide,
///     // et `Vec::with_capacity` garantit que nous avons un espace utilisable pour les écrire.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // SÉCURITÉ: Nous l'avons créé avec cette capacité beaucoup plus tôt,
///     // et le `copy` précédent a initialisé ces éléments.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Effectuer ces vérifications uniquement au moment de l'exécution
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Pas de panique pour réduire l'impact du codegen.
        abort();
    }*/

    // SÉCURITÉ: le contrat de sécurité du `copy` doit être respecté par l'appelant.
    unsafe { copy(src, dst, count) }
}

/// Définit `count * size_of::<T>()` octets de mémoire à partir de `dst` sur `val`.
///
/// `write_bytes` est similaire au [`memset`] de C, mais définit les octets `count * size_of::<T>()` sur `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Le comportement n'est pas défini si l'une des conditions suivantes n'est pas respectée:
///
/// * `dst` doit être [valid] pour les écritures d'octets `count * size_of::<T>()`.
///
/// * `dst` doit être correctement aligné.
///
/// En outre, l'appelant doit s'assurer que l'écriture d'octets `count * size_of::<T>()` dans la région de mémoire donnée aboutit à une valeur valide de `T`.
/// L'utilisation d'une région de mémoire typée comme `T` qui contient une valeur non valide de `T` est un comportement indéfini.
///
/// Notez que même si la taille effectivement copiée (`count * size_of: :<T>()`) est `0`, le pointeur doit être non NULL et correctement aligné.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Utilisation de base:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Création d'une valeur invalide:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Fuite la valeur précédemment conservée en écrasant le `Box<T>` par un pointeur nul.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // À ce stade, l'utilisation ou la suppression de `v` entraîne un comportement indéfini.
/// // drop(v); // ERROR
///
/// // Même fuite `v` "uses", et donc un comportement indéfini.
/// // mem::forget(v); // ERROR
///
/// // En fait, `v` n'est pas valide selon les invariants de disposition de type de base, donc *toute* opération qui la touche est un comportement indéfini.
/////
/// // soit v2 =v;//ERREUR
///
/// unsafe {
///     // Mettons plutôt une valeur valide
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Maintenant, la boîte va bien
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // SÉCURITÉ: le contrat de sécurité du `write_bytes` doit être respecté par l'appelant.
    unsafe { write_bytes(dst, val, count) }
}