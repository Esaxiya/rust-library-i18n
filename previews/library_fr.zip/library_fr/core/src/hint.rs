#![stable(feature = "core_hint", since = "1.27.0")]

//! Conseils au compilateur qui affectent la façon dont le code doit être émis ou optimisé.
//! Les indices peuvent être au moment de la compilation ou à l'exécution.

use crate::intrinsics;

/// Informe le compilateur que ce point du code n'est pas accessible, ce qui permet d'autres optimisations.
///
/// # Safety
///
/// Atteindre cette fonction est complètement *comportement indéfini*(UB).En particulier, le compilateur suppose que tout UB ne doit jamais se produire, et éliminera donc toutes les branches qui atteignent un appel à `unreachable_unchecked()`.
///
/// Comme toutes les instances d'UB, si cette hypothèse s'avère fausse, c'est-à-dire que l'appel `unreachable_unchecked()` est réellement accessible parmi tous les flux de contrôle possibles, le compilateur appliquera la mauvaise stratégie d'optimisation, et peut parfois même corrompre du code apparemment sans rapport, causant des difficultés. pour déboguer les problèmes.
///
///
/// N'utilisez cette fonction que lorsque vous pouvez prouver que le code ne l'appellera jamais.
/// Sinon, pensez à utiliser la macro [`unreachable!`], qui n'autorise pas les optimisations mais qui sera panic lors de son exécution.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` est toujours positif (différent de zéro), donc `checked_div` ne retournera jamais `None`.
/////
///     // Par conséquent, l'autre branch est inaccessible.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // SÉCURITÉ: le contrat de sécurité du `intrinsics::unreachable` doit
    // être confirmée par l'appelant.
    unsafe { intrinsics::unreachable() }
}

/// Émet une instruction machine pour signaler au processeur qu'il s'exécute dans une boucle de rotation d'attente occupée ("verrouillage de rotation").
///
/// Lors de la réception du signal de boucle de rotation, le processeur peut optimiser son comportement, par exemple, en économisant de l'énergie ou en commutant les threads hyper.
///
/// Cette fonction est différente de [`thread::yield_now`] qui cède directement au planificateur du système, alors que `spin_loop` n'interagit pas avec le système d'exploitation.
///
/// Un cas d'utilisation courant de `spin_loop` est l'implémentation de la rotation optimiste limitée dans une boucle CAS dans les primitives de synchronisation.
/// Pour éviter des problèmes comme l'inversion de priorité, il est fortement recommandé que la boucle de rotation se termine après un nombre fini d'itérations et un appel système de blocage approprié est effectué.
///
///
/// **Remarque**: Sur les plates-formes qui ne prennent pas en charge la réception d'indices de boucle de rotation, cette fonction ne fait rien du tout.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Une valeur atomique partagée que les threads utiliseront pour coordonner
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Dans un thread d'arrière-plan, nous définirons finalement la valeur
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Faites un peu de travail, puis faites vivre la valeur
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // De retour sur notre thread actuel, nous attendons que la valeur soit définie
/// while !live.load(Ordering::Acquire) {
///     // La boucle de rotation est un indice pour le processeur que nous attendons, mais probablement pas pour très longtemps
/////
///     hint::spin_loop();
/// }
///
/// // La valeur est maintenant définie
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // SÉCURITÉ: l'attr `cfg` garantit que nous n'exécutons cela que sur les cibles x86.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // SÉCURITÉ: l'attr `cfg` garantit que nous n'exécutons cela que sur les cibles x86_64.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // SÉCURITÉ: l'attr `cfg` garantit que nous n'exécutons cela que sur les cibles aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // SÉCURITÉ: l'attr `cfg` garantit que nous n'exécutons cela que sur des cibles de bras
            // avec prise en charge de la fonction v6.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Une fonction d'identité qui *__ indique __* au compilateur d'être au maximum pessimiste sur ce que `black_box` pourrait faire.
///
/// Contrairement à [`std::convert::identity`], un compilateur Rust est encouragé à supposer que `black_box` peut utiliser `dummy` de toutes les manières valides possibles que le code Rust est autorisé à utiliser sans introduire de comportement indéfini dans le code appelant.
///
/// Cette propriété rend `black_box` utile pour écrire du code dans lequel certaines optimisations ne sont pas souhaitées, comme les benchmarks.
///
/// Notez cependant que `black_box` est uniquement (et ne peut être) fourni que sur une base "best-effort".La mesure dans laquelle il peut bloquer les optimisations peut varier en fonction de la plate-forme et du backend code-gen utilisé.
/// Les programmes ne peuvent en aucun cas compter sur `black_box` pour la *correction*.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Nous devons "use" l'argument d'une manière que LLVM ne peut pas introspecter, et sur les cibles qui le prennent en charge, nous pouvons généralement utiliser l'assemblage en ligne pour le faire.
    // L'interprétation de LLVM de l'assemblage en ligne est que c'est, eh bien, une boîte noire.
    // Ce n'est pas la meilleure implémentation car elle désoptimise probablement plus que nous ne le souhaitons, mais elle est jusqu'à présent suffisante.
    //
    //

    #[cfg(not(miri))] // Ce n'est qu'un indice, donc il n'y a rien de mal à sauter dans Miri.
    // SÉCURITÉ: l'assemblage en ligne est un no-op.
    unsafe {
        // FIXME: Impossible d'utiliser `asm!` car il ne prend pas en charge MIPS et d'autres architectures.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}