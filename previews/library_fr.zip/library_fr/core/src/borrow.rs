//! Un module pour travailler avec des données empruntées.

#![stable(feature = "rust1", since = "1.0.0")]

/// Un trait pour les données d'emprunt.
///
/// Dans Rust, il est courant de fournir différentes représentations d'un type pour différents cas d'utilisation.
/// Par exemple, l'emplacement de stockage et la gestion d'une valeur peuvent être spécifiquement choisis pour une utilisation particulière via des types de pointeurs tels que [`Box<T>`] ou [`Rc<T>`].
/// Au-delà de ces wrappers génériques qui peuvent être utilisés avec n'importe quel type, certains types fournissent des facettes facultatives offrant des fonctionnalités potentiellement coûteuses.
/// Un exemple d'un tel type est [`String`] qui ajoute la possibilité d'étendre une chaîne au [`str`] de base.
/// Cela nécessite de conserver des informations supplémentaires inutiles pour une chaîne simple et immuable.
///
/// Ces types permettent d'accéder aux données sous-jacentes via des références au type de ces données.On dit qu'ils sont «empruntés comme» ce type.
/// Par exemple, un [`Box<T>`] peut être emprunté en tant que `T` tandis qu'un [`String`] peut être emprunté en tant que `str`.
///
/// Les types expriment qu'ils peuvent être empruntés en tant que type `T` en implémentant `Borrow<T>`, en fournissant une référence à un `T` dans la méthode [`borrow`] de trait.Un type est libre d'emprunter comme plusieurs types différents.
/// S'il souhaite emprunter mutuellement comme type-ce qui permet de modifier les données sous-jacentes, il peut en outre implémenter [`BorrowMut<T>`].
///
/// En outre, lors de la fourniture d'implémentations pour des traits supplémentaires, il faut se demander si elles doivent se comporter de la même manière que celles du type sous-jacent en tant que représentation de ce type sous-jacent.
/// Le code générique utilise généralement `Borrow<T>` lorsqu'il repose sur le comportement identique de ces implémentations trait supplémentaires.
/// Ces traits apparaîtront probablement comme trait bounds supplémentaires.
///
/// En particulier, `Eq`, `Ord` et `Hash` doivent être équivalents pour les valeurs empruntées et possédées: `x.borrow() == y.borrow()` doit donner le même résultat que `x == y`.
///
/// Si le code générique doit simplement fonctionner pour tous les types pouvant fournir une référence au type associé `T`, il est souvent préférable d'utiliser [`AsRef<T>`] car davantage de types peuvent l'implémenter en toute sécurité.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// En tant que collection de données, [`HashMap<K, V>`] possède à la fois des clés et des valeurs.Si les données réelles de la clé sont encapsulées dans un type de gestion quelconque, il devrait cependant toujours être possible de rechercher une valeur en utilisant une référence aux données de la clé.
/// Par exemple, si la clé est une chaîne, elle est probablement stockée avec la carte de hachage en tant que [`String`], alors qu'il devrait être possible de rechercher à l'aide d'un [`&str`][`str`].
/// Ainsi, `insert` doit fonctionner sur un `String` tandis que `get` doit pouvoir utiliser un `&str`.
///
/// Légèrement simplifié, les parties pertinentes de `HashMap<K, V>` ressemblent à ceci:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // champs omis
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// La carte de hachage entière est générique sur un type de clé `K`.Étant donné que ces clés sont stockées avec la carte de hachage, ce type doit posséder les données de la clé.
/// Lors de l'insertion d'une paire clé-valeur, la carte reçoit un tel `K` et doit trouver le compartiment de hachage correct et vérifier si la clé est déjà présente en fonction de ce `K`.Il nécessite donc `K: Hash + Eq`.
///
/// Cependant, lors de la recherche d'une valeur dans la carte, le fait de devoir fournir une référence à un `K` comme clé à rechercher nécessiterait de toujours créer une telle valeur possédée.
/// Pour les clés de chaîne, cela signifierait qu'une valeur `String` doit être créée uniquement pour la recherche des cas où seul un `str` est disponible.
///
/// Au lieu de cela, la méthode `get` est générique sur le type des données de clé sous-jacentes, appelées `Q` dans la signature de méthode ci-dessus.Il indique que `K` emprunte en tant que `Q` en exigeant que `K: Borrow<Q>`.
/// En exigeant en plus `Q: Hash + Eq`, il signale l'exigence que `K` et `Q` aient des implémentations des `Hash` et `Eq` traits qui produisent des résultats identiques.
///
/// L'implémentation de `get` repose notamment sur des implémentations identiques de `Hash` en déterminant le compartiment de hachage de la clé en appelant `Hash::hash` sur la valeur `Q` alors même qu'il a inséré la clé en fonction de la valeur de hachage calculée à partir de la valeur `K`.
///
///
/// En conséquence, la mappe de hachage est interrompue si un `K` encapsulant une valeur `Q` produit un hachage différent de `Q`.Par exemple, imaginez que vous ayez un type qui encapsule une chaîne mais compare les lettres ASCII en ignorant leur casse:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Étant donné que deux valeurs égales doivent produire la même valeur de hachage, l'implémentation de `Hash` doit également ignorer la casse ASCII:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// `CaseInsensitiveString` peut-il implémenter `Borrow<str>`?Il peut certainement fournir une référence à une tranche de chaîne via sa chaîne détenue.
/// Mais comme son implémentation `Hash` diffère, il se comporte différemment de `str` et ne doit donc pas, en fait, implémenter `Borrow<str>`.
/// S'il souhaite autoriser d'autres personnes à accéder au `str` sous-jacent, il peut le faire via `AsRef<str>` qui ne comporte aucune exigence supplémentaire.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Emprunte immuablement à une valeur détenue.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// Un trait pour emprunter mutuellement des données.
///
/// En tant que compagnon de [`Borrow<T>`], ce trait permet à un type d'emprunter comme type sous-jacent en fournissant une référence mutable.
/// Voir [`Borrow<T>`] pour plus d'informations sur l'emprunt comme un autre type.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Emprunte mutuellement à une valeur détenue.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}