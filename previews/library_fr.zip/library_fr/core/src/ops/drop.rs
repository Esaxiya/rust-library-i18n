/// Code personnalisé dans le destructeur.
///
/// Lorsqu'une valeur n'est plus nécessaire, Rust exécutera un "destructor" sur cette valeur.
/// La manière la plus courante pour laquelle une valeur n'est plus nécessaire est lorsqu'elle est hors de portée.Les destructeurs peuvent toujours fonctionner dans d'autres circonstances, mais nous allons nous concentrer sur la portée des exemples ici.
/// Pour en savoir plus sur certains de ces autres cas, veuillez consulter la section [the reference] sur les destructeurs.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Ce destructeur se compose de deux composants:
/// - Un appel à `Drop::drop` pour cette valeur, si ce `Drop` trait spécial est implémenté pour son type.
/// - Le "drop glue" généré automatiquement qui appelle récursivement les destructeurs de tous les champs de cette valeur.
///
/// Comme Rust appelle automatiquement les destructeurs de tous les champs contenus, vous n'avez pas à implémenter `Drop` dans la plupart des cas.
/// Mais il y a des cas où cela est utile, par exemple pour les types qui gèrent directement une ressource.
/// Cette ressource peut être de la mémoire, un descripteur de fichier, une socket réseau.
/// Une fois qu'une valeur de ce type ne sera plus utilisée, elle devrait "clean up" sa ressource en libérant la mémoire ou en fermant le fichier ou le socket.
/// C'est le travail d'un destructeur, et donc le travail de `Drop::drop`.
///
/// ## Examples
///
/// Pour voir les destructeurs en action, jetons un œil au programme suivant:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust appellera d'abord `Drop::drop` pour `_x`, puis pour `_x.one` et `_x.two`, ce qui signifie que l'exécution de cette opération imprimera
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Même si on supprime l'implémentation de `Drop` pour `HasTwoDrop`, les destructeurs de ses champs sont toujours appelés.
/// Cela entraînerait
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Vous ne pouvez pas appeler `Drop::drop` vous-même
///
/// Étant donné que `Drop::drop` est utilisé pour nettoyer une valeur, il peut être dangereux d'utiliser cette valeur après l'appel de la méthode.
/// Comme `Drop::drop` ne prend pas possession de son entrée, Rust empêche les abus en ne vous permettant pas d'appeler directement `Drop::drop`.
///
/// En d'autres termes, si vous essayez d'appeler explicitement `Drop::drop` dans l'exemple ci-dessus, vous obtiendrez une erreur du compilateur.
///
/// Si vous souhaitez appeler explicitement le destructeur d'une valeur, [`mem::drop`] peut être utilisé à la place.
///
/// [`mem::drop`]: drop
///
/// ## Ordre de baisse
///
/// Lequel de nos deux `HasDrop` tombe en premier, cependant?Pour les structures, c'est le même ordre dans lequel elles sont déclarées: d'abord `one`, puis `two`.
/// Si vous souhaitez essayer cela vous-même, vous pouvez modifier `HasDrop` ci-dessus pour contenir des données, comme un entier, puis l'utiliser dans le `println!` à l'intérieur de `Drop`.
/// Ce comportement est garanti par la langue.
///
/// Contrairement aux structures, les variables locales sont supprimées dans l'ordre inverse:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Cela imprimera
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Veuillez consulter [the reference] pour les règles complètes.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` et `Drop` sont exclusifs
///
/// Vous ne pouvez pas implémenter à la fois [`Copy`] et `Drop` sur le même type.Les types qui sont `Copy` sont implicitement dupliqués par le compilateur, ce qui rend très difficile de prédire quand et à quelle fréquence les destructeurs seront exécutés.
///
/// En tant que tels, ces types ne peuvent pas avoir de destructeurs.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Exécute le destructeur pour ce type.
    ///
    /// Cette méthode est appelée implicitement lorsque la valeur sort de la portée et ne peut pas être appelée explicitement (il s'agit de l'erreur du compilateur [E0040]).
    /// Cependant, la fonction [`mem::drop`] du prelude peut être utilisée pour appeler l'implémentation `Drop` de l'argument.
    ///
    /// Lorsque cette méthode a été appelée, `self` n'a pas encore été désalloué.
    /// Cela n'arrive qu'après la fin de la méthode.
    /// Si ce n'était pas le cas, `self` serait une référence pendante.
    ///
    /// # Panics
    ///
    /// Étant donné qu'un [`panic!`] appellera `drop` lors de son déroulement, tout [`panic!`] dans une implémentation `drop` sera probablement abandonné.
    ///
    /// Notez que même si ce panics, la valeur est considérée comme supprimée;
    /// vous ne devez pas provoquer l'appel de `drop`.
    /// Cela est normalement géré automatiquement par le compilateur, mais lors de l'utilisation de code non sécurisé, cela peut parfois se produire involontairement, en particulier lors de l'utilisation de [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}