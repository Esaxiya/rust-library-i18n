use crate::marker::Unpin;
use crate::pin::Pin;

/// Le résultat d'une reprise du générateur.
///
/// Cette énumération est renvoyée par la méthode `Generator::resume` et indique les valeurs de retour possibles d'un générateur.
/// Actuellement, cela correspond soit à un point de suspension (`Yielded`), soit à un point de terminaison (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Le générateur suspendu avec une valeur.
    ///
    /// Cet état indique qu'un générateur a été suspendu et correspond généralement à une instruction `yield`.
    /// La valeur fournie dans cette variante correspond à l'expression transmise à `yield` et permet aux générateurs de fournir une valeur à chaque fois qu'ils produisent.
    ///
    ///
    Yielded(Y),

    /// Le générateur complété avec une valeur de retour.
    ///
    /// Cet état indique qu'un générateur a terminé l'exécution avec la valeur fournie.
    /// Une fois qu'un générateur a renvoyé `Complete`, il est considéré comme une erreur de programmeur d'appeler à nouveau `resume`.
    ///
    Complete(R),
}

/// Le trait implémenté par des types de générateurs intégrés.
///
/// Les générateurs, également appelés coroutines, sont actuellement une fonctionnalité de langage expérimental dans Rust.
/// Les générateurs ajoutés dans [RFC 2033] sont actuellement destinés à fournir principalement un bloc de construction pour la syntaxe async/await, mais s'étendent probablement à fournir également une définition ergonomique pour les itérateurs et autres primitives.
///
///
/// La syntaxe et la sémantique des générateurs sont instables et nécessiteront un RFC supplémentaire pour la stabilisation.À ce stade, cependant, la syntaxe est semblable à une fermeture:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Plus de documentation sur les générateurs peut être trouvée dans le livre instable.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Le type de valeur produit par ce générateur.
    ///
    /// Ce type associé correspond à l'expression `yield` et aux valeurs qui peuvent être renvoyées à chaque fois qu'un générateur cède.
    ///
    /// Par exemple, un itérateur en tant que générateur aurait probablement ce type en tant que `T`, le type étant itéré.
    ///
    type Yield;

    /// Le type de valeur renvoyé par ce générateur.
    ///
    /// Cela correspond au type renvoyé par un générateur avec une instruction `return` ou implicitement comme dernière expression d'un littéral de générateur.
    /// Par exemple, futures l'utilisera comme `Result<T, E>` car il représente un future terminé.
    ///
    ///
    type Return;

    /// Reprend l'exécution de ce générateur.
    ///
    /// Cette fonction reprendra l'exécution du générateur ou démarrera l'exécution si ce n'est déjà fait.
    /// Cet appel retournera au dernier point de suspension du générateur, reprenant l'exécution à partir du dernier `yield`.
    /// Le générateur continuera à s'exécuter jusqu'à ce qu'il cède ou retourne, auquel point cette fonction retournera.
    ///
    /// # Valeur de retour
    ///
    /// L'énumération `GeneratorState` renvoyée par cette fonction indique dans quel état se trouve le générateur au retour.
    /// Si la variante `Yielded` est renvoyée, le générateur a atteint un point de suspension et une valeur a été renvoyée.
    /// Les générateurs dans cet état sont disponibles pour une reprise ultérieure.
    ///
    /// Si `Complete` est renvoyé, le générateur a complètement terminé avec la valeur fournie.La reprise du générateur est invalide.
    ///
    /// # Panics
    ///
    /// Cette fonction peut panic si elle est appelée après que la variante `Complete` a été renvoyée précédemment.
    /// Bien que les littéraux de générateur dans le langage soient garantis à panic lors de la reprise après `Complete`, cela n'est pas garanti pour toutes les implémentations du `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}