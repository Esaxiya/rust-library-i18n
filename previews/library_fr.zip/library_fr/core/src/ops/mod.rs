//! Opérateurs surchargeables.
//!
//! L'implémentation de ces traits vous permet de surcharger certains opérateurs.
//!
//! Certains de ces traits sont importés par le prelude, ils sont donc disponibles dans tous les programmes Rust.Seuls les opérateurs soutenus par traits peuvent être surchargés.
//! Par exemple, l'opérateur d'addition (`+`) peut être surchargé via le [`Add`] trait, mais comme l'opérateur d'affectation (`=`) n'a pas de support trait, il n'y a aucun moyen de surcharger sa sémantique.
//! De plus, ce module ne fournit aucun mécanisme pour créer de nouveaux opérateurs.
//! Si une surcharge sans trait ou des opérateurs personnalisés sont nécessaires, vous devriez vous tourner vers des macros ou des plugins de compilateur pour étendre la syntaxe de Rust.
//!
//! Les implémentations de l'opérateur traits ne devraient pas être surprenantes dans leurs contextes respectifs, en gardant à l'esprit leurs significations habituelles et [operator precedence].
//! Par exemple, lors de l'implémentation de [`Mul`], l'opération doit avoir une certaine ressemblance avec la multiplication (et partager les propriétés attendues comme l'associativité).
//!
//! Notez que les opérateurs `&&` et `||` court-circuitent, c'est-à-dire qu'ils n'évaluent leur deuxième opérande que s'il contribue au résultat.Étant donné que ce comportement n'est pas applicable par traits, `&&` et `||` ne sont pas pris en charge en tant qu'opérateurs surchargeables.
//!
//! De nombreux opérateurs prennent leurs opérandes par valeur.Dans des contextes non génériques impliquant des types intégrés, ce n'est généralement pas un problème.
//! Cependant, l'utilisation de ces opérateurs dans du code générique nécessite une certaine attention si les valeurs doivent être réutilisées au lieu de laisser les opérateurs les consommer.Une option consiste à utiliser occasionnellement [`clone`].
//! Une autre option consiste à s'appuyer sur les types impliqués fournissant des implémentations d'opérateurs supplémentaires pour les références.
//! Par exemple, pour un type défini par l'utilisateur `T` qui est censé prendre en charge l'ajout, il est probablement judicieux que `T` et `&T` implémentent les traits [`Add<T>`][`Add`] et [`Add<&T>`][`Add`] afin que le code générique puisse être écrit sans clonage inutile.
//!
//!
//! # Examples
//!
//! Cet exemple crée une structure `Point` qui implémente [`Add`] et [`Sub`], puis montre l'ajout et la soustraction de deux points.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Consultez la documentation de chaque trait pour un exemple d'implémentation.
//!
//! Les [`Fn`], [`FnMut`] et [`FnOnce`] traits sont implémentés par des types qui peuvent être appelés comme des fonctions.Notez que [`Fn`] prend `&self`, [`FnMut`] prend `&mut self` et [`FnOnce`] prend `self`.
//! Celles-ci correspondent aux trois types de méthodes qui peuvent être appelées sur une instance: call-by-reference, call-by-mutable-reference et call-by-value.
//! L'utilisation la plus courante de ces traits est d'agir comme des limites à des fonctions de niveau supérieur qui prennent des fonctions ou des fermetures comme arguments.
//!
//! Prenant un [`Fn`] comme paramètre:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Prenant un [`FnMut`] comme paramètre:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Prenant un [`FnOnce`] comme paramètre:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` consomme ses variables capturées, il ne peut donc pas être exécuté plus d'une fois
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Tenter d'appeler à nouveau `func()` générera une erreur `use of moved value` pour `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` ne peut plus être invoqué à ce stade
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;