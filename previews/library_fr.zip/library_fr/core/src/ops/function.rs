/// La version de l'opérateur d'appel qui prend un récepteur immuable.
///
/// Les instances de `Fn` peuvent être appelées à plusieurs reprises sans état de mutation.
///
/// *Ce trait (`Fn`) ne doit pas être confondu avec [function pointers] (`fn`).*
///
/// `Fn` est implémenté automatiquement par des fermetures qui ne prennent que des références immuables aux variables capturées ou ne capturent rien du tout, ainsi que (safe) [function pointers] (avec quelques mises en garde, voir leur documentation pour plus de détails).
///
/// De plus, pour tout type `F` qui implémente `Fn`, `&F` implémente également `Fn`.
///
/// Puisque [`FnMut`] et [`FnOnce`] sont tous deux des supertraits de `Fn`, toute instance de `Fn` peut être utilisée comme paramètre là où un [`FnMut`] ou [`FnOnce`] est attendu.
///
/// Utilisez `Fn` comme borne lorsque vous souhaitez accepter un paramètre de type de fonction et que vous devez l'appeler à plusieurs reprises et sans mutation d'état (par exemple, lors de son appel simultané).
/// Si vous n'avez pas besoin de telles exigences strictes, utilisez [`FnMut`] ou [`FnOnce`] comme limites.
///
/// Voir le [chapter on closures in *The Rust Programming Language*][book] pour plus d'informations sur ce sujet.
///
/// A noter également la syntaxe spéciale pour `Fn` traits (par exemple
/// `Fn(usize, bool) -> usize`).Les personnes intéressées par les détails techniques peuvent se référer à [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Appeler une fermeture
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Utilisation d'un paramètre `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // afin que regex puisse compter que `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Effectue l'opération d'appel.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// La version de l'opérateur d'appel qui accepte un récepteur mutable.
///
/// Les instances de `FnMut` peuvent être appelées à plusieurs reprises et peuvent changer d'état.
///
/// `FnMut` est implémenté automatiquement par des fermetures qui prennent des références mutables à des variables capturées, ainsi que tous les types qui implémentent [`Fn`], par exemple (safe) [function pointers] (puisque `FnMut` est un supertrait de [`Fn`]).
/// De plus, pour tout type `F` qui implémente `FnMut`, `&mut F` implémente également `FnMut`.
///
/// Puisque [`FnOnce`] est un supertrait de `FnMut`, toute instance de `FnMut` peut être utilisée là où un [`FnOnce`] est attendu, et puisque [`Fn`] est un sous-portrait de `FnMut`, toute instance de [`Fn`] peut être utilisée là où `FnMut` est attendu.
///
/// Utilisez `FnMut` comme borne lorsque vous souhaitez accepter un paramètre de type de fonction et que vous devez l'appeler à plusieurs reprises, tout en lui permettant de muter l'état.
/// Si vous ne voulez pas que le paramètre mute l'état, utilisez [`Fn`] comme borne;si vous n'avez pas besoin de l'appeler à plusieurs reprises, utilisez [`FnOnce`].
///
/// Voir le [chapter on closures in *The Rust Programming Language*][book] pour plus d'informations sur ce sujet.
///
/// A noter également la syntaxe spéciale pour `Fn` traits (par exemple
/// `Fn(usize, bool) -> usize`).Les personnes intéressées par les détails techniques peuvent se référer à [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Appel à une fermeture capturant mutuellement
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Utilisation d'un paramètre `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // afin que regex puisse compter que `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Effectue l'opération d'appel.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// La version de l'opérateur d'appel qui prend un récepteur par valeur.
///
/// Les instances de `FnOnce` peuvent être appelées, mais peuvent ne pas être appelées plusieurs fois.Pour cette raison, si la seule chose connue à propos d'un type est qu'il implémente `FnOnce`, il ne peut être appelé qu'une seule fois.
///
/// `FnOnce` est implémenté automatiquement par des fermetures qui pourraient consommer des variables capturées, ainsi que tous les types qui implémentent [`FnMut`], par exemple (safe) [function pointers] (puisque `FnOnce` est un supertrait de [`FnMut`]).
///
///
/// Puisque [`Fn`] et [`FnMut`] sont des sous-extraits de `FnOnce`, toute instance de [`Fn`] ou [`FnMut`] peut être utilisée là où un `FnOnce` est attendu.
///
/// Utilisez `FnOnce` comme borne lorsque vous souhaitez accepter un paramètre de type de fonction et que vous ne devez l'appeler qu'une seule fois.
/// Si vous devez appeler le paramètre à plusieurs reprises, utilisez [`FnMut`] comme borne;si vous en avez également besoin pour ne pas muter l'état, utilisez [`Fn`].
///
/// Voir le [chapter on closures in *The Rust Programming Language*][book] pour plus d'informations sur ce sujet.
///
/// A noter également la syntaxe spéciale pour `Fn` traits (par exemple
/// `Fn(usize, bool) -> usize`).Les personnes intéressées par les détails techniques peuvent se référer à [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Utilisation d'un paramètre `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` consomme ses variables capturées, il ne peut donc pas être exécuté plus d'une fois.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Tenter d'appeler à nouveau `func()` générera une erreur `use of moved value` pour `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` ne peut plus être invoqué à ce stade
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // afin que regex puisse compter que `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Le type renvoyé après que l'opérateur d'appel est utilisé.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Effectue l'opération d'appel.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}