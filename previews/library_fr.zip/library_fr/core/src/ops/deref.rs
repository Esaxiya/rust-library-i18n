/// Utilisé pour les opérations de déréférencement immuables, comme `*v`.
///
/// En plus d'être utilisé pour des opérations de déréférencement explicites avec l'opérateur (unary) `*` dans des contextes immuables, `Deref` est également utilisé implicitement par le compilateur dans de nombreuses circonstances.
/// Ce mécanisme s'appelle ['`Deref` coercion'][more].
/// Dans les contextes mutables, [`DerefMut`] est utilisé.
///
/// L'implémentation de `Deref` pour les pointeurs intelligents facilite l'accès aux données derrière eux, c'est pourquoi ils implémentent `Deref`.
/// D'autre part, les règles concernant `Deref` et [`DerefMut`] ont été conçues spécifiquement pour accueillir les pointeurs intelligents.
/// Pour cette raison,**`Deref` ne doit être implémenté que pour les pointeurs intelligents** pour éviter toute confusion.
///
/// Pour des raisons similaires,**ce trait ne devrait jamais échouer**.Un échec lors du déréférencement peut être extrêmement déroutant lorsque `Deref` est appelé implicitement.
///
/// # En savoir plus sur la coercition `Deref`
///
/// Si `T` implémente `Deref<Target = U>` et que `x` est une valeur de type `T`, alors:
///
/// * Dans des contextes immuables, `*x` (où `T` n'est ni une référence ni un pointeur brut) est équivalent à `* Deref::deref(&x)`.
/// * Les valeurs de type `&T` sont forcées à des valeurs de type `&U`
/// * `T` implémente implicitement toutes les méthodes (immutable) de type `U`.
///
/// Pour plus de détails, visitez [the chapter in *The Rust Programming Language*][book] ainsi que les sections de référence sur [the dereference operator][ref-deref-op], [method resolution] et [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Une structure avec un seul champ accessible en déréférençant la structure.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Le type résultant après le déréférencement.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Déréférence la valeur.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Utilisé pour les opérations de déréférencement mutables, comme dans `*v = 1;`.
///
/// En plus d'être utilisé pour des opérations de déréférencement explicites avec l'opérateur (unary) `*` dans des contextes mutables, `DerefMut` est également utilisé implicitement par le compilateur dans de nombreuses circonstances.
/// Ce mécanisme s'appelle ['`Deref` coercion'][more].
/// Dans des contextes immuables, [`Deref`] est utilisé.
///
/// L'implémentation de `DerefMut` pour les pointeurs intelligents facilite la mutation des données derrière eux, c'est pourquoi ils implémentent `DerefMut`.
/// D'autre part, les règles concernant [`Deref`] et `DerefMut` ont été conçues spécifiquement pour accueillir les pointeurs intelligents.
/// Pour cette raison,**`DerefMut` ne doit être implémenté que pour les pointeurs intelligents** pour éviter toute confusion.
///
/// Pour des raisons similaires,**ce trait ne devrait jamais échouer**.Un échec lors du déréférencement peut être extrêmement déroutant lorsque `DerefMut` est appelé implicitement.
///
/// # En savoir plus sur la coercition `Deref`
///
/// Si `T` implémente `DerefMut<Target = U>` et que `x` est une valeur de type `T`, alors:
///
/// * Dans les contextes mutables, `*x` (où `T` n'est ni une référence ni un pointeur brut) est équivalent à `* DerefMut::deref_mut(&mut x)`.
/// * Les valeurs de type `&mut T` sont forcées à des valeurs de type `&mut U`
/// * `T` implémente implicitement toutes les méthodes (mutable) de type `U`.
///
/// Pour plus de détails, visitez [the chapter in *The Rust Programming Language*][book] ainsi que les sections de référence sur [the dereference operator][ref-deref-op], [method resolution] et [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Une structure avec un seul champ qui est modifiable en déréférençant la structure.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Déréférence mutuellement la valeur.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Indique qu'une structure peut être utilisée comme récepteur de méthode, sans la fonctionnalité `arbitrary_self_types`.
///
/// Ceci est implémenté par les types de pointeurs stdlib tels que `Box<T>`, `Rc<T>`, `&T` et `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}