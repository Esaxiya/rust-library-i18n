use crate::marker::Unsize;

/// Trait qui indique qu'il s'agit d'un pointeur ou d'un wrapper pour un, où le redimensionnement peut être effectué sur la pointee.
///
/// Voir les [DST coercion RFC][dst-coerce] et [the nomicon entry on coercion][nomicon-coerce] pour plus de détails.
///
/// Pour les types de pointeurs intégrés, les pointeurs vers `T` contraindront les pointeurs vers `U` si `T: Unsize<U>` en convertissant un pointeur fin en un pointeur gras.
///
/// Pour les types personnalisés, la coercition fonctionne ici en contraignant `Foo<T>` à `Foo<U>` à condition qu'un impl de `CoerceUnsized<Foo<U>> for Foo<T>` existe.
/// Un tel impl ne peut être écrit que si `Foo<T>` n'a qu'un seul champ non fantôme impliquant `T`.
/// Si le type de ce champ est `Bar<T>`, une implémentation de `CoerceUnsized<Bar<U>> for Bar<T>` doit exister.
/// La coercition fonctionnera en forçant le champ `Bar<T>` dans `Bar<U>` et en remplissant le reste des champs de `Foo<T>` pour créer un `Foo<U>`.
/// Cela permettra d'accéder efficacement à un champ de pointeur et de le contraindre.
///
/// En règle générale, pour les pointeurs intelligents, vous implémenterez `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, avec un `?Sized` facultatif lié à `T` lui-même.
/// Pour les types de wrapper qui incorporent directement `T` comme `Cell<T>` et `RefCell<T>`, vous pouvez directement implémenter `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Cela permettra aux coercitions de types comme `Cell<Box<T>>` de fonctionner.
///
/// [`Unsize`][unsize] est utilisé pour marquer les types qui peuvent être forcés aux DST s'ils sont derrière des pointeurs.Il est implémenté automatiquement par le compilateur.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Ceci est utilisé pour la sécurité des objets, pour vérifier que le type de récepteur d'une méthode peut être distribué.
///
/// Un exemple d'implémentation du trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}