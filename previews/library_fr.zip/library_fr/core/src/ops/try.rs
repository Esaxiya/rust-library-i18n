/// Un trait pour personnaliser le comportement de l'opérateur `?`.
///
/// Un type implémentant `Try` est celui qui a une manière canonique de le voir en termes d'une dichotomie success/failure.
/// Ce trait permet à la fois d'extraire ces valeurs de réussite ou d'échec d'une instance existante et de créer une nouvelle instance à partir d'une valeur de réussite ou d'échec.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Le type de cette valeur lorsqu'elle est considérée comme réussie.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Le type de cette valeur lorsqu'elle est considérée comme ayant échoué.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Applique l'opérateur "?".Un retour de `Ok(t)` signifie que l'exécution doit se poursuivre normalement et le résultat de `?` est la valeur `t`.
    /// Un retour de `Err(e)` signifie que l'exécution doit branch vers le `catch` englobant le plus intérieur, ou revenir de la fonction.
    ///
    /// Si un résultat `Err(e)` est renvoyé, la valeur `e` sera "wrapped" dans le type de retour de la portée englobante (qui doit elle-même implémenter `Try`).
    ///
    /// Plus précisément, la valeur `X::from_error(From::from(e))` est renvoyée, où `X` est le type de retour de la fonction englobante.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Enveloppez une valeur d'erreur pour construire le résultat composite.
    /// Par exemple, `Result::Err(x)` et `Result::from_error(x)` sont équivalents.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Enveloppez une valeur OK pour construire le résultat composite.
    /// Par exemple, `Result::Ok(x)` et `Result::from_ok(x)` sont équivalents.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}