//! Primitive traits et types représentant les propriétés de base des types.
//!
//! Les types Rust peuvent être classés de diverses manières utiles en fonction de leurs propriétés intrinsèques.
//! Ces classifications sont représentées par traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Types qui peuvent être transférés à travers les limites de thread.
///
/// Ce trait est automatiquement implémenté lorsque le compilateur détermine qu'il est approprié.
///
/// Le pointeur de comptage de références [`rc::Rc`][`Rc`] est un exemple de type non «Envoyer».
/// Si deux threads tentent de cloner des [`Rc`] s qui pointent vers la même valeur comptée par référence, ils peuvent essayer de mettre à jour le nombre de références en même temps, ce qui est [undefined behavior][ub] car [`Rc`] n'utilise pas d'opérations atomiques.
///
/// Son cousin [`sync::Arc`][arc] utilise des opérations atomiques (entraînant une surcharge) et est donc `Send`.
///
/// Voir [the Nomicon](../../nomicon/send-and-sync.html) pour plus de détails.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Types avec une taille constante connue au moment de la compilation.
///
/// Tous les paramètres de type ont une limite implicite de `Sized`.La syntaxe spéciale `?Sized` peut être utilisée pour supprimer cette limite si elle n'est pas appropriée.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//erreur: la taille n'est pas implémentée pour [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// La seule exception est le type implicite `Self` d'un trait.
/// Un trait n'a pas de borne `Sized` implicite car cela est incompatible avec [l'objet trait] s où, par définition, le trait doit fonctionner avec tous les implémenteurs possibles, et pourrait donc être de n'importe quelle taille.
///
///
/// Bien que Rust vous permette de lier `Sized` à un trait, vous ne pourrez pas l'utiliser pour former un objet trait plus tard:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // soit y: &dyn Bar= &Impl;//erreur: le trait `Bar` ne peut pas être transformé en objet
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // pour Default, par exemple, qui nécessite que `[T]: !Default` soit évaluable
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Types qui peuvent être "unsized" à un type de taille dynamique.
///
/// Par exemple, le type de tableau dimensionné `[i8; 2]` implémente `Unsize<[i8]>` et `Unsize<dyn fmt::Debug>`.
///
/// Toutes les implémentations de `Unsize` sont fournies automatiquement par le compilateur.
///
/// `Unsize` est implémenté pour:
///
/// - `[T; N]` est `Unsize<[T]>`
/// - `T` est `Unsize<dyn Trait>` lorsque `T: Trait`
/// - `Foo<..., T, ...>` est `Unsize<Foo<..., U, ...>>` si:
///   - `T: Unsize<U>`
///   - Foo est une structure
///   - Seul le dernier champ de `Foo` a un type impliquant `T`
///   - `T` ne fait partie du type d'aucun autre champ
///   - `Bar<T>: Unsize<Bar<U>>`, si le dernier champ de `Foo` est de type `Bar<T>`
///
/// `Unsize` est utilisé avec [`ops::CoerceUnsized`] pour permettre aux conteneurs "user-defined" tels que [`Rc`] de contenir des types de taille dynamique.
/// Voir les [DST coercion RFC][RFC982] et [the nomicon entry on coercion][nomicon-coerce] pour plus de détails.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Obligatoire trait pour les constantes utilisées dans les correspondances de motifs.
///
/// Tout type qui dérive `PartialEq` implémente automatiquement ce trait,*peu importe* si ses paramètres de type implémentent `Eq`.
///
/// Si un élément `const` contient un type qui n'implémente pas ce trait, alors ce type soit (1.) n'implémente pas `PartialEq` (ce qui signifie que la constante ne fournira pas cette méthode de comparaison, dont la génération de code suppose qu'elle est disponible), ou (2.) qu'elle implémente *la sienne* version de `PartialEq` (que nous supposons n'est pas conforme à une comparaison d'égalité structurelle).
///
///
/// Dans l'un ou l'autre des deux scénarios ci-dessus, nous rejetons l'utilisation d'une telle constante dans une correspondance de modèle.
///
/// Voir aussi les [structural match RFC][RFC1445] et [issue 63438] qui ont motivé la migration de la conception basée sur les attributs vers ce trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Obligatoire trait pour les constantes utilisées dans les correspondances de motifs.
///
/// Tout type qui dérive `Eq` implémente automatiquement ce trait,*indépendamment du fait* que ses paramètres de type implémentent `Eq`.
///
/// Il s'agit d'un hack pour contourner une limitation de notre système de types.
///
/// # Background
///
/// Nous voulons exiger que les types de consts utilisés dans les correspondances de modèles aient l'attribut `#[derive(PartialEq, Eq)]`.
///
/// Dans un monde plus idéal, nous pourrions vérifier cette exigence en vérifiant simplement que le type donné implémente à la fois le `StructuralPartialEq` trait *et* le `Eq` trait.
/// Cependant, vous pouvez avoir des ADT qui *font*`derive(PartialEq, Eq)`, et c'est un cas que nous voulons que le compilateur accepte, et pourtant le type de la constante ne parvient pas à implémenter `Eq`.
///
/// À savoir, un cas comme celui-ci:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Le problème dans le code ci-dessus est que `Wrap<fn(&())>` n'implémente pas `PartialEq`, ni `Eq`, car `for <'a> fn(&'a _)` does not implement those traits.)
///
/// Par conséquent, nous ne pouvons pas nous fier à une vérification naïve pour `StructuralPartialEq` et seulement `Eq`.
///
/// Pour contourner ce problème, nous utilisons deux traits séparés injectés par chacun des deux dérivés (`#[derive(PartialEq)]` et `#[derive(Eq)]`) et vérifions que les deux sont présents dans le cadre de la vérification de correspondance structurelle.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Types dont les valeurs peuvent être dupliquées simplement en copiant des bits.
///
/// Par défaut, les liaisons de variables ont une «sémantique de déplacement».Autrement dit:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` a déménagé dans `y` et ne peut donc pas être utilisé
///
/// // println! ("{: ?}", x);//erreur: utilisation de la valeur déplacée
/// ```
///
/// Cependant, si un type implémente `Copy`, il a à la place une `` sémantique de copie '':
///
/// ```
/// // Nous pouvons dériver une implémentation `Copy`.
/// // `Clone` est également nécessaire, car il s'agit d'un supertrait de `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` est une copie de `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Il est important de noter que dans ces deux exemples, la seule différence est de savoir si vous êtes autorisé à accéder à `x` après l'affectation.
/// Sous le capot, une copie et un déplacement peuvent entraîner la copie de bits en mémoire, bien que cela soit parfois optimisé.
///
/// ## Comment puis-je implémenter `Copy`?
///
/// Il existe deux façons d'implémenter `Copy` sur votre type.Le plus simple est d'utiliser `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Vous pouvez également implémenter manuellement `Copy` et `Clone`:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Il y a une petite différence entre les deux: la stratégie `derive` placera également un `Copy` lié aux paramètres de type, ce qui n'est pas toujours souhaité.
///
/// ## Quelle est la différence entre `Copy` et `Clone`?
///
/// Les copies se font implicitement, par exemple dans le cadre d'une affectation `y = x`.Le comportement de `Copy` n'est pas surchargeable;c'est toujours une simple copie bit par bit.
///
/// Le clonage est une action explicite, `x.clone()`.L'implémentation de [`Clone`] peut fournir tout comportement spécifique au type nécessaire pour dupliquer des valeurs en toute sécurité.
/// Par exemple, l'implémentation de [`Clone`] pour [`String`] doit copier le tampon de chaîne pointée dans le tas.
/// Une simple copie au niveau du bit des valeurs [`String`] ne ferait que copier le pointeur, conduisant à un double libre le long de la ligne.
/// Pour cette raison, [`String`] est [`Clone`] mais pas `Copy`.
///
/// [`Clone`] est un supertrait de `Copy`, donc tout ce qui est `Copy` doit également implémenter [`Clone`].
/// Si un type est `Copy`, son implémentation [`Clone`] n'a besoin que de renvoyer `*self` (voir l'exemple ci-dessus).
///
/// ## Quand mon type peut-il être `Copy`?
///
/// Un type peut implémenter `Copy` si tous ses composants implémentent `Copy`.Par exemple, cette structure peut être `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Une structure peut être `Copy` et [`i32`] est `Copy`, donc `Point` est éligible pour être `Copy`.
/// En revanche, considérez
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// La structure `PointList` ne peut pas implémenter `Copy`, car [`Vec<T>`] n'est pas `Copy`.Si nous essayons de dériver une implémentation `Copy`, nous obtiendrons une erreur:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Les références partagées (`&T`) sont également `Copy`, donc un type peut être `Copy`, même s'il contient des références partagées de types `T` qui ne sont *pas*`Copy`.
/// Considérez la structure suivante, qui peut implémenter `Copy`, car elle ne contient qu'une *référence partagée* à notre type `PointList` non-`Copy` ci-dessus:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Quand *ne peut-il pas* mon type être `Copy`?
///
/// Certains types ne peuvent pas être copiés en toute sécurité.Par exemple, la copie de `&mut T` créerait une référence mutable aliasée.
/// Copier [`String`] dupliquerait la responsabilité de gérer le tampon de [`String`], conduisant à un double libre.
///
/// En généralisant ce dernier cas, tout type implémentant [`Drop`] ne peut pas être `Copy`, car il gère une ressource en plus de ses propres octets [`size_of::<T>`].
///
/// Si vous essayez d'implémenter `Copy` sur une structure ou une énumération contenant des données non-«Copie», vous obtiendrez l'erreur [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Quand *devrait* mon type être `Copy`?
///
/// De manière générale, si votre type _can_ implémente `Copy`, il devrait.
/// Gardez à l'esprit, cependant, que la mise en œuvre de `Copy` fait partie de l'API publique de votre type.
/// Si le type peut devenir non-«Copie» dans le future, il pourrait être prudent d'omettre l'implémentation `Copy` maintenant, pour éviter un changement d'API cassant.
///
/// ## Implémenteurs supplémentaires
///
/// En plus du [implementors listed below][impls], les types suivants implémentent également `Copy`:
///
/// * Types d'éléments de fonction (c'est-à-dire les types distincts définis pour chaque fonction)
/// * Types de pointeurs de fonction (par exemple, `fn() -> i32`)
/// * Types de tableaux, pour toutes les tailles, si le type d'élément implémente également `Copy` (par exemple, `[i32; 123456]`)
/// * Types de tuples, si chaque composant implémente également `Copy` (par exemple, `()`, `(i32, bool)`)
/// * Les types de fermeture, s'ils ne capturent aucune valeur de l'environnement ou si toutes ces valeurs capturées implémentent `Copy` elles-mêmes.
///   Notez que les variables capturées par une référence partagée implémentent toujours `Copy` (même si le référent ne le fait pas), tandis que les variables capturées par une référence mutable n'implémentent jamais `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Cela permet de copier un type qui n'implémente pas `Copy` en raison de limites de durée de vie non satisfaites (copie de `A<'_>` uniquement lorsque `A<'static>: Copy` et `A<'_>: Clone`).
// Nous avons cet attribut ici pour le moment uniquement parce qu'il existe un certain nombre de spécialisations existantes sur `Copy` qui existent déjà dans la bibliothèque standard, et il n'y a aucun moyen d'avoir ce comportement en toute sécurité pour le moment.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Dériver une macro générant un impl du trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Types pour lesquels il est sûr de partager des références entre les threads.
///
/// Ce trait est automatiquement implémenté lorsque le compilateur détermine qu'il est approprié.
///
/// La définition précise est: un type `T` est [`Sync`] si et seulement si `&T` est [`Send`].
/// En d'autres termes, s'il n'y a aucune possibilité de [undefined behavior][ub] (y compris les courses de données) lors du passage des références `&T` entre les threads.
///
/// Comme on pouvait s'y attendre, les types primitifs comme [`u8`] et [`f64`] sont tous [`Sync`], de même que les types d'agrégats simples les contenant, comme les tuples, les structs et les énumérations.
/// D'autres exemples de types [`Sync`] de base incluent les types "immutable" tels que `&T` et ceux avec une simple mutabilité héritée, tels que [`Box<T>`][box], [`Vec<T>`][vec] et la plupart des autres types de collections.
///
/// (Les paramètres génériques doivent être [`Sync`] pour que leur conteneur soit [`Sync`].)
///
/// Une conséquence quelque peu surprenante de la définition est que `&mut T` est `Sync` (si `T` est `Sync`) même s'il semble que cela puisse fournir une mutation non synchronisée.
/// L'astuce est qu'une référence mutable derrière une référence partagée (c'est-à-dire `& &mut T`) devient en lecture seule, comme s'il s'agissait d'un `& &T`.
/// Il n'y a donc aucun risque de course aux données.
///
/// Les types qui ne sont pas `Sync` sont ceux qui ont "interior mutability" sous une forme non thread-safe, comme [`Cell`][cell] et [`RefCell`][refcell].
/// Ces types permettent la mutation de leur contenu même via une référence partagée immuable.
/// Par exemple, la méthode `set` sur [`Cell<T>`][cell] prend `&self`, elle ne nécessite donc qu'une référence partagée [`&Cell<T>`][cell].
/// La méthode n'effectue aucune synchronisation, donc [`Cell`][cell] ne peut pas être `Sync`.
///
/// Un autre exemple de type non "Sync" est le pointeur de comptage de références [`Rc`][rc].
/// Compte tenu de n'importe quelle référence [`&Rc<T>`][rc], vous pouvez cloner un nouveau [`Rc<T>`][rc], en modifiant les comptages de références de manière non atomique.
///
/// Pour les cas où l'on a besoin d'une mutabilité intérieure thread-safe, Rust fournit [atomic data types], ainsi qu'un verrouillage explicite via [`sync::Mutex`][mutex] et [`sync::RwLock`][rwlock].
/// Ces types garantissent qu'aucune mutation ne peut provoquer des courses de données, par conséquent les types sont `Sync`.
/// De même, [`sync::Arc`][arc] fournit un analogue thread-safe de [`Rc`][rc].
///
/// Tous les types avec une mutabilité intérieure doivent également utiliser le wrapper [`cell::UnsafeCell`][unsafecell] autour du value(s) qui peut être muté via une référence partagée.
/// A défaut de faire cela, c'est [undefined behavior][ub].
/// Par exemple, [`transmute`][transmute]-ing de `&T` à `&mut T` n'est pas valide.
///
/// Voir [the Nomicon][nomicon-send-and-sync] pour plus de détails sur `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): une fois que le support pour ajouter des notes dans `rustc_on_unimplemented` arrive en version bêta, et il a été étendu pour vérifier si une fermeture est n'importe où dans la chaîne d'exigences, étendez-la comme telle (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Type de taille zéro utilisé pour marquer les choses que "act like" possède un `T`.
///
/// L'ajout d'un champ `PhantomData<T>` à votre type indique au compilateur que votre type agit comme s'il stockait une valeur de type `T`, même si ce n'est pas vraiment le cas.
/// Ces informations sont utilisées lors du calcul de certaines propriétés de sécurité.
///
/// Pour une explication plus détaillée de l'utilisation de `PhantomData<T>`, veuillez consulter [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Une note horrible 👻👻👻
///
/// Bien qu'ils aient tous les deux des noms effrayants, `PhantomData` et les «types fantômes» sont liés, mais pas identiques.Un paramètre de type fantôme est simplement un paramètre de type qui n'est jamais utilisé.
/// Dans Rust, cela amène souvent le compilateur à se plaindre, et la solution est d'ajouter une utilisation "dummy" via `PhantomData`.
///
/// # Examples
///
/// ## Paramètres de durée de vie inutilisés
///
/// Le cas d'utilisation le plus courant de `PhantomData` est peut-être une structure qui a un paramètre de durée de vie inutilisé, généralement dans le cadre d'un code non sécurisé.
/// Par exemple, voici une structure `Slice` qui a deux pointeurs de type `*const T`, pointant vraisemblablement vers un tableau quelque part:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// L'intention est que les données sous-jacentes ne soient valides que pour la durée de vie `'a`, donc `Slice` ne devrait pas survivre à `'a`.
/// Cependant, cette intention n'est pas exprimée dans le code, car il n'y a aucune utilisation de la durée de vie `'a` et par conséquent, il n'est pas clair à quelles données il s'applique.
/// Nous pouvons corriger cela en disant au compilateur d'agir *comme si* la structure `Slice` contenait une référence `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Cela nécessite également à son tour l'annotation `T: 'a`, indiquant que toutes les références dans `T` sont valides pendant toute la durée de vie de `'a`.
///
/// Lors de l'initialisation d'un `Slice`, il vous suffit de fournir la valeur `PhantomData` pour le champ `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Paramètres de type inutilisés
///
/// Il arrive parfois que vous ayez des paramètres de type inutilisés qui indiquent à quel type de données une structure est "tied", même si ces données ne se trouvent pas réellement dans la structure elle-même.
/// Voici un exemple où cela se produit avec [FFI].
/// L'interface étrangère utilise des poignées de type `*mut ()` pour faire référence aux valeurs Rust de différents types.
/// Nous suivons le type Rust en utilisant un paramètre de type phantom sur la structure `ExternalResource` qui encapsule un handle.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Propriété et chèque de dépôt
///
/// L'ajout d'un champ de type `PhantomData<T>` indique que votre type possède des données de type `T`.Cela implique à son tour que lorsque votre type est supprimé, il peut supprimer une ou plusieurs instances du type `T`.
/// Cela a une incidence sur l'analyse [drop check] du compilateur Rust.
///
/// Si votre structure ne *possède* pas en fait les données de type `T`, il est préférable d'utiliser un type de référence, comme `PhantomData<&'a T>` (ideally) ou `PhantomData<*const T>` (si aucune durée de vie ne s'applique), afin de ne pas indiquer la propriété.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// trait interne au compilateur utilisé pour indiquer le type de discriminants d'énumération.
///
/// Ce trait est automatiquement implémenté pour chaque type et n'ajoute aucune garantie à [`mem::Discriminant`].
/// La transmutation entre `DiscriminantKind::Discriminant` et `mem::Discriminant` est un **comportement indéfini**.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Le type du discriminant, qui doit satisfaire le trait bounds requis par `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// trait interne au compilateur utilisé pour déterminer si un type contient un `UnsafeCell` en interne, mais pas via une indirection.
///
/// Cela affecte, par exemple, si un `static` de ce type est placé dans une mémoire statique en lecture seule ou une mémoire statique inscriptible.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Types qui peuvent être déplacés en toute sécurité après avoir été épinglés.
///
/// Rust lui-même n'a aucune notion de types immobiles et considère que les déplacements (par exemple, par affectation ou [`mem::replace`]) sont toujours sûrs.
///
/// Le type [`Pin`][Pin] est utilisé à la place pour empêcher les déplacements dans le système de type.Les pointeurs `P<T>` encapsulés dans l'encapsuleur [`Pin<P<T>>`][Pin] ne peuvent pas être retirés.
/// Consultez la documentation du [`pin` module] pour plus d'informations sur l'épinglage.
///
/// L'implémentation du `Unpin` trait pour `T` lève les restrictions d'épinglage du type, ce qui permet ensuite de déplacer `T` hors de [`Pin<P<T>>`][Pin] avec des fonctions telles que [`mem::replace`].
///
///
/// `Unpin` n'a aucune conséquence pour les données non épinglées.
/// En particulier, [`mem::replace`] déplace volontiers les données `!Unpin` (cela fonctionne pour n'importe quel `&mut T`, pas seulement pour `T: Unpin`).
/// Cependant, vous ne pouvez pas utiliser [`mem::replace`] sur des données encapsulées dans un [`Pin<P<T>>`][Pin] car vous ne pouvez pas obtenir le `&mut T` dont vous avez besoin pour cela, et *c'est* ce qui fait fonctionner ce système.
///
/// Ainsi, par exemple, cela ne peut être fait que sur les types implémentant `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Nous avons besoin d'une référence mutable pour appeler `mem::replace`.
/// // On peut obtenir une telle référence par (implicitly) en invoquant `Pin::deref_mut`, mais cela n'est possible que parce que `String` implémente `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Ce trait est automatiquement implémenté pour presque tous les types.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Un type de marqueur qui n'implémente pas `Unpin`.
///
/// Si un type contient un `PhantomPinned`, il n'implémentera pas `Unpin` par défaut.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Implémentations de `Copy` pour les types primitifs.
///
/// Les implémentations qui ne peuvent pas être décrites dans Rust sont implémentées dans `traits::SelectionContext::copy_clone_conditions()` dans `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Les références partagées peuvent être copiées, mais les références mutables *ne peuvent pas*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}