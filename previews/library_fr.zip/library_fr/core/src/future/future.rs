#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Un future représente un calcul asynchrone.
///
/// Un future est une valeur qui n'a peut-être pas encore fini de calculer.
/// Ce type de "asynchronous value" permet à un thread de continuer à faire un travail utile en attendant que la valeur devienne disponible.
///
///
/// # La méthode `poll`
///
/// La méthode principale de future, `poll`,*tente* de résoudre le future en une valeur finale.
/// Cette méthode ne bloque pas si la valeur n'est pas prête.
/// Au lieu de cela, la tâche en cours est planifiée pour être réveillée lorsqu'il est possible de progresser en effectuant à nouveau un `sondage`.
/// Le `context` passé à la méthode `poll` peut fournir un [`Waker`], qui est un handle pour réveiller la tâche en cours.
///
/// Lorsque vous utilisez un future, vous n'appelez généralement pas `poll` directement, mais à la place `.await` la valeur.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Le type de valeur produite à l'achèvement.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Essayez de résoudre le future à une valeur finale, en enregistrant la tâche en cours pour le réveil si la valeur n'est pas encore disponible.
    ///
    /// # Valeur de retour
    ///
    /// Cette fonction renvoie:
    ///
    /// - [`Poll::Pending`] si le future n'est pas encore prêt
    /// - [`Poll::Ready(val)`] avec le résultat `val` de ce future s'il s'est terminé avec succès.
    ///
    /// Une fois qu'un future est terminé, les clients ne doivent plus le `poll`.
    ///
    /// Lorsqu'un future n'est pas encore prêt, `poll` renvoie `Poll::Pending` et stocke un clone du [`Waker`] copié à partir du [`Context`] actuel.
    /// Ce [`Waker`] est ensuite réveillé une fois que le future peut progresser.
    /// Par exemple, un future attendant qu'une socket devienne lisible appellerait `.clone()` sur le [`Waker`] et le stockerait.
    /// Lorsqu'un signal arrive ailleurs indiquant que le socket est lisible, [`Waker::wake`] est appelé et la tâche du socket future est réveillée.
    /// Une fois qu'une tâche a été réveillée, elle doit tenter à nouveau de `poll` le future, ce qui peut ou non produire une valeur finale.
    ///
    /// Notez que sur plusieurs appels vers `poll`, seul le [`Waker`] du [`Context`] passé à l'appel le plus récent doit être programmé pour recevoir un réveil.
    ///
    /// # Caractéristiques d'exécution
    ///
    /// Futures seuls sont *inertes*;ils doivent être *activement*`interrogés 'pour progresser, ce qui signifie que chaque fois que la tâche en cours est réveillée, elle doit activement re-`poll` en attendant futures qui l'intéresse toujours.
    ///
    /// La fonction `poll` n'est pas appelée à plusieurs reprises dans une boucle serrée-au lieu de cela, elle ne doit être appelée que lorsque le future indique qu'il est prêt à progresser (en appelant `wake()`).
    /// Si vous êtes familier avec les appels système `poll(2)` ou `select(2)` sur Unix, il convient de noter que futures ne souffre généralement *pas* des mêmes problèmes que "all wakeups must poll all events";ils ressemblent plus à `epoll(4)`.
    ///
    /// Une implémentation de `poll` doit s'efforcer de revenir rapidement et ne doit pas bloquer.Le retour rapide évite d'encrasser inutilement les threads ou les boucles d'événements.
    /// S'il est connu à l'avance qu'un appel à `poll` peut prendre un certain temps, le travail doit être déchargé vers un pool de threads (ou quelque chose de similaire) pour s'assurer que `poll` peut revenir rapidement.
    ///
    /// # Panics
    ///
    /// Une fois qu'un future est terminé (retourné `Ready` de `poll`), le fait d'appeler à nouveau sa méthode `poll` peut panic, bloquer pour toujours ou causer d'autres types de problèmes;le `Future` trait n'impose aucune exigence sur les effets d'un tel appel.
    /// Cependant, comme la méthode `poll` n'est pas marquée `unsafe`, les règles habituelles de Rust s'appliquent: les appels ne doivent jamais provoquer de comportement indéfini (corruption de mémoire, utilisation incorrecte des fonctions `unsafe`, etc.), quel que soit l'état du future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}