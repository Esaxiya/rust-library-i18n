#![stable(feature = "futures_api", since = "1.36.0")]

//! Valeurs asynchrones.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Ce type est nécessaire car:
///
/// a) Les générateurs ne peuvent pas implémenter `for<'a, 'b> Generator<&'a mut Context<'b>>`, nous devons donc passer un pointeur brut (voir <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Les pointeurs bruts et `NonNull` ne sont pas `Send` ou `Sync`, donc cela ferait également de chaque future non-Send/Sync, et nous ne le voulons pas.
///
/// Cela simplifie également l'abaissement HIR du `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Enveloppez un générateur dans un future.
///
/// Cette fonction renvoie un `GenFuture` en dessous, mais le cache dans `impl Trait` pour donner de meilleurs messages d'erreur (`impl Future` plutôt que `GenFuture<[closure.....]>`).
///
// Ceci est `const` pour éviter des erreurs supplémentaires après la récupération de `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Nous nous appuyons sur le fait que async/await futures sont immobiles afin de créer des emprunts auto-référentiels dans le générateur sous-jacent.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // SÉCURITÉ: Sûr parce que nous sommes !Unpin + !Drop, et ce n'est qu'une projection de champ.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Reprenez le générateur en transformant le `&mut Context` en un pointeur brut `NonNull`.
            // L'abaissement du `.await` le ramènera en toute sécurité à un `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // SÉCURITÉ: l'appelant doit garantir que `cx.0` est un pointeur valide
    // qui remplit toutes les conditions requises pour une référence mutable.
    unsafe { &mut *cx.0.as_ptr().cast() }
}