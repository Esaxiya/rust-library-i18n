use crate::future::Future;

/// Conversion en `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// La sortie que le future produira à la fin.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Dans quel genre de future sommes-nous en train de transformer cela?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Crée un future à partir d'une valeur.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}