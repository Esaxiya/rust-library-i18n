use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Bien que cette fonction soit utilisée à un seul endroit et que son implémentation puisse être intégrée, les tentatives précédentes de le faire ont ralenti rustc:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Disposition d'un bloc de mémoire.
///
/// Une instance de `Layout` décrit une disposition particulière de la mémoire.
/// Vous construisez un `Layout` en tant qu'entrée à donner à un allocateur.
///
/// Toutes les mises en page ont une taille associée et un alignement de puissance de deux.
///
/// (Notez que les mises en page ne sont *pas* nécessaires pour avoir une taille non nulle, même si `GlobalAlloc` exige que toutes les demandes de mémoire soient de taille différente de zéro.
/// Un appelant doit soit s'assurer que de telles conditions sont remplies, utiliser des allocateurs spécifiques avec des exigences plus lâches, ou utiliser l'interface `Allocator` plus clémente.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // taille du bloc de mémoire demandé, mesurée en octets.
    size_: usize,

    // alignement du bloc de mémoire demandé, mesuré en octets.
    // nous nous assurons qu'il s'agit toujours d'une puissance de deux, car les API comme `posix_memalign` l'exigent et c'est une contrainte raisonnable à imposer aux constructeurs de Layout.
    //
    //
    // (Cependant, nous n'exigeons pas de manière analogue `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Construit un `Layout` à partir d'un `size` et d'un `align` donnés, ou renvoie `LayoutError` si l'une des conditions suivantes n'est pas remplie:
    ///
    /// * `align` ne doit pas être nul,
    ///
    /// * `align` doit être une puissance de deux,
    ///
    /// * `size`, lorsqu'elle est arrondie au multiple supérieur de `align` le plus proche, ne doit pas dépasser (c'est-à-dire que la valeur arrondie doit être inférieure ou égale à `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (la puissance de deux implique align!=0.)

        // La taille arrondie est:
        //   size_rounded_up=(taille + aligner, 1)&! (aligner, 1);
        //
        // Nous savons d'en haut que align!=0.
        // Si l'ajout (align, 1) ne déborde pas, alors arrondir sera très bien.
        //
        // Inversement,&-masking with! (Align, 1) ne soustraira que les bits de poids faible.
        // Ainsi, si un dépassement se produit avec la somme, le&-mask ne peut pas soustraire suffisamment pour annuler ce dépassement.
        //
        //
        // Ci-dessus implique que la vérification du débordement de sommation est à la fois nécessaire et suffisante.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // SÉCURITÉ: les conditions du `from_size_align_unchecked` ont été
        // vérifié ci-dessus.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Crée une mise en page en contournant toutes les vérifications.
    ///
    /// # Safety
    ///
    /// Cette fonction n'est pas sûre car elle ne vérifie pas les conditions préalables de [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // SÉCURITÉ: l'appelant doit s'assurer que `align` est supérieur à zéro.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// La taille minimale en octets pour un bloc de mémoire de cette disposition.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Alignement d'octets minimum pour un bloc de mémoire de cette disposition.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Construit un `Layout` adapté pour contenir une valeur de type `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // SÉCURITÉ: l'alignement est garanti par Rust pour être une puissance de deux et
        // le combo taille + alignement est garanti pour s'adapter à notre espace d'adressage.
        // En conséquence, utilisez le constructeur non coché ici pour éviter d'insérer du code que panics s'il n'est pas suffisamment optimisé.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produit une mise en page décrivant un enregistrement qui pourrait être utilisé pour allouer une structure de support pour `T` (qui pourrait être un trait ou un autre type non dimensionné comme une tranche).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SÉCURITÉ: voir la justification dans `new` pour savoir pourquoi cela utilise la variante non sécurisée
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produit une mise en page décrivant un enregistrement qui pourrait être utilisé pour allouer une structure de support pour `T` (qui pourrait être un trait ou un autre type non dimensionné comme une tranche).
    ///
    /// # Safety
    ///
    /// Cette fonction ne peut être appelée en toute sécurité que si les conditions suivantes sont réunies:
    ///
    /// - Si `T` est `Sized`, il est toujours possible d'appeler cette fonction en toute sécurité.
    /// - Si la queue non dimensionnée de `T` est:
    ///     - a [slice], alors la longueur de la queue de la tranche doit être un entier initialisé, et la taille de la *valeur entière*(longueur de la queue dynamique + préfixe de taille statique) doit tenir dans `isize`.
    ///     - un [trait object], alors la partie vtable du pointeur doit pointer vers une vtable valide pour le type `T` acquise par une coersion de désencombrement, et la taille de la *valeur entière*(longueur de queue dynamique + préfixe de taille statique) doit tenir dans `isize`.
    ///
    ///     - un (unstable) [extern type], alors cette fonction peut toujours être appelée en toute sécurité, mais elle peut panic ou renvoyer une valeur incorrecte, car la disposition du type externe n'est pas connue.
    ///     C'est le même comportement que [`Layout::for_value`] sur une référence à une queue de type externe.
    ///     - sinon, il n'est pas autorisé à appeler cette fonction.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // SÉCURITÉ: nous transmettons les prérequis de ces fonctions à l'appelant
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SÉCURITÉ: voir la justification dans `new` pour savoir pourquoi cela utilise la variante non sécurisée
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Crée un `NonNull` suspendu, mais bien aligné pour cette mise en page.
    ///
    /// Notez que la valeur du pointeur peut potentiellement représenter un pointeur valide, ce qui signifie qu'il ne doit pas être utilisé comme valeur sentinelle "not yet initialized".
    /// Les types qui allouent paresseusement doivent suivre l'initialisation par d'autres moyens.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // SÉCURITÉ: l'alignement est garanti non nul
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Crée une mise en page décrivant l'enregistrement qui peut contenir une valeur de la même mise en page que `self`, mais qui est également alignée sur l'alignement `align` (mesuré en octets).
    ///
    ///
    /// Si `self` répond déjà à l'alignement prescrit, renvoie `self`.
    ///
    /// Notez que cette méthode n'ajoute aucun remplissage à la taille globale, que la disposition renvoyée ait ou non un alignement différent.
    /// En d'autres termes, si `K` a la taille 16, `K.align_to(32)` aura *toujours* la taille 16.
    ///
    /// Renvoie une erreur si la combinaison de `self.size()` et du `align` donné enfreint les conditions répertoriées dans [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Renvoie la quantité de remplissage que nous devons insérer après `self` pour garantir que l'adresse suivante satisfera `align` (mesurée en octets).
    ///
    /// par exemple, si `self.size()` vaut 9, alors `self.padding_needed_for(4)` renvoie 3, car c'est le nombre minimum d'octets de remplissage requis pour obtenir une adresse alignée sur 4 (en supposant que le bloc de mémoire correspondant commence à une adresse alignée sur 4).
    ///
    ///
    /// La valeur de retour de cette fonction n'a aucune signification si `align` n'est pas une puissance de deux.
    ///
    /// Notez que l'utilité de la valeur renvoyée nécessite que `align` soit inférieur ou égal à l'alignement de l'adresse de départ pour tout le bloc de mémoire alloué.Une façon de satisfaire cette contrainte est de garantir `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // La valeur arrondie est:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // puis nous retournons la différence de remplissage: `len_rounded_up - len`.
        //
        // Nous utilisons l'arithmétique modulaire partout:
        //
        // 1. align est garanti> 0, donc align, 1 est toujours valide.
        //
        // 2.
        // `len + align - 1` peut déborder d'au plus `align - 1`, donc le&-mask avec `!(align - 1)` garantira qu'en cas de débordement, `len_rounded_up` sera lui-même 0.
        //
        //    Ainsi, le remplissage retourné, lorsqu'il est ajouté à `len`, donne 0, ce qui satisfait trivialement l'alignement `align`.
        //
        // (Bien sûr, les tentatives d'allocation de blocs de mémoire dont la taille et le débordement de remplissage de la manière ci-dessus devraient provoquer une erreur de l'allocateur de toute façon.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Crée une mise en page en arrondissant la taille de cette mise en page à un multiple de l'alignement de la mise en page.
    ///
    ///
    /// Cela équivaut à ajouter le résultat de `padding_needed_for` à la taille actuelle de la mise en page.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Cela ne peut pas déborder.Citant l'invariant de Layout:
        // > `size`, arrondi au multiple supérieur de `align` le plus proche,
        // > ne doit pas déborder (c'est-à-dire que la valeur arrondie doit être inférieure à
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Crée une mise en page décrivant l'enregistrement pour les instances `n` de `self`, avec une quantité appropriée de remplissage entre chacune pour garantir que chaque instance reçoit la taille et l'alignement demandés.
    /// En cas de succès, renvoie `(k, offs)` où `k` est la disposition du tableau et `offs` est la distance entre le début de chaque élément du tableau.
    ///
    /// En cas de dépassement arithmétique, renvoie `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Cela ne peut pas déborder.Citant l'invariant de Layout:
        // > `size`, arrondi au multiple supérieur de `align` le plus proche,
        // > ne doit pas déborder (c'est-à-dire que la valeur arrondie doit être inférieure à
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // SÉCURITÉ: self.align est déjà connu pour être valide et alloc_size a été
        // rembourré déjà.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Crée une mise en page décrivant l'enregistrement pour `self` suivi de `next`, y compris tout remplissage nécessaire pour garantir que `next` sera correctement aligné, mais *pas de remplissage de fin*.
    ///
    /// Afin de faire correspondre la mise en page de représentation C `repr(C)`, vous devez appeler `pad_to_align` après avoir étendu la mise en page avec tous les champs.
    /// (Il n'y a aucun moyen de faire correspondre la disposition de représentation Rust par défaut `repr(Rust)`, as it is unspecified.)
    ///
    /// Notez que l'alignement de la mise en page résultante sera le maximum de ceux de `self` et `next`, afin d'assurer l'alignement des deux parties.
    ///
    /// Renvoie `Ok((k, offset))`, où `k` est la présentation de l'enregistrement concaténé et `offset` est l'emplacement relatif, en octets, du début du `next` incorporé dans l'enregistrement concaténé (en supposant que l'enregistrement lui-même commence à l'offset 0).
    ///
    ///
    /// En cas de dépassement arithmétique, renvoie `LayoutError`.
    ///
    /// # Examples
    ///
    /// Pour calculer la disposition d'une structure `#[repr(C)]` et les décalages des champs à partir des dispositions de ses champs:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // N'oubliez pas de finaliser avec `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // tester que ça marche
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Crée une mise en page décrivant l'enregistrement pour les instances `n` de `self`, sans remplissage entre chaque instance.
    ///
    /// Notez que, contrairement à `repeat`, `repeat_packed` ne garantit pas que les instances répétées de `self` seront correctement alignées, même si une instance donnée de `self` est correctement alignée.
    /// En d'autres termes, si la mise en page retournée par `repeat_packed` est utilisée pour allouer un tableau, il n'est pas garanti que tous les éléments du tableau seront correctement alignés.
    ///
    /// En cas de dépassement arithmétique, renvoie `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Crée une mise en page décrivant l'enregistrement pour `self` suivi de `next` sans remplissage supplémentaire entre les deux.
    /// Puisqu'aucun remplissage n'est inséré, l'alignement de `next` n'est pas pertinent et n'est pas incorporé *du tout* dans la mise en page résultante.
    ///
    ///
    /// En cas de dépassement arithmétique, renvoie `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Crée une mise en page décrivant l'enregistrement pour un `[T; n]`.
    ///
    /// En cas de dépassement arithmétique, renvoie `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Les paramètres donnés à `Layout::from_size_align` ou à un autre constructeur `Layout` ne satisfont pas ses contraintes documentées.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (nous en avons besoin pour l'implémentation aval de l'erreur trait)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}