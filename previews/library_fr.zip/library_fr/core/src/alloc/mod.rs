//! API d'allocation de mémoire

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// L'erreur `AllocError` indique un échec d'allocation qui peut être dû à l'épuisement des ressources ou à un problème lors de la combinaison des arguments d'entrée donnés avec cet allocateur.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (nous en avons besoin pour l'implémentation aval de l'erreur trait)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Une implémentation de `Allocator` peut allouer, agrandir, réduire et désallouer des blocs arbitraires de données décrits via [`Layout`][].
///
/// `Allocator` est conçu pour être implémenté sur des ZST, des références ou des pointeurs intelligents, car avoir un allocateur comme `MyAlloc([u8; N])` ne peut pas être déplacé, sans mettre à jour les pointeurs vers la mémoire allouée.
///
/// Contrairement à [`GlobalAlloc`][], les allocations de taille nulle sont autorisées dans `Allocator`.
/// Si un allocateur sous-jacent ne prend pas en charge ceci (comme jemalloc) ou renvoie un pointeur nul (tel que `libc::malloc`), cela doit être intercepté par l'implémentation.
///
/// ### Mémoire actuellement allouée
///
/// Certaines méthodes nécessitent qu'un bloc de mémoire soit *actuellement alloué* via un allocateur.Cela signifie que:
///
/// * l'adresse de départ de ce bloc de mémoire a été précédemment renvoyée par [`allocate`], [`grow`] ou [`shrink`], et
///
/// * le bloc de mémoire n'a pas été désalloué par la suite, où les blocs sont soit désalloués directement en étant passés à [`deallocate`], soit modifiés en étant passés à [`grow`] ou [`shrink`] qui retourne `Ok`.
///
/// Si `grow` ou `shrink` ont renvoyé `Err`, le pointeur passé reste valide.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Ajustement de la mémoire
///
/// Certaines des méthodes nécessitent qu'une mise en page *s'adapte* à un bloc de mémoire.
/// Ce que cela signifie pour une mise en page à "fit" un bloc de mémoire signifie (ou de manière équivalente, pour un bloc de mémoire à "fit" une mise en page) est que les conditions suivantes doivent être remplies:
///
/// * Le bloc doit être alloué avec le même alignement que [`layout.align()`], et
///
/// * Le [`layout.size()`] fourni doit être compris dans la plage `min ..= max`, où:
///   - `min` est la taille de la mise en page la plus récemment utilisée pour allouer le bloc, et
///   - `max` est la dernière taille réelle renvoyée par [`allocate`], [`grow`] ou [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Les blocs mémoire renvoyés par un allocateur doivent pointer vers une mémoire valide et conserver leur validité jusqu'à ce que l'instance et tous ses clones soient supprimés,
///
/// * le clonage ou le déplacement de l'allocateur ne doit pas invalider les blocs de mémoire renvoyés par cet allocateur.Un allocateur cloné doit se comporter comme le même allocateur, et
///
/// * tout pointeur vers un bloc de mémoire qui est [*currently allocated*] peut être passé à toute autre méthode de l'allocateur.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Tente d'allouer un bloc de mémoire.
    ///
    /// En cas de succès, renvoie un [`NonNull<[u8]>`][NonNull] répondant aux garanties de taille et d'alignement de `layout`.
    ///
    /// Le bloc retourné peut avoir une taille plus grande que celle spécifiée par `layout.size()` et peut ou non avoir son contenu initialisé.
    ///
    /// # Errors
    ///
    /// Le renvoi de `Err` indique que la mémoire est épuisée ou que `layout` ne répond pas aux contraintes de taille ou d'alignement de l'allocateur.
    ///
    /// Les implémentations sont encouragées à renvoyer `Err` en cas d'épuisement de la mémoire plutôt que de paniquer ou d'abandonner, mais ce n'est pas une exigence stricte.
    /// (Plus précisément: il est *légal* d'implémenter ce trait au sommet d'une bibliothèque d'allocation native sous-jacente qui abandonne en cas d'épuisement de la mémoire.)
    ///
    /// Les clients souhaitant abandonner le calcul en réponse à une erreur d'allocation sont encouragés à appeler la fonction [`handle_alloc_error`], plutôt que d'appeler directement `panic!` ou similaire.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Se comporte comme `allocate`, mais garantit également que la mémoire renvoyée est initialisée à zéro.
    ///
    /// # Errors
    ///
    /// Le renvoi de `Err` indique que la mémoire est épuisée ou que `layout` ne répond pas aux contraintes de taille ou d'alignement de l'allocateur.
    ///
    /// Les implémentations sont encouragées à renvoyer `Err` en cas d'épuisement de la mémoire plutôt que de paniquer ou d'abandonner, mais ce n'est pas une exigence stricte.
    /// (Plus précisément: il est *légal* d'implémenter ce trait au sommet d'une bibliothèque d'allocation native sous-jacente qui abandonne en cas d'épuisement de la mémoire.)
    ///
    /// Les clients souhaitant abandonner le calcul en réponse à une erreur d'allocation sont encouragés à appeler la fonction [`handle_alloc_error`], plutôt que d'appeler directement `panic!` ou similaire.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // SÉCURITÉ: `alloc` renvoie un bloc de mémoire valide
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Désalloue la mémoire référencée par `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` doit désigner un bloc de mémoire [*currently allocated*] via cet allocateur, et
    /// * `layout` doit [*fit*] ce bloc de mémoire.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Tente d'étendre le bloc de mémoire.
    ///
    /// Renvoie un nouveau [`NonNull<[u8]>`][NonNull] contenant un pointeur et la taille réelle de la mémoire allouée.Le pointeur convient pour contenir les données décrites par `new_layout`.
    /// Pour ce faire, l'allocateur peut étendre l'allocation référencée par `ptr` pour s'adapter à la nouvelle disposition.
    ///
    /// Si cela renvoie `Ok`, alors la propriété du bloc de mémoire référencé par `ptr` a été transférée à cet allocateur.
    /// La mémoire peut ou non avoir été libérée et doit être considérée comme inutilisable à moins qu'elle ne soit à nouveau transférée à l'appelant via la valeur de retour de cette méthode.
    ///
    /// Si cette méthode renvoie `Err`, la propriété du bloc de mémoire n'a pas été transférée à cet allocateur et le contenu du bloc de mémoire n'est pas modifié.
    ///
    /// # Safety
    ///
    /// * `ptr` doit désigner un bloc de mémoire [*currently allocated*] via cet allocateur.
    /// * `old_layout` doit [*fit*] ce bloc de mémoire (l'argument `new_layout` n'a pas besoin de l'adapter.).
    /// * `new_layout.size()` doit être supérieur ou égal à `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Renvoie `Err` si la nouvelle mise en page ne respecte pas la taille de l'allocateur et les contraintes d'alignement de l'allocateur, ou si la croissance échoue dans le cas contraire.
    ///
    /// Les implémentations sont encouragées à renvoyer `Err` en cas d'épuisement de la mémoire plutôt que de paniquer ou d'abandonner, mais ce n'est pas une exigence stricte.
    /// (Plus précisément: il est *légal* d'implémenter ce trait au sommet d'une bibliothèque d'allocation native sous-jacente qui abandonne en cas d'épuisement de la mémoire.)
    ///
    /// Les clients souhaitant abandonner le calcul en réponse à une erreur d'allocation sont encouragés à appeler la fonction [`handle_alloc_error`], plutôt que d'appeler directement `panic!` ou similaire.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SÉCURITÉ: car `new_layout.size()` doit être supérieur ou égal à
        // `old_layout.size()`, l'ancienne et la nouvelle allocation de mémoire sont valides pour les lectures et les écritures d'octets `old_layout.size()`.
        // De plus, comme l'ancienne allocation n'a pas encore été désallouée, elle ne peut pas chevaucher `new_ptr`.
        // Ainsi, l'appel à `copy_nonoverlapping` est sûr.
        // Le contrat de sécurité pour `dealloc` doit être respecté par l'appelant.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Se comporte comme `grow`, mais garantit également que le nouveau contenu est mis à zéro avant d'être renvoyé.
    ///
    /// Le bloc de mémoire contiendra le contenu suivant après un appel réussi à
    /// `grow_zeroed`:
    ///   * Les octets `0..old_layout.size()` sont préservés de l'allocation d'origine.
    ///   * Les octets `old_layout.size()..old_size` seront conservés ou mis à zéro, selon l'implémentation de l'allocateur.
    ///   `old_size` fait référence à la taille du bloc de mémoire avant l'appel `grow_zeroed`, qui peut être supérieure à la taille initialement demandée lors de son allocation.
    ///   * Les octets `old_size..new_size` sont mis à zéro.`new_size` fait référence à la taille du bloc de mémoire renvoyé par l'appel `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` doit désigner un bloc de mémoire [*currently allocated*] via cet allocateur.
    /// * `old_layout` doit [*fit*] ce bloc de mémoire (l'argument `new_layout` n'a pas besoin de l'adapter.).
    /// * `new_layout.size()` doit être supérieur ou égal à `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Renvoie `Err` si la nouvelle mise en page ne respecte pas la taille de l'allocateur et les contraintes d'alignement de l'allocateur, ou si la croissance échoue dans le cas contraire.
    ///
    /// Les implémentations sont encouragées à renvoyer `Err` en cas d'épuisement de la mémoire plutôt que de paniquer ou d'abandonner, mais ce n'est pas une exigence stricte.
    /// (Plus précisément: il est *légal* d'implémenter ce trait au sommet d'une bibliothèque d'allocation native sous-jacente qui abandonne en cas d'épuisement de la mémoire.)
    ///
    /// Les clients souhaitant abandonner le calcul en réponse à une erreur d'allocation sont encouragés à appeler la fonction [`handle_alloc_error`], plutôt que d'appeler directement `panic!` ou similaire.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SÉCURITÉ: car `new_layout.size()` doit être supérieur ou égal à
        // `old_layout.size()`, l'ancienne et la nouvelle allocation de mémoire sont valides pour les lectures et les écritures d'octets `old_layout.size()`.
        // De plus, comme l'ancienne allocation n'a pas encore été désallouée, elle ne peut pas chevaucher `new_ptr`.
        // Ainsi, l'appel à `copy_nonoverlapping` est sûr.
        // Le contrat de sécurité pour `dealloc` doit être respecté par l'appelant.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Tente de réduire le bloc de mémoire.
    ///
    /// Renvoie un nouveau [`NonNull<[u8]>`][NonNull] contenant un pointeur et la taille réelle de la mémoire allouée.Le pointeur convient pour contenir les données décrites par `new_layout`.
    /// Pour ce faire, l'allocateur peut réduire l'allocation référencée par `ptr` pour s'adapter à la nouvelle disposition.
    ///
    /// Si cela renvoie `Ok`, alors la propriété du bloc de mémoire référencé par `ptr` a été transférée à cet allocateur.
    /// La mémoire peut ou non avoir été libérée et doit être considérée comme inutilisable à moins qu'elle ne soit à nouveau transférée à l'appelant via la valeur de retour de cette méthode.
    ///
    /// Si cette méthode renvoie `Err`, la propriété du bloc de mémoire n'a pas été transférée à cet allocateur et le contenu du bloc de mémoire n'est pas modifié.
    ///
    /// # Safety
    ///
    /// * `ptr` doit désigner un bloc de mémoire [*currently allocated*] via cet allocateur.
    /// * `old_layout` doit [*fit*] ce bloc de mémoire (l'argument `new_layout` n'a pas besoin de l'adapter.).
    /// * `new_layout.size()` doit être inférieur ou égal à `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Renvoie `Err` si la nouvelle mise en page ne respecte pas la taille de l'allocateur et les contraintes d'alignement de l'allocateur, ou si la réduction échoue dans le cas contraire.
    ///
    /// Les implémentations sont encouragées à renvoyer `Err` en cas d'épuisement de la mémoire plutôt que de paniquer ou d'abandonner, mais ce n'est pas une exigence stricte.
    /// (Plus précisément: il est *légal* d'implémenter ce trait au sommet d'une bibliothèque d'allocation native sous-jacente qui abandonne en cas d'épuisement de la mémoire.)
    ///
    /// Les clients souhaitant abandonner le calcul en réponse à une erreur d'allocation sont encouragés à appeler la fonction [`handle_alloc_error`], plutôt que d'appeler directement `panic!` ou similaire.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SÉCURITÉ: parce que `new_layout.size()` doit être inférieur ou égal à
        // `old_layout.size()`, l'ancienne et la nouvelle allocation de mémoire sont valides pour les lectures et les écritures d'octets `new_layout.size()`.
        // De plus, comme l'ancienne allocation n'a pas encore été désallouée, elle ne peut pas chevaucher `new_ptr`.
        // Ainsi, l'appel à `copy_nonoverlapping` est sûr.
        // Le contrat de sécurité pour `dealloc` doit être respecté par l'appelant.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Crée un adaptateur "by reference" pour cette instance de `Allocator`.
    ///
    /// L'adaptateur retourné implémente également `Allocator` et l'empruntera simplement.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // SÉCURITÉ: le contrat de sécurité doit être respecté par l'appelant
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SÉCURITÉ: le contrat de sécurité doit être respecté par l'appelant
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SÉCURITÉ: le contrat de sécurité doit être respecté par l'appelant
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SÉCURITÉ: le contrat de sécurité doit être respecté par l'appelant
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}