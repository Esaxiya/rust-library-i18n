use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Un allocateur de mémoire qui peut être enregistré comme bibliothèque standard par défaut via l'attribut `#[global_allocator]`.
///
/// Certaines méthodes nécessitent qu'un bloc de mémoire soit *actuellement alloué* via un allocateur.Cela signifie que:
///
/// * l'adresse de départ de ce bloc de mémoire a été précédemment renvoyée par un appel précédent à une méthode d'allocation telle que `alloc`, et
///
/// * le bloc de mémoire n'a pas été désalloué par la suite, où les blocs sont désalloués soit en étant passés à une méthode de désallocation telle que `dealloc` soit en étant passés à une méthode de réallocation qui renvoie un pointeur non nul.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// Le `GlobalAlloc` trait est un `unsafe` trait pour un certain nombre de raisons, et les réalisateurs doivent s'assurer qu'ils adhèrent à ces contrats:
///
/// * C'est un comportement indéfini si les allocateurs globaux se déroulent.Cette restriction peut être levée dans le future, mais actuellement un panic de l'une de ces fonctions peut conduire à une insécurité de la mémoire.
///
/// * `Layout` les requêtes et les calculs en général doivent être corrects.Les appelants de ce trait sont autorisés à se fier aux contrats définis pour chaque méthode, et les réalisateurs doivent s'assurer que ces contrats restent vrais.
///
/// * Vous ne pouvez pas vous fier aux allocations qui se produisent réellement, même s'il existe des allocations de tas explicites dans la source.
/// L'optimiseur peut détecter des allocations inutilisées qu'il peut soit éliminer entièrement, soit se déplacer vers la pile et ainsi ne jamais appeler l'allocateur.
/// L'optimiseur peut en outre supposer que l'allocation est infaillible, de sorte que le code qui échouait en raison d'échecs d'allocateur peut maintenant fonctionner soudainement parce que l'optimiseur a contourné le besoin d'une allocation.
/// Plus concrètement, l'exemple de code suivant n'est pas valable, que votre allocateur personnalisé autorise ou non le comptage du nombre d'allocations.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Notez que les optimisations mentionnées ci-dessus ne sont pas la seule optimisation qui puisse être appliquée.Vous ne pouvez généralement pas compter sur les allocations de tas si elles peuvent être supprimées sans modifier le comportement du programme.
///   Le fait que les allocations se produisent ou non ne fait pas partie du comportement du programme, même si cela pourrait être détecté via un allocateur qui suit les allocations en imprimant ou en ayant des effets secondaires.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Allouez de la mémoire comme décrit par le `layout` donné.
    ///
    /// Renvoie un pointeur vers la mémoire nouvellement allouée, ou null pour indiquer un échec d'allocation.
    ///
    /// # Safety
    ///
    /// Cette fonction n'est pas sûre car un comportement non défini peut se produire si l'appelant ne garantit pas que `layout` a une taille non nulle.
    ///
    /// (Les sous-portraits d'extension peuvent fournir des limites plus spécifiques sur le comportement, par exemple, garantir une adresse sentinelle ou un pointeur nul en réponse à une demande d'allocation de taille nulle.)
    ///
    /// Le bloc de mémoire alloué peut être initialisé ou non.
    ///
    /// # Errors
    ///
    /// Le renvoi d'un pointeur nul indique que la mémoire est épuisée ou que `layout` ne répond pas aux contraintes de taille ou d'alignement de cet allocateur.
    ///
    /// Les implémentations sont encouragées à retourner null en cas d'épuisement de la mémoire plutôt que d'abandonner, mais ce n'est pas une exigence stricte.
    /// (Plus précisément: il est *légal* d'implémenter ce trait au sommet d'une bibliothèque d'allocation native sous-jacente qui abandonne en cas d'épuisement de la mémoire.)
    ///
    /// Les clients souhaitant abandonner le calcul en réponse à une erreur d'allocation sont encouragés à appeler la fonction [`handle_alloc_error`], plutôt que d'appeler directement `panic!` ou similaire.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Désallouez le bloc de mémoire au pointeur `ptr` donné avec le `layout` donné.
    ///
    /// # Safety
    ///
    /// Cette fonction n'est pas sûre car un comportement indéfini peut se produire si l'appelant ne garantit pas tous les éléments suivants:
    ///
    ///
    /// * `ptr` doit désigner un bloc de mémoire actuellement alloué via cet allocateur,
    ///
    /// * `layout` doit être la même disposition que celle utilisée pour allouer ce bloc de mémoire.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Se comporte comme `alloc`, mais garantit également que le contenu est mis à zéro avant d'être renvoyé.
    ///
    /// # Safety
    ///
    /// Cette fonction est dangereuse pour les mêmes raisons que `alloc`.
    /// Cependant, le bloc de mémoire alloué est garanti d'être initialisé.
    ///
    /// # Errors
    ///
    /// Le renvoi d'un pointeur nul indique que la mémoire est épuisée ou que `layout` ne répond pas aux contraintes de taille ou d'alignement de l'allocateur, tout comme dans `alloc`.
    ///
    /// Les clients souhaitant abandonner le calcul en réponse à une erreur d'allocation sont encouragés à appeler la fonction [`handle_alloc_error`], plutôt que d'appeler directement `panic!` ou similaire.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // SÉCURITÉ: le contrat de sécurité du `alloc` doit être respecté par l'appelant.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // SÉCURITÉ: une fois l'allocation réussie, la région de `ptr`
            // de taille `size` est garanti pour être valide pour les écritures.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Réduisez ou augmentez un bloc de mémoire vers le `new_size` donné.
    /// Le bloc est décrit par le pointeur `ptr` et `layout` donnés.
    ///
    /// Si cela renvoie un pointeur non nul, alors la propriété du bloc de mémoire référencé par `ptr` a été transférée à cet allocateur.
    /// La mémoire peut ou non avoir été désallouée, et doit être considérée comme inutilisable (à moins bien sûr qu'elle ne soit à nouveau transférée à l'appelant via la valeur de retour de cette méthode).
    /// Le nouveau bloc de mémoire est alloué avec `layout`, mais avec le `size` mis à jour vers `new_size`.
    /// Cette nouvelle disposition doit être utilisée lors de la désallocation du nouveau bloc de mémoire avec `dealloc`.
    /// La plage `0..min(layout.size(), new_size) `du nouveau bloc mémoire est garantie d'avoir les mêmes valeurs que le bloc d'origine.
    ///
    /// Si cette méthode renvoie null, la propriété du bloc de mémoire n'a pas été transférée à cet allocateur et le contenu du bloc de mémoire n'est pas modifié.
    ///
    /// # Safety
    ///
    /// Cette fonction n'est pas sûre car un comportement indéfini peut se produire si l'appelant ne garantit pas tous les éléments suivants:
    ///
    /// * `ptr` doit être actuellement alloué via cet allocateur,
    ///
    /// * `layout` doit être la même disposition que celle utilisée pour allouer ce bloc de mémoire,
    ///
    /// * `new_size` doit être supérieur à zéro.
    ///
    /// * `new_size`, lorsqu'il est arrondi au multiple supérieur de `layout.align()` le plus proche, ne doit pas dépasser (c'est-à-dire que la valeur arrondie doit être inférieure à `usize::MAX`).
    ///
    /// (Les sous-portraits d'extension peuvent fournir des limites plus spécifiques sur le comportement, par exemple, garantir une adresse sentinelle ou un pointeur nul en réponse à une demande d'allocation de taille nulle.)
    ///
    /// # Errors
    ///
    /// Renvoie null si la nouvelle mise en page ne répond pas aux contraintes de taille et d'alignement de l'allocateur, ou si la réallocation échoue dans le cas contraire.
    ///
    /// Les implémentations sont encouragées à renvoyer null en cas d'épuisement de la mémoire plutôt que de paniquer ou d'abandonner, mais ce n'est pas une exigence stricte.
    /// (Plus précisément: il est *légal* d'implémenter ce trait au sommet d'une bibliothèque d'allocation native sous-jacente qui abandonne en cas d'épuisement de la mémoire.)
    ///
    /// Les clients souhaitant abandonner le calcul en réponse à une erreur de réallocation sont encouragés à appeler la fonction [`handle_alloc_error`], plutôt que d'appeler directement `panic!` ou similaire.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // SÉCURITÉ: l'appelant doit s'assurer que le `new_size` ne déborde pas.
        // `layout.align()` provient d'un `Layout` et sa validité est donc garantie.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // SÉCURITÉ: l'appelant doit s'assurer que `new_layout` est supérieur à zéro.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // SÉCURITÉ: le bloc précédemment attribué ne peut pas chevaucher le bloc nouvellement attribué.
            // Le contrat de sécurité pour `dealloc` doit être respecté par l'appelant.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}