//! Bit de bidouillage sur les flotteurs IEEE 754 positifs.Les nombres négatifs ne sont pas et n'ont pas besoin d'être traités.
//! Les nombres à virgule flottante normaux ont une représentation canonique comme (frac, exp) telle que la valeur est 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) où N est le nombre de bits.
//!
//! Les sous-normales sont légèrement différentes et bizarres, mais le même principe s'applique.
//!
//! Ici, cependant, nous les représentons comme (sig, k) avec f positif, de sorte que la valeur soit f *
//! 2 <sup>e</sup> .En plus de rendre le "hidden bit" explicite, cela change l'exposant par le soi-disant décalage de mantisse.
//!
//! En d'autres termes, les flottants sont normalement écrits sous la forme (1), mais ici, ils sont écrits sous la forme (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Nous appelons (1) la **représentation fractionnaire** et (2) la **représentation intégrale**.
//!
//! De nombreuses fonctions de ce module ne gèrent que les nombres normaux.Les routines dec2flt prennent de manière conservatrice le chemin lent universellement correct (algorithme M) pour les très petits et très grands nombres.
//! Cet algorithme n'a besoin que de next_float() qui gère les sous-normaux et les zéros.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Un assistant trait pour éviter de dupliquer essentiellement tout le code de conversion pour `f32` et `f64`.
///
/// Voir le commentaire de documentation du module parent pour savoir pourquoi cela est nécessaire.
///
/// Ne devrait **jamais jamais** être implémenté pour d'autres types ou être utilisé en dehors du module dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Type utilisé par `to_bits` et `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Effectue une transmutation brute en un entier.
    fn to_bits(self) -> Self::Bits;

    /// Effectue une transmutation brute à partir d'un entier.
    fn from_bits(v: Self::Bits) -> Self;

    /// Renvoie la catégorie dans laquelle ce nombre appartient.
    fn classify(self) -> FpCategory;

    /// Renvoie la mantisse, l'exposant et le signe sous forme d'entiers.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Décode le flotteur.
    fn unpack(self) -> Unpacked;

    /// Caste à partir d'un petit entier qui peut être représenté exactement.
    /// Panic si l'entier ne peut pas être représenté, l'autre code de ce module s'assure de ne jamais laisser cela se produire.
    fn from_int(x: u64) -> Self;

    /// Obtient la valeur 10 <sup>e à</sup> partir d'une table précalculée.
    /// Panics pour `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Ce que dit le nom.
    /// Il est plus facile de coder en dur que de jongler avec les intrinsèques et d'espérer que la constante LLVM le plie.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Une limite conservatrice sur les chiffres décimaux des entrées qui ne peuvent pas produire de débordement ou zéro ou
    /// sous-normaux.Probablement l'exposant décimal de la valeur normale maximale, d'où le nom.
    const MAX_NORMAL_DIGITS: usize;

    /// Lorsque le chiffre décimal le plus significatif a une valeur de position supérieure à cela, le nombre est certainement arrondi à l'infini.
    ///
    const INF_CUTOFF: i64;

    /// Lorsque le chiffre décimal le plus significatif a une valeur de position inférieure à cela, le nombre est certainement arrondi à zéro.
    ///
    const ZERO_CUTOFF: i64;

    /// Le nombre de bits dans l'exposant.
    const EXP_BITS: u8;

    /// Le nombre de bits dans le significande,*y compris* le bit caché.
    const SIG_BITS: u8;

    /// Le nombre de bits dans le significande,*à l'exclusion* du bit caché.
    const EXPLICIT_SIG_BITS: u8;

    /// L'exposant légal maximum dans la représentation fractionnaire.
    const MAX_EXP: i16;

    /// L'exposant légal minimum dans la représentation fractionnaire, à l'exclusion des sous-normaux.
    const MIN_EXP: i16;

    /// `MAX_EXP` pour la représentation intégrale, c'est-à-dire avec le décalage appliqué.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` encodé (c'est-à-dire avec biais de décalage)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` pour la représentation intégrale, c'est-à-dire avec le décalage appliqué.
    const MIN_EXP_INT: i16;

    /// Le significande normalisé maximum en représentation intégrale.
    const MAX_SIG: u64;

    /// Le significand normalisé minimal en représentation intégrale.
    const MIN_SIG: u64;
}

// Surtout une solution de contournement pour #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Renvoie la mantisse, l'exposant et le signe sous forme d'entiers.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Biais exposant + décalage de mantisse
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe ne sait pas si `as` tourne correctement sur toutes les plates-formes.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Renvoie la mantisse, l'exposant et le signe sous forme d'entiers.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Biais exposant + décalage de mantisse
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe ne sait pas si `as` tourne correctement sur toutes les plates-formes.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Convertit un `Fp` en type de flotteur de machine le plus proche.
/// Ne gère pas les résultats sous-normaux.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f est de 64 bits, donc xe a un décalage de mantisse de 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Arrondissez le significand 64 bits aux bits T::SIG_BITS avec demi-paire.
/// Ne gère pas le débordement d'exposant.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Ajuster le décalage de la mantisse
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Inverse de `RawFloat::unpack()` pour les nombres normalisés.
/// Panics si le significande ou l'exposant ne sont pas valides pour les nombres normalisés.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Supprimer le bit caché
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Ajustez l'exposant pour le biais d'exposant et le décalage de mantisse
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Laissez le bit de signe à 0 ("+"), nos chiffres sont tous positifs
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Construisez un sous-normal.Une mantisse de 0 est autorisée et construit zéro.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // L'exposant codé est 0, le bit de signe est 0, il suffit donc de réinterpréter les bits.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Approximer un bignum avec un Fp.Arrondit dans 0.5 ULP avec demi-paire.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Nous avons coupé tous les bits avant l'indice `start`, c'est-à-dire que nous avons effectivement décalé vers la droite d'une quantité de `start`, donc c'est aussi l'exposant dont nous avons besoin.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Arrondissez (half-to-even) en fonction des bits tronqués.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Recherche le plus grand nombre à virgule flottante strictement inférieur à l'argument.
/// Ne gère pas les sous-normaux, zéro ou sous-dépassement d'exposant.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Trouvez le plus petit nombre à virgule flottante strictement plus grand que l'argument.
// Cette opération est saturante, c'est-à-dire next_float(inf) ==inf.
// Contrairement à la plupart des codes de ce module, cette fonction gère les zéros, les sous-normaux et les infinis.
// Cependant, comme tous les autres codes ici, il ne traite pas le NaN et les nombres négatifs.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Cela semble trop beau pour être vrai, mais cela fonctionne.
        // 0.0 est codé en tant que mot entièrement nul.Les sous-normales sont 0x000m ... m où m est la mantisse.
        // En particulier, la plus petite sous-normale est 0x0 ... 01 et la plus grande est 0x000F ... F.
        // Le plus petit nombre normal est 0x0010 ... 0, donc ce cas d'angle fonctionne également.
        // Si l'incrément dépasse la mantisse, le bit de retenue incrémente l'exposant comme nous le voulons et les bits de la mantisse deviennent nuls.
        // En raison de la convention des bits cachés, c'est aussi exactement ce que nous voulons!
        // Enfin, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}