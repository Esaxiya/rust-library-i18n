//! Fonctions utilitaires pour les bignums qui n'ont pas trop de sens pour se transformer en méthodes.

// FIXME Le nom de ce module est un peu malheureux, car d'autres modules importent également `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Vérifiez si la troncature de tous les bits moins significatifs que `ones_place` introduit une erreur relative inférieure, égale ou supérieure à 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Si tous les bits restants sont égaux à zéro, c'est= 0.5 ULP, sinon> 0.5 S'il n'y a plus de bits (half_bit==0), le code ci-dessous renvoie également correctement Equal.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Convertit une chaîne ASCII contenant uniquement des chiffres décimaux en `u64`.
///
/// N'effectue pas de vérifications de débordement ou de caractères invalides, donc si l'appelant ne fait pas attention, le résultat est faux et peut panic (bien que ce ne soit pas `unsafe`).
/// En outre, les chaînes vides sont traitées comme zéro.
/// Cette fonction existe parce que
///
/// 1. l'utilisation de `FromStr` sur `&[u8]` nécessite `from_utf8_unchecked`, ce qui est mauvais, et
/// 2. reconstituer les résultats de `integral.parse()` et `fractional.parse()` est plus compliqué que toute cette fonction.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Convertit une chaîne de chiffres ASCII en bignum.
///
/// Comme `from_str_unchecked`, cette fonction repose sur l'analyseur pour éliminer les non-chiffres.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Décompresse un bignum en un entier 64 bits.Panics si le nombre est trop grand.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Extrait une plage de bits.

/// L'index 0 est le bit le moins significatif et la plage est semi-ouverte comme d'habitude.
/// Panics si on lui demande d'extraire plus de bits que de rentrer dans le type de retour.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}