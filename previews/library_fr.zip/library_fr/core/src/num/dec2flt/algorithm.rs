//! Les différents algorithmes de l'article.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Nombre de bits de significande en Fp
const P: u32 = 64;

// Nous stockons simplement la meilleure approximation pour *tous* les exposants, de sorte que la variable "h" et les conditions associées peuvent être omises.
// Cela échange les performances pour quelques kilo-octets d'espace.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Dans la plupart des architectures, les opérations en virgule flottante ont une taille de bits explicite, par conséquent la précision du calcul est déterminée sur une base par opération.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Sur x86, le FPU x87 est utilisé pour les opérations flottantes si les extensions SSE/SSE2 ne sont pas disponibles.
// Le FPU x87 fonctionne avec 80 bits de précision par défaut, ce qui signifie que les opérations arrondiront à 80 bits provoquant un double arrondi lorsque les valeurs sont finalement représentées comme
//
// 32/64 valeurs flottantes de bits.Pour surmonter cela, le mot de contrôle FPU peut être défini de sorte que les calculs soient effectués avec la précision souhaitée.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Une structure utilisée pour conserver la valeur d'origine du mot de contrôle FPU, afin qu'elle puisse être restaurée lorsque la structure est supprimée.
    ///
    ///
    /// Le x87 FPU est un registre 16 bits dont les champs sont les suivants:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// La documentation de tous les champs est disponible dans le Manuel du développeur du logiciel IA-32 Architectures (Volume 1).
    ///
    /// Le seul champ pertinent pour le code suivant est PC, Precision Control.
    /// Ce champ détermine la précision des opérations effectuées par la FPU.
    /// Il peut être réglé sur:
    ///  - 0b00, simple précision, c'est-à-dire 32 bits
    ///  - 0b10, double précision, c'est-à-dire 64 bits
    ///  - 0b11, double précision étendue, c'est-à-dire 80 bits (état par défaut) La valeur 0b01 est réservée et ne doit pas être utilisée.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // SÉCURITÉ: l'instruction `fldcw` a été auditée pour pouvoir fonctionner correctement avec
        // tout `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Nous utilisons la syntaxe ATT pour prendre en charge LLVM 8 et LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Définit le champ de précision du FPU sur `T` et renvoie un `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Calculez la valeur du champ Contrôle de précision appropriée pour `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bits
            8 => 0x0200, // 64 bits
            _ => 0x0300, // par défaut, 80 bits
        };

        // Récupérez la valeur d'origine du mot de contrôle pour la restaurer plus tard, lorsque la structure `FPUControlWord` est abandonnée SÉCURITÉ: l'instruction `fnstcw` a été auditée pour pouvoir fonctionner correctement avec n'importe quel `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Nous utilisons la syntaxe ATT pour prendre en charge LLVM 8 et LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Réglez le mot de contrôle sur la précision souhaitée.
        // Ceci est réalisé en masquant l'ancienne précision (bits 8 et 9, 0x300) et en la remplaçant par l'indicateur de précision calculé ci-dessus.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Le chemin rapide de Bellérophon en utilisant des nombres entiers et des flottants de taille machine.
///
/// Ceci est extrait dans une fonction distincte afin qu'il puisse être tenté avant de construire un bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Nous comparons la valeur exacte à MAX_SIG vers la fin, il ne s'agit que d'un rejet rapide et bon marché (et évite également au reste du code de s'inquiéter du sous-débit).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Le chemin rapide dépend essentiellement du fait que l'arithmétique est arrondie au nombre correct de bits sans arrondi intermédiaire.
    // Sur x86 (sans SSE ou SSE2), cela nécessite que la précision de la pile FPU x87 soit modifiée pour qu'elle s'arrondisse directement au bit 64/32.
    // La fonction `set_precision` se charge de paramétrer la précision sur les architectures qui nécessitent de la paramétrer en modifiant l'état global (comme le mot de contrôle du FPU x87).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Le cas e <0 ne peut pas être replié dans l'autre branch.
    // Les puissances négatives se traduisent par une partie fractionnaire répétitive en binaire, qui sont arrondies, ce qui provoque des erreurs réelles (et parfois assez importantes!) Dans le résultat final.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// L'algorithme Bellerophon est un code trivial justifié par une analyse numérique non triviale.
///
/// Il arrondit `` f '' à un flottant avec un significande de 64 bits et le multiplie par la meilleure approximation de `10^e` (dans le même format à virgule flottante).Cela suffit souvent pour obtenir le résultat correct.
/// Cependant, lorsque le résultat est proche de la mi-chemin entre deux flottants (ordinary) adjacents, l'erreur d'arrondi composée résultant de la multiplication de deux approximations signifie que le résultat peut être décalé de quelques bits.
/// Lorsque cela se produit, l'algorithme itératif R corrige les choses.
///
/// Le "close to halfway" ondulé à la main est rendu précis par l'analyse numérique dans le papier.
/// Dans les mots de Clinger:
///
/// > La pente, exprimée en unités du bit le moins significatif, est une borne inclusive de l'erreur
/// > accumulé lors du calcul en virgule flottante de l'approximation de f * 10 ^ e.(La pente est
/// > pas une limite pour l'erreur vraie, mais limite la différence entre l'approximation z et
/// > la meilleure approximation possible qui utilise p bits de significande.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Les boîtiers abs(e) <log5(2^N) sont en fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // La pente est-elle suffisamment grande pour faire une différence lors de l'arrondi à n bits?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Un algorithme itératif qui améliore une approximation en virgule flottante de `f * 10^e`.
///
/// Chaque itération rapproche une unité à la dernière place, ce qui prend bien sûr terriblement longtemps à converger si `z0` est même légèrement éteint.
/// Heureusement, lorsqu'il est utilisé comme solution de secours pour Bellerophon, l'approximation de départ est décalée d'au plus une ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Trouvez les entiers positifs `x`, `y` tels que `x / y` est exactement `(f *10^e) / (m* 2^k)`.
        // Cela évite non seulement de traiter les signes de `e` et `k`, mais nous éliminons également la puissance de deux communs à `10^e` et `2^k` pour réduire les nombres.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Ceci est écrit un peu maladroitement parce que nos bignums ne prennent pas en charge les nombres négatifs, nous utilisons donc les informations de valeur absolue + signe.
        // La multiplication avec m_digits ne peut pas déborder.
        // Si `x` ou `y` sont suffisamment grands pour que nous ayons à nous soucier du débordement, ils sont également suffisamment grands pour que `make_ratio` ait réduit la fraction d'un facteur 2 ^ 64 ou plus.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Plus besoin de x, enregistrez un clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Encore besoin, faites une copie.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Étant donné `x = f` et `y = m` où `f` représente les chiffres décimaux d'entrée comme d'habitude et `m` est le significande d'une approximation en virgule flottante, rendre le rapport `x / y` égal à `(f *10^e) / (m* 2^k)`, éventuellement réduit d'une puissance de deux, les deux ont en commun.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, sauf que nous réduisons la fraction d'une puissance de deux.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Cela ne peut pas déborder car il nécessite `e` positif et `k` négatif, ce qui ne peut se produire que pour des valeurs extrêmement proches de 1, ce qui signifie que `e` et `k` seront relativement minuscules.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Cela ne peut pas non plus déborder, voir ci-dessus.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), en réduisant à nouveau d'une puissance commune de deux.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Conceptuellement, l'algorithme M est le moyen le plus simple de convertir un nombre décimal en flottant.
///
/// On forme un rapport égal à `f * 10^e`, puis on lance des puissances de deux jusqu'à ce qu'il donne un significande flottant valide.
/// L'exposant binaire `k` est le nombre de fois où nous avons multiplié le numérateur ou le dénominateur par deux, c'est-à-dire à tout moment `f *10^e` est égal à `(u / v)* 2^k`.
/// Lorsque nous avons découvert le significand, nous n'avons qu'à arrondir en inspectant le reste de la division, ce qui est fait dans les fonctions d'aide plus loin.
///
///
/// Cet algorithme est extrêmement lent, même avec l'optimisation décrite dans `quick_start()`.
/// Cependant, c'est l'algorithme le plus simple à adapter aux résultats de dépassement de capacité, de dépassement inférieur et sous-normaux.
/// Cette implémentation prend le relais lorsque le Bellérophon et l'algorithme R sont débordés.
/// Détecter les sous-débordements et les débordements est facile: le rapport n'est toujours pas un signifiant dans la plage, mais l'exposant minimum/maximum a été atteint.
/// En cas de débordement, on renvoie simplement l'infini.
///
/// La gestion des débordements inférieurs et inférieurs à la normale est plus délicate.
/// Un gros problème est que, avec l'exposant minimum, le rapport peut encore être trop grand pour un significande.
/// Voir underflow() pour plus de détails.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // Optimisation possible FIXME: généraliser big_to_fp pour que l'on puisse faire l'équivalent de fp_to_float(big_to_fp(u)) ici, uniquement sans le double arrondi.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Nous devons nous arrêter à l'exposant minimum, si nous attendons jusqu'à `k < T::MIN_EXP_INT`, alors nous serions décalés d'un facteur de deux.
            // Malheureusement, cela signifie que nous devons utiliser des nombres normaux de cas spéciaux avec l'exposant minimum.
            // FIXME trouve une formulation plus élégante, mais lancez le test `tiny-pow10` pour vous assurer qu'elle est réellement correcte!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Saute la plupart des itérations d'algorithme en vérifiant la longueur en bits.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // La longueur en bits est une estimation du logarithme de base deux, et log(u / v) = log(u), log(v).
    // L'estimation est décalée d'au plus 1, mais toujours sous-estimée, de sorte que les erreurs sur log(u) et log(v) sont du même signe et s'annulent (si les deux sont grandes).
    // Par conséquent, l'erreur pour log(u / v) est tout au plus une.
    // Le rapport cible est celui où u/v est dans un significand dans la plage.Ainsi, notre condition de terminaison est log2(u / v) étant les bits de significande, plus/minus un.
    // FIXME Regarder le deuxième bit pourrait améliorer l'estimation et éviter quelques divisions supplémentaires.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Débit inférieur ou sous-normal.Laissez-le à la fonction principale.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Débordement.Laissez-le à la fonction principale.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Le rapport n'est pas un significand dans la plage avec l'exposant minimum, nous devons donc arrondir les bits en excès et ajuster l'exposant en conséquence.
    // La valeur réelle ressemble maintenant à ceci:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(représenté par rem)
    //
    // Par conséquent, lorsque les bits arrondis sont!= 0.5 ULP, ils décident eux-mêmes de l'arrondi.
    // Lorsqu'ils sont égaux et que le reste est différent de zéro, la valeur doit encore être arrondie.
    // Ce n'est que lorsque les bits arrondis sont 1/2 et que le reste est égal à zéro, nous avons une situation demi-paire.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Arrondi ordinaire à pair, obscurci par le fait de devoir arrondir en fonction du reste d'une division.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}