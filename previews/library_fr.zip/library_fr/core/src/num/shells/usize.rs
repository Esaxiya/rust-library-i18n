//! Constantes pour le type entier non signé de la taille du pointeur.
//!
//! *[See also the `usize` primitive type][usize].*
//!
//! Le nouveau code doit utiliser les constantes associées directement sur le type primitif.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `usize`"
)]

int_module! { usize }