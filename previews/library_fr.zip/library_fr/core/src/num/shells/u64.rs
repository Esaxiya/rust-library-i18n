//! Constantes pour le type entier non signé 64 bits.
//!
//! *[See also the `u64` primitive type][u64].*
//!
//! Le nouveau code doit utiliser les constantes associées directement sur le type primitif.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u64`"
)]

int_module! { u64 }