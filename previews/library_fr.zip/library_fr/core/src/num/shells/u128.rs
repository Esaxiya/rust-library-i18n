//! Constantes pour le type entier non signé 128 bits.
//!
//! *[See also the `u128` primitive type][u128].*
//!
//! Le nouveau code doit utiliser les constantes associées directement sur le type primitif.

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u128`"
)]

int_module! { u128, #[stable(feature = "i128", since="1.26.0")] }