macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// La plus petite valeur qui peut être représentée par ce type entier.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// La plus grande valeur pouvant être représentée par ce type entier.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// La taille de ce type entier en bits.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Convertit une tranche de chaîne dans une base donnée en un entier.
        ///
        /// La chaîne devrait être un signe `+` facultatif suivi de chiffres.
        ///
        /// Les espaces blancs de début et de fin représentent une erreur.
        /// Les chiffres sont un sous-ensemble de ces caractères, selon `radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Cette fonction panics si `radix` n'est pas dans la plage de 2 à 36.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Renvoie le nombre de uns dans la représentation binaire de `self`.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// Renvoie le nombre de zéros dans la représentation binaire de `self`.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Renvoie le nombre de zéros non significatifs dans la représentation binaire de `self`.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// Renvoie le nombre de zéros de fin dans la représentation binaire de `self`.
        ///
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// Renvoie le nombre de premiers dans la représentation binaire de `self`.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// Renvoie le nombre de derniers dans la représentation binaire de `self`.
        ///
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Décale les bits vers la gauche d'une quantité spécifiée, `n`, encapsulant les bits tronqués à la fin de l'entier résultant.
        ///
        ///
        /// Veuillez noter que ce n'est pas la même opération que l'opérateur de changement de vitesse `<<`!
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Décale les bits vers la droite d'une quantité spécifiée, `n`, en enveloppant les bits tronqués au début de l'entier résultant.
        ///
        ///
        /// Veuillez noter que ce n'est pas la même opération que l'opérateur de changement de vitesse `>>`!
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// Inverse l'ordre des octets de l'entier.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// soit m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// Inverse l'ordre des bits dans l'entier.
        /// Le bit le moins significatif devient le bit le plus significatif, le second bit le moins significatif devient le second bit le plus significatif, etc.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// soit m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Convertit un entier de big endian en endianness de la cible.
        ///
        /// Sur le big endian, c'est un no-op.
        /// Sur Little Endian, les octets sont permutés.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// si cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } autre {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Convertit un entier de little endian en endianness de la cible.
        ///
        /// Sur Little Endian, c'est un no-op.
        /// Sur big endian, les octets sont échangés.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// si cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } autre {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Convertit `self` en big endian à partir de l'endianité de la cible.
        ///
        /// Sur le big endian, c'est un no-op.
        /// Sur Little Endian, les octets sont permutés.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// si cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } else { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // Ou ne pas être?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Convertit `self` en little endian à partir de l'endianness de la cible.
        ///
        /// Sur Little Endian, c'est un no-op.
        /// Sur big endian, les octets sont échangés.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// si cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } else { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Ajout d'entiers vérifié.
        /// Calcule `self + rhs`, renvoyant `None` en cas de dépassement de capacité.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Addition d'entiers non vérifiée.Calcule `self + rhs`, en supposant que le débordement ne peut pas se produire.
        /// Cela entraîne un comportement indéfini lorsque
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Vérification de la soustraction d'entiers.
        /// Calcule `self - rhs`, renvoyant `None` en cas de dépassement de capacité.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Soustraction d'entiers non cochée.Calcule `self - rhs`, en supposant que le débordement ne peut pas se produire.
        /// Cela entraîne un comportement indéfini lorsque
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Vérification de la multiplication des nombres entiers.
        /// Calcule `self * rhs`, renvoyant `None` en cas de dépassement de capacité.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Multiplication d'entiers non vérifiée.Calcule `self * rhs`, en supposant que le débordement ne peut pas se produire.
        /// Cela entraîne un comportement indéfini lorsque
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Division entière vérifiée.
        /// Calcule `self / rhs`, renvoyant `None` si `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SÉCURITÉ: div par zéro a été vérifié ci-dessus et les types non signés n'en ont pas d'autre
                // modes de défaillance pour la division
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Vérification de la division euclidienne.
        /// Calcule `self.div_euclid(rhs)`, renvoyant `None` si `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// Reste entier vérifié.
        /// Calcule `self % rhs`, renvoyant `None` si `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SÉCURITÉ: div par zéro a été vérifié ci-dessus et les types non signés n'en ont pas d'autre
                // modes de défaillance pour la division
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Vérifié modulo euclidien.
        /// Calcule `self.rem_euclid(rhs)`, renvoyant `None` si `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Négation vérifiée.Calcule `-self`, renvoyant `None` sauf si `self==
        /// 0`.
        ///
        /// Notez que la négation de tout entier positif débordera.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Checked shift à gauche.
        /// Calcule `self << rhs`, renvoyant `None` si `rhs` est supérieur ou égal au nombre de bits dans `self`.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Checked shift à droite.
        /// Calcule `self >> rhs`, renvoyant `None` si `rhs` est supérieur ou égal au nombre de bits dans `self`.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Exponentiation vérifiée.
        /// Calcule `self.pow(exp)`, renvoyant `None` en cas de dépassement de capacité.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // puisque exp!=0, finalement l'exp doit être 1.
            // Traitez le dernier bit de l'exposant séparément, car la quadrature de la base par la suite n'est pas nécessaire et peut provoquer un débordement inutile.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Addition d'entiers saturés.
        /// Calcule `self + rhs`, saturant aux limites numériques au lieu de déborder.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Saturation soustraction d'entiers.
        /// Calcule `self - rhs`, saturant aux limites numériques au lieu de déborder.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Multiplication d'entiers saturés.
        /// Calcule `self * rhs`, saturant aux limites numériques au lieu de déborder.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Exponentiation entière saturée.
        /// Calcule `self.pow(exp)`, saturant aux limites numériques au lieu de déborder.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Emballage de l'ajout du (modular).
        /// Calcule `self + rhs`, s'enroulant à la limite du type.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Emballage de la soustraction (modular).
        /// Calcule `self - rhs`, s'enroulant à la limite du type.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Multiplication (modular) d'emballage.
        /// Calcule `self * rhs`, s'enroulant à la limite du type.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// Veuillez noter que cet exemple est partagé entre les types entiers.
        /// Ce qui explique pourquoi `u8` est utilisé ici.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Division d'emballage (modular).Calcule `self / rhs`.
        /// La division enveloppée sur les types non signés est juste une division normale.
        /// Il n'y a aucun moyen que l'emballage puisse se produire.
        /// Cette fonction existe, de sorte que toutes les opérations sont prises en compte dans les opérations d'encapsulation.
        ///
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Emballage de la division euclidienne.Calcule `self.div_euclid(rhs)`.
        /// La division enveloppée sur les types non signés est juste une division normale.
        /// Il n'y a aucun moyen que l'emballage puisse se produire.
        /// Cette fonction existe, de sorte que toutes les opérations sont prises en compte dans les opérations d'encapsulation.
        /// Puisque, pour les entiers positifs, toutes les définitions courantes de division sont égales, ceci est exactement égal à `self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Emballage du reste (modular).Calcule `self % rhs`.
        /// Le calcul du reste enveloppé sur les types non signés n'est que le calcul du reste normal.
        ///
        /// Il n'y a aucun moyen que l'emballage puisse se produire.
        /// Cette fonction existe, de sorte que toutes les opérations sont prises en compte dans les opérations d'encapsulation.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Emballage modulo euclidien.Calcule `self.rem_euclid(rhs)`.
        /// Le calcul modulo enveloppé sur les types non signés n'est que le calcul du reste normal.
        /// Il n'y a aucun moyen que l'emballage puisse se produire.
        /// Cette fonction existe, de sorte que toutes les opérations sont prises en compte dans les opérations d'encapsulation.
        /// Puisque, pour les entiers positifs, toutes les définitions courantes de division sont égales, ceci est exactement égal à `self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Emballage de la négation (modular).
        /// Calcule `-self`, s'enroulant à la limite du type.
        ///
        /// Étant donné que les types non signés n'ont pas d'équivalents négatifs, toutes les applications de cette fonction seront enveloppées (à l'exception de `-0`).
        /// Pour les valeurs inférieures au maximum du type signé correspondant, le résultat est le même que le transtypage de la valeur signée correspondante.
        ///
        /// Toute valeur plus grande équivaut à `MAX + 1 - (val - MAX - 1)` où `MAX` est le maximum du type signé correspondant.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// Veuillez noter que cet exemple est partagé entre les types entiers.
        /// Ce qui explique pourquoi `i8` est utilisé ici.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Décalage gauche au niveau du bit sans Panic;
        /// renvoie `self << mask(rhs)`, où `mask` supprime tous les bits de poids fort de `rhs` qui entraîneraient le décalage à dépasser la largeur de bits du type.
        ///
        /// Notez que ce n'est *pas* la même chose qu'une rotation à gauche;le RHS d'un décalage de retour à gauche est limité à la plage du type, plutôt que les bits décalés hors du LHS sont renvoyés à l'autre extrémité.
        /// Les types entiers primitifs implémentent tous une fonction [`rotate_left`](Self::rotate_left), qui peut être ce que vous voulez à la place.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // SÉCURITÉ: le masquage par le bitize du type garantit que l'on ne décale pas
            // hors limites
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic sans décalage de bit à droite;
        /// renvoie `self >> mask(rhs)`, où `mask` supprime tous les bits de poids fort de `rhs` qui entraîneraient le décalage à dépasser la largeur de bits du type.
        ///
        /// Notez que ce n'est *pas* la même chose qu'une rotation à droite;le RHS d'un décalage de retour à droite est limité à la plage du type, plutôt que les bits décalés hors du LHS sont renvoyés à l'autre extrémité.
        /// Les types entiers primitifs implémentent tous une fonction [`rotate_right`](Self::rotate_right), qui peut être ce que vous voulez à la place.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // SÉCURITÉ: le masquage par le bitize du type garantit que l'on ne décale pas
            // hors limites
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Exponentiation (modular) enveloppante.
        /// Calcule `self.pow(exp)`, s'enroulant à la limite du type.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // puisque exp!=0, finalement l'exp doit être 1.
            // Traitez le dernier bit de l'exposant séparément, car la quadrature de la base par la suite n'est pas nécessaire et peut provoquer un débordement inutile.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Calcule `self` + `rhs`
        ///
        /// Renvoie un tuple de l'addition avec un booléen indiquant si un dépassement arithmétique se produirait.
        /// Si un dépassement s'est produit, la valeur encapsulée est renvoyée.
        ///
        /// # Examples
        ///
        /// Utilisation de base
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Calcule `self`, `rhs`
        ///
        /// Renvoie un tuple de la soustraction avec un booléen indiquant si un dépassement arithmétique se produirait.
        /// Si un dépassement s'est produit, la valeur encapsulée est renvoyée.
        ///
        /// # Examples
        ///
        /// Utilisation de base
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Calcule la multiplication de `self` et `rhs`.
        ///
        /// Renvoie un tuple de la multiplication avec un booléen indiquant si un dépassement arithmétique se produirait.
        /// Si un dépassement s'est produit, la valeur encapsulée est renvoyée.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// Veuillez noter que cet exemple est partagé entre les types entiers.
        /// Ce qui explique pourquoi `u32` est utilisé ici.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Calcule le diviseur lorsque `self` est divisé par `rhs`.
        ///
        /// Renvoie un tuple du diviseur avec un booléen indiquant si un dépassement arithmétique se produirait.
        /// Notez que pour les entiers non signés, le débordement ne se produit jamais, donc la deuxième valeur est toujours `false`.
        ///
        /// # Panics
        ///
        /// Cette fonction sera panic si `rhs` est 0.
        ///
        /// # Examples
        ///
        /// Utilisation de base
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Calcule le quotient de la division euclidienne `self.div_euclid(rhs)`.
        ///
        /// Renvoie un tuple du diviseur avec un booléen indiquant si un dépassement arithmétique se produirait.
        /// Notez que pour les entiers non signés, le débordement ne se produit jamais, donc la deuxième valeur est toujours `false`.
        /// Puisque, pour les entiers positifs, toutes les définitions courantes de division sont égales, ceci est exactement égal à `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Cette fonction sera panic si `rhs` est 0.
        ///
        /// # Examples
        ///
        /// Utilisation de base
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Calcule le reste lorsque `self` est divisé par `rhs`.
        ///
        /// Renvoie un tuple du reste après la division avec un booléen indiquant si un dépassement arithmétique se produirait.
        /// Notez que pour les entiers non signés, le débordement ne se produit jamais, donc la deuxième valeur est toujours `false`.
        ///
        /// # Panics
        ///
        /// Cette fonction sera panic si `rhs` est 0.
        ///
        /// # Examples
        ///
        /// Utilisation de base
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Calcule le reste `self.rem_euclid(rhs)` comme par division euclidienne.
        ///
        /// Renvoie un tuple du modulo après la division avec un booléen indiquant si un dépassement arithmétique se produirait.
        /// Notez que pour les entiers non signés, le débordement ne se produit jamais, donc la deuxième valeur est toujours `false`.
        /// Puisque, pour les entiers positifs, toutes les définitions courantes de division sont égales, cette opération est exactement égale à `self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Cette fonction sera panic si `rhs` est 0.
        ///
        /// # Examples
        ///
        /// Utilisation de base
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Se nie de façon débordante.
        ///
        /// Renvoie `!self + 1` à l'aide d'opérations d'encapsulation pour renvoyer la valeur qui représente la négation de cette valeur non signée.
        /// Notez que pour les valeurs non signées positives, le dépassement se produit toujours, mais la négation de 0 ne déborde pas.
        ///
        /// # Examples
        ///
        /// Utilisation de base
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// Décale l'auto à gauche de `rhs` bits.
        ///
        /// Renvoie un tuple de la version décalée de self avec un booléen indiquant si la valeur de décalage était supérieure ou égale au nombre de bits.
        /// Si la valeur de décalage est trop grande, alors la valeur est masquée (N-1) où N est le nombre de bits, et cette valeur est ensuite utilisée pour effectuer le décalage.
        ///
        /// # Examples
        ///
        /// Utilisation de base
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Décale l'auto-droite de `rhs` bits.
        ///
        /// Renvoie un tuple de la version décalée de self avec un booléen indiquant si la valeur de décalage était supérieure ou égale au nombre de bits.
        /// Si la valeur de décalage est trop grande, alors la valeur est masquée (N-1) où N est le nombre de bits, et cette valeur est ensuite utilisée pour effectuer le décalage.
        ///
        /// # Examples
        ///
        /// Utilisation de base
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// S'élève à la puissance de `exp`, en utilisant l'exponentiation par quadrillage.
        ///
        /// Renvoie un tuple de l'exponentiation avec un bool indiquant si un débordement s'est produit.
        ///
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, vrai));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Espace de travail pour stocker les résultats de overflowing_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // puisque exp!=0, finalement l'exp doit être 1.
            // Traitez le dernier bit de l'exposant séparément, car la quadrature de la base par la suite n'est pas nécessaire et peut provoquer un débordement inutile.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// S'élève à la puissance de `exp`, en utilisant l'exponentiation par quadrillage.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // puisque exp!=0, finalement l'exp doit être 1.
            // Traitez le dernier bit de l'exposant séparément, car la quadrature de la base par la suite n'est pas nécessaire et peut provoquer un débordement inutile.
            //
            //
            acc * base
        }

        /// Effectue la division euclidienne.
        ///
        /// Puisque, pour les entiers positifs, toutes les définitions courantes de division sont égales, ceci est exactement égal à `self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Cette fonction sera panic si `rhs` est 0.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// Calcule le moindre reste de `self (mod rhs)`.
        ///
        /// Puisque, pour les entiers positifs, toutes les définitions courantes de division sont égales, ceci est exactement égal à `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Cette fonction sera panic si `rhs` est 0.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Renvoie `true` si et seulement si `self == 2^k` pour certains `k`.
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // Renvoie un de moins que la prochaine puissance de deux.
        // (Pour 8u8, la prochaine puissance de deux est 8u8 et pour 6u8 c'est 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // Cette méthode ne peut pas déborder, car dans les cas de dépassement `next_power_of_two`, elle finit par renvoyer la valeur maximale du type et peut renvoyer 0 pour 0.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // SÉCURITÉ: Parce que `p > 0`, il ne peut pas être entièrement composé de zéros non significatifs.
            // Cela signifie que le décalage est toujours dans les limites, et certains processeurs (comme intel pre-haswell) ont des intrinsèques ctlz plus efficaces lorsque l'argument est différent de zéro.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// Renvoie la plus petite puissance de deux supérieure ou égale à `self`.
        ///
        /// Lorsque la valeur de retour déborde (c'est-à-dire `self > (1 << (N-1))` pour le type `uN`), elle panics en mode débogage et la valeur de retour est enveloppée à 0 en mode de libération (la seule situation dans laquelle la méthode peut renvoyer 0).
        ///
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// Renvoie la plus petite puissance de deux supérieure ou égale à `n`.
        /// Si la puissance suivante de deux est supérieure à la valeur maximale du type, `None` est renvoyé, sinon la puissance de deux est enveloppée dans `Some`.
        ///
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// Renvoie la plus petite puissance de deux supérieure ou égale à `n`.
        /// Si la prochaine puissance de deux est supérieure à la valeur maximale du type, la valeur de retour est encapsulée à `0`.
        ///
        ///
        /// # Examples
        ///
        /// Utilisation de base:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Renvoie la représentation mémoire de cet entier sous forme de tableau d'octets dans l'ordre des octets (network) big-endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Renvoie la représentation mémoire de cet entier sous forme de tableau d'octets dans l'ordre des octets petit bout.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Renvoie la représentation mémoire de cet entier sous forme de tableau d'octets dans l'ordre des octets natif.
        ///
        /// Comme l'endianness natif de la plate-forme cible est utilisée, le code portable doit utiliser [`to_be_bytes`] ou [`to_le_bytes`], selon le cas, à la place.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     octets, si cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } autre {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SÉCURITÉ: son constant parce que les entiers sont d'anciens types de données afin que nous puissions toujours
        // les transformer en tableaux d'octets
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // SÉCURITÉ: les entiers sont d'anciens types de données, donc nous pouvons toujours les transmuter en
            // tableaux d'octets
            unsafe { mem::transmute(self) }
        }

        /// Renvoie la représentation mémoire de cet entier sous forme de tableau d'octets dans l'ordre des octets natif.
        ///
        ///
        /// [`to_ne_bytes`] devrait être préféré à cela dans la mesure du possible.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// laissez octets= num.as_ne_bytes();
        /// assert_eq!(
        ///     octets, si cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } autre {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // SÉCURITÉ: les entiers sont d'anciens types de données, donc nous pouvons toujours les transmuter en
            // tableaux d'octets
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Créez une valeur entière native endian à partir de sa représentation sous forme de tableau d'octets en big endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// utilisez std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * entrée=repos;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Créez une valeur entière native endian à partir de sa représentation sous forme de tableau d'octets en little endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// utilisez std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * entrée=repos;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Créez une valeur entière endian native à partir de sa représentation mémoire sous forme de tableau d'octets dans endianness native.
        ///
        /// Comme l'endianness natif de la plate-forme cible est utilisée, le code portable souhaite probablement utiliser [`from_be_bytes`] ou [`from_le_bytes`], selon le cas.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } autre {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// utilisez std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * entrée=repos;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SÉCURITÉ: son constant parce que les entiers sont d'anciens types de données afin que nous puissions toujours
        // transmuter à eux
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // SÉCURITÉ: les entiers sont d'anciens types de données, donc nous pouvons toujours les transmuter
            unsafe { mem::transmute(bytes) }
        }

        /// Le nouveau code devrait préférer utiliser
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Renvoie la plus petite valeur pouvant être représentée par ce type entier.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// Le nouveau code devrait préférer utiliser
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Renvoie la plus grande valeur pouvant être représentée par ce type entier.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}