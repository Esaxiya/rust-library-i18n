//! Définitions d'un entier connu comme différent de zéro.

use crate::fmt;
use crate::ops::{BitOr, BitOrAssign, Div, Rem};
use crate::str::FromStr;

use super::from_str_radix;
use super::{IntErrorKind, ParseIntError};
use crate::intrinsics;

macro_rules! impl_nonzero_fmt {
    ( #[$stability: meta] ( $( $Trait: ident ),+ ) for $Ty: ident ) => {
        $(
            #[$stability]
            impl fmt::$Trait for $Ty {
                #[inline]
                fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                    self.get().fmt(f)
                }
            }
        )+
    }
}

macro_rules! nonzero_integers {
    ( $( #[$stability: meta] $Ty: ident($Int: ty); )+ ) => {
        $(
            /// Un entier dont on sait qu'il n'est pas égal à zéro.
            ///
            /// Cela permet une optimisation de la disposition de la mémoire.
            #[doc = concat!("For example, `Option<", stringify!($Ty), ">` is the same size as `", stringify!($Int), "`:")]
            /// ```rust
            /// utilisez std::mem::size_of;
            #[doc = concat!("assert_eq!(size_of::<Option<core::num::", stringify!($Ty), ">>(), size_of::<", stringify!($Int), ">());")]
            /// ```
            #[$stability]
            #[derive(Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
            #[repr(transparent)]
            #[rustc_layout_scalar_valid_range_start(1)]
            #[rustc_nonnull_optimization_guaranteed]
            pub struct $Ty($Int);

            impl $Ty {
                /// Crée un différent de zéro sans vérifier la valeur.
                ///
                /// # Safety
                ///
                /// La valeur ne doit pas être nulle.
                #[$stability]
                #[rustc_const_stable(feature = "nonzero", since = "1.34.0")]
                #[inline]
                pub const unsafe fn new_unchecked(n: $Int) -> Self {
                    // SÉCURITÉ: celle-ci est garantie par l'appelant.
                    unsafe { Self(n) }
                }

                /// Crée un non-zéro si la valeur donnée n'est pas zéro.
                #[$stability]
                #[rustc_const_stable(feature = "const_nonzero_int_methods", since = "1.47.0")]
                #[inline]
                pub const fn new(n: $Int) -> Option<Self> {
                    if n != 0 {
                        // SÉCURITÉ: nous venons de vérifier qu'il n'y a pas de `0`
                        Some(unsafe { Self(n) })
                    } else {
                        None
                    }
                }

                /// Renvoie la valeur sous forme de type primitif.
                #[$stability]
                #[inline]
                #[rustc_const_stable(feature = "nonzero", since = "1.34.0")]
                pub const fn get(self) -> $Int {
                    self.0
                }

            }

            #[stable(feature = "from_nonzero", since = "1.31.0")]
            impl From<$Ty> for $Int {
                #[doc = concat!("Converts a `", stringify!($Ty), "` into an `", stringify!($Int), "`")]
                #[inline]
                fn from(nonzero: $Ty) -> Self {
                    nonzero.0
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOr for $Ty {
                type Output = Self;
                #[inline]
                fn bitor(self, rhs: Self) -> Self::Output {
                    // SÉCURITÉ: puisque `self` et `rhs` sont tous deux différents de zéro, le
                    // résultat du bit au niveau ou sera différent de zéro.
                    unsafe { $Ty::new_unchecked(self.get() | rhs.get()) }
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOr<$Int> for $Ty {
                type Output = Self;
                #[inline]
                fn bitor(self, rhs: $Int) -> Self::Output {
                    // SÉCURITÉ: puisque `self` est différent de zéro, le résultat du
                    // bitwise-or sera différent de zéro quelle que soit la valeur de `rhs`.
                    //
                    unsafe { $Ty::new_unchecked(self.get() | rhs) }
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOr<$Ty> for $Int {
                type Output = $Ty;
                #[inline]
                fn bitor(self, rhs: $Ty) -> Self::Output {
                    // SÉCURITÉ: puisque `rhs` est différent de zéro, le résultat du
                    // bitwise-or sera différent de zéro quelle que soit la valeur de `self`.
                    //
                    unsafe { $Ty::new_unchecked(self | rhs.get()) }
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOrAssign for $Ty {
                #[inline]
                fn bitor_assign(&mut self, rhs: Self) {
                    *self = *self | rhs;
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOrAssign<$Int> for $Ty {
                #[inline]
                fn bitor_assign(&mut self, rhs: $Int) {
                    *self = *self | rhs;
                }
            }

            impl_nonzero_fmt! {
                #[$stability] (Debug, Display, Binary, Octal, LowerHex, UpperHex) for $Ty
            }
        )+
    }
}

nonzero_integers! {
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU8(u8);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU16(u16);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU32(u32);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU64(u64);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU128(u128);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroUsize(usize);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI8(i8);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI16(i16);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI32(i32);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI64(i64);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI128(i128);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroIsize(isize);
}

macro_rules! from_str_radix_nzint_impl {
    ($($t:ty)*) => {$(
        #[stable(feature = "nonzero_parse", since = "1.35.0")]
        impl FromStr for $t {
            type Err = ParseIntError;
            fn from_str(src: &str) -> Result<Self, Self::Err> {
                Self::new(from_str_radix(src, 10)?)
                    .ok_or(ParseIntError {
                        kind: IntErrorKind::Zero
                    })
            }
        }
    )*}
}

from_str_radix_nzint_impl! { NonZeroU8 NonZeroU16 NonZeroU32 NonZeroU64 NonZeroU128 NonZeroUsize
NonZeroI8 NonZeroI16 NonZeroI32 NonZeroI64 NonZeroI128 NonZeroIsize }

macro_rules! nonzero_leading_trailing_zeros {
    ( $( $Ty: ident($Uint: ty) , $LeadingTestExpr:expr ;)+ ) => {
        $(
            impl $Ty {
                /// Renvoie le nombre de zéros non significatifs dans la représentation binaire de `self`.
                ///
                /// Sur de nombreuses architectures, cette fonction peut fonctionner mieux que `leading_zeros()` sur le type entier sous-jacent, car une gestion spéciale de zéro peut être évitée.
                ///
                /// # Examples
                ///
                /// Utilisation de base:
                ///
                /// ```
                /// #![feature(nonzero_leading_trailing_zeros)]
                #[doc = concat!("let n = std::num::", stringify!($Ty), "::new(", stringify!($LeadingTestExpr), ").unwrap();")]
                /// assert_eq!(n.leading_zeros(), 0);
                /// ```
                #[unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[rustc_const_unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[inline]
                pub const fn leading_zeros(self) -> u32 {
                    // SÉCURITÉ: puisque `self` ne peut pas être nul, il est prudent d'appeler ctlz_nonzero
                    unsafe { intrinsics::ctlz_nonzero(self.0 as $Uint) as u32 }
                }

                /// Renvoie le nombre de zéros de fin dans la représentation binaire de `self`.
                ///
                /// Sur de nombreuses architectures, cette fonction peut fonctionner mieux que `trailing_zeros()` sur le type entier sous-jacent, car une gestion spéciale de zéro peut être évitée.
                ///
                ///
                /// # Examples
                ///
                /// Utilisation de base:
                ///
                /// ```
                /// #![feature(nonzero_leading_trailing_zeros)]
                #[doc = concat!("let n = std::num::", stringify!($Ty), "::new(0b0101000).unwrap();")]
                /// assert_eq!(n.trailing_zeros(), 3);
                /// ```
                #[unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[rustc_const_unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[inline]
                pub const fn trailing_zeros(self) -> u32 {
                    // SÉCURITÉ: puisque `self` ne peut pas être nul, il est prudent d'appeler cttz_nonzero
                    unsafe { intrinsics::cttz_nonzero(self.0 as $Uint) as u32 }
                }

            }
        )+
    }
}

nonzero_leading_trailing_zeros! {
    NonZeroU8(u8), u8::MAX;
    NonZeroU16(u16), u16::MAX;
    NonZeroU32(u32), u32::MAX;
    NonZeroU64(u64), u64::MAX;
    NonZeroU128(u128), u128::MAX;
    NonZeroUsize(usize), usize::MAX;
    NonZeroI8(u8), -1i8;
    NonZeroI16(u16), -1i16;
    NonZeroI32(u32), -1i32;
    NonZeroI64(u64), -1i64;
    NonZeroI128(u128), -1i128;
    NonZeroIsize(usize), -1isize;
}

macro_rules! nonzero_integers_div {
    ( $( $Ty: ident($Int: ty); )+ ) => {
        $(
            #[stable(feature = "nonzero_div", since = "1.51.0")]
            impl Div<$Ty> for $Int {
                type Output = $Int;
                /// Cette opération arrondit vers zéro, tronquant toute partie fractionnaire du résultat exact, et ne peut pas panic.
                ///
                #[inline]
                fn div(self, other: $Ty) -> $Int {
                    // SÉCURITÉ: div par zéro est vérifié car `other` est différent de zéro,
                    // et MIN/-1 est vérifié car `self` est un entier non signé.
                    unsafe { crate::intrinsics::unchecked_div(self, other.get()) }
                }
            }

            #[stable(feature = "nonzero_div", since = "1.51.0")]
            impl Rem<$Ty> for $Int {
                type Output = $Int;
                /// Cette opération satisfait `n % d == n - (n / d) * d` et ne peut pas panic.
                #[inline]
                fn rem(self, other: $Ty) -> $Int {
                    // SÉCURITÉ: rem par zéro est vérifié car `other` est différent de zéro,
                    // et MIN/-1 est vérifié car `self` est un entier non signé.
                    unsafe { crate::intrinsics::unchecked_rem(self, other.get()) }
                }
            }
        )+
    }
}

nonzero_integers_div! {
    NonZeroU8(u8);
    NonZeroU16(u16);
    NonZeroU32(u32);
    NonZeroU64(u64);
    NonZeroU128(u128);
    NonZeroUsize(usize);
}

macro_rules! nonzero_unsigned_is_power_of_two {
    ( $( $Ty: ident )+ ) => {
        $(
            impl $Ty {

                /// Renvoie `true` si et seulement si `self == (1 << k)` pour certains `k`.
                ///
                /// Sur de nombreuses architectures, cette fonction peut fonctionner mieux que `is_power_of_two()` sur le type entier sous-jacent, car une gestion spéciale de zéro peut être évitée.
                ///
                ///
                /// # Examples
                ///
                /// Utilisation de base:
                ///
                /// ```
                /// #![feature(nonzero_is_power_of_two)]
                ///
                #[doc = concat!("let eight = std::num::", stringify!($Ty), "::new(8).unwrap();")]
                /// assert!(eight.is_power_of_two());
                #[doc = concat!("let ten = std::num::", stringify!($Ty), "::new(10).unwrap();")]
                /// assert!(!ten.is_power_of_two());
                /// ```
                #[unstable(feature = "nonzero_is_power_of_two", issue = "81106")]
                #[inline]
                pub const fn is_power_of_two(self) -> bool {
                    // LLVM 11 normalise `unchecked_sub(x, 1) & x == 0` à l'implémentation vue ici.
                    // Sur la cible de base x86-64, cela enregistre 3 instructions pour le contrôle du zéro.
                    // Sur x86_64 avec BMI1, être différent de zéro lui permet de coder en `BLSR`, ce qui enregistre une instruction par rapport à l'implémentation `POPCNT` sur le type entier sous-jacent.
                    //

                    intrinsics::ctpop(self.get()) < 2
                }

            }
        )+
    }
}

nonzero_unsigned_is_power_of_two! { NonZeroU8 NonZeroU16 NonZeroU32 NonZeroU64 NonZeroU128 NonZeroUsize }