//! Traduction Rust presque directe (mais légèrement optimisée) de la figure 3 de «Impression rapide et précise des nombres à virgule flottante» [^ 1].
//!
//!
//! [^1]: Burger, RG et Dybvig, RK 1996. Impression de nombres à virgule flottante
//!   rapidement et avec précision.SIGPLAN Non.31, 5 (mai 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// tableaux précalculés de `Digit`s pour 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// utilisable uniquement lorsque `x < 16 * scale`;`scaleN` doit être `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// L'implémentation du mode le plus court pour Dragon.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // le nombre `v` à formater est connu pour être:
    // - égal à `mant * 2^exp`;
    // - précédé de `(mant - 2 *minus)* 2^exp` dans le type d'origine;et
    // - suivi de `(mant + 2 *plus)* 2^exp` dans le type d'origine.
    //
    // évidemment, `minus` et `plus` ne peuvent pas être nuls.(pour l'infini, nous utilisons des valeurs hors limites.) également, nous supposons qu'au moins un chiffre est généré, c'est-à-dire que `mant` ne peut pas être nul aussi.
    //
    // cela signifie également que tout nombre entre `low = (mant - minus)*2^exp` et `high = (mant + plus)* 2^exp` correspondra à ce nombre à virgule flottante exact, avec des limites incluses lorsque la mantisse d'origine était paire (c'est-à-dire `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` est `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // estimer `k_0` à partir des entrées originales satisfaisant `10^(k_0-1) < high <= 10^(k_0+1)`.
    // la borne étroite `k` satisfaisant `10^(k-1) < high <= 10^k` est calculée plus tard.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // convertir `{mant, plus, minus} * 2^exp` en forme fractionnaire de sorte que:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // divisez `mant` par `10^k`.maintenant `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // correction lorsque `mant + plus > scale` (ou `>=`).
    // nous ne modifions pas réellement `scale`, car nous pouvons sauter la multiplication initiale à la place.
    // maintenant `scale < mant + plus <= scale * 10` et nous sommes prêts à générer des chiffres.
    //
    // notez que `d[0]`*peut* être égal à zéro, lorsque `scale - plus < mant < scale`.
    // dans ce cas, la condition d'arrondi (`up` ci-dessous) sera déclenchée immédiatement.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // équivalent à la mise à l'échelle de `scale` par 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // cache `(2, 4, 8) * scale` pour la génération de chiffres.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // invariants, où `d[0..n-1]` sont des chiffres générés jusqu'à présent:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (donc `mant / scale < 10`) où `d[i..j]` est un raccourci pour `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // générer un chiffre: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // il s'agit d'une description simplifiée de l'algorithme de Dragon modifié.
        // de nombreuses dérivations intermédiaires et arguments d'exhaustivité sont omis pour des raisons de commodité.
        //
        // commencez avec des invariants modifiés, comme nous avons mis à jour `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // Supposons que `d[0..n-1]` est la représentation la plus courte entre `low` et `high`, c'est-à-dire que `d[0..n-1]` satisfait les deux conditions suivantes mais `d[0..n-2]` ne le fait pas:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijectivité: chiffres arrondis à `v`);et
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (le dernier chiffre est correct).
        //
        // la deuxième condition se simplifie à `2 * mant <= scale`.
        // la résolution des invariants en termes de `mant`, `low` et `high` donne une version plus simple de la première condition: `-plus < mant < minus`.
        // depuis `-plus < 0 <= mant`, nous avons la représentation la plus courte correcte lorsque `mant < minus` et `2 * mant <= scale`.
        // (le premier devient `mant <= minus` lorsque la mantisse d'origine est paire.)
        //
        // lorsque la seconde ne tient pas (`2 * mant> scale`), nous devons augmenter le dernier chiffre.
        // cela suffit pour restaurer cette condition: nous savons déjà que la génération de chiffres garantit `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // dans ce cas, la première condition devient `-plus < mant - scale < minus`.
        // depuis `mant < scale` après la génération, nous avons `scale < mant + plus`.
        // (encore une fois, cela devient `scale <= mant + plus` lorsque la mantisse d'origine est paire.)
        //
        // en bref:
        // - arrêter et arrondir `down` (conserver les chiffres tels quels) lorsque `mant < minus` (ou `<=`).
        // - arrêter et arrondir `up` (augmenter le dernier chiffre) lorsque `scale < mant + plus` (ou `<=`).
        // - continuez à générer autrement.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // nous avons la représentation la plus courte, procédez à l'arrondissement

        // restaurer les invariants.
        // cela fait que l'algorithme se termine toujours: `minus` et `plus` augmentent toujours, mais `mant` est écrêté modulo `scale` et `scale` est fixe.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // l'arrondissement se produit lorsque i) seule la condition d'arrondi a été déclenchée, ou ii) les deux conditions ont été déclenchées et que le bris d'égalité préfère arrondir vers le haut.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // si l'arrondi change la longueur, l'exposant doit également changer.
        // il semble que cette condition soit très difficile à satisfaire (peut-être impossible), mais nous sommes juste sûrs et cohérents ici.
        //
        // SÉCURITÉ: nous avons initialisé cette mémoire ci-dessus.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // SÉCURITÉ: nous avons initialisé cette mémoire ci-dessus.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// L'implémentation du mode exact et fixe pour Dragon.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // estimer `k_0` à partir des entrées originales satisfaisant `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // divisez `mant` par `10^k`.maintenant `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // correction lorsque `mant + plus >= scale`, où `plus / scale = 10^-buf.len() / 2`.
    // afin de conserver le bignum de taille fixe, nous utilisons en fait `mant + floor(plus) >= scale`.
    // nous ne modifions pas réellement `scale`, car nous pouvons sauter la multiplication initiale à la place.
    // encore une fois avec l'algorithme le plus court, `d[0]` peut être égal à zéro mais sera finalement arrondi.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // équivalent à la mise à l'échelle de `scale` par 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // si nous travaillons avec la limitation du dernier chiffre, nous devons raccourcir le tampon avant le rendu réel afin d'éviter un double arrondi.
    //
    // notez que nous devons à nouveau agrandir le tampon lors de l'arrondi!
    let mut len = if k < limit {
        // oups, nous ne pouvons même pas produire *un* chiffre.
        // cela est possible lorsque, par exemple, nous avons quelque chose comme 9.5 et qu'il est arrondi à 10.
        // nous retournons un tampon vide, à l'exception du dernier cas d'arrondi qui se produit lorsque `k == limit` et doit produire exactement un chiffre.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // cache `(2, 4, 8) * scale` pour la génération de chiffres.
        // (cela peut être coûteux, alors ne les calculez pas lorsque le tampon est vide.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // les chiffres suivants sont tous des zéros, nous nous arrêtons ici ne *pas* essayer d'effectuer des arrondis!remplissez plutôt les chiffres restants.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // SÉCURITÉ: nous avons initialisé cette mémoire ci-dessus.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // arrondir vers le haut si nous nous arrêtons au milieu des chiffres si les chiffres suivants sont exactement 5000 ..., vérifiez le chiffre précédent et essayez d'arrondir à pair (c'est-à-dire, évitez d'arrondir lorsque le chiffre précédent est pair).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // SÉCURITÉ: `buf[len-1]` est initialisé.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // si l'arrondi change la longueur, l'exposant doit également changer.
        // mais on nous a demandé un nombre fixe de chiffres, alors ne modifiez pas le tampon ...
        // SÉCURITÉ: nous avons initialisé cette mémoire ci-dessus.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... sauf si on nous a demandé la précision fixe à la place.
            // nous devons également vérifier que, si le tampon d'origine était vide, le chiffre supplémentaire ne peut être ajouté que lorsque `k == limit` (cas edge).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // SÉCURITÉ: nous avons initialisé cette mémoire ci-dessus.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}