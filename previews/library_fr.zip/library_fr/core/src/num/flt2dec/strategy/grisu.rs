//! Adaptation Rust de l'algorithme Grisu3 décrit dans "Impression rapide et précise de nombres à virgule flottante avec des nombres entiers" [^ 1].
//! Il utilise environ 1 Ko de table précalculée, et à son tour, il est très rapide pour la plupart des entrées.
//!
//! [^1]: Florian Loitsch.2010. Impression rapide des nombres à virgule flottante et
//!   précisément avec des nombres entiers.SIGPLAN Non.45, 6 (juin 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// voir les commentaires dans `format_shortest_opt` pour la justification.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Étant donné `x > 0`, renvoie `(k, 10^k)` tel que `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// L'implémentation du mode le plus court pour Grisu.
///
/// Il retourne `None` lorsqu'il renverrait une représentation inexacte dans le cas contraire.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // nous avons besoin d'au moins trois bits de précision supplémentaire

    // commencez par les valeurs normalisées avec l'exposant partagé
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // trouver n'importe quel `cached = 10^minusk` tel que `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // puisque `plus` est normalisé, cela signifie `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // étant donné nos choix de `ALPHA` et `GAMMA`, cela met `plus * cached` dans `[4, 2^32)`.
    //
    // il est évidemment souhaitable de maximiser `GAMMA - ALPHA`, de sorte que nous n'ayons pas besoin de beaucoup de puissances mises en cache de 10, mais il y a quelques considérations:
    //
    //
    // 1. nous voulons garder `floor(plus * cached)` dans `u32` car il nécessite une division coûteuse.
    //    (ce n'est pas vraiment évitable, un reste est nécessaire pour l'estimation de la précision.)
    // 2.
    // le reste de `floor(plus * cached)` est multiplié à plusieurs reprises par 10, et il ne doit pas déborder.
    //
    // le premier donne `64 + GAMMA <= 32`, tandis que le second donne `10 * 2^-ALPHA <= 2^64`;
    // -60 et -32 est la plage maximale avec cette contrainte, et V8 les utilise également.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // échelle fps.cela donne l'erreur maximale de 1 ulp (prouvée à partir du théorème 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-plage réelle de moins
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // au-dessus de `minus`, `v` et `plus` sont des approximations *quantifiées*(erreur <1 ulp).
    // comme nous ne savons pas que l'erreur est positive ou négative, nous utilisons deux approximations espacées de manière égale et avons l'erreur maximale de 2 ulps.
    //
    // le "unsafe region" est un intervalle libéral que nous générons initialement.
    // le "safe region" est un intervalle conservateur que nous n'acceptons que.
    // nous commençons avec le repr correct dans la région non sécurisée, et essayons de trouver le repr le plus proche de `v` qui est également dans la région sûre.
    // si nous ne pouvons pas, nous abandonnons.
    //
    let plus1 = plus.f + 1;
    // soit plus0 = plus.f, 1;//uniquement pour l'explication let minus0 = minus.f + 1;//uniquement pour explication
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // exposant partagé

    // divisez `plus1` en parties intégrales et fractionnaires.
    // les pièces intégrales sont garanties pour s'adapter à u32, car la puissance mise en cache garantit `plus < 2^32` et `plus.f` normalisé est toujours inférieur à `2^64 - 2^4` en raison de l'exigence de précision.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // calculer le plus grand `10^max_kappa` pas plus que `plus1` (donc `plus1 < 10^(max_kappa+1)`).
    // il s'agit d'une limite supérieure de `kappa` ci-dessous.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Théorème 6.2: si `k` est le plus grand entier st
    // `0 <= y mod 10^k <= y - x`,              alors `V = floor(y / 10^k) * 10^k` est dans `[x, y]` et l'une des représentations les plus courtes (avec le nombre minimal de chiffres significatifs) dans cette plage.
    //
    //
    // trouver la longueur de chiffre `kappa` entre `(minus1, plus1)` selon le théorème 6.2.
    // Le théorème 6.2 peut être adopté pour exclure `x` en exigeant `y mod 10^k < y - x` à la place.
    // (par exemple, `x` =32000, `y` =32777; `kappa` =2 puisque `y mod 10 ^ 3=777 <y, x=777`.) l'algorithme s'appuie sur la phase de vérification ultérieure pour exclure `y`.
    //
    let delta1 = plus1 - minus1;
    // laissez delta1int=(delta1>> e) comme usize;//uniquement pour explication
    let delta1frac = delta1 & ((1 << e) - 1);

    // rendre les pièces intégrales, tout en vérifiant la précision à chaque étape.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // chiffres à rendre
    loop {
        // nous avons toujours au moins un chiffre à rendre, comme invariants `plus1 >= 10^kappa`:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (il s'ensuit que `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // divisez `remainder` par `10^kappa`.les deux sont mis à l'échelle par `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; nous avons trouvé le bon `kappa`.
            let ten_kappa = (ten_kappa as u64) << e; // mettre à l'échelle 10 ^ kappa jusqu'à l'exposant partagé
            return round_and_weed(
                // SÉCURITÉ: nous avons initialisé cette mémoire ci-dessus.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // rompre la boucle lorsque nous avons rendu tous les chiffres intégraux.
        // le nombre exact de chiffres est `max_kappa + 1` comme `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // restaurer les invariants
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // rendre les parties fractionnaires, tout en vérifiant la précision à chaque étape.
    // cette fois, nous comptons sur des multiplications répétées, car la division perdra de la précision.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // le chiffre suivant devrait être significatif car nous l'avons testé avant de décomposer les invariants, où `m = max_kappa + 1` (#de chiffres dans la partie intégrale):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // ne débordera pas, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // divisez `remainder` par `10^kappa`.
        // les deux sont mis à l'échelle par `2^e / 10^kappa`, ce dernier est donc implicite ici.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // diviseur implicite
            return round_and_weed(
                // SÉCURITÉ: nous avons initialisé cette mémoire ci-dessus.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // restaurer les invariants
        kappa -= 1;
        remainder = r;
    }

    // nous avons généré tous les chiffres significatifs de `plus1`, mais nous ne savons pas si c'est le chiffre optimal.
    // par exemple, si `minus1` vaut 3,14153 ... et `plus1` vaut 3,14158 ..., il y a 5 représentations les plus courtes différentes de 3.14154 à 3.14158 mais nous n'avons que la plus grande.
    // il faut successivement diminuer le dernier chiffre et vérifier s'il s'agit de la reprogrammation optimale.
    // il y a au plus 9 candidats (..1 à ..9), donc c'est assez rapide.(Phase "rounding")
    //
    // la fonction vérifie si ce "optimal" repr est réellement dans les plages ulp, et aussi, il est possible que le "second-to-optimal" repr puisse réellement être optimal en raison de l'erreur d'arrondi.
    // dans les deux cas, cela renvoie `None`.
    // (Phase "weeding")
    //
    // tous les arguments ici sont mis à l'échelle par la valeur commune (mais implicite) `k`, de sorte que:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (et aussi, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (et aussi, `threshold > plus1v` des invariants antérieurs)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // produisent deux approximations de `v` (en fait `plus1 - v`) dans les ulps 1.5.
        // la représentation résultante doit être la représentation la plus proche des deux.
        //
        // ici `plus1 - v` est utilisé puisque les calculs sont effectués par rapport à `plus1` afin d'éviter overflow/underflow (d'où les noms apparemment échangés).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // diminuez le dernier chiffre et arrêtez-vous à la représentation la plus proche de `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // nous travaillons avec les chiffres approximatifs `w(n)`, qui est initialement égal à `plus1 - plus1 % 10^kappa`.après avoir exécuté le corps de la boucle `n` fois, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // on positionne `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (donc `reste= plus1w(0)`) pour simplifier les vérifications.
            // notez que `plus1w(n)` augmente toujours.
            //
            // nous avons trois conditions pour terminer.n'importe lequel d'entre eux rendra la boucle incapable de continuer, mais nous avons alors au moins une représentation valide connue pour être la plus proche de `v + 1 ulp` de toute façon.
            // nous les désignerons par TC1 à TC3 par souci de concision.
            //
            // TC1: `w(n) <= v + 1 ulp`, c'est-à-dire, c'est le dernier repr qui peut être le plus proche.
            // cela équivaut à `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // combiné avec TC2 (qui vérifie si `w(n+1)` is valid), cela évite le débordement éventuel sur le calcul de `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, c'est-à-dire, la prochaine repr ne s'arrondit certainement pas à `v`.
            // cela équivaut à `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // le côté gauche peut déborder, mais nous connaissons `threshold > plus1v`, donc si TC1 est faux, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` et nous pouvons tester en toute sécurité si `threshold - plus1w(n) < 10^kappa` à la place.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, c'est-à-dire que le prochain repr est
            // pas plus proche de `v + 1 ulp` que le repr actuel.
            // étant donné `z(n) = plus1v_up - plus1w(n)`, cela devient `abs(z(n)) <= abs(z(n+1))`.en supposant à nouveau que TC1 est faux, nous avons `z(n) > 0`.nous avons deux cas à considérer:
            //
            // - lorsque `z(n+1) >= 0`: TC3 devient `z(n) <= z(n+1)`.
            // comme `plus1w(n)` augmente, `z(n)` devrait diminuer et c'est clairement faux.
            // - lorsque `z(n+1) < 0`:
            //   - TC3a: la condition préalable est `plus1v_up < plus1w(n) + 10^kappa`.en supposant que TC2 est faux, `threshold >= plus1w(n) + 10^kappa` donc il ne peut pas déborder.
            //   - TC3b: TC3 devient `z(n) <= -z(n+1)`, c'est-à-dire `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   le TC1 inversé donne `plus1v_up > plus1w(n)`, il ne peut donc pas déborder ou sous-déborder lorsqu'il est combiné avec TC3a.
            //
            // par conséquent, nous devrions nous arrêter lorsque `TC1 || TC2 || (TC3a && TC3b)`.ce qui suit est égal à son inverse, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // la représentation la plus courte ne peut pas se terminer par `0`
                plus1w += ten_kappa;
            }
        }

        // vérifiez si cette représentation est également la représentation la plus proche de `v - 1 ulp`.
        //
        // c'est simplement la même chose pour les conditions de terminaison pour `v + 1 ulp`, avec tous les `plus1v_up` remplacés par `plus1v_down` à la place.
        // l'analyse de débordement est également valable.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // maintenant nous avons la représentation la plus proche de `v` entre `plus1` et `minus1`.
        // c'est trop libéral, cependant, nous rejetons tout `w(n)` qui n'est pas entre `plus0` et `minus0`, c'est-à-dire `plus1 - plus1w(n) <= minus0` ou `plus1 - plus1w(n) >= plus0`.
        // nous utilisons les faits que `threshold = plus1 - minus1` et `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// L'implémentation du mode le plus court pour Grisu avec la solution de secours Dragon.
///
/// Cela devrait être utilisé dans la plupart des cas.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // SÉCURITÉ: le vérificateur d'emprunt n'est pas assez intelligent pour nous permettre d'utiliser `buf`
    // dans le deuxième branch, donc nous blanchissons la vie ici.
    // Mais nous ne réutilisons `buf` que si `format_shortest_opt` a renvoyé `None`, donc ça va.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// L'implémentation exacte et fixe du mode pour Grisu.
///
/// Il retourne `None` lorsqu'il renverrait une représentation inexacte dans le cas contraire.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // nous avons besoin d'au moins trois bits de précision supplémentaire
    assert!(!buf.is_empty());

    // normaliser et mettre à l'échelle `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // divisez `v` en parties intégrales et fractionnaires.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // l'ancien `v` et le nouveau `v` (mis à l'échelle par `10^-k`) ont une erreur <1 ulp (théorème 5.1).
    // comme nous ne savons pas que l'erreur est positive ou négative, nous utilisons deux approximations espacées de manière égale et avons l'erreur maximale de 2 ulps (même chose pour le cas le plus court).
    //
    //
    // le but est de trouver la série exactement arrondie de chiffres communs à `v - 1 ulp` et `v + 1 ulp`, afin que nous soyons au maximum confiants.
    // si ce n'est pas possible, nous ne savons pas laquelle est la sortie correcte pour `v`, alors nous abandonnons et recourons.
    //
    // `err` est défini comme `1 ulp * 2^e` ici (identique à l'ulp dans `vfrac`), et nous le mettrons à l'échelle chaque fois que `v` sera mis à l'échelle.
    //
    //
    //
    let mut err = 1;

    // calculer le plus grand `10^max_kappa` pas plus que `v` (donc `v < 10^(max_kappa+1)`).
    // il s'agit d'une limite supérieure de `kappa` ci-dessous.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // si nous travaillons avec la limitation du dernier chiffre, nous devons raccourcir le tampon avant le rendu réel afin d'éviter un double arrondi.
    //
    // notez que nous devons à nouveau agrandir le tampon lors de l'arrondi!
    let len = if exp <= limit {
        // oups, nous ne pouvons même pas produire *un* chiffre.
        // cela est possible lorsque, par exemple, nous avons quelque chose comme 9.5 et qu'il est arrondi à 10.
        //
        // en principe, nous pouvons immédiatement appeler `possibly_round` avec un tampon vide, mais la mise à l'échelle de `max_ten_kappa << e` par 10 peut entraîner un débordement.
        //
        // nous sommes donc bâclés ici et élargissons la plage d'erreur d'un facteur 10.
        // cela augmentera le taux de faux négatifs, mais seulement très,*très* légèrement;
        // cela n'a d'importance que lorsque la mantisse est supérieure à 60 bits.
        //
        // SÉCURITÉ: `len=0`, donc l'obligation d'avoir initialisé cette mémoire est triviale.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // rendre des parties intégrales.
    // l'erreur est entièrement fractionnaire, nous n'avons donc pas besoin de la vérifier dans cette partie.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // chiffres à rendre
    loop {
        // nous avons toujours au moins un chiffre pour rendre les invariants:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (il s'ensuit que `remainder = vint % 10^(kappa+1)`)
        //
        //

        // divisez `remainder` par `10^kappa`.les deux sont mis à l'échelle par `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // le tampon est-il plein?exécutez la passe d'arrondi avec le reste.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // SÉCURITÉ: nous avons initialisé `len` de nombreux octets.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // rompre la boucle lorsque nous avons rendu tous les chiffres intégraux.
        // le nombre exact de chiffres est `max_kappa + 1` comme `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // restaurer les invariants
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // rendre des parties fractionnaires.
    //
    // en principe, nous pouvons continuer jusqu'au dernier chiffre disponible et vérifier l'exactitude.
    // malheureusement, nous travaillons avec des entiers de taille finie, nous avons donc besoin d'un critère pour détecter le débordement.
    // V8 utilise `remainder > err`, qui devient faux lorsque les premiers chiffres significatifs `i` de `v - 1 ulp` et `v` diffèrent.
    // cependant, cela rejette trop d'entrées valides par ailleurs.
    //
    // étant donné que la phase ultérieure a une détection de débordement correcte, nous utilisons à la place un critère plus strict:
    // nous continuons jusqu'à ce que `err` dépasse `10^kappa / 2`, de sorte que la plage entre `v - 1 ulp` et `v + 1 ulp` contienne définitivement deux ou plusieurs représentations arrondies.
    //
    // c'est la même chose pour les deux premières comparaisons de `possibly_round`, pour la référence.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invariants, où `m = max_kappa + 1` (nombre de chiffres dans la partie intégrale):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // ne débordera pas, `2^e * 10 < 2^64`
        err *= 10; // ne débordera pas, `err * 10 < 2^e * 5 < 2^64`

        // divisez `remainder` par `10^kappa`.
        // les deux sont mis à l'échelle par `2^e / 10^kappa`, ce dernier est donc implicite ici.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // le tampon est-il plein?exécutez la passe d'arrondi avec le reste.
        if i == len {
            // SÉCURITÉ: nous avons initialisé `len` de nombreux octets.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // restaurer les invariants
        remainder = r;
    }

    // un calcul supplémentaire est inutile (`possibly_round` échoue définitivement), alors nous abandonnons.
    return None;

    // nous avons généré tous les chiffres demandés de `v`, qui devraient également être identiques aux chiffres correspondants de `v - 1 ulp`.
    // maintenant nous vérifions s'il existe une représentation unique partagée par `v - 1 ulp` et `v + 1 ulp`;cela peut être identique aux chiffres générés ou à la version arrondie de ces chiffres.
    //
    // si la plage contient plusieurs représentations de la même longueur, nous ne pouvons pas être sûrs et devrions renvoyer `None` à la place.
    //
    // tous les arguments ici sont mis à l'échelle par la valeur commune (mais implicite) `k`, de sorte que:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // SÉCURITÉ: les premiers octets `len` de `buf` doivent être initialisés.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (pour la référence, la ligne pointillée indique la valeur exacte des représentations possibles dans un nombre donné de chiffres.)
        //
        //
        // l'erreur est trop grande pour qu'il y ait au moins trois représentations possibles entre `v - 1 ulp` et `v + 1 ulp`.
        // nous ne pouvons pas déterminer lequel est correct.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // en fait, 1/2 ulp suffit à introduire deux représentations possibles.
        // (rappelez-vous que nous avons besoin d'une représentation unique pour `v - 1 ulp` et `v + 1 ulp`.) cela ne débordera pas, comme `ulp < ten_kappa` dès la première vérification.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // si `v + 1 ulp` est plus proche de la représentation arrondie (qui est déjà dans `buf`), alors nous pouvons revenir en toute sécurité.
        // notez que `v - 1 ulp`*peut* être inférieur à la représentation actuelle, mais comme `1 ulp < 10^kappa / 2`, cette condition suffit:
        // la distance entre `v - 1 ulp` et la représentation courante ne peut pas dépasser `10^kappa / 2`.
        //
        // la condition est égale à `remainder + ulp < 10^kappa / 2`.
        // puisque cela peut facilement déborder, vérifiez d'abord si `remainder < 10^kappa / 2`.
        // nous avons déjà vérifié que `ulp < 10^kappa / 2`, donc tant que `10^kappa` n'a pas débordé après tout, la deuxième vérification est correcte.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // SÉCURITÉ: notre appelant a initialisé cette mémoire.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------reste------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // d'autre part, si `v - 1 ulp` est plus proche de la représentation arrondie, nous devrions arrondir et revenir.
        // pour la même raison, nous n'avons pas besoin de vérifier `v + 1 ulp`.
        //
        // la condition est égale à `remainder - ulp >= 10^kappa / 2`.
        // encore une fois, nous vérifions d'abord si `remainder > ulp` (notez que ce n'est pas `remainder >= ulp`, car `10^kappa` n'est jamais nul).
        //
        // notez également que `remainder - ulp <= 10^kappa`, donc la deuxième vérification ne déborde pas.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // SÉCURITÉ: notre appelant doit avoir initialisé cette mémoire.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // n'ajoutez un chiffre supplémentaire que lorsque la précision fixe nous a été demandée.
                // nous devons également vérifier que, si le tampon d'origine était vide, le chiffre supplémentaire ne peut être ajouté que lorsque `exp == limit` (cas edge).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // SÉCURITÉ: nous et notre appelant avons initialisé cette mémoire.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // sinon nous sommes condamnés (c'est-à-dire que certaines valeurs entre `v - 1 ulp` et `v + 1 ulp` sont arrondies vers le bas et d'autres sont arrondies vers le haut) et abandonnent.
        //
        None
    }
}

/// L'implémentation exacte et fixe du mode pour Grisu avec Dragon fallback.
///
/// Cela devrait être utilisé dans la plupart des cas.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // SÉCURITÉ: le vérificateur d'emprunt n'est pas assez intelligent pour nous permettre d'utiliser `buf`
    // dans le deuxième branch, donc nous blanchissons la vie ici.
    // Mais nous ne réutilisons `buf` que si `format_exact_opt` a renvoyé `None`, donc ça va.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}