//! Décode une valeur à virgule flottante en parties individuelles et plages d'erreur.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Valeur finie non signée décodée, telle que:
///
/// - La valeur d'origine est égale à `mant * 2^exp`.
///
/// - Tout nombre compris entre `(mant - minus)*2^exp` et `(mant + plus)* 2^exp` sera arrondi à la valeur d'origine.
/// La plage est inclusive uniquement lorsque `inclusive` est `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// La mantisse à l'échelle.
    pub mant: u64,
    /// La plage d'erreur inférieure.
    pub minus: u64,
    /// La plage d'erreur supérieure.
    pub plus: u64,
    /// L'exposant partagé en base 2.
    pub exp: i16,
    /// Vrai lorsque la plage d'erreur est inclusive.
    ///
    /// Dans IEEE 754, cela est vrai lorsque la mantisse d'origine était paire.
    pub inclusive: bool,
}

/// Valeur non signée décodée.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infinis, positifs ou négatifs.
    Infinite,
    /// Zéro, positif ou négatif.
    Zero,
    /// Nombres finis avec d'autres champs décodés.
    Finite(Decoded),
}

/// Un type à virgule flottante qui peut être `decode`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// La valeur normalisée positive minimale.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Renvoie un signe (vrai lorsqu'il est négatif) et une valeur `FullDecoded` à partir d'un nombre à virgule flottante donné.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // voisins: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode conserve toujours l'exposant, donc la mantisse est mise à l'échelle pour les sous-normales.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // voisins: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // où maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // voisins: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}