//! L'estimateur d'exposant.

/// Trouve `k_0` tel que `10^(k_0-1) < mant * 2^exp <= 10^(k_0+1)`.
///
/// Ceci est utilisé pour approximer `k = ceil(log_10 (mant * 2^exp))`;
/// le vrai `k` est soit `k_0` soit `k_0+1`.
#[doc(hidden)]
pub fn estimate_scaling_factor(mant: u64, exp: i16) -> i16 {
    // 2 ^ (nbits-1) <mant <=2 ^ nbits si mant> 0
    let nbits = 64 - (mant - 1).leading_zeros() as i64;
    // 1292913986= floor(2^32 * log_10 2) donc cela sous-estime toujours (ou est exact), mais pas beaucoup.
    //
    (((nbits + exp as i64) * 1292913986) >> 32) as i16
}