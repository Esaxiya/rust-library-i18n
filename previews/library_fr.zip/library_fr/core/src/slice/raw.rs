//! Fonctions gratuites pour créer `&[T]` et `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Forme une tranche à partir d'un pointeur et d'une longueur.
///
/// L'argument `len` est le nombre de **éléments**, pas le nombre d'octets.
///
/// # Safety
///
/// Le comportement n'est pas défini si l'une des conditions suivantes n'est pas respectée:
///
/// * `data` doit être [valid] pour les lectures de `len * mem::size_of::<T>()` sur plusieurs octets et doit être correctement aligné.Cela signifie notamment:
///
///     * Toute la plage de mémoire de cette tranche doit être contenue dans un seul objet alloué!
///       Les tranches ne peuvent jamais s'étendre sur plusieurs objets alloués.Voir [below](#incorrect-usage) pour un exemple incorrectement ne prenant pas cela en compte.
///     * `data` doit être non nul et aligné même pour les tranches de longueur nulle.
///     L'une des raisons à cela est que les optimisations de mise en page enum peuvent s'appuyer sur des références (y compris des tranches de toute longueur) alignées et non nulles pour les distinguer des autres données.
///     Vous pouvez obtenir un pointeur utilisable en tant que `data` pour les tranches de longueur nulle à l'aide de [`NonNull::dangling()`].
///
/// * `data` doit pointer vers `len` valeurs correctement initialisées consécutives de type `T`.
///
/// * La mémoire référencée par la tranche retournée ne doit pas être mutée pendant la durée de vie `'a`, sauf à l'intérieur d'un `UnsafeCell`.
///
/// * La taille totale `len * mem::size_of::<T>()` de la tranche ne doit pas être supérieure à `isize::MAX`.
///   Consultez la documentation de sécurité du [`pointer::offset`].
///
/// # Caveat
///
/// La durée de vie de la tranche renvoyée est déduite de son utilisation.
/// Pour éviter une mauvaise utilisation accidentelle, il est suggéré de lier la durée de vie à la durée de vie de la source qui est sûre dans le contexte, par exemple en fournissant une fonction d'assistance prenant la durée de vie d'une valeur d'hôte pour la tranche, ou par une annotation explicite.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // manifeste une tranche pour un seul élément
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Mauvaise utilisation
///
/// La fonction `join_slices` suivante est **malsaine** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // L'assertion ci-dessus garantit que `fst` et `snd` sont contigus, mais ils peuvent toujours être contenus dans _different allocated objects_, auquel cas la création de cette tranche est un comportement indéfini.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` et `b` sont des objets alloués différents ...
///     let a = 42;
///     let b = 27;
///     // ... qui peuvent néanmoins être disposés de manière contiguë en mémoire: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Exécute les mêmes fonctionnalités que [`from_raw_parts`], sauf qu'une tranche mutable est renvoyée.
///
/// # Safety
///
/// Le comportement n'est pas défini si l'une des conditions suivantes n'est pas respectée:
///
/// * `data` doit être [valid] pour les lectures et les écritures pour `len * mem::size_of::<T>()` de nombreux octets, et il doit être correctement aligné.Cela signifie notamment:
///
///     * Toute la plage de mémoire de cette tranche doit être contenue dans un seul objet alloué!
///       Les tranches ne peuvent jamais s'étendre sur plusieurs objets alloués.
///     * `data` doit être non nul et aligné même pour les tranches de longueur nulle.
///     L'une des raisons à cela est que les optimisations de mise en page enum peuvent s'appuyer sur des références (y compris des tranches de toute longueur) alignées et non nulles pour les distinguer des autres données.
///
///     Vous pouvez obtenir un pointeur utilisable en tant que `data` pour les tranches de longueur nulle à l'aide de [`NonNull::dangling()`].
///
/// * `data` doit pointer vers `len` valeurs correctement initialisées consécutives de type `T`.
///
/// * La mémoire référencée par la tranche renvoyée ne doit pas être accédée via un autre pointeur (non dérivé de la valeur de retour) pendant la durée de vie `'a`.
///   Les accès en lecture et en écriture sont interdits.
///
/// * La taille totale `len * mem::size_of::<T>()` de la tranche ne doit pas être supérieure à `isize::MAX`.
///   Consultez la documentation de sécurité du [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Convertit une référence à T en une tranche de longueur 1 (sans copie).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Convertit une référence à T en une tranche de longueur 1 (sans copie).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}