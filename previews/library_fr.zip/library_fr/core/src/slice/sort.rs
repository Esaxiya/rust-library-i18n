//! Tri des tranches
//!
//! Ce module contient un algorithme de tri basé sur le tri rapide d'Orson Peters qui défait les motifs, publié sur: <https://github.com/orlp/pdqsort>
//!
//!
//! Le tri instable est compatible avec libcore car il n'alloue pas de mémoire, contrairement à notre implémentation de tri stable.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Une fois déposé, copie de `src` vers `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // SÉCURITÉ: Ceci est une classe d'assistance.
        //          Veuillez vous référer à son utilisation pour l'exactitude.
        //          À savoir, il faut être sûr que `src` et `dst` ne se chevauchent pas comme requis par `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Déplace le premier élément vers la droite jusqu'à ce qu'il rencontre un élément supérieur ou égal.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SÉCURITÉ: Les opérations non sécurisées ci-dessous impliquent une indexation sans contrôle lié (`get_unchecked` et `get_unchecked_mut`)
    // et copie de la mémoire (`ptr::copy_nonoverlapping`).
    //
    // une.Indexage:
    //  1. Nous avons vérifié la taille du tableau à>=2.
    //  2. Toute l'indexation que nous ferons se fera toujours entre {0 <= index < len} au maximum.
    //
    // b.Copie de la mémoire
    //  1. Nous obtenons des pointeurs vers des références dont la validité est garantie.
    //  2. Ils ne peuvent pas se chevaucher car nous obtenons des pointeurs vers des indices de différence de la tranche.
    //     À savoir, `i` et `i-1`.
    //  3. Si la tranche est correctement alignée, les éléments sont correctement alignés.
    //     Il est de la responsabilité de l'appelant de s'assurer que la tranche est correctement alignée.
    //
    // Voir les commentaires ci-dessous pour plus de détails.
    unsafe {
        // Si les deux premiers éléments sont en panne ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Lisez le premier élément dans une variable allouée à la pile.
            // Si une opération de comparaison suivante panics, `hole` sera abandonnée et réécrira automatiquement l'élément dans la tranche.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Déplacez le «i» élément d'un endroit vers la gauche, déplaçant ainsi le trou vers la droite.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` est abandonné et copie ainsi `tmp` dans le trou restant de `v`.
        }
    }
}

/// Décale le dernier élément vers la gauche jusqu'à ce qu'il rencontre un élément plus petit ou égal.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SÉCURITÉ: Les opérations non sécurisées ci-dessous impliquent une indexation sans contrôle lié (`get_unchecked` et `get_unchecked_mut`)
    // et copie de la mémoire (`ptr::copy_nonoverlapping`).
    //
    // une.Indexage:
    //  1. Nous avons vérifié la taille du tableau à>=2.
    //  2. Toute l'indexation que nous ferons se fera toujours entre `0 <= index < len-1` au plus.
    //
    // b.Copie de la mémoire
    //  1. Nous obtenons des pointeurs vers des références dont la validité est garantie.
    //  2. Ils ne peuvent pas se chevaucher car nous obtenons des pointeurs vers des indices de différence de la tranche.
    //     À savoir, `i` et `i+1`.
    //  3. Si la tranche est correctement alignée, les éléments sont correctement alignés.
    //     Il est de la responsabilité de l'appelant de s'assurer que la tranche est correctement alignée.
    //
    // Voir les commentaires ci-dessous pour plus de détails.
    unsafe {
        // Si les deux derniers éléments sont en panne ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Lisez le dernier élément dans une variable allouée à la pile.
            // Si une opération de comparaison suivante panics, `hole` sera abandonnée et réécrira automatiquement l'élément dans la tranche.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Déplacez le «i» élément d'un endroit vers la droite, déplaçant ainsi le trou vers la gauche.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` est abandonné et copie ainsi `tmp` dans le trou restant de `v`.
        }
    }
}

/// Trie partiellement une tranche en déplaçant plusieurs éléments dans le désordre.
///
/// Renvoie `true` si la tranche est triée à la fin.Cette fonction est le pire des cas *O*(*n*).
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Nombre maximum de paires adjacentes dans le désordre qui seront décalées.
    const MAX_STEPS: usize = 5;
    // Si la tranche est plus courte que cela, ne déplacez aucun élément.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // SÉCURITÉ: Nous avons déjà fait explicitement la vérification liée avec `i < len`.
        // Toutes nos indexations ultérieures sont uniquement dans la gamme `0 <= index < len`
        unsafe {
            // Trouvez la prochaine paire d'éléments adjacents dans le désordre.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Avons-nous fini?
        if i == len {
            return true;
        }

        // Ne déplacez pas les éléments sur des tableaux courts, cela a un coût en termes de performances.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Échangez la paire d'éléments trouvés.Cela les met dans le bon ordre.
        v.swap(i - 1, i);

        // Déplacez le plus petit élément vers la gauche.
        shift_tail(&mut v[..i], is_less);
        // Déplacez le plus grand élément vers la droite.
        shift_head(&mut v[i..], is_less);
    }

    // N'a pas réussi à trier la tranche dans le nombre limité d'étapes.
    false
}

/// Trie une tranche en utilisant le tri par insertion, qui est le pire des cas *O*(*n*^ 2).
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Trie `v` en utilisant heapsort, ce qui garantit *O*(*n*\*log(* n*)) dans le pire des cas.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ce tas binaire respecte l'invariant `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Enfants de `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Choisissez le plus grand enfant.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Arrêtez-vous si l'invariant tient à `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Échangez `node` avec le plus grand enfant, déplacez-vous d'un cran vers le bas et continuez à tamiser.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Construisez le tas en temps linéaire.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pop éléments maximaux du tas.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Partitionne `v` en éléments plus petits que `pivot`, suivis par des éléments supérieurs ou égaux à `pivot`.
///
///
/// Renvoie le nombre d'éléments inférieur à `pivot`.
///
/// Le partitionnement est effectué bloc par bloc afin de minimiser le coût des opérations de branchement.
/// Cette idée est présentée dans l'article [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Nombre d'éléments dans un bloc typique.
    const BLOCK: usize = 128;

    // L'algorithme de partitionnement répète les étapes suivantes jusqu'à la fin:
    //
    // 1. Tracez un bloc du côté gauche pour identifier les éléments supérieurs ou égaux au pivot.
    // 2. Tracez un bloc du côté droit pour identifier les éléments plus petits que le pivot.
    // 3. Échangez les éléments identifiés entre le côté gauche et le côté droit.
    //
    // Nous conservons les variables suivantes pour un bloc d'éléments:
    //
    // 1. `block` - Nombre d'éléments dans le bloc.
    // 2. `start` - Démarrez le pointeur dans le tableau `offsets`.
    // 3. `end` - Pointeur de fin dans le tableau `offsets`.
    // 4. `offsets, indices des éléments dans le désordre dans le bloc.

    // Le bloc actuel sur le côté gauche (de `l` à `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Le bloc actuel sur le côté droit (à partir de `r.sub(block_r)` to `r`).
    // SÉCURITÉ: La documentation pour .add() mentionne spécifiquement que `vec.as_ptr().add(vec.len())` est toujours sûr`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Lorsque nous obtenons des VLA, essayez de créer un tableau de longueur `min(v.len(), 2 * BLOCK) `plutôt
    // plus de deux tableaux de taille fixe de longueur `BLOCK`.Les VLA peuvent être plus efficaces pour le cache.

    // Renvoie le nombre d'éléments entre les pointeurs `l` (inclusive) et `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Nous en avons terminé avec le partitionnement bloc par bloc lorsque `l` et `r` sont très proches.
        // Ensuite, nous effectuons un travail de correction afin de partitionner les éléments restants entre les deux.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Nombre d'éléments restants (toujours pas comparé au pivot).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Ajustez la taille des blocs afin que les blocs gauche et droit ne se chevauchent pas, mais soient parfaitement alignés pour couvrir tout l'espace restant.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Tracez les éléments `block_l` du côté gauche.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // SÉCURITÉ: Les opérations de non-sécurité ci-dessous impliquent l'utilisation du `offset`.
                //         Selon les conditions requises par la fonction, nous les remplissons car:
                //         1. `offsets_l` est alloué par pile, et donc considéré comme un objet alloué distinct.
                //         2. La fonction `is_less` renvoie un `bool`.
                //            La diffusion d'un `bool` ne débordera jamais de `isize`.
                //         3. Nous avons garanti que `block_l` sera `<= BLOCK`.
                //            De plus, `end_l` a été initialement défini sur le pointeur de début de `offsets_` qui a été déclaré sur la pile.
                //            Ainsi, nous savons que même dans le pire des cas (toutes les invocations de `is_less` retournent false) nous ne serons qu'au plus 1 octet passe la fin.
                //        Une autre opération non sécurisée ici consiste à déréférencer `elem`.
                //        Cependant, `elem` était initialement le pointeur de début vers la tranche qui est toujours valide.
                unsafe {
                    // Comparaison sans branche.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Tracez les éléments `block_r` du côté droit.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // SÉCURITÉ: Les opérations de non-sécurité ci-dessous impliquent l'utilisation du `offset`.
                //         Selon les conditions requises par la fonction, nous les remplissons car:
                //         1. `offsets_r` est alloué par pile, et donc considéré comme un objet alloué distinct.
                //         2. La fonction `is_less` renvoie un `bool`.
                //            La diffusion d'un `bool` ne débordera jamais de `isize`.
                //         3. Nous avons garanti que `block_r` sera `<= BLOCK`.
                //            De plus, `end_r` a été initialement défini sur le pointeur de début de `offsets_` qui a été déclaré sur la pile.
                //            Ainsi, nous savons que même dans le pire des cas (toutes les invocations de `is_less` retournent vrai) nous ne serons qu'au plus 1 octet à la fin.
                //        Une autre opération non sécurisée ici consiste à déréférencer `elem`.
                //        Cependant, `elem` était initialement `1 *sizeof(T)` au-delà de la fin et nous le décrémentons de `1* sizeof(T)` avant d'y accéder.
                //        De plus, il a été affirmé que `block_r` était inférieur à `BLOCK` et `elem` pointerait donc tout au plus vers le début de la tranche.
                unsafe {
                    // Comparaison sans branche.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Nombre d'éléments dans le désordre à permuter entre le côté gauche et le côté droit.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Au lieu d'échanger une paire à la fois, il est plus efficace d'effectuer une permutation cyclique.
            // Ce n'est pas strictement équivalent à l'échange, mais produit un résultat similaire en utilisant moins d'opérations de mémoire.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Tous les éléments dans le désordre du bloc de gauche ont été déplacés.Passez au bloc suivant.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Tous les éléments dans le désordre du bloc de droite ont été déplacés.Passez au bloc précédent.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Tout ce qui reste maintenant est au plus un bloc (à gauche ou à droite) avec des éléments dans le désordre qui doivent être déplacés.
    // Ces éléments restants peuvent être simplement déplacés vers la fin de leur bloc.
    //

    if start_l < end_l {
        // Le bloc de gauche reste.
        // Déplacez ses éléments restants dans le désordre vers l'extrême droite.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Le bon bloc demeure.
        // Déplacez ses éléments restants dans le désordre vers l'extrême gauche.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Rien d'autre à faire, nous avons terminé.
        width(v.as_mut_ptr(), l)
    }
}

/// Partitionne `v` en éléments plus petits que `v[pivot]`, suivis par des éléments supérieurs ou égaux à `v[pivot]`.
///
///
/// Renvoie un tuple de:
///
/// 1. Nombre d'éléments inférieur à `v[pivot]`.
/// 2. Vrai si `v` a déjà été partitionné.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Placez le pivot au début de la tranche.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Lisez le pivot dans une variable allouée à la pile pour plus d'efficacité.
        // Si une opération de comparaison suivante panics, le pivot sera automatiquement réécrit dans la tranche.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Trouvez la première paire d'éléments dans le désordre.
        let mut l = 0;
        let mut r = v.len();

        // SÉCURITÉ: La non-sécurité ci-dessous implique l'indexation d'un tableau.
        // Pour le premier: nous faisons déjà la vérification des limites ici avec `l < r`.
        // Pour le second: Nous avons initialement `l == 0` et `r == v.len()` et nous avons vérifié que `l < r` à chaque opération d'indexation.
        //                     De là, nous savons que `r` doit être au moins `r == l`, ce qui s'est avéré valide dès le premier.
        unsafe {
            // Trouvez le premier élément supérieur ou égal au pivot.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Trouvez le dernier élément plus petit que le pivot.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` sort de la portée et réécrit le pivot (qui est une variable allouée à la pile) dans la tranche où il se trouvait à l'origine.
        // Cette étape est essentielle pour garantir la sécurité!
        //
    };

    // Placez le pivot entre les deux partitions.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Partitionne `v` en éléments égaux à `v[pivot]` suivis d'éléments supérieurs à `v[pivot]`.
///
/// Renvoie le nombre d'éléments égal au pivot.
/// On suppose que `v` ne contient pas d'éléments plus petits que le pivot.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Placez le pivot au début de la tranche.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Lisez le pivot dans une variable allouée à la pile pour plus d'efficacité.
    // Si une opération de comparaison suivante panics, le pivot sera automatiquement réécrit dans la tranche.
    // SÉCURITÉ: Le pointeur ici est valide car il est obtenu à partir d'une référence à une tranche.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Maintenant, partitionnez la tranche.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // SÉCURITÉ: La non-sécurité ci-dessous implique l'indexation d'un tableau.
        // Pour le premier: nous faisons déjà la vérification des limites ici avec `l < r`.
        // Pour le second: Nous avons initialement `l == 0` et `r == v.len()` et nous avons vérifié que `l < r` à chaque opération d'indexation.
        //                     De là, nous savons que `r` doit être au moins `r == l`, ce qui s'est avéré valide dès le premier.
        unsafe {
            // Trouvez le premier élément plus grand que le pivot.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Trouvez le dernier élément égal au pivot.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Avons-nous fini?
            if l >= r {
                break;
            }

            // Échangez la paire trouvée d'éléments dans le désordre.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Nous avons trouvé des éléments `l` égaux au pivot.Ajoutez 1 pour tenir compte du pivot lui-même.
    l + 1

    // `_pivot_guard` sort de la portée et réécrit le pivot (qui est une variable allouée à la pile) dans la tranche où il se trouvait à l'origine.
    // Cette étape est essentielle pour garantir la sécurité!
}

/// Disperse certains éléments dans une tentative de briser les modèles qui pourraient provoquer des partitions déséquilibrées dans le tri rapide.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Générateur de nombres pseudo-aléatoires à partir de l'article "Xorshift RNGs" de George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Prenez des nombres aléatoires modulo ce nombre.
        // Le nombre rentre dans `usize` car `len` n'est pas supérieur à `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Certains candidats pivots seront à proximité de cet index.Disons-les au hasard.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Génère un nombre aléatoire modulo `len`.
            // Cependant, afin d'éviter des opérations coûteuses, nous le prenons d'abord modulo une puissance de deux, puis diminuons de `len` jusqu'à ce qu'il rentre dans la gamme `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` est garanti inférieur à `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Choisit un pivot dans `v` et renvoie l'index et `true` si la tranche est probablement déjà triée.
///
/// Les éléments de `v` peuvent être réorganisés au cours du processus.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Longueur minimale pour choisir la méthode de la médiane des médianes.
    // Les tranches plus courtes utilisent la méthode simple de la médiane de trois.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Nombre maximum de swaps pouvant être effectués dans cette fonction.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Trois indices près desquels nous allons choisir un pivot.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Compte le nombre total de swaps que nous sommes sur le point d'effectuer lors du tri des indices.
    let mut swaps = 0;

    if len >= 8 {
        // Échange les indices pour que `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Échange les indices pour que `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Recherche la médiane de `v[a - 1], v[a], v[a + 1]` et stocke l'index dans `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Trouvez des médianes aux alentours de `a`, `b` et `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Trouvez la médiane entre `a`, `b` et `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Le nombre maximum de swaps a été effectué.
        // Il y a de fortes chances que la tranche soit descendante ou principalement descendante, donc l'inversion aidera probablement à la trier plus rapidement.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Trie `v` de manière récursive.
///
/// Si la tranche avait un prédécesseur dans le tableau d'origine, il est spécifié comme `pred`.
///
/// `limit` est le nombre de partitions déséquilibrées autorisées avant de passer à `heapsort`.
/// Si zéro, cette fonction passera immédiatement au tri en tas.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Les tranches jusqu'à cette longueur sont triées à l'aide du tri par insertion.
    const MAX_INSERTION: usize = 20;

    // Vrai si le dernier partitionnement était raisonnablement équilibré.
    let mut was_balanced = true;
    // Vrai si le dernier partitionnement n'a pas mélangé les éléments (la tranche était déjà partitionnée).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Les tranches très courtes sont triées à l'aide du tri par insertion.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Si trop de mauvais choix de pivot ont été faits, il vous suffit de revenir au tri en masse afin de garantir le pire des cas `O(n * log(n))`.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Si le dernier partitionnement était déséquilibré, essayez de briser les modèles dans la tranche en mélangeant certains éléments.
        // J'espère que nous choisirons un meilleur pivot cette fois.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Choisissez un pivot et essayez de deviner si la tranche est déjà triée.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Si le dernier partitionnement était correctement équilibré et ne mélangeait pas les éléments, et si la sélection de pivot prédit la tranche est probablement déjà triée ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Essayez d'identifier plusieurs éléments dans le désordre et de les déplacer vers les positions correctes.
            // Si la tranche finit par être complètement triée, nous avons terminé.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Si le pivot choisi est égal au prédécesseur, il s'agit du plus petit élément de la tranche.
        // Partitionnez la tranche en éléments égaux à et en éléments supérieurs au pivot.
        // Ce cas est généralement atteint lorsque la tranche contient de nombreux éléments en double.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Continuez à trier les éléments supérieurs au pivot.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Partitionnez la tranche.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Divisez la tranche en `left`, `pivot` et `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Réexécutez le côté le plus court uniquement afin de minimiser le nombre total d'appels récursifs et de consommer moins d'espace dans la pile.
        // Ensuite, continuez simplement avec le côté le plus long (cela s'apparente à la récursivité de la queue).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Trie `v` à l'aide d'un tri rapide anti-modèle, qui est *O*(*n*\*log(* n*)) dans le pire des cas.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Le tri n'a pas de comportement significatif sur les types de taille zéro.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Limitez le nombre de partitions déséquilibrées à `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Pour les tranches jusqu'à cette longueur, il est probablement plus rapide de les trier simplement.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Choisissez un pivot
        let (pivot, _) = choose_pivot(v, is_less);

        // Si le pivot choisi est égal au prédécesseur, il s'agit du plus petit élément de la tranche.
        // Partitionnez la tranche en éléments égaux à et en éléments supérieurs au pivot.
        // Ce cas est généralement atteint lorsque la tranche contient de nombreux éléments en double.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Si nous avons passé notre indice, alors nous sommes bons.
                if mid > index {
                    return;
                }

                // Sinon, continuez à trier les éléments supérieurs au pivot.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Divisez la tranche en `left`, `pivot` et `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Si mid==index, alors nous avons terminé, puisque partition() garantit que tous les éléments après mid sont supérieurs ou égaux à mid.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Le tri n'a pas de comportement significatif sur les types de taille zéro.Ne fais rien.
    } else if index == v.len() - 1 {
        // Trouvez l'élément max et placez-le dans la dernière position du tableau.
        // Nous sommes libres d'utiliser `unwrap()` ici car nous savons que v ne doit pas être vide.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Trouvez l'élément min et placez-le dans la première position du tableau.
        // Nous sommes libres d'utiliser `unwrap()` ici car nous savons que v ne doit pas être vide.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}