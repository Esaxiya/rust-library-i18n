//! Opérations sur ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Vérifie si tous les octets de cette tranche sont dans la plage ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Vérifie que deux tranches sont une correspondance ASCII insensible à la casse.
    ///
    /// Identique à `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, mais sans allouer ni copier les temporaires.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Convertit cette tranche en son équivalent en majuscules ASCII sur place.
    ///
    /// Les lettres ASCII 'a' à 'z' sont mappées entre 'A' et 'Z', mais les lettres non ASCII restent inchangées.
    ///
    /// Pour renvoyer une nouvelle valeur en majuscules sans modifier la valeur existante, utilisez [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Convertit cette tranche en son équivalent en minuscules ASCII sur place.
    ///
    /// Les lettres ASCII 'A' à 'Z' sont mappées entre 'a' et 'z', mais les lettres non ASCII restent inchangées.
    ///
    /// Pour renvoyer une nouvelle valeur en minuscules sans modifier la valeur existante, utilisez [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Renvoie `true` si un octet du mot `v` est nonascii (>=128).
/// Snarfed de `../str/mod.rs`, qui fait quelque chose de similaire pour la validation utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Test ASCII optimisé qui utilisera des opérations de taille à la fois au lieu d'opérations octet à la fois (si possible).
///
/// L'algorithme que nous utilisons ici est assez simple.Si `s` est trop court, nous vérifions simplement chaque octet et en avons terminé.Sinon:
///
/// - Lisez le premier mot avec une charge non alignée.
/// - Alignez le pointeur, lisez les mots suivants jusqu'à la fin avec des charges alignées.
/// - Lisez le dernier `usize` de `s` avec une charge non alignée.
///
/// Si l'une de ces charges produit quelque chose pour lequel `contains_nonascii` (above) renvoie vrai, alors nous savons que la réponse est fausse.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Si nous ne gagnerions rien de l'implémentation mot à la fois, revenons à une boucle scalaire.
    //
    // Nous faisons également cela pour les architectures où `size_of::<usize>()` n'est pas un alignement suffisant pour `usize`, car c'est un cas étrange de edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Nous lisons toujours le premier mot non aligné, ce qui signifie que `align_offset` est
    // 0, nous lirions à nouveau la même valeur pour la lecture alignée.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // SÉCURITÉ: Nous vérifions `len < USIZE_SIZE` ci-dessus.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Nous avons vérifié cela ci-dessus, quelque peu implicitement.
    // Notez que `offset_to_aligned` est soit `align_offset` soit `USIZE_SIZE`, les deux sont explicitement vérifiés ci-dessus.
    //
    debug_assert!(offset_to_aligned <= len);

    // SÉCURITÉ: word_ptr est le (correctement aligné) usize ptr que nous utilisons pour lire le
    // morceau du milieu de la tranche.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` est l'index d'octet de `word_ptr`, utilisé pour les vérifications de fin de boucle.
    let mut byte_pos = offset_to_aligned;

    // Contrôle de la paranoïa sur l'alignement, car nous sommes sur le point de faire un tas de charges non alignées.
    // En pratique, cela devrait être impossible sauf un bogue dans `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Lisez les mots suivants jusqu'au dernier mot aligné, en excluant le dernier mot aligné par lui-même à faire plus tard dans la vérification de la queue, pour vous assurer que la queue est toujours un `usize` au plus à branch `byte_pos == len` supplémentaire.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Vérifiez que la lecture est dans les limites
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Et que nos hypothèses sur `byte_pos` tiennent.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // SÉCURITÉ: Nous savons que `word_ptr` est correctement aligné (en raison de
        // `align_offset`), et nous savons que nous avons assez d'octets entre `word_ptr` et la fin
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // SÉCURITÉ: Nous savons que `byte_pos <= len - USIZE_SIZE`, ce qui signifie que
        // après ce `add`, `word_ptr` sera au plus un-après-la-fin.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Vérifiez l'intégrité pour vous assurer qu'il ne reste vraiment qu'un seul `usize`.
    // Cela devrait être garanti par notre condition de boucle.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // SÉCURITÉ: Cela repose sur `len >= USIZE_SIZE`, que nous vérifions au début.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}