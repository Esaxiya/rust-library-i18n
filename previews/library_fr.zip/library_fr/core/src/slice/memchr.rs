// Implémentation originale tirée de rust-memchr.
// Copyright 2015 Andrew Gallant, bluss et Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Utilisez la troncature.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Renvoie `true` si `x` contient un octet de zéro.
///
/// De *Matters Computational*, J. Arndt:
///
/// "L'idée est de soustraire un de chacun des octets, puis de rechercher les octets où l'emprunt s'est propagé jusqu'au plus significatif
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Renvoie le premier index correspondant à l'octet `x` dans `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Chemin rapide pour les petites tranches
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Recherchez une valeur d'octet unique en lisant deux mots `usize` à la fois.
    //
    // Split `text` en trois parties
    // - partie initiale non alignée, avant le premier mot adresse alignée dans le texte
    // - corps, scannez par 2 mots à la fois
    // - la dernière partie restante, <2 mots de taille

    // recherche jusqu'à une limite alignée
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // rechercher le corps du texte
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // SÉCURITÉ: le prédicat while garantit une distance d'au moins 2 * usize_bytes
        // entre le décalage et la fin de la tranche.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // break s'il y a un octet correspondant
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Trouvez l'octet après le point où la boucle de corps s'est arrêtée.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Renvoie le dernier index correspondant à l'octet `x` dans `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Recherchez une valeur d'octet unique en lisant deux mots `usize` à la fois.
    //
    // Divisez `text` en trois parties:
    // - queue non alignée, après le dernier mot de l'adresse alignée dans le texte,
    // - corps, scanné par 2 mots à la fois,
    // - les premiers octets restants, <2 mots de taille.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Nous appelons cela juste pour obtenir la longueur du préfixe et du suffixe.
        // Au milieu, nous traitons toujours deux morceaux à la fois.
        // SÉCURITÉ: la transmutation de `[u8]` en `[usize]` est sûre, sauf pour les différences de taille qui sont gérées par `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Recherchez le corps du texte, assurez-vous que nous ne traversons pas min_aligned_offset.
    // l'offset est toujours aligné, il suffit donc de tester `>` et d'éviter un éventuel débordement.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // SÉCURITÉ: le décalage commence à len, suffix.len(), tant qu'il est supérieur à
        // min_aligned_offset (prefix.len()) la distance restante est d'au moins 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Break s'il y a un octet correspondant.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Trouvez l'octet avant le point où la boucle de corps s'est arrêtée.
    text[..offset].iter().rposition(|elt| *elt == x)
}