// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Fait pivoter la plage `[mid-left, mid+right)` de sorte que l'élément à `mid` devienne le premier élément.De manière équivalente, fait pivoter les éléments `left` de la plage vers la gauche ou les éléments `right` vers la droite.
///
/// # Safety
///
/// La plage spécifiée doit être valide pour la lecture et l'écriture.
///
/// # Algorithm
///
/// L'algorithme 1 est utilisé pour les petites valeurs de `left + right` ou pour les grandes `T`.
/// Les éléments sont déplacés dans leurs positions finales un par un en commençant à `mid - left` et en avançant par les étapes `right` modulo `left + right`, de sorte qu'un seul temporaire est nécessaire.
/// Finalement, nous arrivons à `mid - left`.
/// Cependant, si `gcd(left + right, right)` n'est pas 1, les étapes ci-dessus ont ignoré des éléments.
/// Par example:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Heureusement, le nombre d'éléments sautés entre les éléments finalisés est toujours égal, nous pouvons donc simplement décaler notre position de départ et faire plus de tours (le nombre total de tours est le `gcd(left + right, right)` value).
///
/// Le résultat final est que tous les éléments sont finalisés une et une seule fois.
///
/// L'algorithme 2 est utilisé si `left + right` est grand mais `min(left, right)` est suffisamment petit pour tenir sur un tampon de pile.
/// Les éléments `min(left, right)` sont copiés sur le tampon, `memmove` est appliqué aux autres et ceux du tampon sont ramenés dans le trou du côté opposé à leur origine.
///
/// Les algorithmes qui peuvent être vectorisés surpassent ceux ci-dessus une fois que `left + right` devient suffisamment grand.
/// L'algorithme 1 peut être vectorisé en segmentant et en effectuant plusieurs tours à la fois, mais il y a trop peu de tours en moyenne jusqu'à ce que `left + right` soit énorme, et le pire des cas d'un seul tour est toujours là.
/// Au lieu de cela, l'algorithme 3 utilise l'échange répété d'éléments `min(left, right)` jusqu'à ce qu'un problème de rotation plus petit soit laissé.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// lorsque `left < right`, l'échange se fait par la gauche à la place.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. les algorithmes ci-dessous peuvent échouer si ces cas ne sont pas vérifiés
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algorithme 1 Les microbenchmarks indiquent que les performances moyennes pour les décalages aléatoires sont meilleures jusqu'à environ `left + right == 32`, mais dans le pire des cas, les performances se situent même autour de 16.
            // 24 a été choisi comme moyen terme.
            // Si la taille de `T` est supérieure à 4 `usize`s, cet algorithme surpasse également les autres algorithmes.
            //
            //
            let x = unsafe { mid.sub(left) };
            // début du premier tour
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` peut être trouvé à l'avance en calculant `gcd(left + right, right)`, mais il est plus rapide de faire une boucle qui calcule le pgcd comme effet secondaire, puis de faire le reste du morceau
            //
            //
            let mut gcd = right;
            // Les benchmarks révèlent qu'il est plus rapide d'échanger des temporaires tout au long au lieu de lire un temporaire une fois, de le copier à l'envers, puis d'écrire ce temporaire à la toute fin.
            // Cela est peut-être dû au fait que l'échange ou le remplacement des temporaires n'utilise qu'une seule adresse mémoire dans la boucle au lieu de devoir en gérer deux.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // au lieu d'incrémenter `i` puis de vérifier s'il est en dehors des limites, nous vérifions si `i` sortira des limites au prochain incrément.
                // Cela empêche tout encapsulation des pointeurs ou `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // fin du premier tour
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // ce conditionnel doit être ici si `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // terminer le morceau avec plus de tours
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` n'est pas un type de taille zéro, donc vous pouvez diviser par sa taille.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algorithme 2 Le `[T; 0]` est ici pour s'assurer qu'il est correctement aligné pour T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algorithme 3 Il existe une autre façon de permuter qui consiste à trouver où se trouverait le dernier échange de cet algorithme et à échanger en utilisant ce dernier morceau au lieu d'échanger des morceaux adjacents comme le fait cet algorithme, mais cette façon est encore plus rapide.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algorithme 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}