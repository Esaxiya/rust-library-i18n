//! Macros utilisées par les itérateurs de slice.

// L'intégration de is_empty et len fait une énorme différence de performances
macro_rules! is_empty {
    // La façon dont nous encodons la longueur d'un itérateur ZST, cela fonctionne à la fois pour ZST et non-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Pour se débarrasser de certaines vérifications de limites (voir `position`), nous calculons la longueur d'une manière quelque peu inattendue.
// (Testé par `codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // nous sommes parfois utilisés dans un bloc non sécurisé

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Ce _cannot_ utilise `unchecked_sub` car nous dépendons du wrapping pour représenter la longueur des itérateurs de tranches ZST longs.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Nous savons que `start <= end`, peut donc faire mieux que `offset_from`, qui doit traiter en signé.
            // En définissant les indicateurs appropriés ici, nous pouvons dire cela à LLVM, ce qui l'aide à supprimer les vérifications de limites.
            // SÉCURITÉ: Par le type invariant, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // En indiquant également à LLVM que les pointeurs sont séparés par un multiple exact de la taille du type, il peut optimiser `len() == 0` jusqu'à `start == end` au lieu de `(end - start) < size`.
            //
            // SÉCURITÉ: Par le type invariant, les pointeurs sont alignés de sorte que le
            //         la distance entre eux doit être un multiple de la taille de la pointe
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// La définition partagée des itérateurs `Iter` et `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Renvoie le premier élément et déplace le début de l'itérateur vers l'avant de 1.
        // Améliore considérablement les performances par rapport à une fonction intégrée.
        // L'itérateur ne doit pas être vide.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Renvoie le dernier élément et déplace la fin de l'itérateur vers l'arrière de 1.
        // Améliore considérablement les performances par rapport à une fonction intégrée.
        // L'itérateur ne doit pas être vide.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Réduit l'itérateur lorsque T est un ZST, en déplaçant la fin de l'itérateur vers l'arrière de `n`.
        // `n` ne doit pas dépasser `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Fonction d'aide pour créer une tranche à partir de l'itérateur.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // SÉCURITÉ: l'itérateur a été créé à partir d'une tranche avec pointeur
                // `self.ptr` et longueur `len!(self)`.
                // Cela garantit que toutes les conditions préalables pour `from_raw_parts` sont remplies.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Fonction d'assistance pour faire avancer le début de l'itérateur par des éléments `offset`, renvoyant l'ancien début.
            //
            // Non sécurisé car le décalage ne doit pas dépasser `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // SÉCURITÉ: l'appelant garantit que `offset` ne dépasse pas `self.len()`,
                    // donc ce nouveau pointeur est à l'intérieur de `self` et donc garanti non nul.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Fonction d'assistance pour déplacer la fin de l'itérateur vers l'arrière par des éléments `offset`, renvoyant la nouvelle fin.
            //
            // Non sécurisé car le décalage ne doit pas dépasser `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // SÉCURITÉ: l'appelant garantit que `offset` ne dépasse pas `self.len()`,
                    // qui est garanti de ne pas déborder un `isize`.
                    // En outre, le pointeur résultant est dans les limites de `slice`, qui remplit les autres exigences pour `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // pourrait être implémenté avec des tranches, mais cela évite les vérifications de limites

                // SÉCURITÉ: les appels `assume` sont sûrs car le pointeur de début d'une tranche
                // doit être non nul, et les tranches sur des non-ZST doivent également avoir un pointeur de fin non nul.
                // L'appel à `next_unchecked!` est sûr puisque nous vérifions d'abord si l'itérateur est vide.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Cet itérateur est maintenant vide.
                    if mem::size_of::<T>() == 0 {
                        // Nous devons le faire de cette façon car `ptr` peut ne jamais être 0, mais `end` pourrait l'être (en raison du wrapping).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // SÉCURITÉ: end ne peut pas être 0 si T n'est pas ZST car ptr n'est pas 0 et end>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // SÉCURITÉ: Nous sommes dans les limites.`post_inc_start` fait ce qu'il faut, même pour les ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Nous remplaçons l'implémentation par défaut, qui utilise `try_fold`, car cette implémentation simple génère moins d'IR LLVM et est plus rapide à compiler.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Nous remplaçons l'implémentation par défaut, qui utilise `try_fold`, car cette implémentation simple génère moins d'IR LLVM et est plus rapide à compiler.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Nous remplaçons l'implémentation par défaut, qui utilise `try_fold`, car cette implémentation simple génère moins d'IR LLVM et est plus rapide à compiler.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Nous remplaçons l'implémentation par défaut, qui utilise `try_fold`, car cette implémentation simple génère moins d'IR LLVM et est plus rapide à compiler.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Nous remplaçons l'implémentation par défaut, qui utilise `try_fold`, car cette implémentation simple génère moins d'IR LLVM et est plus rapide à compiler.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Nous remplaçons l'implémentation par défaut, qui utilise `try_fold`, car cette implémentation simple génère moins d'IR LLVM et est plus rapide à compiler.
            // De plus, le `assume` évite une vérification des limites.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // SÉCURITÉ: nous sommes assurés d'être dans les limites de l'invariant de boucle:
                        // lorsque `i >= n`, `self.next()` renvoie `None` et la boucle se rompt.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Nous remplaçons l'implémentation par défaut, qui utilise `try_fold`, car cette implémentation simple génère moins d'IR LLVM et est plus rapide à compiler.
            // De plus, le `assume` évite une vérification des limites.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // SÉCURITÉ: `i` doit être inférieur à `n` car il commence à `n`
                        // et ne fait que diminuer.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // SÉCURITÉ: l'appelant doit garantir que `i` est dans les limites de
                // la tranche sous-jacente, donc `i` ne peut pas déborder un `isize`, et les références renvoyées sont garanties de se référer à un élément de la tranche et donc garanties d'être valides.
                //
                // Notez également que l'appelant garantit également que nous ne sommes plus jamais appelés avec le même index, et qu'aucune autre méthode qui accèdera à cette sous-tranche n'est appelée, il est donc valide que la référence retournée soit modifiable dans le cas de
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // pourrait être implémenté avec des tranches, mais cela évite les vérifications de limites

                // SÉCURITÉ: les appels `assume` sont sûrs car le pointeur de début d'une tranche doit être non nul,
                // et les tranches sur des non-ZST doivent également avoir un pointeur de fin non nul.
                // L'appel à `next_back_unchecked!` est sûr puisque nous vérifions d'abord si l'itérateur est vide.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Cet itérateur est maintenant vide.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // SÉCURITÉ: Nous sommes dans les limites.`pre_dec_end` fait ce qu'il faut, même pour les ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}