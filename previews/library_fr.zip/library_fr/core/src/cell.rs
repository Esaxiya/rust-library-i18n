//! Conteneurs mutables partageables.
//!
//! La sécurité de la mémoire Rust est basée sur cette règle: étant donné un objet `T`, il est uniquement possible d'avoir l'un des éléments suivants:
//!
//! - Avoir plusieurs références immuables (`&T`) à l'objet (également appelé **aliasing**).
//! - Avoir une référence mutable (`&mut T`) à l'objet (également appelée **mutabilité**).
//!
//! Ceci est appliqué par le compilateur Rust.Cependant, il existe des situations où cette règle n'est pas suffisamment flexible.Parfois, il est nécessaire d'avoir plusieurs références à un objet et de le faire muter.
//!
//! Des conteneurs mutables partageables existent pour permettre la mutabilité d'une manière contrôlée, même en présence d'aliasing.Les deux [`Cell<T>`] et [`RefCell<T>`] permettent de faire cela d'une manière à un seul thread.
//! Cependant, ni `Cell<T>` ni `RefCell<T>` ne sont thread-safe (ils n'implémentent pas [`Sync`]).
//! Si vous devez effectuer des alias et des mutations entre plusieurs threads, il est possible d'utiliser les types [`Mutex<T>`], [`RwLock<T>`] ou [`atomic`].
//!
//! Les valeurs des types `Cell<T>` et `RefCell<T>` peuvent être mutées via des références partagées (c.-à-d.
//! le type `&T` commun), alors que la plupart des types Rust ne peuvent être mutés que par des références uniques («&mut T»).
//! Nous disons que `Cell<T>` et `RefCell<T>` fournissent une «mutabilité intérieure», contrairement aux types Rust typiques qui présentent une «mutabilité héréditaire».
//!
//! Les types de cellules sont disponibles en deux versions: `Cell<T>` et `RefCell<T>`.`Cell<T>` implémente la mutabilité intérieure en déplaçant les valeurs dans et hors du `Cell<T>`.
//! Pour utiliser des références au lieu de valeurs, il faut utiliser le type `RefCell<T>`, en acquérant un verrou d'écriture avant de muter.`Cell<T>` fournit des méthodes pour récupérer et modifier la valeur intérieure actuelle:
//!
//!  - Pour les types qui implémentent [`Copy`], la méthode [`get`](Cell::get) récupère la valeur intérieure actuelle.
//!  - Pour les types qui implémentent [`Default`], la méthode [`take`](Cell::take) remplace la valeur intérieure actuelle par [`Default::default()`] et renvoie la valeur remplacée.
//!  - Pour tous les types, la méthode [`replace`](Cell::replace) remplace la valeur intérieure actuelle et renvoie la valeur remplacée et la méthode [`into_inner`](Cell::into_inner) consomme le `Cell<T>` et renvoie la valeur intérieure.
//!  En outre, la méthode [`set`](Cell::set) remplace la valeur intérieure, supprimant la valeur remplacée.
//!
//! `RefCell<T>` utilise les durées de vie de Rust pour implémenter un «emprunt dynamique», un processus par lequel on peut réclamer un accès temporaire, exclusif et modifiable à la valeur interne.
//! Emprunts pour `RefCell<T>`s sont suivis 'au moment de l'exécution', contrairement aux types de référence natifs de Rust qui sont entièrement suivis de manière statique, au moment de la compilation.
//! Étant donné que les emprunts `RefCell<T>` sont dynamiques, il est possible d'essayer d'emprunter une valeur déjà empruntée mutuellement;lorsque cela se produit, il en résulte un fil panic.
//!
//! # Quand choisir la mutabilité intérieure
//!
//! La mutabilité héritée la plus courante, où l'on doit avoir un accès unique pour muter une valeur, est l'un des éléments clés du langage qui permet à Rust de raisonner fortement sur l'aliasing du pointeur, empêchant statiquement les bogues de crash.
//! Pour cette raison, la mutabilité héréditaire est préférée, et la mutabilité intérieure est quelque chose de dernier recours.
//! Étant donné que les types de cellules permettent une mutation là où elle serait autrement interdite, il y a des occasions où la mutabilité intérieure pourrait être appropriée, ou même *doit* être utilisé, par exemple
//!
//! * Présentation de la mutabilité 'inside' de quelque chose d'immuable
//! * Détails de mise en œuvre des méthodes logiquement immuables.
//! * Implémentations mutantes de [`Clone`].
//!
//! ## Présentation de la mutabilité 'inside' de quelque chose d'immuable
//!
//! De nombreux types de pointeurs intelligents partagés, notamment [`Rc<T>`] et [`Arc<T>`], fournissent des conteneurs qui peuvent être clonés et partagés entre plusieurs parties.
//! Étant donné que les valeurs contenues peuvent avoir des alias multiples, elles ne peuvent être empruntées qu'avec `&`, pas `&mut`.
//! Sans cellules, il serait impossible de faire muter les données à l'intérieur de ces pointeurs intelligents.
//!
//! Il est alors très courant de mettre un `RefCell<T>` dans des types de pointeurs partagés pour réintroduire la mutabilité:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Créer un nouveau bloc pour limiter la portée de l'emprunt dynamique
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Notez que si nous n'avions pas laissé l'emprunt précédent du cache tomber hors de portée, l'emprunt suivant provoquerait un thread dynamique panic.
//!     //
//!     // C'est le principal danger lié à l'utilisation de `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Notez que cet exemple utilise `Rc<T>` et non `Arc<T>`.`RefCell<T>`s sont pour les scénarios à un seul thread.Envisagez d'utiliser [`RwLock<T>`] ou [`Mutex<T>`] si vous avez besoin d'une mutabilité partagée dans une situation multi-thread.
//!
//! ## Détails de mise en œuvre des méthodes logiquement immuables
//!
//! Parfois, il peut être souhaitable de ne pas exposer dans une API qu'une mutation se produit "under the hood".
//! Cela peut être dû au fait que, logiquement, l'opération est immuable, mais par exemple, la mise en cache oblige l'implémentation à effectuer une mutation;ou parce que vous devez utiliser la mutation pour implémenter une méthode trait qui a été initialement définie pour prendre `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Un calcul coûteux va ici
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Implémentations mutantes de `Clone`
//!
//! Il s'agit simplement d'un cas particulier, mais courant, du précédent: masquer la mutabilité pour des opérations qui semblent immuables.
//! La méthode [`clone`](Clone::clone) ne devrait pas changer la valeur source et est déclarée prendre `&self`, pas `&mut self`.
//! Par conséquent, toute mutation qui se produit dans la méthode `clone` doit utiliser des types de cellules.
//! Par exemple, [`Rc<T>`] maintient ses décomptes de références dans un `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Un emplacement mémoire mutable.
///
/// # Examples
///
/// Dans cet exemple, vous pouvez voir que `Cell<T>` active la mutation à l'intérieur d'un struct immuable.
/// En d'autres termes, il active "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // ERREUR: `my_struct` est immuable
/// // my_struct.regular_field =nouvelle_valeur;
///
/// // FONCTIONNE: bien que `my_struct` soit immuable, `special_field` est un `Cell`,
/// // qui peut toujours être muté
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Voir le [module-level documentation](self) pour plus.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Crée un `Cell<T>`, avec la valeur `Default` pour T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Crée un nouveau `Cell` contenant la valeur donnée.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Définit la valeur contenue.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Échange les valeurs de deux cellules.
    /// La différence avec `std::mem::swap` est que cette fonction ne nécessite pas de référence `&mut`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // SÉCURITÉ: Cela peut être risqué s'il est appelé à partir de threads séparés, mais `Cell`
        // est `!Sync` donc cela ne se produira pas.
        // Cela n'invalidera pas non plus les pointeurs puisque `Cell` s'assure que rien d'autre ne pointera vers l'une ou l'autre de ces `Cell`s.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Remplace la valeur contenue par `val` et renvoie l'ancienne valeur contenue.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // SÉCURITÉ: Cela peut provoquer des courses de données s'il est appelé à partir d'un thread séparé,
        // mais `Cell` est `!Sync` donc cela n'arrivera pas.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Décompresse la valeur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Renvoie une copie de la valeur contenue.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // SÉCURITÉ: Cela peut provoquer des courses de données s'il est appelé à partir d'un thread séparé,
        // mais `Cell` est `!Sync` donc cela n'arrivera pas.
        unsafe { *self.value.get() }
    }

    /// Met à jour la valeur contenue à l'aide d'une fonction et renvoie la nouvelle valeur.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Renvoie un pointeur brut vers les données sous-jacentes dans cette cellule.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Renvoie une référence mutable aux données sous-jacentes.
    ///
    /// Cet appel emprunte `Cell` mutuellement (au moment de la compilation), ce qui garantit que nous possédons la seule référence.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Renvoie un `&Cell<T>` à partir d'un `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // SÉCURITÉ: `&mut` garantit un accès unique.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Prend la valeur de la cellule, laissant `Default::default()` à sa place.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Renvoie un `&[Cell<T>]` à partir d'un `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // SÉCURITÉ: `Cell<T>` a la même disposition de mémoire que `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Un emplacement mémoire mutable avec des règles d'emprunt vérifiées dynamiquement
///
/// Voir le [module-level documentation](self) pour plus.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Une erreur renvoyée par [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Une erreur renvoyée par [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Les valeurs positives représentent le nombre de `Ref` actifs.Les valeurs négatives représentent le nombre de `RefMut` actifs.
// Plusieurs `RefMut`s ne peuvent être actifs à la fois que s'ils font référence à des composants distincts et non superposés d'un `RefCell` (par exemple, différentes plages d'une tranche).
//
// `Ref` et `RefMut` sont tous les deux de taille de deux mots, et il n'y aura donc probablement jamais assez de `Ref`s ou de`RefMut`s pour déborder de la moitié de la plage `usize`.
// Ainsi, un `BorrowFlag` ne débordera probablement jamais ni ne sous-débordera.
// Cependant, ce n'est pas une garantie, car un programme pathologique pourrait créer à plusieurs reprises, puis mem::forget `Ref`s ou`RefMut`s.
// Ainsi, tout le code doit vérifier explicitement les débordements et sous-débordements afin d'éviter l'insécurité, ou du moins se comporter correctement en cas de débordement ou de sous-dépassement (par exemple, voir BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Crée un nouveau `RefCell` contenant `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Consomme le `RefCell`, renvoyant la valeur encapsulée.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Puisque cette fonction prend `self` (le `RefCell`) par valeur, le compilateur vérifie statiquement qu'il n'est pas actuellement emprunté.
        //
        self.value.into_inner()
    }

    /// Remplace la valeur encapsulée par une nouvelle, en renvoyant l'ancienne valeur, sans désinitialiser l'une ou l'autre.
    ///
    ///
    /// Cette fonction correspond à [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics si la valeur est actuellement empruntée.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Remplace la valeur encapsulée par une nouvelle calculée à partir de `f`, renvoyant l'ancienne valeur, sans désinitialiser l'une ou l'autre.
    ///
    ///
    /// # Panics
    ///
    /// Panics si la valeur est actuellement empruntée.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Échange la valeur encapsulée de `self` avec la valeur encapsulée de `other`, sans déinitialiser l'une ou l'autre.
    ///
    ///
    /// Cette fonction correspond à [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics si la valeur de l'un ou l'autre `RefCell` est actuellement empruntée.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Emprunte immuablement la valeur encapsulée.
    ///
    /// L'emprunt dure jusqu'à ce que le `Ref` retourné quitte la portée.
    /// Plusieurs emprunts immuables peuvent être contractés en même temps.
    ///
    /// # Panics
    ///
    /// Panics si la valeur est actuellement empruntée mutuellement.
    /// Pour une variante sans panique, utilisez [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Un exemple de panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Emprunte immuablement la valeur encapsulée, renvoyant une erreur si la valeur est actuellement empruntée mutuellement.
    ///
    ///
    /// L'emprunt dure jusqu'à ce que le `Ref` retourné quitte la portée.
    /// Plusieurs emprunts immuables peuvent être contractés en même temps.
    ///
    /// C'est la variante sans panique du [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // SÉCURITÉ: `BorrowRef` garantit qu'il n'y a qu'un accès immuable
            // à la valeur tout emprunté.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Emprunte mutuellement la valeur encapsulée.
    ///
    /// L'emprunt dure jusqu'à ce que le `RefMut` retourné ou tous les `RefMut`s dérivés de celui-ci quittent la portée.
    ///
    /// La valeur ne peut pas être empruntée tant que cet emprunt est actif.
    ///
    /// # Panics
    ///
    /// Panics si la valeur est actuellement empruntée.
    /// Pour une variante sans panique, utilisez [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Un exemple de panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Emprunte mutuellement la valeur encapsulée, renvoyant une erreur si la valeur est actuellement empruntée.
    ///
    ///
    /// L'emprunt dure jusqu'à ce que le `RefMut` retourné ou tous les `RefMut`s dérivés de celui-ci quittent la portée.
    /// La valeur ne peut pas être empruntée tant que cet emprunt est actif.
    ///
    /// C'est la variante sans panique de [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // SÉCURITÉ: `BorrowRef` garantit un accès unique.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Renvoie un pointeur brut vers les données sous-jacentes dans cette cellule.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Renvoie une référence mutable aux données sous-jacentes.
    ///
    /// Cet appel emprunte `RefCell` mutuellement (au moment de la compilation) donc il n'y a pas besoin de vérifications dynamiques.
    ///
    /// Attention cependant: cette méthode s'attend à ce que `self` soit mutable, ce qui n'est généralement pas le cas lors de l'utilisation d'un `RefCell`.
    ///
    /// Jetez plutôt un œil à la méthode [`borrow_mut`] si `self` n'est pas modifiable.
    ///
    /// Sachez également que cette méthode est uniquement destinée à des circonstances spéciales et n'est généralement pas ce que vous souhaitez.
    /// En cas de doute, utilisez plutôt [`borrow_mut`].
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Annulez l'effet des protections qui fuient sur l'état d'emprunt du `RefCell`.
    ///
    /// Cet appel est similaire à [`get_mut`] mais plus spécialisé.
    /// Il emprunte `RefCell` mutuellement pour s'assurer qu'aucun emprunt n'existe, puis réinitialise l'état de suivi des emprunts partagés.
    /// Ceci est pertinent si certains emprunts `Ref` ou `RefMut` ont été divulgués.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Emprunte immuablement la valeur encapsulée, renvoyant une erreur si la valeur est actuellement empruntée mutuellement.
    ///
    /// # Safety
    ///
    /// Contrairement à `RefCell::borrow`, cette méthode n'est pas sûre car elle ne renvoie pas de `Ref`, laissant ainsi le drapeau d'emprunt intact.
    /// L'emprunt mutuel du `RefCell` alors que la référence renvoyée par cette méthode est active est un comportement indéfini.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // SÉCURITÉ: Nous vérifions que personne n'écrit activement maintenant, mais c'est
            // la responsabilité de l'appelant de s'assurer que personne n'écrit tant que la référence renvoyée n'est plus utilisée.
            // En outre, `self.value.get()` fait référence à la valeur détenue par `self` et est donc garanti valable pour la durée de vie de `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Prend la valeur encapsulée, laissant `Default::default()` à sa place.
    ///
    /// # Panics
    ///
    /// Panics si la valeur est actuellement empruntée.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics si la valeur est actuellement empruntée mutuellement.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Crée un `RefCell<T>`, avec la valeur `Default` pour T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics si la valeur de l'un ou l'autre `RefCell` est actuellement empruntée.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics si la valeur de l'un ou l'autre `RefCell` est actuellement empruntée.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics si la valeur de l'un ou l'autre `RefCell` est actuellement empruntée.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics si la valeur de l'un ou l'autre `RefCell` est actuellement empruntée.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics si la valeur de l'un ou l'autre `RefCell` est actuellement empruntée.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics si la valeur de l'un ou l'autre `RefCell` est actuellement empruntée.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics si la valeur de l'un ou l'autre `RefCell` est actuellement empruntée.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // L'emprunt incrémenté peut entraîner une valeur sans lecture (<=0) dans les cas suivants:
            // 1. C'était <0, c'est-à-dire qu'il y a des emprunts d'écriture, nous ne pouvons donc pas autoriser un emprunt en lecture en raison des règles d'alias de référence de Rust
            // 2.
            // C'était isize::MAX (le montant maximum d'emprunts de lecture) et il a débordé dans isize::MIN (le montant maximum d'emprunts d'écriture), nous ne pouvons donc pas autoriser un emprunt en lecture supplémentaire car isize ne peut pas représenter autant d'emprunts de lecture (cela ne peut se produire que si vous mem::forget plus qu'une petite quantité constante de `Ref`s, ce qui n'est pas une bonne pratique)
            //
            //
            //
            //
            None
        } else {
            // L'augmentation de l'emprunt peut entraîner une valeur de lecture (> 0) dans les cas suivants:
            // 1. C'était=0, c'est-à-dire qu'il n'a pas été emprunté, et nous prenons le premier emprunt en lecture
            // 2. C'était> 0 et <isize::MAX, c'est-à-dire
            // il y a eu des emprunts de lecture, et isize est suffisamment grand pour représenter un emprunt de lecture supplémentaire
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Puisque cette référence existe, nous savons que l'indicateur d'emprunt est un emprunt de lecture.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Empêchez le compteur d'emprunts de déborder dans un emprunt d'écriture.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Enveloppe une référence empruntée à une valeur dans une zone `RefCell`.
/// Un type de wrapper pour une valeur immuablement empruntée à un `RefCell<T>`.
///
/// Voir le [module-level documentation](self) pour plus.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Copie un `Ref`.
    ///
    /// Le `RefCell` est déjà immuablement emprunté, donc cela ne peut pas échouer.
    ///
    /// Il s'agit d'une fonction associée qui doit être utilisée comme `Ref::clone(...)`.
    /// Une implémentation ou une méthode `Clone` interférerait avec l'utilisation généralisée de `r.borrow().clone()` pour cloner le contenu d'un `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Crée un nouveau `Ref` pour un composant des données empruntées.
    ///
    /// Le `RefCell` est déjà immuablement emprunté, donc cela ne peut pas échouer.
    ///
    /// Il s'agit d'une fonction associée qui doit être utilisée comme `Ref::map(...)`.
    /// Une méthode interférerait avec les méthodes du même nom sur le contenu d'un `RefCell` utilisé via `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Crée un nouveau `Ref` pour un composant facultatif des données empruntées.
    /// La garde d'origine est renvoyée en tant que `Err(..)` si la fermeture renvoie `None`.
    ///
    /// Le `RefCell` est déjà immuablement emprunté, donc cela ne peut pas échouer.
    ///
    /// Il s'agit d'une fonction associée qui doit être utilisée comme `Ref::filter_map(...)`.
    /// Une méthode interférerait avec les méthodes du même nom sur le contenu d'un `RefCell` utilisé via `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Divise un `Ref` en plusieurs `Ref`s pour différents composants des données empruntées.
    ///
    /// Le `RefCell` est déjà immuablement emprunté, donc cela ne peut pas échouer.
    ///
    /// Il s'agit d'une fonction associée qui doit être utilisée comme `Ref::map_split(...)`.
    /// Une méthode interférerait avec les méthodes du même nom sur le contenu d'un `RefCell` utilisé via `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Convertit en référence aux données sous-jacentes.
    ///
    /// Le `RefCell` sous-jacent ne peut plus jamais être emprunté mutuellement et apparaîtra toujours déjà immuablement emprunté.
    ///
    /// Ce n'est pas une bonne idée de divulguer plus qu'un nombre constant de références.
    /// Le `RefCell` peut être à nouveau emprunté de manière immuable si seulement un plus petit nombre de fuites s'est produit au total.
    ///
    /// Il s'agit d'une fonction associée qui doit être utilisée comme `Ref::leak(...)`.
    /// Une méthode interférerait avec les méthodes du même nom sur le contenu d'un `RefCell` utilisé via `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // En oubliant cette référence, nous nous assurons que le compteur d'emprunt du RefCell ne peut pas revenir à INUTILISÉ pendant la durée de vie du `'b`.
        // La réinitialisation de l'état de suivi des références nécessiterait une référence unique à la RefCell empruntée.
        // Aucune autre référence modifiable ne peut être créée à partir de la cellule d'origine.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Crée un nouveau `RefMut` pour un composant des données empruntées, par exemple une variante d'énumération.
    ///
    /// Le `RefCell` est déjà emprunté mutuellement, donc cela ne peut pas échouer.
    ///
    /// Il s'agit d'une fonction associée qui doit être utilisée comme `RefMut::map(...)`.
    /// Une méthode interférerait avec les méthodes du même nom sur le contenu d'un `RefCell` utilisé via `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): réparer le chèque d'emprunt
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Crée un nouveau `RefMut` pour un composant facultatif des données empruntées.
    /// La garde d'origine est renvoyée en tant que `Err(..)` si la fermeture renvoie `None`.
    ///
    /// Le `RefCell` est déjà emprunté mutuellement, donc cela ne peut pas échouer.
    ///
    /// Il s'agit d'une fonction associée qui doit être utilisée comme `RefMut::filter_map(...)`.
    /// Une méthode interférerait avec les méthodes du même nom sur le contenu d'un `RefCell` utilisé via `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): réparer le chèque d'emprunt
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // SÉCURITÉ: la fonction conserve une référence exclusive pour la durée
        // de son appel via `orig`, et le pointeur n'est dé-référencé qu'à l'intérieur de l'appel de fonction, ne permettant jamais à la référence exclusive de s'échapper.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // SÉCURITÉ: comme ci-dessus.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Divise un `RefMut` en plusieurs `RefMut`s pour différents composants des données empruntées.
    ///
    /// Le `RefCell` sous-jacent restera emprunté mutuellement jusqu'à ce que les deux renvois `RefMut`s soient hors de portée.
    ///
    /// Le `RefCell` est déjà emprunté mutuellement, donc cela ne peut pas échouer.
    ///
    /// Il s'agit d'une fonction associée qui doit être utilisée comme `RefMut::map_split(...)`.
    /// Une méthode interférerait avec les méthodes du même nom sur le contenu d'un `RefCell` utilisé via `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Convertit en une référence mutable aux données sous-jacentes.
    ///
    /// Le `RefCell` sous-jacent ne peut pas être emprunté à nouveau et apparaîtra toujours déjà emprunté mutuellement, faisant de la référence renvoyée la seule à l'intérieur.
    ///
    ///
    /// Il s'agit d'une fonction associée qui doit être utilisée comme `RefMut::leak(...)`.
    /// Une méthode interférerait avec les méthodes du même nom sur le contenu d'un `RefCell` utilisé via `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // En oubliant ce BorrowRefMut, nous nous assurons que le compteur d'emprunt du RefCell ne peut pas revenir à INUTILISÉ pendant la durée de vie du `'b`.
        // La réinitialisation de l'état de suivi des références nécessiterait une référence unique à la RefCell empruntée.
        // Aucune autre référence ne peut être créée à partir de la cellule d'origine au cours de cette durée de vie, ce qui fait de l'emprunt actuel la seule référence pour la durée de vie restante.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Contrairement à BorrowRefMut::clone, new est appelé pour créer l'initiale
        // référence mutable, et il ne doit donc y avoir actuellement aucune référence existante.
        // Ainsi, alors que le clone incrémente le refcount mutable, ici nous n'autorisons explicitement que le passage de UNUSED à UNUSED, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Clone un `BorrowRefMut`.
    //
    // Ceci n'est valide que si chaque `BorrowRefMut` est utilisé pour suivre une référence mutable vers une plage distincte et non superposée de l'objet d'origine.
    //
    // Ce n'est pas dans un implément Clone, donc le code ne l'appelle pas implicitement.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Empêchez le compteur d'emprunt de déborder.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Un type de wrapper pour une valeur empruntée mutuellement à un `RefCell<T>`.
///
/// Voir le [module-level documentation](self) pour plus.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// La primitive de base pour la mutabilité intérieure dans Rust.
///
/// Si vous avez une référence `&T`, alors normalement dans Rust, le compilateur effectue des optimisations basées sur la connaissance que `&T` pointe vers des données immuables.La mutation de ces données, par exemple via un alias ou en transmutant un `&T` en un `&mut T`, est considérée comme un comportement indéfini.
/// `UnsafeCell<T>` exclut la garantie d'immuabilité pour `&T`: une référence partagée `&UnsafeCell<T>` peut pointer vers des données en cours de mutation.Cela s'appelle "interior mutability".
///
/// Tous les autres types qui autorisent la mutabilité interne, tels que `Cell<T>` et `RefCell<T>`, utilisent en interne `UnsafeCell` pour envelopper leurs données.
///
/// Notez que seule la garantie d'immuabilité pour les références partagées est affectée par `UnsafeCell`.La garantie d'unicité pour les références mutables n'est pas affectée.Il n'y a *aucun* moyen légal d'obtenir l'alias `&mut`, même pas avec `UnsafeCell<T>`.
///
/// L'API `UnsafeCell` elle-même est techniquement très simple: [`.get()`] vous donne un pointeur brut `*mut T` vers son contenu.C'est à _you_ en tant que concepteur d'abstraction d'utiliser correctement ce pointeur brut.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Les règles précises d'aliasing Rust sont quelque peu en évolution, mais les principaux points ne sont pas litigieux:
///
/// - Si vous créez une référence sécurisée avec `'a` à vie (une référence `&T` ou `&mut T`) accessible par code sécurisé (par exemple, parce que vous l'avez renvoyée), vous ne devez pas accéder aux données d'une manière qui contredit cette référence pour le reste. de `'a`.
/// Par exemple, cela signifie que si vous prenez le `*mut T` d'un `UnsafeCell<T>` et que vous le convertissez en `&T`, les données de `T` doivent rester immuables (modulo toutes les données `UnsafeCell` trouvées dans `T`, bien sûr) jusqu'à ce que la durée de vie de cette référence expire.
/// De même, si vous créez une référence `&mut T` qui est libérée en code sécurisé, vous ne devez pas accéder aux données dans le `UnsafeCell` jusqu'à ce que cette référence expire.
///
/// - À tout moment, vous devez éviter les courses de données.Si plusieurs threads ont accès au même `UnsafeCell`, alors toutes les écritures doivent avoir une relation appropriée avec tous les autres accès (ou utiliser atomics).
///
/// Pour faciliter la conception, les scénarios suivants sont explicitement déclarés légaux pour le code à un seul thread:
///
/// 1. Une référence `&T` peut être libérée en code sécurisé et là, elle peut coexister avec d'autres références `&T`, mais pas avec un `&mut T`
///
/// 2. Une référence `&mut T` peut être libérée vers un code de sécurité à condition qu'aucun autre `&mut T` ou `&T` ne coexiste avec elle.Un `&mut T` doit toujours être unique.
///
/// Notez que si la mutation du contenu d'un `&UnsafeCell<T>` (même si d'autres références `&UnsafeCell<T>` font référence à l'alias de la cellule) est ok (à condition que vous appliquiez les invariants ci-dessus d'une autre manière), il est toujours un comportement indéfini d'avoir plusieurs alias `&mut UnsafeCell<T>`.
/// Autrement dit, `UnsafeCell` est un wrapper conçu pour avoir une interaction spéciale avec _shared_ accesses (_i.e._, via une référence `&UnsafeCell<_>`);il n'y a aucune magie quand il s'agit de _exclusive_ accesses (_e.g._, via un `&mut UnsafeCell<_>`): ni la cellule ni la valeur encapsulée ne peuvent être aliasées pendant la durée de cet emprunt `&mut`.
///
/// Ceci est présenté par l'accesseur [`.get_mut()`], qui est un _safe_ getter qui donne un `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Voici un exemple montrant comment muter de manière sonore le contenu d'un `UnsafeCell<_>` malgré plusieurs références aliasant la cellule:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Obtenez des références multiples/simultanées/partagées au même `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // SÉCURITÉ: dans cette portée, il n'y a pas d'autres références au contenu de `x`,
///     // le nôtre est donc effectivement unique.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- emprunter-+
///     *p1_exclusive += 27; // |
/// } // <---------- ne peut pas aller au-delà de ce point -------------------+
///
/// unsafe {
///     // SÉCURITÉ: dans ce cadre, personne ne s'attend à avoir un accès exclusif au contenu de `x`,
///     // afin que nous puissions avoir plusieurs accès partagés simultanément.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// L'exemple suivant montre que l'accès exclusif à un `UnsafeCell<T>` implique un accès exclusif à son `T`:
///
/// ```rust
/// #![forbid(unsafe_code)] // avec des accès exclusifs,
///                         // `UnsafeCell` est un wrapper transparent sans opération, donc pas besoin de `unsafe` ici.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Obtenez une référence unique à `x` vérifiée lors de la compilation.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Avec une référence exclusive, nous pouvons muter le contenu gratuitement.
/// *p_unique.get_mut() = 0;
/// // Ou équivalent:
/// x = UnsafeCell::new(0);
///
/// // Lorsque nous possédons la valeur, nous pouvons extraire le contenu gratuitement.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Construit une nouvelle instance de `UnsafeCell` qui encapsulera la valeur spécifiée.
    ///
    ///
    /// Tous les accès à la valeur interne via des méthodes sont `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Décompresse la valeur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Obtient un pointeur mutable vers la valeur encapsulée.
    ///
    /// Cela peut être converti en un pointeur de n'importe quel type.
    /// Assurez-vous que l'accès est unique (aucune référence active, mutable ou non) lors de la conversion vers `&mut T`, et assurez-vous qu'il n'y a pas de mutations ou d'alias mutables lors de la conversion vers `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Nous pouvons simplement convertir le pointeur de `UnsafeCell<T>` en `T` à cause de #[repr(transparent)].
        // Cela exploite le statut spécial de libstd, il n'y a aucune garantie pour le code utilisateur que cela fonctionnera dans les versions future du compilateur!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Renvoie une référence mutable aux données sous-jacentes.
    ///
    /// Cet appel emprunte mutuellement le `UnsafeCell` (au moment de la compilation), ce qui garantit que nous possédons la seule référence.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Obtient un pointeur mutable vers la valeur encapsulée.
    /// La différence avec [`get`] est que cette fonction accepte un pointeur brut, ce qui est utile pour éviter la création de références temporaires.
    ///
    /// Le résultat peut être converti en un pointeur de n'importe quel type.
    /// Assurez-vous que l'accès est unique (aucune référence active, mutable ou non) lors de la conversion vers `&mut T`, et assurez-vous qu'il n'y a pas de mutations ou d'alias mutables lors de la conversion vers `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// L'initialisation progressive d'un `UnsafeCell` nécessite `raw_get`, car l'appel de `get` nécessiterait la création d'une référence à des données non initialisées:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Nous pouvons simplement convertir le pointeur de `UnsafeCell<T>` en `T` à cause de #[repr(transparent)].
        // Cela exploite le statut spécial de libstd, il n'y a aucune garantie pour le code utilisateur que cela fonctionnera dans les versions future du compilateur!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Crée un `UnsafeCell`, avec la valeur `Default` pour T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}