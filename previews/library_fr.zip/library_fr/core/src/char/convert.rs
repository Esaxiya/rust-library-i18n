//! Conversions de caractères.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Convertit un `u32` en `char`.
///
/// Notez que tous les [`char`] sont des [`u32`] valides et peuvent être convertis en un seul avec
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Cependant, l'inverse n'est pas vrai: tous les [`u32`] s valides ne sont pas des [`char`] s valides.
/// `from_u32()` renverra `None` si l'entrée n'est pas une valeur valide pour un [`char`].
///
/// Pour une version non sécurisée de cette fonction qui ignore ces vérifications, consultez [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Utilisation de base:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Renvoi de `None` lorsque l'entrée n'est pas un [`char`] valide:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Convertit un `u32` en `char`, en ignorant la validité.
///
/// Notez que tous les [`char`] sont des [`u32`] valides et peuvent être convertis en un seul avec
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Cependant, l'inverse n'est pas vrai: tous les [`u32`] s valides ne sont pas des [`char`] s valides.
/// `from_u32_unchecked()` ignorera cela, et transtypera aveuglément en [`char`], en créant éventuellement un non valide.
///
///
/// # Safety
///
/// Cette fonction n'est pas sûre, car elle peut créer des valeurs `char` non valides.
///
/// Pour une version sûre de cette fonction, voir la fonction [`from_u32`].
///
/// # Examples
///
/// Utilisation de base:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // SÉCURITÉ: l'appelant doit garantir que `i` est une valeur de caractère valide.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Convertit un [`char`] en [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Convertit un [`char`] en [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Le caractère est transtypé à la valeur du point de code, puis étendu à zéro en 64 bits.
        // Voir [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Convertit un [`char`] en [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Le caractère est transtypé à la valeur du point de code, puis étendu à zéro à 128 bits.
        // Voir [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Mappe un octet de 0x00 ..=0xFF à un `char` dont le point de code a la même valeur, en U + 0000 ..=U + 00FF.
///
/// Unicode est conçu de telle sorte que cela décode efficacement les octets avec le codage de caractères que l'IANA appelle ISO-8859-1.
/// Cet encodage est compatible avec ASCII.
///
/// Notez que c'est différent de ISO/IEC 8859-1 aka
/// ISO 8859-1 (avec un trait d'union en moins), ce qui laisse des "blanks", des valeurs d'octets qui ne sont affectées à aucun caractère.
/// ISO-8859-1 (celui de l'IANA) les attribue aux codes de contrôle C0 et C1.
///
/// Notez que c'est *aussi* différent de Windows-1252 aka
/// la page de codes 1252, qui est un sur-ensemble ISO/IEC 8859-1 qui attribue des blancs (pas tous!) à la ponctuation et à divers caractères latins.
///
/// Pour compliquer davantage les choses, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` et `windows-1252` sont tous des alias pour un sur-ensemble de Windows-1252 qui remplit les espaces restants avec les codes de contrôle C0 et C1 correspondants.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Convertit un [`u8`] en [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Une erreur qui peut être renvoyée lors de l'analyse d'un caractère.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // SÉCURITÉ: vérifié qu'il s'agit d'une valeur unicode légale
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Le type d'erreur renvoyé lorsqu'une conversion de u32 en char échoue.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Convertit un chiffre de la base donnée en `char`.
///
/// Un 'radix' est parfois également appelé 'base'.
/// Une base de deux indique un nombre binaire, une base de dix, décimal, et une base de seize, hexadécimal, pour donner des valeurs communes.
///
/// Les radices arbitraires sont prises en charge.
///
/// `from_digit()` renverra `None` si l'entrée n'est pas un chiffre dans la base donnée.
///
/// # Panics
///
/// Panics si une base supérieure à 36 est donnée.
///
/// # Examples
///
/// Utilisation de base:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // La décimale 11 est un seul chiffre en base 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Renvoi de `None` lorsque l'entrée n'est pas un chiffre:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Passer une grande base, provoquant un panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}