//! char impl {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Le point de code valide le plus élevé qu'un `char` peut avoir.
    ///
    /// Un `char` est un [Unicode Scalar Value], ce qui signifie qu'il s'agit d'un [Code Point], mais seulement ceux dans une certaine plage.
    /// `MAX` est le point de code valide le plus élevé qui est un [Unicode Scalar Value] valide.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () est utilisé en Unicode pour représenter une erreur de décodage.
    ///
    /// Cela peut se produire, par exemple, lors de l'attribution d'octets UTF-8 mal formés à [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Version de [Unicode](http://www.unicode.org/) sur laquelle sont basées les parties Unicode des méthodes `char` et `str`.
    ///
    /// De nouvelles versions d'Unicode sont publiées régulièrement et par la suite toutes les méthodes de la bibliothèque standard dépendant d'Unicode sont mises à jour.
    /// Par conséquent, le comportement de certaines méthodes `char` et `str` et la valeur de cette constante évoluent dans le temps.
    /// Ceci n'est *pas* considéré comme un changement radical.
    ///
    /// Le schéma de numérotation des versions est expliqué dans [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Crée un itérateur sur les points de code codés UTF-16 dans `iter`, renvoyant des substituts non appariés en tant que «Err».
    ///
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Un décodeur avec perte peut être obtenu en remplaçant les résultats `Err` par le caractère de remplacement:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Convertit un `u32` en `char`.
    ///
    /// Notez que tous les `char`s sont des [`u32`] s valides et peuvent être convertis en un seul avec
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Cependant, l'inverse n'est pas vrai: tous les [`u32`] valides ne sont pas des`char`s valides.
    /// `from_u32()` renverra `None` si l'entrée n'est pas une valeur valide pour un `char`.
    ///
    /// Pour une version non sécurisée de cette fonction qui ignore ces vérifications, consultez [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Renvoi de `None` lorsque l'entrée n'est pas un `char` valide:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Convertit un `u32` en `char`, en ignorant la validité.
    ///
    /// Notez que tous les `char`s sont des [`u32`] s valides et peuvent être convertis en un seul avec
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Cependant, l'inverse n'est pas vrai: tous les [`u32`] valides ne sont pas des`char`s valides.
    /// `from_u32_unchecked()` ignorera cela, et transtypera aveuglément en `char`, en créant éventuellement un non valide.
    ///
    ///
    /// # Safety
    ///
    /// Cette fonction n'est pas sûre, car elle peut créer des valeurs `char` non valides.
    ///
    /// Pour une version sûre de cette fonction, voir la fonction [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // SÉCURITÉ: le contrat de sécurité doit être respecté par l'appelant.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Convertit un chiffre de la base donnée en `char`.
    ///
    /// Un 'radix' est parfois également appelé 'base'.
    /// Une base de deux indique un nombre binaire, une base de dix, décimal, et une base de seize, hexadécimal, pour donner des valeurs communes.
    ///
    /// Les radices arbitraires sont prises en charge.
    ///
    /// `from_digit()` renverra `None` si l'entrée n'est pas un chiffre dans la base donnée.
    ///
    /// # Panics
    ///
    /// Panics si une base supérieure à 36 est donnée.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // La décimale 11 est un seul chiffre en base 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Renvoi de `None` lorsque l'entrée n'est pas un chiffre:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Passer une grande base, provoquant un panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Vérifie si un `char` est un chiffre dans la base donnée.
    ///
    /// Un 'radix' est parfois également appelé 'base'.
    /// Une base de deux indique un nombre binaire, une base de dix, décimal, et une base de seize, hexadécimal, pour donner des valeurs communes.
    ///
    /// Les radices arbitraires sont prises en charge.
    ///
    /// Par rapport à [`is_numeric()`], cette fonction ne reconnaît que les caractères `0-9`, `a-z` et `A-Z`.
    ///
    /// 'Digit' est défini comme étant uniquement les caractères suivants:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Pour une compréhension plus complète de 'digit', voir [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics si une base supérieure à 36 est donnée.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Passer une grande base, provoquant un panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Convertit un `char` en chiffre dans la base donnée.
    ///
    /// Un 'radix' est parfois également appelé 'base'.
    /// Une base de deux indique un nombre binaire, une base de dix, décimal, et une base de seize, hexadécimal, pour donner des valeurs communes.
    ///
    /// Les radices arbitraires sont prises en charge.
    ///
    /// 'Digit' est défini comme étant uniquement les caractères suivants:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Renvoie `None` si `char` ne fait pas référence à un chiffre de la base donnée.
    ///
    /// # Panics
    ///
    /// Panics si une base supérieure à 36 est donnée.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Passer un non-chiffre entraîne un échec:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Passer une grande base, provoquant un panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // le code est divisé ici pour améliorer la vitesse d'exécution pour les cas où le `radix` est constant et 10 ou plus petit
        //
        let val = if likely(radix <= 10) {
            // Si ce n'est pas un chiffre, un nombre supérieur à la base sera créé.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Renvoie un itérateur qui produit l'échappement Unicode hexadécimal d'un caractère sous la forme de «char».
    ///
    /// Cela échappera les caractères avec la syntaxe Rust de la forme `\u{NNNNNN}` où `NNNNNN` est une représentation hexadécimale.
    ///
    ///
    /// # Examples
    ///
    /// En tant qu'itérateur:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilisation directe de `println!`:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Les deux sont équivalents à:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// En utilisant `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // or-ing 1 garantit que pour c==0, le code calcule qu'un chiffre doit être imprimé et (qui est le même) évite le sous-débordement (31, 32)
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // l'indice du chiffre hexadécimal le plus significatif
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Une version étendue de `escape_debug` qui permet éventuellement d'échapper aux points de code Extended Grapheme.
    /// Cela nous permet de mieux formater les caractères tels que les marques sans espacement lorsqu'ils sont au début d'une chaîne.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Renvoie un itérateur qui produit le code d'échappement littéral d'un caractère sous la forme de «char».
    ///
    /// Cela échappera aux caractères similaires aux implémentations `Debug` de `str` ou `char`.
    ///
    ///
    /// # Examples
    ///
    /// En tant qu'itérateur:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilisation directe de `println!`:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Les deux sont équivalents à:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// En utilisant `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Renvoie un itérateur qui produit le code d'échappement littéral d'un caractère sous la forme de «char».
    ///
    /// La valeur par défaut est choisie avec un biais vers la production de littéraux légaux dans une variété de langages, y compris C++ 11 et les langages de la famille C similaires.
    /// Les règles exactes sont:
    ///
    /// * Tab est échappé en tant que `\t`.
    /// * Le retour chariot est échappé sous la forme `\r`.
    /// * Le saut de ligne est échappé en tant que `\n`.
    /// * Le guillemet simple est échappé sous la forme `\'`.
    /// * Les guillemets doubles sont échappés sous la forme `\"`.
    /// * La barre oblique inverse est échappée sous la forme `\\`.
    /// * Tout caractère de la plage 'ASCII imprimable' `0x20` .. `0x7e` inclus n'est pas échappé.
    /// * Tous les autres caractères reçoivent des échappements Unicode hexadécimaux;voir [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// En tant qu'itérateur:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilisation directe de `println!`:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Les deux sont équivalents à:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// En utilisant `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Renvoie le nombre d'octets dont ce `char` aurait besoin s'il était encodé en UTF-8.
    ///
    /// Ce nombre d'octets est toujours compris entre 1 et 4 inclus.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Le type `&str` garantit que son contenu est UTF-8, et nous pouvons donc comparer la longueur que cela prendrait si chaque point de code était représenté comme un `char` par rapport au `&str` lui-même:
    ///
    ///
    /// ```
    /// // comme caractères
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // les deux peuvent être représentés par trois octets
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // comme un &str, ces deux sont encodés en UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // nous pouvons voir qu'ils prennent six octets au total ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... tout comme le &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Renvoie le nombre d'unités de code 16 bits dont ce `char` aurait besoin s'il était encodé en UTF-16.
    ///
    ///
    /// Consultez la documentation de [`len_utf8()`] pour plus d'explications sur ce concept.
    /// Cette fonction est un miroir, mais pour UTF-16 au lieu de UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Encode ce caractère comme UTF-8 dans le tampon d'octets fourni, puis retourne la sous-tranche du tampon qui contient le caractère codé.
    ///
    ///
    /// # Panics
    ///
    /// Panics si le tampon n'est pas assez grand.
    /// Un tampon de longueur quatre est suffisamment grand pour encoder n'importe quel `char`.
    ///
    /// # Examples
    ///
    /// Dans ces deux exemples, 'ß' prend deux octets à encoder.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Un tampon trop petit:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // SÉCURITÉ: `char` n'est pas un substitut, c'est donc UTF-8 valide.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Encode ce caractère comme UTF-16 dans le tampon `u16` fourni, puis renvoie la sous-tranche du tampon qui contient le caractère codé.
    ///
    ///
    /// # Panics
    ///
    /// Panics si le tampon n'est pas assez grand.
    /// Un tampon de longueur 2 est suffisamment grand pour encoder n'importe quel `char`.
    ///
    /// # Examples
    ///
    /// Dans ces deux exemples, '𝕊' prend deux «u16» pour encoder.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Un tampon trop petit:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Renvoie `true` si ce `char` a la propriété `Alphabetic`.
    ///
    /// `Alphabetic` est décrit dans le chapitre 4 (Propriétés des caractères) du [Unicode Standard] et spécifié dans le [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // l'amour est beaucoup de choses, mais ce n'est pas alphabétique
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Renvoie `true` si ce `char` a la propriété `Lowercase`.
    ///
    /// `Lowercase` est décrit dans le chapitre 4 (Propriétés des caractères) du [Unicode Standard] et spécifié dans le [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Les différents scripts chinois et ponctuation n'ont pas de casse, et donc:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Renvoie `true` si ce `char` a la propriété `Uppercase`.
    ///
    /// `Uppercase` est décrit dans le chapitre 4 (Propriétés des caractères) du [Unicode Standard] et spécifié dans le [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Les différents scripts chinois et ponctuation n'ont pas de casse, et donc:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Renvoie `true` si ce `char` a la propriété `White_Space`.
    ///
    /// `White_Space` est spécifié dans le [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // un espace insécable
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Renvoie `true` si ce `char` satisfait soit [`is_alphabetic()`] soit [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Renvoie `true` si ce `char` a la catégorie générale pour les codes de contrôle.
    ///
    /// Les codes de contrôle (points de code de la catégorie générale `Cc`) sont décrits dans le chapitre 4 (Propriétés des caractères) du [Unicode Standard] et spécifiés dans le [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// // U + 009C, TERMINATEUR STRING
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Renvoie `true` si ce `char` a la propriété `Grapheme_Extend`.
    ///
    /// `Grapheme_Extend` est décrit dans [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] et spécifié dans [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Renvoie `true` si ce `char` a l'une des catégories générales pour les nombres.
    ///
    /// Les catégories générales pour les nombres (`Nd` pour les chiffres décimaux, `Nl` pour les caractères numériques de type lettre et `No` pour les autres caractères numériques) sont spécifiées dans le [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Renvoie un itérateur qui donne le mappage minuscule de ce `char` comme un ou plusieurs
    /// `char`s.
    ///
    /// Si ce `char` n'a pas de mappage en minuscules, l'itérateur produit le même `char`.
    ///
    /// Si ce `char` a un mappage un à un en minuscules donné par le [Unicode Character Database][ucd] [`UnicodeData.txt`], l'itérateur donne ce `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Si ce `char` nécessite des considérations spéciales (par exemple plusieurs `char`s), l'itérateur donne le ou les`char`s donnés par [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Cette opération effectue un mappage inconditionnel sans adaptation.Autrement dit, la conversion est indépendante du contexte et de la langue.
    ///
    /// Dans le [Unicode Standard], le chapitre 4 (Propriétés des caractères) traite du mappage de cas en général et le chapitre 3 (Conformance) traite de l'algorithme par défaut pour la conversion de cas.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// En tant qu'itérateur:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilisation directe de `println!`:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Les deux sont équivalents à:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// En utilisant `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Parfois, le résultat est plus d'un caractère:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Les caractères qui n'ont pas à la fois de majuscules et de minuscules se convertissent en eux-mêmes.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Renvoie un itérateur qui donne le mappage en majuscules de ce `char` comme un ou plusieurs
    /// `char`s.
    ///
    /// Si ce `char` n'a pas de mappage en majuscules, l'itérateur produit le même `char`.
    ///
    /// Si ce `char` a un mappage un à un majuscule donné par le [Unicode Character Database][ucd] [`UnicodeData.txt`], l'itérateur donne ce `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Si ce `char` nécessite des considérations spéciales (par exemple plusieurs `char`s), l'itérateur donne le ou les`char`s donnés par [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Cette opération effectue un mappage inconditionnel sans adaptation.Autrement dit, la conversion est indépendante du contexte et de la langue.
    ///
    /// Dans le [Unicode Standard], le chapitre 4 (Propriétés des caractères) traite du mappage de cas en général et le chapitre 3 (Conformance) traite de l'algorithme par défaut pour la conversion de cas.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// En tant qu'itérateur:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilisation directe de `println!`:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Les deux sont équivalents à:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// En utilisant `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Parfois, le résultat est plus d'un caractère:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Les caractères qui n'ont pas à la fois de majuscules et de minuscules se convertissent en eux-mêmes.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Remarque sur les paramètres régionaux
    ///
    /// En turc, l'équivalent de 'i' en latin a cinq formes au lieu de deux:
    ///
    /// * 'Dotless': I/ı, parfois écrit ï
    /// * 'Dotted': İ/i
    ///
    /// Notez que le 'i' en pointillé minuscule est le même que le latin.Par conséquent:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// La valeur de `upper_i` dépend ici de la langue du texte: si nous sommes dans `en-US`, ce devrait être `"I"`, mais si nous sommes dans `tr_TR`, ce devrait être `"İ"`.
    /// `to_uppercase()` n'en tient pas compte, et donc:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// tient dans toutes les langues.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Vérifie si la valeur est comprise dans la plage ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Effectue une copie de la valeur dans son équivalent en majuscules ASCII.
    ///
    /// Les lettres ASCII 'a' à 'z' sont mappées entre 'A' et 'Z', mais les lettres non ASCII restent inchangées.
    ///
    /// Pour mettre en majuscule la valeur sur place, utilisez [`make_ascii_uppercase()`].
    ///
    /// Pour mettre en majuscules des caractères ASCII en plus des caractères non ASCII, utilisez [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Fait une copie de la valeur dans son équivalent en minuscules ASCII.
    ///
    /// Les lettres ASCII 'A' à 'Z' sont mappées entre 'a' et 'z', mais les lettres non ASCII restent inchangées.
    ///
    /// Pour mettre en minuscule la valeur sur place, utilisez [`make_ascii_lowercase()`].
    ///
    /// Pour mettre en minuscules des caractères ASCII en plus des caractères non ASCII, utilisez [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Vérifie que deux valeurs correspondent à une correspondance ASCII insensible à la casse.
    ///
    /// Équivalent à `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Convertit ce type en son équivalent ASCII majuscules sur place.
    ///
    /// Les lettres ASCII 'a' à 'z' sont mappées entre 'A' et 'Z', mais les lettres non ASCII restent inchangées.
    ///
    /// Pour renvoyer une nouvelle valeur en majuscules sans modifier la valeur existante, utilisez [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Convertit ce type en son équivalent en minuscules ASCII sur place.
    ///
    /// Les lettres ASCII 'A' à 'Z' sont mappées entre 'a' et 'z', mais les lettres non ASCII restent inchangées.
    ///
    /// Pour renvoyer une nouvelle valeur en minuscules sans modifier la valeur existante, utilisez [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Vérifie si la valeur est un caractère alphabétique ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', ou
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Vérifie si la valeur est un caractère ASCII majuscule:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Vérifie si la valeur est un caractère ASCII minuscule:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Vérifie si la valeur est un caractère alphanumérique ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', ou
    /// - U + 0061 'a' ..=U + 007A 'z', ou
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Vérifie si la valeur est un chiffre décimal ASCII:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Vérifie si la valeur est un chiffre hexadécimal ASCII:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', ou
    /// - U + 0041 'A' ..=U + 0046 'F', ou
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Vérifie si la valeur est un caractère de ponctuation ASCII:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, ou
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, ou
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, ou
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Vérifie si la valeur est un caractère graphique ASCII:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Vérifie si la valeur est un caractère d'espacement ASCII:
    /// U + 0020 ESPACE, U + 0009 HORIZONTAL TAB, U + 000A LINE FEED, U + 000C FORM FEED ou U + 000D CARRIAGE RETURN.
    ///
    /// Rust utilise le [definition of ASCII whitespace][infra-aw] de WhatWG Infra Standard.Il existe plusieurs autres définitions largement utilisées.
    /// Par exemple, [the POSIX locale][pct] inclut U + 000B VERTICAL TAB ainsi que tous les caractères ci-dessus, mais-à partir de la même spécification-[la règle par défaut pour "field splitting" dans Bourne shell][bfs] considère *uniquement* ESPACE, HORIZONTAL TAB et LINE FEED en tant qu'espace blanc.
    ///
    ///
    /// Si vous écrivez un programme qui traitera un format de fichier existant, vérifiez quelle est la définition d'espaces blancs de ce format avant d'utiliser cette fonction.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Vérifie si la valeur est un caractère de contrôle ASCII:
    /// U + 0000 NUL ..=U + 001F SÉPARATEUR D'UNITÉ, ou U + 007F SUPPRIMER.
    /// Notez que la plupart des caractères d'espacement ASCII sont des caractères de contrôle, mais que SPACE ne l'est pas.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Encode une valeur u32 brute en tant que UTF-8 dans le tampon d'octets fourni, puis renvoie la sous-tranche du tampon qui contient le caractère codé.
///
///
/// Contrairement à `char::encode_utf8`, cette méthode gère également les points de code dans la plage de substitution.
/// (La création d'un `char` dans la plage de substitution est UB.) Le résultat est [generalized UTF-8] valide mais pas UTF-8 valide.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics si le tampon n'est pas assez grand.
/// Un tampon de longueur quatre est suffisamment grand pour encoder n'importe quel `char`.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Encode une valeur u32 brute en tant que UTF-16 dans le tampon `u16` fourni, puis renvoie la sous-tranche du tampon qui contient le caractère codé.
///
///
/// Contrairement à `char::encode_utf16`, cette méthode gère également les points de code dans la plage de substitution.
/// (La création d'un `char` dans la plage de substitution est UB.)
///
/// # Panics
///
/// Panics si le tampon n'est pas assez grand.
/// Un tampon de longueur 2 est suffisamment grand pour encoder n'importe quel `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // SÉCURITÉ: chaque bras vérifie s'il y a suffisamment de bits pour écrire
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // Le BMP échoue
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Les avions supplémentaires se transforment en substituts.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}