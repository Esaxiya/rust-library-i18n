//! Le libcore prelude
//!
//! Ce module est destiné aux utilisateurs de libcore qui ne sont pas non plus liés à libstd.
//! Ce module est importé par défaut lorsque `#![no_std]` est utilisé de la même manière que le prelude de la bibliothèque standard.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// La version 2015 du noyau prelude.
///
/// Voir le [module-level documentation](self) pour plus.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// La version 2018 du noyau prelude.
///
/// Voir le [module-level documentation](self) pour plus.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// La version 2021 du noyau prelude.
///
/// Voir le [module-level documentation](self) pour plus.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Ajoutez plus de choses.
}