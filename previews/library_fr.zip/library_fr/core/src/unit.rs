use crate::iter::FromIterator;

/// Réduit tous les éléments d'unité d'un itérateur en un seul.
///
/// Ceci est plus utile lorsqu'il est combiné avec des abstractions de plus haut niveau, comme la collecte vers un `Result<(), E>` où vous ne vous souciez que des erreurs:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}