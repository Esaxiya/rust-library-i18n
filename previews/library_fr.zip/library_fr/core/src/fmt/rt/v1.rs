//! Il s'agit d'un module interne utilisé par ifmt!Durée.Ces structures sont émises vers des tableaux statiques pour précompiler les chaînes de format à l'avance.
//!
//! Ces définitions sont similaires à leurs équivalents `ct`, mais diffèrent en ce qu'elles peuvent être allouées de manière statique et sont légèrement optimisées pour l'exécution
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Alignements possibles qui peuvent être demandés dans le cadre d'une directive de mise en forme.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Indication que le contenu doit être aligné à gauche.
    Left,
    /// Indication que le contenu doit être aligné à droite.
    Right,
    /// Indication que le contenu doit être aligné au centre.
    Center,
    /// Aucun alignement n'a été demandé.
    Unknown,
}

/// Utilisé par les spécificateurs [width](https://doc.rust-lang.org/std/fmt/#width) et [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// Spécifié avec un nombre littéral, stocke la valeur
    Is(usize),
    /// Spécifié à l'aide des syntaxes `$` et `*`, stocke l'index dans `args`
    Param(usize),
    /// Non précisé
    Implied,
}