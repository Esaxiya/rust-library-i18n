use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Un wrapper autour d'un `*mut T` brut non nul qui indique que le possesseur de ce wrapper possède le référent.
/// Utile pour créer des abstractions telles que `Box<T>`, `Vec<T>`, `String` et `HashMap<K, V>`.
///
/// Contrairement à `*mut T`, `Unique<T>` se comporte "as if" c'était une instance de `T`.
/// Il implémente `Send`/`Sync` si `T` est `Send`/`Sync`.
/// Cela implique également le type d'aliasing fort garantit qu'une instance de `T` peut s'attendre:
/// le référent du pointeur ne doit pas être modifié sans un chemin unique vers son propre Unique.
///
/// Si vous ne savez pas s'il est correct d'utiliser `Unique` pour vos besoins, envisagez d'utiliser `NonNull`, qui a une sémantique plus faible.
///
///
/// Contrairement à `*mut T`, le pointeur doit toujours être non nul, même si le pointeur n'est jamais déréférencé.
/// C'est pour que les énumérations puissent utiliser cette valeur interdite comme discriminant-`Option<Unique<T>>` a la même taille que `Unique<T>`.
/// Cependant, le pointeur peut toujours pendre s'il n'est pas déréférencé.
///
/// Contrairement à `*mut T`, `Unique<T>` est covariant sur `T`.
/// Cela devrait toujours être correct pour tout type qui respecte les exigences d'alias d'Unique.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: ce marqueur n'a aucune conséquence sur la variance, mais est nécessaire
    // pour que dropck comprenne que nous possédons logiquement un `T`.
    //
    // Pour plus de détails, consultez:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` les pointeurs sont `Send` si `T` est `Send` car les données auxquelles ils font référence ne sont pas crénelées.
/// Notez que cet invariant d'alias n'est pas appliqué par le système de types;l'abstraction utilisant le `Unique` doit l'appliquer.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` les pointeurs sont `Sync` si `T` est `Sync` car les données auxquelles ils font référence ne sont pas crénelées.
/// Notez que cet invariant d'alias n'est pas appliqué par le système de types;l'abstraction utilisant le `Unique` doit l'appliquer.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Crée un nouveau `Unique` suspendu, mais bien aligné.
    ///
    /// Ceci est utile pour initialiser les types qui sont alloués paresseusement, comme le fait `Vec::new`.
    ///
    /// Notez que la valeur du pointeur peut potentiellement représenter un pointeur valide vers un `T`, ce qui signifie qu'il ne doit pas être utilisé comme valeur sentinelle "not yet initialized".
    /// Les types qui allouent paresseusement doivent suivre l'initialisation par d'autres moyens.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // SÉCURITÉ: mem::align_of() renvoie un pointeur valide non nul.le
        // les conditions pour appeler new_unchecked() sont donc respectées.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Crée un nouveau `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` doit être non nul.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SÉCURITÉ: l'appelant doit garantir que `ptr` est non nul.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Crée un nouveau `Unique` si `ptr` est non nul.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SÉCURITÉ: le pointeur a déjà été vérifié et n'est pas nul.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Acquiert le pointeur `*mut` sous-jacent.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Déréférence le contenu.
    ///
    /// La durée de vie qui en résulte est liée à soi-même donc cela se comporte "as if", c'était en fait une instance de T qui est empruntée.
    /// Si une durée de vie (unbound) plus longue est nécessaire, utilisez `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SÉCURITÉ: l'appelant doit garantir que `self` répond à toutes les
        // exigences pour une référence.
        unsafe { &*self.as_ptr() }
    }

    /// Déréférence mutuellement le contenu.
    ///
    /// La durée de vie qui en résulte est liée à soi-même donc cela se comporte "as if", c'était en fait une instance de T qui est empruntée.
    /// Si une durée de vie (unbound) plus longue est nécessaire, utilisez `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SÉCURITÉ: l'appelant doit garantir que `self` répond à toutes les
        // exigences pour une référence mutable.
        unsafe { &mut *self.as_ptr() }
    }

    /// Convertit en un pointeur d'un autre type.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // SÉCURITÉ: Unique::new_unchecked() crée un nouvel unique et des besoins
        // le pointeur donné ne doit pas être nul.
        // Puisque nous passons self en tant que pointeur, il ne peut pas être nul.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SÉCURITÉ: une référence mutable ne peut pas être nulle
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}