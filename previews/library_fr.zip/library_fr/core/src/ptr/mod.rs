//! Gérez manuellement la mémoire via des pointeurs bruts.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! De nombreuses fonctions de ce module prennent des pointeurs bruts comme arguments et les lisent ou y écrivent.Pour que cela soit sûr, ces pointeurs doivent être *valides*.
//! La validité d'un pointeur dépend de l'opération pour laquelle il est utilisé (lecture ou écriture) et de l'étendue de la mémoire à laquelle on accède (c'est-à-dire combien d'octets représentent read/written).
//! La plupart des fonctions utilisent `*mut T` et `* const T` pour accéder à une seule valeur, auquel cas la documentation omet la taille et suppose implicitement qu'il s'agit d'octets `size_of::<T>()`.
//!
//! Les règles précises de validité ne sont pas encore déterminées.Les garanties fournies à ce stade sont très minimes:
//!
//! * Un pointeur [null] n'est *jamais* valide, même pas pour les accès de [size zero][zst].
//! * Pour qu'un pointeur soit valide, il est nécessaire, mais pas toujours suffisant, que le pointeur soit *déréférençable*: la plage mémoire de la taille donnée commençant au pointeur doit toutes être dans les limites d'un seul objet alloué.
//!
//! Notez que dans Rust, chaque variable (stack-allocated) est considérée comme un objet alloué distinct.
//! * Même pour les opérations de [size zero][zst], le pointeur ne doit pas pointer vers la mémoire désallouée, c'est-à-dire que la désallocation rend les pointeurs invalides même pour les opérations de taille nulle.
//! Cependant, la conversion de tout entier non nul *littéral* en un pointeur est valide pour les accès de taille nulle, même si de la mémoire existe à cette adresse et est désallouée.
//! Cela correspond à l'écriture de votre propre allocateur: allouer des objets de taille nulle n'est pas très difficile.
//! La méthode canonique pour obtenir un pointeur valide pour les accès de taille nulle est [`NonNull::dangling`].
//! * Tous les accès effectués par les fonctions de ce module sont *non atomiques* au sens de [atomic operations] utilisé pour synchroniser entre les threads.
//! Cela signifie que le comportement n'est pas défini d'effectuer deux accès simultanés au même emplacement à partir de différents threads à moins que les deux n'accèdent uniquement en lecture à partir de la mémoire.
//! Notez que cela inclut explicitement [`read_volatile`] et [`write_volatile`]: les accès volatiles ne peuvent pas être utilisés pour la synchronisation inter-thread.
//! * Le résultat de la conversion d'une référence vers un pointeur est valide tant que l'objet sous-jacent est actif et qu'aucune référence (juste des pointeurs bruts) n'est utilisée pour accéder à la même mémoire.
//!
//! Ces axiomes, ainsi qu'une utilisation prudente de [`offset`] pour l'arithmétique des pointeurs, sont suffisants pour implémenter correctement de nombreuses choses utiles dans un code non sécurisé.
//! Des garanties plus solides seront éventuellement fournies, au fur et à mesure que les règles [aliasing] seront déterminées.
//! Pour plus d'informations, voir le [book] ainsi que la section de la référence consacrée au [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Les pointeurs bruts valides tels que définis ci-dessus ne sont pas nécessairement correctement alignés (où l'alignement "proper" est défini par le type pointee, c'est-à-dire que `*const T` doit être aligné sur `mem::align_of::<T>()`).
//! Cependant, la plupart des fonctions exigent que leurs arguments soient correctement alignés et indiqueront explicitement cette exigence dans leur documentation.
//! Les exceptions notables à cela sont [`read_unaligned`] et [`write_unaligned`].
//!
//! Lorsqu'une fonction nécessite un alignement correct, elle le fait même si l'accès a la taille 0, c'est-à-dire même si la mémoire n'est pas réellement touchée.Envisagez d'utiliser [`NonNull::dangling`] dans de tels cas.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Exécute le destructeur (le cas échéant) de la valeur pointée.
///
/// Cela équivaut sémantiquement à appeler [`ptr::read`] et à ignorer le résultat, mais présente les avantages suivants:
///
/// * Il est *obligatoire* d'utiliser `drop_in_place` pour supprimer des types non dimensionnés comme les objets trait, car ils ne peuvent pas être lus sur la pile et déposés normalement.
///
/// * Il est plus convivial pour l'optimiseur de faire cela sur [`ptr::read`] lors de la suppression de la mémoire allouée manuellement (par exemple, dans les implémentations de `Box`/`Rc`/`Vec`), car le compilateur n'a pas besoin de prouver que c'est son pour éluder la copie.
///
///
/// * Il peut être utilisé pour supprimer des données [pinned] lorsque `T` n'est pas `repr(packed)` (les données épinglées ne doivent pas être déplacées avant d'être supprimées).
///
/// Les valeurs non alignées ne peuvent pas être supprimées, elles doivent d'abord être copiées vers un emplacement aligné à l'aide de [`ptr::read_unaligned`].Pour les structures compactées, ce déplacement est effectué automatiquement par le compilateur.
/// Cela signifie que les champs des structures compactées ne sont pas supprimés sur place.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Le comportement n'est pas défini si l'une des conditions suivantes n'est pas respectée:
///
/// * `to_drop` doit être [valid] pour les lectures et les écritures.
///
/// * `to_drop` doit être correctement aligné.
///
/// * La valeur vers laquelle pointe `to_drop` doit être valide pour la suppression, ce qui peut signifier qu'elle doit respecter des invariants supplémentaires, cela dépend du type.
///
/// En outre, si `T` n'est pas [`Copy`], l'utilisation de la valeur pointée après l'appel de `drop_in_place` peut entraîner un comportement indéfini.Notez que `*to_drop = foo` compte comme une utilisation car il entraînera à nouveau la suppression de la valeur.
/// [`write()`] peut être utilisé pour écraser des données sans provoquer leur suppression.
///
/// Notez que même si `T` a la taille `0`, le pointeur doit être non NULL et correctement aligné.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Supprimez manuellement le dernier élément d'un vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Obtenez un pointeur brut vers le dernier élément de `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Raccourcissez `v` pour empêcher la suppression du dernier élément.
///     // Nous faisons cela en premier, pour éviter les problèmes si le `drop_in_place` est inférieur à panics.
///     v.set_len(1);
///     // Sans un appel `drop_in_place`, le dernier élément ne serait jamais abandonné et la mémoire qu'il gère serait divulguée.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Assurez-vous que le dernier élément a été supprimé.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Notez que le compilateur effectue cette copie automatiquement lors de la suppression de structures compressées, c'est-à-dire que vous n'avez généralement pas à vous soucier de ces problèmes à moins que vous n'appeliez `drop_in_place` manuellement.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Le code ici n'a pas d'importance, il est remplacé par le véritable drop glue par le compilateur.
    //

    // SÉCURITÉ: voir commentaire ci-dessus
    unsafe { drop_in_place(to_drop) }
}

/// Crée un pointeur brut nul.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Crée un pointeur brut mutable nul.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Implément manuel nécessaire pour éviter la liaison `T: Clone`.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Implément manuel nécessaire pour éviter la liaison `T: Copy`.
impl<T> Copy for FatPtr<T> {}

/// Forme une tranche brute à partir d'un pointeur et d'une longueur.
///
/// L'argument `len` est le nombre de **éléments**, pas le nombre d'octets.
///
/// Cette fonction est sûre, mais l'utilisation de la valeur de retour n'est pas sûre.
/// Consultez la documentation de [`slice::from_raw_parts`] pour les exigences de sécurité des tranches.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // créer un pointeur de tranche lors du démarrage avec un pointeur vers le premier élément
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // SÉCURITÉ: L'accès à la valeur depuis l'union `Repr` est sécurisé depuis * const [T]
        //
        // et FatPtr ont les mêmes dispositions de mémoire.Seul std peut faire cette garantie.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Exécute les mêmes fonctionnalités que [`slice_from_raw_parts`], sauf qu'une tranche modifiable brute est renvoyée, par opposition à une tranche immuable brute.
///
///
/// Consultez la documentation de [`slice_from_raw_parts`] pour plus de détails.
///
/// Cette fonction est sûre, mais l'utilisation de la valeur de retour n'est pas sûre.
/// Consultez la documentation de [`slice::from_raw_parts_mut`] pour les exigences de sécurité des tranches.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // attribuer une valeur à un index de la tranche
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // SÉCURITÉ: L'accès à la valeur depuis l'union `Repr` est sécurisé depuis * mut [T]
        // et FatPtr ont les mêmes dispositions de mémoire
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Échange les valeurs à deux emplacements mutables du même type, sans désinitialisation non plus.
///
/// Mais pour les deux exceptions suivantes, cette fonction est sémantiquement équivalente à [`mem::swap`]:
///
///
/// * Il fonctionne sur des pointeurs bruts au lieu de références.
/// Lorsque des références sont disponibles, [`mem::swap`] doit être préféré.
///
/// * Les deux valeurs pointées peuvent se chevaucher.
/// Si les valeurs se chevauchent, alors la région de chevauchement de la mémoire de `x` sera utilisée.
/// Ceci est démontré dans le deuxième exemple ci-dessous.
///
/// # Safety
///
/// Le comportement n'est pas défini si l'une des conditions suivantes n'est pas respectée:
///
/// * `x` et `y` doivent être [valid] pour les lectures et les écritures.
///
/// * Les `x` et `y` doivent être correctement alignés.
///
/// Notez que même si `T` a la taille `0`, les pointeurs doivent être non NULL et correctement alignés.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Permutation de deux régions qui ne se chevauchent pas:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // c'est `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // c'est `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Permutation de deux régions qui se chevauchent:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // c'est `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // c'est `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Les indices `1..3` de la tranche se chevauchent entre `x` et `y`.
///     // Des résultats raisonnables seraient pour eux `[2, 3]`, de sorte que les indices `0..3` soient `[1, 2, 3]` (correspondant à `y` avant le `swap`);ou pour qu'ils soient `[0, 1]` afin que les indices `1..4` soient `[0, 1, 2]` (correspondant à `x` avant le `swap`).
/////
///     // Cette implémentation est définie pour faire ce dernier choix.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Donnez-nous un espace de travail avec lequel travailler.
    // Nous n'avons pas à nous soucier des chutes: `MaybeUninit` ne fait rien en cas de chute.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Effectuer le swap SÉCURITÉ: l'appelant doit garantir que `x` et `y` sont valides pour les écritures et correctement alignés.
    // `tmp` ne peut pas chevaucher `x` ou `y` car `tmp` vient d'être alloué sur la pile en tant qu'objet alloué distinct.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` et `y` peuvent se chevaucher
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Échange les octets `count * size_of::<T>()` entre les deux régions de mémoire en commençant par `x` et `y`.
/// Les deux régions ne doivent *pas* se chevaucher.
///
/// # Safety
///
/// Le comportement n'est pas défini si l'une des conditions suivantes n'est pas respectée:
///
/// * `x` et `y` doivent être [valid] pour les lectures et les écritures de `count *
///   taille de: :<T>() `octets.
///
/// * Les `x` et `y` doivent être correctement alignés.
///
/// * La région de mémoire commençant à `x` avec une taille de `count *
///   taille de: :<T>() `les octets ne doivent *pas* chevaucher la région de la mémoire commençant à `y` avec la même taille.
///
/// Notez que même si la taille effectivement copiée (`count * size_of: :<T>()`) est `0`, les pointeurs doivent être non NULL et correctement alignés.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Utilisation de base:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // SÉCURITÉ: l'appelant doit garantir que `x` et `y` sont
    // valide pour les écritures et correctement aligné.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Pour les types plus petits que l'optimisation de bloc ci-dessous, échangez simplement directement pour éviter de pessimiser le codegen.
    //
    if mem::size_of::<T>() < 32 {
        // SÉCURITÉ: l'appelant doit garantir que `x` et `y` sont valides
        // pour les écritures, correctement alignées et sans chevauchement.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // L'approche ici consiste à utiliser simd pour échanger efficacement x&y.
    // Les tests révèlent que l'échange de 32 octets ou de 64 octets à la fois est le plus efficace pour les processeurs Intel Haswell E.
    // LLVM est plus capable d'optimiser si nous donnons à une structure un #[repr(simd)], même si nous n'utilisons pas cette structure directement.
    //
    //
    // FIXME repr(simd) cassé sur emscripten et redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Boucle sur x&y, en les copiant `Block` à la fois L'optimiseur doit dérouler complètement la boucle pour la plupart des types NB
    // Nous ne pouvons pas utiliser une boucle for car le `range` impl appelle `mem::swap` de manière récursive
    //
    let mut i = 0;
    while i + block_size <= len {
        // Créer de la mémoire non initialisée comme espace de travail Déclarer `t` ici évite d'aligner la pile lorsque cette boucle est inutilisée
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // SÉCURITÉ: Comme `i < len`, et que l'appelant doit garantir que `x` et `y` sont valides
        // pour les octets `len`, `x + i` et `y + i` doivent être des adresses valides, qui remplissent le contrat de sécurité pour `add`.
        //
        // En outre, l'appelant doit garantir que `x` et `y` sont valides pour les écritures, correctement alignés et ne se chevauchant pas, ce qui remplit le contrat de sécurité pour `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Échangez un bloc d'octets de x&y, en utilisant t comme tampon temporaire Cela devrait être optimisé en opérations SIMD efficaces, le cas échéant
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Échangez tous les octets restants
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // SÉCURITÉ: voir le commentaire de sécurité précédent.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Déplace `src` dans le `dst` pointé, renvoyant la valeur `dst` précédente.
///
/// Aucune des deux valeurs n'est supprimée.
///
/// Cette fonction est sémantiquement équivalente à [`mem::replace`] sauf qu'elle fonctionne sur des pointeurs bruts au lieu de références.
/// Lorsque des références sont disponibles, [`mem::replace`] doit être préféré.
///
/// # Safety
///
/// Le comportement n'est pas défini si l'une des conditions suivantes n'est pas respectée:
///
/// * `dst` doit être [valid] pour les lectures et les écritures.
///
/// * `dst` doit être correctement aligné.
///
/// * `dst` doit pointer vers une valeur correctement initialisée de type `T`.
///
/// Notez que même si `T` a la taille `0`, le pointeur doit être non NULL et correctement aligné.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` aurait le même effet sans exiger le bloc unsafe.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // SÉCURITÉ: l'appelant doit garantir que `dst` est valide pour être
    // transtyper en une référence mutable (valide pour les écritures, aligné, initialisé) et ne peut pas chevaucher `src` car `dst` doit pointer vers un objet alloué distinct.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // ne peut pas se chevaucher
    }
    src
}

/// Lit la valeur de `src` sans la déplacer.Cela laisse la mémoire de `src` inchangée.
///
/// # Safety
///
/// Le comportement n'est pas défini si l'une des conditions suivantes n'est pas respectée:
///
/// * `src` doit être [valid] pour les lectures.
///
/// * `src` doit être correctement aligné.Utilisez [`read_unaligned`] si ce n'est pas le cas.
///
/// * `src` doit pointer vers une valeur correctement initialisée de type `T`.
///
/// Notez que même si `T` a la taille `0`, le pointeur doit être non NULL et correctement aligné.
///
/// # Examples
///
/// Utilisation de base:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Implémentez manuellement [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Créez une copie au niveau du bit de la valeur à `a` dans `tmp`.
///         let tmp = ptr::read(a);
///
///         // Quitter à ce stade (soit en retournant explicitement, soit en appelant une fonction qui panics) entraînerait la suppression de la valeur dans `tmp` alors que la même valeur est toujours référencée par `a`.
///         // Cela pourrait déclencher un comportement indéfini si `T` n'est pas `Copy`.
/////
/////
///
///         // Créez une copie au niveau du bit de la valeur à `b` dans `a`.
///         // Ceci est sûr car les références mutables ne peuvent pas créer d'alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Comme ci-dessus, quitter ici pourrait déclencher un comportement indéfini car la même valeur est référencée par `a` et `b`.
/////
///
///         // Déplacez `tmp` dans `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` a été déplacé (`write` prend possession de son deuxième argument), donc rien n'est supprimé implicitement ici.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Propriété de la valeur retournée
///
/// `read` crée une copie au niveau du bit de `T`, que `T` soit ou non [`Copy`].
/// Si `T` n'est pas [`Copy`], l'utilisation à la fois de la valeur renvoyée et de la valeur à `*src` peut violer la sécurité de la mémoire.
/// Notez que l'affectation à `*src` compte comme une utilisation car elle tentera de supprimer la valeur à `* src`.
///
/// [`write()`] peut être utilisé pour écraser des données sans provoquer leur suppression.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` pointe maintenant vers la même mémoire sous-jacente que `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // L'affectation à `s2` entraîne la suppression de sa valeur d'origine.
///     // Au-delà de ce point, `s` ne doit plus être utilisé, car la mémoire sous-jacente a été libérée.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // L'affectation à `s` entraînerait à nouveau la suppression de l'ancienne valeur, entraînant un comportement indéfini.
/////
///     // s= String::from("bar");//ERREUR
///
///     // `ptr::write` peut être utilisé pour écraser une valeur sans la supprimer.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SÉCURITÉ: l'appelant doit garantir que `src` est valide pour les lectures.
    // `src` ne peut pas chevaucher `tmp` car `tmp` vient d'être alloué sur la pile en tant qu'objet alloué distinct.
    //
    //
    // De plus, comme nous venons d'écrire une valeur valide dans `tmp`, il est garanti qu'il sera correctement initialisé.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Lit la valeur de `src` sans la déplacer.Cela laisse la mémoire de `src` inchangée.
///
/// Contrairement à [`read`], `read_unaligned` fonctionne avec des pointeurs non alignés.
///
/// # Safety
///
/// Le comportement n'est pas défini si l'une des conditions suivantes n'est pas respectée:
///
/// * `src` doit être [valid] pour les lectures.
///
/// * `src` doit pointer vers une valeur correctement initialisée de type `T`.
///
/// Comme [`read`], `read_unaligned` crée une copie au niveau du bit de `T`, que `T` soit ou non [`Copy`].
/// Si `T` n'est pas [`Copy`], utiliser à la fois la valeur renvoyée et la valeur à `*src` peut [violate memory safety][read-ownership].
///
/// Notez que même si `T` a la taille `0`, le pointeur doit être non NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Sur les structures `packed`
///
/// Il est actuellement impossible de créer des pointeurs bruts vers des champs non alignés d'une structure compressée.
///
/// Tenter de créer un pointeur brut vers un champ struct `unaligned` avec une expression telle que `&packed.unaligned as *const FieldType` crée une référence intermédiaire non alignée avant de la convertir en pointeur brut.
///
/// Le fait que cette référence soit temporaire et immédiatement convertie est sans conséquence car le compilateur s'attend toujours à ce que les références soient correctement alignées.
/// Par conséquent, l'utilisation de `&packed.unaligned as *const FieldType` entraîne un* comportement indéfini * immédiat dans votre programme.
///
/// Voici un exemple de ce qu'il ne faut pas faire et de son lien avec `read_unaligned`:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Ici, nous essayons de prendre l'adresse d'un entier de 32 bits qui n'est pas aligné.
///     let unaligned =
///         // Une référence temporaire non alignée est créée ici, ce qui entraîne un comportement non défini, que la référence soit utilisée ou non.
/////
///         &packed.unaligned
///         // Casting vers un pointeur brut n'aide pas;l'erreur s'est déjà produite.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// L'accès aux champs non alignés directement avec par exemple `packed.unaligned` est cependant sûr.
///
///
///
///
///
///
// FIXME: Mettre à jour les documents en fonction des résultats de la RFC #2582 et de ses amis.
/// # Examples
///
/// Lire une valeur usize à partir d'un tampon d'octets:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SÉCURITÉ: l'appelant doit garantir que `src` est valide pour les lectures.
    // `src` ne peut pas chevaucher `tmp` car `tmp` vient d'être alloué sur la pile en tant qu'objet alloué distinct.
    //
    //
    // De plus, comme nous venons d'écrire une valeur valide dans `tmp`, il est garanti qu'il sera correctement initialisé.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Remplace un emplacement mémoire par la valeur donnée sans lire ni supprimer l'ancienne valeur.
///
/// `write` ne supprime pas le contenu de `dst`.
/// C'est sûr, mais cela pourrait entraîner des fuites d'allocations ou de ressources, il faut donc veiller à ne pas écraser un objet qui doit être supprimé.
///
///
/// De plus, il ne supprime pas `src`.Sémantiquement, `src` est déplacé vers l'emplacement pointé par `dst`.
///
/// Cela convient à l'initialisation de la mémoire non initialisée ou à l'écrasement de la mémoire qui était auparavant [`read`].
///
/// # Safety
///
/// Le comportement n'est pas défini si l'une des conditions suivantes n'est pas respectée:
///
/// * `dst` doit être [valid] pour les écritures.
///
/// * `dst` doit être correctement aligné.Utilisez [`write_unaligned`] si ce n'est pas le cas.
///
/// Notez que même si `T` a la taille `0`, le pointeur doit être non NULL et correctement aligné.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Utilisation de base:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Implémentez manuellement [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Créez une copie au niveau du bit de la valeur à `a` dans `tmp`.
///         let tmp = ptr::read(a);
///
///         // Quitter à ce stade (soit en retournant explicitement, soit en appelant une fonction qui panics) entraînerait la suppression de la valeur dans `tmp` alors que la même valeur est toujours référencée par `a`.
///         // Cela pourrait déclencher un comportement indéfini si `T` n'est pas `Copy`.
/////
/////
///
///         // Créez une copie au niveau du bit de la valeur à `b` dans `a`.
///         // Ceci est sûr car les références mutables ne peuvent pas créer d'alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Comme ci-dessus, quitter ici pourrait déclencher un comportement indéfini car la même valeur est référencée par `a` et `b`.
/////
///
///         // Déplacez `tmp` dans `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` a été déplacé (`write` prend possession de son deuxième argument), donc rien n'est supprimé implicitement ici.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Nous appelons directement les intrinsèques pour éviter les appels de fonction dans le code généré car `intrinsics::copy_nonoverlapping` est une fonction wrapper.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // SÉCURITÉ: l'appelant doit garantir que `dst` est valide pour les écritures.
    // `dst` ne peut pas chevaucher `src` car l'appelant a un accès modifiable à `dst` alors que `src` appartient à cette fonction.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Remplace un emplacement mémoire par la valeur donnée sans lire ni supprimer l'ancienne valeur.
///
/// Contrairement à [`write()`], le pointeur peut ne pas être aligné.
///
/// `write_unaligned` ne supprime pas le contenu de `dst`.C'est sûr, mais cela pourrait entraîner des fuites d'allocations ou de ressources, il faut donc veiller à ne pas écraser un objet qui doit être supprimé.
///
/// De plus, il ne supprime pas `src`.Sémantiquement, `src` est déplacé vers l'emplacement pointé par `dst`.
///
/// Cela convient à l'initialisation de la mémoire non initialisée ou à l'écrasement de la mémoire précédemment lue avec [`read_unaligned`].
///
/// # Safety
///
/// Le comportement n'est pas défini si l'une des conditions suivantes n'est pas respectée:
///
/// * `dst` doit être [valid] pour les écritures.
///
/// Notez que même si `T` a la taille `0`, le pointeur doit être non NULL.
///
/// [valid]: self#safety
///
/// ## Sur les structures `packed`
///
/// Il est actuellement impossible de créer des pointeurs bruts vers des champs non alignés d'une structure compressée.
///
/// Tenter de créer un pointeur brut vers un champ struct `unaligned` avec une expression telle que `&packed.unaligned as *const FieldType` crée une référence intermédiaire non alignée avant de la convertir en pointeur brut.
///
/// Le fait que cette référence soit temporaire et immédiatement convertie est sans conséquence car le compilateur s'attend toujours à ce que les références soient correctement alignées.
/// Par conséquent, l'utilisation de `&packed.unaligned as *const FieldType` entraîne un* comportement indéfini * immédiat dans votre programme.
///
/// Voici un exemple de ce qu'il ne faut pas faire et de son lien avec `write_unaligned`:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Ici, nous essayons de prendre l'adresse d'un entier de 32 bits qui n'est pas aligné.
///     let unaligned =
///         // Une référence temporaire non alignée est créée ici, ce qui entraîne un comportement non défini, que la référence soit utilisée ou non.
/////
///         &mut packed.unaligned
///         // Casting vers un pointeur brut n'aide pas;l'erreur s'est déjà produite.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// L'accès aux champs non alignés directement avec par exemple `packed.unaligned` est cependant sûr.
///
///
///
///
///
///
///
///
///
// FIXME: Mettre à jour les documents en fonction des résultats de la RFC #2582 et de ses amis.
/// # Examples
///
/// Ecrivez une valeur usize dans un tampon d'octets:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // SÉCURITÉ: l'appelant doit garantir que `dst` est valide pour les écritures.
    // `dst` ne peut pas chevaucher `src` car l'appelant a un accès modifiable à `dst` alors que `src` appartient à cette fonction.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Nous appelons directement l'intrinsèque pour éviter les appels de fonction dans le code généré.
        intrinsics::forget(src);
    }
}

/// Effectue une lecture volatile de la valeur de `src` sans la déplacer.Cela laisse la mémoire de `src` inchangée.
///
/// Les opérations volatiles sont destinées à agir sur la mémoire I/O et sont garanties de ne pas être élidées ou réorganisées par le compilateur sur d'autres opérations volatiles.
///
/// # Notes
///
/// Rust n'a actuellement pas de modèle de mémoire rigoureusement et formellement défini, de sorte que la sémantique précise de ce que signifie "volatile" ici est sujette à changement au fil du temps.
/// Cela étant dit, la sémantique finira presque toujours par être assez similaire à [C11's definition of volatile][c11].
///
/// Le compilateur ne doit pas modifier l'ordre relatif ou le nombre d'opérations de mémoire volatile.
/// Cependant, les opérations de mémoire volatile sur les types de taille zéro (par exemple, si un type de taille zéro est passé à `read_volatile`) sont noops et peuvent être ignorées.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Le comportement n'est pas défini si l'une des conditions suivantes n'est pas respectée:
///
/// * `src` doit être [valid] pour les lectures.
///
/// * `src` doit être correctement aligné.
///
/// * `src` doit pointer vers une valeur correctement initialisée de type `T`.
///
/// Comme [`read`], `read_volatile` crée une copie au niveau du bit de `T`, que `T` soit ou non [`Copy`].
/// Si `T` n'est pas [`Copy`], utiliser à la fois la valeur renvoyée et la valeur à `*src` peut [violate memory safety][read-ownership].
/// Cependant, stocker des types non [`Copy`] dans une mémoire volatile est presque certainement incorrect.
///
/// Notez que même si `T` a la taille `0`, le pointeur doit être non NULL et correctement aligné.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Tout comme en C, le fait qu'une opération soit volatile n'a aucun rapport avec les questions impliquant un accès simultané à partir de plusieurs threads.Les accès volatils se comportent exactement comme les accès non atomiques à cet égard.
///
/// En particulier, une course entre un `read_volatile` et toute opération d'écriture au même emplacement est un comportement indéfini.
///
/// # Examples
///
/// Utilisation de base:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Pas de panique pour réduire l'impact du codegen.
        abort();
    }
    // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Effectue une écriture volatile d'un emplacement mémoire avec la valeur donnée sans lire ni supprimer l'ancienne valeur.
///
/// Les opérations volatiles sont destinées à agir sur la mémoire I/O et sont garanties de ne pas être élidées ou réorganisées par le compilateur sur d'autres opérations volatiles.
///
/// `write_volatile` ne supprime pas le contenu de `dst`.C'est sûr, mais cela pourrait entraîner des fuites d'allocations ou de ressources, il faut donc veiller à ne pas écraser un objet qui doit être supprimé.
///
/// De plus, il ne supprime pas `src`.Sémantiquement, `src` est déplacé vers l'emplacement pointé par `dst`.
///
/// # Notes
///
/// Rust n'a actuellement pas de modèle de mémoire rigoureusement et formellement défini, de sorte que la sémantique précise de ce que signifie "volatile" ici est sujette à changement au fil du temps.
/// Cela étant dit, la sémantique finira presque toujours par être assez similaire à [C11's definition of volatile][c11].
///
/// Le compilateur ne doit pas modifier l'ordre relatif ou le nombre d'opérations de mémoire volatile.
/// Cependant, les opérations de mémoire volatile sur les types de taille zéro (par exemple, si un type de taille zéro est passé à `write_volatile`) sont noops et peuvent être ignorées.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Le comportement n'est pas défini si l'une des conditions suivantes n'est pas respectée:
///
/// * `dst` doit être [valid] pour les écritures.
///
/// * `dst` doit être correctement aligné.
///
/// Notez que même si `T` a la taille `0`, le pointeur doit être non NULL et correctement aligné.
///
/// [valid]: self#safety
///
/// Tout comme en C, le fait qu'une opération soit volatile n'a aucun rapport avec les questions impliquant un accès simultané à partir de plusieurs threads.Les accès volatils se comportent exactement comme les accès non atomiques à cet égard.
///
/// En particulier, une course entre un `write_volatile` et toute autre opération (lecture ou écriture) sur le même emplacement est un comportement indéfini.
///
/// # Examples
///
/// Utilisation de base:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Pas de panique pour réduire l'impact du codegen.
        abort();
    }
    // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Alignez le pointeur `p`.
///
/// Calculez le décalage (en termes d'éléments de foulée `stride`) qui doit être appliqué au pointeur `p` afin que le pointeur `p` soit aligné sur `a`.
///
/// Note: Cette implémentation a été soigneusement adaptée pour ne pas panic.C'est UB pour cela à panic.
/// Le seul vrai changement qui peut être fait ici est le changement de `INV_TABLE_MOD_16` et des constantes associées.
///
/// Si jamais nous décidons de rendre possible d'appeler l'intrinsèque avec `a` qui n'est pas une puissance de deux, il sera probablement plus prudent de simplement passer à une implémentation naïve plutôt que d'essayer de l'adapter pour s'adapter à ce changement.
///
///
/// Toutes les questions sont adressées à@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): L'utilisation directe de ces éléments intrinsèques améliore considérablement le codegen au niveau opt <=
    // 1, où les versions de méthode de ces opérations ne sont pas intégrées.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Calculez l'inverse modulaire multiplicatif de `x` modulo `m`.
    ///
    /// Cette implémentation est conçue pour `align_offset` et a les conditions préalables suivantes:
    ///
    /// * `m` est un pouvoir de deux;
    /// * `x < m`; (si `x ≥ m`, passez dans `x % m` à la place)
    ///
    /// La mise en œuvre de cette fonction ne doit pas panic.Jamais.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Table inverse modulaire multiplicative modulo 2⁴=16.
        ///
        /// Notez que ce tableau ne contient pas de valeurs pour lesquelles l'inverse n'existe pas (c'est-à-dire pour `0⁻¹ mod 16`, `2⁻¹ mod 16`, etc.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo auquel le `INV_TABLE_MOD_16` est destiné.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // SÉCURITÉ: `m` doit être une puissance de deux, donc non nulle.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Nous itérons "up" en utilisant la formule suivante:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // jusqu'à 2²ⁿ ≥ m.Ensuite, nous pouvons réduire à notre `m` souhaité en prenant le résultat `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Notez que nous utilisons intentionnellement des opérations d'encapsulation ici-la formule originale utilise par exemple la soustraction `mod n`.
                // Il est tout à fait correct de les faire `mod usize::MAX` à la place, car nous prenons de toute façon le résultat `mod n` à la fin.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // SÉCURITÉ: `a` est une puissance de deux, donc non nulle.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` case peut être calculée plus simplement via `-p (mod a)`, mais cela empêche LLVM de sélectionner des instructions telles que `lea`.Au lieu de cela, nous calculons
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // qui répartit les opérations autour du porteur, mais pessimise suffisamment `and` pour que LLVM puisse utiliser les différentes optimisations dont il a connaissance.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Déjà aligné.Yay!
        return 0;
    } else if stride == 0 {
        // Si le pointeur n'est pas aligné et que l'élément est de taille zéro, aucune quantité d'éléments n'alignera jamais le pointeur.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // SÉCURITÉ: a est une puissance de deux donc non nulle.stride==0 cas est traité ci-dessus.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // SÉCURITÉ: gcdpow a une limite supérieure qui correspond au maximum au nombre de bits dans une taille d'utilisation.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // SÉCURITÉ: pgcd est toujours supérieur ou égal à 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Ce branch résout l'équation de congruence linéaire suivante:
        //
        // ` p + so = 0 mod a `
        //
        // `p` voici la valeur du pointeur, `s`, la foulée de `T`, le décalage `o` en «T» et `a`, l'alignement demandé.
        //
        // Avec `g = gcd(a, s)`, et la condition ci-dessus affirmant que `p` est également divisible par `g`, nous pouvons désigner `a' = a/g`, `s' = s/g`, `p' = p/g`, alors cela devient équivalent à:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Le premier terme est "the relative alignment of `p` to `a`" (divisé par `g`), le deuxième terme est "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (à nouveau divisé par `g`).
        //
        // Une division par `g` est nécessaire pour que l'inverse soit bien formé si `a` et `s` ne sont pas co-premiers.
        //
        // De plus, le résultat produit par cette solution n'est pas "minimal", il faut donc prendre le résultat `o mod lcm(s, a)`.Nous pouvons remplacer `lcm(s, a)` par juste un `a'`.
        //
        //
        //
        //
        //

        // SÉCURITÉ: `gcdpow` a une limite supérieure non supérieure au nombre de 0 bits de fin dans `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // SÉCURITÉ: `a2` est différent de zéro.Le décalage de `a` par `gcdpow` ne peut décaler aucun des bits définis
        // dans `a` (dont il en a exactement un).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // SÉCURITÉ: `gcdpow` a une limite supérieure non supérieure au nombre de 0 bits de fin dans `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SÉCURITÉ: `gcdpow` a une limite supérieure non supérieure au nombre de 0 bits de fin dans
        // `a`.
        // De plus, la soustraction ne peut pas déborder, car `a2 = a >> gcdpow` sera toujours strictement supérieur à `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // SÉCURITÉ: `a2` est une puissance de deux, comme prouvé ci-dessus.`s2` est strictement inférieur à `a2`
        // car `(s % a) >> gcdpow` est strictement inférieur à `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Ne peut pas du tout être aligné.
    usize::MAX
}

/// Compare les pointeurs bruts pour l'égalité.
///
/// C'est la même chose que l'utilisation de l'opérateur `==`, mais moins générique:
/// les arguments doivent être des pointeurs bruts `*const T`, pas quelque chose qui implémente `PartialEq`.
///
/// Cela peut être utilisé pour comparer les références `&T` (qui contraignent implicitement à `*const T`) par leur adresse plutôt que de comparer les valeurs vers lesquelles elles pointent (ce que fait l'implémentation `PartialEq for &T`).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Les tranches sont également comparées par leur longueur (pointeurs de graisse):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Les Traits sont également comparés par leur implémentation:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Les pointeurs ont des adresses égales.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Les objets ont des adresses égales, mais `Trait` a des implémentations différentes.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // La conversion de la référence en `*const u8` compare par adresse.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash un pointeur brut.
///
/// Cela peut être utilisé pour hacher une référence `&T` (qui contraint implicitement à `*const T`) par son adresse plutôt que par la valeur vers laquelle elle pointe (ce que fait l'implémentation `Hash for &T`).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impls pour les pointeurs de fonction
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: La fonte intermédiaire au fur et à mesure de l'utilisation est requise pour l'AVR
                // de sorte que l'espace d'adressage du pointeur de fonction source soit conservé dans le pointeur de fonction final.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: La fonte intermédiaire au fur et à mesure de l'utilisation est requise pour l'AVR
                // de sorte que l'espace d'adressage du pointeur de fonction source soit conservé dans le pointeur de fonction final.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Pas de fonctions variadiques avec 0 paramètre
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Créez un pointeur brut `const` vers un lieu, sans créer de référence intermédiaire.
///
/// La création d'une référence avec `&`/`&mut` n'est autorisée que si le pointeur est correctement aligné et pointe vers des données initialisées.
/// Pour les cas où ces exigences ne sont pas satisfaites, des pointeurs bruts doivent être utilisés à la place.
/// Cependant, `&expr as *const _` crée une référence avant de la convertir en pointeur brut, et cette référence est soumise aux mêmes règles que toutes les autres références.
///
/// Cette macro peut créer un pointeur brut *sans* créer une référence au préalable.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` créerait une référence non alignée, et donc un comportement indéfini!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Créez un pointeur brut `mut` vers un lieu, sans créer de référence intermédiaire.
///
/// La création d'une référence avec `&`/`&mut` n'est autorisée que si le pointeur est correctement aligné et pointe vers des données initialisées.
/// Pour les cas où ces exigences ne sont pas satisfaites, des pointeurs bruts doivent être utilisés à la place.
/// Cependant, `&mut expr as *mut _` crée une référence avant de la convertir en pointeur brut, et cette référence est soumise aux mêmes règles que toutes les autres références.
///
/// Cette macro peut créer un pointeur brut *sans* créer une référence au préalable.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` créerait une référence non alignée, et donc un comportement indéfini!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` force la copie du champ au lieu de créer une référence.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}