use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` mais non nul et covariant.
///
/// C'est souvent la bonne chose à utiliser lors de la création de structures de données à l'aide de pointeurs bruts, mais elle est finalement plus dangereuse à utiliser en raison de ses propriétés supplémentaires.Si vous ne savez pas si vous devez utiliser `NonNull<T>`, utilisez simplement `*mut T`!
///
/// Contrairement à `*mut T`, le pointeur doit toujours être non nul, même si le pointeur n'est jamais déréférencé.C'est pour que les énumérations puissent utiliser cette valeur interdite comme discriminant-`Option<NonNull<T>>` a la même taille que `* mut T`.
/// Cependant, le pointeur peut toujours pendre s'il n'est pas déréférencé.
///
/// Contrairement à `*mut T`, `NonNull<T>` a été choisi comme covariant sur `T`.Cela permet d'utiliser `NonNull<T>` lors de la construction de types covariants, mais introduit le risque de défaut de cohérence s'il est utilisé dans un type qui ne devrait pas réellement être covariant.
/// (Le choix opposé a été fait pour `*mut T` même si techniquement le défaut ne pouvait être causé qu'en appelant des fonctions non sécurisées.)
///
/// La covariance est correcte pour la plupart des abstractions sûres, telles que `Box`, `Rc`, `Arc`, `Vec` et `LinkedList`.C'est le cas car ils fournissent une API publique qui suit les règles de mutation XOR partagées normales de Rust.
///
/// Si votre type ne peut pas être covariant en toute sécurité, vous devez vous assurer qu'il contient un champ supplémentaire pour fournir une invariance.Souvent, ce champ sera de type [`PhantomData`] comme `PhantomData<Cell<T>>` ou `PhantomData<&'a mut T>`.
///
/// Notez que `NonNull<T>` a une instance `From` pour `&T`.Cependant, cela ne change pas le fait que la mutation via une (pointeur dérivé d'une) référence partagée est un comportement indéfini à moins que la mutation ne se produise à l'intérieur d'un [`UnsafeCell<T>`].Il en va de même pour la création d'une référence mutable à partir d'une référence partagée.
///
/// Lorsque vous utilisez cette instance `From` sans `UnsafeCell<T>`, il est de votre responsabilité de vous assurer que `as_mut` n'est jamais appelé et que `as_ptr` n'est jamais utilisé pour la mutation.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` les pointeurs ne sont pas `Send` car les données auxquelles ils font référence peuvent avoir un alias.
// NB, cet impl est inutile, mais devrait fournir de meilleurs messages d'erreur.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` les pointeurs ne sont pas `Sync` car les données auxquelles ils font référence peuvent avoir un alias.
// NB, cet impl est inutile, mais devrait fournir de meilleurs messages d'erreur.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Crée un nouveau `NonNull` suspendu, mais bien aligné.
    ///
    /// Ceci est utile pour initialiser les types qui sont alloués paresseusement, comme le fait `Vec::new`.
    ///
    /// Notez que la valeur du pointeur peut potentiellement représenter un pointeur valide vers un `T`, ce qui signifie qu'il ne doit pas être utilisé comme valeur sentinelle "not yet initialized".
    /// Les types qui allouent paresseusement doivent suivre l'initialisation par d'autres moyens.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // SÉCURITÉ: mem::align_of() renvoie une taille d'utilisation non nulle qui est ensuite castée
        // à un * mut T.
        // Par conséquent, `ptr` n'est pas nul et les conditions d'appel de new_unchecked() sont respectées.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Renvoie une référence partagée à la valeur.Contrairement à [`as_ref`], cela ne nécessite pas d'initialisation de la valeur.
    ///
    /// Pour la contrepartie mutable, voir [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Lorsque vous appelez cette méthode, vous devez vous assurer que toutes les conditions suivantes sont remplies:
    ///
    /// * Le pointeur doit être correctement aligné.
    ///
    /// * Il doit s'agir de "dereferencable" au sens défini dans [the module documentation].
    ///
    /// * Vous devez appliquer les règles d'alias de Rust, car la durée de vie renvoyée `'a` est choisie arbitrairement et ne reflète pas nécessairement la durée de vie réelle des données.
    ///
    ///   En particulier, pendant la durée de cette durée de vie, la mémoire vers laquelle pointe le pointeur ne doit pas être mutée (sauf à l'intérieur de `UnsafeCell`).
    ///
    /// Cela s'applique même si le résultat de cette méthode n'est pas utilisé!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // SÉCURITÉ: l'appelant doit garantir que `self` répond à toutes les
        // exigences pour une référence.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Renvoie une référence unique à la valeur.Contrairement à [`as_mut`], cela ne nécessite pas d'initialisation de la valeur.
    ///
    /// Pour la contrepartie partagée, voir [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Lorsque vous appelez cette méthode, vous devez vous assurer que toutes les conditions suivantes sont remplies:
    ///
    /// * Le pointeur doit être correctement aligné.
    ///
    /// * Il doit s'agir de "dereferencable" au sens défini dans [the module documentation].
    ///
    /// * Vous devez appliquer les règles d'alias de Rust, car la durée de vie renvoyée `'a` est choisie arbitrairement et ne reflète pas nécessairement la durée de vie réelle des données.
    ///
    ///   En particulier, pendant la durée de cette durée de vie, la mémoire vers laquelle pointe le pointeur ne doit pas être accédée (lue ou écrite) par un autre pointeur.
    ///
    /// Cela s'applique même si le résultat de cette méthode n'est pas utilisé!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // SÉCURITÉ: l'appelant doit garantir que `self` répond à toutes les
        // exigences pour une référence.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Crée un nouveau `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` doit être non nul.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SÉCURITÉ: l'appelant doit garantir que `ptr` est non nul.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Crée un nouveau `NonNull` si `ptr` est non nul.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SÉCURITÉ: le pointeur est déjà vérifié et n'est pas nul
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Exécute les mêmes fonctionnalités que [`std::ptr::from_raw_parts`], sauf qu'un pointeur `NonNull` est renvoyé, par opposition à un pointeur `*const` brut.
    ///
    ///
    /// Consultez la documentation de [`std::ptr::from_raw_parts`] pour plus de détails.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // SÉCURITÉ: Le résultat de `ptr::from::raw_parts_mut` est non nul car `data_address` l'est.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Décomposez un pointeur (éventuellement large) en ses composants d'adresse et de métadonnées.
    ///
    /// Le pointeur peut être reconstruit ultérieurement avec [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Acquiert le pointeur `*mut` sous-jacent.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Renvoie une référence partagée à la valeur.Si la valeur n'est peut-être pas initialisée, [`as_uninit_ref`] doit être utilisé à la place.
    ///
    /// Pour la contrepartie mutable, voir [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Lorsque vous appelez cette méthode, vous devez vous assurer que toutes les conditions suivantes sont remplies:
    ///
    /// * Le pointeur doit être correctement aligné.
    ///
    /// * Il doit s'agir de "dereferencable" au sens défini dans [the module documentation].
    ///
    /// * Le pointeur doit pointer vers une instance initialisée de `T`.
    ///
    /// * Vous devez appliquer les règles d'alias de Rust, car la durée de vie renvoyée `'a` est choisie arbitrairement et ne reflète pas nécessairement la durée de vie réelle des données.
    ///
    ///   En particulier, pendant la durée de cette durée de vie, la mémoire vers laquelle pointe le pointeur ne doit pas être mutée (sauf à l'intérieur de `UnsafeCell`).
    ///
    /// Cela s'applique même si le résultat de cette méthode n'est pas utilisé!
    /// (La partie concernant l'initialisation n'est pas encore entièrement décidée, mais tant qu'elle ne le sera pas, la seule approche sûre consiste à s'assurer qu'ils sont effectivement initialisés.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SÉCURITÉ: l'appelant doit garantir que `self` répond à toutes les
        // exigences pour une référence.
        unsafe { &*self.as_ptr() }
    }

    /// Renvoie une référence unique à la valeur.Si la valeur n'est peut-être pas initialisée, [`as_uninit_mut`] doit être utilisé à la place.
    ///
    /// Pour la contrepartie partagée, voir [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Lorsque vous appelez cette méthode, vous devez vous assurer que toutes les conditions suivantes sont remplies:
    ///
    /// * Le pointeur doit être correctement aligné.
    ///
    /// * Il doit s'agir de "dereferencable" au sens défini dans [the module documentation].
    ///
    /// * Le pointeur doit pointer vers une instance initialisée de `T`.
    ///
    /// * Vous devez appliquer les règles d'alias de Rust, car la durée de vie renvoyée `'a` est choisie arbitrairement et ne reflète pas nécessairement la durée de vie réelle des données.
    ///
    ///   En particulier, pendant la durée de cette durée de vie, la mémoire vers laquelle pointe le pointeur ne doit pas être accédée (lue ou écrite) par un autre pointeur.
    ///
    /// Cela s'applique même si le résultat de cette méthode n'est pas utilisé!
    /// (La partie concernant l'initialisation n'est pas encore entièrement décidée, mais tant qu'elle ne le sera pas, la seule approche sûre consiste à s'assurer qu'ils sont effectivement initialisés.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SÉCURITÉ: l'appelant doit garantir que `self` répond à toutes les
        // exigences pour une référence mutable.
        unsafe { &mut *self.as_ptr() }
    }

    /// Convertit en un pointeur d'un autre type.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SÉCURITÉ: `self` est un pointeur `NonNull` qui est nécessairement non nul
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Crée une tranche brute non nulle à partir d'un pointeur fin et d'une longueur.
    ///
    /// L'argument `len` est le nombre de **éléments**, pas le nombre d'octets.
    ///
    /// Cette fonction est sûre, mais le déréférencement de la valeur de retour n'est pas sûr.
    /// Consultez la documentation de [`slice::from_raw_parts`] pour les exigences de sécurité des tranches.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // créer un pointeur de tranche lors du démarrage avec un pointeur vers le premier élément
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Notez que cet exemple démontre artificiellement une utilisation de cette méthode, mais `let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // SÉCURITÉ: `data` est un pointeur `NonNull` qui est nécessairement non nul
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Renvoie la longueur d'une tranche brute non nulle.
    ///
    /// La valeur renvoyée est le nombre de **éléments**, pas le nombre d'octets.
    ///
    /// Cette fonction est sûre, même lorsque la tranche brute non nulle ne peut pas être déréférencée à une tranche car le pointeur n'a pas d'adresse valide.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Renvoie un pointeur non nul vers le tampon de la tranche.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SÉCURITÉ: Nous savons que `self` est non nul.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Renvoie un pointeur brut vers le tampon de la tranche.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Renvoie une référence partagée à une tranche de valeurs éventuellement non initialisées.Contrairement à [`as_ref`], cela ne nécessite pas d'initialisation de la valeur.
    ///
    /// Pour la contrepartie mutable, voir [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Lorsque vous appelez cette méthode, vous devez vous assurer que toutes les conditions suivantes sont remplies:
    ///
    /// * Le pointeur doit être [valid] pour les lectures de nombreux octets `ptr.len() * mem::size_of::<T>()` et il doit être correctement aligné.Cela signifie notamment:
    ///
    ///     * Toute la plage de mémoire de cette tranche doit être contenue dans un seul objet alloué!
    ///       Les tranches ne peuvent jamais s'étendre sur plusieurs objets alloués.
    ///
    ///     * Le pointeur doit être aligné même pour les tranches de longueur nulle.
    ///     L'une des raisons à cela est que les optimisations de mise en page enum peuvent s'appuyer sur des références (y compris des tranches de toute longueur) alignées et non nulles pour les distinguer des autres données.
    ///
    ///     Vous pouvez obtenir un pointeur utilisable en tant que `data` pour les tranches de longueur nulle à l'aide de [`NonNull::dangling()`].
    ///
    /// * La taille totale `ptr.len() * mem::size_of::<T>()` de la tranche ne doit pas être supérieure à `isize::MAX`.
    ///   Consultez la documentation de sécurité du [`pointer::offset`].
    ///
    /// * Vous devez appliquer les règles d'alias de Rust, car la durée de vie renvoyée `'a` est choisie arbitrairement et ne reflète pas nécessairement la durée de vie réelle des données.
    ///   En particulier, pendant la durée de cette durée de vie, la mémoire vers laquelle pointe le pointeur ne doit pas être mutée (sauf à l'intérieur de `UnsafeCell`).
    ///
    /// Cela s'applique même si le résultat de cette méthode n'est pas utilisé!
    ///
    /// Voir également [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Renvoie une référence unique à une tranche de valeurs éventuellement non initialisées.Contrairement à [`as_mut`], cela ne nécessite pas d'initialisation de la valeur.
    ///
    /// Pour la contrepartie partagée, voir [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Lorsque vous appelez cette méthode, vous devez vous assurer que toutes les conditions suivantes sont remplies:
    ///
    /// * Le pointeur doit être [valid] pour les lectures et écritures pour `ptr.len() * mem::size_of::<T>()` de nombreux octets, et il doit être correctement aligné.Cela signifie notamment:
    ///
    ///     * Toute la plage de mémoire de cette tranche doit être contenue dans un seul objet alloué!
    ///       Les tranches ne peuvent jamais s'étendre sur plusieurs objets alloués.
    ///
    ///     * Le pointeur doit être aligné même pour les tranches de longueur nulle.
    ///     L'une des raisons à cela est que les optimisations de mise en page enum peuvent s'appuyer sur des références (y compris des tranches de toute longueur) alignées et non nulles pour les distinguer des autres données.
    ///
    ///     Vous pouvez obtenir un pointeur utilisable en tant que `data` pour les tranches de longueur nulle à l'aide de [`NonNull::dangling()`].
    ///
    /// * La taille totale `ptr.len() * mem::size_of::<T>()` de la tranche ne doit pas être supérieure à `isize::MAX`.
    ///   Consultez la documentation de sécurité du [`pointer::offset`].
    ///
    /// * Vous devez appliquer les règles d'alias de Rust, car la durée de vie renvoyée `'a` est choisie arbitrairement et ne reflète pas nécessairement la durée de vie réelle des données.
    ///   En particulier, pendant la durée de cette durée de vie, la mémoire vers laquelle pointe le pointeur ne doit pas être accédée (lue ou écrite) par un autre pointeur.
    ///
    /// Cela s'applique même si le résultat de cette méthode n'est pas utilisé!
    ///
    /// Voir également [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Ceci est sûr car `memory` est valide pour les lectures et les écritures pour `memory.len()` de nombreux octets.
    /// // Notez que l'appel `memory.as_mut()` n'est pas autorisé ici car le contenu peut être non initialisé.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Renvoie un pointeur brut vers un élément ou une sous-tranche, sans effectuer de vérification des limites.
    ///
    /// L'appel de cette méthode avec un index hors limites ou lorsque `self` n'est pas déréférencable est *[comportement indéfini]* même si le pointeur résultant n'est pas utilisé.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // SÉCURITÉ: l'appelant s'assure que `self` est déréférencable et `index` dans les limites.
        // Par conséquent, le pointeur résultant ne peut pas être NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // SÉCURITÉ: un pointeur unique ne peut pas être nul, donc les conditions pour
        // new_unchecked() sont respectés.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SÉCURITÉ: une référence mutable ne peut pas être nulle.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // SÉCURITÉ: une référence ne peut pas être nulle, donc les conditions pour
        // new_unchecked() sont respectés.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}