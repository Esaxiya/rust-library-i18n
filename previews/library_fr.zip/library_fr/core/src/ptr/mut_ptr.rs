use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Renvoie `true` si le pointeur est nul.
    ///
    /// Notez que les types non dimensionnés ont de nombreux pointeurs nuls possibles, car seul le pointeur de données brutes est pris en compte, pas leur longueur, vtable, etc.
    /// Par conséquent, deux pointeurs qui sont nuls peuvent toujours ne pas se comparer égaux.
    ///
    /// ## Comportement lors de l'évaluation const
    ///
    /// Lorsque cette fonction est utilisée lors de l'évaluation de const, elle peut renvoyer `false` pour les pointeurs qui s'avèrent être null au moment de l'exécution.
    /// Plus précisément, lorsqu'un pointeur vers une mémoire est décalé au-delà de ses limites de telle sorte que le pointeur résultant est nul, la fonction renvoie toujours `false`.
    ///
    /// Il n'y a aucun moyen pour CTFE de connaître la position absolue de cette mémoire, nous ne pouvons donc pas dire si le pointeur est nul ou non.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Comparez via un cast à un pointeur fin, de sorte que les pointeurs gras ne considèrent que leur partie "data" pour une valeur nulle.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Convertit en un pointeur d'un autre type.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Décomposez un pointeur (éventuellement large) en ses composants d'adresse et de métadonnées.
    ///
    /// Le pointeur peut être reconstruit ultérieurement avec [`from_raw_parts_mut`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Renvoie `None` si le pointeur est nul, ou renvoie une référence partagée à la valeur encapsulée dans `Some`.Si la valeur n'est peut-être pas initialisée, [`as_uninit_ref`] doit être utilisé à la place.
    ///
    /// Pour la contrepartie mutable, voir [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Lors de l'appel de cette méthode, vous devez vous assurer que *soit* le pointeur est NULL *soit* toutes les conditions suivantes sont vraies:
    ///
    /// * Le pointeur doit être correctement aligné.
    ///
    /// * Il doit s'agir de "dereferencable" au sens défini dans [the module documentation].
    ///
    /// * Le pointeur doit pointer vers une instance initialisée de `T`.
    ///
    /// * Vous devez appliquer les règles d'alias de Rust, car la durée de vie renvoyée `'a` est choisie arbitrairement et ne reflète pas nécessairement la durée de vie réelle des données.
    ///   En particulier, pendant la durée de cette durée de vie, la mémoire vers laquelle pointe le pointeur ne doit pas être mutée (sauf à l'intérieur de `UnsafeCell`).
    ///
    /// Cela s'applique même si le résultat de cette méthode n'est pas utilisé!
    /// (La partie concernant l'initialisation n'est pas encore entièrement décidée, mais tant qu'elle ne le sera pas, la seule approche sûre consiste à s'assurer qu'ils sont effectivement initialisés.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Version non vérifiée
    ///
    /// Si vous êtes sûr que le pointeur ne peut jamais être nul et que vous recherchez une sorte de `as_ref_unchecked` qui renvoie le `&T` au lieu de `Option<&T>`, sachez que vous pouvez déréférencer le pointeur directement.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // SÉCURITÉ: l'appelant doit garantir que `self` est valide pour un
        // référence s'il n'est pas nul.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Renvoie `None` si le pointeur est nul, ou renvoie une référence partagée à la valeur encapsulée dans `Some`.
    /// Contrairement à [`as_ref`], cela ne nécessite pas d'initialisation de la valeur.
    ///
    /// Pour la contrepartie mutable, voir [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Lors de l'appel de cette méthode, vous devez vous assurer que *soit* le pointeur est NULL *soit* toutes les conditions suivantes sont vraies:
    ///
    /// * Le pointeur doit être correctement aligné.
    ///
    /// * Il doit s'agir de "dereferencable" au sens défini dans [the module documentation].
    ///
    /// * Vous devez appliquer les règles d'alias de Rust, car la durée de vie renvoyée `'a` est choisie arbitrairement et ne reflète pas nécessairement la durée de vie réelle des données.
    ///
    ///   En particulier, pendant la durée de cette durée de vie, la mémoire vers laquelle pointe le pointeur ne doit pas être mutée (sauf à l'intérieur de `UnsafeCell`).
    ///
    /// Cela s'applique même si le résultat de cette méthode n'est pas utilisé!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // SÉCURITÉ: l'appelant doit garantir que `self` répond à toutes les
        // exigences pour une référence.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Calcule le décalage à partir d'un pointeur.
    ///
    /// `count` est en unités de T;par exemple, un `count` de 3 représente un décalage de pointeur de `3 * size_of::<T>()` octets.
    ///
    /// # Safety
    ///
    /// Si l'une des conditions suivantes n'est pas respectée, le résultat est un comportement indéfini:
    ///
    /// * Le pointeur de départ et le pointeur résultant doivent être soit dans les limites, soit un octet après la fin du même objet alloué.
    /// Notez que dans Rust, chaque variable (stack-allocated) est considérée comme un objet alloué distinct.
    ///
    /// * Le décalage calculé,**en octets**, ne peut pas dépasser un `isize`.
    ///
    /// * Le décalage étant dans les limites ne peut pas dépendre de "wrapping around" l'espace d'adressage.Autrement dit, la somme de précision infinie,**en octets** doit tenir dans un usize.
    ///
    /// Le compilateur et la bibliothèque standard essaient généralement de s'assurer que les allocations n'atteignent jamais une taille où un décalage est un problème.
    /// Par exemple, `Vec` et `Box` s'assurent qu'ils n'allouent jamais plus de `isize::MAX` octets, donc `vec.as_ptr().add(vec.len())` est toujours sûr.
    ///
    /// La plupart des plates-formes ne peuvent fondamentalement même pas construire une telle allocation.
    /// Par exemple, aucune plate-forme 64 bits connue ne peut jamais servir une demande de 2 <sup>63</sup> octets en raison de limitations de la table de pages ou de la division de l'espace d'adressage.
    /// Cependant, certaines plates-formes 32 bits et 16 bits peuvent répondre avec succès à une demande de plus de `isize::MAX` octets avec des éléments tels que l'extension d'adresse physique.
    ///
    /// En tant que tel, la mémoire acquise directement à partir des allocateurs ou des fichiers mappés en mémoire *peut* être trop volumineuse pour être gérée avec cette fonction.
    ///
    /// Pensez à utiliser [`wrapping_offset`] à la place si ces contraintes sont difficiles à satisfaire.
    /// Le seul avantage de cette méthode est qu'elle permet des optimisations plus agressives du compilateur.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `offset`.
        // Le pointeur obtenu est valide pour les écritures puisque l'appelant doit garantir qu'il pointe vers le même objet alloué que `self`.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Calcule le décalage à partir d'un pointeur à l'aide de l'arithmétique d'encapsulation.
    /// `count` est en unités de T;par exemple, un `count` de 3 représente un décalage de pointeur de `3 * size_of::<T>()` octets.
    ///
    /// # Safety
    ///
    /// Cette opération elle-même est toujours sûre, mais l'utilisation du pointeur résultant ne l'est pas.
    ///
    /// Le pointeur résultant reste attaché au même objet alloué vers lequel pointe `self`.
    /// Il ne peut *pas* être utilisé pour accéder à un objet alloué différent.Notez que dans Rust, chaque variable (stack-allocated) est considérée comme un objet alloué distinct.
    ///
    /// En d'autres termes, `let z = x.wrapping_offset((y as isize) - (x as isize))` ne rend *pas*`z` identique à `y` même si nous supposons que `T` a la taille `1` et qu'il n'y a pas de débordement: `z` est toujours attaché à l'objet auquel `x` est attaché, et le déréférencement est un comportement indéfini sauf si `x` et `y` pointe vers le même objet alloué.
    ///
    /// Par rapport à [`offset`], cette méthode retarde fondamentalement l'exigence de rester dans le même objet alloué: [`offset`] est un comportement indéfini immédiat lors du franchissement des limites d'objet;`wrapping_offset` produit un pointeur mais conduit toujours à un comportement indéfini si un pointeur est déréférencé lorsqu'il est hors des limites de l'objet auquel il est attaché.
    /// [`offset`] peut être optimisé mieux et est donc préférable dans le code sensible aux performances.
    ///
    /// La vérification différée ne prend en compte que la valeur du pointeur qui a été déréférencée, et non les valeurs intermédiaires utilisées lors du calcul du résultat final.
    /// Par exemple, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` est toujours le même que `x`.En d'autres termes, il est permis de quitter l'objet alloué, puis de le saisir à nouveau plus tard.
    ///
    /// Si vous devez traverser les limites des objets, transtypez le pointeur en entier et effectuez l'arithmétique à cet endroit.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// // Itérer à l'aide d'un pointeur brut par incréments de deux éléments
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // SÉCURITÉ: le `arith_offset` intrinsèque n'a pas de prérequis pour être appelé.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Renvoie `None` si le pointeur est nul, ou renvoie une référence unique à la valeur encapsulée dans `Some`.Si la valeur n'est peut-être pas initialisée, [`as_uninit_mut`] doit être utilisé à la place.
    ///
    /// Pour la contrepartie partagée, voir [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Lors de l'appel de cette méthode, vous devez vous assurer que *soit* le pointeur est NULL *soit* toutes les conditions suivantes sont vraies:
    ///
    /// * Le pointeur doit être correctement aligné.
    ///
    /// * Il doit s'agir de "dereferencable" au sens défini dans [the module documentation].
    ///
    /// * Le pointeur doit pointer vers une instance initialisée de `T`.
    ///
    /// * Vous devez appliquer les règles d'alias de Rust, car la durée de vie renvoyée `'a` est choisie arbitrairement et ne reflète pas nécessairement la durée de vie réelle des données.
    ///   En particulier, pendant la durée de cette durée de vie, la mémoire vers laquelle pointe le pointeur ne doit pas être accédée (lue ou écrite) par un autre pointeur.
    ///
    /// Cela s'applique même si le résultat de cette méthode n'est pas utilisé!
    /// (La partie concernant l'initialisation n'est pas encore entièrement décidée, mais tant qu'elle ne le sera pas, la seule approche sûre consiste à s'assurer qu'ils sont effectivement initialisés.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Il imprimera: "[4, 2, 3]".
    /// ```
    ///
    /// # Version non vérifiée
    ///
    /// Si vous êtes sûr que le pointeur ne peut jamais être nul et que vous recherchez une sorte de `as_mut_unchecked` qui renvoie le `&mut T` au lieu de `Option<&mut T>`, sachez que vous pouvez déréférencer le pointeur directement.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Il imprimera: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // SÉCURITÉ: l'appelant doit garantir que `self` est valide pour
        // une référence mutable si elle n'est pas nulle.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Renvoie `None` si le pointeur est nul, ou renvoie une référence unique à la valeur encapsulée dans `Some`.
    /// Contrairement à [`as_mut`], cela ne nécessite pas d'initialisation de la valeur.
    ///
    /// Pour la contrepartie partagée, voir [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Lors de l'appel de cette méthode, vous devez vous assurer que *soit* le pointeur est NULL *soit* toutes les conditions suivantes sont vraies:
    ///
    /// * Le pointeur doit être correctement aligné.
    ///
    /// * Il doit s'agir de "dereferencable" au sens défini dans [the module documentation].
    ///
    /// * Vous devez appliquer les règles d'alias de Rust, car la durée de vie renvoyée `'a` est choisie arbitrairement et ne reflète pas nécessairement la durée de vie réelle des données.
    ///
    ///   En particulier, pendant la durée de cette durée de vie, la mémoire vers laquelle pointe le pointeur ne doit pas être accédée (lue ou écrite) par un autre pointeur.
    ///
    /// Cela s'applique même si le résultat de cette méthode n'est pas utilisé!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // SÉCURITÉ: l'appelant doit garantir que `self` répond à toutes les
        // exigences pour une référence.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Renvoie si deux pointeurs sont garantis égaux.
    ///
    /// Au moment de l'exécution, cette fonction se comporte comme `self == other`.
    /// Cependant, dans certains contextes (par exemple, l'évaluation au moment de la compilation), il n'est pas toujours possible de déterminer l'égalité de deux pointeurs, de sorte que cette fonction peut renvoyer par erreur `false` pour des pointeurs qui s'avéreront plus tard égaux.
    ///
    /// Mais quand il renvoie `true`, les pointeurs sont garantis égaux.
    ///
    /// Cette fonction est le miroir de [`guaranteed_ne`], mais pas son inverse.Il existe des comparaisons de pointeurs pour lesquelles les deux fonctions renvoient `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// La valeur de retour peut changer en fonction de la version du compilateur et le code non sécurisé peut ne pas s'appuyer sur le résultat de cette fonction pour la solidité.
    /// Il est suggéré de n'utiliser cette fonction que pour les optimisations de performances où des valeurs de retour `false` erronées par cette fonction n'affectent pas le résultat, mais uniquement les performances.
    /// Les conséquences de l'utilisation de cette méthode pour que le code d'exécution et de compilation se comportent différemment n'ont pas été explorées.
    /// Cette méthode ne doit pas être utilisée pour introduire de telles différences, et elle ne doit pas non plus être stabilisée avant que nous ayons une meilleure compréhension de cette question.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Renvoie si deux pointeurs sont garantis inégaux.
    ///
    /// Au moment de l'exécution, cette fonction se comporte comme `self != other`.
    /// Cependant, dans certains contextes (par exemple, l'évaluation au moment de la compilation), il n'est pas toujours possible de déterminer l'inégalité de deux pointeurs, donc cette fonction peut renvoyer par erreur `false` pour des pointeurs qui s'avéreront plus tard être inégaux.
    ///
    /// Mais quand il renvoie `true`, les pointeurs sont garantis inégaux.
    ///
    /// Cette fonction est le miroir de [`guaranteed_eq`], mais pas son inverse.Il existe des comparaisons de pointeurs pour lesquelles les deux fonctions renvoient `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// La valeur de retour peut changer en fonction de la version du compilateur et le code non sécurisé peut ne pas s'appuyer sur le résultat de cette fonction pour la solidité.
    /// Il est suggéré de n'utiliser cette fonction que pour les optimisations de performances où des valeurs de retour `false` erronées par cette fonction n'affectent pas le résultat, mais uniquement les performances.
    /// Les conséquences de l'utilisation de cette méthode pour que le code d'exécution et de compilation se comportent différemment n'ont pas été explorées.
    /// Cette méthode ne doit pas être utilisée pour introduire de telles différences, et elle ne doit pas non plus être stabilisée avant que nous ayons une meilleure compréhension de cette question.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Calcule la distance entre deux pointeurs.La valeur renvoyée est en unités de T: la distance en octets est divisée par `mem::size_of::<T>()`.
    ///
    /// Cette fonction est l'inverse de [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Si l'une des conditions suivantes n'est pas respectée, le résultat est un comportement indéfini:
    ///
    /// * Le pointeur de départ et l'autre doivent être soit dans les limites, soit un octet après la fin du même objet alloué.
    /// Notez que dans Rust, chaque variable (stack-allocated) est considérée comme un objet alloué distinct.
    ///
    /// * Les deux pointeurs doivent être *dérivés* d'un pointeur vers le même objet.
    ///   (Voir ci-dessous pour un exemple.)
    ///
    /// * La distance entre les pointeurs, en octets, doit être un multiple exact de la taille de `T`.
    ///
    /// * La distance entre les pointeurs,**en octets**, ne peut pas dépasser un `isize`.
    ///
    /// * La distance étant dans les limites ne peut pas dépendre de "wrapping around" l'espace d'adressage.
    ///
    /// Les types Rust ne sont jamais plus grands que les allocations `isize::MAX` et Rust ne se déplacent jamais autour de l'espace d'adressage, donc deux pointeurs dans une certaine valeur de tout type Rust `T` satisferont toujours les deux dernières conditions.
    ///
    /// La bibliothèque standard garantit également généralement que les allocations n'atteignent jamais une taille où un décalage est un problème.
    /// Par exemple, `Vec` et `Box` garantissent qu'ils n'allouent jamais plus de `isize::MAX` octets, donc `ptr_into_vec.offset_from(vec.as_ptr())` satisfait toujours les deux dernières conditions.
    ///
    /// La plupart des plates-formes ne peuvent même pas construire une allocation aussi importante.
    /// Par exemple, aucune plate-forme 64 bits connue ne peut jamais servir une demande de 2 <sup>63</sup> octets en raison de limitations de la table de pages ou de la division de l'espace d'adressage.
    /// Cependant, certaines plates-formes 32 bits et 16 bits peuvent répondre avec succès à une demande de plus de `isize::MAX` octets avec des éléments tels que l'extension d'adresse physique.
    /// En tant que tel, la mémoire acquise directement à partir des allocateurs ou des fichiers mappés en mémoire *peut* être trop volumineuse pour être gérée avec cette fonction.
    /// (Notez que [`offset`] et [`add`] ont également une limitation similaire et ne peuvent donc pas non plus être utilisés sur des allocations aussi importantes.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Cette fonction panics si `T` est un ("ZST") de type zéro.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Utilisation incorrecte*:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Faites de ptr2_other un "alias" de ptr2, mais dérivé de ptr1.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Puisque ptr2_other et ptr2 sont dérivés de pointeurs vers des objets différents, le calcul de leur décalage est un comportement indéfini, même s'ils pointent vers la même adresse!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Comportement indéfini
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `offset_from`.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Calcule le décalage à partir d'un pointeur (commodité pour `.offset(count as isize)`).
    ///
    /// `count` est en unités de T;par exemple, un `count` de 3 représente un décalage de pointeur de `3 * size_of::<T>()` octets.
    ///
    /// # Safety
    ///
    /// Si l'une des conditions suivantes n'est pas respectée, le résultat est un comportement indéfini:
    ///
    /// * Le pointeur de départ et le pointeur résultant doivent être soit dans les limites, soit un octet après la fin du même objet alloué.
    /// Notez que dans Rust, chaque variable (stack-allocated) est considérée comme un objet alloué distinct.
    ///
    /// * Le décalage calculé,**en octets**, ne peut pas dépasser un `isize`.
    ///
    /// * Le décalage étant dans les limites ne peut pas dépendre de "wrapping around" l'espace d'adressage.Autrement dit, la somme de précision infinie doit tenir dans un `usize`.
    ///
    /// Le compilateur et la bibliothèque standard essaient généralement de s'assurer que les allocations n'atteignent jamais une taille où un décalage est un problème.
    /// Par exemple, `Vec` et `Box` s'assurent qu'ils n'allouent jamais plus de `isize::MAX` octets, donc `vec.as_ptr().add(vec.len())` est toujours sûr.
    ///
    /// La plupart des plates-formes ne peuvent fondamentalement même pas construire une telle allocation.
    /// Par exemple, aucune plate-forme 64 bits connue ne peut jamais servir une demande de 2 <sup>63</sup> octets en raison de limitations de la table de pages ou de la division de l'espace d'adressage.
    /// Cependant, certaines plates-formes 32 bits et 16 bits peuvent répondre avec succès à une demande de plus de `isize::MAX` octets avec des éléments tels que l'extension d'adresse physique.
    ///
    /// En tant que tel, la mémoire acquise directement à partir des allocateurs ou des fichiers mappés en mémoire *peut* être trop volumineuse pour être gérée avec cette fonction.
    ///
    /// Pensez à utiliser [`wrapping_add`] à la place si ces contraintes sont difficiles à satisfaire.
    /// Le seul avantage de cette méthode est qu'elle permet des optimisations plus agressives du compilateur.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Calcule le décalage à partir d'un pointeur (commodité pour `.offset ((compter comme isize).wrapping_neg())`).
    ///
    /// `count` est en unités de T;par exemple, un `count` de 3 représente un décalage de pointeur de `3 * size_of::<T>()` octets.
    ///
    /// # Safety
    ///
    /// Si l'une des conditions suivantes n'est pas respectée, le résultat est un comportement indéfini:
    ///
    /// * Le pointeur de départ et le pointeur résultant doivent être soit dans les limites, soit un octet après la fin du même objet alloué.
    /// Notez que dans Rust, chaque variable (stack-allocated) est considérée comme un objet alloué distinct.
    ///
    /// * Le décalage calculé ne peut pas dépasser `isize::MAX`**octets**.
    ///
    /// * Le décalage étant dans les limites ne peut pas dépendre de "wrapping around" l'espace d'adressage.Autrement dit, la somme de précision infinie doit tenir dans une taille d'utilisation.
    ///
    /// Le compilateur et la bibliothèque standard essaient généralement de s'assurer que les allocations n'atteignent jamais une taille où un décalage est un problème.
    /// Par exemple, `Vec` et `Box` s'assurent qu'ils n'allouent jamais plus de `isize::MAX` octets, donc `vec.as_ptr().add(vec.len()).sub(vec.len())` est toujours sûr.
    ///
    /// La plupart des plates-formes ne peuvent fondamentalement même pas construire une telle allocation.
    /// Par exemple, aucune plate-forme 64 bits connue ne peut jamais servir une demande de 2 <sup>63</sup> octets en raison de limitations de la table de pages ou de la division de l'espace d'adressage.
    /// Cependant, certaines plates-formes 32 bits et 16 bits peuvent répondre avec succès à une demande de plus de `isize::MAX` octets avec des éléments tels que l'extension d'adresse physique.
    ///
    /// En tant que tel, la mémoire acquise directement à partir des allocateurs ou des fichiers mappés en mémoire *peut* être trop volumineuse pour être gérée avec cette fonction.
    ///
    /// Pensez à utiliser [`wrapping_sub`] à la place si ces contraintes sont difficiles à satisfaire.
    /// Le seul avantage de cette méthode est qu'elle permet des optimisations plus agressives du compilateur.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Calcule le décalage à partir d'un pointeur à l'aide de l'arithmétique d'encapsulation.
    /// (commodité pour `.wrapping_offset(count as isize)`)
    ///
    /// `count` est en unités de T;par exemple, un `count` de 3 représente un décalage de pointeur de `3 * size_of::<T>()` octets.
    ///
    /// # Safety
    ///
    /// Cette opération elle-même est toujours sûre, mais l'utilisation du pointeur résultant ne l'est pas.
    ///
    /// Le pointeur résultant reste attaché au même objet alloué vers lequel pointe `self`.
    /// Il ne peut *pas* être utilisé pour accéder à un objet alloué différent.Notez que dans Rust, chaque variable (stack-allocated) est considérée comme un objet alloué distinct.
    ///
    /// En d'autres termes, `let z = x.wrapping_add((y as usize) - (x as usize))` ne rend *pas*`z` identique à `y` même si nous supposons que `T` a la taille `1` et qu'il n'y a pas de débordement: `z` est toujours attaché à l'objet auquel `x` est attaché, et le déréférencement est un comportement indéfini sauf si `x` et `y` pointe vers le même objet alloué.
    ///
    /// Par rapport à [`add`], cette méthode retarde fondamentalement l'exigence de rester dans le même objet alloué: [`add`] est un comportement indéfini immédiat lors du franchissement des limites d'objet;`wrapping_add` produit un pointeur mais conduit toujours à un comportement indéfini si un pointeur est déréférencé lorsqu'il est hors des limites de l'objet auquel il est attaché.
    /// [`add`] peut être optimisé mieux et est donc préférable dans le code sensible aux performances.
    ///
    /// La vérification différée ne prend en compte que la valeur du pointeur qui a été déréférencée, et non les valeurs intermédiaires utilisées lors du calcul du résultat final.
    /// Par exemple, `x.wrapping_add(o).wrapping_sub(o)` est toujours le même que `x`.En d'autres termes, il est permis de quitter l'objet alloué, puis de le saisir à nouveau plus tard.
    ///
    /// Si vous devez traverser les limites des objets, transtypez le pointeur en entier et effectuez l'arithmétique à cet endroit.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// // Itérer à l'aide d'un pointeur brut par incréments de deux éléments
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Cette boucle imprime "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Calcule le décalage à partir d'un pointeur à l'aide de l'arithmétique d'encapsulation.
    /// (commodité pour `.wrapping_offset ((count as isize).wrapping_neg())`)
    ///
    /// `count` est en unités de T;par exemple, un `count` de 3 représente un décalage de pointeur de `3 * size_of::<T>()` octets.
    ///
    /// # Safety
    ///
    /// Cette opération elle-même est toujours sûre, mais l'utilisation du pointeur résultant ne l'est pas.
    ///
    /// Le pointeur résultant reste attaché au même objet alloué vers lequel pointe `self`.
    /// Il ne peut *pas* être utilisé pour accéder à un objet alloué différent.Notez que dans Rust, chaque variable (stack-allocated) est considérée comme un objet alloué distinct.
    ///
    /// En d'autres termes, `let z = x.wrapping_sub((x as usize) - (y as usize))` ne rend *pas*`z` identique à `y` même si nous supposons que `T` a la taille `1` et qu'il n'y a pas de débordement: `z` est toujours attaché à l'objet auquel `x` est attaché, et le déréférencement est un comportement indéfini sauf si `x` et `y` pointe vers le même objet alloué.
    ///
    /// Par rapport à [`sub`], cette méthode retarde fondamentalement l'exigence de rester dans le même objet alloué: [`sub`] est un comportement indéfini immédiat lors du franchissement des limites d'objet;`wrapping_sub` produit un pointeur mais conduit toujours à un comportement indéfini si un pointeur est déréférencé lorsqu'il est hors des limites de l'objet auquel il est attaché.
    /// [`sub`] peut être optimisé mieux et est donc préférable dans le code sensible aux performances.
    ///
    /// La vérification différée ne prend en compte que la valeur du pointeur qui a été déréférencée, et non les valeurs intermédiaires utilisées lors du calcul du résultat final.
    /// Par exemple, `x.wrapping_add(o).wrapping_sub(o)` est toujours le même que `x`.En d'autres termes, il est permis de quitter l'objet alloué, puis de le saisir à nouveau plus tard.
    ///
    /// Si vous devez traverser les limites des objets, transtypez le pointeur en entier et effectuez l'arithmétique à cet endroit.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// // Itérer à l'aide d'un pointeur brut par incréments de deux éléments (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Cette boucle imprime "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Définit la valeur du pointeur sur `ptr`.
    ///
    /// Dans le cas où `self` est un pointeur (fat) vers un type non dimensionné, cette opération n'affectera que la partie pointeur, tandis que pour les pointeurs (thin) vers des types dimensionnés, cela a le même effet qu'une simple affectation.
    ///
    /// Le pointeur résultant aura la provenance de `val`, c'est-à-dire que pour un pointeur fat, cette opération est sémantiquement la même que la création d'un nouveau pointeur fat avec la valeur du pointeur de données de `val` mais les métadonnées de `self`.
    ///
    ///
    /// # Examples
    ///
    /// Cette fonction est principalement utile pour permettre l'arithmétique des pointeurs octets sur les pointeurs potentiellement gras:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // imprimera "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // SÉCURITÉ: dans le cas d'un pointeur fin, cette opération est identique
        // à une simple mission.
        // Dans le cas d'un pointeur gras, avec l'implémentation actuelle de la disposition du pointeur gras, le premier champ d'un tel pointeur est toujours le pointeur de données, qui est également affecté.
        //
        unsafe { *thin = val };
        self
    }

    /// Lit la valeur de `self` sans la déplacer.
    /// Cela laisse la mémoire de `self` inchangée.
    ///
    /// Voir [`ptr::read`] pour des problèmes de sécurité et des exemples.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du ``.
        unsafe { read(self) }
    }

    /// Effectue une lecture volatile de la valeur de `self` sans la déplacer.Cela laisse la mémoire de `self` inchangée.
    ///
    /// Les opérations volatiles sont destinées à agir sur la mémoire I/O et sont garanties de ne pas être élidées ou réorganisées par le compilateur sur d'autres opérations volatiles.
    ///
    ///
    /// Voir [`ptr::read_volatile`] pour des problèmes de sécurité et des exemples.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Lit la valeur de `self` sans la déplacer.
    /// Cela laisse la mémoire de `self` inchangée.
    ///
    /// Contrairement à `read`, le pointeur peut ne pas être aligné.
    ///
    /// Voir [`ptr::read_unaligned`] pour des problèmes de sécurité et des exemples.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Copie les octets `count * size_of<T>` de `self` vers `dest`.
    /// La source et la destination peuvent se chevaucher.
    ///
    /// NOTE: ceci a le *même* ordre des arguments que [`ptr::copy`].
    ///
    /// Voir [`ptr::copy`] pour des problèmes de sécurité et des exemples.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Copie les octets `count * size_of<T>` de `self` vers `dest`.
    /// La source et la destination ne peuvent *pas* se chevaucher.
    ///
    /// NOTE: ceci a le *même* ordre des arguments que [`ptr::copy_nonoverlapping`].
    ///
    /// Voir [`ptr::copy_nonoverlapping`] pour des problèmes de sécurité et des exemples.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Copie les octets `count * size_of<T>` de `src` vers `self`.
    /// La source et la destination peuvent se chevaucher.
    ///
    /// NOTE: ceci a l'ordre d'argument *opposé* de [`ptr::copy`].
    ///
    /// Voir [`ptr::copy`] pour des problèmes de sécurité et des exemples.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `copy`.
        unsafe { copy(src, self, count) }
    }

    /// Copie les octets `count * size_of<T>` de `src` vers `self`.
    /// La source et la destination ne peuvent *pas* se chevaucher.
    ///
    /// NOTE: ceci a l'ordre d'argument *opposé* de [`ptr::copy_nonoverlapping`].
    ///
    /// Voir [`ptr::copy_nonoverlapping`] pour des problèmes de sécurité et des exemples.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Exécute le destructeur (le cas échéant) de la valeur pointée.
    ///
    /// Voir [`ptr::drop_in_place`] pour des problèmes de sécurité et des exemples.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `drop_in_place`.
        unsafe { drop_in_place(self) }
    }

    /// Remplace un emplacement mémoire par la valeur donnée sans lire ni supprimer l'ancienne valeur.
    ///
    ///
    /// Voir [`ptr::write`] pour des problèmes de sécurité et des exemples.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `write`.
        unsafe { write(self, val) }
    }

    /// Appelle memset sur le pointeur spécifié, définissant `count * size_of::<T>()` octets de mémoire commençant à `self` sur `val`.
    ///
    ///
    /// Voir [`ptr::write_bytes`] pour des problèmes de sécurité et des exemples.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `write_bytes`.
        unsafe { write_bytes(self, val, count) }
    }

    /// Effectue une écriture volatile d'un emplacement mémoire avec la valeur donnée sans lire ni supprimer l'ancienne valeur.
    ///
    /// Les opérations volatiles sont destinées à agir sur la mémoire I/O et sont garanties de ne pas être élidées ou réorganisées par le compilateur sur d'autres opérations volatiles.
    ///
    ///
    /// Voir [`ptr::write_volatile`] pour des problèmes de sécurité et des exemples.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `write_volatile`.
        unsafe { write_volatile(self, val) }
    }

    /// Remplace un emplacement mémoire par la valeur donnée sans lire ni supprimer l'ancienne valeur.
    ///
    ///
    /// Contrairement à `write`, le pointeur peut ne pas être aligné.
    ///
    /// Voir [`ptr::write_unaligned`] pour des problèmes de sécurité et des exemples.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `write_unaligned`.
        unsafe { write_unaligned(self, val) }
    }

    /// Remplace la valeur à `self` par `src`, en renvoyant l'ancienne valeur, sans la supprimer non plus.
    ///
    ///
    /// Voir [`ptr::replace`] pour des problèmes de sécurité et des exemples.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `replace`.
        unsafe { replace(self, src) }
    }

    /// Échange les valeurs à deux emplacements mutables du même type, sans désinitialisation non plus.
    /// Ils peuvent se chevaucher, contrairement au `mem::swap` qui est par ailleurs équivalent.
    ///
    /// Voir [`ptr::swap`] pour des problèmes de sécurité et des exemples.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `swap`.
        unsafe { swap(self, with) }
    }

    /// Calcule le décalage qui doit être appliqué au pointeur pour l'aligner sur `align`.
    ///
    /// S'il n'est pas possible d'aligner le pointeur, l'implémentation renvoie `usize::MAX`.
    /// Il est permis pour l'implémentation de renvoyer *toujours*`usize::MAX`.
    /// Seules les performances de votre algorithme peuvent dépendre de l'obtention d'un décalage utilisable ici, pas de son exactitude.
    ///
    /// Le décalage est exprimé en nombre d'éléments `T` et non en octets.La valeur renvoyée peut être utilisée avec la méthode `wrapping_add`.
    ///
    /// Il n'y a aucune garantie que la compensation du pointeur ne déborde pas ou n'aille pas au-delà de l'allocation vers laquelle pointe le pointeur.
    ///
    /// Il appartient à l'appelant de s'assurer que l'offset renvoyé est correct dans tous les termes autres que l'alignement.
    ///
    /// # Panics
    ///
    /// La fonction panics si `align` n'est pas une puissance de deux.
    ///
    /// # Examples
    ///
    /// Accès au `u8` adjacent en tant que `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // alors que le pointeur peut être aligné via `offset`, il pointerait en dehors de l'allocation
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // SÉCURITÉ: `align` a été vérifié pour être une puissance de 2 ci-dessus
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Renvoie la longueur d'une tranche brute.
    ///
    /// La valeur renvoyée est le nombre de **éléments**, pas le nombre d'octets.
    ///
    /// Cette fonction est sûre, même lorsque la tranche brute ne peut pas être convertie en référence de tranche car le pointeur est nul ou non aligné.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // SÉCURITÉ: c'est sûr car `*const [T]` et `FatPtr<T>` ont la même disposition.
            // Seul `std` peut offrir cette garantie.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Renvoie un pointeur brut vers le tampon de la tranche.
    ///
    /// Cela équivaut à convertir `self` en `*mut T`, mais plus sûr de type.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Renvoie un pointeur brut vers un élément ou une sous-tranche, sans effectuer de vérification des limites.
    ///
    /// L'appel de cette méthode avec un index hors limites ou lorsque `self` n'est pas déréférencable est *[comportement indéfini]* même si le pointeur résultant n'est pas utilisé.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // SÉCURITÉ: l'appelant s'assure que `self` est déréférencable et `index` dans les limites.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Renvoie `None` si le pointeur est nul, ou renvoie une tranche partagée à la valeur encapsulée dans `Some`.
    /// Contrairement à [`as_ref`], cela ne nécessite pas d'initialisation de la valeur.
    ///
    /// Pour la contrepartie mutable, voir [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Lors de l'appel de cette méthode, vous devez vous assurer que *soit* le pointeur est NULL *soit* toutes les conditions suivantes sont vraies:
    ///
    /// * Le pointeur doit être [valid] pour les lectures de nombreux octets `ptr.len() * mem::size_of::<T>()` et il doit être correctement aligné.Cela signifie notamment:
    ///
    ///     * Toute la plage de mémoire de cette tranche doit être contenue dans un seul objet alloué!
    ///       Les tranches ne peuvent jamais s'étendre sur plusieurs objets alloués.
    ///
    ///     * Le pointeur doit être aligné même pour les tranches de longueur nulle.
    ///     L'une des raisons à cela est que les optimisations de mise en page enum peuvent s'appuyer sur des références (y compris des tranches de toute longueur) alignées et non nulles pour les distinguer des autres données.
    ///
    ///     Vous pouvez obtenir un pointeur utilisable en tant que `data` pour les tranches de longueur nulle à l'aide de [`NonNull::dangling()`].
    ///
    /// * La taille totale `ptr.len() * mem::size_of::<T>()` de la tranche ne doit pas être supérieure à `isize::MAX`.
    ///   Consultez la documentation de sécurité du [`pointer::offset`].
    ///
    /// * Vous devez appliquer les règles d'alias de Rust, car la durée de vie renvoyée `'a` est choisie arbitrairement et ne reflète pas nécessairement la durée de vie réelle des données.
    ///   En particulier, pendant la durée de cette durée de vie, la mémoire vers laquelle pointe le pointeur ne doit pas être mutée (sauf à l'intérieur de `UnsafeCell`).
    ///
    /// Cela s'applique même si le résultat de cette méthode n'est pas utilisé!
    ///
    /// Voir également [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Renvoie `None` si le pointeur est nul, ou renvoie une tranche unique à la valeur encapsulée dans `Some`.
    /// Contrairement à [`as_mut`], cela ne nécessite pas d'initialisation de la valeur.
    ///
    /// Pour la contrepartie partagée, voir [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Lors de l'appel de cette méthode, vous devez vous assurer que *soit* le pointeur est NULL *soit* toutes les conditions suivantes sont vraies:
    ///
    /// * Le pointeur doit être [valid] pour les lectures et écritures pour `ptr.len() * mem::size_of::<T>()` de nombreux octets, et il doit être correctement aligné.Cela signifie notamment:
    ///
    ///     * Toute la plage de mémoire de cette tranche doit être contenue dans un seul objet alloué!
    ///       Les tranches ne peuvent jamais s'étendre sur plusieurs objets alloués.
    ///
    ///     * Le pointeur doit être aligné même pour les tranches de longueur nulle.
    ///     L'une des raisons à cela est que les optimisations de mise en page enum peuvent s'appuyer sur des références (y compris des tranches de toute longueur) alignées et non nulles pour les distinguer des autres données.
    ///
    ///     Vous pouvez obtenir un pointeur utilisable en tant que `data` pour les tranches de longueur nulle à l'aide de [`NonNull::dangling()`].
    ///
    /// * La taille totale `ptr.len() * mem::size_of::<T>()` de la tranche ne doit pas être supérieure à `isize::MAX`.
    ///   Consultez la documentation de sécurité du [`pointer::offset`].
    ///
    /// * Vous devez appliquer les règles d'alias de Rust, car la durée de vie renvoyée `'a` est choisie arbitrairement et ne reflète pas nécessairement la durée de vie réelle des données.
    ///   En particulier, pendant la durée de cette durée de vie, la mémoire vers laquelle pointe le pointeur ne doit pas être accédée (lue ou écrite) par un autre pointeur.
    ///
    /// Cela s'applique même si le résultat de cette méthode n'est pas utilisé!
    ///
    /// Voir également [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `as_uninit_slice_mut`.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Égalité pour les pointeurs
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}