//! Ce module implémente le `Any` trait, qui permet le typage dynamique de tout type `'static` via la réflexion d'exécution.
//!
//! `Any` lui-même peut être utilisé pour obtenir un `TypeId`, et a plus de fonctionnalités lorsqu'il est utilisé comme un objet trait.
//! En tant que `&dyn Any` (un objet trait emprunté), il dispose des méthodes `is` et `downcast_ref`, pour tester si la valeur contenue est d'un type donné et pour obtenir une référence à la valeur interne en tant que type.
//! Comme `&mut dyn Any`, il existe également la méthode `downcast_mut`, pour obtenir une référence mutable à la valeur interne.
//! `Box<dyn Any>` ajoute la méthode `downcast`, qui tente de se convertir en `Box<T>`.
//! Consultez la documentation du [`Box`] pour plus de détails.
//!
//! Notez que `&dyn Any` se limite à tester si une valeur est d'un type concret spécifié et ne peut pas être utilisé pour tester si un type implémente un trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Pointeurs intelligents et `dyn Any`
//!
//! Un comportement à garder à l'esprit lors de l'utilisation de `Any` en tant qu'objet trait, en particulier avec des types comme `Box<dyn Any>` ou `Arc<dyn Any>`, est que le simple fait d'appeler `.type_id()` sur la valeur produira le `TypeId` du *conteneur*, pas l'objet trait sous-jacent.
//!
//! Cela peut être évité en convertissant le pointeur intelligent en un `&dyn Any` à la place, qui renverra le `TypeId` de l'objet.
//! Par example:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Vous êtes plus susceptible de vouloir ceci:
//! let actual_id = (&*boxed).type_id();
//! // ... que ça:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Prenons une situation où nous voulons déconnecter une valeur transmise à une fonction.
//! Nous connaissons la valeur sur laquelle nous travaillons implémente Debug, mais nous ne connaissons pas son type concret.Nous voulons donner un traitement spécial à certains types: dans ce cas, imprimer la longueur des valeurs String avant leur valeur.
//! Nous ne connaissons pas le type concret de notre valeur au moment de la compilation, nous devons donc utiliser la réflexion d'exécution à la place.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Fonction de journalisation pour tout type qui implémente Debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Essayez de convertir notre valeur en `String`.
//!     // En cas de succès, nous voulons afficher la longueur de la chaîne ainsi que sa valeur.
//!     // Sinon, c'est un type différent: il suffit de l'imprimer sans ornements.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Cette fonction souhaite déconnecter son paramètre avant de travailler avec elle.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... faire un autre travail
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Tout trait
///////////////////////////////////////////////////////////////////////////////

/// Un trait pour émuler le typage dynamique.
///
/// La plupart des types implémentent `Any`.Cependant, tout type qui contient une référence non "statique" ne le fait pas.
/// Voir le [module-level documentation][mod] pour plus de détails.
///
/// [mod]: crate::any
// Ce trait n'est pas dangereux, bien que nous nous fions aux spécificités de sa seule fonction `type_id` impl en code unsafe (par exemple, `downcast`).Normalement, ce serait un problème, mais comme la seule implémentation de `Any` est une implémentation globale, aucun autre code ne peut implémenter `Any`.
//
// Nous pourrions plausiblement rendre ce trait dangereux-cela ne causerait pas de casse, puisque nous contrôlons toutes les implémentations-mais nous choisissons de ne pas le faire car ce n'est pas vraiment nécessaire et peut dérouter les utilisateurs sur la distinction entre traits et méthodes dangereuses (c'est-à-dire, `type_id` serait toujours sûr d'appeler, mais nous voudrions probablement l'indiquer comme tel dans la documentation).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Obtient le `TypeId` de `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Méthodes d'extension pour tous les objets trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Assurez-vous que le résultat, par exemple, de la jonction d'un fil peut être imprimé et donc utilisé avec `unwrap`.
// Peut éventuellement ne plus être nécessaire si la répartition fonctionne avec l'upcasting.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Renvoie `true` si le type encadré est le même que `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Obtenez `TypeId` du type avec lequel cette fonction est instanciée.
        let t = TypeId::of::<T>();

        // Obtenez `TypeId` du type dans l'objet trait (`self`).
        let concrete = self.type_id();

        // Comparez les deux `TypeId`s sur l'égalité.
        t == concrete
    }

    /// Renvoie une référence à la valeur encadrée si elle est de type `T`, ou `None` si ce n'est pas le cas.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // SÉCURITÉ: il suffit de vérifier si nous pointons vers le bon type, et nous pouvons compter sur
            // qui vérifient la sécurité de la mémoire parce que nous avons implémenté Any pour tous les types;aucun autre impls ne peut exister car ils seraient en conflit avec notre impl.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Renvoie une référence mutable à la valeur encadrée si elle est de type `T`, ou `None` si ce n'est pas le cas.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // SÉCURITÉ: il suffit de vérifier si nous pointons vers le bon type, et nous pouvons compter sur
            // qui vérifient la sécurité de la mémoire parce que nous avons implémenté Any pour tous les types;aucun autre impls ne peut exister car ils seraient en conflit avec notre impl.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Renvoie à la méthode définie sur le type `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Renvoie à la méthode définie sur le type `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Renvoie à la méthode définie sur le type `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Renvoie à la méthode définie sur le type `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Renvoie à la méthode définie sur le type `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Renvoie à la méthode définie sur le type `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID et ses méthodes
///////////////////////////////////////////////////////////////////////////////

/// Un `TypeId` représente un identifiant global unique pour un type.
///
/// Chaque `TypeId` est un objet opaque qui ne permet pas l'inspection de ce qu'il y a à l'intérieur mais permet des opérations de base telles que le clonage, la comparaison, l'impression et l'affichage.
///
///
/// Un `TypeId` n'est actuellement disponible que pour les types qui sont attribués à `'static`, mais cette limitation peut être supprimée dans le future.
///
/// Alors que `TypeId` implémente `Hash`, `PartialOrd` et `Ord`, il convient de noter que les hachages et l'ordre varieront entre les versions de Rust.
/// Méfiez-vous de vous fier à eux à l'intérieur de votre code!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Renvoie le `TypeId` du type avec lequel cette fonction générique a été instanciée.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Renvoie le nom d'un type sous forme de tranche de chaîne.
///
/// # Note
///
/// Ceci est destiné à un usage diagnostique.
/// Le contenu et le format exacts de la chaîne renvoyée ne sont pas spécifiés, sauf s'il s'agit d'une description au mieux du type.
/// Par exemple, parmi les chaînes que `type_name::<Option<String>>()` peut renvoyer, il y a `"Option<String>"` et `"std::option::Option<std::string::String>"`.
///
///
/// La chaîne renvoyée ne doit pas être considérée comme un identifiant unique d'un type car plusieurs types peuvent mapper vers le même nom de type.
/// De même, il n'y a aucune garantie que toutes les parties d'un type apparaîtront dans la chaîne retournée: par exemple, les spécificateurs de durée de vie ne sont actuellement pas inclus.
/// En outre, la sortie peut changer entre les versions du compilateur.
///
/// L'implémentation actuelle utilise la même infrastructure que les diagnostics du compilateur et les informations de débogage, mais cela n'est pas garanti.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Renvoie le nom du type de la valeur pointée sous forme de tranche de chaîne.
/// Ceci est identique à `type_name::<T>()`, mais peut être utilisé lorsque le type d'une variable n'est pas facilement disponible.
///
/// # Note
///
/// Ceci est destiné à un usage diagnostique.Le contenu exact et le format de la chaîne ne sont pas spécifiés, sauf s'il s'agit d'une description au mieux du type.
/// Par exemple, `type_name_of_val::<Option<String>>(None)` peut renvoyer `"Option<String>"` ou `"std::option::Option<std::string::String>"`, mais pas `"foobar"`.
///
/// En outre, la sortie peut changer entre les versions du compilateur.
///
/// Cette fonction ne résout pas les objets trait, ce qui signifie que `type_name_of_val(&7u32 as &dyn Debug)` peut renvoyer `"dyn Debug"`, mais pas `"u32"`.
///
/// Le nom de type ne doit pas être considéré comme un identifiant unique d'un type;
/// plusieurs types peuvent partager le même nom de type.
///
/// L'implémentation actuelle utilise la même infrastructure que les diagnostics du compilateur et les informations de débogage, mais cela n'est pas garanti.
///
/// # Examples
///
/// Imprime les types entier et flottant par défaut.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}