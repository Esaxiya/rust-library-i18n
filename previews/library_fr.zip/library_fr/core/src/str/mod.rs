//! Manipulation des cordes.
//!
//! Pour plus de détails, consultez le module [`std::str`].
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. hors limites
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. begin <=end
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. limite de caractère
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // trouver le personnage
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` doit être inférieur à len et à une limite de caractères
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Renvoie la longueur de `self`.
    ///
    /// Cette longueur est en octets, pas en [`char`] s ou en graphèmes.
    /// En d'autres termes, ce n'est peut-être pas ce qu'un humain considère comme la longueur de la chaîne.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // fantaisie f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Renvoie `true` si `self` a une longueur de zéro octet.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Vérifie que «index»-th octet est le premier octet d'une séquence de points de code UTF-8 ou la fin de la chaîne.
    ///
    ///
    /// Le début et la fin de la chaîne (lorsque `index== self.len()`) sont considérés comme des limites.
    ///
    /// Renvoie `false` si `index` est supérieur à `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // début de `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // deuxième octet de `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // troisième octet de `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 et len sont toujours ok.
        // Testez explicitement 0 afin qu'il puisse optimiser la vérification facilement et ignorer la lecture des données de chaîne pour ce cas.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // C'est un peu magique équivalent à: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Convertit une tranche de chaîne en tranche d'octets.
    /// Pour reconvertir la tranche d'octets en une tranche de chaîne, utilisez la fonction [`from_utf8`].
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // SÉCURITÉ: son constant car nous transmutons deux types avec la même disposition
        unsafe { mem::transmute(self) }
    }

    /// Convertit une tranche de chaîne mutable en une tranche d'octets mutable.
    ///
    /// # Safety
    ///
    /// L'appelant doit s'assurer que le contenu de la tranche est UTF-8 valide avant que l'emprunt ne se termine et que le `str` sous-jacent soit utilisé.
    ///
    ///
    /// Utilisation d'un `str` dont le contenu n'est pas valide UTF-8 est un comportement indéfini.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // SÉCURITÉ: le casting de `&str` à `&[u8]` est sûr depuis `str`
        // a la même disposition que `&[u8]` (seule libstd peut offrir cette garantie).
        // Le déréférencement du pointeur est sûr car il provient d'une référence mutable dont la validité est garantie pour les écritures.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Convertit une tranche de chaîne en pointeur brut.
    ///
    /// Comme les tranches de chaîne sont une tranche d'octets, le pointeur brut pointe vers un [`u8`].
    /// Ce pointeur pointera vers le premier octet de la tranche de chaîne.
    ///
    /// L'appelant doit s'assurer que le pointeur renvoyé n'est jamais écrit dans.
    /// Si vous devez muter le contenu de la tranche de chaîne, utilisez [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Convertit une tranche de chaîne mutable en un pointeur brut.
    ///
    /// Comme les tranches de chaîne sont une tranche d'octets, le pointeur brut pointe vers un [`u8`].
    /// Ce pointeur pointera vers le premier octet de la tranche de chaîne.
    ///
    /// Il est de votre responsabilité de vous assurer que la tranche de chaîne n'est modifiée que de manière à ce qu'elle reste valide UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Renvoie une sous-tranche de `str`.
    ///
    /// C'est l'alternative sans panique à l'indexation du `str`.
    /// Renvoie [`None`] chaque fois qu'une opération d'indexation équivalente serait panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // les indices ne sont pas sur les limites de séquence UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // hors limites
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Renvoie une sous-tranche mutable de `str`.
    ///
    /// C'est l'alternative sans panique à l'indexation du `str`.
    /// Renvoie [`None`] chaque fois qu'une opération d'indexation équivalente serait panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // longueur correcte
    /// assert!(v.get_mut(0..5).is_some());
    /// // hors limites
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Renvoie une sous-tranche non vérifiée de `str`.
    ///
    /// C'est l'alternative non cochée à l'indexation du `str`.
    ///
    /// # Safety
    ///
    /// Les appelants de cette fonction sont responsables de la satisfaction de ces conditions préalables:
    ///
    /// * L'index de départ ne doit pas dépasser l'index de fin;
    /// * Les index doivent être dans les limites de la tranche d'origine;
    /// * Les index doivent se trouver sur les limites de séquence UTF-8.
    ///
    /// À défaut, la tranche de chaîne renvoyée peut faire référence à une mémoire non valide ou violer les invariants communiqués par le type `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `get_unchecked`;
        // la tranche est déréférencable car `self` est une référence sûre.
        // Le pointeur retourné est sûr car les impls de `SliceIndex` doivent garantir qu'il l'est.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Renvoie une sous-tranche mutable et non vérifiée de `str`.
    ///
    /// C'est l'alternative non cochée à l'indexation du `str`.
    ///
    /// # Safety
    ///
    /// Les appelants de cette fonction sont responsables de la satisfaction de ces conditions préalables:
    ///
    /// * L'index de départ ne doit pas dépasser l'index de fin;
    /// * Les index doivent être dans les limites de la tranche d'origine;
    /// * Les index doivent se trouver sur les limites de séquence UTF-8.
    ///
    /// À défaut, la tranche de chaîne renvoyée peut faire référence à une mémoire non valide ou violer les invariants communiqués par le type `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `get_unchecked_mut`;
        // la tranche est déréférencable car `self` est une référence sûre.
        // Le pointeur retourné est sûr car les impls de `SliceIndex` doivent garantir qu'il l'est.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Crée une tranche de chaîne à partir d'une autre tranche de chaîne, en contournant les contrôles de sécurité.
    ///
    /// Ce n'est généralement pas recommandé, à utiliser avec prudence!Pour une alternative sûre, voir [`str`] et [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Cette nouvelle tranche passe de `begin` à `end`, en incluant `begin` mais en excluant `end`.
    ///
    /// Pour obtenir une tranche de chaîne mutable à la place, consultez la méthode [`slice_mut_unchecked`].
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Les appelants de cette fonction sont responsables du respect de trois conditions préalables:
    ///
    /// * `begin` ne doit pas dépasser `end`.
    /// * `begin` et `end` doivent être des positions d'octets dans la tranche de chaîne.
    /// * `begin` et `end` doit se trouver sur les limites de séquence UTF-8.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `get_unchecked`;
        // la tranche est déréférencable car `self` est une référence sûre.
        // Le pointeur retourné est sûr car les impls de `SliceIndex` doivent garantir qu'il l'est.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Crée une tranche de chaîne à partir d'une autre tranche de chaîne, en contournant les contrôles de sécurité.
    /// Ce n'est généralement pas recommandé, à utiliser avec prudence!Pour une alternative sûre, voir [`str`] et [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Cette nouvelle tranche passe de `begin` à `end`, en incluant `begin` mais en excluant `end`.
    ///
    /// Pour obtenir une tranche de chaîne immuable à la place, consultez la méthode [`slice_unchecked`].
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Les appelants de cette fonction sont responsables du respect de trois conditions préalables:
    ///
    /// * `begin` ne doit pas dépasser `end`.
    /// * `begin` et `end` doivent être des positions d'octets dans la tranche de chaîne.
    /// * `begin` et `end` doit se trouver sur les limites de séquence UTF-8.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `get_unchecked_mut`;
        // la tranche est déréférencable car `self` est une référence sûre.
        // Le pointeur retourné est sûr car les impls de `SliceIndex` doivent garantir qu'il l'est.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Divisez une tranche de chaîne en deux à un index.
    ///
    /// L'argument, `mid`, doit être un décalage d'octet par rapport au début de la chaîne.
    /// Il doit également être à la limite d'un point de code UTF-8.
    ///
    /// Les deux tranches renvoyées vont du début de la tranche de chaîne à `mid` et de `mid` à la fin de la tranche de chaîne.
    ///
    /// Pour obtenir des tranches de chaîne mutables à la place, consultez la méthode [`split_at_mut`].
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics si `mid` n'est pas sur une limite de point de code UTF-8, ou s'il est au-delà de la fin du dernier point de code de la tranche de chaîne.
    ///
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary vérifie que l'index est dans [0, .len()]
        if self.is_char_boundary(mid) {
            // SÉCURITÉ: vient de vérifier que `mid` est sur une limite de caractère.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Divisez une tranche de chaîne mutable en deux à un index.
    ///
    /// L'argument, `mid`, doit être un décalage d'octet par rapport au début de la chaîne.
    /// Il doit également être à la limite d'un point de code UTF-8.
    ///
    /// Les deux tranches renvoyées vont du début de la tranche de chaîne à `mid` et de `mid` à la fin de la tranche de chaîne.
    ///
    /// Pour obtenir à la place des tranches de chaîne immuables, consultez la méthode [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics si `mid` n'est pas sur une limite de point de code UTF-8, ou s'il est au-delà de la fin du dernier point de code de la tranche de chaîne.
    ///
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary vérifie que l'index est dans [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // SÉCURITÉ: vient de vérifier que `mid` est sur une limite de caractère.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Renvoie un itérateur sur les [`char`] s d'une tranche de chaîne.
    ///
    /// Comme une tranche de chaîne se compose de UTF-8 valide, nous pouvons parcourir une tranche de chaîne par [`char`].
    /// Cette méthode renvoie un tel itérateur.
    ///
    /// Il est important de se rappeler que [`char`] représente une valeur scalaire Unicode et peut ne pas correspondre à votre idée de ce qu'est un 'character'.
    ///
    /// L'itération sur des grappes de graphèmes peut être ce que vous voulez réellement.
    /// Cette fonctionnalité n'est pas fournie par la bibliothèque standard de Rust, vérifiez plutôt crates.io.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// N'oubliez pas que les [`char`] peuvent ne pas correspondre à votre intuition à propos des caractères:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // pas 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Renvoie un itérateur sur les [`char`] s d'une tranche de chaîne et leurs positions.
    ///
    /// Comme une tranche de chaîne se compose de UTF-8 valide, nous pouvons parcourir une tranche de chaîne par [`char`].
    /// Cette méthode retourne un itérateur de ces deux [`char`] s, ainsi que leurs positions d'octets.
    ///
    /// L'itérateur produit des tuples.La position est la première, le [`char`] est la deuxième.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// N'oubliez pas que les [`char`] peuvent ne pas correspondre à votre intuition à propos des caractères:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // pas (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // notez le 3 ici, le dernier caractère a pris deux octets
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Un itérateur sur les octets d'une tranche de chaîne.
    ///
    /// Comme une tranche de chaîne se compose d'une séquence d'octets, nous pouvons parcourir une chaîne tranche par octet.
    /// Cette méthode renvoie un tel itérateur.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Divise une tranche de chaîne par un espace.
    ///
    /// L'itérateur retourné renverra des tranches de chaîne qui sont des sous-tranches de la tranche de chaîne d'origine, séparées par n'importe quelle quantité d'espaces.
    ///
    ///
    /// 'Whitespace' est défini selon les termes de la propriété de base dérivée Unicode `White_Space`.
    /// Si vous souhaitez uniquement fractionner sur des espaces ASCII, utilisez [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Tous les types d'espaces sont considérés:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Divise une tranche de chaîne par un espace ASCII.
    ///
    /// L'itérateur retourné renverra des tranches de chaîne qui sont des sous-tranches de la tranche de chaîne d'origine, séparées par n'importe quelle quantité d'espaces ASCII.
    ///
    ///
    /// Pour diviser par Unicode `Whitespace` à la place, utilisez [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Tous les types d'espaces ASCII sont considérés:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Un itérateur sur les lignes d'une chaîne, sous forme de tranches de chaîne.
    ///
    /// Les lignes se terminent par une nouvelle ligne (`\n`) ou par un retour chariot avec un saut de ligne (`\r\n`).
    ///
    /// La fin de la dernière ligne est facultative.
    /// Une chaîne qui se termine par une fin de ligne finale renverra les mêmes lignes qu'une chaîne par ailleurs identique sans fin de ligne finale.
    ///
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// La fin de la dernière ligne n'est pas obligatoire:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Un itérateur sur les lignes d'une chaîne.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Renvoie un itérateur de `u16` sur la chaîne codée en UTF-16.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Renvoie `true` si le modèle donné correspond à une sous-tranche de cette tranche de chaîne.
    ///
    /// Renvoie `false` si ce n'est pas le cas.
    ///
    /// Le [pattern] peut être un `&str`, [`char`], une tranche de [`char`] s, ou une fonction ou une fermeture qui détermine si un caractère correspond.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Renvoie `true` si le modèle donné correspond à un préfixe de cette tranche de chaîne.
    ///
    /// Renvoie `false` si ce n'est pas le cas.
    ///
    /// Le [pattern] peut être un `&str`, [`char`], une tranche de [`char`] s, ou une fonction ou une fermeture qui détermine si un caractère correspond.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Renvoie `true` si le modèle donné correspond à un suffixe de cette tranche de chaîne.
    ///
    /// Renvoie `false` si ce n'est pas le cas.
    ///
    /// Le [pattern] peut être un `&str`, [`char`], une tranche de [`char`] s, ou une fonction ou une fermeture qui détermine si un caractère correspond.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Renvoie l'index d'octet du premier caractère de cette tranche de chaîne qui correspond au modèle.
    ///
    /// Renvoie [`None`] si le modèle ne correspond pas.
    ///
    /// Le [pattern] peut être un `&str`, [`char`], une tranche de [`char`] s, ou une fonction ou une fermeture qui détermine si un caractère correspond.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Modèles simples:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Modèles plus complexes utilisant un style et des fermetures sans point:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Ne pas trouver le motif:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Renvoie l'index d'octet du premier caractère de la correspondance la plus à droite du modèle dans cette tranche de chaîne.
    ///
    /// Renvoie [`None`] si le modèle ne correspond pas.
    ///
    /// Le [pattern] peut être un `&str`, [`char`], une tranche de [`char`] s, ou une fonction ou une fermeture qui détermine si un caractère correspond.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Modèles simples:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Modèles plus complexes avec fermetures:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Ne pas trouver le motif:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Un itérateur sur des sous-chaînes de cette tranche de chaîne, séparés par des caractères correspondant à un modèle.
    ///
    /// Le [pattern] peut être un `&str`, [`char`], une tranche de [`char`] s, ou une fonction ou une fermeture qui détermine si un caractère correspond.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportement de l'itérateur
    ///
    /// L'itérateur retourné sera un [`DoubleEndedIterator`] si le modèle autorise une recherche inversée et que la recherche forward/reverse produit les mêmes éléments.
    /// Ceci est vrai, par exemple, pour [`char`], mais pas pour `&str`.
    ///
    /// Si le modèle autorise une recherche inversée mais que ses résultats peuvent différer d'une recherche avant, la méthode [`rsplit`] peut être utilisée.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Modèles simples:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Si le motif est une tranche de caractères, divisez-le à chaque occurrence de l'un des caractères:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Un motif plus complexe, utilisant une fermeture:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Si une chaîne contient plusieurs séparateurs contigus, vous vous retrouverez avec des chaînes vides dans la sortie:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Les séparateurs contigus sont séparés par la chaîne vide.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Les séparateurs au début ou à la fin d'une chaîne sont contigus par des chaînes vides.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Lorsque la chaîne vide est utilisée comme séparateur, elle sépare chaque caractère de la chaîne, ainsi que le début et la fin de la chaîne.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Les séparateurs contigus peuvent conduire à un comportement peut-être surprenant lorsque des espaces sont utilisés comme séparateur.Ce code est correct:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Il vous donne _not_:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Utilisez [`split_whitespace`] pour ce comportement.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Un itérateur sur des sous-chaînes de cette tranche de chaîne, séparés par des caractères correspondant à un modèle.
    /// Diffère de l'itérateur produit par `split` en ce que `split_inclusive` laisse la partie correspondante comme terminateur de la sous-chaîne.
    ///
    ///
    /// Le [pattern] peut être un `&str`, [`char`], une tranche de [`char`] s, ou une fonction ou une fermeture qui détermine si un caractère correspond.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Si le dernier élément de la chaîne correspond, cet élément sera considéré comme le terminateur de la sous-chaîne précédente.
    /// Cette sous-chaîne sera le dernier élément renvoyé par l'itérateur.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Un itérateur sur des sous-chaînes de la tranche de chaîne donnée, séparés par des caractères mis en correspondance par un modèle et renvoyés dans l'ordre inverse.
    ///
    /// Le [pattern] peut être un `&str`, [`char`], une tranche de [`char`] s, ou une fonction ou une fermeture qui détermine si un caractère correspond.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportement de l'itérateur
    ///
    /// L'itérateur retourné nécessite que le modèle prenne en charge une recherche inversée, et ce sera un [`DoubleEndedIterator`] si une recherche forward/reverse produit les mêmes éléments.
    ///
    ///
    /// Pour itérer depuis l'avant, la méthode [`split`] peut être utilisée.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Modèles simples:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Un motif plus complexe, utilisant une fermeture:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Un itérateur sur des sous-chaînes de la tranche de chaîne donnée, séparés par des caractères correspondant à un modèle.
    ///
    /// Le [pattern] peut être un `&str`, [`char`], une tranche de [`char`] s, ou une fonction ou une fermeture qui détermine si un caractère correspond.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Équivalent à [`split`], sauf que la sous-chaîne de fin est ignorée si elle est vide.
    ///
    /// [`split`]: str::split
    ///
    /// Cette méthode peut être utilisée pour les données de chaîne qui sont _terminated_, plutôt que _separated_ par un modèle.
    ///
    /// # Comportement de l'itérateur
    ///
    /// L'itérateur retourné sera un [`DoubleEndedIterator`] si le modèle autorise une recherche inversée et que la recherche forward/reverse produit les mêmes éléments.
    /// Ceci est vrai, par exemple, pour [`char`], mais pas pour `&str`.
    ///
    /// Si le modèle autorise une recherche inversée mais que ses résultats peuvent différer d'une recherche avant, la méthode [`rsplit_terminator`] peut être utilisée.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Un itérateur sur des sous-chaînes de `self`, séparés par des caractères mis en correspondance par un modèle et renvoyés dans l'ordre inverse.
    ///
    /// Le [pattern] peut être un `&str`, [`char`], une tranche de [`char`] s, ou une fonction ou une fermeture qui détermine si un caractère correspond.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Équivalent à [`split`], sauf que la sous-chaîne de fin est ignorée si elle est vide.
    ///
    /// [`split`]: str::split
    ///
    /// Cette méthode peut être utilisée pour les données de chaîne qui sont _terminated_, plutôt que _separated_ par un modèle.
    ///
    /// # Comportement de l'itérateur
    ///
    /// L'itérateur renvoyé nécessite que le modèle prenne en charge une recherche inversée, et il sera double si une recherche forward/reverse produit les mêmes éléments.
    ///
    ///
    /// Pour itérer depuis l'avant, la méthode [`split_terminator`] peut être utilisée.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Un itérateur sur des sous-chaînes de la tranche de chaîne donnée, séparés par un modèle, limité à renvoyer au maximum les éléments `n`.
    ///
    /// Si des sous-chaînes `n` sont renvoyées, la dernière sous-chaîne (la `n`ième sous-chaîne) contiendra le reste de la chaîne.
    ///
    /// Le [pattern] peut être un `&str`, [`char`], une tranche de [`char`] s, ou une fonction ou une fermeture qui détermine si un caractère correspond.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportement de l'itérateur
    ///
    /// L'itérateur renvoyé ne sera pas double, car sa prise en charge n'est pas efficace.
    ///
    /// Si le modèle permet une recherche inversée, la méthode [`rsplitn`] peut être utilisée.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Modèles simples:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Un motif plus complexe, utilisant une fermeture:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Un itérateur sur des sous-chaînes de cette tranche de chaîne, séparés par un modèle, à partir de la fin de la chaîne, limité à renvoyer au maximum les éléments `n`.
    ///
    ///
    /// Si des sous-chaînes `n` sont renvoyées, la dernière sous-chaîne (la `n`ième sous-chaîne) contiendra le reste de la chaîne.
    ///
    /// Le [pattern] peut être un `&str`, [`char`], une tranche de [`char`] s, ou une fonction ou une fermeture qui détermine si un caractère correspond.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportement de l'itérateur
    ///
    /// L'itérateur renvoyé ne sera pas double, car sa prise en charge n'est pas efficace.
    ///
    /// Pour la division par l'avant, la méthode [`splitn`] peut être utilisée.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Modèles simples:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Un motif plus complexe, utilisant une fermeture:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Divise la chaîne à la première occurrence du délimiteur spécifié et renvoie le préfixe avant le délimiteur et le suffixe après le délimiteur.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Divise la chaîne à la dernière occurrence du délimiteur spécifié et renvoie le préfixe avant le délimiteur et le suffixe après le délimiteur.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Un itérateur sur les correspondances disjointes d'un modèle dans la tranche de chaîne donnée.
    ///
    /// Le [pattern] peut être un `&str`, [`char`], une tranche de [`char`] s, ou une fonction ou une fermeture qui détermine si un caractère correspond.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportement de l'itérateur
    ///
    /// L'itérateur retourné sera un [`DoubleEndedIterator`] si le modèle autorise une recherche inversée et que la recherche forward/reverse produit les mêmes éléments.
    /// Ceci est vrai, par exemple, pour [`char`], mais pas pour `&str`.
    ///
    /// Si le modèle autorise une recherche inversée mais que ses résultats peuvent différer d'une recherche avant, la méthode [`rmatches`] peut être utilisée.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Un itérateur sur les correspondances disjointes d'un modèle dans cette tranche de chaîne, produit dans l'ordre inverse.
    ///
    /// Le [pattern] peut être un `&str`, [`char`], une tranche de [`char`] s, ou une fonction ou une fermeture qui détermine si un caractère correspond.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportement de l'itérateur
    ///
    /// L'itérateur retourné nécessite que le modèle prenne en charge une recherche inversée, et ce sera un [`DoubleEndedIterator`] si une recherche forward/reverse produit les mêmes éléments.
    ///
    ///
    /// Pour itérer depuis l'avant, la méthode [`matches`] peut être utilisée.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Un itérateur sur les correspondances disjointes d'un modèle dans cette tranche de chaîne ainsi que l'index à partir duquel la correspondance commence.
    ///
    /// Pour les correspondances de `pat` dans `self` qui se chevauchent, seuls les indices correspondant à la première correspondance sont renvoyés.
    ///
    /// Le [pattern] peut être un `&str`, [`char`], une tranche de [`char`] s, ou une fonction ou une fermeture qui détermine si un caractère correspond.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportement de l'itérateur
    ///
    /// L'itérateur retourné sera un [`DoubleEndedIterator`] si le modèle autorise une recherche inversée et que la recherche forward/reverse produit les mêmes éléments.
    /// Ceci est vrai, par exemple, pour [`char`], mais pas pour `&str`.
    ///
    /// Si le modèle autorise une recherche inversée mais que ses résultats peuvent différer d'une recherche avant, la méthode [`rmatch_indices`] peut être utilisée.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // seulement le premier `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Un itérateur sur les correspondances disjointes d'un modèle dans `self`, produit dans l'ordre inverse avec l'index de la correspondance.
    ///
    /// Pour les correspondances de `pat` dans `self` qui se chevauchent, seuls les indices correspondant à la dernière correspondance sont renvoyés.
    ///
    /// Le [pattern] peut être un `&str`, [`char`], une tranche de [`char`] s, ou une fonction ou une fermeture qui détermine si un caractère correspond.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportement de l'itérateur
    ///
    /// L'itérateur retourné nécessite que le modèle prenne en charge une recherche inversée, et ce sera un [`DoubleEndedIterator`] si une recherche forward/reverse produit les mêmes éléments.
    ///
    ///
    /// Pour itérer depuis l'avant, la méthode [`match_indices`] peut être utilisée.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // seulement le dernier `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Renvoie une tranche de chaîne avec les espaces de début et de fin supprimés.
    ///
    /// 'Whitespace' est défini selon les termes de la propriété de base dérivée Unicode `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Renvoie une tranche de chaîne avec les espaces de début supprimés.
    ///
    /// 'Whitespace' est défini selon les termes de la propriété de base dérivée Unicode `White_Space`.
    ///
    /// # Directivité du texte
    ///
    /// Une chaîne est une séquence d'octets.
    /// `start` dans ce contexte, signifie la première position de cette chaîne d'octets;pour une langue de gauche à droite comme l'anglais ou le russe, ce sera le côté gauche, et pour les langues de droite à gauche comme l'arabe ou l'hébreu, ce sera le côté droit.
    ///
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Renvoie une tranche de chaîne avec les espaces de fin supprimés.
    ///
    /// 'Whitespace' est défini selon les termes de la propriété de base dérivée Unicode `White_Space`.
    ///
    /// # Directivité du texte
    ///
    /// Une chaîne est une séquence d'octets.
    /// `end` dans ce contexte signifie la dernière position de cette chaîne d'octets;pour une langue de gauche à droite comme l'anglais ou le russe, ce sera le côté droit, et pour les langues de droite à gauche comme l'arabe ou l'hébreu, ce sera le côté gauche.
    ///
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Renvoie une tranche de chaîne avec les espaces de début supprimés.
    ///
    /// 'Whitespace' est défini selon les termes de la propriété de base dérivée Unicode `White_Space`.
    ///
    /// # Directivité du texte
    ///
    /// Une chaîne est une séquence d'octets.
    /// 'Left' dans ce contexte, signifie la première position de cette chaîne d'octets;pour une langue comme l'arabe ou l'hébreu qui sont «de droite à gauche» plutôt que «de gauche à droite», ce sera le côté _right_, pas la gauche.
    ///
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Renvoie une tranche de chaîne avec les espaces de fin supprimés.
    ///
    /// 'Whitespace' est défini selon les termes de la propriété de base dérivée Unicode `White_Space`.
    ///
    /// # Directivité du texte
    ///
    /// Une chaîne est une séquence d'octets.
    /// 'Right' dans ce contexte signifie la dernière position de cette chaîne d'octets;pour une langue comme l'arabe ou l'hébreu qui sont «de droite à gauche» plutôt que «de gauche à droite», ce sera le côté _left_, pas la droite.
    ///
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Renvoie une tranche de chaîne avec tous les préfixes et suffixes qui correspondent à un modèle supprimé à plusieurs reprises.
    ///
    /// Le [pattern] peut être un [`char`], une tranche de [`char`] s, ou une fonction ou une fermeture qui détermine si un caractère correspond.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Modèles simples:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Un motif plus complexe, utilisant une fermeture:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Rappelez-vous la première correspondance connue, corrigez-la ci-dessous si
            // le dernier match est différent
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SÉCURITÉ: `Searcher` est connu pour renvoyer des indices valides.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Renvoie une tranche de chaîne avec tous les préfixes qui correspondent à un modèle supprimés à plusieurs reprises.
    ///
    /// Le [pattern] peut être un `&str`, [`char`], une tranche de [`char`] s, ou une fonction ou une fermeture qui détermine si un caractère correspond.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Directivité du texte
    ///
    /// Une chaîne est une séquence d'octets.
    /// `start` dans ce contexte, signifie la première position de cette chaîne d'octets;pour une langue de gauche à droite comme l'anglais ou le russe, ce sera le côté gauche, et pour les langues de droite à gauche comme l'arabe ou l'hébreu, ce sera le côté droit.
    ///
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // SÉCURITÉ: `Searcher` est connu pour renvoyer des indices valides.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Renvoie une tranche de chaîne avec le préfixe supprimé.
    ///
    /// Si la chaîne commence par le modèle `prefix`, retourne la sous-chaîne après le préfixe, encapsulée dans `Some`.
    /// Contrairement à `trim_start_matches`, cette méthode supprime le préfixe une seule fois.
    ///
    /// Si la chaîne ne commence pas par `prefix`, renvoie `None`.
    ///
    /// Le [pattern] peut être un `&str`, [`char`], une tranche de [`char`] s, ou une fonction ou une fermeture qui détermine si un caractère correspond.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Renvoie une tranche de chaîne avec le suffixe supprimé.
    ///
    /// Si la chaîne se termine par le modèle `suffix`, renvoie la sous-chaîne avant le suffixe, encapsulée dans `Some`.
    /// Contrairement à `trim_end_matches`, cette méthode supprime le suffixe une seule fois.
    ///
    /// Si la chaîne ne se termine pas par `suffix`, renvoie `None`.
    ///
    /// Le [pattern] peut être un `&str`, [`char`], une tranche de [`char`] s, ou une fonction ou une fermeture qui détermine si un caractère correspond.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Renvoie une tranche de chaîne avec tous les suffixes qui correspondent à un modèle supprimés à plusieurs reprises.
    ///
    /// Le [pattern] peut être un `&str`, [`char`], une tranche de [`char`] s, ou une fonction ou une fermeture qui détermine si un caractère correspond.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Directivité du texte
    ///
    /// Une chaîne est une séquence d'octets.
    /// `end` dans ce contexte signifie la dernière position de cette chaîne d'octets;pour une langue de gauche à droite comme l'anglais ou le russe, ce sera le côté droit, et pour les langues de droite à gauche comme l'arabe ou l'hébreu, ce sera le côté gauche.
    ///
    ///
    /// # Examples
    ///
    /// Modèles simples:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Un motif plus complexe, utilisant une fermeture:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SÉCURITÉ: `Searcher` est connu pour renvoyer des indices valides.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Renvoie une tranche de chaîne avec tous les préfixes qui correspondent à un modèle supprimés à plusieurs reprises.
    ///
    /// Le [pattern] peut être un `&str`, [`char`], une tranche de [`char`] s, ou une fonction ou une fermeture qui détermine si un caractère correspond.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Directivité du texte
    ///
    /// Une chaîne est une séquence d'octets.
    /// 'Left' dans ce contexte, signifie la première position de cette chaîne d'octets;pour une langue comme l'arabe ou l'hébreu qui sont «de droite à gauche» plutôt que «de gauche à droite», ce sera le côté _right_, pas la gauche.
    ///
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Renvoie une tranche de chaîne avec tous les suffixes qui correspondent à un modèle supprimés à plusieurs reprises.
    ///
    /// Le [pattern] peut être un `&str`, [`char`], une tranche de [`char`] s, ou une fonction ou une fermeture qui détermine si un caractère correspond.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Directivité du texte
    ///
    /// Une chaîne est une séquence d'octets.
    /// 'Right' dans ce contexte signifie la dernière position de cette chaîne d'octets;pour une langue comme l'arabe ou l'hébreu qui sont «de droite à gauche» plutôt que «de gauche à droite», ce sera le côté _left_, pas la droite.
    ///
    ///
    /// # Examples
    ///
    /// Modèles simples:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Un motif plus complexe, utilisant une fermeture:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Analyse cette tranche de chaîne dans un autre type.
    ///
    /// Parce que `parse` est si général, il peut causer des problèmes avec l'inférence de type.
    /// En tant que tel, `parse` est l'une des rares fois où vous verrez la syntaxe affectueusement connue sous le nom de 'turbofish': `::<>`.
    ///
    /// Cela aide l'algorithme d'inférence à comprendre précisément le type dans lequel vous essayez d'analyser.
    ///
    /// `parse` peut analyser n'importe quel type qui implémente le [`FromStr`] trait.
    ///

    /// # Errors
    ///
    /// Renvoie [`Err`] s'il n'est pas possible d'analyser cette tranche de chaîne dans le type souhaité.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Utilisation de base
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Utilisation du 'turbofish' au lieu d'annoter `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Échec de l'analyse:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Vérifie si tous les caractères de cette chaîne se trouvent dans la plage ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Nous pouvons traiter chaque octet comme un caractère ici: tous les caractères multi-octets commencent par un octet qui n'est pas dans la plage ascii, donc nous nous arrêterons déjà là.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Vérifie que deux chaînes sont une correspondance ASCII insensible à la casse.
    ///
    /// Identique à `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, mais sans allouer ni copier les temporaires.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Convertit cette chaîne en son équivalent en majuscules ASCII sur place.
    ///
    /// Les lettres ASCII 'a' à 'z' sont mappées entre 'A' et 'Z', mais les lettres non ASCII restent inchangées.
    ///
    /// Pour renvoyer une nouvelle valeur en majuscules sans modifier la valeur existante, utilisez [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // SÉCURITÉ: sûr car nous transmutons deux types avec la même disposition.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Convertit cette chaîne en son équivalent en minuscules ASCII sur place.
    ///
    /// Les lettres ASCII 'A' à 'Z' sont mappées entre 'a' et 'z', mais les lettres non ASCII restent inchangées.
    ///
    /// Pour renvoyer une nouvelle valeur en minuscules sans modifier la valeur existante, utilisez [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // SÉCURITÉ: sûr car nous transmutons deux types avec la même disposition.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Renvoie un itérateur qui échappe chaque caractère dans `self` avec [`char::escape_debug`].
    ///
    ///
    /// Note: seuls les points de code de graphème étendus qui commencent la chaîne seront échappés.
    ///
    /// # Examples
    ///
    /// En tant qu'itérateur:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilisation directe de `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Les deux sont équivalents à:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// En utilisant `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Renvoie un itérateur qui échappe chaque caractère dans `self` avec [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// En tant qu'itérateur:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilisation directe de `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Les deux sont équivalents à:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// En utilisant `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Renvoie un itérateur qui échappe chaque caractère dans `self` avec [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// En tant qu'itérateur:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilisation directe de `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Les deux sont équivalents à:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// En utilisant `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Crée un str vide
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Crée une chaîne mutable vide
    #[inline]
    fn default() -> Self {
        // SÉCURITÉ: la chaîne vide est UTF-8 valide.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Un type fn nommable et clonable
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // SÉCURITÉ: pas sûr
        unsafe { from_utf8_unchecked(bytes) }
    };
}