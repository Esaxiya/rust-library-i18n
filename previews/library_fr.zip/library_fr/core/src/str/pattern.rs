//! L'API de modèle de chaîne.
//!
//! L'API Pattern fournit un mécanisme générique pour utiliser différents types de modèles lors de la recherche dans une chaîne.
//!
//! Pour plus de détails, consultez les traits [`Pattern`], [`Searcher`], [`ReverseSearcher`] et [`DoubleEndedSearcher`].
//!
//! Bien que cette API soit instable, elle est exposée via des API stables sur le type [`str`].
//!
//! # Examples
//!
//! [`Pattern`] est [implemented][pattern-impls] dans l'API stable pour [`&str`][`str`], [`char`], les tranches de [`char`] et les fonctions et fermetures implémentant `FnMut(char) -> bool`.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // motif char
//! assert_eq!(s.find('n'), Some(2));
//! // motif de tranche de caractères
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // motif de fermeture
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Un modèle de chaîne.
///
/// Un `Pattern<'a>` indique que le type d'implémentation peut être utilisé comme modèle de chaîne pour la recherche dans un [`&'a str`][str].
///
/// Par exemple, `'a'` et `"aa"` sont des modèles qui correspondent à l'index `1` dans la chaîne `"baaaab"`.
///
/// Le trait lui-même agit comme un générateur pour un type [`Searcher`] associé, qui effectue le travail réel de recherche des occurrences du modèle dans une chaîne.
///
///
/// Selon le type de motif, le comportement de méthodes telles que [`str::find`] et [`str::contains`] peut changer.
/// Le tableau ci-dessous décrit certains de ces comportements.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Chercheur associé pour ce modèle
    type Searcher: Searcher<'a>;

    /// Construit le moteur de recherche associé à partir de `self` et du `haystack` dans lequel effectuer la recherche.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Vérifie si le motif correspond à n'importe quel endroit de la botte de foin
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Vérifie si le motif correspond à l'avant de la botte de foin
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Vérifie si le motif correspond à l'arrière de la botte de foin
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Supprime le motif de l'avant de la botte de foin, s'il correspond.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // SÉCURITÉ: `Searcher` est connu pour renvoyer des indices valides.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Supprime le motif de l'arrière de la botte de foin, s'il correspond.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // SÉCURITÉ: `Searcher` est connu pour renvoyer des indices valides.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// Résultat de l'appel [`Searcher::next()`] ou [`ReverseSearcher::next_back()`].
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Exprime qu'une correspondance du modèle a été trouvée à `haystack[a..b]`.
    ///
    Match(usize, usize),
    /// Exprime que `haystack[a..b]` a été rejeté comme correspondance possible du modèle.
    ///
    /// Notez qu'il peut y avoir plus d'un `Reject` entre deux `Match`, il n'est pas nécessaire de les combiner en un seul.
    ///
    ///
    Reject(usize, usize),
    /// Exprime que chaque octet de la botte de foin a été visité, mettant fin à l'itération.
    ///
    Done,
}

/// Un chercheur pour un modèle de chaîne.
///
/// Ce trait fournit des méthodes pour rechercher des correspondances sans chevauchement d'un motif à partir du (left) avant d'une chaîne.
///
/// Il sera implémenté par les types `Searcher` associés du [`Pattern`] trait.
///
/// Le trait est marqué comme dangereux car les indices renvoyés par les méthodes [`next()`][Searcher::next] doivent se trouver sur des limites utf8 valides dans la botte de foin.
/// Cela permet aux utilisateurs de ce trait de découper la botte de foin sans contrôles d'exécution supplémentaires.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter pour la chaîne sous-jacente à rechercher dans
    ///
    /// Renvoie toujours le même [`&str`][str].
    fn haystack(&self) -> &'a str;

    /// Effectue la prochaine étape de recherche en commençant par l'avant.
    ///
    /// - Renvoie [`Match(a, b)`][SearchStep::Match] si `haystack[a..b]` correspond au modèle.
    /// - Renvoie [`Reject(a, b)`][SearchStep::Reject] si `haystack[a..b]` ne peut pas correspondre au modèle, même partiellement.
    /// - Renvoie [`Done`][SearchStep::Done] si chaque octet de la botte de foin a été visité.
    ///
    /// Le flux de valeurs [`Match`][SearchStep::Match] et [`Reject`][SearchStep::Reject] jusqu'à un [`Done`][SearchStep::Done] contiendra des plages d'index adjacentes, ne se chevauchant pas, couvrant toute la botte de foin et reposant sur les limites utf8.
    ///
    ///
    /// Un résultat [`Match`][SearchStep::Match] doit contenir tout le modèle correspondant, cependant les résultats [`Reject`][SearchStep::Reject] peuvent être divisés en plusieurs fragments adjacents arbitraires.Les deux plages peuvent avoir une longueur nulle.
    ///
    /// À titre d'exemple, le motif `"aaa"` et la botte de foin `"cbaaaaab"` peuvent produire le flux
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Recherche le résultat [`Match`][SearchStep::Match] suivant.Voir [`next()`][Searcher::next].
    ///
    /// Contrairement à [`next()`][Searcher::next], il n'y a aucune garantie que les plages renvoyées de this et [`next_reject`][Searcher::next_reject] se chevaucheront.
    /// Cela renverra `(start_match, end_match)`, où start_match est l'index du début de la correspondance et end_match est l'index après la fin de la correspondance.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Recherche le résultat [`Reject`][SearchStep::Reject] suivant.Voir [`next()`][Searcher::next] et [`next_match()`][Searcher::next_match].
    ///
    /// Contrairement à [`next()`][Searcher::next], il n'y a aucune garantie que les plages renvoyées de this et [`next_match`][Searcher::next_match] se chevaucheront.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Un chercheur inversé pour un modèle de chaîne.
///
/// Ce trait fournit des méthodes pour rechercher des correspondances sans chevauchement d'un motif à partir du (right) arrière d'une chaîne.
///
/// Il sera implémenté par les types [`Searcher`] associés du [`Pattern`] trait si le motif prend en charge sa recherche par l'arrière.
///
///
/// Les plages d'index renvoyées par ce trait ne sont pas obligées de correspondre exactement à celles de la recherche vers l'avant en sens inverse.
///
/// Pour la raison pour laquelle ce trait est marqué comme dangereux, voyez-les parent trait [`Searcher`].
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Effectue la prochaine étape de recherche en commençant par l'arrière.
    ///
    /// - Renvoie [`Match(a, b)`][SearchStep::Match] si `haystack[a..b]` correspond au modèle.
    /// - Renvoie [`Reject(a, b)`][SearchStep::Reject] si `haystack[a..b]` ne peut pas correspondre au modèle, même partiellement.
    /// - Renvoie [`Done`][SearchStep::Done] si chaque octet de la botte de foin a été visité
    ///
    /// Le flux de valeurs [`Match`][SearchStep::Match] et [`Reject`][SearchStep::Reject] jusqu'à un [`Done`][SearchStep::Done] contiendra des plages d'index adjacentes, ne se chevauchant pas, couvrant toute la botte de foin et reposant sur les limites utf8.
    ///
    ///
    /// Un résultat [`Match`][SearchStep::Match] doit contenir tout le modèle correspondant, cependant les résultats [`Reject`][SearchStep::Reject] peuvent être divisés en plusieurs fragments adjacents arbitraires.Les deux plages peuvent avoir une longueur nulle.
    ///
    /// A titre d'exemple, le motif `"aaa"` et la botte de foin `"cbaaaaab"` peuvent produire le flux `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Recherche le résultat [`Match`][SearchStep::Match] suivant.
    /// Voir [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Recherche le résultat [`Reject`][SearchStep::Reject] suivant.
    /// Voir [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Un marqueur trait pour exprimer qu'un [`ReverseSearcher`] peut être utilisé pour une implémentation [`DoubleEndedIterator`].
///
/// Pour cela, les implément de [`Searcher`] et [`ReverseSearcher`] doivent suivre ces conditions:
///
/// - Tous les résultats de `next()` doivent être identiques aux résultats de `next_back()` dans l'ordre inverse.
/// - `next()` et `next_back()` doivent se comporter comme les deux extrémités d'une plage de valeurs, c'est-à-dire qu'ils ne peuvent pas "walk past each other".
///
/// # Examples
///
/// `char::Searcher` est un `DoubleEndedSearcher` car la recherche d'un [`char`] ne nécessite que d'en regarder un à la fois, ce qui se comporte de la même manière des deux côtés.
///
/// `(&str)::Searcher` n'est pas un `DoubleEndedSearcher` car le motif `"aa"` dans la botte de foin `"aaa"` correspond à `"[aa]a"` ou `"a[aa]"`, selon le côté à partir duquel il est recherché.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Impl pour char
/////////////////////////////////////////////////////////////////////////////

/// Type associé pour `<char as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // invariant de sécurité: `finger`/`finger_back` doit être un index d'octet utf8 valide de `haystack` Cet invariant peut être brisé *dans* next_match et next_match_back, mais ils doivent sortir avec les doigts sur des limites de points de code valides.
    //
    //
    /// `finger` est l'index d'octet actuel de la recherche vers l'avant.
    /// Imaginons qu'il existe avant l'octet à son index, c'est-à-dire
    /// `haystack[finger]` est le premier octet de la tranche que nous devons inspecter lors de la recherche directe
    ///
    finger: usize,
    /// `finger_back` est l'index d'octet actuel de la recherche inversée.
    /// Imaginons qu'il existe après l'octet à son index, c'est-à-dire
    /// haystack [finger_back, 1] est le dernier octet de la tranche que nous devons inspecter lors de la recherche vers l'avant (et donc le premier octet à inspecter lors de l'appel de next_back()).
    ///
    finger_back: usize,
    /// Le personnage recherché
    needle: char,

    // invariant de sécurité: `utf8_size` doit être inférieur à 5
    /// Le nombre d'octets que `needle` prend lorsqu'il est codé en utf8.
    utf8_size: usize,
    /// Une copie codée utf8 du `needle`
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // SÉCURITÉ: 1-4 garantissent la sécurité du `get_unchecked`
        // 1. `self.finger` et `self.finger_back` sont conservés sur les limites unicode (ceci est invariant)
        // 2. `self.finger >= 0` puisqu'il commence à 0 et n'augmente que
        // 3. `self.finger < self.finger_back` car sinon le char `iter` renverrait `SearchStep::Done`
        // 4.
        // `self.finger` vient avant la fin de la botte de foin car `self.finger_back` commence à la fin et ne fait que diminuer
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // ajouter le décalage d'octet du caractère actuel sans recodage en utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // récupérer la botte de foin après le dernier personnage trouvé
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // le dernier octet de l'aiguille codée utf8 SÉCURITÉ: nous avons un invariant que `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Le nouveau doigt est l'index de l'octet que nous avons trouvé, plus un, puisque nous avons mémorisé le dernier octet du caractère.
                //
                // Notez que cela ne nous donne pas toujours un doigt sur une frontière UTF8.
                // Si nous *n'avons* pas * trouvé notre caractère, nous avons peut-être indexé le non-dernier octet d'un caractère de 3 ou 4 octets.
                // Nous ne pouvons pas simplement passer au prochain octet de départ valide car un caractère comme ꁁ (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` nous fera toujours trouver le deuxième octet lors de la recherche du troisième.
                //
                //
                // Cependant, c'est tout à fait correct.
                // Bien que nous ayons l'invariant que self.finger est sur une frontière UTF8, cet invariant n'est pas utilisé dans cette méthode (il est utilisé dans CharSearcher::next()).
                //
                // Nous quittons cette méthode uniquement lorsque nous atteignons la fin de la chaîne, ou si nous trouvons quelque chose.Lorsque nous trouvons quelque chose, le `finger` sera réglé sur une limite UTF8.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // rien trouvé, sortie
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // laissez next_reject utiliser l'implémentation par défaut du Searcher trait
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // SÉCURITÉ: voir le commentaire pour next() ci-dessus
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // soustraire le décalage d'octet du caractère actuel sans recodage en utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // obtenir la botte de foin jusqu'au dernier caractère recherché, mais sans l'inclure
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // le dernier octet de l'aiguille codée utf8 SÉCURITÉ: nous avons un invariant que `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // nous avons recherché une tranche qui était décalée par self.finger, ajoutez self.finger pour récupérer l'index d'origine
                //
                let index = self.finger + index;
                // memrchr retournera l'index de l'octet que nous souhaitons trouver.
                // Dans le cas d'un caractère ASCII, c'est bien là que l'on souhaite que soit notre nouveau doigt ("after" le caractère trouvé dans le paradigme de l'itération inverse).
                //
                // Pour les caractères multi-octets, nous devons sauter par le nombre d'octets de plus qu'ils ont par rapport à ASCII
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // déplacer le doigt avant le caractère trouvé (c'est-à-dire à son index de départ)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Nous ne pouvons pas utiliser finger_back=index, size + 1 ici.
                // Si nous avons trouvé le dernier caractère d'un caractère de taille différente (ou l'octet du milieu d'un caractère différent), nous devons ramener le finger_back à `index`.
                // De la même manière, `finger_back` a le potentiel de ne plus être sur une limite, mais c'est OK puisque nous ne quittons cette fonction que sur une limite ou lorsque la botte de foin a été complètement recherchée.
                //
                //
                // Contrairement à next_match, cela n'a pas le problème des octets répétés dans utf-8 car nous recherchons le dernier octet, et nous ne pouvons avoir trouvé le dernier octet que lors d'une recherche inversée.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // rien trouvé, sortie
                return None;
            }
        }
    }

    // laissez next_reject_back utiliser l'implémentation par défaut du Searcher trait
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Recherche les caractères égaux à un [`char`] donné.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Impl pour un wrapper MultiCharEq
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Comparez les longueurs de l'itérateur de tranche d'octet interne pour trouver la longueur du caractère actuel
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Comparez les longueurs de l'itérateur de tranche d'octet interne pour trouver la longueur du caractère actuel
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Impl pour&[char]
/////////////////////////////////////////////////////////////////////////////

// Todo: Changer/Supprimer en raison de l'ambiguïté du sens.

/// Type associé pour `<&[char] as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Recherche les caractères égaux à l'un des [`char`] de la tranche.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl pour F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// Type associé pour `<F as Pattern<'a>>::Searcher`.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Recherche les [`char`] s qui correspondent au prédicat donné.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl pour&&str
/////////////////////////////////////////////////////////////////////////////

/// Les délégués à l'impl. `&str`.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Impl pour &str
/////////////////////////////////////////////////////////////////////////////

/// Recherche de sous-chaînes sans allocation.
///
/// Traitera le modèle `""` comme renvoyant des correspondances vides à chaque limite de caractère.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Vérifie si le motif correspond à l'avant de la botte de foin.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Supprime le motif de l'avant de la botte de foin, s'il correspond.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // SÉCURITÉ: le préfixe vient d'être vérifié.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Vérifie si le motif correspond à l'arrière de la botte de foin.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Supprime le motif de l'arrière de la botte de foin, s'il correspond.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // SÉCURITÉ: le suffixe vient d'être vérifié pour exister.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// Recherche de sous-chaîne bidirectionnelle
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Type associé pour `<&str as Pattern<'a>>::Searcher`.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // l'aiguille vide rejette tous les caractères et correspond à chaque chaîne vide entre eux
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher produit des index *Match* valides qui se divisent aux limites des caractères tant qu'il corrige la correspondance et que la botte de foin et l'aiguille sont valides UTF-8 *Les rejets* de l'algorithme peuvent tomber sur n'importe quel index, mais nous les marcherons manuellement jusqu'à la limite de caractère suivante, afin qu'ils soient sûrs utf-8.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // passer à la limite de caractères suivante
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // écrivez les cas `true` et `false` pour encourager le compilateur à spécialiser les deux cas séparément.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // passer à la limite de caractères suivante
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // écrire `true` et `false`, comme `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// L'état interne de l'algorithme de recherche bidirectionnelle de sous-chaînes.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// indice de factorisation critique
    crit_pos: usize,
    /// indice de factorisation critique pour l'aiguille inversée
    crit_pos_back: usize,
    period: usize,
    /// `byteset` est une extension (ne fait pas partie de l'algorithme bidirectionnel);
    /// c'est un "fingerprint" 64 bits où chaque bit `j` défini correspond à un (octet&63)==j présent dans l'aiguille.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// index dans l'aiguille avant laquelle nous avons déjà apparié
    memory: usize,
    /// index dans l'aiguille après quoi nous avons déjà apparié
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Une explication particulièrement lisible de ce qui se passe ici peut être trouvée dans le livre "Text Algorithms" de Crochemore et Rytter, ch 13.
        // Voir plus précisément le code pour "Algorithm CP" à la p.
        // 323.
        //
        // Ce qui se passe, c'est que nous avons une factorisation critique (u, v) de l'aiguille, et nous voulons déterminer si u est un suffixe de&v [.. période].
        // Si c'est le cas, nous utilisons "Algorithm CP1".
        // Sinon, nous utilisons "Algorithm CP2", qui est optimisé lorsque la période de l'aiguille est grande.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // cas de période courte-la période est exacte calculer une factorisation critique distincte pour l'aiguille inversée x=u 'v' où | v '|<period(x).
            //
            // Ceci est accéléré par la période déjà connue.
            // Notez qu'un cas comme x= "acba" peut être factorisé exactement en avant (crit_pos=1, period=3) tout en étant factorisé avec une période approximative en sens inverse (crit_pos=2, period=2).
            // Nous utilisons la factorisation inverse donnée mais gardons la période exacte.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // cas de longue période-nous avons une approximation de la période réelle et n'utilisons pas la mémorisation.
            //
            //
            // Approximer la période par la borne inférieure max(|u|, |v|) + 1.
            // La factorisation critique est efficace à utiliser pour la recherche avant et arrière.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Valeur fictive pour indiquer que la période est longue
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // L'une des principales idées de Two-Way est que nous factorisons l'aiguille en deux moitiés, (u, v), et commençons à essayer de trouver v dans la botte de foin en balayant de gauche à droite.
    // Si v correspond, nous essayons de faire correspondre u en scannant de droite à gauche.
    // Jusqu'où nous pouvons sauter lorsque nous rencontrons une discordance est basé sur le fait que (u, v) est une factorisation critique pour l'aiguille.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` utilise `self.position` comme curseur
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Vérifiez que nous avons de la place pour rechercher en position + aiguille_last ne peut pas déborder si nous supposons que les tranches sont délimitées par la plage de isize.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Sautez rapidement par grandes portions sans rapport avec notre sous-chaîne
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Voir si la partie droite de l'aiguille correspond
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Voir si la partie gauche de l'aiguille correspond
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Nous avons trouvé un match!
            let match_pos = self.position;

            // Note: ajoutez self.period au lieu de needle.len() pour avoir des correspondances qui se chevauchent
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // défini sur needle.len(), self.period pour les correspondances qui se chevauchent
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Suit les idées de `next()`.
    //
    // Les définitions sont symétriques, avec period(x) = period(reverse(x)) et local_period(u, v) = local_period(reverse(v), reverse(u)), donc si (u, v) est une factorisation critique, il en va de même pour (reverse(v), reverse(u)).
    //
    //
    // Pour le cas inverse, nous avons calculé une factorisation critique x=u 'v' (champ `crit_pos_back`).Nous avons besoin de | u |<period(x) pour le cas avant et donc | v '|<period(x) pour l'inverse.
    //
    // Pour rechercher en sens inverse dans la botte de foin, nous recherchons en avant dans une botte de foin inversée avec une aiguille inversée, correspondant d'abord à u ', puis à v'.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` utilise `self.end` comme curseur-de sorte que `next()` et `next_back()` soient indépendants.
        //
        let old_end = self.end;
        'search: loop {
            // Vérifiez que nous avons de la place pour rechercher à la fin, needle.len() s'enroulera lorsqu'il n'y aura plus de place, mais en raison des limites de longueur de tranche, il ne pourra jamais revenir complètement dans la longueur de la botte de foin.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Sautez rapidement par grandes portions sans rapport avec notre sous-chaîne
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Voir si la partie gauche de l'aiguille correspond
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Voir si la partie droite de l'aiguille correspond
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Nous avons trouvé un match!
            let match_pos = self.end - needle.len();
            // Note: sub self.period au lieu de needle.len() pour avoir des correspondances qui se chevauchent
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Calculez le suffixe maximal de `arr`.
    //
    // Le suffixe maximal est une possible factorisation critique (u, v) de `arr`.
    //
    // Renvoie (`i`, `p`) où `i` est l'indice de départ de v et `p` est la période de v.
    //
    // `order_greater` détermine si l'ordre lexical est `<` ou `>`.
    // Les deux ordres doivent être calculés-la commande avec le plus grand `i` donne une factorisation critique.
    //
    //
    // Pour les cas de longue période, la période résultante n'est pas exacte (elle est trop courte).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Correspond à i dans le papier
        let mut right = 1; // Correspond à j dans le papier
        let mut offset = 0; // Correspond à k dans le papier, mais à partir de 0
        // pour correspondre à l'indexation basée sur 0.
        let mut period = 1; // Correspond à p dans l'article

        while let Some(&a) = arr.get(right + offset) {
            // `left` sera dans les limites lorsque `right` est.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Le suffixe est plus petit, le point est le préfixe entier jusqu'à présent.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Avancez en répétant la période en cours.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Le suffixe est plus grand, recommencez à partir de l'emplacement actuel.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Calculez le suffixe maximal de l'inverse de `arr`.
    //
    // Le suffixe maximal est une possible factorisation critique (u ', v') de `arr`.
    //
    // Renvoie `i` où `i` est l'indice de départ de v ', à partir de l'arrière;
    // retourne immédiatement lorsqu'une période de `known_period` est atteinte.
    //
    // `order_greater` détermine si l'ordre lexical est `<` ou `>`.
    // Les deux ordres doivent être calculés-la commande avec le plus grand `i` donne une factorisation critique.
    //
    //
    // Pour les cas de longue période, la période résultante n'est pas exacte (elle est trop courte).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Correspond à i dans le papier
        let mut right = 1; // Correspond à j dans le papier
        let mut offset = 0; // Correspond à k dans le papier, mais à partir de 0
        // pour correspondre à l'indexation basée sur 0.
        let mut period = 1; // Correspond à p dans l'article
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Le suffixe est plus petit, le point est le préfixe entier jusqu'à présent.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Avancez en répétant la période en cours.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Le suffixe est plus grand, recommencez à partir de l'emplacement actuel.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy permet à l'algorithme soit d'ignorer les non-correspondances aussi rapidement que possible, soit de travailler dans un mode où il émet des rejets relativement rapidement.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Passer aux intervalles de correspondance aussi rapidement que possible
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Émettre des rejets régulièrement
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}