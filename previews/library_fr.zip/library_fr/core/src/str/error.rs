//! Définit le type d'erreur utf8.

use crate::fmt;

/// Erreurs qui peuvent survenir lors de la tentative d'interprétation d'une séquence de [`u8`] comme une chaîne.
///
/// En tant que tel, la famille de fonctions et de méthodes `from_utf8` pour les [`String`] s et [`&str`] s utilise cette erreur, par exemple.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Les méthodes de ce type d'erreur peuvent être utilisées pour créer des fonctionnalités similaires à `String::from_utf8_lossy` sans allouer de mémoire de tas:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Renvoie l'index dans la chaîne donnée jusqu'à laquelle UTF-8 valide a été vérifié.
    ///
    /// C'est l'indice maximum tel que `from_utf8(&input[..index])` renverrait `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// use std::str;
    ///
    /// // quelques octets invalides, dans un vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 renvoie une Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // le deuxième octet est invalide ici
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Fournit plus d'informations sur l'échec:
    ///
    /// * `None`: la fin de l'entrée a été atteinte de manière inattendue.
    ///   `self.valid_up_to()` est de 1 à 3 octets à partir de la fin de l'entrée.
    ///   Si un flux d'octets (tel qu'un fichier ou une socket réseau) est décodé de manière incrémentielle, il peut s'agir d'un `char` valide dont la séquence d'octets UTF-8 s'étend sur plusieurs blocs.
    ///
    ///
    /// * `Some(len)`: un octet inattendu a été rencontré.
    ///   La longueur fournie est celle de la séquence d'octets invalide qui commence à l'index donné par `valid_up_to()`.
    ///   Le décodage doit reprendre après cette séquence (après l'insertion d'un [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) en cas de décodage avec perte.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Une erreur renvoyée lors de l'analyse d'un `bool` à l'aide de [`from_str`] échoue
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}