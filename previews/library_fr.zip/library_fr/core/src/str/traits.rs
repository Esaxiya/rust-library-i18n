//! Implémentations Trait pour `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Implémente l'ordre des chaînes.
///
/// Les chaînes sont classées [lexicographically](Ord#lexicographical-comparison) par leurs valeurs d'octets.
/// Cela ordonne les points de code Unicode en fonction de leur position dans les graphiques de code.
/// Ce n'est pas nécessairement la même chose que l'ordre "alphabetical", qui varie selon la langue et les paramètres régionaux.
/// Le tri des chaînes selon les normes culturellement acceptées nécessite des données spécifiques aux paramètres régionaux qui sont en dehors de la portée du type `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Implémente des opérations de comparaison sur les chaînes.
///
/// Les chaînes sont comparées [lexicographically](Ord#lexicographical-comparison) par leurs valeurs d'octets.
/// Cela compare les points de code Unicode en fonction de leur position dans les graphiques de code.
/// Ce n'est pas nécessairement la même chose que l'ordre "alphabetical", qui varie selon la langue et les paramètres régionaux.
/// La comparaison de chaînes selon des normes culturellement acceptées nécessite des données spécifiques aux paramètres régionaux qui sortent du cadre du type `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Implémente le découpage de sous-chaînes avec la syntaxe `&self[..]` ou `&mut self[..]`.
///
/// Renvoie une tranche de la chaîne entière, c'est-à-dire renvoie `&self` ou `&mut self`.Équivaut à `&self [0 ..
/// len] `ou`&mut self [0 ..
/// len]`.
/// Contrairement à d'autres opérations d'indexation, cela ne peut jamais panic.
///
/// Cette opération est *O*(1).
///
/// Avant 1.20.0, ces opérations d'indexation étaient toujours prises en charge par l'implémentation directe de `Index` et `IndexMut`.
///
/// Équivalent à `&self[0 .. len]` ou `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Implémente le découpage de sous-chaînes avec la syntaxe `&self[begin .. end]` ou `&mut self[begin .. end]`.
///
/// Renvoie une tranche de la chaîne donnée à partir de la plage d'octets [`begin`, `end`).
///
/// Cette opération est *O*(1).
///
/// Avant 1.20.0, ces opérations d'indexation étaient toujours prises en charge par l'implémentation directe de `Index` et `IndexMut`.
///
/// # Panics
///
/// Panics si `begin` ou `end` ne pointe pas vers le décalage d'octet de départ d'un caractère (tel que défini par `is_char_boundary`), si `begin > end` ou si `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // ceux-ci seront panic:
/// // l'octet 2 se trouve dans `ö`:
/// // &s [2 ..3];
///
/// // l'octet 8 se trouve dans `老`&s [1 ..
/// // 8];
///
/// // l'octet 100 est en dehors de la chaîne&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SÉCURITÉ: vient de vérifier que `start` et `end` sont sur une limite de caractère,
            // et nous transmettons une référence sûre, donc la valeur de retour sera également un.
            // Nous avons également vérifié les limites des caractères, donc c'est UTF-8 valide.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SÉCURITÉ: vient de vérifier que `start` et `end` sont sur une limite de caractère.
            // Nous savons que le pointeur est unique car nous l'avons obtenu de `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SÉCURITÉ: l'appelant garantit que `self` est dans les limites de `slice`
        // qui satisfait toutes les conditions pour `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SÉCURITÉ: voir les commentaires pour `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary vérifie que l'index est dans [0, .len()] ne peut pas réutiliser `get` comme ci-dessus, en raison d'un problème NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SÉCURITÉ: vient de vérifier que `start` et `end` sont sur une limite de caractère,
            // et nous transmettons une référence sûre, donc la valeur de retour sera également un.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Implémente le découpage de sous-chaînes avec la syntaxe `&self[.. end]` ou `&mut self[.. end]`.
///
/// Renvoie une tranche de la chaîne donnée à partir de la plage d'octets [«0», `end`).
/// Équivalent à `&self[0 .. end]` ou `&mut self[0 .. end]`.
///
/// Cette opération est *O*(1).
///
/// Avant 1.20.0, ces opérations d'indexation étaient toujours prises en charge par l'implémentation directe de `Index` et `IndexMut`.
///
/// # Panics
///
/// Panics si `end` ne pointe pas sur le décalage d'octet de départ d'un caractère (tel que défini par `is_char_boundary`), ou si `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SÉCURITÉ: vient de vérifier que `end` est sur une limite de caractère,
            // et nous transmettons une référence sûre, donc la valeur de retour sera également un.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SÉCURITÉ: vient de vérifier que `end` est sur une limite de caractère,
            // et nous transmettons une référence sûre, donc la valeur de retour sera également un.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // SÉCURITÉ: vient de vérifier que `end` est sur une limite de caractère,
            // et nous transmettons une référence sûre, donc la valeur de retour sera également un.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Implémente le découpage de sous-chaînes avec la syntaxe `&self[begin ..]` ou `&mut self[begin ..]`.
///
/// Renvoie une tranche de la chaîne donnée à partir de la plage d'octets [`begin`, `len`).Équivalent à `&self [begin ..
/// len] `ou`&mut self [begin ..
/// len]`.
///
/// Cette opération est *O*(1).
///
/// Avant 1.20.0, ces opérations d'indexation étaient toujours prises en charge par l'implémentation directe de `Index` et `IndexMut`.
///
/// # Panics
///
/// Panics si `begin` ne pointe pas sur le décalage d'octet de départ d'un caractère (tel que défini par `is_char_boundary`), ou si `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SÉCURITÉ: vient de vérifier que `start` est sur une limite de caractère,
            // et nous transmettons une référence sûre, donc la valeur de retour sera également un.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SÉCURITÉ: vient de vérifier que `start` est sur une limite de caractère,
            // et nous transmettons une référence sûre, donc la valeur de retour sera également un.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SÉCURITÉ: l'appelant garantit que `self` est dans les limites de `slice`
        // qui satisfait toutes les conditions pour `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SÉCURITÉ: identique au `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // SÉCURITÉ: vient de vérifier que `start` est sur une limite de caractère,
            // et nous transmettons une référence sûre, donc la valeur de retour sera également un.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Implémente le découpage de sous-chaînes avec la syntaxe `&self[begin ..= end]` ou `&mut self[begin ..= end]`.
///
/// Renvoie une tranche de la chaîne donnée à partir de la plage d'octets [`begin`, `end`].Équivalent à `&self [begin .. end + 1]` ou `&mut self[begin .. end + 1]`, sauf si `end` a la valeur maximale pour `usize`.
///
/// Cette opération est *O*(1).
///
/// # Panics
///
/// Panics si `begin` ne pointe pas sur le décalage d'octet de départ d'un caractère (tel que défini par `is_char_boundary`), si `end` ne pointe pas sur le décalage d'octet de fin d'un caractère (`end + 1` est un décalage d'octet de départ ou égal à `len`), si `begin > end`, ou si `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Implémente le découpage de sous-chaînes avec la syntaxe `&self[..= end]` ou `&mut self[..= end]`.
///
/// Renvoie une tranche de la chaîne donnée à partir de la plage d'octets [0, `end`].
/// Équivalent à `&self [0 .. end + 1]`, sauf si `end` a la valeur maximale pour `usize`.
///
/// Cette opération est *O*(1).
///
/// # Panics
///
/// Panics si `end` ne pointe pas vers le décalage d'octet de fin d'un caractère (`end + 1` est soit un décalage d'octet de départ tel que défini par `is_char_boundary`, soit égal à `len`), ou si `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SÉCURITÉ: l'appelant doit respecter le contrat de sécurité du `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Analyser une valeur à partir d'une chaîne
///
/// La méthode [`from_str`] de `FromStr` est souvent utilisée implicitement, via la méthode [`parse`] de [`str`].
/// Voir la documentation de [`parse`] pour des exemples.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` n'a pas de paramètre de durée de vie et vous ne pouvez donc analyser que les types qui ne contiennent pas eux-mêmes de paramètre de durée de vie.
///
/// En d'autres termes, vous pouvez analyser un `i32` avec `FromStr`, mais pas un `&i32`.
/// Vous pouvez analyser une structure qui contient un `i32`, mais pas une qui contient un `&i32`.
///
/// # Examples
///
/// Implémentation de base de `FromStr` sur un exemple de type `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// L'erreur associée qui peut être renvoyée par l'analyse.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Analyse une chaîne `s` pour renvoyer une valeur de ce type.
    ///
    /// Si l'analyse réussit, retournez la valeur à l'intérieur de [`Ok`], sinon lorsque la chaîne est mal formatée, retournez une erreur spécifique à l'intérieur de [`Err`].
    /// Le type d'erreur est spécifique à l'implémentation du trait.
    ///
    /// # Examples
    ///
    /// Utilisation de base avec [`i32`], un type qui implémente `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Analysez un `bool` à partir d'une chaîne.
    ///
    /// Donne un `Result<bool, ParseBoolError>`, car `s` peut être analysable ou non.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Notez que dans de nombreux cas, la méthode `.parse()` sur `str` est plus appropriée.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}