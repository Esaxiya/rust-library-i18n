//! Façons de créer un `str` à partir d'une tranche d'octets.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Convertit une tranche d'octets en une tranche de chaîne.
///
/// Une tranche de chaîne ([`&str`]) est composée d'octets ([`u8`]) et une tranche d'octets ([`&[u8]`][byteslice]) est composée d'octets, cette fonction convertit donc entre les deux.
/// Cependant, toutes les tranches d'octets ne sont pas des tranches de chaîne valides: [`&str`] exige qu'il soit UTF-8 valide.
/// `from_utf8()` vérifie que les octets sont valides UTF-8, puis effectue la conversion.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Si vous êtes sûr que la tranche d'octets est UTF-8 valide et que vous ne voulez pas encourir la surcharge du contrôle de validité, il existe une version non sécurisée de cette fonction, [`from_utf8_unchecked`], qui a le même comportement mais ignore la vérification.
///
///
/// Si vous avez besoin d'un `String` au lieu d'un `&str`, pensez à [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Étant donné que vous pouvez allouer un `[u8; N]` par pile et que vous pouvez en prendre un [`&[u8]`][byteslice], cette fonction est un moyen d'avoir une chaîne allouée par pile.Il y a un exemple de cela dans la section des exemples ci-dessous.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Renvoie `Err` si la tranche n'est pas UTF-8 avec une description expliquant pourquoi la tranche fournie n'est pas UTF-8.
///
/// # Examples
///
/// Utilisation de base:
///
/// ```
/// use std::str;
///
/// // quelques octets, dans un vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Nous savons que ces octets sont valides, alors utilisez simplement `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Octets incorrects:
///
/// ```
/// use std::str;
///
/// // quelques octets invalides, dans un vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Consultez la documentation de [`Utf8Error`] pour plus de détails sur les types d'erreurs pouvant être renvoyées.
///
/// Un "stack allocated string":
///
/// ```
/// use std::str;
///
/// // quelques octets, dans un tableau alloué par pile
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Nous savons que ces octets sont valides, alors utilisez simplement `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // SÉCURITÉ: vient de lancer la validation.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Convertit une tranche d'octets mutable en une tranche de chaîne mutable.
///
/// # Examples
///
/// Utilisation de base:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" comme un vector mutable
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Comme nous savons que ces octets sont valides, nous pouvons utiliser `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Octets incorrects:
///
/// ```
/// use std::str;
///
/// // Certains octets non valides dans un vector mutable
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Consultez la documentation de [`Utf8Error`] pour plus de détails sur les types d'erreurs pouvant être renvoyées.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // SÉCURITÉ: vient de lancer la validation.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Convertit une tranche d'octets en une tranche de chaîne sans vérifier que la chaîne contient UTF-8 valide.
///
/// Consultez la version sécurisée, [`from_utf8`], pour plus d'informations.
///
/// # Safety
///
/// Cette fonction n'est pas sûre car elle ne vérifie pas que les octets qui lui sont passés sont valides UTF-8.
/// Si cette contrainte est violée, un comportement indéfini se produit, car le reste de Rust suppose que les [`&str`] sont valides UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Utilisation de base:
///
/// ```
/// use std::str;
///
/// // quelques octets, dans un vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // SÉCURITÉ: l'appelant doit garantir que les octets `v` sont valides UTF-8.
    // S'appuie également sur `&str` et `&[u8]` ayant la même disposition.
    unsafe { mem::transmute(v) }
}

/// Convertit une tranche d'octets en une tranche de chaîne sans vérifier que la chaîne contient UTF-8 valide;version mutable.
///
///
/// Voir la version immuable, [`from_utf8_unchecked()`] pour plus d'informations.
///
/// # Examples
///
/// Utilisation de base:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // SÉCURITÉ: l'appelant doit garantir que les octets `v`
    // sont valides UTF-8, donc la conversion en `*mut str` est sûre.
    // En outre, le déréférencement du pointeur est sûr car ce pointeur provient d'une référence dont la validité est garantie pour les écritures.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}