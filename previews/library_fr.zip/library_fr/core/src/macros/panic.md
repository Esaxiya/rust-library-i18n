Panics le thread actuel.

Cela permet à un programme de se terminer immédiatement et de fournir une rétroaction à l'appelant du programme.
`panic!` doit être utilisé lorsqu'un programme atteint un état irrécupérable.

Cette macro est le moyen idéal pour affirmer des conditions dans le code d'exemple et dans les tests.
`panic!` est étroitement liée à la méthode `unwrap` des énumérations [`Option`][ounwrap] et [`Result`][runwrap].
Les deux implémentations appellent `panic!` lorsqu'elles sont définies sur des variantes [`None`] ou [`Err`].

Lorsque vous utilisez `panic!()`, vous pouvez spécifier une charge utile de chaîne, qui est construite à l'aide de la syntaxe [`format!`].
Cette charge utile est utilisée lors de l'injection du panic dans le thread Rust appelant, provoquant entièrement le thread vers panic.

Le comportement du `std` hook par défaut, c'est-à-dire
le code qui s'exécute directement après l'appel du panic consiste à imprimer la charge utile du message sur `stderr` avec les informations file/line/column de l'appel `panic!()`.

Vous pouvez remplacer le panic hook à l'aide de [`std::panic::set_hook()`].
À l'intérieur du hook, un panic est accessible en tant que `&dyn Any + Send`, qui contient soit un `&str` soit un `String` pour les appels `panic!()` normaux.
Pour panic avec une valeur d'un autre type, [`panic_any`] peut être utilisé.

[`Result`] enum est souvent une meilleure solution pour récupérer des erreurs que d'utiliser la macro `panic!`.
Cette macro doit être utilisée pour éviter de continuer en utilisant des valeurs incorrectes, telles que celles provenant de sources externes.
Des informations détaillées sur la gestion des erreurs se trouvent dans le [book].

Voir aussi la macro [`compile_error!`], pour générer des erreurs lors de la compilation.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Implémentation actuelle

Si le thread principal panics, il terminera tous vos threads et terminera votre programme avec le code `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





