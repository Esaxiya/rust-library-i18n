#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // S'étend à `$crate::panic::panic_2015` ou `$crate::panic::panic_2021` selon l'édition de l'appelant.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Affirme que deux expressions sont égales l'une à l'autre (en utilisant [`PartialEq`]).
///
/// Sur panic, cette macro imprimera les valeurs des expressions avec leurs représentations de débogage.
///
///
/// Comme [`assert!`], cette macro a une deuxième forme, où un message panic personnalisé peut être fourni.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Les réemprunts ci-dessous sont intentionnels.
                    // Sans eux, l'emplacement de pile pour l'emprunt est initialisé avant même que les valeurs ne soient comparées, ce qui entraîne un ralentissement notable.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Les réemprunts ci-dessous sont intentionnels.
                    // Sans eux, l'emplacement de pile pour l'emprunt est initialisé avant même que les valeurs ne soient comparées, ce qui entraîne un ralentissement notable.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Affirme que deux expressions ne sont pas égales l'une à l'autre (en utilisant [`PartialEq`]).
///
/// Sur panic, cette macro imprimera les valeurs des expressions avec leurs représentations de débogage.
///
///
/// Comme [`assert!`], cette macro a une deuxième forme, où un message panic personnalisé peut être fourni.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Les réemprunts ci-dessous sont intentionnels.
                    // Sans eux, l'emplacement de pile pour l'emprunt est initialisé avant même que les valeurs ne soient comparées, ce qui entraîne un ralentissement notable.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Les réemprunts ci-dessous sont intentionnels.
                    // Sans eux, l'emplacement de pile pour l'emprunt est initialisé avant même que les valeurs ne soient comparées, ce qui entraîne un ralentissement notable.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Affirme qu'une expression booléenne est `true` au moment de l'exécution.
///
/// Cela appellera la macro [`panic!`] si l'expression fournie ne peut pas être évaluée en `true` au moment de l'exécution.
///
/// Comme [`assert!`], cette macro a également une deuxième version, où un message panic personnalisé peut être fourni.
///
/// # Uses
///
/// Contrairement à [`assert!`], les instructions `debug_assert!` ne sont activées que dans les versions non optimisées par défaut.
/// Une version optimisée n'exécutera pas les instructions `debug_assert!` à moins que `-C debug-assertions` ne soit passé au compilateur.
/// Cela rend `debug_assert!` utile pour les vérifications qui sont trop coûteuses pour être présentes dans une version de version, mais qui peuvent être utiles pendant le développement.
/// Le résultat de l'expansion de `debug_assert!` est toujours contrôlé de type.
///
/// Une assertion non vérifiée permet à un programme dans un état incohérent de continuer à s'exécuter, ce qui peut avoir des conséquences inattendues mais n'introduit pas de non-sécurité tant que cela ne se produit que dans un code sûr.
///
/// Le coût de performance des assertions, cependant, n'est pas mesurable en général.
/// Le remplacement de [`assert!`] par `debug_assert!` n'est donc encouragé qu'après un profilage approfondi, et surtout, uniquement en code sécurisé!
///
/// # Examples
///
/// ```
/// // le message panic pour ces assertions est la valeur stringifiée de l'expression donnée.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // une fonction très simple
/// debug_assert!(some_expensive_computation());
///
/// // affirmer avec un message personnalisé
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Affirme que deux expressions sont égales l'une à l'autre.
///
/// Sur panic, cette macro imprimera les valeurs des expressions avec leurs représentations de débogage.
///
/// Contrairement à [`assert_eq!`], les instructions `debug_assert_eq!` ne sont activées que dans les versions non optimisées par défaut.
/// Une version optimisée n'exécutera pas d'instructions `debug_assert_eq!` à moins que `-C debug-assertions` ne soit passé au compilateur.
/// Cela rend `debug_assert_eq!` utile pour les vérifications qui sont trop coûteuses pour être présentes dans une version de version, mais qui peuvent être utiles pendant le développement.
///
/// Le résultat de l'expansion de `debug_assert_eq!` est toujours contrôlé de type.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Affirme que deux expressions ne sont pas égales l'une à l'autre.
///
/// Sur panic, cette macro imprimera les valeurs des expressions avec leurs représentations de débogage.
///
/// Contrairement à [`assert_ne!`], les instructions `debug_assert_ne!` ne sont activées que dans les versions non optimisées par défaut.
/// Une version optimisée n'exécutera pas les instructions `debug_assert_ne!` à moins que `-C debug-assertions` ne soit passé au compilateur.
/// Cela rend `debug_assert_ne!` utile pour les vérifications qui sont trop coûteuses pour être présentes dans une version de version, mais qui peuvent être utiles pendant le développement.
///
/// Le résultat de l'expansion de `debug_assert_ne!` est toujours contrôlé de type.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Renvoie si l'expression donnée correspond à l'un des modèles donnés.
///
/// Comme dans une expression `match`, le modèle peut être éventuellement suivi de `if` et d'une expression de garde qui a accès aux noms liés par le modèle.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Décompresse un résultat ou propage son erreur.
///
/// L'opérateur `?` a été ajouté pour remplacer `try!` et doit être utilisé à la place.
/// De plus, `try` est un mot réservé dans Rust 2018, donc si vous devez l'utiliser, vous devrez utiliser le [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` correspond au [`Result`] donné.Dans le cas de la variante `Ok`, l'expression a la valeur de la valeur encapsulée.
///
/// Dans le cas de la variante `Err`, il récupère l'erreur interne.`try!` effectue ensuite la conversion à l'aide de `From`.
/// Cela permet une conversion automatique entre les erreurs spécialisées et les erreurs plus générales.
/// L'erreur qui en résulte est alors immédiatement renvoyée.
///
/// En raison du retour anticipé, `try!` ne peut être utilisé que dans les fonctions qui renvoient [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // La méthode préférée de retour rapide des erreurs
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // La méthode précédente de retour rapide des erreurs
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Ceci équivaut à:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Écrit les données formatées dans un tampon.
///
/// Cette macro accepte un 'writer', une chaîne de format et une liste d'arguments.
/// Les arguments seront formatés selon la chaîne de format spécifiée et le résultat sera transmis au rédacteur.
/// L'enregistreur peut être n'importe quelle valeur avec une méthode `write_fmt`;généralement cela vient d'une implémentation du [`fmt::Write`] ou du [`io::Write`] trait.
/// La macro renvoie tout ce que la méthode `write_fmt` renvoie;généralement un [`fmt::Result`] ou un [`io::Result`].
///
/// Voir [`std::fmt`] pour plus d'informations sur la syntaxe de la chaîne de format.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Un module peut importer à la fois `std::fmt::Write` et `std::io::Write` et appeler `write!` sur les objets implémentant l'un ou l'autre, car les objets n'implémentent généralement pas les deux.
///
/// Cependant, le module doit importer les traits qualifiés pour que leurs noms ne soient pas en conflit:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // utilise fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // utilise io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Cette macro peut également être utilisée dans les configurations `no_std`.
/// Dans une configuration `no_std`, vous êtes responsable des détails d'implémentation des composants.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Écrivez les données formatées dans un tampon, avec une nouvelle ligne ajoutée.
///
/// Sur toutes les plates-formes, la nouvelle ligne est le caractère LINE FEED (`\n`/`U+000A`) seul (pas de CARRIAGE RETURN (`\r`/`U+000D`) supplémentaire.
///
/// Pour plus d'informations, consultez [`write!`].Pour plus d'informations sur la syntaxe de la chaîne de format, consultez [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Un module peut importer à la fois `std::fmt::Write` et `std::io::Write` et appeler `write!` sur les objets implémentant l'un ou l'autre, car les objets n'implémentent généralement pas les deux.
/// Cependant, le module doit importer les traits qualifiés pour que leurs noms ne soient pas en conflit:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // utilise fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // utilise io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Indique un code inaccessible.
///
/// Cela est utile chaque fois que le compilateur ne peut pas déterminer que du code est inaccessible.Par example:
///
/// * Faites correspondre les bras avec les conditions de garde.
/// * Boucles qui se terminent dynamiquement.
/// * Itérateurs qui se terminent dynamiquement.
///
/// Si la détermination que le code est inaccessible s'avère incorrecte, le programme se termine immédiatement avec un [`panic!`].
///
/// La contrepartie dangereuse de cette macro est la fonction [`unreachable_unchecked`], qui provoquera un comportement indéfini si le code est atteint.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Ce sera toujours [`panic!`].
///
/// # Examples
///
/// Match bras:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // erreur de compilation en cas de commentaire
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // l'une des implémentations les plus pauvres de x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Indique un code non implémenté en paniquant avec un message de "not implemented".
///
/// Cela permet à votre code de vérifier le type, ce qui est utile si vous prototypez ou implémentez un trait qui nécessite plusieurs méthodes que vous ne prévoyez pas d'utiliser toutes.
///
/// La différence entre `unimplemented!` et [`todo!`] est que, bien que `todo!` transmette l'intention d'implémenter la fonctionnalité plus tard et que le message soit "not yet implemented", `unimplemented!` ne fait aucune déclaration de ce type.
/// Son message est "not implemented".
/// De plus, certains IDE marqueront "todo!" S.
///
/// # Panics
///
/// Ce sera toujours [`panic!`] car `unimplemented!` n'est qu'un raccourci pour `panic!` avec un message fixe et spécifique.
///
/// Comme `panic!`, cette macro a une deuxième forme pour afficher des valeurs personnalisées.
///
/// # Examples
///
/// Disons que nous avons un trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Nous voulons implémenter `Foo` pour 'MyStruct', mais pour une raison quelconque, il est logique d'implémenter la fonction `bar()`.
/// `baz()` et `qux()` devront encore être définis dans notre implémentation de `Foo`, mais nous pouvons utiliser `unimplemented!` dans leurs définitions pour permettre à notre code de se compiler.
///
/// Nous voulons toujours que notre programme s'arrête si les méthodes non implémentées sont atteintes.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Cela n'a aucun sens pour `baz` un `MyStruct`, nous n'avons donc aucune logique ici.
/////
///         // Cela affichera "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Nous avons une certaine logique ici, nous pouvons ajouter un message à non implémenté!pour afficher notre omission.
///         // Cela affichera: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Indique un code inachevé.
///
/// Cela peut être utile si vous effectuez un prototypage et que vous souhaitez simplement vérifier le type de votre code.
///
/// La différence entre [`unimplemented!`] et `todo!` est que, bien que `todo!` transmette l'intention d'implémenter la fonctionnalité plus tard et que le message soit "not yet implemented", `unimplemented!` ne fait aucune déclaration de ce type.
/// Son message est "not implemented".
/// De plus, certains IDE marqueront "todo!" S.
///
/// # Panics
///
/// Ce sera toujours [`panic!`].
///
/// # Examples
///
/// Voici un exemple de code en cours.Nous avons un trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Nous voulons implémenter `Foo` sur l'un de nos types, mais nous voulons également travailler d'abord uniquement sur `bar()`.Pour que notre code se compile, nous devons implémenter `baz()`, afin que nous puissions utiliser `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // la mise en œuvre va ici
///     }
///
///     fn baz(&self) {
///         // ne nous inquiétons pas de l'implémentation de baz() pour le moment
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // nous n'utilisons même pas baz(), donc c'est très bien.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Définitions des macros intégrées.
///
/// La plupart des propriétés de macro (stabilité, visibilité, etc.) sont tirées du code source ici, à l'exception des fonctions d'expansion transformant les entrées de macro en sorties, ces fonctions sont fournies par le compilateur.
///
///
pub(crate) mod builtin {

    /// Provoque l'échec de la compilation avec le message d'erreur donné lorsqu'il est rencontré.
    ///
    /// Cette macro doit être utilisée lorsqu'un crate utilise une stratégie de compilation conditionnelle pour fournir de meilleurs messages d'erreur en cas de conditions erronées.
    ///
    /// C'est la forme au niveau du compilateur de [`panic!`], mais émet une erreur pendant la *compilation* plutôt qu'au *runtime*.
    ///
    /// # Examples
    ///
    /// Deux de ces exemples sont les macros et les environnements `#[cfg]`.
    ///
    /// Émettre une meilleure erreur de compilation si une macro reçoit des valeurs non valides.
    /// Sans le branch final, le compilateur émettrait toujours une erreur, mais le message d'erreur ne mentionnerait pas les deux valeurs valides.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Émet une erreur du compilateur si l'une des nombreuses fonctionnalités n'est pas disponible.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Construit des paramètres pour les autres macros de formatage de chaîne.
    ///
    /// Cette macro fonctionne en prenant une chaîne de formatage littérale contenant `{}` pour chaque argument supplémentaire passé.
    /// `format_args!` prépare les paramètres supplémentaires pour garantir que la sortie peut être interprétée comme une chaîne et canonise les arguments en un seul type.
    /// Toute valeur qui implémente le [`Display`] trait peut être transmise à `format_args!`, de même que toute implémentation [`Debug`] peut être transmise à un `{:?}` dans la chaîne de formatage.
    ///
    ///
    /// Cette macro produit une valeur de type [`fmt::Arguments`].Cette valeur peut être transmise aux macros dans [`std::fmt`] pour effectuer une redirection utile.
    /// Toutes les autres macros de formatage ([`format!`], [`write!`], [`println!`], etc.) sont envoyées par proxy via celle-ci.
    /// `format_args!`, contrairement à ses macros dérivées, évite les allocations de tas.
    ///
    /// Vous pouvez utiliser la valeur [`fmt::Arguments`] que `format_args!` renvoie dans les contextes `Debug` et `Display` comme indiqué ci-dessous.
    /// L'exemple montre également que `Debug` et `Display` formatent la même chose: la chaîne de format interpolée dans `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Pour plus d'informations, consultez la documentation de [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Identique à `format_args`, mais ajoute une nouvelle ligne à la fin.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Inspecte une variable d'environnement au moment de la compilation.
    ///
    /// Cette macro s'étendra à la valeur de la variable d'environnement nommée au moment de la compilation, produisant une expression de type `&'static str`.
    ///
    ///
    /// Si la variable d'environnement n'est pas définie, une erreur de compilation sera émise.
    /// Pour ne pas émettre d'erreur de compilation, utilisez plutôt la macro [`option_env!`].
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Vous pouvez personnaliser le message d'erreur en passant une chaîne comme deuxième paramètre:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Si la variable d'environnement `documentation` n'est pas définie, vous obtiendrez l'erreur suivante:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Inspecte éventuellement une variable d'environnement au moment de la compilation.
    ///
    /// Si la variable d'environnement nommée est présente au moment de la compilation, elle se développera dans une expression de type `Option<&'static str>` dont la valeur est `Some` de la valeur de la variable d'environnement.
    /// Si la variable d'environnement n'est pas présente, cela s'étendra à `None`.
    /// Voir [`Option<T>`][Option] pour plus d'informations sur ce type.
    ///
    /// Une erreur de compilation n'est jamais émise lors de l'utilisation de cette macro, que la variable d'environnement soit présente ou non.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatène les identifiants en un seul identifiant.
    ///
    /// Cette macro prend n'importe quel nombre d'identificateurs séparés par des virgules et les concatène tous en un seul, donnant une expression qui est un nouvel identificateur.
    /// Notez que l'hygiène fait en sorte que cette macro ne peut pas capturer les variables locales.
    /// De plus, en règle générale, les macros ne sont autorisées que dans la position de l'élément, de l'instruction ou de l'expression.
    /// Cela signifie que si vous pouvez utiliser cette macro pour faire référence à des variables, fonctions ou modules existants, etc., vous ne pouvez pas en définir une nouvelle avec elle.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (new, fun, name) { }//non utilisable de cette façon!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatène les littéraux en une tranche de chaîne statique.
    ///
    /// Cette macro prend n'importe quel nombre de littéraux séparés par des virgules, ce qui donne une expression de type `&'static str` qui représente tous les littéraux concaténés de gauche à droite.
    ///
    ///
    /// Les littéraux entiers et à virgule flottante sont stringifiés afin d'être concaténés.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// S'étend au numéro de ligne sur lequel il a été appelé.
    ///
    /// Avec [`column!`] et [`file!`], ces macros fournissent des informations de débogage aux développeurs sur l'emplacement dans la source.
    ///
    /// L'expression développée a le type `u32` et est basée sur 1, de sorte que la première ligne de chaque fichier est évaluée à 1, la seconde à 2, etc.
    /// Ceci est cohérent avec les messages d'erreur des compilateurs courants ou des éditeurs populaires.
    /// La ligne renvoyée n'est *pas nécessairement* la ligne de l'invocation `line!` elle-même, mais plutôt la première invocation de macro menant à l'appel de la macro `line!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Se développe jusqu'au numéro de colonne auquel il a été appelé.
    ///
    /// Avec [`line!`] et [`file!`], ces macros fournissent des informations de débogage aux développeurs sur l'emplacement dans la source.
    ///
    /// L'expression développée a le type `u32` et est basée sur 1, de sorte que la première colonne de chaque ligne est évaluée à 1, la seconde à 2, etc.
    /// Ceci est cohérent avec les messages d'erreur des compilateurs courants ou des éditeurs populaires.
    /// La colonne retournée n'est *pas nécessairement* la ligne de l'invocation `column!` elle-même, mais plutôt la première invocation de macro menant à l'appel de la macro `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// S'étend au nom de fichier dans lequel il a été appelé.
    ///
    /// Avec [`line!`] et [`column!`], ces macros fournissent des informations de débogage aux développeurs sur l'emplacement dans la source.
    ///
    /// L'expression développée a le type `&'static str` et le fichier retourné n'est pas l'appel de la macro `file!` elle-même, mais plutôt le premier appel de macro menant à l'appel de la macro `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Stringifie ses arguments.
    ///
    /// Cette macro donnera une expression de type `&'static str` qui est la stringification de tous les tokens passés à la macro.
    /// Aucune restriction n'est placée sur la syntaxe de l'invocation de macro elle-même.
    ///
    /// Notez que les résultats étendus de l'entrée tokens peuvent changer dans future.Vous devez être prudent si vous comptez sur la sortie.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Inclut un fichier codé UTF-8 sous forme de chaîne.
    ///
    /// Le fichier est situé par rapport au fichier actuel (de la même manière que les modules sont trouvés).
    /// Le chemin fourni est interprété d'une manière spécifique à la plate-forme au moment de la compilation.
    /// Ainsi, par exemple, une invocation avec un chemin Windows contenant des barres obliques inverses `\` ne se compilerait pas correctement sur Unix.
    ///
    ///
    /// Cette macro donnera une expression de type `&'static str` qui est le contenu du fichier.
    ///
    /// # Examples
    ///
    /// Supposons qu'il y ait deux fichiers dans le même répertoire avec le contenu suivant:
    ///
    /// Fichier 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Fichier 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Compiler 'main.rs' et exécuter le binaire résultant imprimera "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Inclut un fichier comme référence à un tableau d'octets.
    ///
    /// Le fichier est situé par rapport au fichier actuel (de la même manière que les modules sont trouvés).
    /// Le chemin fourni est interprété d'une manière spécifique à la plate-forme au moment de la compilation.
    /// Ainsi, par exemple, une invocation avec un chemin Windows contenant des barres obliques inverses `\` ne se compilerait pas correctement sur Unix.
    ///
    ///
    /// Cette macro donnera une expression de type `&'static [u8; N]` qui est le contenu du fichier.
    ///
    /// # Examples
    ///
    /// Supposons qu'il y ait deux fichiers dans le même répertoire avec le contenu suivant:
    ///
    /// Fichier 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Fichier 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Compiler 'main.rs' et exécuter le binaire résultant imprimera "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Se développe en une chaîne qui représente le chemin d'accès du module actuel.
    ///
    /// Le chemin actuel du module peut être considéré comme la hiérarchie des modules menant au crate root.
    /// Le premier composant du chemin renvoyé est le nom du crate en cours de compilation.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Évalue les combinaisons booléennes d'indicateurs de configuration au moment de la compilation.
    ///
    /// En plus de l'attribut `#[cfg]`, cette macro est fournie pour permettre l'évaluation d'expression booléenne des indicateurs de configuration.
    /// Cela conduit souvent à moins de code dupliqué.
    ///
    /// La syntaxe donnée à cette macro est la même que celle de l'attribut [`cfg`].
    ///
    /// `cfg!`, contrairement à `#[cfg]`, ne supprime aucun code et évalue uniquement vrai ou faux.
    /// Par exemple, tous les blocs d'une expression if/else doivent être valides lorsque `cfg!` est utilisé pour la condition, indépendamment de ce que `cfg!` évalue.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Analyse un fichier comme une expression ou un élément en fonction du contexte.
    ///
    /// Le fichier est situé par rapport au fichier actuel (de la même manière que les modules sont trouvés).Le chemin fourni est interprété d'une manière spécifique à la plate-forme au moment de la compilation.
    /// Ainsi, par exemple, une invocation avec un chemin Windows contenant des barres obliques inverses `\` ne se compilerait pas correctement sur Unix.
    ///
    /// L'utilisation de cette macro est souvent une mauvaise idée, car si le fichier est analysé en tant qu'expression, il sera placé dans le code environnant de manière non hygiénique.
    /// Cela pourrait entraîner des variables ou des fonctions différentes de ce que le fichier attendait s'il y a des variables ou des fonctions qui ont le même nom dans le fichier actuel.
    ///
    ///
    /// # Examples
    ///
    /// Supposons qu'il y ait deux fichiers dans le même répertoire avec le contenu suivant:
    ///
    /// Fichier 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Fichier 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Compiler 'main.rs' et exécuter le binaire résultant affichera "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Affirme qu'une expression booléenne est `true` au moment de l'exécution.
    ///
    /// Cela appellera la macro [`panic!`] si l'expression fournie ne peut pas être évaluée en `true` au moment de l'exécution.
    ///
    /// # Uses
    ///
    /// Les assertions sont toujours vérifiées dans les versions de débogage et de version, et ne peuvent pas être désactivées.
    /// Consultez [`debug_assert!`] pour les assertions qui ne sont pas activées par défaut dans les versions de version.
    ///
    /// Un code non sécurisé peut s'appuyer sur `assert!` pour appliquer des invariants d'exécution qui, s'ils sont violés, peuvent conduire à une non-sécurité.
    ///
    /// D'autres cas d'utilisation de `assert!` incluent le test et l'application des invariants d'exécution dans le code sécurisé (dont la violation ne peut pas entraîner de non-sécurité).
    ///
    ///
    /// # Messages personnalisés
    ///
    /// Cette macro a une deuxième forme, où un message panic personnalisé peut être fourni avec ou sans arguments pour la mise en forme.
    /// Voir [`std::fmt`] pour la syntaxe de ce formulaire.
    /// Les expressions utilisées comme arguments de format ne seront évaluées que si l'assertion échoue.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // le message panic pour ces assertions est la valeur stringifiée de l'expression donnée.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // une fonction très simple
    ///
    /// assert!(some_computation());
    ///
    /// // affirmer avec un message personnalisé
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Assemblage en ligne.
    ///
    /// Lisez le [unstable book] pour l'utilisation.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Assemblage en ligne de style LLVM.
    ///
    /// Lisez le [unstable book] pour l'utilisation.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Assemblage en ligne au niveau du module.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Les impressions ont passé tokens dans la sortie standard.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Active ou désactive la fonctionnalité de traçage utilisée pour le débogage d'autres macros.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Macro d'attribut utilisée pour appliquer des macros de dérivation.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Macro d'attribut appliquée à une fonction pour en faire un test unitaire.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Macro d'attribut appliquée à une fonction pour en faire un test de référence.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Un détail d'implémentation des macros `#[test]` et `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Macro d'attribut appliquée à un statique pour l'enregistrer en tant qu'allocateur global.
    ///
    /// Voir également [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Conserve l'élément auquel il est appliqué si le chemin transmis est accessible et le supprime dans le cas contraire.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Développe tous les attributs `#[cfg]` et `#[cfg_attr]` dans le fragment de code auquel il est appliqué.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Détail d'implémentation instable du compilateur `rustc`, ne pas utiliser.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Détail d'implémentation instable du compilateur `rustc`, ne pas utiliser.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}