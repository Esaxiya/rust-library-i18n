//! Le `Clone` trait pour les types qui ne peuvent pas être «copiés implicitement».
//!
//! Dans Rust, certains types simples sont "implicitly copyable" et lorsque vous les attribuez ou les passez en tant qu'arguments, le récepteur en recevra une copie, laissant la valeur d'origine en place.
//! Ces types ne nécessitent pas d'allocation pour copier et n'ont pas de finaliseurs (c'est-à-dire qu'ils ne contiennent pas de boîtes possédées ou n'implémentent pas [`Drop`]), de sorte que le compilateur les considère peu coûteux et sûrs à copier.
//!
//! Pour les autres types, les copies doivent être faites explicitement, par convention implémentant le [`Clone`] trait et appelant la méthode [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Exemple d'utilisation de base:
//!
//! ```
//! let s = String::new(); // Le type de chaîne implémente le clonage
//! let copy = s.clone(); // afin que nous puissions le cloner
//! ```
//!
//! Pour implémenter facilement le Clone trait, vous pouvez également utiliser `#[derive(Clone)]`.Exemple:
//!
//! ```
//! #[derive(Clone)] // on ajoute le Clone trait à la structure Morpheus
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // et maintenant nous pouvons le cloner!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Un trait commun pour la possibilité de dupliquer explicitement un objet.
///
/// Diffère de [`Copy`] en ce que [`Copy`] est implicite et extrêmement peu coûteux, tandis que `Clone` est toujours explicite et peut ou non être coûteux.
/// Afin d'appliquer ces caractéristiques, Rust ne vous permet pas de réimplémenter [`Copy`], mais vous pouvez réimplémenter `Clone` et exécuter du code arbitraire.
///
/// Puisque `Clone` est plus général que [`Copy`], vous pouvez automatiquement faire de tout [`Copy`] un `Clone`.
///
/// ## Derivable
///
/// Ce trait peut être utilisé avec `#[derive]` si tous les champs sont `Clone`.L'implémentation `derive`d de [`Clone`] appelle [`clone`] sur chaque champ.
///
/// [`clone`]: Clone::clone
///
/// Pour une structure générique, `#[derive]` implémente `Clone` de manière conditionnelle en ajoutant `Clone` lié sur des paramètres génériques.
///
/// ```
/// // `derive` implémente Clone pour la lecture<T>lorsque T est Clone.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Comment puis-je implémenter `Clone`?
///
/// Les types qui sont [`Copy`] devraient avoir une implémentation triviale de `Clone`.Plus formellement:
/// si `T: Copy`, `x: T` et `y: &T`, alors `let x = y.clone();` est équivalent à `let x = *y;`.
/// Les implémentations manuelles doivent veiller à respecter cet invariant;cependant, le code non sécurisé ne doit pas s'y fier pour garantir la sécurité de la mémoire.
///
/// Un exemple est une structure générique contenant un pointeur de fonction.Dans ce cas, l'implémentation de `Clone` ne peut pas être `derive`d, mais peut être implémentée comme:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Implémenteurs supplémentaires
///
/// En plus du [implementors listed below][impls], les types suivants implémentent également `Clone`:
///
/// * Types d'éléments de fonction (c'est-à-dire les types distincts définis pour chaque fonction)
/// * Types de pointeurs de fonction (par exemple, `fn() -> i32`)
/// * Types de tableaux, pour toutes les tailles, si le type d'élément implémente également `Clone` (par exemple, `[i32; 123456]`)
/// * Types de tuples, si chaque composant implémente également `Clone` (par exemple, `()`, `(i32, bool)`)
/// * Les types de fermeture, s'ils ne capturent aucune valeur de l'environnement ou si toutes ces valeurs capturées implémentent `Clone` elles-mêmes.
///   Notez que les variables capturées par une référence partagée implémentent toujours `Clone` (même si le référent ne le fait pas), tandis que les variables capturées par une référence mutable n'implémentent jamais `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Renvoie une copie de la valeur.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str implémente Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Effectue l'affectation de copie à partir de `source`.
    ///
    /// `a.clone_from(&b)` équivaut à `a = b.clone()` en fonctionnalité, mais peut être remplacé pour réutiliser les ressources de `a` afin d'éviter des allocations inutiles.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Dériver une macro générant un impl du trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): ces structures sont utilisées uniquement par#[derive] pour affirmer que chaque composant d'un type implémente Clone ou Copy.
//
//
// Ces structures ne doivent jamais apparaître dans le code utilisateur.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Implémentations de `Clone` pour les types primitifs.
///
/// Les implémentations qui ne peuvent pas être décrites dans Rust sont implémentées dans `traits::SelectionContext::copy_clone_conditions()` dans `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Les références partagées peuvent être clonées, mais les références mutables *ne peuvent pas*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Les références partagées peuvent être clonées, mais les références mutables *ne peuvent pas*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}