#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// Un `RawWaker` permet à l'implémenteur d'un exécuteur de tâches de créer un [`Waker`] qui fournit un comportement de réveil personnalisé.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Il se compose d'un pointeur de données et d'un [virtual function pointer table (vtable)][vtable] qui personnalise le comportement du `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Un pointeur de données, qui peut être utilisé pour stocker des données arbitraires selon les besoins de l'exécuteur.
    /// Cela pourrait être par exemple
    /// un pointeur effacé vers un `Arc` associé à la tâche.
    /// La valeur de ce champ est transmise à toutes les fonctions qui font partie de la vtable en tant que premier paramètre.
    ///
    data: *const (),
    /// Table de pointeur de fonction virtuelle qui personnalise le comportement de ce waker.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Crée un nouveau `RawWaker` à partir du pointeur `data` et du `vtable` fournis.
    ///
    /// Le pointeur `data` peut être utilisé pour stocker des données arbitraires comme requis par l'exécuteur.Cela pourrait être par exemple
    /// un pointeur effacé vers un `Arc` associé à la tâche.
    /// La valeur de ce pointeur sera transmise à toutes les fonctions qui font partie du `vtable` en tant que premier paramètre.
    ///
    /// Le `vtable` personnalise le comportement d'un `Waker` qui est créé à partir d'un `RawWaker`.
    /// Pour chaque opération sur le `Waker`, la fonction associée dans le `vtable` du `RawWaker` sous-jacent sera appelée.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Une table de pointeur de fonction virtuelle (vtable) qui spécifie le comportement d'un [`RawWaker`].
///
/// Le pointeur passé à toutes les fonctions à l'intérieur de la vtable est le pointeur `data` de l'objet [`RawWaker`] englobant.
///
/// Les fonctions à l'intérieur de cette structure sont uniquement destinées à être appelées sur le pointeur `data` d'un objet [`RawWaker`] correctement construit à partir de l'implémentation [`RawWaker`].
/// L'appel de l'une des fonctions contenues à l'aide de n'importe quel autre pointeur `data` entraînera un comportement indéfini.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Cette fonction sera appelée lorsque le [`RawWaker`] sera cloné, par exemple lorsque le [`Waker`] dans lequel le [`RawWaker`] est stocké sera cloné.
    ///
    /// L'implémentation de cette fonction doit conserver toutes les ressources requises pour cette instance supplémentaire d'un [`RawWaker`] et la tâche associée.
    /// L'appel de `wake` sur le [`RawWaker`] résultant devrait entraîner un réveil de la même tâche qui aurait été réveillée par le [`RawWaker`] d'origine.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Cette fonction sera appelée lorsque `wake` sera appelé sur le [`Waker`].
    /// Il doit réveiller la tâche associée à ce [`RawWaker`].
    ///
    /// L'implémentation de cette fonction doit veiller à libérer toutes les ressources associées à cette instance d'un [`RawWaker`] et à la tâche associée.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Cette fonction sera appelée lorsque `wake_by_ref` sera appelé sur le [`Waker`].
    /// Il doit réveiller la tâche associée à ce [`RawWaker`].
    ///
    /// Cette fonction est similaire à `wake`, mais ne doit pas consommer le pointeur de données fourni.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Cette fonction est appelée lorsqu'un [`RawWaker`] est abandonné.
    ///
    /// L'implémentation de cette fonction doit veiller à libérer toutes les ressources associées à cette instance d'un [`RawWaker`] et à la tâche associée.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Crée un nouveau `RawWakerVTable` à partir des fonctions `clone`, `wake`, `wake_by_ref` et `drop` fournies.
    ///
    /// # `clone`
    ///
    /// Cette fonction sera appelée lorsque le [`RawWaker`] sera cloné, par exemple lorsque le [`Waker`] dans lequel le [`RawWaker`] est stocké sera cloné.
    ///
    /// L'implémentation de cette fonction doit conserver toutes les ressources requises pour cette instance supplémentaire d'un [`RawWaker`] et la tâche associée.
    /// L'appel de `wake` sur le [`RawWaker`] résultant devrait entraîner un réveil de la même tâche qui aurait été réveillée par le [`RawWaker`] d'origine.
    ///
    /// # `wake`
    ///
    /// Cette fonction sera appelée lorsque `wake` sera appelé sur le [`Waker`].
    /// Il doit réveiller la tâche associée à ce [`RawWaker`].
    ///
    /// L'implémentation de cette fonction doit veiller à libérer toutes les ressources associées à cette instance d'un [`RawWaker`] et à la tâche associée.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Cette fonction sera appelée lorsque `wake_by_ref` sera appelé sur le [`Waker`].
    /// Il doit réveiller la tâche associée à ce [`RawWaker`].
    ///
    /// Cette fonction est similaire à `wake`, mais ne doit pas consommer le pointeur de données fourni.
    ///
    /// # `drop`
    ///
    /// Cette fonction est appelée lorsqu'un [`RawWaker`] est abandonné.
    ///
    /// L'implémentation de cette fonction doit veiller à libérer toutes les ressources associées à cette instance d'un [`RawWaker`] et à la tâche associée.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// Le `Context` d'une tâche asynchrone.
///
/// Actuellement, `Context` ne sert qu'à donner accès à un `&Waker` qui peut être utilisé pour réveiller la tâche en cours.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Assurez-vous que nous sommes à l'épreuve de future contre les changements de variance en forçant la durée de vie à être invariante (les durées de la position des arguments sont contravariantes tandis que les durées de la position de retour sont covariantes).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Créez un nouveau `Context` à partir d'un `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Renvoie une référence au `Waker` pour la tâche en cours.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// Un `Waker` est un handle pour réveiller une tâche en notifiant son exécuteur qu'il est prêt à être exécuté.
///
/// Ce handle encapsule une instance [`RawWaker`], qui définit le comportement de réveil spécifique à l'exécuteur.
///
///
/// Implémente [`Clone`], [`Send`] et [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Réveillez la tâche associée à ce `Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // L'appel de réveil réel est délégué via un appel de fonction virtuelle à l'implémentation qui est définie par l'exécuteur.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // N'appelez pas `drop`-le waker sera consommé par `wake`.
        crate::mem::forget(self);

        // SÉCURITÉ: Ceci est sûr car `Waker::from_raw` est le seul moyen
        // pour initialiser `wake` et `data` obligeant l'utilisateur à reconnaître que le contrat de `RawWaker` est respecté.
        //
        unsafe { (wake)(data) };
    }

    /// Réveillez la tâche associée à ce `Waker` sans consommer le `Waker`.
    ///
    /// Ceci est similaire à `wake`, mais peut être légèrement moins efficace dans le cas où un `Waker` possédé est disponible.
    /// Cette méthode doit être préférée à l'appel de `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // L'appel de réveil réel est délégué via un appel de fonction virtuelle à l'implémentation qui est définie par l'exécuteur.
        //

        // SÉCURITÉ: voir `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Renvoie `true` si ce `Waker` et un autre `Waker` ont réveillé la même tâche.
    ///
    /// Cette fonction fonctionne au mieux, et peut retourner false même lorsque le `Waker`s réveillerait la même tâche.
    /// Cependant, si cette fonction renvoie `true`, il est garanti que les `Waker`s réveilleront la même tâche.
    ///
    /// Cette fonction est principalement utilisée à des fins d'optimisation.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Crée un nouveau `Waker` à partir de [`RawWaker`].
    ///
    /// Le comportement du `Waker` renvoyé n'est pas défini si le contrat défini dans la documentation de [`RawWaker`] et de [`RawWakerVTable`] n'est pas respecté.
    ///
    /// Par conséquent, cette méthode n'est pas sûre.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // SÉCURITÉ: Ceci est sûr car `Waker::from_raw` est le seul moyen
            // pour initialiser `clone` et `data` obligeant l'utilisateur à reconnaître que le contrat de [`RawWaker`] est respecté.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // SÉCURITÉ: Ceci est sûr car `Waker::from_raw` est le seul moyen
        // pour initialiser `drop` et `data` obligeant l'utilisateur à reconnaître que le contrat de `RawWaker` est respecté.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}