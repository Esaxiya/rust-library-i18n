// ignore-tidy-filelength Ce fichier se compose presque exclusivement de la définition de `Iterator`.
// Nous ne pouvons pas diviser cela en plusieurs fichiers.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Une interface pour traiter les itérateurs.
///
/// C'est l'itérateur principal trait.
/// Pour en savoir plus sur le concept des itérateurs en général, veuillez consulter le [module-level documentation].
/// En particulier, vous voudrez peut-être savoir comment utiliser [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Le type des éléments sur lesquels l'itération est effectuée.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Avance l'itérateur et renvoie la valeur suivante.
    ///
    /// Renvoie [`None`] lorsque l'itération est terminée.
    /// Les implémentations d'itérateur individuelles peuvent choisir de reprendre l'itération, et donc appeler à nouveau `next()` peut éventuellement recommencer à renvoyer [`Some(Item)`] à un moment donné.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Un appel à next() renvoie la valeur suivante ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... et puis None une fois que c'est fini.
    /// assert_eq!(None, iter.next());
    ///
    /// // Plus d'appels peuvent renvoyer ou non `None`.Ici, ils le feront toujours.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Renvoie les limites de la longueur restante de l'itérateur.
    ///
    /// Plus précisément, `size_hint()` renvoie un tuple où le premier élément est la limite inférieure et le deuxième élément est la limite supérieure.
    ///
    /// La seconde moitié du tuple retourné est une [`Option`]`<`[`usize`] `>`.
    /// Un [`None`] signifie ici soit qu'il n'y a pas de limite supérieure connue, soit que la limite supérieure est plus grande que [`usize`].
    ///
    /// # Notes de mise en œuvre
    ///
    /// Il n'est pas forcé qu'une implémentation d'itérateur donne le nombre déclaré d'éléments.Un itérateur bogué peut donner moins que la limite inférieure ou plus que la limite supérieure des éléments.
    ///
    /// `size_hint()` est principalement destiné à être utilisé pour des optimisations telles que la réservation d'espace pour les éléments de l'itérateur, mais ne doit pas être fiable pour, par exemple, omettre les vérifications de limites dans le code non sécurisé.
    /// Une implémentation incorrecte de `size_hint()` ne doit pas conduire à des violations de la sécurité de la mémoire.
    ///
    /// Cela dit, l'implémentation doit fournir une estimation correcte, car sinon ce serait une violation du protocole de trait.
    ///
    /// L'implémentation par défaut renvoie `(0,` [`None`]`)`ce qui est correct pour n'importe quel itérateur.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Un exemple plus complexe:
    ///
    /// ```
    /// // Les nombres pairs de zéro à dix.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Nous pourrions itérer de zéro à dix fois.
    /// // Savoir qu'il est exactement cinq ne serait pas possible sans exécuter filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Ajoutons cinq autres nombres avec chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // maintenant les deux bornes sont augmentées de cinq
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Retour de `None` pour une limite supérieure:
    ///
    /// ```
    /// // un itérateur infini n'a pas de limite supérieure et la limite inférieure maximale possible
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Consomme l'itérateur, en comptant le nombre d'itérations et en le renvoyant.
    ///
    /// Cette méthode appellera [`next`] à plusieurs reprises jusqu'à ce que [`None`] soit rencontré, renvoyant le nombre de fois où elle a vu [`Some`].
    /// Notez que [`next`] doit être appelé au moins une fois même si l'itérateur ne contient aucun élément.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Comportement de débordement
    ///
    /// La méthode ne protège pas contre les débordements, donc compter les éléments d'un itérateur avec plus de [`usize::MAX`] éléments produit soit le mauvais résultat, soit panics.
    ///
    /// Si les assertions de débogage sont activées, un panic est garanti.
    ///
    /// # Panics
    ///
    /// Cette fonction peut panic si l'itérateur a plus de [`usize::MAX`] éléments.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Consomme l'itérateur, renvoyant le dernier élément.
    ///
    /// Cette méthode évaluera l'itérateur jusqu'à ce qu'il renvoie [`None`].
    /// Ce faisant, il garde la trace de l'élément actuel.
    /// Une fois [`None`] renvoyé, `last()` renverra alors le dernier élément qu'il a vu.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Avance l'itérateur par éléments `n`.
    ///
    /// Cette méthode sautera avec empressement les éléments `n` en appelant [`next`] jusqu'à `n` fois jusqu'à ce que [`None`] soit rencontré.
    ///
    /// `advance_by(n)` retournera [`Ok(())`][Ok] si l'itérateur avance avec succès par les éléments `n`, ou [`Err(k)`][Err] si [`None`] est rencontré, où `k` est le nombre d'éléments par lesquels l'itérateur est avancé avant de manquer d'éléments (c.-à-d.
    /// la longueur de l'itérateur).
    /// Notez que `k` est toujours inférieur à `n`.
    ///
    /// L'appel de `advance_by(0)` ne consomme aucun élément et renvoie toujours [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // seul `&4` a été ignoré
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Renvoie le `n`ième élément de l'itérateur.
    ///
    /// Comme la plupart des opérations d'indexation, le décompte commence à zéro, donc `nth(0)` renvoie la première valeur, `nth(1)` la seconde, et ainsi de suite.
    ///
    /// Notez que tous les éléments précédents, ainsi que l'élément retourné, seront consommés à partir de l'itérateur.
    /// Cela signifie que les éléments précédents seront ignorés et que l'appel de `nth(0)` plusieurs fois sur le même itérateur renverra des éléments différents.
    ///
    ///
    /// `nth()` renverra [`None`] si `n` est supérieur ou égal à la longueur de l'itérateur.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Appeler `nth()` plusieurs fois ne rembobine pas l'itérateur:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Renvoi de `None` s'il y a moins de `n + 1` éléments:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Crée un itérateur commençant au même point, mais progressant du montant donné à chaque itération.
    ///
    /// Remarque 1: Le premier élément de l'itérateur sera toujours renvoyé, quelle que soit l'étape donnée.
    ///
    /// Remarque 2: l'heure à laquelle les éléments ignorés sont tirés n'est pas fixe.
    /// `StepBy` se comporte comme la séquence `next(), nth(step-1), nth(step-1),…`, mais est également libre de se comporter comme la séquence
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// La méthode utilisée peut changer pour certains itérateurs pour des raisons de performances.
    /// La deuxième méthode fera avancer l'itérateur plus tôt et peut consommer plus d'éléments.
    ///
    /// `advance_n_and_return_first` est l'équivalent de:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// La méthode panic si le pas donné est `0`.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Prend deux itérateurs et crée un nouvel itérateur sur les deux en séquence.
    ///
    /// `chain()` renverra un nouvel itérateur qui effectuera d'abord une itération sur les valeurs du premier itérateur, puis sur les valeurs du deuxième itérateur.
    ///
    /// En d'autres termes, il relie deux itérateurs ensemble, dans une chaîne.🔗
    ///
    /// [`once`] est couramment utilisé pour adapter une valeur unique dans une chaîne d'autres types d'itérations.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Puisque l'argument de `chain()` utilise [`IntoIterator`], nous pouvons transmettre tout ce qui peut être converti en [`Iterator`], pas seulement un [`Iterator`] lui-même.
    /// Par exemple, les tranches (`&[T]`) implémentent [`IntoIterator`] et peuvent donc être transmises directement à `chain()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Si vous travaillez avec l'API Windows, vous souhaiterez peut-être convertir [`OsStr`] en `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// «Zippe» deux itérateurs en un seul itérateur de paires.
    ///
    /// `zip()` retourne un nouvel itérateur qui itérera sur deux autres itérateurs, retournant un tuple où le premier élément provient du premier itérateur et le second élément vient du second itérateur.
    ///
    ///
    /// En d'autres termes, il zippe deux itérateurs ensemble, en un seul.
    ///
    /// Si l'un des itérateurs renvoie [`None`], [`next`] de l'itérateur compressé renverra [`None`].
    /// Si le premier itérateur renvoie [`None`], `zip` court-circuitera et `next` ne sera pas appelé sur le deuxième itérateur.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Puisque l'argument de `zip()` utilise [`IntoIterator`], nous pouvons transmettre tout ce qui peut être converti en [`Iterator`], pas seulement un [`Iterator`] lui-même.
    /// Par exemple, les tranches (`&[T]`) implémentent [`IntoIterator`] et peuvent donc être transmises directement à `zip()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` est souvent utilisé pour compresser un itérateur infini en un itérateur fini.
    /// Cela fonctionne parce que l'itérateur fini renverra finalement [`None`], mettant fin à la fermeture à glissière.La compression avec `(0..)` peut ressembler beaucoup à [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Crée un nouvel itérateur qui place une copie de `separator` entre les éléments adjacents de l'itérateur d'origine.
    ///
    /// Dans le cas où `separator` n'implémente pas [`Clone`] ou doit être calculé à chaque fois, utilisez [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Le premier élément de `a`.
    /// assert_eq!(a.next(), Some(&100)); // Le séparateur.
    /// assert_eq!(a.next(), Some(&1));   // L'élément suivant de `a`.
    /// assert_eq!(a.next(), Some(&100)); // Le séparateur.
    /// assert_eq!(a.next(), Some(&2));   // Le dernier élément de `a`.
    /// assert_eq!(a.next(), None);       // L'itérateur est terminé.
    /// ```
    ///
    /// `intersperse` peut être très utile pour joindre les éléments d'un itérateur en utilisant un élément commun:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Crée un nouvel itérateur qui place un élément généré par `separator` entre des éléments adjacents de l'itérateur d'origine.
    ///
    /// La fermeture sera appelée exactement une fois à chaque fois qu'un élément est placé entre deux éléments adjacents de l'itérateur sous-jacent;
    /// spécifiquement, la fermeture n'est pas appelée si l'itérateur sous-jacent produit moins de deux éléments et après le dernier élément.
    ///
    ///
    /// Si l'élément de l'itérateur implémente [`Clone`], il peut être plus facile d'utiliser [`intersperse`].
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Le premier élément de `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Le séparateur.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // L'élément suivant de `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Le séparateur.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Le dernier élément de `v`.
    /// assert_eq!(it.next(), None);               // L'itérateur est terminé.
    /// ```
    ///
    /// `intersperse_with` peut être utilisé dans les situations où le séparateur doit être calculé:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // La fermeture emprunte mutuellement son contexte pour générer un élément.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Prend une fermeture et crée un itérateur qui appelle cette fermeture sur chaque élément.
    ///
    /// `map()` transforme un itérateur en un autre, au moyen de son argument:
    /// quelque chose qui implémente [`FnMut`].Il produit un nouvel itérateur qui appelle cette fermeture sur chaque élément de l'itérateur d'origine.
    ///
    /// Si vous êtes doué pour penser aux types, vous pouvez penser à `map()` comme ceci:
    /// Si vous avez un itérateur qui vous donne des éléments d'un certain type `A`, et que vous voulez un itérateur d'un autre type `B`, vous pouvez utiliser `map()`, en passant une fermeture qui prend un `A` et renvoie un `B`.
    ///
    ///
    /// `map()` est conceptuellement similaire à une boucle [`for`].Cependant, comme `map()` est paresseux, il est préférable de l'utiliser lorsque vous travaillez déjà avec d'autres itérateurs.
    /// Si vous faites une sorte de boucle pour un effet secondaire, il est considéré comme plus idiomatique d'utiliser [`for`] que `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Si vous faites une sorte d'effet secondaire, préférez [`for`] à `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // ne fais pas ça:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // il ne s'exécutera même pas, car il est paresseux.Rust vous en avertira.
    ///
    /// // À la place, utilisez pour:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Appelle une fermeture sur chaque élément d'un itérateur.
    ///
    /// Cela équivaut à utiliser une boucle [`for`] sur l'itérateur, bien que `break` et `continue` ne soient pas possibles à partir d'une fermeture.
    /// Il est généralement plus idiomatique d'utiliser une boucle `for`, mais `for_each` peut être plus lisible lors du traitement d'éléments à la fin de chaînes d'itérateurs plus longues.
    ///
    /// Dans certains cas, `for_each` peut également être plus rapide qu'une boucle, car il utilisera une itération interne sur des adaptateurs tels que `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Pour un si petit exemple, une boucle `for` peut être plus propre, mais `for_each` peut être préférable pour conserver un style fonctionnel avec des itérateurs plus longs:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Crée un itérateur qui utilise une fermeture pour déterminer si un élément doit être produit.
    ///
    /// Étant donné un élément, la fermeture doit renvoyer `true` ou `false`.L'itérateur retourné ne donnera que les éléments pour lesquels la fermeture renvoie true.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Étant donné que la fermeture passée à `filter()` prend une référence et que de nombreux itérateurs itèrent sur des références, cela conduit à une situation éventuellement déroutante, où le type de fermeture est une double référence:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // besoin de deux * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Il est courant d'utiliser à la place la déstructuration sur l'argument pour en supprimer un:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // les deux et *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ou les deux:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // deux &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// de ces couches.
    ///
    /// Notez que `iter.filter(f).next()` est équivalent à `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Crée un itérateur qui filtre et mappe à la fois.
    ///
    /// L'itérateur retourné ne renvoie que les «valeurs» pour lesquelles la fermeture fournie renvoie `Some(value)`.
    ///
    /// `filter_map` peut être utilisé pour rendre les chaînes de [`filter`] et [`map`] plus concises.
    /// L'exemple ci-dessous montre comment un `map().filter().map()` peut être raccourci en un seul appel à `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Voici le même exemple, mais avec [`filter`] et [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Crée un itérateur qui donne le nombre d'itérations en cours ainsi que la valeur suivante.
    ///
    /// L'itérateur retourné donne des paires `(i, val)`, où `i` est l'index actuel de l'itération et `val` est la valeur renvoyée par l'itérateur.
    ///
    ///
    /// `enumerate()` garde son compte comme un [`usize`].
    /// Si vous souhaitez compter par un entier de taille différente, la fonction [`zip`] fournit des fonctionnalités similaires.
    ///
    /// # Comportement de débordement
    ///
    /// La méthode ne protège pas contre les débordements, donc l'énumération de plus de [`usize::MAX`] éléments produit soit le mauvais résultat, soit panics.
    /// Si les assertions de débogage sont activées, un panic est garanti.
    ///
    /// # Panics
    ///
    /// L'itérateur renvoyé pourrait panic si l'index à renvoyer débordait d'un [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Crée un itérateur qui peut utiliser [`peek`] pour regarder l'élément suivant de l'itérateur sans le consommer.
    ///
    /// Ajoute une méthode [`peek`] à un itérateur.Consultez sa documentation pour plus d'informations.
    ///
    /// Notez que l'itérateur sous-jacent est toujours avancé lorsque [`peek`] est appelé pour la première fois: afin de récupérer l'élément suivant, [`next`] est appelé sur l'itérateur sous-jacent, d'où les effets secondaires (ie
    ///
    /// autre chose que la récupération de la valeur suivante) de la méthode [`next`] se produira.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() nous permet de voir dans le future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // nous pouvons peek() plusieurs fois, l'itérateur ne progressera pas
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // une fois l'itérateur terminé, peek() aussi
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Crée un itérateur qui [`skip`] s éléments basé sur un prédicat.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` prend une clôture comme argument.Il appellera cette fermeture sur chaque élément de l'itérateur et ignorera les éléments jusqu'à ce qu'il retourne `false`.
    ///
    /// Une fois `false` renvoyé, le travail `skip_while()`'s est terminé et le reste des éléments est renvoyé.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Étant donné que la fermeture passée à `skip_while()` prend une référence et que de nombreux itérateurs itèrent sur des références, cela conduit à une situation éventuellement déroutante, où le type de l'argument de fermeture est une double référence:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // besoin de deux * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Arrêt après un `false` initial:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // alors que cela aurait été faux, puisque nous avons déjà obtenu un faux, skip_while() n'est plus utilisé
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Crée un itérateur qui produit des éléments basés sur un prédicat.
    ///
    /// `take_while()` prend une clôture comme argument.Il appellera cette fermeture sur chaque élément de l'itérateur et produira des éléments pendant qu'il renvoie `true`.
    ///
    /// Une fois `false` renvoyé, le travail `take_while()`'s est terminé et le reste des éléments est ignoré.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Étant donné que la fermeture passée à `take_while()` prend une référence et que de nombreux itérateurs itèrent sur des références, cela conduit à une situation éventuellement déroutante, où le type de fermeture est une double référence:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // besoin de deux * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Arrêt après un `false` initial:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Nous avons plus d'éléments inférieurs à zéro, mais comme nous avons déjà un faux, take_while() n'est plus utilisé
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Parce que `take_while()` doit regarder la valeur afin de voir si elle doit être incluse ou non, les itérateurs de consommation verront qu'elle est supprimée:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// Le `3` n'est plus là, car il a été consommé afin de voir si l'itération devait s'arrêter, mais n'a pas été replacé dans l'itérateur.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Crée un itérateur qui produit à la fois des éléments basés sur un prédicat et des mappages.
    ///
    /// `map_while()` prend une clôture comme argument.
    /// Il appellera cette fermeture sur chaque élément de l'itérateur et produira des éléments pendant qu'il renvoie [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Voici le même exemple, mais avec [`take_while`] et [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Arrêt après un [`None`] initial:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Nous avons plus d'éléments qui pourraient tenir dans u32 (4, 5), mais `map_while` a renvoyé `None` pour `-3` (comme le `predicate` a renvoyé `None`) et `collect` s'arrête au premier `None` rencontré.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Parce que `map_while()` a besoin de regarder la valeur afin de voir si elle doit être incluse ou non, la consommation d'itérateurs verra qu'elle est supprimée:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// Le `-3` n'est plus là, car il a été consommé afin de voir si l'itération devait s'arrêter, mais n'a pas été replacé dans l'itérateur.
    ///
    /// Notez que contrairement à [`take_while`], cet itérateur n'est **pas** fusionné.
    /// Il n'est pas non plus spécifié ce que cet itérateur renvoie après le retour du premier [`None`].
    /// Si vous avez besoin d'un itérateur fusionné, utilisez [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Crée un itérateur qui ignore les premiers éléments `n`.
    ///
    /// Après avoir été consommés, le reste des éléments est cédé.
    /// Plutôt que de remplacer directement cette méthode, remplacez plutôt la méthode `nth`.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Crée un itérateur qui produit ses premiers éléments `n`.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` est souvent utilisé avec un itérateur infini, pour le rendre fini:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Si moins de `n` éléments sont disponibles, `take` se limitera à la taille de l'itérateur sous-jacent:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Un adaptateur d'itérateur similaire à [`fold`] qui contient l'état interne et produit un nouvel itérateur.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` prend deux arguments: une valeur initiale qui amorce l'état interne, et une fermeture avec deux arguments, le premier étant une référence mutable à l'état interne et le second un élément itérateur.
    ///
    /// La fermeture peut affecter à l'état interne pour partager l'état entre les itérations.
    ///
    /// Lors de l'itération, la fermeture sera appliquée à chaque élément de l'itérateur et la valeur de retour de la fermeture, un [`Option`], est fournie par l'itérateur.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // à chaque itération, nous multiplierons l'état par l'élément
    ///     *state = *state * x;
    ///
    ///     // alors, nous céderons la négation de l'état
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Crée un itérateur qui fonctionne comme une carte, mais aplatit la structure imbriquée.
    ///
    /// L'adaptateur [`map`] est très utile, mais uniquement lorsque l'argument de fermeture produit des valeurs.
    /// S'il produit un itérateur à la place, il y a une couche supplémentaire d'indirection.
    /// `flat_map()` supprimera cette couche supplémentaire tout seul.
    ///
    /// Vous pouvez considérer `flat_map(f)` comme l'équivalent sémantique de [`map`] ping, puis [`flatten`] ing comme dans `map(f).flatten()`.
    ///
    /// Une autre façon de penser à `flat_map()`: la fermeture de [`map`] renvoie un élément pour chaque élément, et la fermeture `flat_map()`'s renvoie un itérateur pour chaque élément.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() renvoie un itérateur
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Crée un itérateur qui aplatit la structure imbriquée.
    ///
    /// Ceci est utile lorsque vous avez un itérateur d'itérateurs ou un itérateur d'éléments qui peuvent être transformés en itérateurs et que vous souhaitez supprimer un niveau d'indirection.
    ///
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Cartographie puis aplatissement:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() renvoie un itérateur
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Vous pouvez également réécrire cela en termes de [`flat_map()`], ce qui est préférable dans ce cas car il exprime plus clairement l'intention:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() renvoie un itérateur
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// L'aplatissement ne supprime qu'un seul niveau d'imbrication à la fois:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// On voit ici que `flatten()` n'effectue pas d'aplatissement "deep".
    /// Au lieu de cela, un seul niveau d'imbrication est supprimé.Autrement dit, si vous `flatten()` un tableau tridimensionnel, le résultat sera bidimensionnel et non unidimensionnel.
    /// Pour obtenir une structure unidimensionnelle, vous devez à nouveau `flatten()`.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Crée un itérateur qui se termine après le premier [`None`].
    ///
    /// Une fois qu'un itérateur a renvoyé [`None`], les appels future peuvent ou non générer à nouveau [`Some(T)`].
    /// `fuse()` adapte un itérateur, garantissant qu'après avoir donné un [`None`], il retournera toujours [`None`] pour toujours.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// // un itérateur qui alterne entre Some et None
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // si c'est pair, Some(i32), sinon Aucun
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // nous pouvons voir notre itérateur aller et venir
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // cependant, une fois que nous le fusionnons ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // il renverra toujours `None` après la première fois.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Fait quelque chose avec chaque élément d'un itérateur, en transmettant la valeur.
    ///
    /// Lorsque vous utilisez des itérateurs, vous en enchaînez souvent plusieurs.
    /// Tout en travaillant sur un tel code, vous voudrez peut-être vérifier ce qui se passe à différentes parties du pipeline.Pour ce faire, insérez un appel à `inspect()`.
    ///
    /// Il est plus courant que `inspect()` soit utilisé comme outil de débogage que d'exister dans votre code final, mais les applications peuvent le trouver utile dans certaines situations lorsque des erreurs doivent être consignées avant d'être supprimées.
    ///
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // cette séquence d'itérateurs est complexe.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // ajoutons quelques appels inspect() pour enquêter sur ce qui se passe
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Cela imprimera:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Journalisation des erreurs avant de les supprimer:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Cela imprimera:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Emprunte un itérateur plutôt que de le consommer.
    ///
    /// Ceci est utile pour autoriser l'application d'adaptateurs d'itérateur tout en conservant la propriété de l'itérateur d'origine.
    ///
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // si nous essayons de l'utiliser à nouveau, cela ne fonctionnera pas.
    /// // La ligne suivante donne "erreur: utilisation de la valeur déplacée: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // essayons à nouveau
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // à la place, nous ajoutons un .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // maintenant c'est très bien:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Transforme un itérateur en collection.
    ///
    /// `collect()` peut prendre tout ce qui est itérable et le transformer en une collection pertinente.
    /// C'est l'une des méthodes les plus puissantes de la bibliothèque standard, utilisée dans divers contextes.
    ///
    /// Le modèle le plus basique dans lequel `collect()` est utilisé est de transformer une collection en une autre.
    /// Vous prenez une collection, appelez [`iter`] dessus, faites un tas de transformations, puis `collect()` à la fin.
    ///
    /// `collect()` peut également créer des instances de types qui ne sont pas des collections typiques.
    /// Par exemple, un [`String`] peut être construit à partir de [`char`] s, et un itérateur d'éléments [`Result<T, E>`][`Result`] peut être collecté dans `Result<Collection<T>, E>`.
    ///
    /// Consultez les exemples ci-dessous pour en savoir plus.
    ///
    /// Parce que `collect()` est si général, il peut causer des problèmes avec l'inférence de type.
    /// En tant que tel, `collect()` est l'une des rares fois où vous verrez la syntaxe affectueusement connue sous le nom de 'turbofish': `::<>`.
    /// Cela aide l'algorithme d'inférence à comprendre spécifiquement dans quelle collection vous essayez de collecter.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Notez que nous avions besoin du `: Vec<i32>` sur le côté gauche.C'est parce que nous pourrions collecter, par exemple, un [`VecDeque<T>`] à la place:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Utilisation du 'turbofish' au lieu d'annoter `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Parce que `collect()` ne se soucie que de ce dans quoi vous collectez, vous pouvez toujours utiliser un indice de type partiel, `_`, avec le turbo-poisson:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Utilisation de `collect()` pour créer un [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Si vous avez une liste de [`Résultat<T, E>`][`Result`] s, vous pouvez utiliser `collect()` pour voir si l'un d'entre eux a échoué:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // nous donne la première erreur
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // nous donne la liste des réponses
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Consomme un itérateur, créant deux collections à partir de celui-ci.
    ///
    /// Le prédicat passé à `partition()` peut renvoyer `true` ou `false`.
    /// `partition()` renvoie une paire, tous les éléments pour lesquels il a renvoyé `true` et tous les éléments pour lesquels il a renvoyé `false`.
    ///
    ///
    /// Voir également [`is_partitioned()`] et [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Réorganise les éléments de cet itérateur *en place* en fonction du prédicat donné, de sorte que tous ceux qui renvoient `true` précèdent tous ceux qui renvoient `false`.
    ///
    /// Renvoie le nombre d'éléments `true` trouvés.
    ///
    /// L'ordre relatif des éléments partitionnés n'est pas conservé.
    ///
    /// Voir également [`is_partitioned()`] et [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Partition en place entre les égales et les cotes
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: faut-il s'inquiéter du débordement du décompteLa seule façon d'avoir plus de
        // `usize::MAX` les références mutables sont avec les ZST, qui ne sont pas utiles pour partitionner ...

        // Ces fonctions de fermeture "factory" existent pour éviter la généricité dans `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Trouvez à plusieurs reprises le premier `false` et échangez-le avec le dernier `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Vérifie si les éléments de cet itérateur sont partitionnés selon le prédicat donné, de sorte que tous ceux qui renvoient `true` précèdent tous ceux qui renvoient `false`.
    ///
    ///
    /// Voir également [`partition()`] et [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Soit tous les éléments testent `true`, soit la première clause s'arrête à `false` et nous vérifions qu'il n'y a plus d'éléments `true` après cela.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Méthode d'itération qui applique une fonction tant qu'elle est renvoyée avec succès, produisant une seule valeur finale.
    ///
    /// `try_fold()` prend deux arguments: une valeur initiale et une fermeture avec deux arguments: un 'accumulator' et un élément.
    /// La fermeture est renvoyée avec succès, avec la valeur que l'accumulateur devrait avoir pour l'itération suivante, ou elle renvoie un échec, avec une valeur d'erreur qui est immédiatement renvoyée à l'appelant (short-circuiting).
    ///
    ///
    /// La valeur initiale est la valeur que l'accumulateur aura lors du premier appel.Si l'application de la fermeture a réussi sur chaque élément de l'itérateur, `try_fold()` renvoie l'accumulateur final comme un succès.
    ///
    /// Le pliage est utile chaque fois que vous avez une collection de quelque chose et que vous souhaitez en produire une valeur unique.
    ///
    /// # Note aux réalisateurs
    ///
    /// Plusieurs des autres méthodes (forward) ont des implémentations par défaut en termes de celle-ci, alors essayez de l'implémenter explicitement si elle peut faire quelque chose de mieux que l'implémentation de la boucle `for` par défaut.
    ///
    /// En particulier, essayez d'avoir cet appel `try_fold()` sur les parties internes à partir desquelles cet itérateur est composé.
    /// Si plusieurs appels sont nécessaires, l'opérateur `?` peut être pratique pour enchaîner la valeur de l'accumulateur, mais méfiez-vous des invariants qui doivent être respectés avant ces retours anticipés.
    /// Il s'agit d'une méthode `&mut self`, donc l'itération doit être reprise après avoir rencontré une erreur ici.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // la somme vérifiée de tous les éléments du tableau
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Cette somme déborde lors de l'ajout de l'élément 100
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Parce qu'il a court-circuité, les éléments restants sont toujours disponibles via l'itérateur.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Méthode d'itérateur qui applique une fonction faillible à chaque élément de l'itérateur, s'arrêtant à la première erreur et renvoyant cette erreur.
    ///
    ///
    /// Cela peut également être considéré comme la forme faillible de [`for_each()`] ou comme la version sans état de [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Il a court-circuité, donc les éléments restants sont toujours dans l'itérateur:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Plie chaque élément dans un accumulateur en appliquant une opération, renvoyant le résultat final.
    ///
    /// `fold()` prend deux arguments: une valeur initiale et une fermeture avec deux arguments: un 'accumulator' et un élément.
    /// La fermeture renvoie la valeur que l'accumulateur devrait avoir pour la prochaine itération.
    ///
    /// La valeur initiale est la valeur que l'accumulateur aura lors du premier appel.
    ///
    /// Après avoir appliqué cette fermeture à chaque élément de l'itérateur, `fold()` renvoie l'accumulateur.
    ///
    /// Cette opération est parfois appelée 'reduce' ou 'inject'.
    ///
    /// Le pliage est utile chaque fois que vous avez une collection de quelque chose et que vous souhaitez en produire une valeur unique.
    ///
    /// Note: `fold()`, et les méthodes similaires qui traversent l'itérateur entier, peuvent ne pas se terminer pour des itérateurs infinis, même sur traits pour lesquels un résultat est déterminable en temps fini.
    ///
    /// Note: [`reduce()`] peut être utilisé pour utiliser le premier élément comme valeur initiale, si le type d'accumulateur et le type d'élément sont identiques.
    ///
    /// # Note aux réalisateurs
    ///
    /// Plusieurs des autres méthodes (forward) ont des implémentations par défaut en termes de celle-ci, alors essayez de l'implémenter explicitement si elle peut faire quelque chose de mieux que l'implémentation de la boucle `for` par défaut.
    ///
    ///
    /// En particulier, essayez d'avoir cet appel `fold()` sur les parties internes à partir desquelles cet itérateur est composé.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // la somme de tous les éléments du tableau
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Passons en revue chaque étape de l'itération ici:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Et donc, notre résultat final, `6`.
    ///
    /// Il est courant pour les personnes qui n'ont pas beaucoup utilisé les itérateurs d'utiliser une boucle `for` avec une liste de choses pour construire un résultat.Ceux-ci peuvent être transformés en `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // pour la boucle:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // ils sont pareils
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Réduit les éléments à un seul, en appliquant à plusieurs reprises une opération de réduction.
    ///
    /// Si l'itérateur est vide, renvoie [`None`];sinon, renvoie le résultat de la réduction.
    ///
    /// Pour les itérateurs avec au moins un élément, c'est la même chose que [`fold()`] avec le premier élément de l'itérateur comme valeur initiale, en y repliant chaque élément suivant.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Trouvez la valeur maximale:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Teste si chaque élément de l'itérateur correspond à un prédicat.
    ///
    /// `all()` prend une fermeture qui renvoie `true` ou `false`.Il applique cette fermeture à chaque élément de l'itérateur, et s'ils retournent tous `true`, il en va de même pour `all()`.
    /// Si l'un d'eux renvoie `false`, il renvoie `false`.
    ///
    /// `all()` est en court-circuit;en d'autres termes, il arrêtera le traitement dès qu'il trouvera un `false`, étant donné que quoi qu'il arrive, le résultat sera également `false`.
    ///
    ///
    /// Un itérateur vide renvoie `true`.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Arrêt au premier `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // nous pouvons toujours utiliser `iter`, car il y a plus d'éléments.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Teste si un élément de l'itérateur correspond à un prédicat.
    ///
    /// `any()` prend une fermeture qui renvoie `true` ou `false`.Il applique cette fermeture à chaque élément de l'itérateur, et si l'un d'eux renvoie `true`, il en va de même pour `any()`.
    /// S'ils renvoient tous `false`, cela renvoie `false`.
    ///
    /// `any()` est en court-circuit;en d'autres termes, il arrêtera le traitement dès qu'il trouvera un `true`, étant donné que quoi qu'il arrive, le résultat sera également `true`.
    ///
    ///
    /// Un itérateur vide renvoie `false`.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Arrêt au premier `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // nous pouvons toujours utiliser `iter`, car il y a plus d'éléments.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Recherche un élément d'un itérateur qui satisfait un prédicat.
    ///
    /// `find()` prend une fermeture qui renvoie `true` ou `false`.
    /// Il applique cette fermeture à chaque élément de l'itérateur, et si l'un d'eux renvoie `true`, alors `find()` renvoie [`Some(element)`].
    /// S'ils renvoient tous `false`, cela renvoie [`None`].
    ///
    /// `find()` est en court-circuit;en d'autres termes, il arrêtera le traitement dès que la fermeture retournera `true`.
    ///
    /// Étant donné que `find()` prend une référence et que de nombreux itérateurs itèrent sur des références, cela conduit à une situation éventuellement déroutante où l'argument est une double référence.
    ///
    /// Vous pouvez voir cet effet dans les exemples ci-dessous, avec `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Arrêt au premier `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // nous pouvons toujours utiliser `iter`, car il y a plus d'éléments.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Notez que `iter.find(f)` est équivalent à `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Applique la fonction aux éléments de l'itérateur et renvoie le premier résultat non nul.
    ///
    ///
    /// `iter.find_map(f)` équivaut à `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Applique la fonction aux éléments de l'itérateur et renvoie le premier résultat vrai ou la première erreur.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Recherche un élément dans un itérateur, retournant son index.
    ///
    /// `position()` prend une fermeture qui renvoie `true` ou `false`.
    /// Il applique cette fermeture à chaque élément de l'itérateur, et si l'un d'eux renvoie `true`, alors `position()` renvoie [`Some(index)`].
    /// Si tous renvoient `false`, cela renvoie [`None`].
    ///
    /// `position()` est en court-circuit;en d'autres termes, il arrêtera le traitement dès qu'il trouvera un `true`.
    ///
    /// # Comportement de débordement
    ///
    /// La méthode ne protège pas contre les débordements, donc s'il y a plus de [`usize::MAX`] éléments non correspondants, elle produit soit le mauvais résultat, soit panics.
    ///
    /// Si les assertions de débogage sont activées, un panic est garanti.
    ///
    /// # Panics
    ///
    /// Cette fonction peut panic si l'itérateur a plus de `usize::MAX` éléments non correspondants.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Arrêt au premier `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // nous pouvons toujours utiliser `iter`, car il y a plus d'éléments.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // L'index renvoyé dépend de l'état de l'itérateur
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Recherche un élément dans un itérateur à partir de la droite, retournant son index.
    ///
    /// `rposition()` prend une fermeture qui renvoie `true` ou `false`.
    /// Il applique cette fermeture à chaque élément de l'itérateur, en commençant par la fin, et si l'un d'eux retourne `true`, alors `rposition()` renvoie [`Some(index)`].
    ///
    /// Si tous renvoient `false`, cela renvoie [`None`].
    ///
    /// `rposition()` est en court-circuit;en d'autres termes, il arrêtera le traitement dès qu'il trouvera un `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Arrêt au premier `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // nous pouvons toujours utiliser `iter`, car il y a plus d'éléments.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Pas besoin de contrôle de débordement ici, car `ExactSizeIterator` implique que le nombre d'éléments rentre dans un `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Renvoie l'élément maximum d'un itérateur.
    ///
    /// Si plusieurs éléments sont égaux au maximum, le dernier élément est renvoyé.
    /// Si l'itérateur est vide, [`None`] est renvoyé.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Renvoie l'élément minimum d'un itérateur.
    ///
    /// Si plusieurs éléments sont égaux au minimum, le premier élément est renvoyé.
    /// Si l'itérateur est vide, [`None`] est renvoyé.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Renvoie l'élément qui donne la valeur maximale de la fonction spécifiée.
    ///
    ///
    /// Si plusieurs éléments sont égaux au maximum, le dernier élément est renvoyé.
    /// Si l'itérateur est vide, [`None`] est renvoyé.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Renvoie l'élément qui donne la valeur maximale par rapport à la fonction de comparaison spécifiée.
    ///
    ///
    /// Si plusieurs éléments sont égaux au maximum, le dernier élément est renvoyé.
    /// Si l'itérateur est vide, [`None`] est renvoyé.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Renvoie l'élément qui donne la valeur minimale de la fonction spécifiée.
    ///
    ///
    /// Si plusieurs éléments sont égaux au minimum, le premier élément est renvoyé.
    /// Si l'itérateur est vide, [`None`] est renvoyé.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Renvoie l'élément qui donne la valeur minimale par rapport à la fonction de comparaison spécifiée.
    ///
    ///
    /// Si plusieurs éléments sont égaux au minimum, le premier élément est renvoyé.
    /// Si l'itérateur est vide, [`None`] est renvoyé.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Inverse la direction d'un itérateur.
    ///
    /// Habituellement, les itérateurs effectuent des itérations de gauche à droite.
    /// Après avoir utilisé `rev()`, un itérateur effectuera à la place une itération de droite à gauche.
    ///
    /// Ceci n'est possible que si l'itérateur a une fin, donc `rev()` ne fonctionne que sur les [`DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Convertit un itérateur de paires en une paire de conteneurs.
    ///
    /// `unzip()` consomme un itérateur entier de paires, produisant deux collections: une à partir des éléments de gauche des paires et une à partir des éléments de droite.
    ///
    ///
    /// Cette fonction est, dans un certain sens, l'opposé de [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Crée un itérateur qui copie tous ses éléments.
    ///
    /// Ceci est utile lorsque vous avez un itérateur sur `&T`, mais que vous avez besoin d'un itérateur sur `T`.
    ///
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // copié est le même que .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Crée un itérateur qui [`clone`] est tous ses éléments.
    ///
    /// Ceci est utile lorsque vous avez un itérateur sur `&T`, mais que vous avez besoin d'un itérateur sur `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // cloné est le même que .map(|&x| x), pour les entiers
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Répète un itérateur à l'infini.
    ///
    /// Au lieu de s'arrêter à [`None`], l'itérateur recommencera à la place, depuis le début.Après une nouvelle itération, il recommencera au début.Et encore.
    /// Et encore.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Somme les éléments d'un itérateur.
    ///
    /// Prend chaque élément, les ajoute ensemble et renvoie le résultat.
    ///
    /// Un itérateur vide renvoie la valeur zéro du type.
    ///
    /// # Panics
    ///
    /// Lorsque vous appelez `sum()` et qu'un type entier primitif est renvoyé, cette méthode sera panic si le calcul déborde et les assertions de débogage sont activées.
    ///
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Itère sur tout l'itérateur, multipliant tous les éléments
    ///
    /// Un itérateur vide renvoie la valeur unique du type.
    ///
    /// # Panics
    ///
    /// Lors de l'appel de `product()` et qu'un type entier primitif est renvoyé, la méthode panic si le calcul déborde et les assertions de débogage sont activées.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) compare les éléments de ce [`Iterator`] avec ceux d'un autre.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) compare les éléments de ce [`Iterator`] avec ceux d'un autre par rapport à la fonction de comparaison spécifiée.
    ///
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) compare les éléments de ce [`Iterator`] avec ceux d'un autre.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) compare les éléments de ce [`Iterator`] avec ceux d'un autre par rapport à la fonction de comparaison spécifiée.
    ///
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Détermine si les éléments de ce [`Iterator`] sont égaux à ceux d'un autre.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Détermine si les éléments de ce [`Iterator`] sont égaux à ceux d'un autre par rapport à la fonction d'égalité spécifiée.
    ///
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Détermine si les éléments de ce [`Iterator`] sont différents de ceux d'un autre.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Détermine si les éléments de ce [`Iterator`] sont [lexicographically](Ord#lexicographical-comparison) inférieurs à ceux d'un autre.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Détermine si les éléments de ce [`Iterator`] sont [lexicographically](Ord#lexicographical-comparison) inférieurs ou égaux à ceux d'un autre.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Détermine si les éléments de ce [`Iterator`] sont [lexicographically](Ord#lexicographical-comparison) supérieurs à ceux d'un autre.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Détermine si les éléments de ce [`Iterator`] sont [lexicographically](Ord#lexicographical-comparison) supérieurs ou égaux à ceux d'un autre.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Vérifie si les éléments de cet itérateur sont triés.
    ///
    /// Autrement dit, pour chaque élément `a` et son élément suivant `b`, `a <= b` doit tenir.Si l'itérateur donne exactement zéro ou un élément, `true` est renvoyé.
    ///
    /// Notez que si `Self::Item` est uniquement `PartialOrd`, mais pas `Ord`, la définition ci-dessus implique que cette fonction renvoie `false` si deux éléments consécutifs ne sont pas comparables.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Vérifie si les éléments de cet itérateur sont triés à l'aide de la fonction de comparateur donnée.
    ///
    /// Au lieu d'utiliser `PartialOrd::partial_cmp`, cette fonction utilise la fonction `compare` donnée pour déterminer l'ordre de deux éléments.
    /// En dehors de cela, c'est équivalent à [`is_sorted`];voir sa documentation pour plus d'informations.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Vérifie si les éléments de cet itérateur sont triés à l'aide de la fonction d'extraction de clé donnée.
    ///
    /// Au lieu de comparer directement les éléments de l'itérateur, cette fonction compare les clés des éléments, comme déterminé par `f`.
    /// En dehors de cela, c'est équivalent à [`is_sorted`];voir sa documentation pour plus d'informations.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Voir [TrustedRandomAccess]
    // Le nom inhabituel est d'éviter les collisions de noms dans la résolution de méthode, voir #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}