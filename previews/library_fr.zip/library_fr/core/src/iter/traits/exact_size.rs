/// Un itérateur qui connaît sa longueur exacte.
///
/// Beaucoup d '[«itérateurs»] ne savent pas combien de fois ils vont itérer, mais certains le savent.
/// Si un itérateur sait combien de fois il peut itérer, donner accès à ces informations peut être utile.
/// Par exemple, si vous souhaitez effectuer une itération vers l'arrière, un bon début est de savoir où se trouve la fin.
///
/// Lors de l'implémentation d'un `ExactSizeIterator`, vous devez également implémenter [`Iterator`].
/// Ce faisant, l'implémentation de [`Iterator::size_hint`]*doit* renvoyer la taille exacte de l'itérateur.
///
/// La méthode [`len`] a une implémentation par défaut, vous ne devriez donc généralement pas l'implémenter.
/// Cependant, vous pourrez peut-être fournir une implémentation plus performante que la valeur par défaut, il est donc logique de la remplacer dans ce cas.
///
///
/// Notez que ce trait est un trait sûr et qu'en tant que tel, il ne *pas* et *ne peut* garantir que la longueur renvoyée est correcte.
/// Cela signifie que le code `unsafe`**ne doit pas** s'appuyer sur l'exactitude de [`Iterator::size_hint`].
/// Le [`TrustedLen`](super::marker::TrustedLen) trait instable et dangereux donne cette garantie supplémentaire.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Utilisation de base:
///
/// ```
/// // une plage finie sait exactement combien de fois elle va itérer
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Dans le [module-level docs], nous avons implémenté un [`Iterator`], `Counter`.
/// Implémentons également `ExactSizeIterator` pour cela:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Nous pouvons facilement calculer le nombre d'itérations restantes.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Et maintenant, nous pouvons l'utiliser!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Renvoie la longueur exacte de l'itérateur.
    ///
    /// L'implémentation garantit que l'itérateur retournera exactement `len()` plus de fois une valeur [`Some(T)`], avant de renvoyer [`None`].
    ///
    /// Cette méthode a une implémentation par défaut, vous ne devez donc généralement pas l'implémenter directement.
    /// Cependant, si vous pouvez fournir une implémentation plus efficace, vous pouvez le faire.
    /// Consultez la documentation du [trait-level] pour un exemple.
    ///
    /// Cette fonction a les mêmes garanties de sécurité que la fonction [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// // une plage finie sait exactement combien de fois elle va itérer
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Cette assertion est trop défensive, mais elle vérifie l'invariant
        // garanti par le trait.
        // Si ce trait était interne à rust, nous pourrions utiliser debug_assert !;assert_eq!vérifiera également toutes les implémentations utilisateur de Rust.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Renvoie `true` si l'itérateur est vide.
    ///
    /// Cette méthode a une implémentation par défaut utilisant [`ExactSizeIterator::len()`], vous n'avez donc pas besoin de l'implémenter vous-même.
    ///
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}