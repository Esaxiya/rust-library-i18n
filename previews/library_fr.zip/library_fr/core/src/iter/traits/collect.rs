/// Conversion à partir d'un [`Iterator`].
///
/// En implémentant `FromIterator` pour un type, vous définissez comment il sera créé à partir d'un itérateur.
/// Ceci est courant pour les types qui décrivent une collection quelconque.
///
/// [`FromIterator::from_iter()`] est rarement appelé explicitement, et est à la place utilisé via la méthode [`Iterator::collect()`].
///
/// Voir la documentation [`Iterator::collect()`]'s pour plus d'exemples.
///
/// Voir également: [`IntoIterator`].
///
/// # Examples
///
/// Utilisation de base:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Utilisation de [`Iterator::collect()`] pour utiliser implicitement `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Implémentation de `FromIterator` pour votre type:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Une collection d'échantillons, c'est juste un wrapper sur Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Donnons-lui quelques méthodes afin que nous puissions en créer une et y ajouter des éléments.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // et nous implémenterons FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Nous pouvons maintenant créer un nouvel itérateur ...
/// let iter = (0..5).into_iter();
///
/// // ... et en faire une MyCollection
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // collectionnez les œuvres aussi!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Crée une valeur à partir d'un itérateur.
    ///
    /// Voir le [module-level documentation] pour plus.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Conversion en [`Iterator`].
///
/// En implémentant `IntoIterator` pour un type, vous définissez comment il sera converti en itérateur.
/// Ceci est courant pour les types qui décrivent une collection quelconque.
///
/// L'un des avantages de la mise en œuvre de `IntoIterator` est que votre type sera [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Voir également: [`FromIterator`].
///
/// # Examples
///
/// Utilisation de base:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Implémentation de `IntoIterator` pour votre type:
///
/// ```
/// // Une collection d'échantillons, c'est juste un wrapper sur Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Donnons-lui quelques méthodes afin que nous puissions en créer une et y ajouter des éléments.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // et nous implémenterons IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Nous pouvons maintenant créer une nouvelle collection ...
/// let mut c = MyCollection::new();
///
/// // ... y ajouter des trucs ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... puis transformez-le en itérateur:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Il est courant d'utiliser `IntoIterator` comme trait bound.Cela permet au type de collection d'entrée de changer, tant qu'il s'agit toujours d'un itérateur.
/// Des limites supplémentaires peuvent être spécifiées en limitant
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Le type des éléments sur lesquels l'itération est effectuée.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// En quel type d'itérateur transformons-nous cela?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Crée un itérateur à partir d'une valeur.
    ///
    /// Voir le [module-level documentation] pour plus.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Étendez une collection avec le contenu d'un itérateur.
///
/// Les itérateurs produisent une série de valeurs et les collections peuvent également être considérées comme une série de valeurs.
/// Le `Extend` trait comble cette lacune, vous permettant d'étendre une collection en incluant le contenu de cet itérateur.
/// Lors de l'extension d'une collection avec une clé déjà existante, cette entrée est mise à jour ou, dans le cas de collections qui autorisent plusieurs entrées avec des clés égales, cette entrée est insérée.
///
///
/// # Examples
///
/// Utilisation de base:
///
/// ```
/// // Vous pouvez étendre une chaîne avec quelques caractères:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Implémentation de `Extend`:
///
/// ```
/// // Une collection d'échantillons, c'est juste un wrapper sur Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Donnons-lui quelques méthodes afin que nous puissions en créer une et y ajouter des éléments.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // puisque MyCollection a une liste d'i32, nous implémentons Extend pour i32
/// impl Extend<i32> for MyCollection {
///
///     // C'est un peu plus simple avec la signature de type concret: on peut appeler extend sur tout ce qui peut être transformé en un Iterator qui nous donne des i32s.
///     // Parce que nous avons besoin d'i32 à mettre dans MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // La mise en œuvre est très simple: parcourez l'itérateur et add() chaque élément vers nous-mêmes.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // élargissons notre collection avec trois autres numéros
/// c.extend(vec![1, 2, 3]);
///
/// // nous avons ajouté ces éléments à la fin
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Étend une collection avec le contenu d'un itérateur.
    ///
    /// Comme c'est la seule méthode requise pour ce trait, la documentation [trait-level] contient plus de détails.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// // Vous pouvez étendre une chaîne avec quelques caractères:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Étend une collection avec exactement un élément.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Réserve de la capacité dans une collection pour le nombre donné d'éléments supplémentaires.
    ///
    /// L'implémentation par défaut ne fait rien.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}