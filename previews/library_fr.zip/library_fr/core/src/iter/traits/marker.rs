/// Un itérateur qui continue toujours à produire `None` lorsqu'il est épuisé.
///
/// L'appel suivant sur un itérateur fusionné qui a renvoyé `None` une fois est garanti pour renvoyer [`None`] à nouveau.
/// Ce trait doit être implémenté par tous les itérateurs qui se comportent de cette façon car il permet d'optimiser [`Iterator::fuse()`].
///
///
/// Note: En général, vous ne devez pas utiliser `FusedIterator` dans des limites génériques si vous avez besoin d'un itérateur fusionné.
/// Au lieu de cela, vous devez simplement appeler [`Iterator::fuse()`] sur l'itérateur.
/// Si l'itérateur est déjà fusionné, le wrapper [`Fuse`] supplémentaire sera un no-op sans pénalité de performances.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Un itérateur qui rapporte une longueur précise à l'aide de size_hint.
///
/// L'itérateur signale un indice de taille où il est soit exact (la limite inférieure est égale à la limite supérieure), soit la limite supérieure est [`None`].
///
/// La limite supérieure ne doit être [`None`] que si la longueur réelle de l'itérateur est supérieure à [`usize::MAX`].
/// Dans ce cas, la limite inférieure doit être [`usize::MAX`], ce qui donne un [`Iterator::size_hint()`] de `(usize::MAX, None)`.
///
/// L'itérateur doit produire exactement le nombre d'éléments qu'il a rapporté ou diverger avant d'atteindre la fin.
///
/// # Safety
///
/// Ce trait ne doit être mis en œuvre que lorsque le contrat est respecté.
/// Les consommateurs de ce trait doivent inspecter la limite supérieure du [`Iterator::size_hint()`]’s.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Un itérateur qui, lors de la production d'un élément, aura pris au moins un élément de son [`SourceIter`] sous-jacent.
///
/// Appel de toute méthode qui fait avancer l'itérateur, par exemple
/// [`next()`] ou [`try_fold()`], garantit que pour chaque étape au moins une valeur de la source sous-jacente de l'itérateur a été déplacée et que le résultat de la chaîne d'itérateurs pourrait être inséré à sa place, en supposant que les contraintes structurelles de la source permettent une telle insertion.
///
/// En d'autres termes, ce trait indique qu'un pipeline d'itérateur peut être collecté en place.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}