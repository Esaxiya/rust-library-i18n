//! Itération externe composable.
//!
//! Si vous vous êtes retrouvé avec une collection quelconque et que vous deviez effectuer une opération sur les éléments de ladite collection, vous rencontrerez rapidement 'iterators'.
//! Les itérateurs sont largement utilisés dans le code idiomatique Rust, il vaut donc la peine de se familiariser avec eux.
//!
//! Avant d'expliquer davantage, parlons de la structure de ce module:
//!
//! # Organization
//!
//! Ce module est largement organisé par type:
//!
//! * [Traits] sont la partie principale: ces traits définissent les types d'itérateurs existants et ce que vous pouvez en faire.Les méthodes de ces traits méritent un peu plus de temps d'étude.
//! * [Functions] fournissent des moyens utiles pour créer des itérateurs de base.
//! * [Structs] sont souvent les types de retour des différentes méthodes sur le traits de ce module.Vous voudrez généralement regarder la méthode qui crée le `struct`, plutôt que le `struct` lui-même.
//! Pour plus de détails sur les raisons, consultez '[Implémentation d'itérateur](#implementation-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! C'est ça!Explorons les itérateurs.
//!
//! # Iterator
//!
//! Le cœur et l'âme de ce module est le [`Iterator`] trait.Le noyau de [`Iterator`] ressemble à ceci:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Un itérateur a une méthode, [`next`], qui, lorsqu'elle est appelée, renvoie une [`Option`]`<Item>».
//! [`next`] retournera [`Some(Item)`] tant qu'il y aura des éléments, et une fois qu'ils auront tous été épuisés, retournera `None` pour indiquer que l'itération est terminée.
//! Les itérateurs individuels peuvent choisir de reprendre l'itération, et donc appeler à nouveau [`next`] peut éventuellement recommencer à renvoyer [`Some(Item)`] à un moment donné (par exemple, voir [`TryIter`]).
//!
//!
//! La définition complète de [`Iterator`] comprend également un certain nombre d'autres méthodes, mais ce sont des méthodes par défaut, construites sur [`next`], et vous les obtenez donc gratuitement.
//!
//! Les itérateurs sont également composables et il est courant de les enchaîner pour effectuer des formes de traitement plus complexes.Voir la section [Adapters](#adapters) ci-dessous pour plus de détails.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Les trois formes d'itération
//!
//! Il existe trois méthodes courantes permettant de créer des itérateurs à partir d'une collection:
//!
//! * `iter()`, qui itère sur `&T`.
//! * `iter_mut()`, qui itère sur `&mut T`.
//! * `into_iter()`, qui itère sur `T`.
//!
//! Divers éléments de la bibliothèque standard peuvent implémenter un ou plusieurs des trois, le cas échéant.
//!
//! # Implémentation d'itérateur
//!
//! La création de votre propre itérateur implique deux étapes: la création d'un `struct` pour contenir l'état de l'itérateur, puis l'implémentation de [`Iterator`] pour ce `struct`.
//! C'est pourquoi il y a tant de `struct`s dans ce module: il y en a un pour chaque itérateur et adaptateur d'itérateur.
//!
//! Faisons un itérateur nommé `Counter` qui compte de `1` à `5`:
//!
//! ```
//! // Tout d'abord, la structure:
//!
//! /// Un itérateur qui compte de un à cinq
//! struct Counter {
//!     count: usize,
//! }
//!
//! // nous voulons que notre décompte commence à un, alors ajoutons une méthode new() pour vous aider.
//! // Ce n'est pas strictement nécessaire, mais c'est pratique.
//! // Notez que nous démarrons `count` à zéro, nous verrons pourquoi dans l'implémentation `next()`'s ci-dessous.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Ensuite, nous implémentons `Iterator` pour notre `Counter`:
//!
//! impl Iterator for Counter {
//!     // nous compterons avec usize
//!     type Item = usize;
//!
//!     // next() est la seule méthode requise
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Augmentez notre décompte.C'est pourquoi nous avons commencé à zéro.
//!         self.count += 1;
//!
//!         // Vérifiez si nous avons fini de compter ou non.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Et maintenant, nous pouvons l'utiliser!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Appeler [`next`] de cette façon devient répétitif.Rust a une construction qui peut appeler [`next`] sur votre itérateur, jusqu'à ce qu'il atteigne `None`.Passons en revue cela ensuite.
//!
//! Notez également que `Iterator` fournit une implémentation par défaut de méthodes telles que `nth` et `fold` qui appellent `next` en interne.
//! Cependant, il est également possible d'écrire une implémentation personnalisée de méthodes telles que `nth` et `fold` si un itérateur peut les calculer plus efficacement sans appeler `next`.
//!
//! # `for` boucles et `IntoIterator`
//!
//! La syntaxe de la boucle `for` de Rust est en fait du sucre pour les itérateurs.Voici un exemple de base de `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Cela imprimera les nombres un à cinq, chacun sur sa propre ligne.Mais vous remarquerez quelque chose ici: nous n'avons jamais rien appelé sur notre vector pour produire un itérateur.Ce qui donne?
//!
//! Il y a un trait dans la bibliothèque standard pour convertir quelque chose en un itérateur: [`IntoIterator`].
//! Ce trait a une méthode, [`into_iter`], qui convertit la chose implémentant [`IntoIterator`] en un itérateur.
//! Regardons à nouveau cette boucle `for` et en quoi le compilateur la convertit:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust dé-sucres ceci en:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Tout d'abord, nous appelons `into_iter()` sur la valeur.Ensuite, nous faisons correspondre l'itérateur qui retourne, appelant [`next`] encore et encore jusqu'à ce que nous voyions un `None`.
//! À ce stade, nous avons `break` hors de la boucle, et nous avons fini d'itérer.
//!
//! Il y a un autre élément subtil ici: la bibliothèque standard contient une implémentation intéressante de [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! En d'autres termes, tous les [`Iterator`] implémentent [`IntoIterator`], en retournant simplement eux-mêmes.Cela signifie deux choses:
//!
//! 1. Si vous écrivez un [`Iterator`], vous pouvez l'utiliser avec une boucle `for`.
//! 2. Si vous créez une collection, l'implémentation de [`IntoIterator`] pour cela permettra à votre collection d'être utilisée avec la boucle `for`.
//!
//! # Itération par référence
//!
//! Puisque [`into_iter()`] prend `self` par valeur, l'utilisation d'une boucle `for` pour itérer sur une collection consomme cette collection.Souvent, vous souhaiterez peut-être parcourir une collection sans la consommer.
//! De nombreuses collections proposent des méthodes qui fournissent des itérateurs sur des références, classiquement appelées respectivement `iter()` et `iter_mut()`:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` appartient toujours à cette fonction.
//! ```
//!
//! Si un type de collection `C` fournit `iter()`, il implémente généralement également `IntoIterator` pour `&C`, avec une implémentation qui appelle simplement `iter()`.
//! De même, une collection `C` qui fournit `iter_mut()` implémente généralement `IntoIterator` pour `&mut C` en déléguant à `iter_mut()`.Cela permet un raccourci pratique:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // identique à `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // identique à `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Alors que de nombreuses collections proposent `iter()`, toutes n'offrent pas `iter_mut()`.
//! Par exemple, la mutation des clés d'un [`HashSet<T>`] ou [`HashMap<K, V>`] pourrait mettre la collection dans un état incohérent si les hachages de clé changent, de sorte que ces collections n'offrent que `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Les fonctions qui prennent un [`Iterator`] et renvoient un autre [`Iterator`] sont souvent appelées ``adaptateurs d'itérateur '', car ils sont une forme de`` adaptateur
//! pattern'.
//!
//! Les adaptateurs d'itérateur courants incluent [`map`], [`take`] et [`filter`].
//! Pour en savoir plus, consultez leur documentation.
//!
//! S'il s'agit d'un adaptateur d'itérateur panics, l'itérateur sera dans un état non spécifié (mais sans danger pour la mémoire).
//! Cet état n'est pas non plus garanti de rester le même dans toutes les versions de Rust, vous devez donc éviter de vous fier aux valeurs exactes renvoyées par un itérateur qui a paniqué.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Les itérateurs (et l'itérateur [adapters](#adapters)) sont *paresseux*. Cela signifie que le simple fait de créer un itérateur ne fait pas beaucoup de _do_. Rien ne se passe vraiment jusqu'à ce que vous appeliez [`next`].
//! C'est parfois une source de confusion lors de la création d'un itérateur uniquement pour ses effets secondaires.
//! Par exemple, la méthode [`map`] appelle une fermeture sur chaque élément sur lequel elle itère:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Cela n'imprimera aucune valeur, car nous avons uniquement créé un itérateur, plutôt que de l'utiliser.Le compilateur nous avertira de ce type de comportement:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! La façon idiomatique d'écrire un [`map`] pour ses effets secondaires est d'utiliser une boucle `for` ou d'appeler la méthode [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Une autre façon courante d'évaluer un itérateur consiste à utiliser la méthode [`collect`] pour produire une nouvelle collection.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Les itérateurs ne doivent pas être finis.Par exemple, une plage ouverte est un itérateur infini:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Il est courant d'utiliser l'adaptateur d'itérateur [`take`] pour transformer un itérateur infini en un itérateur fini:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Cela imprimera les numéros `0` à `4`, chacun sur sa propre ligne.
//!
//! Gardez à l'esprit que les méthodes sur des itérateurs infinis, même celles pour lesquelles un résultat peut être déterminé mathématiquement en temps fini, peuvent ne pas se terminer.
//! Plus précisément, les méthodes telles que [`min`], qui dans le cas général nécessitent de parcourir chaque élément de l'itérateur, ne seront probablement pas renvoyées avec succès pour les itérateurs infinis.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Oh non!Une boucle infinie!
//! // `ones.min()` provoque une boucle infinie, donc nous n'atteindrons pas ce point!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;