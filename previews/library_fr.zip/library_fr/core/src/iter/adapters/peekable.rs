use crate::iter::{adapters::SourceIter, FusedIterator, InPlaceIterable, TrustedLen};
use crate::ops::Try;

/// Un itérateur avec un `peek()` qui renvoie une référence facultative à l'élément suivant.
///
///
/// Ce `struct` est créé par la méthode [`peekable`] sur [`Iterator`].
/// Consultez sa documentation pour en savoir plus.
///
/// [`peekable`]: Iterator::peekable
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Peekable<I: Iterator> {
    iter: I,
    /// Rappelez-vous une valeur jeté, même si elle était Aucune.
    peeked: Option<Option<I::Item>>,
}

impl<I: Iterator> Peekable<I> {
    pub(in crate::iter) fn new(iter: I) -> Peekable<I> {
        Peekable { iter, peeked: None }
    }
}

// Peekable doit se souvenir si un None a été vu dans la méthode `.peek()`.
// Il garantit que `.peek();.peek();` ou `.peek();.next();` ne fait avancer l'itérateur sous-jacent qu'une seule fois.
// Cela ne rend pas l'itérateur fusionné en soi.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> Iterator for Peekable<I> {
    type Item = I::Item;

    #[inline]
    fn next(&mut self) -> Option<I::Item> {
        match self.peeked.take() {
            Some(v) => v,
            None => self.iter.next(),
        }
    }

    #[inline]
    #[rustc_inherit_overflow_checks]
    fn count(mut self) -> usize {
        match self.peeked.take() {
            Some(None) => 0,
            Some(Some(_)) => 1 + self.iter.count(),
            None => self.iter.count(),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        match self.peeked.take() {
            Some(None) => None,
            Some(v @ Some(_)) if n == 0 => v,
            Some(Some(_)) => self.iter.nth(n - 1),
            None => self.iter.nth(n),
        }
    }

    #[inline]
    fn last(mut self) -> Option<I::Item> {
        let peek_opt = match self.peeked.take() {
            Some(None) => return None,
            Some(v) => v,
            None => None,
        };
        self.iter.last().or(peek_opt)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let peek_len = match self.peeked {
            Some(None) => return (0, Some(0)),
            Some(Some(_)) => 1,
            None => 0,
        };
        let (lo, hi) = self.iter.size_hint();
        let lo = lo.saturating_add(peek_len);
        let hi = match hi {
            Some(x) => x.checked_add(peek_len),
            None => None,
        };
        (lo, hi)
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let acc = match self.peeked.take() {
            Some(None) => return try { init },
            Some(Some(v)) => f(init, v)?,
            None => init,
        };
        self.iter.try_fold(acc, f)
    }

    #[inline]
    fn fold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        let acc = match self.peeked {
            Some(None) => return init,
            Some(Some(v)) => fold(init, v),
            None => init,
        };
        self.iter.fold(acc, fold)
    }
}

#[stable(feature = "double_ended_peek_iterator", since = "1.38.0")]
impl<I> DoubleEndedIterator for Peekable<I>
where
    I: DoubleEndedIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        match self.peeked.as_mut() {
            Some(v @ Some(_)) => self.iter.next_back().or_else(|| v.take()),
            Some(None) => None,
            None => self.iter.next_back(),
        }
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        match self.peeked.take() {
            Some(None) => try { init },
            Some(Some(v)) => match self.iter.try_rfold(init, &mut f).into_result() {
                Ok(acc) => f(acc, v),
                Err(e) => {
                    self.peeked = Some(Some(v));
                    Try::from_error(e)
                }
            },
            None => self.iter.try_rfold(init, f),
        }
    }

    #[inline]
    fn rfold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        match self.peeked {
            Some(None) => init,
            Some(Some(v)) => {
                let acc = self.iter.rfold(init, &mut fold);
                fold(acc, v)
            }
            None => self.iter.rfold(init, fold),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator> ExactSizeIterator for Peekable<I> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator> FusedIterator for Peekable<I> {}

impl<I: Iterator> Peekable<I> {
    /// Renvoie une référence à la valeur next() sans avancer l'itérateur.
    ///
    /// Comme [`next`], s'il y a une valeur, elle est enveloppée dans un `Some(T)`.
    /// Mais si l'itération est terminée, `None` est renvoyé.
    ///
    /// [`next`]: Iterator::next
    ///
    /// Étant donné que `peek()` renvoie une référence et que de nombreux itérateurs itèrent sur des références, il peut y avoir une situation éventuellement déroutante où la valeur de retour est une double référence.
    /// Vous pouvez voir cet effet dans les exemples ci-dessous.
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() nous permet de voir dans le future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // L'itérateur n'avance pas même si on `peek` plusieurs fois
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Une fois l'itérateur terminé, `peek()` l'est aussi
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&mut self) -> Option<&I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_ref()
    }

    /// Renvoie une référence mutable à la valeur next() sans faire avancer l'itérateur.
    ///
    /// Comme [`next`], s'il y a une valeur, elle est enveloppée dans un `Some(T)`.
    /// Mais si l'itération est terminée, `None` est renvoyé.
    ///
    /// Étant donné que `peek_mut()` renvoie une référence et que de nombreux itérateurs itèrent sur des références, il peut y avoir une situation éventuellement déroutante où la valeur de retour est une double référence.
    /// Vous pouvez voir cet effet dans les exemples ci-dessous.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Utilisation de base:
    ///
    /// ```
    /// #![feature(peekable_peek_mut)]
    /// let mut iter = [1, 2, 3].iter().peekable();
    ///
    /// // Comme avec `peek()`, nous pouvons voir dans le future sans faire avancer l'itérateur.
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // Jetez un œil dans l'itérateur et définissez la valeur derrière la référence mutable.
    /// if let Some(p) = iter.peek_mut() {
    ///     assert_eq!(*p, &2);
    ///     *p = &5;
    /// }
    ///
    /// // La valeur que nous avons mise réapparaît au fur et à mesure que l'itérateur continue.
    /// assert_eq!(iter.collect::<Vec<_>>(), vec![&5, &3]);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "peekable_peek_mut", issue = "78302")]
    pub fn peek_mut(&mut self) -> Option<&mut I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_mut()
    }

    /// Consommer et renvoyer la valeur suivante de cet itérateur si une condition est vraie.
    /// Si `func` renvoie `true` pour la valeur suivante de cet itérateur, consommez-le et renvoyez-le.
    /// Sinon, renvoyez `None`.
    /// # Examples
    /// Consommez un nombre s'il est égal à 0.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // Le premier élément de l'itérateur est 0;consommez-le.
    /// assert_eq!(iter.next_if(|&x| x == 0), Some(0));
    /// // L'élément suivant retourné est maintenant 1, donc `consume` renverra `false`.
    /// assert_eq!(iter.next_if(|&x| x == 0), None);
    /// // `next_if` enregistre la valeur de l'élément suivant si elle n'était pas égale à `expected`.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    ///
    /// Consommez n'importe quel nombre inférieur à 10.
    ///
    /// ```
    /// let mut iter = (1..20).peekable();
    /// // Consommez tous les nombres inférieurs à 10
    /// while iter.next_if(|&x| x < 10).is_some() {}
    /// // La prochaine valeur renvoyée sera 10
    /// assert_eq!(iter.next(), Some(10));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if(&mut self, func: impl FnOnce(&I::Item) -> bool) -> Option<I::Item> {
        match self.next() {
            Some(matched) if func(&matched) => Some(matched),
            other => {
                // Depuis que nous avons appelé `self.next()`, nous avons consommé `self.peeked`.
                assert!(self.peeked.is_none());
                self.peeked = Some(other);
                None
            }
        }
    }

    /// Consommez et renvoyez l'élément suivant s'il est égal à `expected`.
    /// # Example
    /// Consommez un nombre s'il est égal à 0.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // Le premier élément de l'itérateur est 0;consommez-le.
    /// assert_eq!(iter.next_if_eq(&0), Some(0));
    /// // L'élément suivant retourné est maintenant 1, donc `consume` renverra `false`.
    /// assert_eq!(iter.next_if_eq(&0), None);
    /// // `next_if_eq` enregistre la valeur de l'élément suivant si elle n'était pas égale à `expected`.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if_eq<T>(&mut self, expected: &T) -> Option<I::Item>
    where
        T: ?Sized,
        I::Item: PartialEq<T>,
    {
        self.next_if(|next| next == expected)
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I> TrustedLen for Peekable<I> where I: TrustedLen {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S: Iterator, I: Iterator> SourceIter for Peekable<I>
where
    I: SourceIter<Source = S>,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // SÉCURITÉ: transfert de fonction non sécurisé vers une fonction non sécurisée avec les mêmes exigences
        unsafe { SourceIter::as_inner(&mut self.iter) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I: InPlaceIterable> InPlaceIterable for Peekable<I> {}