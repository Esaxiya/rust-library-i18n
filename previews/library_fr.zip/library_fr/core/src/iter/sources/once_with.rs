use crate::iter::{FusedIterator, TrustedLen};

/// Crée un itérateur qui génère paresseusement une valeur exactement une fois en invoquant la fermeture fournie.
///
/// Ceci est couramment utilisé pour adapter un générateur de valeur unique dans un [`chain()`] d'autres types d'itération.
/// Peut-être avez-vous un itérateur qui couvre presque tout, mais vous avez besoin d'un cas spécial supplémentaire.
/// Peut-être avez-vous une fonction qui fonctionne sur les itérateurs, mais vous n'avez besoin de traiter qu'une seule valeur.
///
/// Contrairement à [`once()`], cette fonction générera paresseusement la valeur sur demande.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Utilisation de base:
///
/// ```
/// use std::iter;
///
/// // l'un est le nombre le plus solitaire
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // juste un, c'est tout ce que nous obtenons
/// assert_eq!(None, one.next());
/// ```
///
/// Enchaînement avec un autre itérateur.
/// Disons que nous voulons itérer sur chaque fichier du répertoire `.foo`, mais aussi un fichier de configuration,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // nous devons convertir un itérateur de DirEntry-s en un itérateur de PathBufs, nous utilisons donc map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // maintenant, notre itérateur juste pour notre fichier de configuration
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // enchaîner les deux itérateurs en un seul grand itérateur
/// let files = dirs.chain(config);
///
/// // cela nous donnera tous les fichiers dans .foo ainsi que .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Un itérateur qui produit un seul élément de type `A` en appliquant la fermeture `F: FnOnce() -> A` fournie.
///
///
/// Ce `struct` est créé par la fonction [`once_with()`].
/// Consultez sa documentation pour en savoir plus.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}