use crate::iter::{FusedIterator, TrustedLen};

/// Crée un nouvel itérateur qui répète sans fin un seul élément.
///
/// La fonction `repeat()` répète une valeur unique encore et encore.
///
/// Les itérateurs infinis comme `repeat()` sont souvent utilisés avec des adaptateurs comme [`Iterator::take()`], afin de les rendre finis.
///
/// Si le type d'élément de l'itérateur dont vous avez besoin n'implémente pas `Clone`, ou si vous ne souhaitez pas conserver l'élément répété en mémoire, vous pouvez à la place utiliser la fonction [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Utilisation de base:
///
/// ```
/// use std::iter;
///
/// // le nombre quatre 4 jamais:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // ouais, encore quatre
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Aller fini avec [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // ce dernier exemple était trop de quatre.Ayons seulement quatre quatre.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... et maintenant nous avons terminé
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Un itérateur qui répète un élément à l'infini.
///
/// Ce `struct` est créé par la fonction [`repeat()`].Consultez sa documentation pour en savoir plus.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}