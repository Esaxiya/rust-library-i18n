use crate::iter::{FusedIterator, TrustedLen};

/// Crée un itérateur qui produit un élément exactement une fois.
///
/// Ceci est couramment utilisé pour adapter une valeur unique dans un [`chain()`] d'autres types d'itération.
/// Peut-être avez-vous un itérateur qui couvre presque tout, mais vous avez besoin d'un cas spécial supplémentaire.
/// Peut-être avez-vous une fonction qui fonctionne sur les itérateurs, mais vous n'avez besoin de traiter qu'une seule valeur.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Utilisation de base:
///
/// ```
/// use std::iter;
///
/// // l'un est le nombre le plus solitaire
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // juste un, c'est tout ce que nous obtenons
/// assert_eq!(None, one.next());
/// ```
///
/// Enchaînement avec un autre itérateur.
/// Disons que nous voulons itérer sur chaque fichier du répertoire `.foo`, mais aussi un fichier de configuration,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // nous devons convertir un itérateur de DirEntry-s en un itérateur de PathBufs, nous utilisons donc map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // maintenant, notre itérateur juste pour notre fichier de configuration
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // enchaîner les deux itérateurs en un seul grand itérateur
/// let files = dirs.chain(config);
///
/// // cela nous donnera tous les fichiers dans .foo ainsi que .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Un itérateur qui produit un élément exactement une fois.
///
/// Ce `struct` est créé par la fonction [`once()`].Consultez sa documentation pour en savoir plus.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}