use crate::fmt;

/// Crée un nouvel itérateur où chaque itération appelle la fermeture fournie `F: FnMut() -> Option<T>`.
///
/// Cela permet de créer un itérateur personnalisé avec n'importe quel comportement sans utiliser la syntaxe plus verbeuse de création d'un type dédié et d'implémenter le [`Iterator`] trait pour celui-ci.
///
/// Notez que l'itérateur `FromFn` ne fait pas d'hypothèses sur le comportement de la fermeture, et par conséquent n'implémente pas de manière prudente [`FusedIterator`], ou remplace [`Iterator::size_hint()`] par rapport à son `(0, None)` par défaut.
///
///
/// La fermeture peut utiliser des captures et son environnement pour suivre l'état à travers les itérations.Selon la façon dont l'itérateur est utilisé, cela peut nécessiter de spécifier le mot-clé [`move`] sur la fermeture.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Réimplémentons l'itérateur de compteur de [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Augmentez notre décompte.C'est pourquoi nous avons commencé à zéro.
///     count += 1;
///
///     // Vérifiez si nous avons fini de compter ou non.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Un itérateur où chaque itération appelle la fermeture fournie `F: FnMut() -> Option<T>`.
///
/// Ce `struct` est créé par la fonction [`iter::from_fn()`].
/// Consultez sa documentation pour en savoir plus.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}