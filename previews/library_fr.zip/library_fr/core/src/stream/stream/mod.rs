use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Une interface pour traiter les itérateurs asynchrones.
///
/// C'est le flux principal trait.
/// Pour plus d'informations sur le concept de flux en général, veuillez consulter le [module-level documentation].
/// En particulier, vous voudrez peut-être savoir comment utiliser [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Le type d'éléments générés par le flux.
    type Item;

    /// Essayez d'extraire la valeur suivante de ce flux, en enregistrant la tâche actuelle pour le réveil si la valeur n'est pas encore disponible et en renvoyant `None` si le flux est épuisé.
    ///
    /// # Valeur de retour
    ///
    /// Il existe plusieurs valeurs de retour possibles, chacune indiquant un état de flux distinct:
    ///
    /// - `Poll::Pending` signifie que la valeur suivante de ce flux n'est pas encore prête.Les implémentations garantiront que la tâche en cours sera notifiée lorsque la valeur suivante sera prête.
    ///
    /// - `Poll::Ready(Some(val))` signifie que le flux a réussi à produire une valeur, `val`, et peut produire des valeurs supplémentaires lors des appels `poll_next` ultérieurs.
    ///
    /// - `Poll::Ready(None)` signifie que le flux est terminé et que `poll_next` ne doit plus être invoqué.
    ///
    /// # Panics
    ///
    /// Une fois qu'un flux est terminé (retourné `Ready(None)` from `poll_next`), appeler à nouveau sa méthode `poll_next` peut panic, bloquer pour toujours, ou causer d'autres types de problèmes; le `Stream` trait n'impose aucune exigence sur les effets d'un tel appel.
    ///
    /// Cependant, comme la méthode `poll_next` n'est pas marquée `unsafe`, les règles habituelles de Rust s'appliquent: les appels ne doivent jamais provoquer de comportement indéfini (corruption de mémoire, utilisation incorrecte des fonctions `unsafe`, etc.), quel que soit l'état du flux.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Renvoie les limites de la longueur restante du flux.
    ///
    /// Plus précisément, `size_hint()` renvoie un tuple où le premier élément est la limite inférieure et le deuxième élément est la limite supérieure.
    ///
    /// La seconde moitié du tuple retourné est une [`Option`]`<`[`usize`] `>`.
    /// Un [`None`] signifie ici soit qu'il n'y a pas de limite supérieure connue, soit que la limite supérieure est plus grande que [`usize`].
    ///
    /// # Notes de mise en œuvre
    ///
    /// Il n'est pas forcé qu'une implémentation de flux produise le nombre déclaré d'éléments.Un flux bogué peut produire moins que la limite inférieure ou plus que la limite supérieure des éléments.
    ///
    /// `size_hint()` est principalement destiné à être utilisé pour des optimisations telles que la réservation d'espace pour les éléments du flux, mais ne doit pas être fiable pour, par exemple, omettre les vérifications de limites dans le code non sécurisé.
    /// Une implémentation incorrecte de `size_hint()` ne doit pas conduire à des violations de la sécurité de la mémoire.
    ///
    /// Cela dit, l'implémentation doit fournir une estimation correcte, car sinon ce serait une violation du protocole de trait.
    ///
    /// L'implémentation par défaut renvoie `(0,` [`None`]`)`qui est correcte pour n'importe quel flux.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}