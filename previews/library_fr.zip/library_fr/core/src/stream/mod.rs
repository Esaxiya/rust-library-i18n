//! Itération asynchrone composable.
//!
//! Si futures sont des valeurs asynchrones, alors les flux sont des itérateurs asynchrones.
//! Si vous vous êtes retrouvé avec une collection asynchrone quelconque et que vous deviez effectuer une opération sur les éléments de ladite collection, vous rencontrerez rapidement 'streams'.
//! Les flux sont fortement utilisés dans le code asynchrone idiomatique Rust, il vaut donc la peine de se familiariser avec eux.
//!
//! Avant d'expliquer davantage, parlons de la structure de ce module:
//!
//! # Organization
//!
//! Ce module est largement organisé par type:
//!
//! * [Traits] sont la partie principale: ces traits définissent le type de flux existants et ce que vous pouvez en faire.Les méthodes de ces traits méritent un peu plus de temps d'étude.
//! * Les fonctions fournissent des moyens utiles pour créer des flux de base.
//! * Les structures sont souvent les types de retour des différentes méthodes sur le traits de ce module.Vous voudrez généralement regarder la méthode qui crée le `struct`, plutôt que le `struct` lui-même.
//! Pour plus de détails sur les raisons, consultez «[Implementing Stream](#implementation-stream)».
//!
//! [Traits]: #traits
//!
//! C'est ça!Explorons les flux.
//!
//! # Stream
//!
//! Le cœur et l'âme de ce module est le [`Stream`] trait.Le noyau de [`Stream`] ressemble à ceci:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Contrairement à `Iterator`, `Stream` fait une distinction entre la méthode [`poll_next`] qui est utilisée lors de l'implémentation d'un `Stream`, et une méthode (to-be-implemented) `next` qui est utilisée lors de la consommation d'un flux.
//!
//! Les consommateurs de `Stream` doivent uniquement prendre en compte `next`, qui, lorsqu'il est appelé, renvoie un future qui donne `Option<Stream::Item>`.
//!
//! Le future retourné par `next` donnera `Some(Item)` tant qu'il y aura des éléments, et une fois qu'ils auront tous été épuisés, produira `None` pour indiquer que l'itération est terminée.
//! Si nous attendons que quelque chose d'asynchrone soit résolu, le future attendra que le flux soit prêt à céder à nouveau.
//!
//! Les flux individuels peuvent choisir de reprendre l'itération, et donc appeler à nouveau `next` peut éventuellement générer à nouveau `Some(Item)` à un moment donné.
//!
//! La définition complète de [`Stream`] comprend également un certain nombre d'autres méthodes, mais ce sont des méthodes par défaut, construites sur [`poll_next`], et vous les obtenez donc gratuitement.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Implémentation de Stream
//!
//! La création de votre propre flux implique deux étapes: la création d'un `struct` pour contenir l'état du flux, puis l'implémentation de [`Stream`] pour ce `struct`.
//!
//! Faisons un flux nommé `Counter` qui compte de `1` à `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Tout d'abord, la structure:
//!
//! /// Un flux qui compte de un à cinq
//! struct Counter {
//!     count: usize,
//! }
//!
//! // nous voulons que notre décompte commence à un, alors ajoutons une méthode new() pour vous aider.
//! // Ce n'est pas strictement nécessaire, mais c'est pratique.
//! // Notez que nous démarrons `count` à zéro, nous verrons pourquoi dans l'implémentation `poll_next()`'s ci-dessous.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Ensuite, nous implémentons `Stream` pour notre `Counter`:
//!
//! impl Stream for Counter {
//!     // nous compterons avec usize
//!     type Item = usize;
//!
//!     // poll_next() est la seule méthode requise
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Augmentez notre décompte.C'est pourquoi nous avons commencé à zéro.
//!         self.count += 1;
//!
//!         // Vérifiez si nous avons fini de compter ou non.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Les flux sont *paresseux*.Cela signifie que la simple création d'un flux ne fait pas beaucoup _do_.Rien ne se passe vraiment jusqu'à ce que vous appeliez `next`.
//! C'est parfois une source de confusion lors de la création d'un flux uniquement pour ses effets secondaires.
//! Le compilateur nous avertira de ce type de comportement:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;