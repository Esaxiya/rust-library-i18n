#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Contient des définitions de structure pour la disposition des types intégrés du compilateur.
//!
//! Ils peuvent être utilisés comme cibles de transmutations en code non sécurisé pour manipuler directement les représentations brutes.
//!
//!
//! Leur définition doit toujours correspondre à l'ABI définie dans `rustc_middle::ty::layout`.
//!

/// La représentation d'un objet trait comme `&dyn SomeTrait`.
///
/// Cette structure a la même disposition que les types tels que `&dyn SomeTrait` et `Box<dyn AnotherTrait>`.
///
/// `TraitObject` est garanti pour correspondre aux mises en page, mais ce n'est pas le type d'objets trait (par exemple, les champs ne sont pas directement accessibles sur un `&dyn SomeTrait`) ni ne contrôle cette mise en page (changer la définition ne changera pas la mise en page d'un `&dyn SomeTrait`).
///
/// Il est uniquement conçu pour être utilisé par du code non sécurisé qui doit manipuler les détails de bas niveau.
///
/// Il n'y a aucun moyen de faire référence à tous les objets trait de manière générique, donc la seule façon de créer des valeurs de ce type est d'utiliser des fonctions comme [`std::mem::transmute`][transmute].
/// De même, la seule façon de créer un véritable objet trait à partir d'une valeur `TraitObject` est d'utiliser `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// La synthèse d'un objet trait avec des types non concordants-un objet dans lequel la vtable ne correspond pas au type de la valeur vers laquelle pointe le pointeur de données-est très susceptible d'entraîner un comportement indéfini.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // un exemple trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // laissez le compilateur créer un objet trait
/// let object: &dyn Foo = &value;
///
/// // regardez la représentation brute
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // le pointeur de données est l'adresse de `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // construire un nouvel objet, pointant vers un `i32` différent, en prenant soin d'utiliser la vtable `i32` de `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // cela devrait fonctionner comme si nous avions construit un objet trait directement à partir de `other_value`
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}