use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Un wrapper pour empêcher le compilateur d'appeler automatiquement le destructeur de `T`.
/// Ce wrapper a un coût nul.
///
/// `ManuallyDrop<T>` est soumis aux mêmes optimisations de mise en page que `T`.
/// En conséquence, il n'a *aucun effet* sur les hypothèses que le compilateur fait sur son contenu.
/// Par exemple, l'initialisation d'un `ManuallyDrop<&mut T>` avec [`mem::zeroed`] est un comportement indéfini.
/// Si vous devez gérer des données non initialisées, utilisez plutôt [`MaybeUninit<T>`].
///
/// Notez que l'accès à la valeur à l'intérieur d'un `ManuallyDrop<T>` est sécurisé.
/// Cela signifie qu'un `ManuallyDrop<T>` dont le contenu a été supprimé ne doit pas être exposé via une API de sécurité publique.
/// En conséquence, `ManuallyDrop::drop` n'est pas sûr.
///
/// # `ManuallyDrop` et déposer la commande.
///
/// Rust a un [drop order] de valeurs bien défini.
/// Pour vous assurer que les champs ou les sections locales sont supprimés dans un ordre spécifique, réorganisez les déclarations de manière à ce que l'ordre de suppression implicite soit le bon.
///
/// Il est possible d'utiliser `ManuallyDrop` pour contrôler l'ordre de dépôt, mais cela nécessite un code non sécurisé et est difficile à faire correctement en présence de déroulement.
///
///
/// Par exemple, si vous voulez vous assurer qu'un champ spécifique est supprimé après les autres, faites-en le dernier champ d'une structure:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` sera abandonné après `children`.
///     // Rust garantit que les champs sont supprimés dans l'ordre de déclaration.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Enveloppez une valeur à supprimer manuellement.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Vous pouvez toujours opérer en toute sécurité sur la valeur
    /// assert_eq!(*x, "Hello");
    /// // Mais `Drop` ne sera pas exécuté ici
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Extrait la valeur du conteneur `ManuallyDrop`.
    ///
    /// Cela permet de supprimer à nouveau la valeur.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Cela laisse tomber le `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Prend la valeur du conteneur `ManuallyDrop<T>`.
    ///
    /// Cette méthode est principalement destinée à déplacer des valeurs en baisse.
    /// Au lieu d'utiliser [`ManuallyDrop::drop`] pour supprimer manuellement la valeur, vous pouvez utiliser cette méthode pour prendre la valeur et l'utiliser comme vous le souhaitez.
    ///
    /// Dans la mesure du possible, il est préférable d'utiliser [`into_inner`][`ManuallyDrop::into_inner`] à la place, ce qui évite de dupliquer le contenu du `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Cette fonction déplace sémantiquement la valeur contenue sans empêcher une utilisation ultérieure, laissant l'état de ce conteneur inchangé.
    /// Il est de votre responsabilité de vous assurer que ce `ManuallyDrop` ne sera plus utilisé.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // SÉCURITÉ: nous lisons à partir d'une référence, ce qui est garanti
        // pour être valide pour les lectures.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Supprime manuellement la valeur contenue.Cela équivaut exactement à appeler [`ptr::drop_in_place`] avec un pointeur vers la valeur contenue.
    /// En tant que tel, à moins que la valeur contenue ne soit une structure compressée, le destructeur sera appelé sur place sans déplacer la valeur, et peut donc être utilisé pour supprimer en toute sécurité des données [pinned].
    ///
    /// Si vous êtes propriétaire de la valeur, vous pouvez utiliser [`ManuallyDrop::into_inner`] à la place.
    ///
    /// # Safety
    ///
    /// Cette fonction exécute le destructeur de la valeur contenue.
    /// À part les modifications apportées par le destructeur lui-même, la mémoire reste inchangée, et donc en ce qui concerne le compilateur, elle contient toujours un modèle de bits qui est valide pour le type `T`.
    ///
    ///
    /// Cependant, cette valeur "zombie" ne doit pas être exposée au code sécurisé et cette fonction ne doit pas être appelée plus d'une fois.
    /// Utiliser une valeur après sa suppression, ou supprimer une valeur plusieurs fois, peut entraîner un comportement indéfini (en fonction de ce que fait `drop`).
    /// Ceci est normalement empêché par le système de type, mais les utilisateurs de `ManuallyDrop` doivent respecter ces garanties sans l'aide du compilateur.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // SÉCURITÉ: nous abandonnons la valeur pointée par une référence mutable
        // qui est garanti pour être valide pour les écritures.
        // Il appartient à l'appelant de s'assurer que `slot` n'est pas à nouveau abandonné.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}