use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Un type de wrapper pour construire des instances non initialisées de `T`.
///
/// # Invariant d'initialisation
///
/// Le compilateur, en général, suppose qu'une variable est correctement initialisée selon les exigences du type de la variable.Par exemple, une variable de type référence doit être alignée et non NULL.
/// C'est un invariant qui doit *toujours* être respecté, même dans un code non sécurisé.
/// En conséquence, l'initialisation à zéro d'une variable de type référence provoque un [undefined behavior][ub] instantané, peu importe si cette référence est utilisée pour accéder à la mémoire:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // comportement indéfini!⚠️
/// // Le code équivalent avec `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // comportement indéfini!⚠️
/// ```
///
/// Ceci est exploité par le compilateur pour diverses optimisations, telles que l'élimination des vérifications d'exécution et l'optimisation de la disposition `enum`.
///
/// De même, une mémoire entièrement non initialisée peut avoir n'importe quel contenu, tandis qu'un `bool` doit toujours être `true` ou `false`.Par conséquent, la création d'un `bool` non initialisé est un comportement non défini:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // comportement indéfini!⚠️
/// // Le code équivalent avec `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // comportement indéfini!⚠️
/// ```
///
/// De plus, la mémoire non initialisée a la particularité de ne pas avoir de valeur fixe ("fixed" signifiant "it won't change without being written to").La lecture du même octet non initialisé plusieurs fois peut donner des résultats différents.
/// Cela rend le comportement non défini d'avoir des données non initialisées dans une variable même si cette variable a un type entier, qui autrement peut contenir n'importe quel motif de bits *fixe*:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // comportement indéfini!⚠️
/// // Le code équivalent avec `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // comportement indéfini!⚠️
/// ```
/// (Notez que les règles concernant les entiers non initialisés ne sont pas encore finalisées, mais tant qu'elles ne le sont pas, il est conseillé de les éviter.)
///
/// En plus de cela, rappelez-vous que la plupart des types ont des invariants supplémentaires au-delà du simple fait d'être considérés comme initialisés au niveau du type.
/// Par exemple, un [`Vec<T>`] initialisé à «1» est considéré comme initialisé (dans l'implémentation actuelle; cela ne constitue pas une garantie stable) car la seule exigence dont le compilateur en a connaissance est que le pointeur de données doit être non nul.
/// La création d'un tel `Vec<T>` ne provoque pas de comportement *immédiat* indéfini, mais provoquera un comportement indéfini avec la plupart des opérations sûres (y compris la suppression).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` sert à activer le code non sécurisé pour traiter les données non initialisées.
/// C'est un signal au compilateur indiquant que les données ici pourraient *ne pas* être initialisées:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Créez une référence explicitement non initialisée.
/// // Le compilateur sait que les données à l'intérieur d'un `MaybeUninit<T>` peuvent être invalides, et par conséquent ce n'est pas UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Définissez-le sur une valeur valide.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Extraire les données initialisées-ceci n'est autorisé *qu'après* avoir correctement initialisé `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Le compilateur sait alors ne pas faire d'hypothèses ou d'optimisations incorrectes sur ce code.
///
/// Vous pouvez penser à `MaybeUninit<T>` comme étant un peu comme `Option<T>` mais sans aucun suivi d'exécution et sans aucun des contrôles de sécurité.
///
/// ## out-pointers
///
/// Vous pouvez utiliser `MaybeUninit<T>` pour implémenter "out-pointers": au lieu de renvoyer des données à partir d'une fonction, passez-lui un pointeur vers une mémoire (uninitialized) dans laquelle placer le résultat.
/// Cela peut être utile lorsqu'il est important pour l'appelant de contrôler la façon dont la mémoire dans laquelle le résultat est stocké est allouée et que vous souhaitez éviter les déplacements inutiles.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` ne laisse pas tomber l'ancien contenu, ce qui est important.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Nous savons maintenant que `v` est initialisé!Cela garantit également que le vector est correctement déposé.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Initialiser un tableau élément par élément
///
/// `MaybeUninit<T>` peut être utilisé pour initialiser un grand tableau élément par élément:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Créez un tableau non initialisé de `MaybeUninit`.
///     // Le `assume_init` est sûr car le type que nous prétendons avoir initialisé ici est un tas de `MaybeUninit`s, qui ne nécessitent pas d'initialisation.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Laisser tomber un `MaybeUninit` ne fait rien.
///     // Ainsi, l'utilisation de l'affectation de pointeur brut au lieu de `ptr::write` n'entraîne pas la suppression de l'ancienne valeur non initialisée.
/////
///     // De plus, s'il y a un panic pendant cette boucle, nous avons une fuite de mémoire, mais il n'y a pas de problème de sécurité de la mémoire.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Tout est initialisé.
///     // Transmutez la matrice au type initialisé.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Vous pouvez également travailler avec des tableaux partiellement initialisés, qui peuvent être trouvés dans des structures de données de bas niveau.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Créez un tableau non initialisé de `MaybeUninit`.
/// // Le `assume_init` est sûr car le type que nous prétendons avoir initialisé ici est un tas de `MaybeUninit`s, qui ne nécessitent pas d'initialisation.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Comptez le nombre d'éléments que nous avons assignés.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Pour chaque élément du tableau, supprimez-le si nous l'avons alloué.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Initialiser une structure champ par champ
///
/// Vous pouvez utiliser `MaybeUninit<T>` et la macro [`std::ptr::addr_of_mut`] pour initialiser les structures champ par champ:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Initialisation du champ `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Initialisation du champ `list` S'il y a un panic ici, alors le `String` dans le champ `name` fuit.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Tous les champs sont initialisés, nous appelons donc `assume_init` pour obtenir un Foo initialisé.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` est garanti d'avoir la même taille, alignement et ABI que `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Cependant, rappelez-vous qu'un type *contenant* un `MaybeUninit<T>` n'est pas nécessairement la même disposition;Rust ne garantit pas en général que les champs d'un `Foo<T>` ont le même ordre qu'un `Foo<U>` même si `T` et `U` ont la même taille et le même alignement.
///
/// De plus, comme toute valeur de bit est valide pour un `MaybeUninit<T>`, le compilateur ne peut pas appliquer les optimisations non-zero/niche-filling, ce qui peut entraîner une taille plus grande:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Si `T` est sécurisé FFI, il en va de même pour `MaybeUninit<T>`.
///
/// Bien que `MaybeUninit` soit `#[repr(transparent)]` (indiquant qu'il garantit la même taille, l'alignement et l'ABI que `T`), cela ne change *pas* aucune des mises en garde précédentes.
/// `Option<T>` et `Option<MaybeUninit<T>>` peuvent encore avoir des tailles différentes, et les types contenant un champ de type `T` peuvent être disposés (et dimensionnés) différemment que si ce champ était `MaybeUninit<T>`.
/// `MaybeUninit` est un type d'union, et `#[repr(transparent)]` sur les unions est instable (voir [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Au fil du temps, les garanties exactes de `#[repr(transparent)]` sur les unions peuvent évoluer, et `MaybeUninit` peut ou non rester `#[repr(transparent)]`.
/// Cela dit, `MaybeUninit<T>` garantira *toujours* qu'il a la même taille, alignement et ABI que `T`;c'est juste que la façon dont `MaybeUninit` implémente cette garantie peut évoluer.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Élément Lang afin que nous puissions y envelopper d'autres types.Ceci est utile pour les générateurs.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // N'appelant pas `T::clone()`, nous ne pouvons pas savoir si nous sommes suffisamment initialisés pour cela.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Crée un nouveau `MaybeUninit<T>` initialisé avec la valeur donnée.
    /// Il est prudent d'appeler [`assume_init`] sur la valeur de retour de cette fonction.
    ///
    /// Notez que déposer un `MaybeUninit<T>` n'appellera jamais le code de dépôt de `T`.
    /// Il est de votre responsabilité de vous assurer que `T` est abandonné s'il est initialisé.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Crée un nouveau `MaybeUninit<T>` dans un état non initialisé.
    ///
    /// Notez que déposer un `MaybeUninit<T>` n'appellera jamais le code de dépôt de `T`.
    /// Il est de votre responsabilité de vous assurer que `T` est abandonné s'il est initialisé.
    ///
    /// Voir le [type-level documentation][MaybeUninit] pour quelques exemples.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Créez un nouveau tableau d'éléments `MaybeUninit<T>`, dans un état non initialisé.
    ///
    /// Note: dans une version future Rust, cette méthode peut devenir inutile lorsque la syntaxe littérale de tableau autorise [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// L'exemple ci-dessous pourrait alors utiliser `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Renvoie une tranche (éventuellement plus petite) de données qui a été réellement lue
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // SÉCURITÉ: un `[MaybeUninit<_>; LEN]` non initialisé est valide.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Crée un nouveau `MaybeUninit<T>` dans un état non initialisé, la mémoire étant remplie d'octets `0`.Cela dépend de `T` si cela permet déjà une initialisation correcte.
    ///
    /// Par exemple, `MaybeUninit<usize>::zeroed()` est initialisé, mais `MaybeUninit<&'static i32>::zeroed()` ne l'est pas car les références ne doivent pas être nulles.
    ///
    /// Notez que déposer un `MaybeUninit<T>` n'appellera jamais le code de dépôt de `T`.
    /// Il est de votre responsabilité de vous assurer que `T` est abandonné s'il est initialisé.
    ///
    /// # Example
    ///
    /// Utilisation correcte de cette fonction: initialisation d'une structure avec zéro, où tous les champs de la structure peuvent contenir le modèle de bits 0 comme valeur valide.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// Utilisation *incorrecte* de cette fonction: appel de `x.zeroed().assume_init()` lorsque `0` n'est pas un modèle de bit valide pour le type:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // À l'intérieur d'une paire, nous créons un `NotZero` qui n'a pas de discriminant valide.
    /// // C'est un comportement indéfini.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // SÉCURITÉ: `u.as_mut_ptr()` pointe vers la mémoire allouée.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Définit la valeur du `MaybeUninit<T>`.
    /// Cela écrase toute valeur précédente sans la supprimer, donc veillez à ne pas l'utiliser deux fois à moins que vous ne souhaitiez ignorer l'exécution du destructeur.
    ///
    /// Pour votre commodité, cela renvoie également une référence mutable au contenu (désormais initialisé en toute sécurité) de `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // SÉCURITÉ: Nous venons d'initialiser cette valeur.
        unsafe { self.assume_init_mut() }
    }

    /// Obtient un pointeur vers la valeur contenue.
    /// Lire à partir de ce pointeur ou le transformer en référence est un comportement indéfini à moins que le `MaybeUninit<T>` ne soit initialisé.
    /// L'écriture en mémoire vers laquelle pointe ce pointeur (non-transitively) est un comportement indéfini (sauf à l'intérieur d'un `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Utilisation correcte de cette méthode:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Créez une référence dans le `MaybeUninit<T>`.C'est correct car nous l'avons initialisé.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// Utilisation *incorrecte* de cette méthode:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Nous avons créé une référence à un vector non initialisé!C'est un comportement indéfini.⚠️
    /// ```
    ///
    /// (Notez que les règles relatives aux références aux données non initialisées ne sont pas encore finalisées, mais tant qu'elles ne le sont pas, il est conseillé de les éviter.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` et `ManuallyDrop` sont tous les deux `repr(transparent)` afin que nous puissions lancer le pointeur.
        self as *const _ as *const T
    }

    /// Obtient un pointeur mutable vers la valeur contenue.
    /// Lire à partir de ce pointeur ou le transformer en référence est un comportement indéfini à moins que le `MaybeUninit<T>` ne soit initialisé.
    ///
    /// # Examples
    ///
    /// Utilisation correcte de cette méthode:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Créez une référence dans le `MaybeUninit<Vec<u32>>`.
    /// // C'est correct car nous l'avons initialisé.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// Utilisation *incorrecte* de cette méthode:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Nous avons créé une référence à un vector non initialisé!C'est un comportement indéfini.⚠️
    /// ```
    ///
    /// (Notez que les règles relatives aux références aux données non initialisées ne sont pas encore finalisées, mais tant qu'elles ne le sont pas, il est conseillé de les éviter.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` et `ManuallyDrop` sont tous les deux `repr(transparent)` afin que nous puissions lancer le pointeur.
        self as *mut _ as *mut T
    }

    /// Extrait la valeur du conteneur `MaybeUninit<T>`.C'est un excellent moyen de garantir que les données seront supprimées, car le `T` résultant est soumis à la gestion de la suppression habituelle.
    ///
    /// # Safety
    ///
    /// Il appartient à l'appelant de garantir que le `MaybeUninit<T>` est vraiment dans un état initialisé.L'appeler lorsque le contenu n'est pas encore complètement initialisé entraîne un comportement indéfini immédiat.
    /// Le [type-level documentation][inv] contient plus d'informations sur cet invariant d'initialisation.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// En plus de cela, rappelez-vous que la plupart des types ont des invariants supplémentaires au-delà du simple fait d'être considérés comme initialisés au niveau du type.
    /// Par exemple, un [`Vec<T>`] initialisé à «1» est considéré comme initialisé (dans l'implémentation actuelle; cela ne constitue pas une garantie stable) car la seule exigence dont le compilateur en a connaissance est que le pointeur de données doit être non nul.
    ///
    /// La création d'un tel `Vec<T>` ne provoque pas de comportement *immédiat* indéfini, mais provoquera un comportement indéfini avec la plupart des opérations sûres (y compris la suppression).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Utilisation correcte de cette méthode:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// Utilisation *incorrecte* de cette méthode:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` n'avait pas encore été initialisé, donc cette dernière ligne provoquait un comportement indéfini.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // SÉCURITÉ: l'appelant doit garantir que `self` est initialisé.
        // Cela signifie également que `self` doit être une variante `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Lit la valeur du conteneur `MaybeUninit<T>`.Le `T` résultant est soumis à la gestion de chute habituelle.
    ///
    /// Dans la mesure du possible, il est préférable d'utiliser [`assume_init`] à la place, ce qui évite de dupliquer le contenu du `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Il appartient à l'appelant de garantir que le `MaybeUninit<T>` est vraiment dans un état initialisé.L'appeler lorsque le contenu n'est pas encore complètement initialisé entraîne un comportement indéfini.
    /// Le [type-level documentation][inv] contient plus d'informations sur cet invariant d'initialisation.
    ///
    /// De plus, cela laisse une copie des mêmes données dans le `MaybeUninit<T>`.
    /// Lorsque vous utilisez plusieurs copies des données (en appelant `assume_init_read` plusieurs fois, ou en appelant d'abord `assume_init_read` puis [`assume_init`]), il est de votre responsabilité de vous assurer que ces données peuvent effectivement être dupliquées.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Utilisation correcte de cette méthode:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` est `Copy`, nous pouvons donc lire plusieurs fois.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // La duplication d'une valeur `None` est acceptable, nous pouvons donc lire plusieurs fois.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// Utilisation *incorrecte* de cette méthode:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Nous avons maintenant créé deux copies du même vector, menant à un double-gratuit ⚠️ quand ils sont tous les deux lâchés!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // SÉCURITÉ: l'appelant doit garantir que `self` est initialisé.
        // La lecture à partir de `self.as_ptr()` est sûre car `self` doit être initialisé.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Supprime la valeur contenue en place.
    ///
    /// Si vous êtes propriétaire du `MaybeUninit`, vous pouvez utiliser [`assume_init`] à la place.
    ///
    /// # Safety
    ///
    /// Il appartient à l'appelant de garantir que le `MaybeUninit<T>` est vraiment dans un état initialisé.L'appeler lorsque le contenu n'est pas encore complètement initialisé entraîne un comportement indéfini.
    ///
    /// En plus de cela, tous les invariants supplémentaires du type `T` doivent être satisfaits, car l'implémentation `Drop` de `T` (ou de ses membres) peut s'appuyer sur cela.
    /// Par exemple, un [`Vec<T>`] initialisé à «1» est considéré comme initialisé (dans l'implémentation actuelle; cela ne constitue pas une garantie stable) car la seule exigence dont le compilateur en a connaissance est que le pointeur de données doit être non nul.
    ///
    /// La suppression d'un tel `Vec<T>` entraînera cependant un comportement indéfini.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // SÉCURITÉ: l'appelant doit garantir que `self` est initialisé et
        // satisfait tous les invariants de `T`.
        // La suppression de la valeur en place est sûre si tel est le cas.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Obtient une référence partagée à la valeur contenue.
    ///
    /// Cela peut être utile lorsque nous voulons accéder à un `MaybeUninit` qui a été initialisé mais qui ne possède pas la propriété du `MaybeUninit` (empêchant l'utilisation de `.assume_init()`).
    ///
    /// # Safety
    ///
    /// L'appeler lorsque le contenu n'est pas encore complètement initialisé entraîne un comportement indéfini: il appartient à l'appelant de garantir que le `MaybeUninit<T>` est vraiment dans un état initialisé.
    ///
    ///
    /// # Examples
    ///
    /// ### Utilisation correcte de cette méthode:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Initialisez `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Maintenant que notre `MaybeUninit<_>` est connu pour être initialisé, il est possible de créer une référence partagée vers celui-ci:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // SÉCURITÉ: `x` a été initialisé.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### Utilisations *incorrectes* de cette méthode:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Nous avons créé une référence à un vector non initialisé!C'est un comportement indéfini.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Initialisez le `MaybeUninit` à l'aide de `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Référence à un `Cell<bool>` non initialisé: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // SÉCURITÉ: l'appelant doit garantir que `self` est initialisé.
        // Cela signifie également que `self` doit être une variante `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Obtient une référence (unique) mutable à la valeur contenue.
    ///
    /// Cela peut être utile lorsque nous voulons accéder à un `MaybeUninit` qui a été initialisé mais qui ne possède pas la propriété du `MaybeUninit` (empêchant l'utilisation de `.assume_init()`).
    ///
    /// # Safety
    ///
    /// L'appeler lorsque le contenu n'est pas encore complètement initialisé entraîne un comportement indéfini: il appartient à l'appelant de garantir que le `MaybeUninit<T>` est vraiment dans un état initialisé.
    /// Par exemple, `.assume_init_mut()` ne peut pas être utilisé pour initialiser un `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Utilisation correcte de cette méthode:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Initialise *tous* les octets du tampon d'entrée.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Initialisez `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Nous savons maintenant que `buf` a été initialisé, nous pourrions donc le `.assume_init()`.
    /// // Cependant, l'utilisation de `.assume_init()` peut déclencher un `memcpy` des 2048 octets.
    /// // Pour affirmer que notre tampon a été initialisé sans le copier, nous mettons à niveau le `&mut MaybeUninit<[u8; 2048]>` vers un `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // SÉCURITÉ: `buf` a été initialisé.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Maintenant, nous pouvons utiliser `buf` comme une tranche normale:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### Utilisations *incorrectes* de cette méthode:
    ///
    /// Vous ne pouvez pas utiliser `.assume_init_mut()` pour initialiser une valeur:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Nous avons créé une référence (mutable) à un `bool` non initialisé!
    ///     // C'est un comportement indéfini.⚠️
    /// }
    /// ```
    ///
    /// Par exemple, vous ne pouvez pas [`Read`] dans un tampon non initialisé:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) référence à la mémoire non initialisée!
    ///                             // C'est un comportement indéfini.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Vous ne pouvez pas non plus utiliser l'accès direct aux champs pour effectuer une initialisation progressive champ par champ:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) référence à la mémoire non initialisée!
    ///                  // C'est un comportement indéfini.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) référence à la mémoire non initialisée!
    ///                  // C'est un comportement indéfini.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Nous pensons actuellement que ce qui précède est incorrect, c'est-à-dire que nous avons des références à des données non initialisées (par exemple, dans `libcore/fmt/float.rs`).
    // Nous devons prendre une décision finale sur les règles avant la stabilisation.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // SÉCURITÉ: l'appelant doit garantir que `self` est initialisé.
        // Cela signifie également que `self` doit être une variante `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Extrait les valeurs d'un tableau de conteneurs `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Il appartient à l'appelant de garantir que tous les éléments du tableau sont dans un état initialisé.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // SÉCURITÉ: maintenant en sécurité car nous avons initialisé tous les éléments
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * L'appelant garantit que tous les éléments du tableau sont initialisés
        // * `MaybeUninit<T>` et T sont garantis d'avoir la même disposition
        // * Peut-êtreUnint ne tombe pas, donc il n'y a pas de double-freins Et donc la conversion est sûre
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// En supposant que tous les éléments sont initialisés, obtenez-leur une tranche.
    ///
    /// # Safety
    ///
    /// Il appartient à l'appelant de garantir que les éléments `MaybeUninit<T>` sont réellement dans un état initialisé.
    ///
    /// L'appeler lorsque le contenu n'est pas encore complètement initialisé entraîne un comportement indéfini.
    ///
    /// Voir [`assume_init_ref`] pour plus de détails et d'exemples.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // SÉCURITÉ: lancer une tranche sur un `*const [T]` est sûr car l'appelant garantit que
        // `slice` est initialisé, et`MaybeUninit` est garanti d'avoir la même disposition que `T`.
        // Le pointeur obtenu est valide car il fait référence à la mémoire appartenant à `slice` qui est une référence et donc garantie d'être valide pour les lectures.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// En supposant que tous les éléments sont initialisés, obtenez-leur une tranche mutable.
    ///
    /// # Safety
    ///
    /// Il appartient à l'appelant de garantir que les éléments `MaybeUninit<T>` sont réellement dans un état initialisé.
    ///
    /// L'appeler lorsque le contenu n'est pas encore complètement initialisé entraîne un comportement indéfini.
    ///
    /// Voir [`assume_init_mut`] pour plus de détails et d'exemples.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // SÉCURITÉ: similaire aux notes de sécurité pour `slice_get_ref`, mais nous avons un
        // référence mutable qui est également garantie valable pour les écritures.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Obtient un pointeur vers le premier élément du tableau.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Obtient un pointeur mutable vers le premier élément du tableau.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Copie les éléments de `src` vers `this`, renvoyant une référence mutable au contenu désormais activé de `this`.
    ///
    /// Si `T` n'implémente pas `Copy`, utilisez [`write_slice_cloned`]
    ///
    /// Ceci est similaire à [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Cette fonction sera panic si les deux tranches ont des longueurs différentes.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SÉCURITÉ: nous venons de copier tous les éléments de len dans la capacité de réserve
    /// // les premiers éléments src.len() du vec sont maintenant valides.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // SÉCURITÉ: &[T] et&[MaybeUninit<T>] ont la même disposition
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // SÉCURITÉ: les éléments valides viennent d'être copiés dans `this` donc il est initialisé
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Clone les éléments de `src` vers `this`, renvoyant une référence mutable au contenu désormais activé de `this`.
    /// Les éléments déjà activés ne seront pas supprimés.
    ///
    /// Si `T` implémente `Copy`, utilisez [`write_slice`]
    ///
    /// Ceci est similaire à [`slice::clone_from_slice`] mais ne supprime pas les éléments existants.
    ///
    /// # Panics
    ///
    /// Cette fonction sera panic si les deux tranches ont des longueurs différentes, ou si l'implémentation de `Clone` panics.
    ///
    /// S'il y a un panic, les éléments déjà clonés seront supprimés.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SÉCURITÉ: nous venons de cloner tous les éléments de len dans la capacité de réserve
    /// // les premiers éléments src.len() du vec sont maintenant valides.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // contrairement à copy_from_slice, cela n'appelle pas clone_from_slice sur la tranche, c'est parce que `MaybeUninit<T: Clone>` n'implémente pas Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // SÉCURITÉ: cette tranche brute ne contiendra que des objets initialisés
                // c'est pourquoi, il est permis de le laisser tomber.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Nous devons les découper explicitement à la même longueur
        // pour que la vérification des limites soit élidée, et l'optimiseur générera memcpy pour les cas simples (par exemple T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // une protection est nécessaire b/c panic peut se produire lors d'un clonage
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // SÉCURITÉ: les éléments valides viennent d'être écrits dans `this` donc il est initialisé
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}