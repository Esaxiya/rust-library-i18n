//! Fonctions de base pour gérer la mémoire.
//!
//! Ce module contient des fonctions pour interroger la taille et l'alignement des types, initialiser et manipuler la mémoire.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// S'approprie et "forgets" sur la valeur **sans exécuter son destructeur**.
///
/// Toutes les ressources gérées par la valeur, telles que la mémoire du tas ou un descripteur de fichier, resteront indéfiniment dans un état inaccessible.Cependant, cela ne garantit pas que les pointeurs vers cette mémoire resteront valides.
///
/// * Si vous souhaitez perdre de la mémoire, consultez [`Box::leak`].
/// * Si vous souhaitez obtenir un pointeur brut vers la mémoire, consultez [`Box::into_raw`].
/// * Si vous souhaitez supprimer correctement une valeur en exécutant son destructeur, consultez [`mem::drop`].
///
/// # Safety
///
/// `forget` n'est pas marqué comme `unsafe`, car les garanties de sécurité de Rust n'incluent pas la garantie que les destructeurs fonctionneront toujours.
/// Par exemple, un programme peut créer un cycle de référence à l'aide de [`Rc`][rc] ou appeler [`process::exit`][exit] pour quitter sans exécuter de destructeurs.
/// Ainsi, autoriser `mem::forget` à partir d'un code sécurisé ne change pas fondamentalement les garanties de sécurité de Rust.
///
/// Cela dit, les fuites de ressources telles que la mémoire ou les objets I/O sont généralement indésirables.
/// Le besoin se fait sentir dans certains cas d'utilisation spécialisés pour FFI ou code non sécurisé, mais même dans ce cas, [`ManuallyDrop`] est généralement préféré.
///
/// Parce que l'oubli d'une valeur est autorisé, tout code `unsafe` que vous écrivez doit permettre cette possibilité.Vous ne pouvez pas renvoyer une valeur et vous attendre à ce que l'appelant exécute nécessairement le destructeur de la valeur.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// L'utilisation sûre canonique de `mem::forget` est de contourner le destructeur de valeur implémenté par le `Drop` trait.Par exemple, cela fera fuir un `File`, c'est-à-dire
/// récupère l'espace occupé par la variable mais ne ferme jamais la ressource système sous-jacente:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Ceci est utile lorsque la propriété de la ressource sous-jacente a été précédemment transférée vers du code en dehors de Rust, par exemple en transmettant le descripteur de fichier brut au code C.
///
/// # Relation avec `ManuallyDrop`
///
/// Alors que `mem::forget` peut également être utilisé pour transférer la propriété de *mémoire*, cela est sujet aux erreurs.
/// [`ManuallyDrop`] devrait être utilisé à la place.Considérez, par exemple, ce code:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Construisez un `String` en utilisant le contenu de `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // fuite `v` car sa mémoire est désormais gérée par `s`
/// mem::forget(v);  // ERREUR, v est invalide et ne doit pas être passé à une fonction
/// assert_eq!(s, "Az");
/// // `s` est implicitement supprimée et sa mémoire est libérée.
/// ```
///
/// Il y a deux problèmes avec l'exemple ci-dessus:
///
/// * Si plus de code était ajouté entre la construction de `String` et l'invocation de `mem::forget()`, un panic à l'intérieur provoquerait un double libre car la même mémoire est gérée à la fois par `v` et `s`.
/// * Après avoir appelé `v.as_mut_ptr()` et transmis la propriété des données à `s`, la valeur `v` n'est pas valide.
/// Même lorsqu'une valeur est simplement déplacée vers `mem::forget` (qui ne l'inspectera pas), certains types ont des exigences strictes sur leurs valeurs qui les rendent invalides lorsqu'elles sont suspendues ou qu'elles ne sont plus possédées.
/// L'utilisation de valeurs non valides de quelque manière que ce soit, y compris en les passant ou en les renvoyant à des fonctions, constitue un comportement indéfini et peut casser les hypothèses faites par le compilateur.
///
/// Le passage à `ManuallyDrop` évite les deux problèmes:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Avant de démonter `v` dans ses parties brutes, assurez-vous qu'il ne tombe pas!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Démontez maintenant `v`.Ces opérations ne peuvent pas panic, il ne peut donc pas y avoir de fuite.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Enfin, construisez un `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` est implicitement supprimée et sa mémoire est libérée.
/// ```
///
/// `ManuallyDrop` empêche de manière robuste le double free car nous désactivons le destructeur de `v` avant de faire quoi que ce soit d'autre.
/// `mem::forget()` ne le permet pas car il consomme son argument, nous obligeant à l'appeler uniquement après avoir extrait tout ce dont nous avons besoin de `v`.
/// Même si un panic était introduit entre la construction de `ManuallyDrop` et la construction de la chaîne (ce qui ne peut pas arriver dans le code comme indiqué), cela entraînerait une fuite et non un double gratuit.
/// En d'autres termes, `ManuallyDrop` se trompe du côté de la fuite au lieu de se tromper du côté de la (double) chute.
///
/// De plus, `ManuallyDrop` nous évite d'avoir à "touch" `v` après avoir transféré la propriété à `s`-la dernière étape d'interaction avec `v` pour s'en débarrasser sans exécuter son destructeur est entièrement évitée.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Comme [`forget`], mais accepte également les valeurs non dimensionnées.
///
/// Cette fonction est juste une cale destinée à être supprimée lorsque la fonction `unsized_locals` est stabilisée.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Renvoie la taille d'un type en octets.
///
/// Plus précisément, il s'agit du décalage en octets entre les éléments successifs d'un tableau avec ce type d'élément, y compris le remplissage d'alignement.
///
/// Ainsi, pour tout type `T` et longueur `n`, `[T; n]` a une taille de `n * size_of::<T>()`.
///
/// En général, la taille d'un type n'est pas stable entre les compilations, mais des types spécifiques tels que les primitives le sont.
///
/// Le tableau suivant donne la taille des primitives.
///
/// Type |taille de: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// De plus, `usize` et `isize` ont la même taille.
///
/// Les types `*const T`, `&T`, `Box<T>`, `Option<&T>` et `Option<Box<T>>` ont tous la même taille.
/// Si `T` est dimensionné, tous ces types ont la même taille que `usize`.
///
/// La mutabilité d'un pointeur ne change pas sa taille.En tant que tels, `&T` et `&mut T` ont la même taille.
/// De même pour `*const T` et `* mut T`.
///
/// # Taille des articles `#[repr(C)]`
///
/// La représentation `C` des éléments a une disposition définie.
/// Avec cette disposition, la taille des éléments est également stable tant que tous les champs ont une taille stable.
///
/// ## Taille des structures
///
/// Pour `structs`, la taille est déterminée par l'algorithme suivant.
///
/// Pour chaque champ de la structure trié par ordre de déclaration:
///
/// 1. Ajoutez la taille du champ.
/// 2. Arrondissez la taille actuelle au multiple le plus proche du [alignment] du champ suivant.
///
/// Enfin, arrondissez la taille de la structure au multiple le plus proche de son [alignment].
/// L'alignement de la structure est généralement le plus grand alignement de tous ses champs;cela peut être changé avec l'utilisation de `repr(align(N))`.
///
/// Contrairement à `C`, les structures de taille nulle ne sont pas arrondies à un octet supérieur.
///
/// ## Taille des énumérations
///
/// Les énumérations qui ne portent aucune donnée autre que le discriminant ont la même taille que les énumérations C sur la plate-forme pour laquelle elles sont compilées.
///
/// ## Taille des syndicats
///
/// La taille d'une union est la taille de son plus grand champ.
///
/// Contrairement à `C`, les unions de taille zéro ne sont pas arrondies à un octet supérieur.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Quelques primitives
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Certains tableaux
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Égalité de la taille du pointeur
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Utilisation de `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // La taille du premier champ est 1, alors ajoutez 1 à la taille.La taille est de 1.
/// // L'alignement du deuxième champ est 2, donc ajoutez 1 à la taille pour le remplissage.La taille est de 2.
/// // La taille du deuxième champ est de 2, ajoutez donc 2 à la taille.La taille est de 4.
/// // L'alignement du troisième champ est 1, donc ajoutez 0 à la taille pour le remplissage.La taille est de 4.
/// // La taille du troisième champ est 1, alors ajoutez 1 à la taille.La taille est de 5.
/// // Enfin, l'alignement de la structure est 2 (car le plus grand alignement parmi ses champs est 2), alors ajoutez 1 à la taille pour le remplissage.
/// // La taille est de 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Les structures de tuple suivent les mêmes règles.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Notez que la réorganisation des champs peut réduire la taille.
/// // Nous pouvons supprimer les deux octets de remplissage en plaçant `third` avant `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // La taille de l'Union est la taille du plus grand champ.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Renvoie la taille de la valeur pointée en octets.
///
/// C'est généralement le même que `size_of::<T>()`.
/// Cependant, lorsque `T`*n'a* aucune taille connue statiquement, par exemple une tranche [`[T]`][slice] ou un [trait object], alors `size_of_val` peut être utilisé pour obtenir la taille connue dynamiquement.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // SÉCURITÉ: `val` est une référence, donc c'est un pointeur brut valide
    unsafe { intrinsics::size_of_val(val) }
}

/// Renvoie la taille de la valeur pointée en octets.
///
/// C'est généralement le même que `size_of::<T>()`.Cependant, lorsque `T`*n'a* aucune taille connue statiquement, par exemple une tranche [`[T]`][slice] ou un [trait object], alors `size_of_val_raw` peut être utilisé pour obtenir la taille connue dynamiquement.
///
/// # Safety
///
/// Cette fonction ne peut être appelée en toute sécurité que si les conditions suivantes sont réunies:
///
/// - Si `T` est `Sized`, il est toujours possible d'appeler cette fonction en toute sécurité.
/// - Si la queue non dimensionnée de `T` est:
///     - a [slice], alors la longueur de la queue de la tranche doit être un entier initialisé, et la taille de la *valeur entière*(longueur de la queue dynamique + préfixe de taille statique) doit tenir dans `isize`.
///     - un [trait object], alors la partie vtable du pointeur doit pointer vers une vtable valide acquise par une coercition de non dimensionnement, et la taille de la *valeur entière*(longueur de queue dynamique + préfixe de taille statique) doit tenir dans `isize`.
///
///     - un (unstable) [extern type], alors cette fonction peut toujours être appelée en toute sécurité, mais elle peut panic ou renvoyer une valeur incorrecte, car la disposition du type externe n'est pas connue.
///     C'est le même comportement que [`size_of_val`] sur une référence à un type avec une queue de type externe.
///     - sinon, il n'est pas autorisé à appeler cette fonction.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SÉCURITÉ: l'appelant doit fournir un pointeur brut valide
    unsafe { intrinsics::size_of_val(val) }
}

/// Renvoie l'alignement minimum requis [ABI] d'un type.
///
/// Chaque référence à une valeur de type `T` doit être un multiple de ce nombre.
///
/// C'est l'alignement utilisé pour les champs struct.Il peut être plus petit que l'alignement préféré.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Renvoie l'alignement minimum requis [ABI] du type de la valeur vers laquelle pointe `val`.
///
/// Chaque référence à une valeur de type `T` doit être un multiple de ce nombre.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // SÉCURITÉ: val est une référence, donc c'est un pointeur brut valide
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Renvoie l'alignement minimum requis [ABI] d'un type.
///
/// Chaque référence à une valeur de type `T` doit être un multiple de ce nombre.
///
/// C'est l'alignement utilisé pour les champs struct.Il peut être plus petit que l'alignement préféré.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Renvoie l'alignement minimum requis [ABI] du type de la valeur vers laquelle pointe `val`.
///
/// Chaque référence à une valeur de type `T` doit être un multiple de ce nombre.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // SÉCURITÉ: val est une référence, donc c'est un pointeur brut valide
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Renvoie l'alignement minimum requis [ABI] du type de la valeur vers laquelle pointe `val`.
///
/// Chaque référence à une valeur de type `T` doit être un multiple de ce nombre.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Cette fonction ne peut être appelée en toute sécurité que si les conditions suivantes sont réunies:
///
/// - Si `T` est `Sized`, il est toujours possible d'appeler cette fonction en toute sécurité.
/// - Si la queue non dimensionnée de `T` est:
///     - a [slice], alors la longueur de la queue de la tranche doit être un entier initialisé, et la taille de la *valeur entière*(longueur de la queue dynamique + préfixe de taille statique) doit tenir dans `isize`.
///     - un [trait object], alors la partie vtable du pointeur doit pointer vers une vtable valide acquise par une coercition de non dimensionnement, et la taille de la *valeur entière*(longueur de queue dynamique + préfixe de taille statique) doit tenir dans `isize`.
///
///     - un (unstable) [extern type], alors cette fonction peut toujours être appelée en toute sécurité, mais elle peut panic ou renvoyer une valeur incorrecte, car la disposition du type externe n'est pas connue.
///     C'est le même comportement que [`align_of_val`] sur une référence à un type avec une queue de type externe.
///     - sinon, il n'est pas autorisé à appeler cette fonction.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SÉCURITÉ: l'appelant doit fournir un pointeur brut valide
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Renvoie `true` si la suppression des valeurs de type `T` est importante.
///
/// Ceci est purement un conseil d'optimisation et peut être implémenté de manière conservatrice:
/// il peut renvoyer `true` pour les types qui n'ont pas besoin d'être supprimés.
/// En tant que tel, toujours renvoyer `true` serait une implémentation valide de cette fonction.Cependant, si cette fonction renvoie réellement `false`, vous pouvez être certain que la suppression de `T` n'a aucun effet secondaire.
///
/// Les implémentations de bas niveau de choses comme les collections, qui doivent supprimer manuellement leurs données, devraient utiliser cette fonction pour éviter d'essayer inutilement de supprimer tout leur contenu lorsqu'elles sont détruites.
///
/// Cela peut ne pas faire de différence dans les versions de version (où une boucle qui n'a pas d'effets secondaires est facilement détectée et éliminée), mais c'est souvent une grande victoire pour les versions de débogage.
///
/// Notez que [`drop_in_place`] effectue déjà cette vérification, donc si votre charge de travail peut être réduite à un petit nombre d'appels [`drop_in_place`], son utilisation n'est pas nécessaire.
/// En particulier, notez que vous pouvez [`drop_in_place`] une tranche, et cela fera une seule vérification de needs_drop pour toutes les valeurs.
///
/// Des types comme Vec donc juste `drop_in_place(&mut self[..])` sans utiliser `needs_drop` explicitement.
/// Les types comme [`HashMap`], en revanche, doivent supprimer les valeurs une par une et doivent utiliser cette API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Voici un exemple de la façon dont une collection peut utiliser `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // déposer les données
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Renvoie la valeur de type `T` représentée par le modèle d'octet entièrement nul.
///
/// Cela signifie que, par exemple, l'octet de remplissage dans `(u8, u16)` n'est pas nécessairement mis à zéro.
///
/// Il n'y a aucune garantie qu'un modèle d'octet entièrement nul représente une valeur valide d'un certain type `T`.
/// Par exemple, le modèle d'octet tout zéro n'est pas une valeur valide pour les types de référence (`&T`, `&mut T`) et les pointeurs de fonctions.
/// L'utilisation de `zeroed` sur de tels types provoque un [undefined behavior][ub] immédiat car [the Rust compiler assumes][inv] qu'il y a toujours une valeur valide dans une variable qu'il considère comme initialisée.
///
///
/// Cela a le même effet que [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Il est parfois utile pour FFI, mais doit généralement être évité.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Utilisation correcte de cette fonction: initialisation d'un entier avec zéro.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// Utilisation *incorrecte* de cette fonction: initialisation d'une référence à zéro.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Comportement indéfini!
/// let _y: fn() = unsafe { mem::zeroed() }; // Et encore!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // SÉCURITÉ: l'appelant doit garantir qu'une valeur tout-zéro est valide pour `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Contourne les vérifications normales d'initialisation de la mémoire de Rust en faisant semblant de produire une valeur de type `T`, sans rien faire du tout.
///
/// **Cette fonction est obsolète.** Utilisez plutôt [`MaybeUninit<T>`].
///
/// La raison de la dépréciation est que la fonction ne peut pas être utilisée correctement: elle a le même effet que [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Comme l'explique le [`assume_init` documentation][assume_init], [the Rust compiler assumes][inv] que les valeurs sont correctement initialisées.
/// En conséquence, appeler par exemple
/// `mem::uninitialized::<bool>()` provoque un comportement indéfini immédiat pour renvoyer un `bool` qui n'est définitivement ni `true` ni `false`.
/// Pire encore, la mémoire vraiment non initialisée comme ce qui est renvoyé ici est spéciale en ce que le compilateur sait qu'elle n'a pas de valeur fixe.
/// Cela rend le comportement non défini d'avoir des données non initialisées dans une variable même si cette variable a un type entier.
/// (Notez que les règles concernant les entiers non initialisés ne sont pas encore finalisées, mais tant qu'elles ne le sont pas, il est conseillé de les éviter.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // SÉCURITÉ: l'appelant doit garantir qu'une valeur unitaire est valide pour `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Échange les valeurs à deux emplacements mutables, sans désinitialiser l'un ou l'autre.
///
/// * Si vous souhaitez échanger avec une valeur par défaut ou fictive, consultez [`take`].
/// * Si vous souhaitez échanger avec une valeur transmise, en renvoyant l'ancienne valeur, consultez [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // SÉCURITÉ: les pointeurs bruts ont été créés à partir de références mutables sûres satisfaisant toutes les
    // contraintes sur `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Remplace `dest` par la valeur par défaut de `T`, renvoyant la valeur `dest` précédente.
///
/// * Si vous souhaitez remplacer les valeurs de deux variables, consultez [`swap`].
/// * Si vous souhaitez remplacer par une valeur transmise au lieu de la valeur par défaut, consultez [`replace`].
///
/// # Examples
///
/// Un exemple simple:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` permet de s'approprier un champ struct en le remplaçant par une valeur "empty".
/// Sans `take`, vous pouvez rencontrer des problèmes comme ceux-ci:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Notez que `T` n'implémente pas nécessairement [`Clone`], il ne peut donc même pas cloner et réinitialiser `self.buf`.
/// Mais `take` peut être utilisé pour dissocier la valeur d'origine de `self.buf` de `self`, lui permettant d'être retourné:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Déplace `src` dans le `dest` référencé, renvoyant la valeur `dest` précédente.
///
/// Aucune des deux valeurs n'est supprimée.
///
/// * Si vous souhaitez remplacer les valeurs de deux variables, consultez [`swap`].
/// * Si vous souhaitez remplacer par une valeur par défaut, consultez [`take`].
///
/// # Examples
///
/// Un exemple simple:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` permet la consommation d'un champ struct en le remplaçant par une autre valeur.
/// Sans `replace`, vous pouvez rencontrer des problèmes comme ceux-ci:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Notez que `T` n'implémente pas nécessairement [`Clone`], donc nous ne pouvons même pas cloner `self.buf[i]` pour éviter le déplacement.
/// Mais `replace` peut être utilisé pour dissocier la valeur d'origine à cet index de `self`, lui permettant d'être retourné:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // SÉCURITÉ: Nous lisons à partir de `dest` mais y écrivons directement `src` par la suite,
    // de sorte que l'ancienne valeur ne soit pas dupliquée.
    // Rien n'est laissé tomber et rien ici ne peut panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Dispose d'une valeur.
///
/// Cela se fait en appelant l'implémentation de l'argument de [`Drop`][drop].
///
/// Cela ne fait rien pour les types qui implémentent `Copy`, par exemple
/// integers.
/// Ces valeurs sont copiées et _then_ déplacé dans la fonction, de sorte que la valeur persiste après cet appel de fonction.
///
///
/// Cette fonction n'est pas magique;il est littéralement défini comme
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Étant donné que `_x` est déplacé dans la fonction, il est automatiquement supprimé avant le retour de la fonction.
///
/// [drop]: Drop
///
/// # Examples
///
/// Utilisation de base:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // déposer explicitement le vector
/// ```
///
/// Puisque [`RefCell`] applique les règles d'emprunt au moment de l'exécution, `drop` peut libérer un emprunt [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // abandonner l'emprunt mutable sur cet emplacement
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Les entiers et autres types implémentant [`Copy`] ne sont pas affectés par `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // une copie de `x` est déplacée et déposée
/// drop(y); // une copie de `y` est déplacée et déposée
///
/// println!("x: {}, y: {}", x, y.0); // toujours disponible
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Interprète `src` comme ayant le type `&U`, puis lit `src` sans déplacer la valeur contenue.
///
/// Cette fonction supposera de manière non sûre que le pointeur `src` est valide pour les octets [`size_of::<U>`][size_of] en transmutant `&T` en `&U`, puis en lisant le `&U` (sauf que cela est fait d'une manière correcte même lorsque `&U` impose des exigences d'alignement plus strictes que `&T`).
/// Il créera également de manière non sécurisée une copie de la valeur contenue au lieu de sortir de `src`.
///
/// Ce n'est pas une erreur de compilation si `T` et `U` ont des tailles différentes, mais il est fortement recommandé de n'appeler cette fonction que lorsque `T` et `U` ont la même taille.Cette fonction déclenche [undefined behavior][ub] si `U` est plus grand que `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Copiez les données de 'foo_array' et traitez-les comme un 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Modifier les données copiées
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Le contenu de 'foo_array' n'aurait pas dû changer
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Si U a une exigence d'alignement plus élevée, src peut ne pas être correctement aligné.
    if align_of::<U>() > align_of::<T>() {
        // SÉCURITÉ: `src` est une référence dont la validité est garantie pour les lectures.
        // L'appelant doit garantir que la transmutation réelle est sûre.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // SÉCURITÉ: `src` est une référence dont la validité est garantie pour les lectures.
        // Nous venons de vérifier que `src as *const U` était correctement aligné.
        // L'appelant doit garantir que la transmutation réelle est sûre.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Type opaque représentant le discriminant d'une énumération.
///
/// Voir la fonction [`discriminant`] dans ce module pour plus d'informations.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Ces implémentations de trait ne peuvent pas être dérivées car nous ne voulons pas de limites sur T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Renvoie une valeur identifiant de manière unique la variante d'énumération dans `v`.
///
/// Si `T` n'est pas une énumération, l'appel de cette fonction n'entraînera pas de comportement indéfini, mais la valeur de retour n'est pas spécifiée.
///
///
/// # Stability
///
/// Le discriminant d'un variant d'énumération peut changer si la définition d'énumération change.
/// Un discriminant d'une variante ne changera pas entre les compilations avec le même compilateur.
///
/// # Examples
///
/// Cela peut être utilisé pour comparer les énumérations qui transportent des données, sans tenir compte des données réelles:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Renvoie le nombre de variantes dans le type d'énumération `T`.
///
/// Si `T` n'est pas une énumération, l'appel de cette fonction n'entraînera pas de comportement indéfini, mais la valeur de retour n'est pas spécifiée.
/// De même, si `T` est une énumération avec plus de variantes que `usize::MAX`, la valeur de retour n'est pas spécifiée.
/// Les variantes inhabitées seront comptées.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}