//! Implémentation de Rust panics via des abandons de processus
//!
//! Comparé à l'implémentation via déroulement, ce crate est *beaucoup* plus simple!Cela étant dit, ce n'est pas aussi polyvalent, mais voilà!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" la charge utile et le shim à l'abandon concerné sur la plate-forme en question.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // appeler std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Sur Windows, utilisez le mécanisme __fastfail spécifique au processeur.Dans Windows 8 et versions ultérieures, cela mettra fin au processus immédiatement sans exécuter de gestionnaire d'exceptions en cours.
            // Dans les versions antérieures de Windows, cette séquence d'instructions sera traitée comme une violation d'accès, mettant fin au processus mais sans nécessairement contourner tous les gestionnaires d'exceptions.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: c'est la même implémentation que dans le `abort_internal` de libstd
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// C'est ... un peu bizarre.Le tl; dr;est que cela est nécessaire pour lier correctement, l'explication plus longue est ci-dessous.
//
// À l'heure actuelle, les binaires de libcore/libstd que nous livrons sont tous compilés avec `-C panic=unwind`.Ceci est fait pour s'assurer que les binaires sont au maximum compatibles avec autant de situations que possible.
// Le compilateur, cependant, nécessite un "personality function" pour toutes les fonctions compilées avec `-C panic=unwind`.Cette fonction de personnalité est codée en dur avec le symbole `rust_eh_personality` et est définie par l'élément lang `eh_personality`.
//
// So...
// pourquoi ne pas simplement définir cet élément lang ici?Bonne question!La façon dont les runtimes panic sont liés est en fait un peu subtile en ce sens qu'ils sont "sort of" dans le magasin crate du compilateur, mais seulement réellement liés si un autre n'est pas réellement lié.
//
// Cela finit par signifier que ce crate et le panic_unwind crate peuvent apparaître dans le magasin crate du compilateur, et si les deux définissent l'élément lang `eh_personality`, cela provoquera une erreur.
//
// Pour gérer cela, le compilateur ne nécessite que le `eh_personality` soit défini si le runtime panic lié est le runtime de déroulement, et sinon il n'est pas nécessaire de le définir (à juste titre).
// Dans ce cas, cependant, cette bibliothèque définit simplement ce symbole donc il y a au moins une certaine personnalité quelque part.
//
// Essentiellement, ce symbole est simplement défini pour être câblé aux binaires libcore/libstd, mais il ne devrait jamais être appelé car nous ne lions pas du tout dans un runtime de déroulement.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // Sur x86_64-pc-windows-gnu, nous utilisons notre propre fonction de personnalité qui doit renvoyer `ExceptionContinueSearch` lorsque nous transmettons toutes nos images.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Semblable à ci-dessus, cela correspond à l'élément lang `eh_catch_typeinfo` qui n'est actuellement utilisé que sur Emscripten.
    //
    // Puisque panics ne génère pas d'exceptions et que les exceptions étrangères sont actuellement UB avec -C panic=abort (bien que cela puisse être sujet à changement), tout appel catch_unwind n'utilisera jamais ce typeinfo.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Ces deux objets sont appelés par nos objets de démarrage sur i686-pc-windows-gnu, mais ils n'ont rien à faire, donc les corps sont nops.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}