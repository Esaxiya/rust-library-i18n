// rsbegin.o et rsend.o sont les soi-disant "compiler runtime startup objects".
// Ils contiennent le code nécessaire pour initialiser correctement le runtime du compilateur.
//
// Lorsqu'une image exécutable ou dylib est liée, tous les codes utilisateur et bibliothèques sont "sandwiched" entre ces deux fichiers objets, donc le code ou les données de rsbegin.o deviennent les premiers dans les sections respectives de l'image, tandis que le code et les données de rsend.o deviennent les derniers.
// Cet effet peut être utilisé pour placer des symboles au début ou à la fin d'une section, ainsi que pour insérer les en-têtes ou pieds de page requis.
//
// Notez que le point d'entrée réel du module se trouve dans l'objet de démarrage du runtime C (généralement appelé `crtX.o`), qui appelle ensuite les rappels d'initialisation d'autres composants du runtime (enregistrés via une autre section d'image spéciale).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Marque le début de la section d'informations de déroulement du cadre de pile
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Espace à gratter pour la comptabilité interne du dérouleur.
    // Ceci est défini comme `struct object` dans $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Déroulez les routines info registration/deregistration.
    // Voir la documentation de libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // enregistrer les informations de déroulement au démarrage du module
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // désinscrire à l'arrêt
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Enregistrement de routine init/uninit spécifique à MinGW
    pub mod mingw_init {
        // Les objets de démarrage de MinGW (crt0.o/dllcrt0.o) invoqueront les constructeurs globaux dans les sections .ctors et .dtors au démarrage et à la sortie.
        // Dans le cas des DLL, cela est fait lorsque la DLL est chargée et déchargée.
        //
        // L'éditeur de liens triera les sections, ce qui garantit que nos rappels sont situés à la fin de la liste.
        // Puisque les constructeurs sont exécutés dans l'ordre inverse, cela garantit que nos rappels sont les premiers et les derniers exécutés.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: rappels d'initialisation C
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: rappels de terminaison C
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}