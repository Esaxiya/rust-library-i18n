//! Une bibliothèque de support pour les auteurs de macros lors de la définition de nouvelles macros.
//!
//! Cette bibliothèque, fournie par la distribution standard, fournit les types consommés dans les interfaces de définitions de macros définies de manière procédurale telles que les macros de type fonction `#[proc_macro]`, les attributs de macro `#[proc_macro_attribute]` et les attributs de dérivation personnalisés`#[proc_macro_derive]`.
//!
//!
//! Voir [the book] pour plus.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Détermine si proc_macro a été rendu accessible au programme en cours d'exécution.
///
/// Le proc_macro crate est uniquement destiné à être utilisé dans l'implémentation de macros procédurales.Toutes les fonctions de ce crate panic si elles sont appelées de l'extérieur d'une macro procédurale, comme à partir d'un script de construction ou d'un test unitaire ou d'un binaire Rust ordinaire.
///
/// En tenant compte des bibliothèques Rust qui sont conçues pour prendre en charge les cas d'utilisation macro et non macro, `proc_macro::is_available()` fournit un moyen sans panique de détecter si l'infrastructure requise pour utiliser l'API de proc_macro est actuellement disponible.
/// Renvoie true si elle est invoquée depuis l'intérieur d'une macro procédurale, false si elle est invoquée depuis n'importe quel autre binaire.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Le type principal fourni par ce crate, représentant un flux abstrait de tokens, ou, plus précisément, une séquence d'arbres token.
/// Le type fournit des interfaces pour itérer sur ces arbres token et, inversement, pour collecter un certain nombre d'arbres token en un seul flux.
///
///
/// Il s'agit à la fois de l'entrée et de la sortie des définitions `#[proc_macro]`, `#[proc_macro_attribute]` et `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Erreur renvoyée par `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Renvoie un `TokenStream` vide ne contenant aucun arbre token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Vérifie si ce `TokenStream` est vide.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Tente de diviser la chaîne en tokens et d'analyser ces tokens en un flux token.
/// Peut échouer pour un certain nombre de raisons, par exemple, si la chaîne contient des délimiteurs non équilibrés ou des caractères qui n'existent pas dans la langue.
///
/// Tous les tokens du flux analysé obtiennent des étendues `Span::call_site()`.
///
/// NOTE: certaines erreurs peuvent provoquer panics au lieu de renvoyer `LexError`.Nous nous réservons le droit de changer ces erreurs en «LexError» plus tard.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, le pont ne fournit que `to_string`, implémentez `fmt::Display` en fonction de celui-ci (l'inverse de la relation habituelle entre les deux).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Imprime le flux token sous la forme d'une chaîne qui est censée être convertible sans perte dans le même flux token (étendues modulo), à l'exception éventuellement de `TokenTree: : Group`s avec des délimiteurs `Delimiter::None` et des littéraux numériques négatifs.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Imprime token sous une forme pratique pour le débogage.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Crée un flux token contenant un seul arbre token.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Collecte un certain nombre d'arbres token en un seul flux.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Une opération "flattening" sur les flux token collecte les arbres token à partir de plusieurs flux token en un seul flux.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Utilisez une implémentation optimisée if/when possible.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Détails d'implémentation publique pour le type `TokenStream`, tels que les itérateurs.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Un itérateur sur les TokenTree de `TokenStream`.
    /// L'itération est "shallow", par exemple, l'itérateur ne rentre pas dans des groupes délimités et retourne des groupes entiers sous forme d'arbres token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` accepte des tokens arbitraires et se développe en un `TokenStream` décrivant l'entrée.
/// Par exemple, `quote!(a + b)` produira une expression qui, une fois évaluée, construit le `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// La suppression des guillemets se fait avec `$` et fonctionne en prenant l'identifiant suivant unique comme terme sans guillemets.
/// Pour citer `$` lui-même, utilisez `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Une région de code source, ainsi que des informations d'extension de macro.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Crée un nouveau `Diagnostic` avec le `message` donné à la plage `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Une étendue qui se résout sur le site de définition de macro.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// La durée de l'appel de la macro procédurale actuelle.
    /// Les identifiants créés avec cette étendue seront résolus comme s'ils avaient été écrits directement à l'emplacement de l'appel de macro (hygiène du site d'appel) et tout autre code sur le site d'appel de macro pourra également s'y référer.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Une étendue qui représente l'hygiène `macro_rules`, et se résout parfois sur le site de définition de macro (variables locales, étiquettes, `$crate`) et parfois sur le site d'appel de macro (tout le reste).
    ///
    /// L'emplacement de la plage est pris à partir du site d'appel.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Le fichier source d'origine vers lequel pointe cette plage.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// Le `Span` pour le tokens dans l'extension de macro précédente à partir de laquelle `self` a été généré, le cas échéant.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// La plage du code source d'origine à partir de laquelle `self` a été généré.
    /// Si ce `Span` n'a pas été généré à partir d'autres extensions de macro, la valeur de retour est la même que `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Obtient le line/column de départ dans le fichier source pour cette étendue.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Obtient le line/column de fin dans le fichier source pour cette étendue.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Crée une nouvelle étendue englobant `self` et `other`.
    ///
    /// Renvoie `None` si `self` et `other` proviennent de fichiers différents.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Crée une nouvelle étendue avec les mêmes informations line/column que `self` mais qui résout les symboles comme si elles étaient à `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Crée une nouvelle plage avec le même comportement de résolution de nom que `self` mais avec les informations line/column de `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Se compare aux travées pour voir si elles sont égales.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Renvoie le texte source derrière une étendue.
    /// Cela préserve le code source d'origine, y compris les espaces et les commentaires.
    /// Il ne renvoie un résultat que si l'étendue correspond au code source réel.
    ///
    /// Note: Le résultat observable d'une macro ne doit reposer que sur le tokens et non sur ce texte source.
    ///
    /// Le résultat de cette fonction est un meilleur effort à utiliser uniquement pour les diagnostics.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Imprime une étendue sous une forme pratique pour le débogage.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Une paire ligne-colonne représentant le début ou la fin d'un `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Ligne indexée 1 dans le fichier source sur laquelle le span commence ou se termine (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Colonne indexée 0 (en caractères UTF-8) dans le fichier source sur laquelle le span commence ou se termine (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Le fichier source d'un `Span` donné.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Obtient le chemin d'accès à ce fichier source.
    ///
    /// ### Note
    /// Si la plage de code associée à ce `SourceFile` a été générée par une macro externe, cette macro, cela peut ne pas être un chemin réel sur le système de fichiers.
    /// Utilisez [`is_real`] pour vérifier.
    ///
    /// Notez également que même si `is_real` renvoie `true`, si `--remap-path-prefix` a été passé sur la ligne de commande, le chemin tel que donné peut ne pas être valide.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Renvoie `true` si ce fichier source est un fichier source réel et n'est pas généré par l'expansion d'une macro externe.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Il s'agit d'un hack jusqu'à ce que les travées d'intercrate soient implémentées et que nous puissions avoir de vrais fichiers source pour les travées générées dans des macros externes.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Un seul token ou une séquence délimitée d'arbres token (par exemple, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Un flux token entouré de délimiteurs de parenthèses.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Un identifiant.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Un seul caractère de ponctuation («+», `,`, `$`, etc.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Un caractère littéral (`'a'`), une chaîne (`"hello"`), un nombre (`2.3`), etc.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Renvoie l'étendue de cette arborescence, en déléguant à la méthode `span` du token contenu ou à un flux délimité.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Configure la plage pour *uniquement ce token*.
    ///
    /// Notez que si ce token est un `Group` alors cette méthode ne configurera pas l'étendue de chacun des tokens internes, cela déléguera simplement à la méthode `set_span` de chaque variante.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Imprime l'arborescence token sous une forme pratique pour le débogage.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Chacun de ceux-ci a le nom dans le type de structure dans le débogage dérivé, alors ne vous embêtez pas avec une couche supplémentaire d'indirection
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, le pont ne fournit que `to_string`, implémentez `fmt::Display` en fonction de celui-ci (l'inverse de la relation habituelle entre les deux).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Imprime l'arborescence token comme une chaîne qui est censée être convertible sans perte dans le même arbre token (étendues modulo), à l'exception éventuellement de `TokenTree: : Group`s avec des délimiteurs `Delimiter::None` et des littéraux numériques négatifs.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Un flux token délimité.
///
/// Un `Group` contient en interne un `TokenStream` qui est entouré de `Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Décrit comment une séquence d'arbres token est délimitée.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Un délimiteur implicite, qui peut, par exemple, apparaître autour de tokens provenant d'un "macro variable" `$var`.
    /// Il est important de préserver les priorités des opérateurs dans des cas comme `$var * 3` où `$var` est `1 + 2`.
    /// Les délimiteurs implicites peuvent ne pas survivre à l'aller-retour d'un flux token via une chaîne.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Crée un nouveau `Group` avec le délimiteur et le flux token donnés.
    ///
    /// Ce constructeur définira l'étendue de ce groupe sur `Span::call_site()`.
    /// Pour modifier la plage, vous pouvez utiliser la méthode `set_span` ci-dessous.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Renvoie le délimiteur de ce `Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Renvoie le `TokenStream` de tokens délimité dans ce `Group`.
    ///
    /// Notez que le flux token retourné n'inclut pas le délimiteur renvoyé ci-dessus.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Renvoie l'étendue des délimiteurs de ce flux token, couvrant l'intégralité du `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Renvoie l'étendue pointant vers le délimiteur d'ouverture de ce groupe.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Renvoie la plage pointant vers le délimiteur de fermeture de ce groupe.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Configure la plage pour les délimiteurs de ce `Groupe`, mais pas pour son tokens interne.
    ///
    /// Cette méthode ne définira **pas** l'étendue de tous les tokens internes couverts par ce groupe, mais elle ne définira plutôt l'étendue du délimiteur tokens qu'au niveau du `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, le pont ne fournit que `to_string`, implémentez `fmt::Display` en fonction de celui-ci (l'inverse de la relation habituelle entre les deux).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Imprime le groupe sous la forme d'une chaîne qui devrait être convertible sans perte dans le même groupe (étendues modulo), à l'exception éventuellement de `TokenTree: : Group`s avec des délimiteurs `Delimiter::None`.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// Un `Punct` est un caractère de ponctuation unique comme `+`, `-` ou `#`.
///
/// Les opérateurs à plusieurs caractères tels que `+=` sont représentés comme deux instances de `Punct` avec différentes formes de `Spacing` renvoyées.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Si un `Punct` est immédiatement suivi par un autre `Punct` ou suivi par un autre token ou un espace blanc.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// par exemple, `+` est `Alone` dans `+ =`, `+ident` ou `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// par exemple, `+` est `Joint` dans `+=` ou `'#`.
    /// De plus, le guillemet simple `'` peut se joindre aux identifiants pour former des durées de vie `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Crée un nouveau `Punct` à partir du caractère et de l'espacement donnés.
    /// L'argument `ch` doit être un caractère de ponctuation valide autorisé par la langue, sinon la fonction sera panic.
    ///
    /// Le `Punct` retourné aura la plage par défaut de `Span::call_site()` qui peut être configurée plus avant avec la méthode `set_span` ci-dessous.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Renvoie la valeur de ce caractère de ponctuation sous la forme `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Renvoie l'espacement de ce caractère de ponctuation, indiquant s'il est immédiatement suivi par un autre `Punct` dans le flux token, afin qu'ils puissent potentiellement être combinés en un opérateur à plusieurs caractères (`Joint`), ou il est suivi par un autre token ou un espace (`Alone`) donc l'opérateur a certainement terminé.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Renvoie l'étendue de ce caractère de ponctuation.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configurez l'étendue de ce caractère de ponctuation.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, le pont ne fournit que `to_string`, implémentez `fmt::Display` en fonction de celui-ci (l'inverse de la relation habituelle entre les deux).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Imprime le caractère de ponctuation sous forme de chaîne qui doit être reconvertie sans perte en le même caractère.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Un identifiant (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Crée un nouveau `Ident` avec le `string` donné ainsi que le `span` spécifié.
    /// L'argument `string` doit être un identifiant valide autorisé par la langue (y compris les mots-clés, par exemple `self` ou `fn`).Sinon, la fonction sera panic.
    ///
    /// Notez que `span`, actuellement dans rustc, configure les informations d'hygiène pour cet identifiant.
    ///
    /// À partir de ce moment, `Span::call_site()` opte explicitement pour l'hygiène "call-site", ce qui signifie que les identifiants créés avec cette étendue seront résolus comme s'ils étaient écrits directement à l'emplacement de l'appel de macro, et que tout autre code sur le site d'appel de macro pourra faire référence à eux aussi.
    ///
    ///
    /// Les extensions ultérieures telles que `Span::def_site()` permettront d'activer l'hygiène "definition-site", ce qui signifie que les identifiants créés avec cette plage seront résolus à l'emplacement de la définition de macro et que tout autre code sur le site d'appel de macro ne pourra pas y faire référence.
    ///
    /// En raison de l'importance actuelle de l'hygiène, ce constructeur, contrairement aux autres tokens, nécessite un `Span` à spécifier lors de la construction.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Identique à `Ident::new`, mais crée un identifiant brut (`r#ident`).
    /// L'argument `string` soit un identifiant valide autorisé par la langue (y compris les mots-clés, par exemple `fn`).
    /// Mots-clés utilisables dans les segments de chemin (par exemple
    /// `self`, `super`) ne sont pas pris en charge et provoquera un panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Renvoie l'étendue de ce `Ident`, englobant la chaîne entière retournée par [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configure l'étendue de ce `Ident`, en modifiant éventuellement son contexte d'hygiène.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, le pont ne fournit que `to_string`, implémentez `fmt::Display` en fonction de celui-ci (l'inverse de la relation habituelle entre les deux).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Imprime l'identifiant sous forme de chaîne qui doit être reconvertie sans perte en le même identifiant.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Une chaîne littérale (`"hello"`), une chaîne d'octets (`b"hello"`), un caractère (`'a'`), un caractère d'octet (`b'a'`), un nombre entier ou à virgule flottante avec ou sans suffixe («1», `1u8`, `2.3`, `2.3f32`).
///
/// Les littéraux booléens comme `true` et `false` n'appartiennent pas ici, ce sont des ident.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Crée un nouveau littéral entier suffixé avec la valeur spécifiée.
        ///
        /// Cette fonction créera un entier comme `1u32` où la valeur entière spécifiée est la première partie du token et l'intégrale est également suffixée à la fin.
        /// Les littéraux créés à partir de nombres négatifs peuvent ne pas survivre aux allers-retours via `TokenStream` ou des chaînes et peuvent être divisés en deux tokens (`-` et littéral positif).
        ///
        ///
        /// Les littéraux créés par cette méthode ont la portée `Span::call_site()` par défaut, qui peut être configurée avec la méthode `set_span` ci-dessous.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Crée un nouveau littéral entier non suffixé avec la valeur spécifiée.
        ///
        /// Cette fonction créera un entier comme `1` où la valeur entière spécifiée est la première partie du token.
        /// Aucun suffixe n'est spécifié sur ce token, ce qui signifie que les invocations comme `Literal::i8_unsuffixed(1)` sont équivalentes à `Literal::u32_unsuffixed(1)`.
        /// Les littéraux créés à partir de nombres négatifs peuvent ne pas survivre aux rountrips via `TokenStream` ou des chaînes et peuvent être divisés en deux tokens (`-` et littéral positif).
        ///
        ///
        /// Les littéraux créés par cette méthode ont la portée `Span::call_site()` par défaut, qui peut être configurée avec la méthode `set_span` ci-dessous.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Crée un nouveau littéral à virgule flottante sans suffixe.
    ///
    /// Ce constructeur est similaire à ceux comme `Literal::i8_unsuffixed` où la valeur du flottant est émise directement dans le token mais aucun suffixe n'est utilisé, il peut donc être déduit comme étant un `f64` plus tard dans le compilateur.
    ///
    /// Les littéraux créés à partir de nombres négatifs peuvent ne pas survivre aux rountrips via `TokenStream` ou des chaînes et peuvent être divisés en deux tokens (`-` et littéral positif).
    ///
    /// # Panics
    ///
    /// Cette fonction nécessite que le flottant spécifié soit fini, par exemple s'il est infini ou NaN, cette fonction sera panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Crée un nouveau littéral à virgule flottante avec suffixe.
    ///
    /// Ce constructeur créera un littéral comme `1.0f32` où la valeur spécifiée est la partie précédente du token et `f32` est le suffixe du token.
    /// Ce token sera toujours déduit comme étant un `f32` dans le compilateur.
    /// Les littéraux créés à partir de nombres négatifs peuvent ne pas survivre aux rountrips via `TokenStream` ou des chaînes et peuvent être divisés en deux tokens (`-` et littéral positif).
    ///
    ///
    /// # Panics
    ///
    /// Cette fonction nécessite que le flottant spécifié soit fini, par exemple s'il est infini ou NaN, cette fonction sera panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Crée un nouveau littéral à virgule flottante sans suffixe.
    ///
    /// Ce constructeur est similaire à ceux comme `Literal::i8_unsuffixed` où la valeur du flottant est émise directement dans le token mais aucun suffixe n'est utilisé, il peut donc être déduit comme étant un `f64` plus tard dans le compilateur.
    ///
    /// Les littéraux créés à partir de nombres négatifs peuvent ne pas survivre aux rountrips via `TokenStream` ou des chaînes et peuvent être divisés en deux tokens (`-` et littéral positif).
    ///
    /// # Panics
    ///
    /// Cette fonction nécessite que le flottant spécifié soit fini, par exemple s'il est infini ou NaN, cette fonction sera panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Crée un nouveau littéral à virgule flottante avec suffixe.
    ///
    /// Ce constructeur créera un littéral comme `1.0f64` où la valeur spécifiée est la partie précédente du token et `f64` est le suffixe du token.
    /// Ce token sera toujours déduit comme étant un `f64` dans le compilateur.
    /// Les littéraux créés à partir de nombres négatifs peuvent ne pas survivre aux rountrips via `TokenStream` ou des chaînes et peuvent être divisés en deux tokens (`-` et littéral positif).
    ///
    ///
    /// # Panics
    ///
    /// Cette fonction nécessite que le flottant spécifié soit fini, par exemple s'il est infini ou NaN, cette fonction sera panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Chaîne littérale.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Caractère littéral.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Chaîne d'octets littérale.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Renvoie l'étendue englobant ce littéral.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configure la plage associée à ce littéral.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Renvoie un `Span` qui est un sous-ensemble de `self.span()` contenant uniquement les octets source de la plage `range`.
    /// Renvoie `None` si la plage potentielle tronquée est en dehors des limites de `self`.
    ///
    // FIXME(SergioBenitez): vérifiez que la plage d'octets commence et se termine à une limite UTF-8 de la source.
    // sinon, il est probable qu'un panic se produise ailleurs lorsque le texte source est imprimé.
    // FIXME(SergioBenitez): il n'y a aucun moyen pour l'utilisateur de savoir à quoi correspond réellement `self.span()`, donc cette méthode ne peut actuellement être appelée qu'à l'aveugle.
    // Par exemple, `to_string()` pour le caractère 'c' renvoie "'\u{63}'";il n'y a aucun moyen pour l'utilisateur de savoir si le texte source était 'c' ou s'il s'agissait de '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) quelque chose qui ressemble à `Option::cloned`, mais pour `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, le pont ne fournit que `to_string`, implémentez `fmt::Display` en fonction de celui-ci (l'inverse de la relation habituelle entre les deux).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Imprime le littéral sous la forme d'une chaîne qui doit être convertible sans perte dans le même littéral (à l'exception de l'arrondi possible des littéraux à virgule flottante).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Suivi de l'accès aux variables d'environnement.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Récupérez une variable d'environnement et ajoutez-la pour créer des informations de dépendance.
    /// Le système de construction exécutant le compilateur saura que la variable a été accédée pendant la compilation, et pourra réexécuter la construction lorsque la valeur de cette variable changera.
    ///
    /// Outre le suivi des dépendances, cette fonction doit être équivalente à `env::var` de la bibliothèque standard, sauf que l'argument doit être UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}