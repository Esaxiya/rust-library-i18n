# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Une bibliothèque pour l'acquisition de backtraces lors de l'exécution pour Rust.
Cette bibliothèque vise à améliorer le support de la bibliothèque standard en fournissant une interface de programmation avec laquelle travailler, mais elle prend également en charge simplement l'impression de la trace actuelle comme panics de libstd.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Pour simplement capturer une trace arrière et reporter son traitement à une date ultérieure, vous pouvez utiliser le type `Backtrace` de niveau supérieur.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Si, cependant, vous souhaitez un accès plus brut à la fonctionnalité de traçage réelle, vous pouvez utiliser directement les fonctions `trace` et `resolve`.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Résolvez ce pointeur d'instruction sur un nom de symbole
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // continuez à la prochaine image
    });
}
```

# License

Ce projet est autorisé sous l'un ou l'autre des

 * Licence Apache, version 2.0, ([LICENSE-APACHE](LICENSE-APACHE) ou http://www.apache.org/licenses/LICENSE-2.0)
 * Licence MIT ([LICENSE-MIT](LICENSE-MIT) ou http://opensource.org/licenses/MIT)

à votre choix.

### Contribution

Sauf indication contraire explicite de votre part, toute contribution soumise intentionnellement pour inclusion dans backtrace-rs par vous, telle que définie dans la licence Apache-2.0, fera l'objet d'une double licence comme ci-dessus, sans conditions supplémentaires.







