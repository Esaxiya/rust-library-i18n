use core::ffi::c_void;
use core::fmt;

/// Inspecte la pile d'appels actuelle, en passant toutes les trames actives dans la fermeture fournie pour calculer une trace de pile.
///
/// Cette fonction est le cheval de bataille de cette bibliothèque dans le calcul des traces de pile pour un programme.La fermeture `cb` donnée donne des instances d'un `Frame` qui représentent des informations sur cette trame d'appel sur la pile.
/// La fermeture donne des cadres de manière descendante (plus récemment appelés fonctions en premier).
///
/// La valeur de retour de la fermeture indique si la trace arrière doit se poursuivre.Une valeur de retour de `false` mettra fin à la trace arrière et retournera immédiatement.
///
/// Une fois qu'un `Frame` est acquis, vous voudrez probablement appeler `backtrace::resolve` pour convertir le `ip` (pointeur d'instruction) ou l'adresse de symbole en un `Symbol` à travers lequel le nom et/ou le nom de fichier/numéro de ligne peuvent être appris.
///
///
/// Notez qu'il s'agit d'une fonction de niveau relativement bas et si vous souhaitez, par exemple, capturer une trace arrière pour être inspectée plus tard, le type `Backtrace` peut être plus approprié.
///
/// # Fonctionnalités requises
///
/// Cette fonction nécessite l'activation de la fonction `std` du `backtrace` crate et la fonction `std` est activée par défaut.
///
/// # Panics
///
/// Cette fonction s'efforce de ne jamais panic, mais si le `cb` a fourni panics alors certaines plates-formes forceront un double panic à abandonner le processus.
/// Certaines plates-formes utilisent une bibliothèque C qui utilise en interne des rappels qui ne peuvent pas être déroulés, donc paniquer à partir de `cb` peut déclencher un abandon du processus.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // continuer la trace
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Identique à `trace`, mais non sécurisé car non synchronisé.
///
/// Cette fonction n'a pas de garanties de synchronisation mais est disponible lorsque la fonctionnalité `std` de ce crate n'est pas compilée dans.
/// Voir la fonction `trace` pour plus de documentation et d'exemples.
///
/// # Panics
///
/// Voir les informations sur `trace` pour les mises en garde sur la panique `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// Un trait représentant une image d'un backtrace, cédé à la fonction `trace` de ce crate.
///
/// La fermeture de la fonction de traçage produira des trames et la trame est virtuellement distribuée car l'implémentation sous-jacente n'est pas toujours connue avant l'exécution.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Renvoie le pointeur d'instruction actuel de cette image.
    ///
    /// C'est normalement la prochaine instruction à exécuter dans le cadre, mais toutes les implémentations ne la répertorient pas avec une précision de 100% (mais c'est généralement assez proche).
    ///
    ///
    /// Il est recommandé de transmettre cette valeur à `backtrace::resolve` pour la transformer en nom de symbole.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Renvoie le pointeur de pile actuel de cette image.
    ///
    /// Dans le cas où un backend ne peut pas récupérer le pointeur de pile pour cette trame, un pointeur nul est renvoyé.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Renvoie l'adresse du symbole de départ de la trame de cette fonction.
    ///
    /// Cela tentera de rembobiner le pointeur d'instruction renvoyé par `ip` au début de la fonction, renvoyant cette valeur.
    ///
    /// Dans certains cas, cependant, les backends renverront simplement `ip` à partir de cette fonction.
    ///
    /// La valeur renvoyée peut parfois être utilisée si `backtrace::resolve` a échoué sur le `ip` indiqué ci-dessus.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Renvoie l'adresse de base du module auquel appartient la trame.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Cela doit venir en premier, pour s'assurer que Miri a la priorité sur la plate-forme hôte
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // utilisé uniquement dans dbghelp symbolize
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}