//! Prise en charge de la symbolisation à l'aide du `gimli` crate sur crates.io
//!
//! Il s'agit de l'implémentation de symbolisation par défaut pour Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // «La durée de vie statique est un mensonge à pirater autour du manque de support des structures auto-référentielles.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Convertissez en 'durées de vie statiques puisque les symboles ne devraient emprunter que `map` et `stash` et nous les conservons ci-dessous.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Pour charger des bibliothèques natives sur Windows, voir une discussion sur rust-lang/rust#71060 pour les différentes stratégies ici.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // Les bibliothèques MinGW ne prennent actuellement pas en charge ASLR (rust-lang/rust#16514), mais les DLL peuvent toujours être déplacées dans l'espace d'adressage.
            // Il semble que les adresses dans les informations de débogage sont toutes comme si cette bibliothèque était chargée à son "image base", qui est un champ dans ses en-têtes de fichier COFF.
            // Puisque c'est ce que semble afficher debuginfo, nous analysons la table des symboles et stockons les adresses comme si la bibliothèque était également chargée à "image base".
            //
            // Cependant, la bibliothèque peut ne pas être chargée sur "image base".
            // (probablement quelque chose d'autre peut y être chargé?) C'est là que le champ `bias` entre en jeu, et nous devons déterminer la valeur de `bias` ici.Malheureusement, il n'est pas clair comment acquérir cela à partir d'un module chargé.
            // Ce que nous avons, cependant, est l'adresse de chargement réelle (`modBaseAddr`).
            //
            // En guise de dérobade pour l'instant, nous mmap le fichier, lisons les informations d'en-tête du fichier, puis déposons le mmap.C'est du gaspillage car nous rouvrirons probablement le mmap plus tard, mais cela devrait fonctionner assez bien pour le moment.
            //
            // Une fois que nous avons le `image_base` (emplacement de chargement souhaité) et le `base_addr` (emplacement de chargement réel), nous pouvons remplir le `bias` (différence entre le réel et le désiré), puis l'adresse indiquée de chaque segment est le `image_base` puisque c'est ce que dit le fichier.
            //
            //
            // Pour l'instant, il semble que contrairement à ELF/MachO, nous pouvons nous contenter d'un segment par bibliothèque, en utilisant `modBaseSize` comme taille totale.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS utilise le format de fichier Mach-O et utilise des API spécifiques à DYLD pour charger une liste de bibliothèques natives faisant partie de l'application.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Récupérez également le nom de cette bibliothèque qui correspond au chemin d'accès où la charger.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Chargez l'en-tête d'image de cette bibliothèque et déléguez à `object` pour analyser toutes les commandes de chargement afin que nous puissions comprendre tous les segments impliqués ici.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Parcourez les segments et enregistrez les régions connues pour les segments que nous trouvons.
            // Enregistrez en outre des informations sur les segments de texte pour un traitement ultérieur, voir les commentaires ci-dessous.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Déterminez le "slide" pour cette bibliothèque qui finit par être le biais que nous utilisons pour déterminer où dans la mémoire les objets sont chargés.
            // C'est un calcul un peu étrange cependant et est le résultat d'essayer quelques choses dans la nature et de voir ce qui colle.
            //
            // L'idée générale est que le `bias` plus le `stated_virtual_memory_address` d'un segment se trouvera là où dans l'espace d'adressage réel le segment réside.
            // L'autre chose sur laquelle nous nous appuyons cependant est qu'une adresse réelle moins le `bias` est l'index à rechercher dans la table des symboles et dans les informations de débogage.
            //
            // Il s'avère cependant que pour les bibliothèques chargées par le système, ces calculs sont incorrects.Pour les exécutables natifs, cependant, cela semble correct.
            // En soulevant une certaine logique de la source de LLDB, il a une casse spéciale pour la première section `__TEXT` chargée à partir du décalage de fichier 0 avec une taille non nulle.
            // Pour une raison quelconque, lorsque cela est présent, cela semble signifier que la table des symboles est relative uniquement à la diapositive vmaddr de la bibliothèque.
            // S'il n'est *pas* présent, la table des symboles est relative à la diapositive vmaddr plus l'adresse indiquée du segment.
            //
            // Pour gérer cette situation si nous ne trouvons *pas* une section de texte au décalage de fichier zéro, nous augmentons le biais de l'adresse indiquée de la première section de texte et diminuons également toutes les adresses indiquées de ce montant.
            //
            // De cette façon, la table des symboles apparaît toujours par rapport au montant du biais de la bibliothèque.
            // Cela semble avoir les bons résultats pour la symbolisation via la table des symboles.
            //
            // Honnêtement, je ne suis pas tout à fait sûr que ce soit juste ou s'il y a autre chose qui devrait indiquer comment faire cela.
            // Pour l'instant, cela semble fonctionner assez bien (?) et nous devrions toujours être en mesure de le modifier au fil du temps si nécessaire.
            //
            // Pour plus d'informations, consultez #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Autre Unix (par exemple
        // Linux) utilisent ELF comme format de fichier objet et implémentent généralement une API appelée `dl_iterate_phdr` pour charger des bibliothèques natives.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` devrait être un pointeurs valides.
        // `vec` doit être un pointeur valide vers un `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 ne prend pas en charge nativement les informations de débogage, mais le système de construction placera les informations de débogage sur le chemin `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Tout le reste devrait utiliser ELF, mais ne sait pas comment charger les bibliothèques natives.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Toutes les bibliothèques partagées connues qui ont été chargées.
    libraries: Vec<Library>,

    /// Cache de mappages où nous conservons les informations naines analysées.
    ///
    /// Cette liste a une capacité fixe pour tout son temps de levage qui n'augmente jamais.
    /// L'élément `usize` de chaque paire est un index dans `libraries` ci-dessus où `usize::max_value()` représente l'exécutable actuel.
    ///
    /// Le `Mapping` correspond aux informations naines analysées correspondantes.
    ///
    /// Notez qu'il s'agit essentiellement d'un cache LRU et nous allons déplacer les choses ici en symbolisant les adresses.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Les segments de cette bibliothèque chargés en mémoire et où ils sont chargés.
    segments: Vec<LibrarySegment>,
    /// Le "bias" de cette bibliothèque, généralement là où il est chargé en mémoire.
    /// Cette valeur est ajoutée à l'adresse indiquée de chaque segment pour obtenir l'adresse de mémoire virtuelle réelle dans laquelle le segment est chargé.
    /// De plus, ce biais est soustrait des adresses de mémoire virtuelle réelles pour les indexer dans debuginfo et la table des symboles.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// L'adresse indiquée de ce segment dans le fichier objet.
    /// Ce n'est pas vraiment là où le segment est chargé, mais plutôt cette adresse plus le `bias` de la bibliothèque contenant est l'endroit où le trouver.
    ///
    stated_virtual_memory_address: usize,
    /// La taille de ce segment en mémoire.
    len: usize,
}

// dangereux car il doit être synchronisé en externe
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // dangereux car il doit être synchronisé en externe
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Un cache LRU très petit et très simple pour les mappages d'informations de débogage.
        //
        // Le taux de réussite doit être très élevé, car la pile typique ne se croise pas entre de nombreuses bibliothèques partagées.
        //
        // Les structures `addr2line::Context` sont assez chères à créer.
        // Son coût devrait être amorti par les requêtes `locate` ultérieures, qui exploitent les structures construites lors de la construction de `addr2line: : Context`s pour obtenir de belles accélérations.
        //
        // Si nous n'avions pas ce cache, cet amortissement ne se produirait jamais, et symboliser les retours en arrière serait ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Tout d'abord, testez si ce `lib` a un segment contenant le `addr` (gestion du déplacement).Si cette vérification réussit, nous pouvons continuer ci-dessous et traduire réellement l'adresse.
                //
                // Notez que nous utilisons `wrapping_add` ici pour éviter les contrôles de dépassement de capacité.On a vu dans la nature que le calcul du biais SVMA + déborde.
                // Cela semble un peu étrange que cela se produise, mais nous ne pouvons pas faire grand-chose à part probablement simplement ignorer ces segments, car ils pointent probablement vers l'espace.
                //
                // Cela est apparu à l'origine dans rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Maintenant que nous savons que `lib` contient `addr`, nous pouvons compenser le biais pour trouver l'adresse mémoire virutale indiquée.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Invariant: après que cette condition se termine sans retour anticipé
        // suite à une erreur, l'entrée de cache pour ce chemin est à l'index 0.

        if let Some(idx) = idx {
            // Lorsque le mappage est déjà dans le cache, déplacez-le vers l'avant.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Lorsque le mappage n'est pas dans le cache, créez un nouveau mappage, insérez-le à l'avant du cache et supprimez l'entrée de cache la plus ancienne si nécessaire.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // ne laissez pas s'échapper la durée de vie du `'static`, assurez-vous qu'elle ne concerne que nous-mêmes
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Prolongez la durée de vie de `sym` à `'static` puisque nous sommes malheureusement obligés de le faire ici, mais il ne sera jamais publié comme référence, donc aucune référence ne devrait être persistante au-delà de ce cadre de toute façon.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Enfin, obtenez un mappage mis en cache ou créez un nouveau mappage pour ce fichier et évaluez les informations DWARF pour trouver le file/line/name pour cette adresse.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Nous avons pu localiser les informations de cadre pour ce symbole, et le cadre de `addr2line` a en interne tous les détails.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Impossible de trouver les informations de débogage, mais nous les avons trouvées dans la table des symboles de l'exécutable elf.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}