use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Résolvez une adresse en symbole, en passant le symbole à la fermeture spécifiée.
///
/// Cette fonction recherchera l'adresse donnée dans des zones telles que la table de symboles locale, la table de symboles dynamiques ou les informations de débogage DWARF (selon l'implémentation activée) pour trouver les symboles à générer.
///
///
/// La fermeture ne peut pas être appelée si la résolution n'a pas pu être effectuée, et elle peut également être appelée plus d'une fois dans le cas de fonctions intégrées.
///
/// Les symboles générés représentent l'exécution au `addr` spécifié, renvoyant des paires file/line pour cette adresse (si disponible).
///
/// Notez que si vous avez un `Frame`, il est recommandé d'utiliser la fonction `resolve_frame` à la place de celle-ci.
///
/// # Fonctionnalités requises
///
/// Cette fonction nécessite l'activation de la fonction `std` du `backtrace` crate et la fonction `std` est activée par défaut.
///
/// # Panics
///
/// Cette fonction s'efforce de ne jamais panic, mais si le `cb` a fourni panics alors certaines plates-formes forceront un double panic à abandonner le processus.
/// Certaines plates-formes utilisent une bibliothèque C qui utilise en interne des rappels qui ne peuvent pas être déroulés, donc paniquer à partir de `cb` peut déclencher un abandon du processus.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // ne regardez que le cadre supérieur
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Résolvez une image précédemment capturée en un symbole, en passant le symbole à la fermeture spécifiée.
///
/// Cette functin remplit la même fonction que `resolve` sauf qu'elle prend un `Frame` comme argument au lieu d'une adresse.
/// Cela peut permettre à certaines implémentations de plate-forme de backtracing de fournir des informations de symbole plus précises ou des informations sur les cadres en ligne, par exemple.
///
/// Il est recommandé de l'utiliser si vous le pouvez.
///
/// # Fonctionnalités requises
///
/// Cette fonction nécessite l'activation de la fonction `std` du `backtrace` crate et la fonction `std` est activée par défaut.
///
/// # Panics
///
/// Cette fonction s'efforce de ne jamais panic, mais si le `cb` a fourni panics alors certaines plates-formes forceront un double panic à abandonner le processus.
/// Certaines plates-formes utilisent une bibliothèque C qui utilise en interne des rappels qui ne peuvent pas être déroulés, donc paniquer à partir de `cb` peut déclencher un abandon du processus.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // ne regardez que le cadre supérieur
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Les valeurs IP des cadres de pile sont généralement (always?) l'instruction *après* l'appel qui est la trace réelle de la pile.
// Le symboliser sur fait que le numéro filename/line est en avance et peut-être dans le vide s'il est proche de la fin de la fonction.
//
// Cela semble être fondamentalement toujours le cas sur toutes les plates-formes, donc nous soustrayons toujours une d'une adresse IP résolue pour la résoudre à l'instruction d'appel précédente au lieu de l'instruction renvoyée.
//
//
// Idéalement, nous ne ferions pas cela.
// Idéalement, nous demanderions aux appelants des API `resolve` ici de faire manuellement le -1 et de rendre compte qu'ils veulent des informations de localisation pour l'instruction *précédente*, pas pour l'instruction actuelle.
// Idéalement, nous exposerions également sur `Frame` si nous sommes effectivement l'adresse de l'instruction suivante ou du courant.
//
// Pour l'instant, il s'agit d'une préoccupation de niche, donc nous en soustrayons toujours une en interne.
// Les consommateurs devraient continuer à travailler et obtenir de très bons résultats, nous devrions donc être assez bons.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Identique à `resolve`, mais non sécurisé car non synchronisé.
///
/// Cette fonction n'a pas de garanties de synchronisation mais est disponible lorsque la fonctionnalité `std` de ce crate n'est pas compilée dans.
/// Voir la fonction `resolve` pour plus de documentation et d'exemples.
///
/// # Panics
///
/// Voir les informations sur `resolve` pour les mises en garde sur la panique `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Identique à `resolve_frame`, mais non sécurisé car non synchronisé.
///
/// Cette fonction n'a pas de garanties de synchronisation mais est disponible lorsque la fonctionnalité `std` de ce crate n'est pas compilée dans.
/// Voir la fonction `resolve_frame` pour plus de documentation et d'exemples.
///
/// # Panics
///
/// Voir les informations sur `resolve_frame` pour les mises en garde sur la panique `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// Un trait représentant la résolution d'un symbole dans un fichier.
///
/// Ce trait est cédé en tant qu'objet trait à la fermeture donnée à la fonction `backtrace::resolve`, et il est virtuellement distribué car on ne sait pas quelle implémentation est derrière.
///
///
/// Un symbole peut donner des informations contextuelles sur une fonction, par exemple le nom, le nom de fichier, le numéro de ligne, l'adresse précise, etc.
/// Cependant, toutes les informations ne sont pas toujours disponibles dans un symbole, donc toutes les méthodes renvoient un `Option`.
///
///
pub struct Symbol {
    // TODO: cette limite de durée de vie doit être persistée à `Symbol`,
    // mais c'est actuellement un changement radical.
    // Pour l'instant, c'est sûr puisque `Symbol` n'est distribué que par référence et ne peut pas être cloné.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Renvoie le nom de cette fonction.
    ///
    /// La structure retournée peut être utilisée pour interroger diverses propriétés sur le nom du symbole:
    ///
    ///
    /// * L'implémentation `Display` imprimera le symbole démêlé.
    /// * La valeur brute `str` du symbole est accessible (si elle est utf-8 valide).
    /// * Les octets bruts du nom du symbole sont accessibles.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Renvoie l'adresse de départ de cette fonction.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Renvoie le nom de fichier brut sous forme de tranche.
    /// Ceci est principalement utile pour les environnements `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Renvoie le numéro de colonne pour lequel ce symbole est en cours d'exécution.
    ///
    /// Seul gimli fournit actuellement une valeur ici et même alors seulement si `filename` renvoie `Some`, et donc il est alors soumis à des mises en garde similaires.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Renvoie le numéro de ligne où ce symbole est en cours d'exécution.
    ///
    /// Cette valeur de retour est généralement `Some` si `filename` renvoie `Some` et est par conséquent soumise à des mises en garde similaires.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Renvoie le nom du fichier dans lequel cette fonction a été définie.
    ///
    /// Ceci n'est actuellement disponible que lorsque libbacktrace ou gimli est utilisé (par exemple
    /// unix plates-formes autres) et lorsqu'un binaire est compilé avec debuginfo.
    /// Si aucune de ces conditions n'est remplie, cela renverra probablement `None`.
    ///
    /// # Fonctionnalités requises
    ///
    /// Cette fonction nécessite l'activation de la fonction `std` du `backtrace` crate et la fonction `std` est activée par défaut.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Peut-être un symbole C++ analysé, si l'analyse du symbole mutilé en tant que Rust a échoué.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Assurez-vous de conserver cette taille zéro, afin que la fonction `cpp_demangle` n'ait aucun coût lorsqu'elle est désactivée.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Un wrapper autour d'un nom de symbole pour fournir des accesseurs ergonomiques au nom démêlé, aux octets bruts, à la chaîne brute, etc.
///
// Autoriser le code mort lorsque la fonction `cpp_demangle` n'est pas activée.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Crée un nouveau nom de symbole à partir des octets bruts sous-jacents.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Renvoie le nom du symbole (mangled) brut sous la forme d'un `str` si le symbole est utf-8 valide.
    ///
    /// Utilisez l'implémentation `Display` si vous voulez la version démêlée.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Renvoie le nom du symbole brut sous forme de liste d'octets
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Cela peut s'imprimer si le symbole démêlé n'est pas réellement valide, donc gérez l'erreur ici avec élégance en ne la propageant pas vers l'extérieur.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Tentative de récupération de la mémoire mise en cache utilisée pour symboliser les adresses.
///
/// Cette méthode tentera de libérer toutes les structures de données globales qui ont autrement été mises en cache globalement ou dans le thread qui représentent généralement des informations DWARF analysées ou similaires.
///
///
/// # Caveats
///
/// Bien que cette fonction soit toujours disponible, elle ne fait rien sur la plupart des implémentations.
/// Les bibliothèques comme dbghelp ou libbacktrace ne fournissent pas de fonctionnalités pour désallouer l'état et gérer la mémoire allouée.
/// Pour l'instant, la fonctionnalité `gimli-symbolize` de ce crate est la seule fonctionnalité où cette fonction a un effet.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}