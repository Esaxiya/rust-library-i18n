// utilisé uniquement sur Linux pour le moment, alors autorisez le code mort ailleurs
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Un simple allocateur d'arène pour les tampons d'octets.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Alloue un tampon de la taille spécifiée et lui renvoie une référence mutable.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SÉCURITÉ: c'est la seule fonction qui construit jamais un mutable
        // référence à `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // SÉCURITÉ: nous ne supprimons jamais d'éléments de `self.buffers`, donc une référence
        // aux données à l'intérieur de n'importe quel tampon vivra aussi longtemps que `self`.
        &mut buffers[i]
    }
}