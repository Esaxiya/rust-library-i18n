use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr prend un rappel qui recevra un pointeur dl_phdr_info pour chaque DSO qui a été lié dans le processus.
    // dl_iterate_phdr garantit également que l'éditeur de liens dynamique est verrouillé du début à la fin de l'itération.
    // Si le rappel renvoie une valeur différente de zéro, l'itération se termine prématurément.
    // 'data' sera passé comme troisième argument du rappel à chaque appel.
    // 'size' donne la taille de dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Nous devons analyser l'ID de construction et certaines données d'en-tête de programme de base, ce qui signifie que nous avons également besoin d'un peu de choses de la spécification ELF.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Nous devons maintenant répliquer, bit pour bit, la structure du type dl_phdr_info utilisé par l'éditeur de liens dynamique actuel de fuchsia.
// Chromium a également cette limite ABI ainsi qu'un crashpad.
// Eventully nous aimerions déplacer ces cas pour utiliser elf-search mais nous aurions besoin de fournir cela dans le SDK et cela n'a pas encore été fait.
//
// Ainsi, nous (et eux) sommes obligés d'utiliser cette méthode qui entraîne un couplage étroit avec la libc fuchsia.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Nous n'avons aucun moyen de savoir si e_phoff et e_phnum sont valides.
    // Cependant, la libc devrait garantir cela pour nous, il est donc sûr de former une tranche ici.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr représente un en-tête de programme ELF 64 bits dans l'endianness de l'architecture cible.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr représente un en-tête de programme ELF valide et son contenu.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Nous n'avons aucun moyen de vérifier si p_addr ou p_memsz sont valides.
    // La libc de Fuchsia analyse les notes en premier, cependant, en vertu de leur présence ici, ces en-têtes doivent être valides.
    //
    // NoteIter n'exige pas que les données sous-jacentes soient valides, mais il exige que les limites soient valides.
    // Nous sommes convaincus que la libc a veillé à ce que ce soit le cas pour nous ici.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Le type de note pour les ID de build.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr représente un en-tête de note ELF dans l'endianité de la cible.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// La note représente une note ELF (en-tête + contenu).
// Le nom est laissé sous forme de tranche u8 car il n'est pas toujours terminé par null et rust permet de vérifier assez facilement que les octets correspondent dans les deux cas.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter vous permet d'itérer en toute sécurité sur un segment de note.
// Il se termine dès qu'une erreur survient ou qu'il n'y a plus de notes.
// Si vous parcourez des données invalides, cela fonctionnera comme si aucune note n'avait été trouvée.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // C'est un invariant de fonction que le pointeur et la taille donnés dénotent une plage valide d'octets qui peuvent tous être lus.
    // Le contenu de ces octets peut être n'importe quoi, mais la plage doit être valide pour que cela soit sûr.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to aligne 'x' sur l'alignement 'to' byte en supposant que 'to' est une puissance de 2.
// Cela suit un modèle standard dans le code d'analyse ELF C/C ++ où (x + to, 1)&-to est utilisé.
// Rust ne vous laisse pas nier l'utilisation donc j'utilise
// Conversion du complément 2 pour recréer cela.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 consomme nombre d'octets de la tranche (si elle est présente) et s'assure en outre que la tranche finale est correctement alignée.
// Si le nombre d'octets demandé est trop grand ou si la tranche ne peut pas être réalignée par la suite en raison d'un nombre insuffisant d'octets restants, None est renvoyé et la tranche n'est pas modifiée.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Cette fonction n'a pas de réels invariants que l'appelant doit respecter, à part peut-être que 'bytes' doit être aligné pour les performances (et sur certaines architectures correctes).
// Les valeurs dans les champs Elf_Nhdr peuvent être absurdes mais cette fonction ne garantit rien de tel.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Ceci est sûr tant qu'il y a suffisamment d'espace et nous venons de confirmer que dans l'instruction if ci-dessus, cela ne devrait pas être dangereux.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Notez que sice_of: :<Elf_Nhdr>() est toujours aligné sur 4 octets.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Vérifiez si nous avons atteint la fin.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Nous transmutons un nhdr mais nous considérons attentivement la structure résultante.
        // Nous ne faisons pas confiance aux namesz ou aux descsz et nous ne prenons aucune décision dangereuse en fonction du type.
        //
        // Donc, même si nous sortons des poubelles complètes, nous devrions toujours être en sécurité.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Indique qu'un segment est exécutable.
const PERM_X: u32 = 0b00000001;
/// Indique qu'un segment est accessible en écriture.
const PERM_W: u32 = 0b00000010;
/// Indique qu'un segment est lisible.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Représente un segment ELF au moment de l'exécution.
struct Segment {
    /// Donne l'adresse virtuelle d'exécution du contenu de ce segment.
    addr: usize,
    /// Donne la taille de la mémoire du contenu de ce segment.
    size: usize,
    /// Donne l'adresse virtuelle du module de ce segment avec le fichier ELF.
    mod_rel_addr: usize,
    /// Donne les autorisations trouvées dans le fichier ELF.
    /// Cependant, ces autorisations ne sont pas nécessairement les autorisations présentes au moment de l'exécution.
    flags: Perm,
}

/// Permet une itération sur les segments à partir d'un DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Représente un DSO ELF (objet partagé dynamique).
/// Ce type fait référence aux données stockées dans le DSO réel plutôt que de faire sa propre copie.
struct Dso<'a> {
    /// L'éditeur de liens dynamique nous donne toujours un nom, même si le nom est vide.
    /// Dans le cas de l'exécutable principal, ce nom sera vide.
    /// Dans le cas d'un objet partagé ce sera le soname (voir DT_SONAME).
    name: &'a str,
    /// Sur Fuchsia, pratiquement tous les binaires ont des ID de compilation, mais ce n'est pas une exigence stricte.
    /// Il n'y a aucun moyen de faire correspondre les informations DSO avec un vrai fichier ELF par la suite s'il n'y a pas de build_id donc nous exigeons que chaque DSO en ait un ici.
    ///
    /// Les DSO sans build_id sont ignorés.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Renvoie un itérateur sur les segments dans ce DSO.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Ces erreurs codent les problèmes qui surviennent lors de l'analyse des informations sur chaque DSO.
///
enum Error {
    /// NameError signifie qu'une erreur s'est produite lors de la conversion d'une chaîne de style C en une chaîne rust.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError signifie que nous n'avons pas trouvé d'ID de build.
    /// Cela peut être dû au fait que le DSO n'a pas d'ID de build ou au fait que le segment contenant l'ID de build est mal formé.
    ///
    BuildIDError,
}

/// Appelle 'dso' ou 'error' pour chaque DSO lié au processus par l'éditeur de liens dynamique.
///
///
/// # Arguments
///
/// * `visitor` - Un DsoPrinter qui aura l'une des méthodes mange appelées foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr garantit que info.name pointera vers un emplacement valide.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Cette fonction imprime le balisage du symboliseur Fuchsia pour toutes les informations contenues dans un DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}