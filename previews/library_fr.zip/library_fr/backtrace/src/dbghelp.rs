//! Un module pour aider à gérer les liaisons dbghelp sur Windows
//!
//! Les backtraces sur Windows (du moins pour MSVC) sont largement alimentées par `dbghelp.dll` et les différentes fonctions qu'il contient.
//! Ces fonctions sont actuellement chargées *dynamiquement* plutôt que d'être reliées statiquement à `dbghelp.dll`.
//! Ceci est actuellement fait par la bibliothèque standard (et est en théorie requis là-bas), mais c'est un effort pour aider à réduire les dépendances dll statiques d'une bibliothèque puisque les backtraces sont généralement assez facultatives.
//!
//! Cela étant dit, `dbghelp.dll` se charge presque toujours avec succès sur Windows.
//!
//! Notez cependant que puisque nous chargeons tout ce support dynamiquement, nous ne pouvons pas réellement utiliser les définitions brutes dans `winapi`, mais nous devons plutôt définir nous-mêmes les types de pointeurs de fonction et les utiliser.
//! Nous ne voulons pas vraiment dupliquer winapi, nous avons donc une fonction Cargo `verify-winapi` qui affirme que toutes les liaisons correspondent à celles de winapi et que cette fonctionnalité est activée sur CI.
//!
//! Enfin, vous noterez ici que la dll pour `dbghelp.dll` n'est jamais déchargée, et c'est actuellement intentionnel.
//! L'idée est que nous pouvons globalement le mettre en cache et l'utiliser entre les appels à l'API, en évitant le loads/unloads coûteux.
//! Si c'est un problème pour les détecteurs de fuites ou quelque chose du genre, nous pouvons traverser le pont quand nous y arriverons.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Contournez `SymGetOptions` et `SymSetOptions` qui ne sont pas présents dans winapi lui-même.
// Sinon, cela n'est utilisé que lorsque nous vérifions les types contre winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Pas encore défini dans winapi
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Ceci est défini dans winapi, mais c'est incorrect (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Pas encore défini dans winapi
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Cette macro est utilisée pour définir une structure `Dbghelp` qui contient en interne tous les pointeurs de fonction que nous pourrions charger.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// La DLL chargée pour `dbghelp.dll`
            dll: HMODULE,

            // Chaque pointeur de fonction pour chaque fonction que nous pourrions utiliser
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Au départ, nous n'avons pas chargé la DLL
            dll: 0 as *mut _,
            // Au départ, toutes les fonctions sont mises à zéro pour indiquer qu'elles doivent être chargées dynamiquement.
            //
            $($name: 0,)*
        };

        // Typedef de commodité pour chaque type de fonction.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Tente d'ouvrir `dbghelp.dll`.
            /// Renvoie le succès si cela fonctionne ou une erreur si `LoadLibraryW` échoue.
            ///
            /// Panics si la bibliothèque est déjà chargée.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Fonction pour chaque méthode que nous aimerions utiliser.
            // Lorsqu'il est appelé, il lit le pointeur de fonction mis en cache ou le charge et renvoie la valeur chargée.
            // Les charges sont affirmées pour réussir.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Proxy pratique pour utiliser les verrous de nettoyage pour référencer les fonctions dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Initialisez tout le support nécessaire pour accéder aux fonctions de l'API `dbghelp` à partir de ce crate.
///
///
/// Notez que cette fonction est **sûre**, elle a sa propre synchronisation en interne.
/// Notez également qu'il est prudent d'appeler cette fonction plusieurs fois de manière récursive.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // La première chose à faire est de synchroniser cette fonction.Cela peut être appelé simultanément à partir d'autres threads ou de manière récursive dans un thread.
        // Notez que c'est plus compliqué que cela car ce que nous utilisons ici, `dbghelp`,*également* doit être synchronisé avec tous les autres appelants de `dbghelp` dans ce processus.
        //
        // En règle générale, il n'y a pas vraiment beaucoup d'appels à `dbghelp` dans le même processus et nous pouvons probablement supposer en toute sécurité que nous sommes les seuls à y accéder.
        // Il y a, cependant, un autre utilisateur principal dont nous devons nous soucier, qui est ironiquement nous-mêmes, mais dans la bibliothèque standard.
        // La bibliothèque standard Rust dépend de ce crate pour la prise en charge du backtrace, et ce crate existe également sur crates.io.
        // Cela signifie que si la bibliothèque standard imprime une trace arrière panic, elle peut courir avec ce crate provenant de crates.io, provoquant des erreurs de segmentation.
        //
        // Pour aider à résoudre ce problème de synchronisation, nous utilisons ici une astuce spécifique à Windows (il s'agit, après tout, d'une restriction spécifique à Windows concernant la synchronisation).
        // Nous créons un mutex nommé *session-local* pour protéger cet appel.
        // L'intention ici est que la bibliothèque standard et ce crate ne doivent pas partager des API de niveau Rust pour se synchroniser ici, mais peuvent à la place travailler en arrière-plan pour s'assurer qu'ils se synchronisent les uns avec les autres.
        //
        // De cette façon, lorsque cette fonction est appelée via la bibliothèque standard ou via crates.io, nous pouvons être sûrs que le même mutex est en cours d'acquisition.
        //
        // Donc, tout cela pour dire que la première chose que nous faisons ici est de créer atomiquement un `HANDLE` qui est un mutex nommé sur Windows.
        // Nous synchronisons un peu avec d'autres threads partageant cette fonction spécifiquement et nous nous assurons qu'un seul handle est créé par instance de cette fonction.
        // Notez que le handle n'est jamais fermé une fois qu'il est stocké dans le global.
        //
        // Une fois que nous aurons fini la serrure, nous l'acquérons simplement et notre poignée `Init` que nous distribuons sera responsable de la laisser tomber éventuellement.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, ouf!Maintenant que nous sommes tous synchronisés en toute sécurité, commençons à tout traiter.
        // Tout d'abord, nous devons nous assurer que `dbghelp.dll` est réellement chargé dans ce processus.
        // Nous faisons cela dynamiquement pour éviter une dépendance statique.
        // Cela a toujours été fait pour contourner des problèmes de liaison étranges et vise à rendre les binaires un peu plus portables car il ne s'agit en grande partie que d'un utilitaire de débogage.
        //
        //
        // Une fois que nous avons ouvert `dbghelp.dll`, nous devons y appeler certaines fonctions d'initialisation, et c'est détaillé ci-dessous.
        // Cependant, nous ne le faisons qu'une seule fois, donc nous avons un booléen global indiquant si nous avons déjà terminé ou pas.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Assurez-vous que l'indicateur `SYMOPT_DEFERRED_LOADS` est défini, car selon la documentation de MSVC à ce sujet: "This is the fastest, most efficient way to use the symbol handler.", faisons-le!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // En fait, initialisez les symboles avec MSVC.Notez que cela peut échouer, mais nous l'ignorons.
        // Il n'y a pas une tonne d'art antérieur pour cela en soi, mais LLVM en interne semble ignorer la valeur de retour ici et l'une des bibliothèques de désinfection de LLVM imprime un avertissement effrayant si cela échoue mais l'ignore fondamentalement à long terme.
        //
        //
        // Un cas où cela revient souvent pour Rust est que la bibliothèque standard et ce crate sur crates.io veulent tous deux rivaliser pour `SymInitializeW`.
        // La bibliothèque standard voulait historiquement initialiser puis nettoyer la plupart du temps, mais maintenant qu'elle utilise ce crate, cela signifie que quelqu'un va commencer l'initialisation et que l'autre reprendra cette initialisation.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}