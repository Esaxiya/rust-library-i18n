mod auxiliary;

macro_rules! pos {
    () => {
        (file!(), line!())
    };
}

macro_rules! check {
    ($($pos:expr),*) => ({
        verify(&[$($pos,)* pos!()]);
    })
}

type Pos = (&'static str, u32);

#[test]
fn doit() {
    if
    // Ignorer musl qui est par défaut lié statiquement et ne prend pas en charge les bibliothèques dynamiques.
    //
    !cfg!(target_env = "musl")
    // Ignorez MinGW sur libbacktrace qui ne prend pas en charge les DLL.
    && !(cfg!(windows) && cfg!(target_env = "gnu") && cfg!(feature = "libbacktrace"))
    // Ignorez Miri, car il ne prend pas en charge les bibliothèques dynamiques.
    && !cfg!(miri)
    {
        // TODO(#238) cela ne devrait pas avoir à se produire en premier dans cette fonction, mais c'est le cas actuellement.
        //
        let mut dir = std::env::current_exe().unwrap();
        dir.pop();
        if cfg!(windows) {
            dir.push("dylib_dep.dll");
        } else if cfg!(target_os = "macos") {
            dir.push("libdylib_dep.dylib");
        } else {
            dir.push("libdylib_dep.so");
        }
        let lib = libloading::Library::new(&dir).unwrap();
        let api = unsafe { lib.get::<extern "C" fn(Pos, fn(Pos, Pos))>(b"foo").unwrap() };
        api(pos!(), |a, b| {
            check!(a, b);
        });
    }

    outer(pos!());
}

#[inline(never)]
fn outer(main_pos: Pos) {
    inner(main_pos, pos!());
    inner_inlined(main_pos, pos!());
}

#[inline(never)]
#[rustfmt::skip]
fn inner(main_pos: Pos, outer_pos: Pos) {
    check!(main_pos, outer_pos);
    check!(main_pos, outer_pos);
    let inner_pos = pos!(); auxiliary::callback(|aux_pos| {
        check!(main_pos, outer_pos, inner_pos, aux_pos);
    });
    let inner_pos = pos!(); auxiliary::callback_inlined(|aux_pos| {
        check!(main_pos, outer_pos, inner_pos, aux_pos);
    });
}

#[inline(always)]
#[rustfmt::skip]
fn inner_inlined(main_pos: Pos, outer_pos: Pos) {
    check!(main_pos, outer_pos);
    check!(main_pos, outer_pos);

    #[inline(always)]
    fn inner_further_inlined(main_pos: Pos, outer_pos: Pos, inner_pos: Pos) {
        check!(main_pos, outer_pos, inner_pos);
    }
    inner_further_inlined(main_pos, outer_pos, pos!());

    let inner_pos = pos!(); auxiliary::callback(|aux_pos| {
        check!(main_pos, outer_pos, inner_pos, aux_pos);
    });
    let inner_pos = pos!(); auxiliary::callback_inlined(|aux_pos| {
        check!(main_pos, outer_pos, inner_pos, aux_pos);
    });

    // ceci teste une distinction entre deux appels indépendants à la fonction en ligne.
    // (un) heureusement, LLVM fusionne en quelque sorte deux appels de ce type consécutifs en un seul nœud.
    inner_further_inlined(main_pos, outer_pos, pos!());
}

fn verify(filelines: &[Pos]) {
    let trace = backtrace::Backtrace::new();
    println!("-----------------------------------");
    println!("looking for:");
    for (file, line) in filelines.iter().rev() {
        println!("\t{}:{}", file, line);
    }
    println!("found:\n{:?}", trace);
    let mut symbols = trace.frames().iter().flat_map(|frame| frame.symbols());
    let mut iter = filelines.iter().rev();
    while let Some((file, line)) = iter.next() {
        loop {
            let sym = match symbols.next() {
                Some(sym) => sym,
                None => panic!("failed to find {}:{}", file, line),
            };
            if let Some(filename) = sym.filename() {
                if let Some(lineno) = sym.lineno() {
                    if filename.ends_with(file) && lineno == *line {
                        break;
                    }
                }
            }
        }
    }
}