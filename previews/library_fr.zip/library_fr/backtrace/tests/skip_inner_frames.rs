use backtrace::Backtrace;

// Ce test ne fonctionne que sur les plates-formes qui ont une fonction `symbol_address` fonctionnelle pour les trames qui rapporte l'adresse de départ d'un symbole.
// En conséquence, il n'est activé que sur quelques plates-formes.
//
const ENABLED: bool = cfg!(all(
    // Windows n'a pas vraiment été testé, et OSX ne prend pas en charge la recherche d'un cadre englobant, alors désactivez cette option
    //
    target_os = "linux",
    // Sur ARM, trouver la fonction englobante renvoie simplement l'adresse IP elle-même.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}