#![feature(no_core)]
#![no_core]

// Kuckt rustc-std-Workspace-Kär firwat dës crate gebraucht gëtt.

// Rename den crate fir ze vermeiden datt et mam Alloc Modul am Liballoc konfliktéiert gëtt.
extern crate alloc as foo;

pub use foo::*;