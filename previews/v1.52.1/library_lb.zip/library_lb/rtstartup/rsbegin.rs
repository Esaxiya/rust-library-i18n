// rsbegin.o an rsend.o sinn déi sougenannt "compiler runtime startup objects".
// Si enthalen Code néideg fir de Compiler Runtime korrekt ze initialiséieren.
//
// Wann en ausführbar oder dylib Bild verlinkt ass, sinn all Benotzercode a Bibliothéiken "sandwiched" tëscht dësen zwee Objektdateien, sou datt Code oder Daten aus rsbegin.o als éischt an de jeweilegen Abschnitter vum Bild ginn, wärend Code an Daten aus rsend.o déi lescht ginn.
// Dësen Effekt kann benotzt ginn fir Symboler am Ufank oder um Enn vun enger Sektioun ze placéieren, souwéi fir all erfuerderlech Header oder Fousszeilen anzesetzen.
//
// Bedenkt datt den aktuellen Modul Entrée Punkt am C Runtime Start Objet ass (normalerweis `crtX.o` genannt), déi dann Initialiséierungs Réckruff vun anere Runtime Komponenten opruffen (registréiert iwwer nach eng aner speziell Bild Sektioun).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Marks Ufank vum Stack Frame entspaant Info Sektioun
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Kratz Plaz fir d'intern Bicherhale vun der Unwinder.
    // Dëst ass definéiert als `struct object` an $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Entdeckt Info registration/deregistration Routinen.
    // Kuckt d'Dokumenter vu libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // registréiert entspaant Info beim Start vum Modul
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // ofmellen beim Ofschalten
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-spezifesch init/uninit Routine Aschreiwung
    pub mod mingw_init {
        // D'Start Objete vum MinGW (crt0.o/dllcrt0.o) ruffe global Konstrukteuren an den .ctors an .dtors Sektiounen beim Start an Ausféieren op.
        // Am Fall vun DLLs gëtt dëst gemaach wann d'DLL gelueden an erofgelueden ass.
        //
        // De Linker wäert d'Sektiounen sortéieren, wat garantéiert datt eis Callbacks um Enn vun der Lëscht sinn.
        // Well Konstruktoren an ëmgedréinter Reiefolleg gefouert ginn, garantéiert dat datt eis Callbacks déi éischt a lescht ausgefouert ginn.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C Initialiséierungs Réckruff
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C Ofbriechen Callbacks
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}