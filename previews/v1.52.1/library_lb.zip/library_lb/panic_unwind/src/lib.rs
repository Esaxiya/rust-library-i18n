//! Ëmsetzung vun panics iwwer Stack ofzeschalten
//!
//! Dësen crate ass eng Implementatioun vun panics am Rust mam "most native" Stack Entwécklungsmechanismus vun der Plattform fir déi et kompiléiert gëtt.
//! Dëst gëtt am Moment an dräi Eemer kategoriséiert:
//!
//! 1. MSVC Ziler benotze SEH an der `seh.rs` Datei.
//! 2. Emscripten benotzt C++ Ausnamen an der `emcc.rs` Datei.
//! 3. All aner Ziler benotzen libunwind/libgcc an der `gcc.rs` Datei.
//!
//! Méi Dokumentatioun iwwer all Implementatioun fannt Dir am jeeweilege Modul.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` ass net benotzt mam Miri, also roueg Warnungen.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Rust Runtime Startup Objeten hänken vun dëse Symboler of, also maacht se ëffentlech.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Ziler déi net z'entschaffen ënnerstëtzen.
        // - arch=wasm32
        // - os=keen ("bare metal" Ziler)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Benotzt d'Miri Runtime.
        // Mir mussen nach déi normal Runtime uewen eroplueden, well rustc erwaart datt bestëmmte Lang Elementer vun do definéiert ginn.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Benotzt déi richteg Runtime.
        use real_imp as imp;
    }
}

extern "C" {
    /// Handler am libstd geruff wann en panic Objet ausserhalb vun `catch_unwind` fale gelooss gëtt.
    ///
    fn __rust_drop_panic() -> !;

    /// Handler am Libstd geruff wann eng auslännesch Ausnam agefaang ass.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Entrée fir eng Ausnam ze erhéijen, just Delegéiert op déi plattformspezifesch Ëmsetzung.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}