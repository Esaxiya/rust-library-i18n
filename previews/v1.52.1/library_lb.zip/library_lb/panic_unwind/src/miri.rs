//! panics fir Miri ofzebauen.
use alloc::boxed::Box;
use core::any::Any;

// Déi Aart vun der Notzlaascht, déi de Miri-Motor propagéiert andeems se eis entfält.
// Muss Zeigergréisst sinn.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Miri-zur Verfügung gestallt extern Funktioun fir ofzeschalten.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // D'Notzlaascht déi mir op `miri_start_panic` weiderginn ass genau d'Argument dat mir am `cleanup` hei drënner kréien.
    // Also mir boxen et just eemol, fir eppes Zeigefërmeg ze kréien.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Erhuel de Basis `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}