//! Ëmsetzung vun panics ënnerstëtzt vun libgcc/libunwind (a iergendenger Form).
//!
//! Fir Hannergrond iwwer Ausnamebehandlung a Stack Ofwécklung kuckt "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) an Dokumenter dovun verlinkt.
//! Dës sinn och gutt liest:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## E kuerze Resumé
//!
//! Exceptiounsbehandlung geschitt an zwou Phasen: eng Sichphase an eng Botzphase.
//!
//! A béide Phasen trëppelt den Unwinder Stackframes vun uewen no ënnen mat Informatioun aus de Stackframe ofzewéckelen Sektioune vun den aktuelle Prozessmoduler ("module" bezitt sech hei op en OS Modul, also eng ausféierbar oder eng dynamesch Bibliothéik).
//!
//!
//! Fir all Stack Frame rufft se den assoziéierten "personality routine" op, deem seng Adress och an der Ofkéier Info Info gespäichert ass.
//!
//! An der Sichphase ass d'Aufgab vun enger Perséinlechkeet Routine d'Ausnam vun engem Ausnam Objet z'entdecken, deen entscheet gëtt, an ze entscheeden ob et an deem Stack Frame gefaange sollt ginn.Soubal den Handler Frame identifizéiert gouf, fänkt d'Botzphase un.
//!
//! An der Botzphase rifft den Unwinder all Perséinlechkeet Routine erëm un.
//! Dës Kéier entscheet et wéi e (wann iwwerhaapt) Botzcode fir den aktuelle Stackframe muss lafen.Wa jo, gëtt d'Kontroll op e speziellen branch am Funktiounskierper transferéiert, den "landing pad", deen Destruktoren oprufft, Erënnerung befreit asw.
//! Um Enn vum Landungspad gëtt d'Kontroll zréck an d'Ofwécklung transferéiert an d'Ofwécklung geet weider.
//!
//! Wann de Stack bis op den Handler Frame Niveau ofgewéckelt gouf, stoppt d'Ofklappen an déi lescht Perséinlechkeet Routine iwwerdréit d'Kontroll op de Fangblock.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Rust Ausnam Klass Identifizéierer.
// Dëst gëtt vu Perséinlechkeet Routine benotzt fir ze bestëmmen ob d'Ausnam duerch hir eege Runtime geworf gouf.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-Verkeefer, Sprooch
    0x4d4f5a_00_52555354
}

// Registréiert Ids goufen aus LLVM's TargetLowering::getExceptionPointerRegister() an TargetLowering::getExceptionSelectorRegister() fir all Architektur opgehuewen, duerno op DWARF Registernummeren iwwer Register Definitiounstabellen (typesch)<arch>RegisterInfo.td, Sich no "DwarfRegNum").
//
// Kuckt och http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// De folgende Code baséiert op GCC's C an C++ Perséinlechkeet Routinen.Fir Referenz, kuckt:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM EHABI Perséinlechkeet Routine.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS benotzt d'Standardroutine amplaz well et benotzt SjLj ofzeschalten.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // Backtraces op ARM nennen d'Perséinlechkeet Routine mam Staat==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // An deene Fäll wëlle mir de Stack weider opléisen, soss géifen all eis Réckstrecken op __rust_try ophalen
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // Den DWARF Unwinder geet dovun aus datt_Unwind_Context Saachen hält wéi d'Funktioun an d'LSDA Zeigefanger, awer ARM EHABI setzt se an d'Ausnam Objet.
            // Fir d'Ënnerschrëfte vu Funktiounen wéi _Unwind_GetLanguageSpecificData() ze erhaalen, déi nëmmen de Kontextzeiger huelen, stashen d'GCC Perséinlechkeet Routinen e Zeiger op exception_object am Kontext, mat der Location reservéiert fir den ARM "scratch register" (r12).
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... Eng méi prinzipiell Approche wier déi voll Definitioun vum ARM's_Unwind_Context an eise libunwind Bindungen unzebidden an déi néideg Donnéeë vun do direkt ze kréien, andeems Dir DWARF Kompatibilitéitsfunktiounen ëmgitt.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI erfuerdert d'Perséinlechkeet Routine fir de SP-Wäert am Barriere-Cache vum Ausnam-Objet ze aktualiséieren.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // Op ARM EHABI ass d'Perséinlechkeet Routine verantwortlech fir tatsächlech en eenzege Stack Frame ofzewéckelen ier se zréckgeet (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // definéiert an libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // Standard Perséinlechkeet Routine, déi direkt op déi meescht Ziler benotzt gëtt an indirekt op Windows x86_64 iwwer SEH.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // Op x86_64 MinGW Ziler ass den Entwecklungsmechanismus SEH awer déi entschëllegen Handler Daten (alias LSDA) benotzen GCC-kompatibel Kodéierung.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // D'Perséinlechkeet Routine fir déi meescht vun eisen Ziler.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // D'Retouradress weist 1 Byte laanscht d'Opruffinstruktioun, déi an der nächster IP Band an der LSDA Range Tabelle kéint sinn.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// Frame entspaant Info Umeldung
//
// All Bild vum Modul enthält e Frame ofzeschalten Info Sektioun (normalerweis ".eh_frame").Wann e Modul loaded/unloaded am Prozess ass, muss den Unwinder iwwer de Standort vun dëser Sektioun am Gedächtnis informéiert ginn.D'Methoden fir ze erreechen déi variéiere vun der Plattform.
// Op e puer (z. B. Linux) kann den Unwinder eleng Entdeckungsinformatiounssektiounen entdecken (andeems en aktuell gelueden Moduler iwwer den dl_iterate_phdr() API and finding their ".eh_frame" sections) dynamesch zielt; Anerer, wéi Windows, erfuerderen Moduler fir aktiv hir Entspanung Info Sektiounen iwwer Unwinder API anzeschreiwen.
//
//
// Dëst Modul definéiert zwee Symboler déi referenzéiert sinn a vun rsbegin.rs geruff ginn fir eis Informatioun mat der GCC Runtime ze registréieren.
// D'Ëmsetzung vu Stack Entwécklung gëtt (fir de Moment) op libgcc_eh ofgesot, awer Rust crates benotzen dës Rust-spezifesch Entréeë fir potenziell Ausstéiss mat all GCC Runtime ze vermeiden.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}