//! Windows SEH
//!
//! Op Windows (aktuell nëmmen op MSVC) ass de Standard Ausnamen Handling Mechanismus Structured Exception Handling (SEH).
//! Dëst ass ganz anescht wéi Zwergbaséiert Ausnam Handling (z. B. wat aner unix Plattformen benotzen) a Bezuch op Compiler Interner, sou datt LLVM verlaangt ass eng gutt Offer extra Ënnerstëtzung fir SEH ze hunn.
//!
//! An enger Nossschuel, wat hei geschitt ass:
//!
//! 1. D `panic` Funktioun nennt d'Standard Windows Funktioun `_CxxThrowException` fir e C++ ze werfen-ähnlech Ausnam, ausléist den Entwécklungsprozess.
//! 2.
//! All Landungspads generéiert vum Compiler benotzen d'Perséinlechkeetfunktioun `__CxxFrameHandler3`, eng Funktioun am CRT, an den Entwécklungscode am Windows benotzt dës Perséinlechkeetfunktioun fir all Botzcode um Stack auszeféieren.
//!
//! 3. All Compiler generéiert Uriff op `invoke` hunn e Landungspad gesat als `cleanuppad` LLVM Instruktioun, wat de Start vun der Botzroutine uginn.
//! D'Perséinlechkeet (am Schrëtt 2, definéiert am CRT) ass verantwortlech fir d'Botzroutinen ze bedreiwen.
//! 4. Eventuell gëtt den "catch" Code am `try` intrinsesche (generéiert vum Compiler) ausgefouert a weist datt d'Kontroll op Rust zréck sollt kommen.
//! Dëst gëtt iwwer en `catchswitch` plus eng `catchpad` Instruktioun a LLVM IR Begrëffer gemaach, a schliisslech normal Kontroll zréck an de Programm mat enger `catchret` Instruktioun.
//!
//! E puer spezifesch Ënnerscheeder vum gcc-baséiert Ausnamebehandlung sinn:
//!
//! * Rust huet keng personaliséiert Perséinlechkeetsfunktioun, et ass amplaz *ëmmer*`__CxxFrameHandler3`.Zousätzlech gëtt keen extra Filter gemaach, also fänke mir eventuell C++ Ausnamen op, déi sou ausgesinn, wéi déi Aart, déi mir werfen.
//! Bedenkt datt eng Ausnahm an Rust geheit ass souwisou ondefinéiert Behuelen, also sollt dat gutt sinn.
//! * Mir hunn e puer Daten fir iwwer d'Ofwécklungsgrenz ze vermëttelen, speziell e `Box<dyn Any + Send>`.Wéi mat Zwergen Ausnahmen ginn dës zwee Zeigefanger als Notzlaascht an der Ausnam selwer gespäichert.
//! Op MSVC ass et awer net néideg fir eng extra Koup Bewëllegung ze kréien well de Ruffstack erhale bleift wann d'Filterfunktiounen ausgefouert ginn.
//! Dëst bedeit datt d'Uweiser direkt op `_CxxThrowException` weiderginn, déi dann an der Filterfunktioun erëmfonnt ginn fir an de Stackframe vum `try` intrinsesch ze schreiwen.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Dëst muss eng Optioun sinn well mir d'Ausnam duerch Referenz fänken a säin Destructor duerch d'C ++ Runtime ausgefouert gëtt.
    // Wa mir d'Box aus der Ausnahm eraushuelen, musse mir d'Ausnam an engem gültege Staat hannerloossen fir datt säin Destructor leeft ouni d'Box duebel erofzesetzen.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Als éischt, eng ganz Rëtsch vun Typdefinitiounen.Et ginn e puer plattformspezifesch Odditéiten hei, a vill dat just blatant vu LLVM kopéiert gëtt.Den Zweck vun all deem ass d `panic` Funktioun hei ënnen duerch en Uruff op `_CxxThrowException` ëmzesetzen.
//
// Dës Funktioun hëlt zwee Argumenter.Déi éischt ass e Zeigefanger op d'Donnéeën déi mir weiderginn, wat an dësem Fall eisen trait Objet ass.Zimlech einfach ze fannen!Déi nächst ass awer méi komplizéiert.
// Dëst ass e Zeiger zu enger `_ThrowInfo` Struktur, an et ass normalerweis just geduecht fir just d'Ausnam ze beschreiwen déi geworf gëtt.
//
// Momentan ass d'Definitioun vun dësem Typ [1] e bësse haareg, an d'Haapt oddity (an Ënnerscheed vum Online Artikel) ass datt op 32-Bit d'Pinzéier sinn Zeigefanger awer op 64-Bit d'Punkte ginn als 32-Bit Offset aus der `__ImageBase` Symbol.
//
// Den `ptr_t` an den `ptr!` Makro an de Module hei ënnendrënner gi benotzt fir dëst auszedrécken.
//
// De Labyrinth vun Typdefinitiounen verfollegt och enk wat LLVM fir dës Zort Operatioun emittéiert.Zum Beispill, wann Dir dësen C++ Code op MSVC kompiléiert an den LLVM IR emittéiert:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      ongëlteg foo() { rust_panic a = {0, 1};
//          werfen a;}
//
// Dat ass am Fong wat mir probéieren nozemaachen.Déi meescht vun de konstante Wäerter hei ënnendrënner goufe just vun LLVM kopéiert,
//
// Op jiddfer Fall sinn dës Strukturen all op eng ähnlech Manéier gebaut, an et ass just e bësse verboss fir eis.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Bedenkt datt mir absichtlech d'Nimm-Mangleregelen hei ignoréieren: mir wëllen net datt C++ fäeg ass Rust panics ze fänken andeems en einfach en `struct rust_panic` deklaréiert.
//
//
// Wann Dir ännert, gitt sécher datt d'Typennimm String exakt mat deem an `compiler/rustc_codegen_llvm/src/intrinsic.rs` passt.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // De féierende `\x01` Byte hei ass tatsächlech e magescht Signal fir LLVM fir *keng* aner Mangelen anzesetzen wéi e Präfix mat engem `_` Charakter.
    //
    //
    // Dëst Symbol ass d'Vtabell déi vum C++ `std::type_info` benotzt gëtt.
    // Objete vum Typ `std::type_info`, Typ Descriptoren, hunn e Zeigefanger op dës Tabell.
    // Typ Descripteure gi referenzéiert vun den C++ EH Strukturen hei uewen definéiert an déi mir hei bauen.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Dësen Typ Descriptor gëtt nëmme benotzt wann Dir eng Ausnam werft.
// De Fang Deel gëtt behandelt vum intrinsesche Versuch, deen en eegenen TypeDescriptor generéiert.
//
// Dëst ass gutt, well d'MSVC Runtime benotzt Stringverglach am Typ Numm fir mat TypeDescriptoren ze passen anstatt d'Gewiicht vun der Zeiger.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destructor benotzt wann den C++ Code decidéiert d'Ausnam ze fänken an ze falen ouni se ze propagéieren.
// De Fang Deel vum Versuch intrinsesch wäert dat éischt Wuert vum Ausnam Objet op 0 setzen sou datt et vum Destructor iwwersprongen ass.
//
// Bedenkt datt x86 Windows d "thiscall" Vocatioun Konventioun fir C++ Member Funktiounen amplaz vun der Standard "C" Vocatioun Konventioun benotzt.
//
// D'Exception_copy Funktioun ass e bësse speziell hei: et gëtt vun der MSVC Runtime ënner engem try/catch Block opgeruff an den panic dee mir hei generéieren gëtt als Resultat vun der Ausnahmekopie benotzt.
//
// Dëst gëtt vun der C++ Runtime benotzt fir Ausnamen mat std::exception_ptr z'ënnerstëtzen, déi mir net kënnen ënnerstëtzen well Box<dyn Any>ass net klonabel.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException féiert ganz op dësem Stack Frame aus, also ass et net néideg de `data` anescht op de Koup ze transferéieren.
    // Mir weiderginn just e Stackzeiger zu dëser Funktioun.
    //
    // De ManuallyDrop ass hei gebraucht well mir net wëllen datt d'Ausnahm fällt wann Dir ofbaut.
    // Amplaz datt se duerch exception_cleanup fale gelooss gëtt, déi vun der C++ Runtime opgeruff gëtt.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Dëst ... ka vläicht iwwerraschend, a gerechtfäerdeg esou.Op 32-Bit MSVC sinn d'Indikatiounen tëscht dëser Struktur just dat, Uweiser.
    // Op 64-Bit MSVC sinn awer d'Indikatiounen tëscht Strukturen éischter als 32-Bit Offset vun `__ImageBase` ausgedréckt.
    //
    // Dofir kënne mir op 32-Bit MSVC all dës Zeigefanger an de "statesche" uewe erklären.
    // Op 64-Bit MSVC musse mir Subtraktioun vun Zeigefanger a Statik ausdrécken, déi Rust de Moment net erlaabt, also kënne mir dat net wierklech maachen.
    //
    // Déi nächst Bescht Saach, dann ass dës Strukturen an der Runtime auszefëllen (Panik ass souwisou schonn den "slow path").
    // Also hei interpretéiere mir all dës Zeigefelder als 32-Bit ganz Zuelen a späicheren dann de relevante Wäert dran (atomesch, well gläichzäiteg panics ka geschéien).
    //
    // Technesch wäert d'Runtime méiglecherweis eng nonatomesch Liesung vun dëse Felder maachen, awer an der Theorie liesen se ni de *falsche* Wäert also sollt et net ze schlecht sinn ...
    //
    // Op jiddfer Fall musse mir am Fong sou eppes maache bis mir méi Operatiounen a Statik ausdrécken (a mir kënnen et ni fäeg sinn).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Eng NULL Notzlaascht hei bedeit datt mir hei vum Fang (...) vun __rust_try hierkomm sinn.
    // Dëst geschitt wann eng net-Rust auslännesch Ausnam agefaang ass.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Dëst ass vum Compiler gefuerdert ze existéieren (z. B. et ass e Lang Element), awer et gëtt ni wierklech vum Compiler geruff well __C_specific_handler oder_except_handler3 d'Perséinlechkeetfunktioun ass déi ëmmer benotzt gëtt.
//
// Dofir ass dëst just en ofgebrachene Stomp.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}