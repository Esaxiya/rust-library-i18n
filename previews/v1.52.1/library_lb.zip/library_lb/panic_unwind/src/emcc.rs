//! Ausklappen fir *emscripten* Zil.
//!
//! Wou Rust hir üblech Entwécklungsimplementatioun fir Unix Plattformen direkt an d'libunwind APIe rufft, op Emscripten ruffe mir anstatt an d'C ++ Entwécklung APIen.
//! Dëst ass just eng Expeditioun well d'Runtime vun Emscripten dës APIen ëmmer implementéiert an net libunwind implementéiert.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// Dëst entsprécht dem Layout vun std::type_info an C++
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // De féierende `\x01` Byte hei ass tatsächlech e magescht Signal fir LLVM fir *keng* aner Mangelen anzesetzen wéi e Präfix mat engem `_` Charakter.
    //
    //
    // Dëst Symbol ass d'Vtabell déi vum C++ `std::type_info` benotzt gëtt.
    // Objete vum Typ `std::type_info`, Typ Descriptoren, hunn e Zeigefanger op dës Tabell.
    // Typ Descripteure gi referenzéiert vun den C++ EH Strukturen hei uewen definéiert an déi mir hei bauen.
    //
    // Bedenkt datt déi richteg Gréisst méi grouss ass wéi 3 Usize, awer mir brauche just eis Tabelle fir op dat drëtt Element ze weisen.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info fir eng rust_panic Klass
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // Normalerweis benotze mir .as_ptr().add(2) awer dëst funktionnéiert net an engem const Kontext.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // Dëst benotzt bewosst net den normalen Numm Mangling Schema well mir net wëllen datt C++ Rust panics produzéiere kann oder fänken.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // Dëst ass noutwendeg well den C++ Code eis Exekutioun mat std::exception_ptr ka fänken an e puer Mol nei geheien, méiglecherweis och an engem anere Fuedem.
    //
    //
    caught: AtomicBool,

    // Dëst muss eng Optioun sinn, well d'Liewensdauer vum Objet C++ Semantik follegt: wann catch_unwind d'Box aus der Ausnam réckelt, muss et ëmmer nach d'Ausnam Objet an engem gültege Staat hannerloossen, well säin Destructor nach ëmmer vun __cxa_end_catch genannt gëtt.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try gëtt eis tatsächlech en Zeigefanger zu dëser Struktur.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // Zënter cleanup() ass net erlaabt panic ze maachen, ofbrieche mir just amplaz.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}