# Bäidroen zu stdarch

Den `stdarch` crate ass méi wéi bereet Contributiounen ze akzeptéieren!Als éischt wëllt Dir wahrscheinlech de Repository kucken a sécher stellen datt Tester fir Iech passen:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Wou `<your-target-arch>` d'Zil Triple ass wéi vun `rustup` benotzt, zB `x86_x64-unknown-linux-gnu` (ouni virdrun `nightly-` oder ähnlech).
Denkt och drun datt dëst Repository den Nuetskanal vun Rust erfuerdert!
Déi uewe genannten Tester erfuerderen tatsächlech nuets rust fir de Standard op Ärem System ze sinn, fir dat ze benotzen `rustup default nightly` (an `rustup default stable` fir zréckzekommen).

Wann ee vun de genannte Schrëtt net funktionnéiert, [please let us know][new]!

Als nächst kënnt Dir [find an issue][issues] hëllefen, mir hunn e puer mat den [`help wanted`][help] an [`impl-period`][impl] Tags ausgewielt, déi besonnesch hëllefe kéinten. 
Dir kënnt am meeschten interesséiert sinn am [#40][vendor], all Verkeeferintrinsiken op x86 implementéieren.Dës Ausgab huet e puer gutt Uweiser iwwer wou unzefänken!

Wann Dir allgemeng Froen hutt fillt Iech gratis op [join us on gitter][gitter] a frot ronderëm!Fillt sech gratis entweder@BurntSushi oder@alexcrichton mat Froen ze pinge.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Wéi schreiwen ech Beispiller fir stdarch Intrinsiken

Et ginn e puer Features déi aktivéiert musse sinn fir de gegebene intrinsesche fir richteg ze schaffen an d'Beispill muss nëmme vu `cargo test --doc` ausgefouert ginn wann d'Feature vun der CPU ënnerstëtzt gëtt.

Als Resultat funktionnéiert de Standard `fn main` deen duerch `rustdoc` generéiert gëtt (an de meeschte Fäll) net.
Bedenkt d'folgend als Guide ze benotzen fir datt Äert Beispill funktionnéiert wéi erwaart.

```rust
/// # // Mir brauchen cfg_target_feature fir sécher ze sinn datt d'Beispill nëmmen ass
/// # // vun `cargo test --doc` gerannt wann d'CPU d'Feature ënnerstëtzt
/// # #![feature(cfg_target_feature)]
/// # // Mir brauche target_feature fir dat intrinsescht ze schaffen
/// # #![feature(target_feature)]
/// #
/// # // rustdoc als Standard benotzt `extern crate stdarch`, awer mir brauche de
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // Déi richteg Haaptfunktioun
/// # fn main() {
/// #     // Fuert dëst nëmmen wann `<target feature>` ënnerstëtzt gëtt
/// #     wann cfg_feature_enabled! ("<target feature>"){
/// #         // Erstellt eng `worker` Funktioun déi nëmmen ausgefouert gëtt wann d'Zil Feature
/// #         // gëtt ënnerstëtzt a garantéiert datt `target_feature` fir Ären Aarbechter aktivéiert ass
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         onsécher FN worker() {
/// // Schreift Äert Beispill hei.Feature spezifesch Intrinsike funktionnéieren hei!Gitt wëll!
///
/// #         }
///
/// #         onsécher { worker(); }
/// #     }
/// # }
```

Wann e puer vun den uewe genannte Syntaxen net vertraut ausgesinn, beschreift d [Documentation as tests] Sektioun vun der [Rust Book] d `rustdoc` Syntax ganz gutt.
Wéi ëmmer, fillt Iech gär op [join us on gitter][gitter] a frot eis ob Dir iergendeng Schnappschëss getraff hutt, a Merci fir Är Hëllef fir d'Dokumentatioun vun `stdarch` ze verbesseren!

# Alternativ Testinstruktiounen

Et ass allgemeng recommandéiert datt Dir `ci/run.sh` benotzt fir d'Tester ze maachen.
Dëst kann awer net fir Iech funktionnéieren, zB wann Dir op Windows sidd.

An deem Fall kënnt Dir zréck féieren `cargo +nightly test` an `cargo +nightly test --release -p core_arch` ze lafen fir d'Codegeneratioun ze testen.
Bedenkt datt dës d'Nuets-Toolkette installéiere mussen a fir `rustc` iwwer Ären Zil Triple a seng CPU ze wëssen.
Besonnesch Dir musst d `TARGET` Ëmfeldvariabel setzen wéi Dir et fir `ci/run.sh` géift maachen.
Zousätzlech musst Dir `RUSTCFLAGS` setzen (braucht den `C`) fir Zilfeatures unzeginn, z `RUSTCFLAGS="-C -target-features=+avx2"`.
Dir kënnt och `-C -target-cpu=native` setzen wann Dir "just" géint Är aktuell CPU entwéckelt.

Gitt gewarnt datt wann Dir dës alternativ Instruktioune benotzt, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], z
Instruktiounsgeneratiounstester kënnen ausfalen well den Demonstrant se anescht benannt, z
et kann `vaesenc` generéieren amplaz `aesenc` Instruktiounen trotz datt se d'selwecht behuelen.
Och dës Instruktiounen féieren manner Tester aus wéi normalerweis gemaach ginn, also sidd net iwwerrascht datt wann Dir eventuell zitt-Ufro e puer Feeler kënne weisen fir Tester déi net hei ofgedeckt sinn.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






