//! Ëmsetzung vum `#[assert_instr]` Macro
//!
//! Dëse Makro gëtt benotzt beim Test vun der `stdarch` crate a gëtt benotzt fir Testfäll ze generéieren fir ze behaapten datt d'Funktioune wierklech d'Instruktioune enthalen déi mir erwaarden datt se enthalen.
//!
//! De prozeduralen Makro hei ass relativ einfach, et füügt einfach eng `#[test]` Funktioun op den originale token Stream un, dee behaapt datt d'Funktioun selwer déi relevant Instruktioun enthält.
//!
//!
//!
//!

extern crate proc_macro;
extern crate proc_macro2;
#[macro_use]
extern crate quote;
extern crate syn;

use proc_macro2::TokenStream;
use quote::ToTokens;

#[proc_macro_attribute]
pub fn assert_instr(
    attr: proc_macro::TokenStream,
    item: proc_macro::TokenStream,
) -> proc_macro::TokenStream {
    let invoc = match syn::parse::<Invoc>(attr) {
        Ok(s) => s,
        Err(e) => return e.to_compile_error().into(),
    };
    let item = match syn::parse::<syn::Item>(item) {
        Ok(s) => s,
        Err(e) => return e.to_compile_error().into(),
    };
    let func = match item {
        syn::Item::Fn(ref f) => f,
        _ => panic!("must be attached to a function"),
    };

    let instr = &invoc.instr;
    let name = &func.sig.ident;

    // Desaktivéiert assert_instr fir x86 Ziler kompiléiert mat avx aktivéiert, wat bewierkt datt LLVM verschidden Intrinsike generéiert wéi déi déi mir testen.
    //
    //
    let disable_assert_instr = std::env::var("STDARCH_DISABLE_ASSERT_INSTR").is_ok();

    // Wann Instruktiounstester behënnert sinn, vermeit dës Shim iwwerhaapt auszestellen, just den Original Element zréckginn ouni eis Attribut.
    //
    if !cfg!(optimized) || disable_assert_instr {
        return (quote! { #item }).into();
    }

    let instr_str = instr
        .replace('.', "_")
        .replace('/', "_")
        .replace(':', "_")
        .replace(char::is_whitespace, "");
    let assert_name = syn::Ident::new(&format!("assert_{}_{}", name, instr_str), name.span());
    // Dësen Numm muss eenzegaarteg sinn fir eis et spéider am Demontage ze fannen:
    let shim_name = syn::Ident::new(
        &format!("stdarch_test_shim_{}_{}", name, instr_str),
        name.span(),
    );
    let mut inputs = Vec::new();
    let mut input_vals = Vec::new();
    let ret = &func.sig.output;
    for arg in func.sig.inputs.iter() {
        let capture = match *arg {
            syn::FnArg::Typed(ref c) => c,
            ref v => panic!(
                "arguments must not have patterns: `{:?}`",
                v.clone().into_token_stream()
            ),
        };
        let ident = match *capture.pat {
            syn::Pat::Ident(ref i) => &i.ident,
            _ => panic!("must have bare arguments"),
        };
        if let Some(&(_, ref tokens)) = invoc.args.iter().find(|a| *ident == a.0) {
            input_vals.push(quote! { #tokens });
        } else {
            inputs.push(capture);
            input_vals.push(quote! { #ident });
        }
    }

    let attrs = func
        .attrs
        .iter()
        .filter(|attr| {
            attr.path
                .segments
                .first()
                .expect("attr.path.segments.first() failed")
                .ident
                .to_string()
                .starts_with("target")
        })
        .collect::<Vec<_>>();
    let attrs = Append(&attrs);

    // Benotzt en ABI op Windows déi SIMD Wäerter a Regëster weiderginn, wéi wat op Unix geschitt (ech mengen?) Par défaut.
    //
    let abi = if cfg!(windows) {
        syn::LitStr::new("vectorcall", proc_macro2::Span::call_site())
    } else {
        syn::LitStr::new("C", proc_macro2::Span::call_site())
    };
    let shim_name_str = format!("{}{}", shim_name, assert_name);
    let to_test = quote! {
        #attrs
        #[no_mangle]
        #[inline(never)]
        pub unsafe extern #abi fn #shim_name(#(#inputs),*) #ret {
            // De Compiler am optimiséierte Modus par défaut leeft e Pass mam Numm "mergefunc" wou et Funktioune fusionéiert déi identesch ausgesinn.
            // Et stellt sech eraus datt e puer Intrinsike identesch Code produzéieren a si sinn zesummegeklappt, dat heescht datt ee just op en anert spréngt.
            // Dëst veruersaacht eis Inspektioun vun der Demontage vun dëser Funktioun a mir si kee grousse Fan dovun.
            //
            // Fir dëse Pass ze verhënneren an ze verhënneren datt Funktioune fusionéiert ginn generéiere mir e puer Code déi hoffentlech ganz enk wat Codegen ugeet awer anescht eenzegaarteg ass fir ze verhënneren datt de Code zesummefalt.
            //
            //
            // Dëst gëtt op Wasm32 elo vermeit, well dës Funktiounen net gezeechent sinn, déi eis Tester briechen, well all intrinsesch ausgesäit wéi se Funktiounen nennt.
            // Et stellt sech eraus datt Funktiounen net ähnlech genuch sinn fir souwisou op wasm32 fusionéiert ze ginn.
            // Dëse Feeler gëtt op rust-lang/rust#74320 verfollegt.
            //
            //
            //
            //
            //
            //
            //
            #[cfg(not(target_arch = "wasm32"))]
            ::stdarch_test::_DONT_DEDUP.store(
                std::mem::transmute(#shim_name_str.as_bytes().as_ptr()),
                std::sync::atomic::Ordering::Relaxed,
            );
            #name(#(#input_vals),*)
        }
    };

    let tokens: TokenStream = quote! {
        #[test]
        #[allow(non_snake_case)]
        fn #assert_name() {
            #to_test

            ::stdarch_test::assert(#shim_name as usize,
                                   stringify!(#shim_name),
                                   #instr);
        }
    };

    let tokens: TokenStream = quote! {
        #item
        #tokens
    };
    tokens.into()
}

struct Invoc {
    instr: String,
    args: Vec<(syn::Ident, syn::Expr)>,
}

impl syn::parse::Parse for Invoc {
    fn parse(input: syn::parse::ParseStream) -> syn::Result<Self> {
        use syn::{ext::IdentExt, Token};

        let mut instr = String::new();
        while !input.is_empty() {
            if input.parse::<Token![,]>().is_ok() {
                break;
            }
            if let Ok(ident) = syn::Ident::parse_any(input) {
                instr.push_str(&ident.to_string());
                continue;
            }
            if input.parse::<Token![.]>().is_ok() {
                instr.push('.');
                continue;
            }
            if let Ok(s) = input.parse::<syn::LitStr>() {
                instr.push_str(&s.value());
                continue;
            }
            println!("{:?}", input.cursor().token_stream());
            return Err(input.error("expected an instruction"));
        }
        if instr.is_empty() {
            return Err(input.error("expected an instruction before comma"));
        }
        let mut args = Vec::new();
        while !input.is_empty() {
            let name = input.parse::<syn::Ident>()?;
            input.parse::<Token![=]>()?;
            let expr = input.parse::<syn::Expr>()?;
            args.push((name, expr));

            if input.parse::<Token![,]>().is_err() {
                if !input.is_empty() {
                    return Err(input.error("extra tokens at end"));
                }
                break;
            }
        }
        Ok(Self { instr, args })
    }
}

struct Append<T>(T);

impl<T> quote::ToTokens for Append<T>
where
    T: Clone + IntoIterator,
    T::Item: quote::ToTokens,
{
    fn to_tokens(&self, tokens: &mut proc_macro2::TokenStream) {
        for item in self.0.clone() {
            item.to_tokens(tokens);
        }
    }
}