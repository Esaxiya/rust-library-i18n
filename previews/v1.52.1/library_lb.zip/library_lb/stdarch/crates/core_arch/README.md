`core::arch` - Rust Kärbibliothéik Architektur-spezifesch Intrinsik
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Den `core::arch` Modul implementéiert architektonofhängeg Intrinsiken (zB SIMD).

# Usage 

`core::arch` ass als Deel vun `libcore` verfügbar an et gëtt vun `libstd` nei exportéiert.Benotzt et léiwer iwwer `core::arch` oder `std::arch` wéi iwwer dësen crate.
Onbestänneg Features sinn dacks an der Nuecht Rust iwwer den `feature(stdsimd)` verfügbar.

`core::arch` iwwer dësen crate ze benotzen erfuerdert nuets Rust, an et kann (a mécht) dacks briechen.Déi eenzeg Fäll an deenen Dir et sollt iwwer dëse crate benotzen ze benotzen:

* wann Dir `core::arch` selwer nei zesummestelle musst, zB mat speziellen Zilfunktiounen aktivéiert déi net fir `libcore`/`libstd` aktivéiert sinn.
Note: wann Dir et fir en net-Standard Ziel nei zesummestelle musst, gitt léiwer mat `xargo` an `libcore`/`libstd` nei kompiléieren wéi ubruecht amplaz dës crate ze benotzen.
  
* mat e puer Features déi net méiglech sinn och hannert onbestännegen Rust Featuren.Mir probéieren dës op e Minimum ze halen.
Wann Dir e puer vun dëse Feature benotze musst, maacht weg e Thema op, fir datt mir se an der Nuecht Rust exponéieren an Dir kënnt se vun do aus benotzen.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` gëtt haaptsächlech ënner de Bedéngunge vun der MIT Lizenz an der Apache Lizenz (Versioun 2.0) verdeelt, mat Portiounen déi vu verschiddene BSD-ähnleche Lizenzen ofgedeckt sinn.

Kuckt LIZENZ-APACHE, a LIZENZ-MIT fir Detailer.

# Contribution

Ausser Dir explizit anescht uginn, gëtt all Bäitrag absichtlech fir Iech an `core_arch` agereecht, wéi definéiert an der Apache-2.0 Lizenz, duebel lizenzéiert wéi uewen, ouni zousätzlech Bedéngungen oder Bedéngungen.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












