use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Benotzt fir eis `#[assert_instr]` Annotatiounen ze soen datt all simd Intrinsike verfügbar sinn fir hir Codegen ze testen, well e puer sinn hannert engem extra `-Ctarget-feature=+unimplemented-simd128` gepaart, deen am Moment keng Äquivalent am `#[target_feature]` huet.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}