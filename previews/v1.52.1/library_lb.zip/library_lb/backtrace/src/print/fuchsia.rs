use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr hëlt e Réckruff deen en dl_phdr_info Zeiger kritt fir all DSO deen an de Prozess verlinkt ass.
    // dl_iterate_phdr garantéiert och datt den dynamesche Linker vun Ufank bis Enn vun der Iteratioun gespaart ass.
    // Wann de Réckruff en Net-Null Wäert zréckkënnt, gëtt d'Iteratioun fréi ofgeschloss.
    // 'data' gëtt als drëtt Argument un de Réckruff bei all Uruff weiderginn.
    // 'size' gëtt d'Gréisst vum dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Mir mussen d'Build ID analyséieren an e puer Basis Programm Header Daten dat heescht datt mir e bësse Saachen aus der ELF Spezifizéierung brauchen.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Elo musse mir replikéieren, bëssen fir bëssen, d'Struktur vum Typ dl_phdr_info benotzt vum aktuellen dynamesche Linker vum Fuchsia.
// Chrom huet och dës ABI Grenz wéi och Crashpad.
// Eventuell wéilte mir dës Fäll réckele fir Elf-Sich ze benotzen awer mir missten dat an der SDK ubidden an dat ass nach net gemaach.
//
// Dofir si mir (a si) hänke bliwwen dës Method ze benotzen déi eng enk Kopplung mat der Fuchsia Libc mécht.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Mir hu kee Wee fir ze wëssen ze kontrolléieren ob e_phoff an e_phnum valabel sinn.
    // libc sollt dëst awer fir eis suergen dofir ass et sécher eng Scheif hei ze bilden.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr representéiert en 64-Bit ELF Programm Header an der Endlechkeet vun der Zilarchitektur.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr stellt e gültege ELF Programm Header a säin Inhalt duer.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Mir hu kee Wee fir ze kontrolléieren ob p_addr oder p_memsz valabel sinn.
    // Dem Fuchsia säi Libc analyséiert d'Noten als éischt awer sou datt se hei sinn dës Header gëlteg sinn.
    //
    // NoteIter erfuerdert net datt d'Basisdaten gëlteg sinn, awer et erfuerdert d'Grenze fir valabel ze sinn.
    // Mir vertrauen datt Libc gesuergt huet datt dëst de Fall fir eis hei ass.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Den Notiztyp fir Build IDen.
const NT_GNU_BUILD_ID: u32 = 3;

// Den Elf_Nhdr representéiert en ELF Noten Header an der Endlechkeet vum Zil.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Notiz stellt eng ELF Notiz duer (Header + Inhalt).
// Den Numm bleift als u8 Slice well et ass net ëmmer null ofgeschloss an rust mécht et einfach genuch ze kontrolléieren datt d'Bytes egal wéi passen.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter léisst Iech sécher iwwer e Notizsegment iteréieren.
// Et gëtt ofgeschloss soubal e Feeler geschitt oder et gi keng Notizen méi.
// Wann Dir iwwer ongëlteg Daten itéiert, funktionnéiert et wéi wa keng Notize fonnt goufen.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Et ass en Ofwiesselungsfunktioun datt de Zeiger a Gréisst uginn e gültege Beräich vu Bytes bezeechent déi all gelies kënne ginn.
    // Den Inhalt vun dëse Bytes kann alles sinn awer d'Band muss valabel sinn fir dat sécher ze sinn.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to alignéiert 'x' op 'to'-Byte Ausrichtung unzehuelen datt 'to' eng Kraaft vun 2 ass.
// Dëst folgt e Standardmuster am C/C ++ ELF Parsingcode wou (x + to, 1)&-to benotzt gëtt.
// Rust léisst Iech net d'Benotzung negéieren also benotze ech
// 2's-Ergänzungs Konversioun fir dat nei ze kreéieren.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 verbraucht num Bytes aus der Scheif (wann se do sinn) a garantéiert zousätzlech datt d'Finale Slice richteg ausgeriicht ass.
// Wann entweder d'Zuel vun de gefrote Bytes ze grouss ass oder d'Scheif net duerno nei ausgeriicht ka ginn, well net genuch Rescht Bytes existéieren, gëtt Keen zréckkomm an de Slice gëtt net geännert.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Dës Funktioun huet keng richteg Invarariater, déi den Uruff muss ënnerhalen, ausser vläicht datt 'bytes' fir d'Performance ausgeriicht sollt sinn (an op e puer Architekturkorrektheeten).
// D'Wäerter an den Elf_Nhdr Felder kéinte Blödsinn sinn awer dës Funktioun suergt fir näischt.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Dëst ass sécher soulaang genuch Plaz ass a mir hu just bestätegt datt an der Ausso hei uewen, sou datt dëst net onsécher sollt sinn.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Bedenkt datt sice_of: :<Elf_Nhdr>() ass ëmmer 4-Byte ausgeriicht.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Kontrolléiert ob mir um Enn ukomm sinn.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Mir transmutéieren en nhdr awer mir betruechten déi entstinn Struktur suergfälteg.
        // Mir vertrauen net den namesz oder descsz a mir maachen keng onsécher Entscheedungen op Basis vum Typ.
        //
        // Also och wa mir e komplette Müll erauskréien, solle mir nach ëmmer sécher sinn.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Weist datt e Segment ausführbar ass.
const PERM_X: u32 = 0b00000001;
/// Weist datt e Segment schrëftlech ass.
const PERM_W: u32 = 0b00000010;
/// Weist datt e Segment liesbar ass.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Stellt en ELF Segment bei der Runtime duer.
struct Segment {
    /// Gëtt eng runtime virtuell Adress vum Inhalt vun dësem Segment.
    addr: usize,
    /// Gitt d'Erënnerungsgréisst vum Inhalt vun dësem Segment.
    size: usize,
    /// Gitt d'Modul virtuell Adress vun dësem Segment mat der ELF Datei.
    mod_rel_addr: usize,
    /// Gitt d'Rechter déi an der ELF Datei fonnt goufen.
    /// Dës Permissiounen sinn awer net onbedéngt d'Rechter déi beim Runtime present sinn.
    flags: Perm,
}

/// Loosst een iwwer Segmenter vun engem DSO iteréieren.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Stellt en ELF DSO (Dynamic Shared Object) duer.
/// Dësen Typ bezitt sech op d'Daten déi am aktuellen DSO gespäichert sinn anstatt eng eege Kopie ze maachen.
struct Dso<'a> {
    /// Den dynamesche Linker gëtt eis ëmmer en Numm, och wann den Numm eidel ass.
    /// Am Fall vun der Haaptausführbar ass dësen Numm eidel.
    /// Am Fall vun engem gemeinsamen Objet ass et de Soname (kuck DT_SONAME).
    name: &'a str,
    /// Op Fuchsia hu praktesch all Binarien IDe gebaut awer dëst ass net eng strikt Ufro.
    /// Et gëtt kee Wee fir DSO Informatioun mat enger richteger ELF Datei mateneen unzepassen, wann et kee build_id ass, also brauche mir datt all DSO een hei huet.
    ///
    /// DSO's ouni build_id ginn ignoréiert.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Nees en Iterator iwwer Segmenter an dësem DSO.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Dës Feeler kodéieren Themen déi entstinn beim Informéiere vun all DSO.
///
enum Error {
    /// NameError heescht datt e Feeler geschitt ass beim Ëmwandele vun enger C Stil String an eng rust String.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError heescht datt mir keng Build ID fonnt hunn.
    /// Dëst kéint entweder sinn well den DSO keng Build ID hat oder well de Segment mat der Build ID mat falsch geformt war.
    ///
    BuildIDError,
}

/// Rufft entweder 'dso' oder 'error' fir all DSO an de Prozess vum dynamesche Linker un.
///
///
/// # Arguments
///
/// * `visitor` - En DsoPrinter deen eng vun Iessmethoden huet genannt foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr garantéiert datt info.name op eng valabel Plaz hiweist.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Dës Funktioun dréckt de Fuchsia Symbolizer Markup fir all Informatioun an engem DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}