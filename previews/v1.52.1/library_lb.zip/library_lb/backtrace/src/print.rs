#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// E Formater fir Backtraces.
///
/// Dësen Typ kann benotzt ginn fir e Backtrace ze drécken egal wou de Backtrace selwer kënnt.
/// Wann Dir en `Backtrace` Typ hutt, da benotzt seng `Debug` Implementatioun schonn dëst Dréckformat.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// D'Stiler vum Drock, dee mir kënne drécken
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Dréckt en Terser Backtrace deen am Idealfall nëmmen relevant Informatioun enthält
    Short,
    /// Dréckt e Réckwee deen all méiglech Informatiounen enthält
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Erstellt en neien `BacktraceFmt` deen d'Ausgab op de verfügbaren `fmt` schreift.
    ///
    /// D `format` Argument wäert de Stil kontrolléieren an deem de Backtrace gedréckt ass, an d `print_path` Argument gëtt benotzt fir d `BytesOrWideString` Instanzen vun Dateinumm ze drécken.
    /// Dësen Typ selwer mécht keen Drock vun Dateinumm, awer dëse Réckruff ass erfuerderlech fir dat ze maachen.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Dréckt e Preambel fir datt de Réckwee ongeféier gedréckt gëtt.
    ///
    /// Dëst ass op e puer Plattformen erfuerderlech fir Backtraces méi spéit symboliséiert ze sinn, a soss sollt dëst just déi éischt Method sinn déi Dir nennt nodeems Dir en `BacktraceFmt` erstallt hutt.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Füügt e Frame fir de Backtrace Output bäi.
    ///
    /// Dës Verpflichtung bréngt eng RAII Instanz vun engem `BacktraceFrameFmt` zréck, déi benotzt ka ginn fir e Frame ze drécken, a bei der Zerstéierung wäert de Frame Compteur eropgoen.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Fäerdeg de Backtrace Output.
    ///
    /// Dëst ass de Moment e No-Op awer gëtt fir future Kompatibilitéit mat Backtrace Formater derbäigesat.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Momentan en No-op-- inklusive dësen hook fir future Ergänzungen z'erméiglechen.
        Ok(())
    }
}

/// E Formater fir just ee Frame vun engem Backtrace.
///
/// Dësen Typ gëtt vun der `BacktraceFmt::frame` Funktioun erstallt.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Dréckt en `BacktraceFrame` mat dësem Frameformater.
    ///
    /// Dëst wäert recursiv all `BacktraceSymbol` Instanzen am `BacktraceFrame` drécken.
    ///
    /// # Néideg Features
    ///
    /// Dës Funktioun erfuerdert d `std` Feature vum `backtrace` crate fir aktivéiert ze sinn, an d `std` Feature ass standard aktivéiert.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Dréckt en `BacktraceSymbol` bannent engem `BacktraceFrame`.
    ///
    /// # Néideg Features
    ///
    /// Dës Funktioun erfuerdert d `std` Feature vum `backtrace` crate fir aktivéiert ze sinn, an d `std` Feature ass standard aktivéiert.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: dëst ass net super, datt mir näischt drécken
            // mat net-utf8 Dateinumm.
            // Glécklecherweis ass bal alles utf8, sou dat sollt net ze schlecht sinn.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Dréckt e rau verfollegt `Frame` an `Symbol`, typesch vu bannent de roude Réckruff vun dësem crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Füügt e roude Frame fir de Backtrace Output bäi.
    ///
    /// Dës Method, am Géigesaz zu der viregter, hëlt déi réi Argumenter am Fall wou se Quell vu verschiddene Standorte sinn.
    /// Bedenkt datt dëst e puer Mol fir ee Frame ka genannt ginn.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Füügt e roude Frame an de Backtrace Output bäi, mat Spalteinformatioun.
    ///
    /// Dës Method, wéi déi virdrun, hëlt déi réi Argumenter am Fall wou se vu verschiddene Standuerte kommen.
    /// Bedenkt datt dëst e puer Mol fir ee Frame ka genannt ginn.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia kann net bannent engem Prozess symboliséieren, sou datt et e speziellt Format huet wat benotzt ka gi méi spéit ze symboliséieren.
        // Dréckt dat amplaz Adressen an eisem eegene Format hei ze drécken.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Kee Grond fir "null" Frames ze drécken, et heescht am Fong just datt de System Backtrace e bësse gär war fir super wäit zréckzekommen.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Fir TCB Gréisst a Sgx Enklav ze reduzéieren, wëlle mir keng Symbolopléisungsfunktionalitéit implementéieren.
        // Villméi kënne mir den Offset vun der Adress hei drécken, déi spéider op eng korrekt Funktioun ka ginn.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Dréckt den Index vum Frame wéi och den optionalen Uweisungszeiger vum Frame.
        // Wa mir méi wäit wéi dat éischt Symbol vun dësem Frame sinn, drécken mir awer just de passende Wäissraum.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Niewendrun schreift de Symbolnumm aus, benotzt d'alternativ Formatéierung fir méi Informatioun wa mir e komplette Réckwee sinn.
        // Hei behandele mir och Symboler déi keen Numm hunn,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // A leschter erop, dréckt d filename/line Nummer aus wann se verfügbar sinn.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line ginn op Zeilen ënner dem Symbolnumm gedréckt, dréckt also e passende wäisse Raum fir eis selwer richteg auszeriichten.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Delegéiert un eisen interne Réckruff fir den Dateinumm ze drécken an dann d'Linnennummer auszedrécken.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Füügt Kolonnennummer bäi, wann verfügbar.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Mir këmmeren eis nëmmen ëm dat éischt Symbol vun engem Frame
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}