use core::ffi::c_void;
use core::fmt;

/// Inspizéiert den aktuellen Call-Stack, weiderginn all aktiv Frames an den Zoumaache fir eng Stackspur ze berechnen.
///
/// Dës Funktioun ass d'Aarbechtspäerd vun dëser Bibliothéik fir d'Stackspure fir e Programm ze berechnen.De gegebene Schließung `cb` gëtt Instanzen vun engem `Frame` ausgezeechent déi Informatioun iwwer dëse Ruffframe am Stack representéieren.
/// D'Schléissung gëtt Frames op Top-Down Moud (lescht genannt Funktiounen als éischt).
///
/// De Retourwäert vun der Fermeture ass eng Indikatioun ob de Backtrace sollt weidergoen.E Retourwäert vun `false` wäert de Réckwee ophalen an direkt zréckgoen.
///
/// Wann en `Frame` kaaft ass, wëllt Dir wuel `backtrace::resolve` uruffe fir den `ip` (Instruktiounsweiser) oder d'Symbol Adress un en `Symbol` ze konvertéieren, duerch deen den Numm an/oder Dateinumm/Zeilennummer ka geléiert ginn.
///
///
/// Bedenkt datt dëst eng relativ niddereg Funktioun ass a wann Dir zum Beispill e Backtrace erfaasse fir méi spéit ze kontrolléieren, da kann den `Backtrace` Typ méi passend sinn.
///
/// # Néideg Features
///
/// Dës Funktioun erfuerdert d `std` Feature vum `backtrace` crate fir aktivéiert ze sinn, an d `std` Feature ass standard aktivéiert.
///
/// # Panics
///
/// Dës Funktioun beméit sech ni panic ze maachen, awer wann den `cb` panics zur Verfügung gestallt huet, da wäerte verschidde Plattformen en duebelen panic forcéieren de Prozess ofzebriechen.
/// E puer Plattforme benotzen eng C Bibliothéik déi intern Callbacks benotzt déi net kënnen ausgewéckelt ginn, sou datt Panik vun `cb` e Prozess ofbrécht.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // weider de Réckwee
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Selwecht wéi `trace`, nëmmen onsécher wéi et net synchroniséiert ass.
///
/// Dës Funktioun huet keng Synchroniséierungsgarantien awer ass verfügbar wann d `std` Feature vun dësem crate net erstallt ass.
/// Kuckt d `trace` Funktioun fir méi Dokumentatioun a Beispiller.
///
/// # Panics
///
/// Kuckt d'Informatioun iwwer `trace` fir Virbehalt op `cb` Panik.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// En trait, deen ee Frame vun engem Backtrace representéiert, huet der `trace` Funktioun vun dësem crate noginn.
///
/// D'Schléissfunktioun vun der Verfollegungsfunktioun gëtt Frames ausgeliwwert, an de Frame gëtt praktesch verschéckt, well d'Basisgrond Ëmsetzung net ëmmer bis zur Runtime bekannt ass.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Gitt den aktuellen Instruktiounszeiger vun dësem Frame zréck.
    ///
    /// Dëst ass normalerweis déi nächst Instruktioun fir am Frame auszeféieren, awer net all Implementéierunge lëschten dëst mat 100% Genauegkeet (awer et ass normalerweis relativ no).
    ///
    ///
    /// Et ass recommandéiert dëse Wäert op `backtrace::resolve` weiderzeginn fir en an e Symbolnumm ze maachen.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Gitt den aktuellen Stackzeiger vun dësem Frame zréck.
    ///
    /// Am Fall datt e Backend de Stackzeiger fir dëse Frame net erëmfanne kann, gëtt en Nullzeiger zréck.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Gitt d'Ufankssymbol Adress vum Frame vun dëser Funktioun zréck.
    ///
    /// Dëst wäert probéieren d'Instruktiounsspuer zréckzeschloen, déi vum `ip` zréck an de Start vun der Funktioun zréckgeet, an dee Wäert zréckbréngt.
    ///
    /// An e puer Fäll wäerten awer Backends just `ip` vun dëser Funktioun zréckginn.
    ///
    /// De zréckgezunnene Wäert kann heiansdo benotzt ginn wann `backtrace::resolve` op der `ip` hei uewen uginn.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Gitt d'Basis Adress vum Modul zréck, zu deem de Frame gehéiert.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Dëst muss als éischt kommen, fir sécherzestellen datt Miri Prioritéit iwwer d'Hostplattform huet
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // nëmmen an dbghelp symboliséiert benotzt
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}