// nëmmen elo op Linux benotzt, also erlaabt doudege Code anzwuesch
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Eng einfach Arena allocator fir Byte Buffer.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Allokéiert e Puffer vun der spezifizéierter Gréisst a bréngt eng mutéierbar Referenz drop zréck.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SAFETY: dëst ass déi eenzeg Funktioun déi jeemools eng mutabel konstruéiert
        // Referenz op `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // SAFETY: mir huele ni Elementer aus `self.buffers` ewech, also eng Referenz
        // zu den Daten an all Puffer wäert soulaang liewen wéi `self`.
        &mut buffers[i]
    }
}