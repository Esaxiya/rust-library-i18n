use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Léis eng Adress un e Symbol, gitt d'Symbol un de spezifizéierte Schluss.
///
/// Dës Funktioun kuckt déi gegebene Adress a Beräicher wéi d'lokal Symboltabell, dynamesch Symboltabell oder DWARF Debug Info (ofhängeg vun der aktivéierter Ëmsetzung) fir Symboler ze fannen fir ze ginn.
///
///
/// D'Fermeture kann net genannt ginn wann d'Resolutioun net konnt ausgefouert ginn, an et kann och méi wéi eemol am Fall vun inline Funktiounen genannt ginn.
///
/// Krut Symboler stellen d'Ausféierung op der spezifizéierter `addr` duer, an zréck file/line Puer fir dës Adress (wa verfügbar).
///
/// Bedenkt datt wann Dir en `Frame` hutt, da gëtt et recommandéiert d `resolve_frame` Funktioun ze benotzen anstatt dës.
///
/// # Néideg Features
///
/// Dës Funktioun erfuerdert d `std` Feature vum `backtrace` crate fir aktivéiert ze sinn, an d `std` Feature ass standard aktivéiert.
///
/// # Panics
///
/// Dës Funktioun beméit sech ni panic ze maachen, awer wann den `cb` panics zur Verfügung gestallt huet, da wäerte verschidde Plattformen en duebelen panic forcéieren de Prozess ofzebriechen.
/// E puer Plattforme benotzen eng C Bibliothéik déi intern Callbacks benotzt déi net kënnen ausgewéckelt ginn, sou datt Panik vun `cb` e Prozess ofbrécht.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // kuckt nëmmen den ieweschte Frame
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Léist e virdrun erfaassen Frame zu engem Symbol, weiderginn d'Symbol an de spezifizéierte Schluss.
///
/// Dëse Functin féiert déiselwecht Funktioun wéi `resolve` ausser datt et en `Frame` als Argument hëlt amplaz eng Adress.
/// Dëst kann e puer Plattformimplementatioune vum Backtracing erlaben fir méi korrekt Symbolinformatioun oder Informatioun iwwer Inline Frames zum Beispill ze bidden.
///
/// Et ass recommandéiert dëst ze benotzen wann Dir kënnt.
///
/// # Néideg Features
///
/// Dës Funktioun erfuerdert d `std` Feature vum `backtrace` crate fir aktivéiert ze sinn, an d `std` Feature ass standard aktivéiert.
///
/// # Panics
///
/// Dës Funktioun beméit sech ni panic ze maachen, awer wann den `cb` panics zur Verfügung gestallt huet, da wäerte verschidde Plattformen en duebelen panic forcéieren de Prozess ofzebriechen.
/// E puer Plattforme benotzen eng C Bibliothéik déi intern Callbacks benotzt déi net kënnen ausgewéckelt ginn, sou datt Panik vun `cb` e Prozess ofbrécht.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // kuckt nëmmen den ieweschte Frame
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// IP Wäerter vu Stackframes sinn normalerweis (always?) d'Instruktioun *nom* den Uruff dat ass déi aktuell Stackspur.
// Symboliséiert dëst verursaacht datt d filename/line Nummer e viraus ass a vläicht an d'Void wann et um Enn vun der Funktioun ass.
//
// Dëst schéngt am Fong ëmmer de Fall ze sinn op alle Plattformen, also subtraktéiere mir ëmmer een vun engem geléisten IP fir se op déi fréier Uruffinstruktioun ze léisen amplaz datt d'Instruktioun zréckgeet.
//
//
// Ideal wäerte mir dat net maachen.
// Ideal wäerte mir Uruff vun den `resolve` APIs hei erfuerderen fir den -1 manuell ze maachen an ze berécksiichtegen datt se Plazinformatioun fir déi *vireg* Instruktioun wëllen, net déi aktuell.
// Ideal wäerte mir och op `Frame` aussetzen wa mir wierklech d'Adress vun der nächster Instruktioun oder der aktueller sinn.
//
// Fir elo awer dëst ass eng zimlech Nischebesuergung, also huele mir ëmmer intern ëmmer een of.
// Konsumenten solle weider schaffen an zimlech gutt Resultater kréien, also solle mir gutt genuch sinn.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Selwecht wéi `resolve`, nëmmen onsécher wéi et net synchroniséiert ass.
///
/// Dës Funktioun huet keng Synchroniséierungsgarantien awer ass verfügbar wann d `std` Feature vun dësem crate net erstallt ass.
/// Kuckt d `resolve` Funktioun fir méi Dokumentatioun a Beispiller.
///
/// # Panics
///
/// Kuckt d'Informatioun iwwer `resolve` fir Virbehalt op `cb` Panik.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Selwecht wéi `resolve_frame`, nëmmen onsécher wéi et net synchroniséiert ass.
///
/// Dës Funktioun huet keng Synchroniséierungsgarantien awer ass verfügbar wann d `std` Feature vun dësem crate net erstallt ass.
/// Kuckt d `resolve_frame` Funktioun fir méi Dokumentatioun a Beispiller.
///
/// # Panics
///
/// Kuckt d'Informatioun iwwer `resolve_frame` fir Virbehalt op `cb` Panik.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// En trait representéiert d'Resolutioun vun engem Symbol an enger Datei.
///
/// Dësen trait gëtt als trait Objet zum Zoumaache vun der `backtrace::resolve` Funktioun erginn, an et gëtt praktesch verschéckt well et onbekannt ass wéi eng Implementatioun hannendrun ass.
///
///
/// E Symbol kann kontextuell Informatioun iwwer eng Funktioun ginn, zum Beispill den Numm, Dateinumm, Zeilennummer, präzis Adress, asw.
/// Net all Informatioun ass ëmmer an engem Symbol verfügbar, awer dofir ginn all Methoden en `Option` zréck.
///
///
pub struct Symbol {
    // TODO: dës Liewensdauer gebonnen muss schlussendlech op `Symbol` bestoe bleiwen,
    // awer dat ass am Moment eng brechend Ännerung.
    // Fir elo ass dëst sécher, well `Symbol` gëtt ëmmer nëmme mat Referenz ausgedeelt a kann net gekloont ginn.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Nees den Numm vun dëser Funktioun.
    ///
    /// Déi zréckkomm Struktur kann benotzt ginn fir verschidde Properties iwwer de Symbolnumm ze froen:
    ///
    ///
    /// * D `Display` Implementatioun dréckt dat ofgebaute Symbol aus.
    /// * De roude `str` Wäert vum Symbol kann zougänglech sinn (wann et gëlteg utf-8 ass).
    /// * Déi ro Bytes fir de Symbolnumm kënnen zougeruff ginn.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Retourneiert d'Startadress vun dëser Funktioun.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Returns de roude Dateinumm als Stéck.
    /// Dëst ass haaptsächlech nëtzlech fir `no_std` Ëmfeld.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Gitt d'Kolonnennummer zréck fir wou dëst Symbol de Moment ausgefouert gëtt.
    ///
    /// Nëmme gimli liwwert de Moment e Wäert hei an och nëmmen dann wann `filename` `Some` zréckbréngt, an dofir ass et deemno ähnlech Virbehalt.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Gitt d'Linnennummer zréck fir wou dëst Symbol de Moment ausgefouert gëtt.
    ///
    /// Dëse Retourwäert ass typesch `Some` wann `filename` `Some` zréckkommt, an ass deemno ähnlech Bedierfnesser.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Gitt de Dateinumm zréck wou dës Funktioun definéiert war.
    ///
    /// Dëst ass de Moment nëmme verfügbar wann libbacktrace oder gimli benotzt gëtt (z. B.
    /// unix Plattformen aner) a wann e Binär mat Debuginfo kompiléiert gëtt.
    /// Wa keng vun dëse Konditioune erfëllt sinn, wäert dëst méiglecherweis `None` zréckbréngen.
    ///
    /// # Néideg Features
    ///
    /// Dës Funktioun erfuerdert d `std` Feature vum `backtrace` crate fir aktivéiert ze sinn, an d `std` Feature ass standard aktivéiert.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Vläicht e analyséiert C++ Symbol, wann dat mangléiert Symbol als Rust analyséiert gëtt.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Gitt sécher datt Dir dës Nullgréisst behält, sou datt d `cpp_demangle` Feature keng Käschten huet wann se deaktivéiert sinn.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// E Wéckel ronderëm e Symbolnumm fir ergonomesch Accessoiren zum demangéierten Numm, de roude Bytes, de roude String, etc.
///
// Erlaabt Doudekode fir wann d `cpp_demangle` Feature net aktivéiert ass.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Erstellt en neie Symbolnumm aus de roude Basisbytes.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Nees de roude (mangled) Symbolnumm als `str` wann d'Symbol gëlteg utf-8 ass.
    ///
    /// Benotzt d `Display`-Implementatioun wann Dir déi ofgebauter Versioun wëllt.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Nees de roude Symbolnumm als Lëscht vu Bytes
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Dëst ka fir ze drécken wann dat demangéiert Symbol net tatsächlech gëlteg ass, also handelt de Feeler hei graziéis andeems Dir et net no bausse propagéiert.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Versicht dat gespäichert Gedächtnis ze recuperéieren fir d'Adressen ze symboliséieren.
///
/// Dës Method wäert probéieren all global Datastrukturen ze verëffentlechen déi soss weltwäit cache gelooss goufen oder am Fuedem déi normalerweis analyséiert DWARF Informatioun oder ähnlech duerstellen.
///
///
/// # Caveats
///
/// Och wann dës Funktioun ëmmer verfügbar ass, mécht et eigentlech näischt op de meeschten Implementatiounen.
/// Bibliothéiken wéi dbghelp oder libbacktrace bidden keng Ariichtungen fir de Staat ze verhandelen an d'allocéiert Erënnerung ze managen.
/// Fir elo ass d `gimli-symbolize` Feature vun dësem crate déi eenzeg Feature wou dës Funktioun iergendeen Effekt huet.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}