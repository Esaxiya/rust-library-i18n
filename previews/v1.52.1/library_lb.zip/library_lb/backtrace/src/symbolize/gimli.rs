//! Ënnerstëtzung fir Symbolik mat der `gimli` crate op crates.io
//!
//! Dëst ass d'Standardsymbolikéierung fir Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'statesch Liewensdauer ass eng Ligen fir ronderëm Mangel un Ënnerstëtzung fir selbstbezuelend Strucken ze hacken.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Konvertéiert an 'statesch Liewensdauer well d'Symboler nëmmen `map` an `stash` léine mussen a mir erhalen se hei drënner.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Fir Luede vun natierleche Bibliothéiken op Windows, kuckt e puer Diskussiounen op rust-lang/rust#71060 fir déi verschidde Strategien hei.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW Bibliothéiken ënnerstëtzen de Moment net ASLR (rust-lang/rust#16514), awer DLLs kënnen ëmmer nach am Adressraum verluecht ginn.
            // Et schéngt datt Adressen an Debug Info all sinn wéi wann dës Bibliothéik op hirem "image base" gelueden ass, wat e Feld a senge COFF Datei Header ass.
            // Well dëst ass wat Debuginfo schéngt ze lëschten analyséiere mir d'Symboltabelle a späichere Adressen wéi wann d'Bibliothéik och op "image base" gelueden ass.
            //
            // D'Bibliothéik kann awer net op "image base" gelueden sinn.
            // (vermeintlech kann eppes anescht do gelueden ginn?) Dëst ass wou den `bias` Feld an d'Spill kënnt, a mir mussen de Wäert vun der `bias` hei erausfannen.Leider ass et awer net kloer wéi een dëst aus engem geluedene Modul kritt.
            // Wat mir awer hunn ass déi tatsächlech Lastadress (`modBaseAddr`).
            //
            // Als e bësse Cop-Out fir de Moment mmapéiere mir d'Datei, liesen d'Datei Header Informatioun, da fällt de mmap.Dëst ass verschwenden, well mir wäerte méiglecherweis de mmap méi spéit erëm opmaachen, awer dëst sollt elo gutt genuch funktionnéieren.
            //
            // Wann mir d `image_base` (gewënschte Laaschtplaz) an d `base_addr` (tatsächlech Laaschtlokalitéit) hunn, kënne mir den `bias` ausfëllen (Ënnerscheed tëscht der aktueller a gewënschter) an dann ass déi uginn Adress vun all Segment den `image_base` well dat ass wat d'Datei seet.
            //
            //
            // Fir elo schéngt et datt am Géigesaz zu ELF/MachO kënne mir mat engem Segment pro Bibliothéik maachen, mat `modBaseSize` als ganz Gréisst.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS benotzt de Mach-O Dateiformat a benotzt DYLD-spezifesch APIen fir eng Lëscht vun natierleche Bibliothéiken ze lueden déi Deel vun der Applikatioun sinn.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Gitt den Numm vun dëser Bibliothéik, deen dem Wee entsprécht, wou se se och luede soll.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Luet den Image Header vun dëser Bibliothéik an delegéiert op `object` fir all d'Belaaschtungskommandoen ze analyséieren, sou datt mir all d'Segmenter déi hei involvéiert sinn erausfannen.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Iteréiert iwwer d'Segmenter a registréiert bekannte Regioune fir Segmenter déi mir fannen.
            // Zousätzlech registréiert Informatioun iwwer Textsegmenter fir spéider ze verarbeiten, kuckt Kommentaren hei ënnen
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Bestëmmt den "slide" fir dës Bibliothéik déi am Endeffekt d'Bias ass déi mir benotze fir erauszefannen wou an Erënnerung Objete gelueden sinn.
            // Dëst ass e bësse komesch Berechnung awer an ass d'Resultat e puer Saachen an der fräier Natur ze probéieren an ze gesinn, wat stécht.
            //
            // Déi allgemeng Iddi ass datt den `bias` plus e `stated_virtual_memory_address` vun engem Segment wäert sinn wou am aktuellen Adressraum de Segment wunnt.
            // Déi aner Saach op déi mir awer vertrauen ass datt eng richteg Adress minus den `bias` den Index ass fir an der Symboltabelle nozekucken an ze debuginfo.
            //
            // Et stellt sech awer eraus, datt fir systemgelueden Bibliothéiken dës Berechnungen net korrekt sinn.Fir nativen Exekutabelen schéngt et awer richteg.
            // Hëlt eng Logik aus der Quell vum LLDB et huet e speziellen Hülsen fir déi éischt `__TEXT` Sektioun aus der Dateioffset 0 mat enger Nullgréisst.
            // Aus egal wéi engem Grond wann dëst präsent ass, schéngt et ze heeschen datt d'Symboltabelle relativ zu der vmaddr Rutsch fir d'Bibliothéik ass.
            // Wann et *net* präsent ass, ass d'Symboltabelle relativ zum vmaddr Rutsch plus der uginn Adress vum Segment.
            //
            // Fir dës Situatioun ze handhaben wa mir *keen* Textofschnëtt bei der Dateioffsetzer Null fannen, da erhéije mir de Viraussiicht vun der uginner Adress vun den éischten Textsektiounen a reduzéieren och all uginn Adresse mat deem Betrag.
            //
            // Sou ass d'Symboltabelle ëmmer relativ zu der Viraussetzung vun der Bibliothéik.
            // Dëst schéngt déi richteg Resultater ze hunn fir iwwer d'Symboltabell ze symboliséieren.
            //
            // Éierlech gesot sinn ech net ganz sécher ob dëst richteg ass oder ob et eppes anescht gëtt wat soll uginn wéi een dat maache kann.
            // Fir elo awer dëst schéngt gutt genuch (?) ze schaffen a mir sollten ëmmer fäeg sinn dëst iwwer Zäit z'änneren wann néideg.
            //
            // Fir méi Informatioun kuckt #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Aner Unix (z. B.
        // Linux) Plattforme benotze ELF als Objekt Dateiformat an implementéieren normalerweis eng API genannt `dl_iterate_phdr` fir natierlech Bibliothéiken ze lueden.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` sollten eng valabel Zeigefanger sinn.
        // `vec` sollt e valabelen Zeigefanger op en `std::Vec` sinn.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 ënnerstëtzt net natiirlech Debug Info, awer de Build System plazéiert Debug Info um Wee `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Alles anescht soll ELF benotzen, awer weess net wéi natiirlech Bibliothéiken gelueden ginn.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// All bekannt gemeinsam Bibliothéiken déi gelueden sinn.
    libraries: Vec<Library>,

    /// Mappings Cache wou mir analyséiert Zwerginformatioun behalen.
    ///
    /// Dës Lëscht huet eng fix Kapazitéit fir hir ganz Liftzäit déi ni eropgeet.
    /// D `usize` Element vun all Paar ass en Index an `libraries` uewen, wou `usize::max_value()` déi aktuell ausführbar representéiert.
    ///
    /// Den `Mapping` ass entspriechend analyséiert Zwerginformatioun.
    ///
    /// Bedenkt datt dëst am Fong e LRU Cache ass a mir wäerten d'Saache ronderëm hei verréckele wéi mir Adresse symboliséieren.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Segmenter vun dëser Bibliothéik an d'Erënnerung gelueden, a wou se gelueden sinn.
    segments: Vec<LibrarySegment>,
    /// Den "bias" vun dëser Bibliothéik, normalerweis wou se an d'Gedächtnis gelueden ass.
    /// Dëse Wäert gëtt zu all uginn Adress vun all Segment bäigefüügt fir déi tatsächlech virtuell Memory Adress ze kréien, an déi de Segment gelueden ass.
    /// Zousätzlech gëtt dës Viraussetzung vun echte virtuelle Gedächtnisadressen ofgezunn fir an d'Debuginfo an d'Symboltabelle ze indexéieren.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Déi uginn Adress vun dësem Segment an der Objektdatei.
    /// Dëst ass net wierklech wou de Segment geluede gëtt, awer éischter dës Adress plus déi enthale Bibliothéik `bias` ass wou et ze fannen ass.
    ///
    stated_virtual_memory_address: usize,
    /// D'Gréisst vum ths Segment am Gedächtnis.
    len: usize,
}

// onsécher well dëst erfuerderlech ass fir extern synchroniséiert ze sinn
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // onsécher well dëst erfuerderlech ass fir extern synchroniséiert ze sinn
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // E ganz klengen, ganz einfachen LRU Cache fir Debug Info Mapping.
        //
        // Den Hitrate sollt ganz héich sinn, well den typesche Stack net tëscht ville gemeinsame Bibliothéike kräizt.
        //
        // D `addr2line::Context` Strukturen sinn zimlech teuer ze kreéieren.
        // Seng Käschte sollen erwaart ginn duerch pafolgende `locate` Ufroen amortiséiert ginn, déi d'Strukture benotzen, déi gebaut gi beim Bau vun "addr2line: : Context" fir flott Speedups ze kréien.
        //
        // Wa mir dëse Cache net hätten, géif déi Amortiséierung ni geschéien, a symbolesch Backtraces wieren ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Als éischt, test ob dësen `lib` e Segment huet deen den `addr` enthält (Ëmgank ëmgoen).Wann dëse Scheck passéiert da kënne mir weiderfuere weider an tatsächlech d'Adress iwwersetzen.
                //
                // Bedenkt datt mir `wrapping_add` hei benotze fir Iwwerflusschecken ze vermeiden.Et ass an der Natur gesi ginn datt de SVMA + Bias Berechnung iwwerschwemmt.
                // Et schéngt e bësse komesch dat géif geschéien awer et ass net enorm vill mir kënnen doriwwer maachen anescht wéi wahrscheinlech just dës Segmenter ignoréieren well se wahrscheinlech an de Weltraum weisen.
                //
                // Dëst koum ursprénglech an rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Elo wësse mer datt `lib` `addr` enthält, kënne mir mat der Viraussetzung kompenséiert ginn fir déi uginn virutal Gedächtnis Adress ze fannen.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Invariant: no dësem bedingten Ofschloss ouni fréizäiteg zréckzekommen
        // vun engem Feeler ass de Cache-Entrée fir dëse Wee um Index 0.

        if let Some(idx) = idx {
            // Wann d'Mapping schonn am Cache ass, réckelt se no vir.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Wann d'Mapping net am Cache ass, erstallt eng nei Mapping, setzt se an d'Front vum Cache, an evitéiert déi eelste Cache-Entrée wann néideg.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // leck net d `'static` Liewensdauer, gitt sécher datt et just fir eis selwer geschriwwe gëtt
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Verlängert d'Liewensdauer vun `sym` op `'static` well mir leider hei verlaangt sinn, awer et ass ëmmer als Referenz erausgaang, sou datt keng Referenz doriwwer souwisou sollt bestoe bleiwen.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Endlech kritt eng cache Mapping oder erstallt eng nei Mapping fir dës Datei, a bewäert d'DWARF Info fir den file/line/name fir dës Adress ze fannen.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Mir konnten d'Framinformatioun fir dëst Symbol lokaliséieren, an de "addr2line" säi Frame huet intern all déi graff Detailer.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Konnt d'Debug Informatioun net fannen, awer mir hunn et an der Symboltabelle vum Elf ausführbar fonnt.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}