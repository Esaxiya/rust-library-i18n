//! Symbolikstrategie mam DWARF-Parsingcode am libbacktrace.
//!
//! D'Libbacktrace C Bibliothéik, typesch mat gcc verdeelt, ënnerstëtzt net nëmmen e Backtrace ze generéieren (wat mir net tatsächlech benotzen) awer och symboliséiert de Backtrace an d'Handhabung vun Zwerg Debug Informatioun iwwer Saachen wéi Inline Frames a wat net.
//!
//!
//! Dëst ass relativ komplizéiert wéinst ville verschiddene Bedenken hei, awer d'Basis Iddi ass:
//!
//! * Als éischt nenne mir `backtrace_syminfo`.Dëst kritt Symbolinformatioun vun der dynamescher Symboltabell wa mir kënnen.
//! * Als nächst nenne mir `backtrace_pcinfo`.Dëst analyséiert Debuginfo Dëscher wa se verfügbar sinn an erlaben eis Informatiounen iwwer Inline Frames, Dateinumm, Linnennummeren, etc.
//!
//! Et gi vill Trickerie fir d'Zwerg Dëscher an d'Libbacktrace ze kréien, awer hoffentlech ass et net d'Enn vun der Welt an ass kloer genuch wann Dir hei ënnen liest.
//!
//! Dëst ass d'Standardsymbolikatiounsstrategie fir net MSVC an net OSX Plattformen.An libstd awer dëst ass d'Standardstrategie fir OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Wa méiglech léiwer den `function` Numm deen aus Debuginfo kënnt a kann normalerweis méi korrekt sinn fir Inline Frames zum Beispill.
                // Wann dat net präsent ass, fällt awer zréck op de Symboltabellennumm an `symname`.
                //
                // Bedenkt datt heiansdo `function` kann e bësse manner korrekt fillen, zum Beispill als `try<i32,closure>` opgezielt ass net vun `std::panicking::try::do_call`.
                //
                // Et ass net wierklech kloer firwat, awer insgesamt schéngt den `function` Numm méi korrekt.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // maach elo näischt
}

/// Typ vum `data` Zeiger deen an `syminfo_cb` weidergeleet gëtt
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Wann dëse Réckruff vun `backtrace_syminfo` ugeruff gëtt wa mir ufänken ze léisen, gi mir méi wäit fir `backtrace_pcinfo` ze ruffen.
    // D `backtrace_pcinfo` Funktioun wäert Debug Informatioun konsultéieren a versichen Saachen ze maachen wéi file/line Informatioun ze recuperéieren wéi och inline Frames.
    // Bedenkt awer datt `backtrace_pcinfo` kann ausfalen oder net vill maachen wann et keng Debug Info gëtt, also wann dat geschitt si mir sécher de Réckruff mat mindestens engem Symbol vun der `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Typ vum `data` Zeiger deen an `pcinfo_cb` weidergeleet gëtt
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// D'Libbacktrace API ënnerstëtzt e Staat ze schafen, awer et ënnerstëtzt net e Staat ze zerstéieren.
// Ech perséinlech huelen dat heesche datt e Staat soll geschafe ginn an da fir ëmmer liewen.
//
// Ech wéilt gär en at_exit() Handler registréieren deen dësen Zoustand botzt, awer libbacktrace bitt kee Wee fir dat ze maachen.
//
// Mat dëse Contrainten huet dës Funktioun e statesch tëschegeschachtene Staat deen déi éischte Kéier berechent gëtt déi gefrot gëtt.
//
// Denkt drun datt de Backtracing alles seriell geschitt (eng global Spär).
//
// Notéiert de Manktem u Synchroniséierung hei wéinst der Noutwendegkeet datt `resolve` extern synchroniséiert ass.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Maacht keng Threadsafe Fäegkeete vu libbacktrace aus, well mir nennen et ëmmer synchroniséiert.
        //
        0,
        error_cb,
        ptr::null_mut(), // keng extra Daten
    );

    return STATE;

    // Bedenkt datt fir libbacktrace iwwerhaapt ze bedreiwen et muss d'DWARF Debug Info fir déi aktuell ausführbar fannen.Et mécht dat normalerweis iwwer eng Rei Mechanismen abegraff, awer net limitéiert op:
    //
    // * /proc/self/exe op ënnerstëtzt Plattformen
    // * Den Dateinumm ass explizit weiderginn beim Erstelle vum Staat
    //
    // D'Libbacktrace Bibliothéik ass e grousst Wad vum C Code.Dëst bedeit natierlech datt et Gedächtnis Sécherheet Schwachlëchkeet huet, besonnesch wann Dir falsch geformt Debuginfo behandelt.
    // Libstd ass vill vun dësen historesch gerannt.
    //
    // Wann /proc/self/exe benotzt gëtt da kënne mir dës normalerweis ignoréieren, well mir dovun ausgoen datt libbacktrace "mostly correct" ass a soss net komesch Saachen mat "attempted to be correct" Zwerg Debug Info mécht.
    //
    //
    // Wa mir an engem Dateinumm weiderginn, awer et ass méiglech op e puer Plattformen (wéi BSDs) wou e béisaartege Schauspiller kann eng arbiträr Datei op där Plaz plazéieren.
    // Dëst bedeit datt wa mir libbacktrace iwwer e Dateinumm erzielen, et vläicht eng arbiträr Datei benotzt, méiglecherweis Segfaults verursaacht.
    // Wa mir libbacktrace näischt erzielen awer da wäert et näischt op Plattformen maachen déi Weeër wéi /proc/self/exe net ënnerstëtzen!
    //
    // Gitt alles wat mir sou schwéier wéi méiglech probéieren *net* an engem Dateinumm ze weiderginn, awer mir mussen op Plattformen déi /proc/self/exe guer net ënnerstëtzen.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Bedenkt datt idealerweis mir `std::env::current_exe` benotzen, awer mir kënnen net `std` hei erfuerderen.
            //
            // Benotzt `_NSGetExecutablePath` fir den aktuellen ausféierbaren Wee an e statescht Gebitt ze lueden (wat wann et ze kleng ass einfach opginn).
            //
            //
            // Bedenkt datt mir eescht Libbacktrace hei vertrauen fir net op korrupten Exekutabelen ze stierwen, awer et ass sécher ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows huet e Modus fir Dateien opzemaachen, wou nodeems se opgemaach ginn et net ka geläscht ginn.
            // Dat ass am Allgemenge wat mir hei wëllen, well mir wëlle sécherstellen datt eisen Exekutiv net vun eis aus ännert nodeems mir et op libbacktrace ofginn hunn, hoffentlech d'Fäegkeet ze vermëttelen an arbiträr Daten an Libbacktrace weiderzeginn (wat ka falsch behandelt ginn).
            //
            //
            // Entscheet datt mir hei e bëssen Danz maachen fir ze probéieren eng Aart Spär op eisem eegene Bild ze kréien:
            //
            // * Gitt den aktuellen Prozess an de Grëff, lued säin Dateinumm.
            // * Öffnen eng Datei op dee Dateinumm mat de richtege Fändelen.
            // * Luet den aktuellen Prozess Dateinumm nei, gitt sécher datt et déiselwecht ass
            //
            // Wann dat alles passéiert hu mir an der Theorie wierklech eise Prozessdatei opgemaach a mir si garantéiert datt et net ännert.FWIW e Koup dovu gëtt aus libstd historesch kopéiert, also ass dat meng bescht Interpretatioun vu wat geschitt ass.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Dëst lieft a stateschem Gedächtnis fir datt mir et zréckginn ..
                static mut BUF: [i8; N] = [0; N];
                // ... an dëst lieft um Stack well et temporär ass
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // bewosst `handle` hei erausleeën, well dat opmaache sollt eis Spär op dësem Dateinumm erhalen.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Mir wëllen e Stéck zréckschécken deen Null-Terminéiert ass, also wann alles ausgefëllt war an et ass d'total Längt gläich, dann entsprécht dat dem Versoen.
                //
                //
                // Soss wann Dir Erfolleg zréckgitt, vergewëssert Iech datt den Nul Byte an der Scheif abegraff ass.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // Réckspuerfeeler ginn de Moment ënner den Teppech geschwemmt
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Rufft d `backtrace_syminfo` API un, déi (beim Liese vum Code) `syminfo_cb` genau eemol uruffe soll (oder mat engem Feeler vermeintlech ausfalen).
    // Mir handelen dann méi am `syminfo_cb`.
    //
    // Bedenkt datt mir dat maachen well `syminfo` d'Symboltabelle konsultéiert, Symbolennimm fannen och wann et keng Debug Informatioun am Binär ass.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}