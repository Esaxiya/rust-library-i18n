//! E Modul fir ze hëllefen dbghelp Bindungen op Windows ze managen
//!
//! Backtraces op Windows (op d'mannst fir MSVC) gi gréisstendeels iwwer `dbghelp.dll` an déi verschidde Funktiounen ugedriwwen déi et enthält.
//! Dës Funktioune sinn de Moment *dynamesch* gelueden anstatt statesch mat `dbghelp.dll` ze verknëppelen.
//! Dëst gëtt de Moment vun der Standardbibliothéik gemaach (an ass an der Theorie do erfuerderlech), awer ass en Effort fir d'statesch dll Ofhängegkeete vun enger Bibliothéik ze reduzéieren, well Backtraces normalerweis zimmlech optional sinn.
//!
//! Wann dat gesot gëtt, lued `dbghelp.dll` bal ëmmer erfollegräich op Windows.
//!
//! Bedenkt awer datt well mir all dës Ënnerstëtzung dynamesch lueden, kënne mir net tatsächlech déi rau Definitioune bei `winapi` benotzen, awer mir musse selwer d'Funktiounsweiserentypen definéieren an dat benotzen.
//! Mir wëllen net wierklech am Geschäft sinn fir winapi ze duplizéieren, also hu mir eng Cargo Feature `verify-winapi` déi behaapt datt all Bindungen mat deenen a winapi passen an dës Feature ass op CI aktivéiert.
//!
//! Schlussendlech wäert Dir hei feststellen datt den dll fir `dbghelp.dll` ni erofgelueden ass, an dat ass de Moment absichtlech.
//! D'Iwwerleeung ass datt mir et global cache kënnen an et tëscht Uriff un d'API benotzen, deier loads/unloads vermeiden.
//! Wann dëst e Problem fir Leckdetektoren oder sou ass, kënne mir iwwer d'Bréck goen, wa mir dohinner kommen.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Schafft ronderëm `SymGetOptions` an `SymSetOptions` net präsent am winapi selwer.
// Soss gëtt dëst nëmme benotzt wa mir Zorten duebel iwwer Winapi kontrolléieren.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Nach net am Winapi definéiert
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Dëst ass a winapi definéiert, awer et ass falsch (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Nach net am Winapi definéiert
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Dëse Makro gëtt benotzt fir eng `Dbghelp` Struktur ze definéieren déi intern all d'Funktiounsweiser enthält déi mir kënne lueden.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// De geluedenen DLL fir `dbghelp.dll`
            dll: HMODULE,

            // All Funktiounszeiger fir all Funktioun déi mir benotze kënnen
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Ufanks hu mir d'DLL net gelueden
            dll: 0 as *mut _,
            // Initiall all Funktioune sinn op Null gesat fir ze soen datt se dynamesch geluede musse ginn.
            //
            $($name: 0,)*
        };

        // Convenience typedef fir all Funktiounstyp.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Versich `dbghelp.dll` opzemaachen.
            /// Nees Erfolleg wann et funktionnéiert oder Feeler wann `LoadLibraryW` net klappt.
            ///
            /// Panics wann d'Bibliothéik scho gelueden ass.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Funktioun fir all Method déi mir gär benotze wëllen.
            // Wann opgeruff gëtt et entweder de cache Funktiounszeiger liesen oder lueden an de geluedene Wäert zréckginn.
            // Luede gi behaapt fir Erfolleg ze hunn.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Convenience Proxy fir d'Botzopschloss ze benotzen fir dbghelp Funktiounen ze referenzéieren.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Initialiséiert all néideg Ënnerstëtzung fir Zougang zu `dbghelp` API Funktiounen aus dësem crate ze kréien.
///
///
/// Bedenkt datt dës Funktioun **sécher ass**, et huet intern seng eege Synchroniséierung.
/// Bedenkt och datt et sécher ass dës Funktioun méi oft rekursiv ze nennen.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Dat éischt wat mir musse maachen ass dës Funktioun ze synchroniséieren.Dëst kann gläichzäiteg vun anere Fuedem genannt ginn oder recursiv bannent engem Fuedem.
        // Bedenkt datt et méi komplizéiert ass wéi dat awer well wat mir hei benotzen, `dbghelp`,*och* muss mat all aner Uruff op `dbghelp` an dësem Prozess synchroniséiert ginn.
        //
        // Normalerweis sinn et net wierklech sou vill Uriff op `dbghelp` am selwechte Prozess a mir kënne sécher mat Sécherheet dovun ausgoen datt mir déi eenzeg sinn déi et zougänglech maachen.
        // Et gëtt awer een anere primäre Benotzer dee mir eis Suerge maache wat ironesch selwer ass, awer an der Standardbibliothéik.
        // D'Rust Standardbibliothéik hänkt vun dësem crate of fir Backtrace Support, an dës crate existéiert och op crates.io.
        // Dëst bedeit datt wann d'Standardbibliothéik en panic Backtrace dréckt, da ka se mat dësem crate rennen, deen aus crates.io kënnt a verursaacht Segfaults.
        //
        // Fir dëst Synchroniséierungsprobleem ze léisen, benotze mir e Windows-spezifeschen Trick hei (et ass schliisslech eng Windows-spezifesch Restriktioun iwwer Synchroniséierung).
        // Mir kreéieren eng *Sessioun-lokal* mam Numm Mutex fir dësen Uruff ze schützen.
        // D'Intentioun hei ass datt d'Standardbibliothéik an dës crate keng Rust-Niveau APIe mussen deelen fir hei ze synchroniséieren, awer kënnen amplaz hannert de Kulisse schaffen fir sécher ze sinn datt se matenee synchroniséieren.
        //
        // Dee Wee wann dës Funktioun duerch d'Standardbibliothéik oder duerch crates.io genannt gëtt kënne mir sécher sinn datt déiselwecht Mutex kaaft gëtt.
        //
        // Also alles dat ass ze soen datt dat éischt wat mir hei maachen mir atomesch en `HANDLE` erstellen deen e benannte Mutex op Windows ass.
        // Mir synchroniséieren e bësse mat anere Fuedem déi dës Funktioun speziell deelen a suergen datt nëmmen ee Grëff pro Instanz vun dëser Funktioun erstallt gëtt.
        // Bedenkt datt de Grëff ni zou ass wann et global gespäichert ass.
        //
        // Nodeems mir d'Spär tatsächlech gemaach hunn, kréien mir et einfach, an eisen `Init` Grëff, deen mir ausdeelen, wäert verantwortlech sinn fir se eventuell ze falen.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, phew!Elo wou mir all sécher synchroniséiert sinn, lass eis alles ufänken ze verarbeiten.
        // Als éischt musse mir sécher sinn datt `dbghelp.dll` tatsächlech an dësem Prozess gelueden ass.
        // Mir maachen dat dynamesch fir eng statesch Ofhängegkeet ze vermeiden.
        // Dëst gouf historesch gemaach fir komesch Verknëppungsprobleemer ze schaffen an ass geduecht fir Binarien e bësse méi portabel ze maachen, well dëst gréisstendeels just en Debuggen Utility ass.
        //
        //
        // Wann mir `dbghelp.dll` opgemaach hunn, musse mir e puer Initialiséierungsfunktiounen dran nennen, an dat ass méi detailléiert detailléiert.
        // Mir maachen dat nëmmen eemol, awer, also hu mir e globalen Boolschen, dee weist ob mir nach fäerdeg sinn oder net.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Gitt sécher datt den `SYMOPT_DEFERRED_LOADS` Fändel gesat ass, well no den MSVC eegene Dokumenter iwwer dëst: "This is the fastest, most efficient way to use the symbol handler.", also loosst eis dat maachen!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Initialiséiert eigentlech Symboler mat MSVC.Bedenkt datt dëst ka faalen, awer mir ignoréieren et.
        // Et ass net eng Tonn vun der fréierer Konscht fir dëst per se, awer LLVM intern schéngt de Retourwäert hei ze ignoréieren an eng vun de Sanitizerbibliothéiken an LLVM dréckt eng grujeleg Warnung wann dëst ausfält awer am Fong ignoréiert et op laang Dauer.
        //
        //
        // Ee Fall dëst kënnt vill fir Rust op ass datt d'Standardbibliothéik an dës crate op crates.io béid fir `SymInitializeW` konkurréiere wëllen.
        // D'Standardbibliothéik wollt historesch duerno d'Ursaache meeschtens initialiséieren, awer elo, datt se dësen crate benotzt, heescht et, datt een als éischt un d'Initialiséierung kënnt an deen aneren dës Initialiséierung ophëlt.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}