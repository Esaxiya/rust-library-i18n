use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Representatioun vun engem Besëtz a selbststännegem Réckwee.
///
/// Dës Struktur kann benotzt ginn fir e Réckbléck op verschidde Punkte vun engem Programm ze fänken a spéider benotzt fir ze kontrolléieren wat de Réckwee zu där Zäit war.
///
///
/// `Backtrace` ënnerstëtzt zimmlech Drock vu Backtraces duerch seng `Debug` Implementatioun.
///
/// # Néideg Features
///
/// Dës Funktioun erfuerdert d `std` Feature vum `backtrace` crate fir aktivéiert ze sinn, an d `std` Feature ass standard aktivéiert.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Rummen hei sinn vun uewen no ënnen um Stack opgezielt
    frames: Vec<BacktraceFrame>,
    // Den Index dee mir gleewen ass den aktuellen Ufank vum Backtrace, ouni Frames wéi `Backtrace::new` an `backtrace::trace` auszeleeën.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Gefaangene Versioun vun engem Frame an engem Backtrace.
///
/// Dësen Typ gëtt als Lëscht vun `Backtrace::frames` zréckkomm a stellt e Stackframe an engem agefaangene Réckwee duer.
///
/// # Néideg Features
///
/// Dës Funktioun erfuerdert d `std` Feature vum `backtrace` crate fir aktivéiert ze sinn, an d `std` Feature ass standard aktivéiert.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Gefaangene Versioun vun engem Symbol an engem Réckwee.
///
/// Dësen Typ gëtt als Lëscht vun `BacktraceFrame::symbols` zréckkomm a stellt d'Metadate fir e Symbol an engem Réckwee duer.
///
/// # Néideg Features
///
/// Dës Funktioun erfuerdert d `std` Feature vum `backtrace` crate fir aktivéiert ze sinn, an d `std` Feature ass standard aktivéiert.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Trefft e Réckwee op der Callsite vun dëser Funktioun, zréck an eng Besëtz Representatioun.
    ///
    /// Dës Funktioun ass nëtzlech fir e Backtrace als Objet am Rust duerzestellen.Dëse zréckgezunnene Wäert kann iwwer Fiedem geschéckt a soss anzwousch gedréckt ginn, an den Zweck vun dësem Wäert ass ganz selwer enthale ze sinn.
    ///
    /// Bedenkt datt op e puer Plattformen e komplette Backtrace kréien an ze léisen et extrem deier ka sinn.
    /// Wann d'Käschte fir Är Uwendung zevill ass, ass et recommandéiert amplaz `Backtrace::new_unresolved()` ze benotzen déi de Symbolopléisungsschrëtt vermeit (deen normalerweis dee längsten dauert) an et erlaabt et op e spéideren Datum ze verleeën.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Néideg Features
    ///
    /// Dës Funktioun erfuerdert d `std` Feature vum `backtrace` crate fir aktivéiert ze sinn, an d `std` Feature ass standard aktivéiert.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // wëllt sécher sinn, datt hei e Frame ass, fir ewechzehuelen
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Ähnlech wéi `new` ausser datt dëst keng Symboler opléist, erfaasst dëst einfach de Réckwee als eng Lëscht vun Adressen.
    ///
    /// Zu engem spéideren Zäitpunkt kann d `resolve` Funktioun geruff ginn fir dës Backtrace Symboler a liesbar Nimm ze léisen.
    /// Dës Funktioun existéiert well de Resolutiounsprozess heiansdo e wesentleche Betrag vun Zäit kann huelen wärend all Réckstreck nëmme selten gedréckt ka ginn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // keng Symbolnimm
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // Symbol Nimm elo präsent
    /// ```
    ///
    /// # Néideg Features
    ///
    /// Dës Funktioun erfuerdert d `std` Feature vum `backtrace` crate fir aktivéiert ze sinn, an d `std` Feature ass standard aktivéiert.
    ///
    ///
    ///
    #[inline(never)] // wëllt sécher sinn, datt hei e Frame ass, fir ewechzehuelen
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Retourneiert d'Frames vu wou dës Backtrace ageholl gouf.
    ///
    /// Déi éischt Entrée vun dësem Slice ass méiglecherweis d'Funktioun `Backtrace::new`, an de leschte Frame ass méiglecherweis eppes wéi dëse Fuedem oder d'Haaptfunktioun ugefaang huet.
    ///
    ///
    /// # Néideg Features
    ///
    /// Dës Funktioun erfuerdert d `std` Feature vum `backtrace` crate fir aktivéiert ze sinn, an d `std` Feature ass standard aktivéiert.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Wann dës Backtrace aus `new_unresolved` erstallt gouf, da léisst dës Funktioun all Adressen am Backtrace op hir symbolesch Nimm.
    ///
    ///
    /// Wann dës Backtrace virdru geléist gouf oder duerch `new` erstallt gouf, mécht dës Funktioun näischt.
    ///
    /// # Néideg Features
    ///
    /// Dës Funktioun erfuerdert d `std` Feature vum `backtrace` crate fir aktivéiert ze sinn, an d `std` Feature ass standard aktivéiert.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Selwecht wéi `Frame::ip`
    ///
    /// # Néideg Features
    ///
    /// Dës Funktioun erfuerdert d `std` Feature vum `backtrace` crate fir aktivéiert ze sinn, an d `std` Feature ass standard aktivéiert.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Selwecht wéi `Frame::symbol_address`
    ///
    /// # Néideg Features
    ///
    /// Dës Funktioun erfuerdert d `std` Feature vum `backtrace` crate fir aktivéiert ze sinn, an d `std` Feature ass standard aktivéiert.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Selwecht wéi `Frame::module_base_address`
    ///
    /// # Néideg Features
    ///
    /// Dës Funktioun erfuerdert d `std` Feature vum `backtrace` crate fir aktivéiert ze sinn, an d `std` Feature ass standard aktivéiert.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Gitt d'Lëscht vun de Symboler zréck, déi dëse Frame entsprécht.
    ///
    /// Normalerweis gëtt et nëmmen ee Symbol pro Frame, awer heiansdo wann eng Zuel vu Funktiounen an ee Frame gezeechent sinn da gi méi Symboler zréck.
    /// Dat éischt opgezielt Symbol ass den "innermost function", wärend dat lescht Symbol dee baussenzegen ass (leschten Uruffer).
    ///
    /// Bedenkt datt wann dëse Frame aus engem ongeléiste Backtrace kënnt, da gëtt dëst eng eidel Lëscht zréck.
    ///
    /// # Néideg Features
    ///
    /// Dës Funktioun erfuerdert d `std` Feature vum `backtrace` crate fir aktivéiert ze sinn, an d `std` Feature ass standard aktivéiert.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Selwecht wéi `Symbol::name`
    ///
    /// # Néideg Features
    ///
    /// Dës Funktioun erfuerdert d `std` Feature vum `backtrace` crate fir aktivéiert ze sinn, an d `std` Feature ass standard aktivéiert.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Selwecht wéi `Symbol::addr`
    ///
    /// # Néideg Features
    ///
    /// Dës Funktioun erfuerdert d `std` Feature vum `backtrace` crate fir aktivéiert ze sinn, an d `std` Feature ass standard aktivéiert.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Selwecht wéi `Symbol::filename`
    ///
    /// # Néideg Features
    ///
    /// Dës Funktioun erfuerdert d `std` Feature vum `backtrace` crate fir aktivéiert ze sinn, an d `std` Feature ass standard aktivéiert.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Selwecht wéi `Symbol::lineno`
    ///
    /// # Néideg Features
    ///
    /// Dës Funktioun erfuerdert d `std` Feature vum `backtrace` crate fir aktivéiert ze sinn, an d `std` Feature ass standard aktivéiert.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Selwecht wéi `Symbol::colno`
    ///
    /// # Néideg Features
    ///
    /// Dës Funktioun erfuerdert d `std` Feature vum `backtrace` crate fir aktivéiert ze sinn, an d `std` Feature ass standard aktivéiert.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Beim Drécken vu Weeër probéiere mir de cwd ze sträifen wann et existéiert, soss drécke mir de Wee just esou wéi et ass.
        // Bedenkt datt mir dëst och nëmme fir de kuerze Format maachen, well wann et voll ass wëlle mir vermeintlech alles drécken.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}