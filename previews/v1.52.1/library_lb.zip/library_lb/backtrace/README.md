# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Eng Bibliothéik fir Backtraces beim Runtime fir Rust ze kréien.
Dës Bibliothéik soll d'Ënnerstëtzung vun der Standardbibliothéik verbesseren andeems en eng programmatesch Interface ubitt fir ze schaffen, awer et ënnerstëtzt och einfach den aktuellen Backtrace ze drécken wéi libstd's panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Fir einfach e Réckwee ze fänken an ofzeginn mat deem bis zu engem spéideren Zäitpunkt, kënnt Dir den Top-Level `Backtrace` Typ benotzen.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Wann Dir awer méi roude Zougang zu der aktueller Tracefunktionalitéit wëllt hutt, kënnt Dir d `trace` an d `resolve` Funktiounen direkt benotzen.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Léist dësen Instruktiounszeiger op e Symbolnumm
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // weider am nächste Frame
    });
}
```

# License

Dëse Projet ass lizenzéiert ënner engem vun

 * Apache Lizenz, Versioun 2.0, ([LICENSE-APACHE](LICENSE-APACHE) oder http://www.apache.org/licenses/LICENSE-2.0)
 * MIT Lizenz ([LICENSE-MIT](LICENSE-MIT) oder http://opensource.org/licenses/MIT)

op Är Optioun.

### Contribution

Ausser Dir explizit anescht uginn, gëtt all Bäitrag absichtlech fir an Backtrace-rs vun Iech ageleet, wéi definéiert an der Apache-2.0 Lizenz, duebel lizenzéiert wéi uewen, ouni zousätzlech Bedéngungen oder Bedéngungen.







