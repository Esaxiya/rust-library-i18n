use backtrace::Backtrace;

// Dësen Test funktionnéiert nëmmen op Plattformen déi eng funktionéierend `symbol_address` Funktioun fir Frames hunn déi d'Startadress vun engem Symbol bericht.
// Als Resultat ass et nëmmen op e puer Plattformen aktivéiert.
//
const ENABLED: bool = cfg!(all(
    // Windows ass net wierklech gepréift ginn, an OSX ënnerstëtzt net tatsächlech en enge Rumm ze fannen, also deaktivéiert dëst
    //
    target_os = "linux",
    // Beim ARM fanne vun der Ofschlossfunktioun ass einfach d'IP selwer zréck.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}