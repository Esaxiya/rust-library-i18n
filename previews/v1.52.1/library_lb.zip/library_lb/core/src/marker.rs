//! Primitiv traits an Typen déi Basis Eegeschafte vun Typen duerstellen.
//!
//! Rust Typen kënnen op verschidde nëtzlech Weeër klasséiert ginn no hiren intrinsesche Properties.
//! Dës Klassifikatiounen sinn als traits duergestallt.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Typen déi iwwer Thread Grenze transferéiert kënne ginn.
///
/// Dësen trait gëtt automatesch implementéiert wann de Compiler bestëmmt datt et ubruecht ass.
///
/// E Beispill vun engem net-"Schécken" Typ ass de Referenzzieler Zeiger [`rc::Rc`][`Rc`].
/// Wann zwee Threads probéieren [[Rc`] ze klonen déi op dee selwechte Referenz gezielt Wäert weisen, da kënne se probéieren d'Referenzzuel zur selwechter Zäit ze aktualiséieren, wat [undefined behavior][ub] ass well [`Rc`] keng atomesch Operatiounen benotzt.
///
/// Säi Koseng [`sync::Arc`][arc] benotzt atomesch Operatiounen (entsteet e puer Overhead) an ass also `Send`.
///
/// Kuckt [the Nomicon](../../nomicon/send-and-sync.html) fir méi Detailer.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Typen mat enger konstanter Gréisst bekannt an der Kompiléierzäit.
///
/// All Typparameter hunn eng implizit Grenz vun `Sized`.Déi speziell Syntax `?Sized` kann benotzt ginn fir dës Bound ewechzehuelen wann et net ubruecht ass.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//Feeler: Gréisst ass net fir [i32] implementéiert
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Déi eenzeg Ausnahm ass den impliziten `Self` Typ vun engem trait.
/// En trait huet keen impliziten `Sized` gebonnen, well dëst ass net kompatibel mat [trait Objet], wou, no Definitioun, den trait mat all méiglechen Implementateure schaffe muss, an domat all Gréisst ka sinn.
///
///
/// Och wa Rust Iech erlaabt `Sized` un en trait ze bannen, kënnt Dir et net méi spéit benotze fir en trait Objet ze bilden:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // loosst y: &dyn Bar= &Impl;//Feeler: den trait `Bar` kann net zu engem Objet gemaach ginn
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // fir Standard, zum Beispill, wat erfuerdert datt `[T]: !Default` bewäertbar ass
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Typen déi "unsized" zu engem dynamesche Gréisst Typ kënne sinn.
///
/// Zum Beispill implementéiert de groussen Arraytyp `[i8; 2]` `Unsize<[i8]>` an `Unsize<dyn fmt::Debug>`.
///
/// All Implementatioune vum `Unsize` ginn automatesch vum Compiler zur Verfügung gestallt.
///
/// `Unsize` gëtt ëmgesat fir:
///
/// - `[T; N]` ass `Unsize<[T]>`
/// - `T` ass `Unsize<dyn Trait>` wann `T: Trait`
/// - `Foo<..., T, ...>` ass `Unsize<Foo<..., U, ...>>` wann:
///   - `T: Unsize<U>`
///   - Foo ass e struct
///   - Nëmmen dat lescht Feld vun `Foo` huet en Typ mat `T`
///   - `T` ass net Deel vun der Aart vun anere Felder
///   - `Bar<T>: Unsize<Bar<U>>`, wann dat lescht Feld vun `Foo` den Typ `Bar<T>` huet
///
/// `Unsize` gëtt zesumme mat [`ops::CoerceUnsized`] benotzt fir "user-defined" Container wéi [`Rc`] dynamesch grouss Zorten ze enthalen.
/// Kuckt d [DST coercion RFC][RFC982] an d [the nomicon entry on coercion][nomicon-coerce] fir méi Detailer.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Néideg trait fir Konstante benotzt a Muster Matcher.
///
/// All Typ deen `PartialEq` ofleeft implementéiert dësen trait automatesch,*egal* ob seng Typparameter `Eq` implementéieren.
///
/// Wann en `const` Element en Typ enthält deen dësen trait net implementéiert, da gëtt deen Typ entweder (1.) net `PartialEq` implementéiert (dat heescht datt de Konstant net déi Verglachsmethod gëtt, wéi eng Code Generatioun dovun ausgeet datt se verfügbar ass), oder (2.) implementéiert se *seng eege* Versioun vum `PartialEq` (déi mir dovun ausgoen, entsprécht net engem strukturelle Gläichheetsverglach).
///
///
/// An enger vun den zwou Szenarien hei uewe refuséiere mir d'Benotzung vun esou enger Konstante an engem Mustermatch.
///
/// Kuckt och d [structural match RFC][RFC1445], an d [issue 63438] déi motivéiert wanderen aus attributbaséiertem Design zu dësem trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Néideg trait fir Konstante benotzt a Muster Matcher.
///
/// All Typ deen `Eq` ofleeft implementéiert dësen trait automatesch,*egal* ob seng Typparameter `Eq` implementéieren.
///
/// Dëst ass en Hack fir eng Begrenzung an eisem Typ System ze schaffen.
///
/// # Background
///
/// Mir wëllen verlaangen datt Aarte vu Konsts déi a Muster Matcher benotzt ginn den Attribut `#[derive(PartialEq, Eq)]` hunn.
///
/// An enger méi idealer Welt kéinte mir dës Ufuerderung kontrolléieren andeems mir just kontrolléieren datt de gegebene Typ den `StructuralPartialEq` trait *an* den `Eq` trait implementéiert.
/// Wéi och ëmmer, Dir kënnt ADTs hunn déi *maachen*`derive(PartialEq, Eq)`, an e Fall sinn datt mir de Compiler akzeptéiere wëllen, an awer de konstante Typ net implementéiert `Eq`.
///
/// Nämlech e Fall esou:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (De Problem am uewe genannte Code ass datt `Wrap<fn(&())>` net `PartialEq` implementéiert, nach `Eq`, well "fir <" a> fn(&'a _)` does not implement those traits.)
///
/// Dofir kënne mir net op naiv Kontroll fir `StructuralPartialEq` a just `Eq` vertrauen.
///
/// Als Hack fir ronderëm dëst ze schaffen, benotze mir zwee getrennte traits, déi vun all deenen zwee ofgeleet (`#[derive(PartialEq)]` an `#[derive(Eq)]`) injizéiert ginn a kontrolléieren datt béid präsent sinn als Deel vum strukturelle Match Kontroll.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Typen deenen hir Wäerter kënnen einfach kopéiert ginn andeems se Bits kopéieren.
///
/// Par défaut hu verännerlech Bindungen 'Semantik bewegen.'An anere Wierder:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` ass an `y` geréckelt, a kann also net benotzt ginn
///
/// // println! ("{: ?}", x);//Feeler: Benotze vum geréckte Wäert
/// ```
///
/// Wéi och ëmmer, wann en Typ `Copy` implementéiert, huet en amplaz 'Kopie Semantik':
///
/// ```
/// // Mir kënnen eng `Copy`-Implementatioun ofleeden.
/// // `Clone` ass och erfuerderlech, well et ass e Supertrait vun `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` ass eng Kopie vun `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Et ass wichteg ze bemierken datt an dësen zwee Beispiller deen eenzegen Ënnerscheed ass ob Dir Zougang zu `x` no der Aufgab hutt.
/// Ënnert der Kapuze kënnen eng Kopie an eng Beweegung dozou féieren datt Bits an Erënnerung kopéiert ginn, och wann dat heiansdo optimiséiert gëtt.
///
/// ## Wéi kann ech `Copy` implementéieren?
///
/// Et ginn zwou Méiglechkeeten fir `Copy` op Ärem Typ ëmzesetzen.Déi einfachst ass `derive` ze benotzen:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Dir kënnt och `Copy` an `Clone` manuell implementéieren:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Et ass e klengen Ënnerscheed tëscht deenen zwee: D `derive` Strategie plazéiert och en `Copy` gebonne mat Typparameteren, wat net ëmmer gewënscht ass.
///
/// ## Wat ass den Ënnerscheed tëscht `Copy` an `Clone`?
///
/// Kopie geschéien implizit, zum Beispill als Deel vun enger Aufgab `y = x`.D'Verhalen vum `Copy` ass net iwwerluedbar;et ass ëmmer eng einfach bëssen-schlau Kopie.
///
/// Klonen ass eng explizit Aktioun, `x.clone()`.D'Ëmsetzung vun [`Clone`] kann all typsspezifescht Verhalen noutwenneg fir Wäerter sécher ze duplizéieren.
/// Zum Beispill, d'Ëmsetzung vun [`Clone`] fir [`String`] muss de point-to-string-Puffer am Koup kopéieren.
/// Eng einfach bitwise Kopie vun [`String`] Wäerter géif just de Zeiger kopéieren, wat zu enger Duebelfreiheet vun der Linn féiert.
/// Aus dësem Grond ass [`String`] [`Clone`] awer net `Copy`.
///
/// [`Clone`] ass en Supertrait vun `Copy`, also alles wat `Copy` ass, muss och [`Clone`] implementéieren.
/// Wann en Typ `Copy` ass, da muss seng [`Clone`]-Implementéierung nëmmen `*self` zréckbréngen (kuckt d'Beispill uewen).
///
/// ## Wéini kann mäin Typ `Copy` sinn?
///
/// En Typ kann `Copy` implementéieren wann all seng Komponenten `Copy` implementéieren.Zum Beispill kann dëse Struct `Copy` sinn:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// E Struct kann `Copy` sinn, an [`i32`] ass `Copy`, dofir ass `Point` berechtegt `Copy` ze sinn.
/// Am Kontrast, betruecht
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// De Struct `PointList` kann net `Copy` implementéieren, well [`Vec<T>`] net `Copy` ass.Wa mir versichen eng `Copy`-Implementatioun ze kréien, kréie mir e Feeler:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Gedeelt Referenzen (`&T`) sinn och `Copy`, sou datt en Typ `Copy` ka sinn, och wann et gedeelt Referenze vun den Typen `T` hält déi *net*`Copy` sinn.
/// Betruecht de folgende Struktur, deen `Copy` implementéiere kann, well et nëmmen e *Shared Referenz* op eisen Net-"Copy" Typ `PointList` vun uewen hält:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Wéini *kann* net mäi Typ `Copy` sinn?
///
/// E puer Typen kënnen net sécher kopéiert ginn.Zum Beispill, `&mut T` kopéieren hätt eng aliéiert mutabel Referenz.
/// [`String`] kopéieren géif d'Verantwortung duplizéieren fir de ["String"] Puffer ze managen, wat zu engem Duebelfräiheet féiert.
///
/// Generaliséiere vum leschte Fall, all Typ, deen [`Drop`] implementéiert, kann net `Copy` sinn, well et e puer Ressource niewent hiren eegene [`size_of::<T>`] Bytes verwalt.
///
/// Wann Dir probéiert `Copy` op e struct oder enum z'implementéieren deen net "Kopie" Daten enthält, kritt Dir de Feeler [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Wéini *soll* mäin Typ `Copy` sinn?
///
/// Allgemeng, wann Ären Typ _can_ `Copy` implementéiert, sollt et sinn.
/// Denkt awer drun datt d'Ëmsetzung vun `Copy` Deel vun der ëffentlecher API vun Ärem Typ ass.
/// Wann den Typ net "Kopie" am future kéint ginn, kéint et virsiichteg sinn d `Copy`-Implementatioun elo ewech ze loossen, fir e brechende API-Changement ze vermeiden.
///
/// ## Zousätzlech Implementateuren
///
/// Nieft dem [implementors listed below][impls] implementéiere folgend Zorten och `Copy`:
///
/// * Funktiounsartypen (dh déi ënnerschiddlech Aarte fir all Funktioun definéiert)
/// * Funktioun Zeigentypen (z. B. `fn() -> i32`)
/// * Arraytypen, fir all Gréissten, wann den Artikelart och `Copy` implementéiert (z. B. `[i32; 123456]`)
/// * Tupeltypen, wann all Komponent och `Copy` implementéiert (z. B. `()`, `(i32, bool)`)
/// * Ofschlossaarten, wa se kee Wäert aus der Ëmwelt fänken oder wann all sou agefaangene Wäerter `Copy` selwer implementéieren.
///   Bedenkt datt Variablen déi duerch gemeinsame Referenz erfaasst ginn ëmmer `Copy` implementéieren (och wann de Referent net), wärend Variabelen déi duerch mutabel Referenz erfaasst ginn ni `Copy` implementéieren.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Dëst erlaabt en Typ ze kopéieren deen net `Copy` implementéiert wéinst onzefridden Liewensdauer Grenzen (Kopie `A<'_>` wann nëmmen `A<'static>: Copy` an `A<'_>: Clone`).
// Mir hunn dëst Attribut hei elo just well et e puer existent Spezialiséierungen op `Copy` sinn déi et schonn an der Standardbibliothéik gëtt, an et ass kee Wee fir dëst Verhalen elo sécher ze hunn.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Ofleeft Makro generéiert en Impl vun der trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Typen fir déi et sécher ass Referenzen tëscht Themen ze deelen.
///
/// Dësen trait gëtt automatesch implementéiert wann de Compiler bestëmmt datt et ubruecht ass.
///
/// Déi präzis Definitioun ass: en Typ `T` ass [`Sync`] wann an nëmmen wann `&T` [`Send`] ass.
/// An anere Wierder, wann et keng Méiglechkeet vu [undefined behavior][ub] gëtt (och Datenrennen) wann Dir `&T` Referenzen tëscht Fiedem weidergitt.
///
/// Wéi ee kéint erwaarden, primitiv Aarte wéi [`u8`] an [`f64`] sinn all [`Sync`], an och einfach Aggregatentypen déi se enthalen, wéi Tuppen, Strucken an Enums.
/// Méi Beispiller vu Basis [`Sync`] Typen enthalen "immutable" Typen wéi `&T`, an déi mat einfacher ierflecher Verännerlechkeet, wéi [`Box<T>`][box], [`Vec<T>`][vec] an déi meescht aner Sammlungstypen.
///
/// (Allgemeng Parameter mussen [`Sync`] sinn fir datt hire Container ["Sync"] ass.)
///
/// Eng e bëssen iwwerraschend Konsequenz vun der Definitioun ass datt `&mut T` `Sync` ass (wann `T` `Sync` ass) och wann et schéngt datt et onsynchroniséiert Mutatioun kéint ginn.
/// Den Trick ass datt eng mutéierbar Referenz hannert enger gemeinsamer Referenz (dat heescht `& &mut T`) nëmme gelies gëtt, wéi wann et en `& &T` wier.
/// Dofir gëtt et kee Risiko vun enger Datenrace.
///
/// Typen déi net `Sync` sinn, sinn déi déi "interior mutability" an enger net thread-sécherer Form hunn, wéi [`Cell`][cell] an [`RefCell`][refcell].
/// Dës Aarte erlaben Mutatioun vun hirem Inhalt och duerch eng onverännerbar, gemeinsam Referenz.
/// Zum Beispill d `set` Method op [`Cell<T>`][cell] hëlt `&self`, sou datt et nëmmen e gemeinsame Referenz [`&Cell<T>`][cell] erfuerdert.
/// D'Methode féiert keng Synchroniséierung, sou datt [`Cell`][cell] net `Sync` ka sinn.
///
/// En anert Beispill vun engem net-"Sync" Typ ass de Referenzzieler Zeiger [`Rc`][rc].
/// Gitt all Referenz [`&Rc<T>`][rc], Dir kënnt en neien [`Rc<T>`][rc] klonen, andeems Dir d'Referenzzuelen op net atomarer Manéier ännert.
///
/// Fir Fäll wou een thread-séchere Bannemutabilitéit brauch, bitt Rust [atomic data types], souwéi explizit Sperren iwwer [`sync::Mutex`][mutex] an [`sync::RwLock`][rwlock].
/// Dës Aarte suergen dofir datt keng Mutatioun keng Datecourse verursaache kann, dofir sinn d'Typen `Sync`.
/// Och [`sync::Arc`][arc] bitt e thread-safe Analog vun [`Rc`][rc].
///
/// All Typen mat Interieurmutabilitéit mussen och den [`cell::UnsafeCell`][unsafecell] Wrapper ronderëm den value(s) benotzen, deen duerch eng gemeinsam Referenz mutéiert ka ginn.
/// Echec dëst net ze maachen ass [undefined behavior][ub].
/// Zum Beispill ass [`transmute`][transmute]-ing vun `&T` op `&mut T` ongëlteg.
///
/// Kuckt [the Nomicon][nomicon-send-and-sync] fir méi Detailer iwwer `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): eemol Ënnerstëtzung fir Notizen an `rustc_on_unimplemented` ze addéieren lant a Beta, an et gouf verlängert fir ze kontrolléieren ob eng Zoumaache iergendwou an der Ufuerderungskette ass, verlängert se als sou (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Nullgréissten Typ benotzt fir Saachen ze markéieren déi "act like" si hunn en `T`.
///
/// Wann Dir e `PhantomData<T>` Feld op Äert Typ füügt, erzielt de Compiler datt Ären Typ handelt wéi wann et e Wäert vum Typ `T` späichert, och wann et net wierklech ass.
/// Dës Informatioun gëtt benotzt wann Dir verschidde Sécherheetseegeschafte berechent.
///
/// Fir eng méi detailléiert Erklärung wéi Dir `PhantomData<T>` benotzt, kuckt [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Eng schrecklech Notiz 👻👻👻
///
/// Och wa se allen beängschteg Nimm hunn, sinn `PhantomData` a 'Phantomtypen' verbonnen, awer net identesch.E Phantomtyp Parameter ass einfach en Typ Parameter deen ni benotzt gëtt.
/// Am Rust verursaacht dëst dacks de Compiler ze kloen, an d'Léisung ass en "dummy" Gebrauch iwwer de Wee vun `PhantomData` derbäizefügen.
///
/// # Examples
///
/// ## Onbenotzt Liewensdauer Parameteren
///
/// Vläicht am meeschte verbreet Benotzungsfall fir `PhantomData` ass e Struktur deen en net benotzte Liewensdauer Parameter huet, typesch als Deel vun engem onséchere Code.
/// Zum Beispill, hei ass e struct `Slice` deen zwee Zeigefanger vum Typ `*const T` huet, déi vermutlech an engem Array anzwousch hindeit:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// D'Intentioun ass datt d'Basisdaten nëmme fir de Liewensdauer `'a` valabel sinn, sou datt `Slice` net `'a` sollt iwwerliewen.
/// Dës Intent gëtt awer net am Code ausgedréckt, well et gi keng Uwendunge vum `'a` Liewensdauer an dofir ass et net kloer op wéi eng Daten et zielt.
/// Mir kënnen dëst korrigéieren andeems de Compiler seet *ze handelen* wéi wann * den `Slice` struct eng Referenz `&'a T` enthält:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Dëst erfuerdert och d'Annotatioun `T: 'a`, wat uginn datt all Referenzen am `T` gëlteg sinn iwwer de Liewensdauer `'a`.
///
/// Wann Dir en `Slice` initialiséiert hutt, gitt Dir einfach de Wäert `PhantomData` fir d'Feld `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Net benotzt Typ Parameteren
///
/// Et geschitt heiansdo datt Dir net benotzte Typparameter hutt déi uginn zu wéi engem Typ vun Daten e Struct "tied" ass, och wann dës Daten net wierklech am Struct selwer fonnt ginn.
/// Hei ass e Beispill wou dëst mat [FFI] entsteet.
/// Déi auslännesch Interface benotzt Grëff vum Typ `*mut ()` fir Rust Wäerter vu verschiddenen Typen ze bezeechnen.
/// Mir verfollegen den Rust Typ mat engem Phantomtyp Parameter um Struct `ExternalResource` deen e Grëff wéckelt.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Besëtzer an den Dropcheck
///
/// Wann Dir e Feld vum Typ `PhantomData<T>` bäifüügt, weist datt Ären Typ Daten vum Typ `T` besëtzt.Dëst bedeit erëm datt wann Ären Typ fällt, kann et een oder méi Instanzen vum Typ `T` falen.
/// Dëst huet Afloss op den Rust Compiler [drop check] Analyse.
///
/// Wann Äre Struct net d'Date vum Typ `T`*besëtzt*, ass et besser e Referenztyp ze benotzen, wéi `PhantomData<&'a T>` (ideally) oder `PhantomData<*const T>` (wa keng Liewensdauer zoutrëfft), fir net Proprietéit unzeginn.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Compiler-intern trait benotzt fir den Typ vun Enum Diskriminanten unzeginn.
///
/// Dësen trait gëtt automatesch fir all Typ implementéiert an huet keng Garantien op [`mem::Discriminant`] derbäi.
/// Et ass **ondefinéiert Verhalen** fir tëscht `DiscriminantKind::Discriminant` an `mem::Discriminant` ze transmutéieren.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Déi Zort vum Diskriminéierter, deen den trait bounds erfuerderlech vun `mem::Discriminant` erfëllen muss.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Compiler-intern trait benotzt fir ze bestëmmen ob en Typ en `UnsafeCell` intern enthält, awer net duerch eng Indirektioun.
///
/// Dëst beaflosst, zum Beispill, ob en `static` vun deem Typ an de read-only statesche Gedächtnis oder schrëftlecher statescher Erënnerung gesat gëtt.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Typen déi sécher kënne geréckelt ginn nodeems se gespaart sinn.
///
/// Rust selwer huet keng Notioun vun onbeweeglechen Typen a betruecht Bewegungen (z. B. duerch Aufgab oder [`mem::replace`]) fir ëmmer sécher.
///
/// Den [`Pin`][Pin] Typ gëtt amplaz benotzt fir Bewegungen duerch den Typ System ze vermeiden.Zeigefanger `P<T>` an der [`Pin<P<T>>`][Pin] Wrapper gewéckelt kënnen net aus geréckelt ginn.
/// Kuckt d [`pin` module] Dokumentatioun fir méi Informatioun iwwer Pinning.
///
/// D'Ëmsetzung vum `Unpin` trait fir `T` hëlt d'Restriktiounen vum Spëntchen vum Typ, wat et erlaabt `T` aus [`Pin<P<T>>`][Pin] mat Funktiounen wéi [`mem::replace`] ze réckelen.
///
///
/// `Unpin` huet iwwerhaapt keng Konsequenz fir net gespéngten Daten.
/// Besonnesch [`mem::replace`] bewegt glécklech `!Unpin` Daten (et funktionnéiert fir all `&mut T`, net nëmme wann `T: Unpin`).
/// Dir kënnt awer net [`mem::replace`] op Date benotzen, déi an engem [`Pin<P<T>>`][Pin] gewéckelt sinn, well Dir kënnt net den `&mut T` kréien, deen Dir dofir braucht, an *dat* ass wat dëse System funktionnéiert.
///
/// Also dëst, zum Beispill, kann nëmme gemaach ginn op Typen déi `Unpin` implementéieren:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Mir brauchen eng mutéierbar Referenz fir `mem::replace` ze nennen.
/// // Mir kënnen esou eng Referenz kréien andeems mir (implicitly) op `Pin::deref_mut` beruffen, awer dat ass nëmme méiglech well `String` `Unpin` implementéiert.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Dësen trait gëtt automatesch fir bal all Typ implementéiert.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// E Markéierertyp deen net `Unpin` implementéiert.
///
/// Wann en Typ en `PhantomPinned` enthält, gëtt en net als Standard `Unpin` implementéiert.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Implementatiounen vum `Copy` fir primitiv Typen.
///
/// Implementatiounen déi net am Rust beschriwwe kënne ginn an `traits::SelectionContext::copy_clone_conditions()` an `rustc_trait_selection` implementéiert.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Gedeelt Referenze kënne kopéiert ginn, awer mutéierbar Referenzen *kënnen net*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}