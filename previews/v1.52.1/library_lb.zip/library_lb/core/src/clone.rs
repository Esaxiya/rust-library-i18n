//! Den `Clone` trait fir Typen déi net "implizit kopéiert" kënne ginn.
//!
//! Am Rust sinn e puer einfache Typen "implicitly copyable" a wann Dir se zouweist oder se als Argumenter weidergitt, kritt den Empfänger eng Kopie, léisst den originelle Wäert op der Plaz.
//! Dës Aarte erfuerderen keng Bewëllegung fir ze kopéieren an hu keng Finaliséierer (dh si enthalen net Besëtzboxen oder implementéieren [`Drop`]), sou datt de Compiler se als bëlleg a sécher kopéiert.
//!
//! Fir aner Aarte mussen Exemplare explizit gemaach ginn, duerch Konventioun déi d [`Clone`] trait implementéieren an d [`clone`] Method nennen.
//!
//! [`clone`]: Clone::clone
//!
//! Basis Benotzungs Beispill:
//!
//! ```
//! let s = String::new(); // String Typ implementéiert Klon
//! let copy = s.clone(); // sou datt mir et klone kënnen
//! ```
//!
//! Fir de Klon trait einfach ëmzesetzen, kënnt Dir och `#[derive(Clone)]` benotzen.Beispill:
//!
//! ```
//! #[derive(Clone)] // mir fügen de Klon trait op de Morpheus struct bäi
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // an elo kënne mir et klonen!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// E gemeinsamen trait fir d'Fäegkeet explizit en Objet ze duplizéieren.
///
/// Ënnerscheet sech vun [`Copy`] an deem [`Copy`] ass implizit an extrem preiswert, wärend `Clone` ëmmer explizit ass a vläicht net deier ass.
/// Fir dës Charakteristiken duerchzesetzen, erlaabt Rust Iech net [`Copy`] nei z'implementéieren, awer Dir kënnt `Clone` nei implementéieren an arbiträre Code ausféieren.
///
/// Well `Clone` méi allgemeng ass wéi [`Copy`], kënnt Dir automatesch alles [`Copy`] och `Clone` maachen.
///
/// ## Derivable
///
/// Dësen trait kann mat `#[derive]` benotzt ginn wann all Felder `Clone` sinn.Déi "ofgeleet" Implementatioun vun [`Clone`] rifft [`clone`] op all Feld.
///
/// [`clone`]: Clone::clone
///
/// Fir e generesche Struct implementéiert `#[derive]` `Clone` bedingt andeems se gebonne `Clone` op generesch Parameteren derbäisetzen.
///
/// ```
/// // `derive` implementéiert Klon fir ze liesen<T>wann T Klon ass.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Wéi kann ech `Clone` implementéieren?
///
/// Typen déi [`Copy`] sinn, sollten eng trivial Ëmsetzung vun `Clone` hunn.Méi formell:
/// wann `T: Copy`, `x: T` an `y: &T`, dann ass `let x = y.clone();` gläichwäerteg wéi `let x = *y;`.
/// Manuell Implementéierunge sollten oppassen fir dësen Invariant ze halen;allerdéngs, onséchere Code däerf net drop vertrauen fir d'Erënnerungssécherheet ze garantéieren.
///
/// E Beispill ass e generesche Struktur deen e Funktiounszeiger hält.An dësem Fall kann d'Ëmsetzung vun `Clone` net "ofgeleet" ginn, awer kann implementéiert ginn wéi:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Zousätzlech Implementateuren
///
/// Nieft dem [implementors listed below][impls] implementéiere folgend Zorten och `Clone`:
///
/// * Funktiounsartypen (dh déi ënnerschiddlech Aarte fir all Funktioun definéiert)
/// * Funktioun Zeigentypen (z. B. `fn() -> i32`)
/// * Arraytypen, fir all Gréissten, wann den Artikelart och `Clone` implementéiert (z. B. `[i32; 123456]`)
/// * Tupeltypen, wann all Komponent och `Clone` implementéiert (z. B. `()`, `(i32, bool)`)
/// * Ofschlossaarten, wa se kee Wäert aus der Ëmwelt fänken oder wann all sou agefaangene Wäerter `Clone` selwer implementéieren.
///   Bedenkt datt Variablen déi duerch gemeinsame Referenz erfaasst ginn ëmmer `Clone` implementéieren (och wann de Referent net), wärend Variabelen déi duerch mutabel Referenz erfaasst ginn ni `Clone` implementéieren.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Nees eng Kopie vum Wäert.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str implementéiert Klon
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Leeschtunge Kopie Aufgab vun `source`.
    ///
    /// `a.clone_from(&b)` ass gläichwäerteg wéi `a = b.clone()` a Funktionalitéit, awer kann iwwerschriwwe ginn fir d'Ressourcen vun `a` weiderbenotzen fir onnéideg Allocatiounen ze vermeiden.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Ofleeft Makro generéiert en Impl vun der trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): dës Structs gi just vum#[ofgeleet] benotzt fir ze behaapten datt all Komponent vun engem Typ Klon oder Kopie implementéiert.
//
//
// Dës Structs sollten ni am Benotzerkode erschéngen.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Implementatiounen vum `Clone` fir primitiv Typen.
///
/// Implementatiounen déi net am Rust beschriwwe kënne ginn an `traits::SelectionContext::copy_clone_conditions()` an `rustc_trait_selection` implementéiert.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Gedeelt Referenze kënne gekloont ginn, awer mutéierbar Referenzen *kënnen net*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Gedeelt Referenze kënne gekloont ginn, awer mutéierbar Referenzen *kënnen net*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}