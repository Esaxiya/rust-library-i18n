//! Deelbar verännerbar Behälter.
//!
//! Rust Gedächtnissécherheet baséiert op dëser Regel: Gitt en Objet `T`, ass et nëmme méiglech eent vun de folgenden ze hunn:
//!
//! - Hutt verschidde onverännerbar Referenzen (`&T`) op den Objet (och bekannt als **aliasing**).
//! - Eng mutabel Referenz hunn (`&mut T`) zum Objet (och bekannt als **Verännerlechkeet**).
//!
//! Dëst gëtt vum Rust Compiler duerchgesat.Wéi och ëmmer, et gi Situatiounen wou dës Regel net flexibel genuch ass.Heiansdo ass et erfuerderlech verschidde Referenzen zu engem Objet ze hunn an awer ze mutéieren.
//!
//! Deelbar verännerbar Container existéieren fir eng kontrolléiert Manéier z'änneren, och a Präsenz vum Aliasing.Béid [`Cell<T>`] an [`RefCell<T>`] erlaben et op engem eenzege Fuedem ze maachen.
//! Wéi och ëmmer, weder `Cell<T>` nach `RefCell<T>` sinn thread thread sécher (se implementéieren net [`Sync`]).
//! Wann Dir Aliasing a Mutatioun tëscht méi Threads maache musst ass et méiglech [`Mutex<T>`], [`RwLock<T>`] oder [`atomic`] Typen ze benotzen.
//!
//! Wäerter vun den `Cell<T>` an `RefCell<T>` Typen kënnen duerch gedeelt Referenzen mutéiert ginn (dh
//! den allgemenge `&T` Typ), wärend déi meescht Rust Typen nëmmen duerch eenzegaarteg (`&mut T`) Referenze mutéiert kënne ginn.
//! Mir soen datt `Cell<T>` an `RefCell<T>` 'Interieurmutabilitéit' ubidden, am Géigesaz zu typeschen Rust Typen déi 'ierflech Mutabilitéit' weisen.
//!
//! Zellentypen sinn an zwee Goûten: `Cell<T>` an `RefCell<T>`.`Cell<T>` implementéiert bannenzeg Verännerlechkeet andeems se Wäerter an an aus der `Cell<T>` réckelen.
//! Fir Referenzen amplaz vu Wäerter ze benotzen, muss een den `RefCell<T>` Typ benotzen, e Schreifschloss kréien ier e mutéiert.`Cell<T>` bitt Methoden fir den aktuellen Interieurwäert erëmzefannen an z'änneren:
//!
//!  - Fir Typen déi [`Copy`] implementéieren, hëlt d [`get`](Cell::get) Method den aktuellen Interieurwäert zréck.
//!  - Fir Typen déi [`Default`] implementéieren, ersetzt d [`take`](Cell::take) Method den aktuellen Interieurwäert mat [`Default::default()`] an ersetzt den ersetzte Wäert.
//!  - Fir all Typ ersetzt d [`replace`](Cell::replace) Method den aktuellen Interieurwäert an ersetzt den ersatene Wäert an d [`into_inner`](Cell::into_inner) Method verbraucht den `Cell<T>` an zréck den Interieurwäert.
//!  Zousätzlech ersetzt d [`set`](Cell::set) Method den Interieurwäert, fällt den ersetzte Wäert.
//!
//! `RefCell<T>` benotzt d'Liewensdauer vum Rust fir 'dynamesch Prêten' ëmzesetzen, e Prozess wou een temporäre, exklusiven, verännerbaren Zougang zum banneschte Wäert kann ufroen.
//! Prêt fir `RefCell<T>`s ginn 'bei Runtime' verfollegt, am Géigesaz zu den natierleche Referenztypen vun Rust déi ganz statesch verfollegt ginn, a kompiléierter Zäit.
//! Well `RefCell<T>` Prêten dynamesch sinn ass et méiglech e Wäert ze léinen dee scho mutéiert geléint ass;wann dëst passéiert ass et e Fuedem panic.
//!
//! # Wéini wielt Interieurmutabilitéit
//!
//! Déi méi heefeg ierflech Mutabilitéit, wou een eenzegen Zougang muss hunn fir e Wäert ze mutéieren, ass ee vun de Schlësselsproochelementer déi et erméiglecht Rust staark ze veruersaachen iwwer Pointer Aliasing, statesch verhënnert Crash Bugs.
//! Dofir ass geierft Verännerlechkeet bevorzugt, an bannenzeg Verännerlechkeet ass eppes vun engem leschten Auswee.
//! Well Zelltypen d'Mutatioun erméiglechen, wou se awer soss net erlaabt sinn, ginn et Geleeënheeten, wann bannenzeg Mutabilitéit kéint ubruecht sinn, oder souguer *muss* benotzt ginn, z.
//!
//! * Aféierung vun der Verännerlechkeet 'inside' vun eppes onverännerlech
//! * Implementéierungsdetailer vu logesch onverännerbare Methoden.
//! * Mutéierend Implementatiounen vun [`Clone`].
//!
//! ## Aféierung vun der Verännerlechkeet 'inside' vun eppes onverännerlech
//!
//! Vill gemeinsam intelligent Zeigentypen, dorënner [`Rc<T>`] an [`Arc<T>`], bidden Container déi gekloont a gedeelt kënne ginn tëscht verschiddene Parteien.
//! Well déi enthale Wäerter multiplizéiert kënne ginn, kënne se nëmme mat `&`, net `&mut`, ausgeléint ginn.
//! Ouni Zellen wier et onméiglech iwwerhaapt Daten innerhalb vun dësen intelligenten Zeigefanger ze mutéieren.
//!
//! Et ass ganz heefeg dann en `RefCell<T>` an de gemeinsamen Zeigertypen ze setzen fir d'Mutabilitéit erëm anzeféieren:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Erstellt en neie Block fir den Ëmfang vun der dynamescher Prêt ze limitéieren
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Bedenkt datt wa mir de fréiere Prêt vum Cache net aus dem Ëmfang fale gelooss hunn, da géif de spéidere Prêt en dynamesche Fuedem panic verursaachen.
//!     //
//!     // Dëst ass déi grouss Gefor fir `RefCell` ze benotzen.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Bedenkt datt dëst Beispill `Rc<T>` benotzt an net `Arc<T>`.`RefCell<T>`s si fir eenzeg thread Szenarien.Bedenkt [`RwLock<T>`] oder [`Mutex<T>`] ze benotzen wann Dir eng gedeelt Mutabilitéit an enger Multi-Threaded Situatioun braucht.
//!
//! ## Implementéierungsdetailer vu logesch onverännerbare Methoden
//!
//! Heiansdo kann et wënschenswäert sinn net an enger API z'exposéieren datt et eng Mutatioun "under the hood" geschitt.
//! Dëst ka well logescherweis d'Operatioun onverännerbar ass, awer zB Cache zwéngt d'Implementatioun fir eng Mutatioun ze maachen;oder well Dir Mutatioun benotze musst fir eng trait Method ëmzesetzen déi ursprénglech definéiert war fir `&self` ze huelen.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Deier Berechnung geet hei
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Mutéierend Implementatiounen vun `Clone`
//!
//! Dëst ass einfach e speziellen, awer allgemenge Fall vun der viregter: Verstoppt Mutabilitéit fir Operatiounen déi onverännerbar schéngen.
//! D [`clone`](Clone::clone) Method gëtt erwaart de Quellwäert net z'änneren, a gëtt deklaréiert `&self` ze huelen, net `&mut self`.
//! Dofir, all Mutatioun déi an der `clone` Method passéiert muss Zelltypen benotzen.
//! Zum Beispill, [`Rc<T>`] hält seng Referenzzuelen an engem `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Eng verännerbar Erënnerungsplaz.
///
/// # Examples
///
/// An dësem Beispill kënnt Dir gesinn datt `Cell<T>` d'Mutatioun an engem onverännerleche Struktur erméiglecht.
/// An anere Wierder, et erméiglecht "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // FEELER: `my_struct` ass onverännerlech
/// // my_struct.regular_field =nei_wäert;
///
/// // SCHAFFT: och wann den `my_struct` onverännerbar ass, ass den `special_field` en `Cell`,
/// // déi ëmmer kënne mutéiert ginn
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Kuckt de [module-level documentation](self) fir méi.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Erstellt en `Cell<T>`, mam `Default` Wäert fir den T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Erstellt en neien `Cell` mat dem gegebene Wäert.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Setzt de enthale Wäert.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Tauscht d'Wäerter vun zwou Zellen aus.
    /// Ënnerscheed mam `std::mem::swap` ass datt dës Funktioun keng `&mut` Referenz brauch.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // SAFETY: Dëst ka riskant si wa se aus getrennten Threads geruff ginn, awer `Cell`
        // ass `!Sync` also wäert dat net geschéien.
        // Dëst wäert och keng Uweiser ongëlteg maachen well `Cell` suergt datt näischt anescht an eng vun dësen `Cell`s weist.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Ersetzt de enthale Wäert mat `val`, a bréngt den ale enthale Wäert zréck.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // SAFETY: Dëst kann Datenrennen verursaachen wann se aus engem getrennten thread geruff ginn,
        // awer `Cell` ass `!Sync`, sou datt dëst net geschitt.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Entwéckelt de Wäert.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Gitt eng Kopie vum enthale Wäert.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // SAFETY: Dëst kann Datenrennen verursaachen wann se aus engem getrennten thread geruff ginn,
        // awer `Cell` ass `!Sync`, sou datt dëst net geschitt.
        unsafe { *self.value.get() }
    }

    /// Aktualiséiert de enthale Wäert mat enger Funktioun a bréngt den neie Wäert zréck.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Gitt e roude Zeiger op d'Basisdaten an dëser Zell.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Gitt eng mutéierbar Referenz zu de Basisdaten.
    ///
    /// Dësen Uruff léint `Cell` mutéierbar (a Kompiléierzäit) wat garantéiert datt mir déi eenzeg Referenz hunn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Retour en `&Cell<T>` vun engem `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // SAFETY: `&mut` suergt fir een eenzegaartegen Zougang.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Huelt de Wäert vun der Zell, léisst `Default::default()` op senger Plaz.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Retour en `&[Cell<T>]` vun engem `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // SAFETY: `Cell<T>` huet dee selwechte Memory Layout wéi `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Eng mutabel Erënnerungsplaz mat dynamesch iwwerpréifte Prêtregelen
///
/// Kuckt de [module-level documentation](self) fir méi.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// E Feeler vun [`RefCell::try_borrow`] zréck.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// E Feeler vun [`RefCell::try_borrow_mut`] zréck.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Positiv Wäerter stellen d'Zuel vun `Ref` aktiv duer.Negativ Wäerter stellen d'Zuel vun `RefMut` aktiv duer.
// Multiple `RefMut`s kënnen nëmme gläichzäiteg aktiv sinn wa se op ënnerschiddlech, net iwwerlappend Komponente vun engem `RefCell` bezéien (zB verschidde Reegele vun enger Scheif).
//
// `Ref` an `RefMut` sinn zwee Wierder an der Gréisst, an dofir gëtt et wuel ni genuch `Ref` oder`RefMut`s fir d'Halschent vun der `usize` Range z'iwwerschreiden.
// Also, en `BorrowFlag` wäert wahrscheinlech ni iwwerfléissen oder ënnerstréimen.
// Wéi och ëmmer, dëst ass keng Garantie, well e pathologesche Programm kéint ëmmer erëm mem::forget `Ref`s oder`RefMut`s erstellen.
// Also muss all Code explizit fir Iwwerfluss an Ënnerstroum kontrolléieren fir Onsécherheet ze vermeiden, oder op d'mannst richteg behuelen am Fall wou Iwwerlaf oder Ënnerlaf geschitt (z. B. BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Erstellt en neien `RefCell` mat `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Verbraucht den `RefCell`, bréngt de gewéckelte Wäert zréck.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Well dës Funktioun `self` (den `RefCell`) nom Wäert hëlt, verifizéiert de Compiler statesch datt en de Moment net ausgeléint ass.
        //
        self.value.into_inner()
    }

    /// Ersetzt de gewéckelte Wäert mat engem neien, bréngt den ale Wäert zréck, ouni deinitialiséieren.
    ///
    ///
    /// Dës Funktioun entsprécht [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics wann de Wäert aktuell ausgeléint ass.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Ersetzt de gewéckelte Wäert mat engem neie berechent vun `f`, zréckgëtt deen ale Wäert, ouni een ze deinitialiséieren.
    ///
    ///
    /// # Panics
    ///
    /// Panics wann de Wäert aktuell ausgeléint ass.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Tauscht de gewéckelte Wäert vun `self` mam agewéckelte Wäert vun `other` aus, ouni een ze deitialiséieren.
    ///
    ///
    /// Dës Funktioun entsprécht [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics wann de Wäert an entweder `RefCell` aktuell ausgeléint ass.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Immutable léint de gewéckelte Wäert.
    ///
    /// De Prêt dauert bis den zréck `Ref` Ëmfang erausgeet.
    /// Méi onverännerbar Prêten kënnen zur selwechter Zäit ausgeholl ginn.
    ///
    /// # Panics
    ///
    /// Panics wann de Wäert de Moment mutabel ausgeléint ass.
    /// Fir eng net panikéiert Variant, benotzt [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// E Beispill vu panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Immutable léint de gewéckelte Wäert, e Feeler zréck wann de Wäert aktuell mutabel ausgeléint ass.
    ///
    ///
    /// De Prêt dauert bis den zréck `Ref` Ëmfang erausgeet.
    /// Méi onverännerbar Prêten kënnen zur selwechter Zäit ausgeholl ginn.
    ///
    /// Dëst ass déi net panikéiert Variant vun [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // SAFETY: `BorrowRef` garantéiert datt et nëmmen onverännerbar Zougang ass
            // un de Wäert beim Prêt.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Mutéiert léint de gewéckelte Wäert.
    ///
    /// De Prêt dauert bis den zréck `RefMut` oder all 'RefMut`s ofgeleet vun deem Ausgangsberäich.
    ///
    /// De Wäert kann net ausgeléint ginn wärend dëse Prêt aktiv ass.
    ///
    /// # Panics
    ///
    /// Panics wann de Wäert aktuell ausgeléint ass.
    /// Fir eng net panikéiert Variant, benotzt [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// E Beispill vu panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Mutéiert léint de gewéckelte Wäert, e Feeler zréck wann de Wäert aktuell geléint ass.
    ///
    ///
    /// De Prêt dauert bis den zréck `RefMut` oder all 'RefMut`s ofgeleet vun deem Ausgangsberäich.
    /// De Wäert kann net ausgeléint ginn wärend dëse Prêt aktiv ass.
    ///
    /// Dëst ass déi net panikéiert Variant vun [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // SAFETY: `BorrowRef` garantéiert eenzegaarteg Zougang.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Gitt e roude Zeiger op d'Basisdaten an dëser Zell.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Gitt eng mutéierbar Referenz zu de Basisdaten.
    ///
    /// Dësen Uruff léint `RefCell` mutéierbar (beim Zesummestellen) also ass et net néideg fir dynamesch Kontrollen.
    ///
    /// Maacht awer virsiichteg: dës Method erwaart datt `self` mutabel ass, wat normalerweis net de Fall ass wann Dir en `RefCell` benotzt.
    ///
    /// Kuckt d [`borrow_mut`] Method anstatt wann `self` net verännerbar ass.
    ///
    /// Och, gitt w.e.g. bewosst datt dës Method nëmme fir speziell Ëmstänn ass an normalerweis net ass wat Dir wëllt.
    /// Am Zweiwelsfall benotzt [`borrow_mut`] statt.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Den Effekt vu geleckte Wuecht op de Prêtzoustand vun der `RefCell` réckgängeg maachen.
    ///
    /// Dëse Ruff ass ähnlech wéi [`get_mut`] awer méi spezialiséiert.
    /// Et léint `RefCell` mutéierbar fir sécherzestellen datt keng Prêten existéieren an da setzt d'Staat zréck a verfollegt gedeelt Prêten.
    /// Dëst ass relevant wann e puer `Ref` oder `RefMut` Prêten duerchgesat goufen.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Immutable léint de gewéckelte Wäert, e Feeler zréck wann de Wäert aktuell mutabel ausgeléint ass.
    ///
    /// # Safety
    ///
    /// Am Géigesaz zu `RefCell::borrow` ass dës Method onsécher well se keen `Ref` zréckbréngt, sou datt de Prêt Fändel onberéiert bleift.
    /// Mutéiert d `RefCell` ze léinen, wärend d'Referenz vun dëser Method zréck liewt ass ondefinéiert Verhalen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // SAFETY: Mir kontrolléieren datt keen elo aktiv schreift, awer et ass
            // d'Verantwortung vum Uruff fir sécherzestellen datt kee schreift bis déi zréckbezunnen Referenz net méi benotzt gëtt.
            // Och `self.value.get()` bezitt sech op de Wäert vum `self` a ass dofir garantéiert fir d'Liewensdauer vun `self` gëlteg.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Hëlt de gewéckelte Wäert, léisst `Default::default()` op senger Plaz.
    ///
    /// # Panics
    ///
    /// Panics wann de Wäert aktuell ausgeléint ass.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics wann de Wäert de Moment mutabel ausgeléint ass.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Erstellt en `RefCell<T>`, mam `Default` Wäert fir den T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics wann de Wäert an entweder `RefCell` aktuell ausgeléint ass.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics wann de Wäert an entweder `RefCell` aktuell ausgeléint ass.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics wann de Wäert an entweder `RefCell` aktuell ausgeléint ass.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics wann de Wäert an entweder `RefCell` aktuell ausgeléint ass.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics wann de Wäert an entweder `RefCell` aktuell ausgeléint ass.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics wann de Wäert an entweder `RefCell` aktuell ausgeléint ass.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics wann de Wäert an entweder `RefCell` aktuell ausgeléint ass.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Inkrementéierend Prêt kann zu engem Net-Lieswäert (<=0) an dëse Fäll resultéieren:
            // 1. Et war <0, dh et gi Schreifléin, also kënne mir keng Lieskredit erlaben wéinst Rust Referenz Aliaséierungsregelen
            // 2.
            // Et war isize::MAX (de maximale Betrag u Lieskrediten) an et ass an isize::MIN iwwerschwemmt (de Maximum vu Schreifprêten), sou datt mir keng zousätzlech Lieskreditt erlaben, well isize kann net sou vill gelies Krediter duerstellen (dëst kann nëmme geschéien wann Dir mem::forget méi wéi e klenge konstante Betrag vun `Ref`s, wat net gutt Praxis ass)
            //
            //
            //
            //
            None
        } else {
            // Inkrementéierend Prêt kann zu engem Lieswäert (> 0) an dëse Fäll resultéieren:
            // 1. Et war=0, dh et war net ausgeléint, a mir huelen déi éischt gelies Prêt
            // 2. Et war> 0 an <isize::MAX, dh
            // do ware geléinte Prêten, an isize ass grouss genuch fir duerzestellen, datt ee méi gelies kritt
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Zënter dësem Ref existéiert, wësse mer datt de Prêtfändel e Liespuer ass.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Verhënnert datt de Prêt Compteur iwwerschwemmt an e Schrëftprêt.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Wéckelt eng geléinte Referenz zu engem Wäert an enger `RefCell` Box.
/// E Wéckertyp fir en onverännert geléinte Wäert vun engem `RefCell<T>`.
///
/// Kuckt de [module-level documentation](self) fir méi.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Kopéiert en `Ref`.
    ///
    /// Den `RefCell` ass scho onverännert geléint, sou datt dëst net fale kann.
    ///
    /// Dëst ass eng assoziéiert Funktioun déi als `Ref::clone(...)` benotzt muss ginn.
    /// Eng `Clone`-Implementatioun oder eng Method géif mat der verbreeter Benotzung vun `r.borrow().clone()` interferéieren fir den Inhalt vun engem `RefCell` ze klonen.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Maacht en neien `Ref` fir e Bestanddeel vun de geléinten Daten.
    ///
    /// Den `RefCell` ass scho onverännert geléint, sou datt dëst net fale kann.
    ///
    /// Dëst ass eng assoziéiert Funktioun déi als `Ref::map(...)` benotzt muss ginn.
    /// Eng Method géif mat Methode mam selwechten Numm am Inhalt vun engem `RefCell`, deen duerch `Deref` benotzt gëtt, stéieren.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Maacht en neien `Ref` fir e optional Komponent vun de geléinten Daten.
    /// Den originelle Schutz gëtt als `Err(..)` zréckgezunn wann d'Zoumaache `None` zréckgeet.
    ///
    /// Den `RefCell` ass scho onverännert geléint, sou datt dëst net fale kann.
    ///
    /// Dëst ass eng assoziéiert Funktioun déi als `Ref::filter_map(...)` benotzt muss ginn.
    /// Eng Method géif mat Methode mam selwechten Numm am Inhalt vun engem `RefCell`, deen duerch `Deref` benotzt gëtt, stéieren.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Deelt en `Ref` a verschidde `Ref`s fir verschidde Komponente vun de geléinten Daten.
    ///
    /// Den `RefCell` ass scho onverännert geléint, sou datt dëst net fale kann.
    ///
    /// Dëst ass eng assoziéiert Funktioun déi als `Ref::map_split(...)` benotzt muss ginn.
    /// Eng Method géif mat Methode mam selwechten Numm am Inhalt vun engem `RefCell`, deen duerch `Deref` benotzt gëtt, stéieren.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Konvertéiert an eng Referenz zu de Basisdaten.
    ///
    /// De Basis `RefCell` kann ni mutabel ausgeléint ginn a wäert ëmmer scho onverännerbar ausgeléint sinn.
    ///
    /// Et ass net eng gutt Iddi méi wéi eng konstant Unzuel u Referenzen ze lecken.
    /// Den `RefCell` kann immut erëm ausgeléint ginn wann nëmmen eng méi kleng Unzuel vu Leck am Ganzen geschitt ass.
    ///
    /// Dëst ass eng assoziéiert Funktioun déi als `Ref::leak(...)` benotzt muss ginn.
    /// Eng Method géif mat Methode mam selwechten Numm am Inhalt vun engem `RefCell`, deen duerch `Deref` benotzt gëtt, stéieren.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Mat dësem Ref vergiessen mir sécher datt de Prêt Compteur an der RefCell net zréck an UNUSED bannent der Liewensdauer `'b` kënnt.
        // De Referenzverfollegungsstatus zrécksetzen erfuerdert eng eenzegaarteg Referenz zu der geléinter RefCell.
        // Keng weider mutéierbar Referenze kënnen aus der Originalzell erstallt ginn.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Maacht en neien `RefMut` fir e Bestanddeel vun de geléinten Daten, zB eng Enum Variant.
    ///
    /// Den `RefCell` ass scho mutéiert ausgeléint, sou datt dëst net fale kann.
    ///
    /// Dëst ass eng assoziéiert Funktioun déi als `RefMut::map(...)` benotzt muss ginn.
    /// Eng Method géif mat Methode mam selwechten Numm am Inhalt vun engem `RefCell`, deen duerch `Deref` benotzt gëtt, stéieren.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): fix léinen-kontrolléieren
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Maacht en neien `RefMut` fir e optional Komponent vun de geléinten Daten.
    /// Den originelle Schutz gëtt als `Err(..)` zréckgezunn wann d'Zoumaache `None` zréckgeet.
    ///
    /// Den `RefCell` ass scho mutéiert ausgeléint, sou datt dëst net fale kann.
    ///
    /// Dëst ass eng assoziéiert Funktioun déi als `RefMut::filter_map(...)` benotzt muss ginn.
    /// Eng Method géif mat Methode mam selwechten Numm am Inhalt vun engem `RefCell`, deen duerch `Deref` benotzt gëtt, stéieren.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): fix léinen-kontrolléieren
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // SAFETY: Funktioun hält eng exklusiv Referenz fir d'Dauer
        // vu sengem Uruff duerch `orig`, an de Zeiger ass nëmmen de-referenzéiert bannent dem Funktiounsruff ni erlaabt datt déi exklusiv Referenz entkomm ass.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // SAFETY: d'selwecht wéi uewen.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Deelt en `RefMut` a verschidde `RefMut`s fir verschidde Komponente vun de geléinten Daten.
    ///
    /// De Basis `RefCell` bleift mutabel ausgeléint bis béid zréckkomm "RefMut`s aus dem Ëmfang erausgoen.
    ///
    /// Den `RefCell` ass scho mutéiert ausgeléint, sou datt dëst net fale kann.
    ///
    /// Dëst ass eng assoziéiert Funktioun déi als `RefMut::map_split(...)` benotzt muss ginn.
    /// Eng Method géif mat Methode mam selwechten Numm am Inhalt vun engem `RefCell`, deen duerch `Deref` benotzt gëtt, stéieren.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Konvertéiert an eng mutéierbar Referenz zu de Basisdaten.
    ///
    /// De Basis `RefCell` kann net erëm ausgeléint ginn a wäert ëmmer scho mutabel geléint erschéngen, wouduerch déi zréckbezunnen Referenz nëmmen zum Interieur ass.
    ///
    ///
    /// Dëst ass eng assoziéiert Funktioun déi als `RefMut::leak(...)` benotzt muss ginn.
    /// Eng Method géif mat Methode mam selwechten Numm am Inhalt vun engem `RefCell`, deen duerch `Deref` benotzt gëtt, stéieren.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Mat dësem BorrowRefMut vergiesst mir sécher datt de Prêt Compteur an der RefCell net zréck an UNUSED bannent der Liewensdauer `'b` kënnt.
        // De Referenzverfollegungsstatus zrécksetzen erfuerdert eng eenzegaarteg Referenz zu der geléinter RefCell.
        // Keng weider Referenze kënnen aus der Originalzell bannent där Liewensdauer erstallt ginn, wouduerch de Stroum déi eenzeg Referenz fir de Rescht Liewensdauer gëtt.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Am Géigesaz zu BorrowRefMut::clone gëtt nei geruff fir den Initial ze kreéieren
        // mutéierbar Referenz, an dofir däerfen de Moment keng existent Referenze sinn.
        // Also, wärend de Klon de mutabelen Zréckzuel erhéicht, erlaabt mir hei explizit nëmmen vun UNUSED op UNUSED, 1 ze goen.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Klon en `BorrowRefMut`.
    //
    // Dëst ass nëmme gëlteg wann all `BorrowRefMut` benotzt gëtt fir eng mutabel Referenz zu engem ënnerschiddlechen, net iwwerlappende Beräich vum Original Objet ze verfollegen.
    //
    // Dëst ass net an engem Klon impl sou datt de Code dëst net implizit nennt.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Verhënnert de Prêt Comptoir vum Ënnerfloss.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// E Wéckeltyp fir e mutéiert geléinte Wäert vun engem `RefCell<T>`.
///
/// Kuckt de [module-level documentation](self) fir méi.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// De Kär primitiv fir bannenzeg Verännerlechkeet an Rust.
///
/// Wann Dir eng Referenz `&T` hutt, da mécht de Compiler normalerweis an Rust Optimiséierungen op Basis vum Wëssen datt `&T` op onverännerbar Daten weist.Mutatioun vun dësen Donnéeën, zum Beispill duerch en Alias oder duerch en `&T` an en `&mut T` ëmzesetzen, gëllt als ondefinéiert Verhalen.
/// `UnsafeCell<T>` wielt aus der Immutabilitéitsgarantie fir `&T`: eng gemeinsam Referenz `&UnsafeCell<T>` kann op Daten hiweisen déi mutéiert ginn.Dëst gëtt "interior mutability" genannt.
///
/// All aner Typen déi intern Verännerlechkeet erlaben, wéi `Cell<T>` an `RefCell<T>`, benotzen intern `UnsafeCell` fir hir Donnéeën ze wéckelen.
///
/// Bedenkt datt nëmmen d'Immutabilitéitsgarantie fir gemeinsam Referenzen duerch `UnsafeCell` beaflosst gëtt.D'Eindeutegarantie fir mutabel Referenzen ass net beaflosst.Et gëtt *kee* legal Wee fir den Aliasing `&mut` ze kréien, och net mat `UnsafeCell<T>`.
///
/// D `UnsafeCell` API selwer ass technesch ganz einfach: [`.get()`] gëtt Iech e rauen Zeiger `*mut T` fir säin Inhalt.Et ass bis zu _you_ als Abstraktiounsdesigner fir dee roude Zeiger korrekt ze benotzen.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Déi präzis Rust Aliaséierungsregele sinn e bësse fléissend, awer d'Haaptpunkte sinn net kontrovers:
///
/// - Wann Dir eng sécher Referenz mat der Liewensdauer `'a` (entweder eng `&T` oder `&mut T` Referenz) erstallt, déi mat engem séchere Code zougänglech ass (zum Beispill well Dir se zréckkomm hutt), da musst Dir d'Daten op kee Fall zougräifen, déi der Referenz fir de Rescht widderspriechen vun `'a`.
/// Zum Beispill heescht dat, datt wann Dir den `*mut T` vun engem `UnsafeCell<T>` hëlt a se op en `&T` geheit, da mussen d'Donnéeën am `T` onverännerbar bleiwen (modulo all `UnsafeCell` Daten, déi natierlech am `T` fonnt ginn) bis datt d'Liewensdauer vun der Referenz ofleeft.
/// Ähnlech wéi wann Dir eng `&mut T` Referenz erstellt déi op e séchere Code verëffentlecht gëtt, da musst Dir net Zougang zu den Daten am `UnsafeCell` kréien bis dës Referenz ofleeft.
///
/// - Zu all Moment musst Dir vermeiden daten Rennen.Wa méi Threads Zougang zum selwechte `UnsafeCell` hunn, da muss all Schreiwe richteg geschéien-viru Relatioun zu allen aneren Accessen (oder Atomer benotzen).
///
/// Fir beim richtegen Design ze hëllefen, ginn déi folgend Szenarie explizit legal fir een thread threaded Code deklaréiert:
///
/// 1. Eng `&T` Referenz kann op e séchere Code verëffentlecht ginn an do ka se mat anere `&T` Referenzen existéieren, awer net mat engem `&mut T`
///
/// 2. Eng `&mut T` Referenz kann op e séchere Code verëffentlecht ginn, wa weder aner `&mut T` nach `&T` matenee existéieren.A `&mut T` muss ëmmer eenzegaarteg sinn.
///
/// Bedenkt datt wärend den Inhalt vun engem `&UnsafeCell<T>` mutéiert (och wann aner `&UnsafeCell<T>` Referenzen op Alias d'Zell) ok ass (virausgesat datt Dir déi uewe genannten Invarianer op eng aner Manéier duerchsetzt), ass et ëmmer nach definéiert Verhalen e puer `&mut UnsafeCell<T>` Aliasen ze hunn.
/// Dat ass, `UnsafeCell` ass e Wrapper entwéckelt fir eng speziell Interaktioun mat _shared_ accesses (_i.e._ ze hunn, duerch eng `&UnsafeCell<_>` Referenz);et gëtt keng Magie iwwerhaapt beim Ëmgang mat _exclusive_ accesses (_e.g._, duerch en `&mut UnsafeCell<_>`): weder d'Zell nach de gewéckelte Wäert däerf fir d'Dauer vun deem `&mut` léinen.
///
/// Dëst gëtt vum [`.get_mut()`] Accessor presentéiert, wat en _safe_ getter ass deen en `&mut T` gëtt.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Hei ass e Beispill dat weist wéi een den Inhalt vun engem `UnsafeCell<_>` gutt mutéiere kann, trotz datt et verschidde Referenze gëtt déi d'Zell aliaséieren:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Kritt méi/gläichzäiteg/gedeelt Referenzen op déi selwecht `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // SAFETY: bannent dësem Ëmfang ginn et keng aner Referenzen zum Inhalt vun "x",
///     // sou ass eis effektiv eenzegaarteg.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- léinen-+
///     *p1_exclusive += 27; // |
/// } // <---------- kann net iwwer dëse Punkt erausgoen -------------------+
///
/// unsafe {
///     // SAFETY: bannent dësem Ëmfang erwaart kee sech exklusiv Zougang zum "x" Inhalt ze hunn,
///     // sou datt mir e puer gedeelt Zougäng gläichzäiteg hunn.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Déi folgend Beispill weist de Fakt datt exklusiv Zougang zu engem `UnsafeCell<T>` exklusiv Zougang zu sengem `T` bedeit:
///
/// ```rust
/// #![forbid(unsafe_code)] // mat exklusiv Zougang,
///                         // `UnsafeCell` ass en transparenten No-op Wrapper, also kee Besoin fir `unsafe` hei.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Kritt eng kompiléieren-Zäit-kontrolléiert eenzegaarteg Referenz zu `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Mat enger exklusiver Referenz kënne mir den Inhalt gratis mutéieren.
/// *p_unique.get_mut() = 0;
/// // Oder, gläichwäerteg:
/// x = UnsafeCell::new(0);
///
/// // Wa mir de Wäert hunn, kënne mir den Inhalt gratis extrahieren.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Baut eng nei Instanz vun `UnsafeCell` déi de spezifizéierte Wäert packt.
    ///
    ///
    /// All Zougang zum banneschte Wäert duerch Methoden ass `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Entwéckelt de Wäert.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Kritt e mutablen Zeiger zum agewéckelte Wäert.
    ///
    /// Dëst kann zu engem Zeiger vun iergendenger Goss ginn.
    /// Gitt sécher datt den Zougang eenzegaarteg ass (keng aktiv Referenzen, mutéierbar oder net) beim Casting op `&mut T`, a gitt sécher datt et keng Mutatiounen oder mutable Aliasen amgaang ass wann Dir op `&T` castt
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Mir kënne just den Zeiger vun `UnsafeCell<T>` op `T` werfen wéinst #[repr(transparent)].
        // Dëst exploitéiert de besonnesche Status vun der libstd, et gëtt keng Garantie fir de Benotzercode datt dëst an future Versioune vum Compiler funktionnéiert!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Gitt eng mutéierbar Referenz zu de Basisdaten.
    ///
    /// Dësen Uruff léint den `UnsafeCell` mutéierbar (a Kompiléierzäit) wat garantéiert datt mir déi eenzeg Referenz hunn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Kritt e mutablen Zeiger zum agewéckelte Wäert.
    /// Den Ënnerscheed zu [`get`] ass datt dës Funktioun e roude Zeiger acceptéiert, wat nëtzlech ass fir d'Schafe vun temporäre Referenzen ze vermeiden.
    ///
    /// D'Resultat kann zu engem Zeiger vun iergendenger Goss ginn.
    /// Gitt sécher datt den Zougang eenzegaarteg ass (keng aktiv Referenzen, mutéierbar oder net) beim Casting op `&mut T`, a gitt sécher datt et keng Mutatiounen oder mutable Aliasen gëtt wann Dir op `&T` castt.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Graduell Initialiséierung vun engem `UnsafeCell` erfuerdert `raw_get`, well `get` uruffe géif verlaangen eng Referenz op net-initialiséiert Daten ze kreéieren:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Mir kënne just den Zeiger vun `UnsafeCell<T>` op `T` werfen wéinst #[repr(transparent)].
        // Dëst exploitéiert de besonnesche Status vun der libstd, et gëtt keng Garantie fir de Benotzercode datt dëst an future Versioune vum Compiler funktionnéiert!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Erstellt en `UnsafeCell`, mam `Default` Wäert fir den T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}