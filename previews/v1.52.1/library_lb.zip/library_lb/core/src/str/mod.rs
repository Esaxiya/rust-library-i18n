//! String Manipulatioun.
//!
//! Fir méi Detailer, kuckt de [`std::str`] Modul.
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. ausser Grenzen
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. ufänken <=Enn
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. Charakter Grenz
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // de Charakter fannen
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` muss manner wéi len an eng Char Grenz sinn
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Nees d'Längt vun `self`.
    ///
    /// Dës Längt ass a Bytes, net [`char`] oder Grafemen.
    /// An anere Wierder, et kann net sinn, wat e Mënsch d'Längt vun der Schnouer hält.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // ausgefalene f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Retour `true` wann `self` eng Längt vun Null Bytes huet.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Kontrolléiert datt den "Index"-te Byte deen éischte Bytes an enger UTF-8 Code Punktsekvens oder um Enn vun der String ass.
    ///
    ///
    /// Den Ufank an d'Enn vun der String (wann `index== self.len()`) als Grenze gëllt.
    ///
    /// Retour `false` wann `index` méi grouss ass wéi `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // Ufank vun `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // zweete Byte vun `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // drëtten Byte vun `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 a len sinn ëmmer ok.
        // Test fir 0 explizit sou datt et de Scheck einfach optiméiere kann an d'Strengendate fir dee Fall iwwerspréngt.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Dëst ass bësse magesch gläichwäerteg wéi: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Konvertéiert e String Slice zu engem Byte Slice.
    /// Fir d'Bytes Slice zréck an e String Slice ze konvertéieren, benotzt d [`from_utf8`] Funktioun.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // SAFETY: const Sound well mir zwou Aarte mat dem selwechte Layout transmutéieren
        unsafe { mem::transmute(self) }
    }

    /// Konvertéiert eng mutabel String Scheif an eng mutabel Byte Scheif.
    ///
    /// # Safety
    ///
    /// De Ruffer muss sécher sinn datt den Inhalt vun der Scheif UTF-8 gëlteg ass ier de Prêt eriwwer ass an de Basis `str` benotzt gëtt.
    ///
    ///
    /// Benotzung vun engem `str` deem säin Inhalt net gëlteg ass UTF-8 ass ondefinéiert Verhalen.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // SAFETY: de Besetzung vun `&str` op `&[u8]` ass sécher zënter `str`
        // huet dee selwechte Layout wéi `&[u8]` (nëmmen libstd kann dës Garantie maachen).
        // De Zeiger Dereferenz ass sécher well et kënnt aus enger mutéierter Referenz déi garantéiert gëlteg ass fir ze schreiwen.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Konvertéiert e Stringschnitt zu engem rauen Zeiger.
    ///
    /// Wéi String Scheiwen e Stéck Bytes sinn, weist de roude Zeiger op en [`u8`].
    /// Dëse Zeiger weist op den éischte Byte vum Stringschnitt.
    ///
    /// De Ruffer muss sécher sinn datt de zréckgezunnen Zeiger ni geschriwwe gëtt.
    /// Wann Dir d'Inhalter vun der String Slice mutéiere musst, benotzt [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Konvertéiert eng mutéierbar String Scheif an e rauen Zeiger.
    ///
    /// Wéi String Scheiwen e Stéck Bytes sinn, weist de roude Zeiger op en [`u8`].
    /// Dëse Zeiger weist op den éischte Byte vum Stringschnitt.
    ///
    /// Et ass Är Verantwortung sécher ze stellen datt d'Stréckschnitt nëmmen esou geännert gëtt datt et gëlteg UTF-8 bleift.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Nees e Subslice vun `str`.
    ///
    /// Dëst ass déi net panikéiert Alternativ zum `str` ze indexéieren.
    /// Retour [`None`] wann eng gläichwäerteg Indexéierungsoperatioun panic wier.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // Indizes net op UTF-8 Sequenzegrenzen
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // ausser Grenzen
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Nees e mutabelen Ënnerschnitt vun `str`.
    ///
    /// Dëst ass déi net panikéiert Alternativ zum `str` ze indexéieren.
    /// Retour [`None`] wann eng gläichwäerteg Indexéierungsoperatioun panic wier.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // richteg Längt
    /// assert!(v.get_mut(0..5).is_some());
    /// // ausser Grenzen
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Nees en onkontrolléierten Ënnerschnitt vun `str`.
    ///
    /// Dëst ass déi onkontrolléiert Alternativ fir den `str` ze indexéieren.
    ///
    /// # Safety
    ///
    /// Anruferer vun dëser Funktioun si verantwortlech datt dës Viraussetzungen zefridden sinn:
    ///
    /// * Den Startindex däerf den Endindex net iwwerschreiden;
    /// * Indexer musse bannent Grenze vun der Original Scheif sinn;
    /// * Indexer mussen op UTF-8 Sequenzegrenze leien.
    ///
    /// Ausgefall ass, kann déi zréckgestuerwe Stringplacke op en ongëltegt Gedächtnis referenzéieren oder géint d'Invariante verstoussen, déi vum `str` Typ kommunizéiert ginn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // SAFETY: den Uruff muss de Sécherheetsvertrag fir `get_unchecked` oprechterhalen;
        // de Slice ass verfeinbar well `self` ass eng sécher Referenz.
        // Den zréckgezunnen Zeiger ass sécher, well Imples vun `SliceIndex` musse garantéieren datt et ass.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Nees e mutabelen, onkontrolléierten Ënnerschnitt vun `str`.
    ///
    /// Dëst ass déi onkontrolléiert Alternativ fir den `str` ze indexéieren.
    ///
    /// # Safety
    ///
    /// Anruferer vun dëser Funktioun si verantwortlech datt dës Viraussetzungen zefridden sinn:
    ///
    /// * Den Startindex däerf den Endindex net iwwerschreiden;
    /// * Indexer musse bannent Grenze vun der Original Scheif sinn;
    /// * Indexer mussen op UTF-8 Sequenzegrenze leien.
    ///
    /// Ausgefall ass, kann déi zréckgestuerwe Stringplacke op en ongëltegt Gedächtnis referenzéieren oder géint d'Invariante verstoussen, déi vum `str` Typ kommunizéiert ginn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // SAFETY: den Uruff muss de Sécherheetsvertrag fir `get_unchecked_mut` oprechterhalen;
        // de Slice ass verfeinbar well `self` ass eng sécher Referenz.
        // Den zréckgezunnen Zeiger ass sécher, well Imples vun `SliceIndex` musse garantéieren datt et ass.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Erstellt e String Slice vun engem anere String Slice, andeems d'Sécherheetskontrollen ëmgaang sinn.
    ///
    /// Dëst ass normalerweis net recommandéiert, benotzt mat Vorsicht!Fir eng sécher Alternativ kuckt [`str`] an [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Dës nei Scheif geet vun `begin` op `end`, abegraff `begin` awer exklusiv `end`.
    ///
    /// Fir e mutablen Stringschnitt amplaz ze kréien, kuckt d [`slice_mut_unchecked`] Method.
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Anruferer vun dëser Funktioun si responsabel datt dräi Viraussetzungen zefridden sinn:
    ///
    /// * `begin` dierf net `end` iwwerschreiden.
    /// * `begin` an `end` musse Byte Positioune bannent der String Scheif sinn.
    /// * `begin` an `end` mussen op UTF-8 Sequenzgrenzen leien.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // SAFETY: den Uruff muss de Sécherheetsvertrag fir `get_unchecked` oprechterhalen;
        // de Slice ass verfeinbar well `self` ass eng sécher Referenz.
        // Den zréckgezunnen Zeiger ass sécher, well Imples vun `SliceIndex` musse garantéieren datt et ass.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Erstellt e String Slice vun engem anere String Slice, andeems d'Sécherheetskontrollen ëmgaang sinn.
    /// Dëst ass normalerweis net recommandéiert, benotzt mat Vorsicht!Fir eng sécher Alternativ kuckt [`str`] an [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Dës nei Scheif geet vun `begin` op `end`, abegraff `begin` awer exklusiv `end`.
    ///
    /// Fir amplaz eng onverännerbar Stringschnitt ze kréien, kuckt d [`slice_unchecked`] Method.
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Anruferer vun dëser Funktioun si responsabel datt dräi Viraussetzungen zefridden sinn:
    ///
    /// * `begin` dierf net `end` iwwerschreiden.
    /// * `begin` an `end` musse Byte Positioune bannent der String Scheif sinn.
    /// * `begin` an `end` mussen op UTF-8 Sequenzgrenzen leien.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // SAFETY: den Uruff muss de Sécherheetsvertrag fir `get_unchecked_mut` oprechterhalen;
        // de Slice ass verfeinbar well `self` ass eng sécher Referenz.
        // Den zréckgezunnen Zeiger ass sécher, well Imples vun `SliceIndex` musse garantéieren datt et ass.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Deelt eng String Scheif an zwee am Index.
    ///
    /// D'Argument, `mid`, soll e Byte Offset vum Ufank vun der String sinn.
    /// Et muss och op der Grenz vun engem UTF-8 Code Punkt sinn.
    ///
    /// Déi zwou Scheiwen, déi zréckginn, gi vum Ufank vun der Stringschnitt op `mid`, a vum `mid` bis zum Enn vum Stringschnitt.
    ///
    /// Fir amplaz mutabel String Scheiwen ze kréien, kuckt d [`split_at_mut`] Method.
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics wann `mid` net op enger UTF-8 Code Punkt Grenz ass, oder wann et laanscht d'Enn vum leschte Code Punkt vun der String Slice ass.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary kontrolléiert datt den Index an [0, .len()]
        if self.is_char_boundary(mid) {
            // SAFETY: just iwwerpréift datt `mid` op enger Char Grenz ass.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Deelt eng mutéierbar String Scheif an zwee am Index.
    ///
    /// D'Argument, `mid`, soll e Byte Offset vum Ufank vun der String sinn.
    /// Et muss och op der Grenz vun engem UTF-8 Code Punkt sinn.
    ///
    /// Déi zwou Scheiwen, déi zréckginn, gi vum Ufank vun der Stringschnitt op `mid`, a vum `mid` bis zum Enn vum Stringschnitt.
    ///
    /// Fir statt onverännerbar Stringplacke ze kréien, kuckt d [`split_at`] Method.
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics wann `mid` net op enger UTF-8 Code Punkt Grenz ass, oder wann et laanscht d'Enn vum leschte Code Punkt vun der String Slice ass.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary kontrolléiert datt den Index an [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // SAFETY: just iwwerpréift datt `mid` op enger Char Grenz ass.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Nees en Iterator iwwer de [`Char`] vun engem Stringschnitt.
    ///
    /// Wéi e Stringschnitt aus gëltege UTF-8 besteet, kënne mir duerch e Stringschnitt duerch [`char`] iteréieren.
    /// Dës Method bréngt sou en Iterator zréck.
    ///
    /// Et ass wichteg ze vergiessen datt [`char`] en Unicode Scalar Value representéiert, a vläicht net mat Ärer Iddi entsprécht wat en 'character' ass.
    ///
    /// Iteratioun iwwer Graphemcluster ka sinn, wat Dir tatsächlech wëllt.
    /// Dës Funktionalitéit gëtt net vun der Standardbibliothéik vun Rust zur Verfügung gestallt, kuckt crates.io statt.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Denkt drun, [`char`] kënnen net mat Ärer Intuition iwwer Charaktere passen:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // net 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Nees en Iterator iwwer de [`Char`] vun engem Stringschnitt, an hir Positiounen.
    ///
    /// Wéi e Stringschnitt aus gëltege UTF-8 besteet, kënne mir duerch e Stringschnitt duerch [`char`] iteréieren.
    /// Dës Method bréngt en Iterator vu béiden dës [`Char`], souwéi hir Byte Positiounen zréck.
    ///
    /// Den Iterator ergëtt Tuplen.D'Positioun ass éischt, d [`char`] ass zweet.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Denkt drun, [`char`] kënnen net mat Ärer Intuition iwwer Charaktere passen:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // net (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // notéiert déi 3 hei, de leschte Charakter huet zwee Bytes opgeholl
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// En Iterator iwwer d'Bytes vun engem Stringschnitt.
    ///
    /// Wéi e Stringschnitt aus enger Sequenz vu Bytes besteet, kënne mir duerch e String Slice Byte iteréieren.
    /// Dës Method bréngt sou en Iterator zréck.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Deelt e Stringschnëtt no Wäissraum.
    ///
    /// Den Iterator zréckgëtt wäert String Scheiwen zréckginn, déi Ënnerschnitter vun der ursprénglecher String Scheif sinn, getrennt vun all Wäissraum.
    ///
    ///
    /// 'Whitespace' gëtt definéiert no de Bedéngunge vum Unicode Derived Core Property `White_Space`.
    /// Wann Dir nëmmen op ASCII Wäissraum amplaz deele wëllt, benotzt [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// All Zort Wäissraum gëtt als:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Splitt e String Scheif vum ASCII Wäissraum.
    ///
    /// Den Iterator zréckgëtt wäert Stringplacke zréckginn, déi Ënnerscheiwen vun der ursprénglecher String Scheif sinn, getrennt vun all Betrag vun ASCII Wäissraum.
    ///
    ///
    /// Fir amplaz vun Unicode `Whitespace` opzedeelen, benotzt [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// All Zort ASCII Wäissraum gëtt als:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// En Iterator iwwer d'Linnen vun enger Schnouer, wéi Sträichschnëtt.
    ///
    /// Linnen ginn entweder mat enger Neilinn (`\n`) oder enger Kutscheréck mat enger Linnefütterung (`\r\n`) ofgeschloss.
    ///
    /// Déi lescht Zeilendung ass optional.
    /// Eng String déi mat engem Schlusslinn endet, wäert déiselwecht Linnen zréckschécken wéi en anescht identesche String ouni eng Schlusslinn.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Déi lescht Zeilendung ass net erfuerderlech:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// En Iterator iwwer d'Linnen vun engem String.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Nees en Iterator vun `u16` iwwer de String kodéiert als UTF-16.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Gitt `true` zréck wann de gegebene Muster mat engem Ënnerschnitt vun dësem Stringschnitt entsprécht.
    ///
    /// Retour `false` wann et net ass.
    ///
    /// Den [pattern] kann en `&str`, [`char`], e Stéck vun [`char`] s sinn, oder eng Funktioun oder Zoumaache déi bestëmmt ob e Charakter entsprécht.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Gitt `true` zréck wann de gegebene Muster mat engem Präfix vun dëser Stringplacke passt.
    ///
    /// Retour `false` wann et net ass.
    ///
    /// Den [pattern] kann en `&str`, [`char`], e Stéck vun [`char`] s sinn, oder eng Funktioun oder Zoumaache déi bestëmmt ob e Charakter entsprécht.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Gitt `true` zréck wann de gegebene Muster mat engem Suffix vun dëser Stringplacke passt.
    ///
    /// Retour `false` wann et net ass.
    ///
    /// Den [pattern] kann en `&str`, [`char`], e Stéck vun [`char`] s sinn, oder eng Funktioun oder Zoumaache déi bestëmmt ob e Charakter entsprécht.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Nees de Byte Index vum éischte Charakter vun dësem Stringschnitt dat dem Muster entsprécht.
    ///
    /// Retour [`None`] wann d'Muster net passt.
    ///
    /// Den [pattern] kann en `&str`, [`char`], e Stéck vun [`char`] s sinn, oder eng Funktioun oder Zoumaache déi bestëmmt ob e Charakter entsprécht.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Einfach Musteren:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Méi komplex Mustere mat punktfreie Stil a Fermeturen:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Net d'Muster fannen:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Nees de Byte Index fir den éischte Charakter vum rietsste Match vum Muster an dësem String Slice.
    ///
    /// Retour [`None`] wann d'Muster net passt.
    ///
    /// Den [pattern] kann en `&str`, [`char`], e Stéck vun [`char`] s sinn, oder eng Funktioun oder Zoumaache déi bestëmmt ob e Charakter entsprécht.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Einfach Musteren:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Méi komplex Mustere mat Zoumaache:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Net d'Muster fannen:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// En Iterator iwwer Ënnersträiche vun dësem Stringschnitt, getrennt vu Personnagen, déi mat engem Muster passend sinn.
    ///
    /// Den [pattern] kann en `&str`, [`char`], e Stéck vun [`char`] s sinn, oder eng Funktioun oder Zoumaache déi bestëmmt ob e Charakter entsprécht.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator Verhalen
    ///
    /// Den zréckgoen Iterator ass en [`DoubleEndedIterator`] wann d'Muster eng ëmgedréint Sich erlaabt an d forward/reverse Sich déi selwecht Elementer gëtt.
    /// Dëst ass richteg fir zB [`char`], awer net fir `&str`.
    ///
    /// Wann d'Muster eng ëmgedréint Sich erlaabt awer hir Resultater kéinten ënnerscheede vun enger Forward Sich, kann d [`rsplit`] Method benotzt ginn.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Einfach Musteren:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Wann d'Muster e Stéck Zeechen ass, deelt op all Optriede vun engem vun de Personnagen:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// E méi komplext Muster, mat enger Zoumaache:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Wann e String méi kontinuéierlech Separatoren enthält, da sidd Dir mat eidelen Zeilen am Output:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Uschléissend Trennere si getrennt vum eidele String.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Separatoren am Ufank oder um Enn vun enger Schnouer ginn duerch eidel Saiten noperéiert.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Wann déi eidel String als Separator benotzt gëtt, trennt se all Charakter am String, zesumme mam Ufank an Enn vum String.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Niewendrun Trennere kënnen zu méiglecherweis iwwerraschendem Verhalen féieren, wa Wäissraum als Separator benotzt gëtt.Dëse Code ass richteg:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Et gëtt _not_ Iech:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Benotzt [`split_whitespace`] fir dëst Verhalen.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// En Iterator iwwer Ënnersträiche vun dësem Stringschnitt, getrennt vu Personnagen, déi mat engem Muster passend sinn.
    /// Ënnerscheet sech vum Iterator, dee vum `split` produzéiert gëtt, an deem den `split_inclusive` de passenden Deel als Terminator vum Substring verléisst.
    ///
    ///
    /// Den [pattern] kann en `&str`, [`char`], e Stéck vun [`char`] s sinn, oder eng Funktioun oder Zoumaache déi bestëmmt ob e Charakter entsprécht.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Wann dat lescht Element vun der String mateneen ass, gëtt dat Element als den Terminator vun der viregter Substring ugesinn.
    /// Dëse Substring ass dat lescht Element vum Itator zréck.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// En Iterator iwwer Ënnersträiche vun der gegebene String Scheif, getrennt vu Personnagen, déi mat engem Muster ugepasst sinn an an der ëmgedréiter Uerdnung erginn.
    ///
    /// Den [pattern] kann en `&str`, [`char`], e Stéck vun [`char`] s sinn, oder eng Funktioun oder Zoumaache déi bestëmmt ob e Charakter entsprécht.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator Verhalen
    ///
    /// Den zréckgoen Iterator erfuerdert datt d'Muster eng Reverse Sich ënnerstëtzt, an et wäert en [`DoubleEndedIterator`] sinn wann eng forward/reverse Sich déi selwecht Elementer gëtt.
    ///
    ///
    /// Fir et vu vir ze iteréieren, kann d [`split`] Method benotzt ginn.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Einfach Musteren:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// E méi komplext Muster, mat enger Zoumaache:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// En Iterator iwwer Ënnersträiche vun der bestëmmter String Scheif, getrennt vu Personnagen, déi mat engem Muster passend sinn.
    ///
    /// Den [pattern] kann en `&str`, [`char`], e Stéck vun [`char`] s sinn, oder eng Funktioun oder Zoumaache déi bestëmmt ob e Charakter entsprécht.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Gläichwäerteg mat [`split`], ausser datt de verfolgte Substring iwwersprongen ass wann eidel ass.
    ///
    /// [`split`]: str::split
    ///
    /// Dës Method kann fir Stringdaten benotzt ginn déi _terminated_ ass, anstatt _separated_ duerch e Muster.
    ///
    /// # Iterator Verhalen
    ///
    /// Den zréckgoen Iterator ass en [`DoubleEndedIterator`] wann d'Muster eng ëmgedréint Sich erlaabt an d forward/reverse Sich déi selwecht Elementer gëtt.
    /// Dëst ass richteg fir zB [`char`], awer net fir `&str`.
    ///
    /// Wann d'Muster eng ëmgedréint Sich erlaabt awer hir Resultater kéinten ënnerscheede vun enger Forward Sich, kann d [`rsplit_terminator`] Method benotzt ginn.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// En Iterator iwwer Ënnersträiche vun `self`, getrennt vu Personnagen, déi mat engem Muster ugepasst sinn an an ëmgedréinter Uerdnung erginn.
    ///
    /// Den [pattern] kann en `&str`, [`char`], e Stéck vun [`char`] s sinn, oder eng Funktioun oder Zoumaache déi bestëmmt ob e Charakter entsprécht.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Gläichwäerteg mat [`split`], ausser datt de verfolgte Substring iwwersprongen ass wann eidel ass.
    ///
    /// [`split`]: str::split
    ///
    /// Dës Method kann fir Stringdaten benotzt ginn déi _terminated_ ass, anstatt _separated_ duerch e Muster.
    ///
    /// # Iterator Verhalen
    ///
    /// Den zréckgoen Iterator erfuerdert datt d'Muster eng Reverse Sich ënnerstëtzt, an et gëtt duebel ofgeschloss wann eng forward/reverse Sich déi selwecht Elementer bréngt.
    ///
    ///
    /// Fir et vu vir ze iteréieren, kann d [`split_terminator`] Method benotzt ginn.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// En Iterator iwwer Ënnersträiche vun der gegebene String Scheif, getrennt vun engem Muster, limitéiert op héchstens `n` Elementer zréckzekommen.
    ///
    /// Wann `n` Substrings zréckkomm sinn, enthält de leschte Substring (de 'n`th Substring) de Rescht vum String.
    ///
    /// Den [pattern] kann en `&str`, [`char`], e Stéck vun [`char`] s sinn, oder eng Funktioun oder Zoumaache déi bestëmmt ob e Charakter entsprécht.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator Verhalen
    ///
    /// Den zréckgoen Iterator gëtt net duebel ofgeschloss, well et net effizient ze ënnerstëtzen ass.
    ///
    /// Wann d'Muster eng Reverse Sich erlaabt, kann d [`rsplitn`] Method benotzt ginn.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Einfach Musteren:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// E méi komplext Muster, mat enger Zoumaache:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// En Iterator iwwer Ënnersträiche vun dëser String Scheif, getrennt vun engem Muster, ab dem Enn vum String, limitéiert op héchstens `n` Elementer zréckzekommen.
    ///
    ///
    /// Wann `n` Substrings zréckkomm sinn, enthält de leschte Substring (de 'n`th Substring) de Rescht vum String.
    ///
    /// Den [pattern] kann en `&str`, [`char`], e Stéck vun [`char`] s sinn, oder eng Funktioun oder Zoumaache déi bestëmmt ob e Charakter entsprécht.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator Verhalen
    ///
    /// Den zréckgoen Iterator gëtt net duebel ofgeschloss, well et net effizient ze ënnerstëtzen ass.
    ///
    /// Fir opzedeelen vu vir, kann d [`splitn`] Method benotzt ginn.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Einfach Musteren:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// E méi komplext Muster, mat enger Zoumaache:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Deelt de String um éischten Optriede vum spezifizéierten Delimiter a gëtt de Präfix virum Delimiter an de Suffix nom Delimiter zréck.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Deelt de String op der leschter Optriede vum spezifizéierten Delimiter a gëtt de Präfix virum Delimiter an de Suffix nom Delimiter zréck.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// En Iterator iwwer déi net getrennte Matcher vun engem Muster an der bestëmmter String Scheif.
    ///
    /// Den [pattern] kann en `&str`, [`char`], e Stéck vun [`char`] s sinn, oder eng Funktioun oder Zoumaache déi bestëmmt ob e Charakter entsprécht.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator Verhalen
    ///
    /// Den zréckgoen Iterator ass en [`DoubleEndedIterator`] wann d'Muster eng ëmgedréint Sich erlaabt an d forward/reverse Sich déi selwecht Elementer gëtt.
    /// Dëst ass richteg fir zB [`char`], awer net fir `&str`.
    ///
    /// Wann d'Muster eng ëmgedréint Sich erlaabt awer hir Resultater kéinten ënnerscheede vun enger Forward Sich, kann d [`rmatches`] Method benotzt ginn.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// En Iterator iwwer déi net getrennte Matcher vun engem Muster an dësem Stringschnëtt, erginn an ëmgedréint Uerdnung.
    ///
    /// Den [pattern] kann en `&str`, [`char`], e Stéck vun [`char`] s sinn, oder eng Funktioun oder Zoumaache déi bestëmmt ob e Charakter entsprécht.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator Verhalen
    ///
    /// Den zréckgoen Iterator erfuerdert datt d'Muster eng Reverse Sich ënnerstëtzt, an et wäert en [`DoubleEndedIterator`] sinn wann eng forward/reverse Sich déi selwecht Elementer gëtt.
    ///
    ///
    /// Fir et vu vir ze iteréieren, kann d [`matches`] Method benotzt ginn.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// En Iterator iwwer déi net getrennte Matcher vun engem Muster an dësem Stringschnëtt wéi och den Index wou de Match ufänkt.
    ///
    /// Fir Matcher vun `pat` bannent `self` déi sech iwwerschneiden, ginn nëmmen d'Indizes déi dem éischte Match entspriechen zréck.
    ///
    /// Den [pattern] kann en `&str`, [`char`], e Stéck vun [`char`] s sinn, oder eng Funktioun oder Zoumaache déi bestëmmt ob e Charakter entsprécht.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator Verhalen
    ///
    /// Den zréckgoen Iterator ass en [`DoubleEndedIterator`] wann d'Muster eng ëmgedréint Sich erlaabt an d forward/reverse Sich déi selwecht Elementer gëtt.
    /// Dëst ass richteg fir zB [`char`], awer net fir `&str`.
    ///
    /// Wann d'Muster eng ëmgedréint Sich erlaabt awer hir Resultater kéinten ënnerscheede vun enger Forward Sich, kann d [`rmatch_indices`] Method benotzt ginn.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // nëmmen déi éischt `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// En Iterator iwwer déi net getrennte Matcher vun engem Muster bannent `self`, an ëmgedréinter Uerdnung zesumme mam Index vum Match erginn.
    ///
    /// Fir Matcher vun `pat` bannent `self` déi sech iwwerschneiden, ginn nëmmen d'Indizes déi dem leschte Match entspriechen zréck.
    ///
    /// Den [pattern] kann en `&str`, [`char`], e Stéck vun [`char`] s sinn, oder eng Funktioun oder Zoumaache déi bestëmmt ob e Charakter entsprécht.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator Verhalen
    ///
    /// Den zréckgoen Iterator erfuerdert datt d'Muster eng Reverse Sich ënnerstëtzt, an et wäert en [`DoubleEndedIterator`] sinn wann eng forward/reverse Sich déi selwecht Elementer gëtt.
    ///
    ///
    /// Fir vu vir ze widderhuelen, kann d [`match_indices`] Method benotzt ginn.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // nëmmen déi lescht `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Returns eng String Scheif mat féierendem an hannendrun Wäissraum ewechgeholl.
    ///
    /// 'Whitespace' gëtt definéiert no de Bedéngunge vum Unicode Derived Core Property `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Returns eng String Scheif mat féierende Wäissraum ewechgeholl.
    ///
    /// 'Whitespace' gëtt definéiert no de Bedéngunge vum Unicode Derived Core Property `White_Space`.
    ///
    /// # Text Direktionalitéit
    ///
    /// E String ass eng Sequenz vu Bytes.
    /// `start` heescht an dësem Kontext déi éischt Positioun vun deem Byte String;fir eng lénks-no-riets Sprooch wéi Englesch oder Russesch, wäert dat lénks Säit sinn, a fir riets-no-lénks Sprooche wéi Arabesch oder Hebräesch, wäert dat déi riets Säit sinn.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Returns eng String Scheif mat schleefenden Wäissraum ewechgeholl.
    ///
    /// 'Whitespace' gëtt definéiert no de Bedéngunge vum Unicode Derived Core Property `White_Space`.
    ///
    /// # Text Direktionalitéit
    ///
    /// E String ass eng Sequenz vu Bytes.
    /// `end` heescht an dësem Kontext déi lescht Positioun vun deem Byte String;fir eng lénks-no-riets Sprooch wéi Englesch oder Russesch, wäert dat riets sinn, a fir riets-no-lénks Sprooche wéi Arabesch oder Hebräesch, wäert dat déi lénks Säit sinn.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Returns eng String Scheif mat féierende Wäissraum ewechgeholl.
    ///
    /// 'Whitespace' gëtt definéiert no de Bedéngunge vum Unicode Derived Core Property `White_Space`.
    ///
    /// # Text Direktionalitéit
    ///
    /// E String ass eng Sequenz vu Bytes.
    /// 'Left' heescht an dësem Kontext déi éischt Positioun vun deem Byte String;fir eng Sprooch wéi Arabesch oder Hebräesch déi 'riets op lénks' anstatt 'lénks op riets' ass, wäert dëst d _right_ Säit sinn, net déi lénks.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Returns eng String Scheif mat schleefenden Wäissraum ewechgeholl.
    ///
    /// 'Whitespace' gëtt definéiert no de Bedéngunge vum Unicode Derived Core Property `White_Space`.
    ///
    /// # Text Direktionalitéit
    ///
    /// E String ass eng Sequenz vu Bytes.
    /// 'Right' heescht an dësem Kontext déi lescht Positioun vun deem Byte String;fir eng Sprooch wéi Arabesch oder Hebräesch déi 'riets op lénks' anstatt 'lénks op riets' ass, wäert dëst d _left_ Säit sinn, net déi richteg.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Returns e Stringschnitt mat allen Präfixen an Suffixer déi mat engem Muster passend ëmmer erëm ewechgeholl ginn.
    ///
    /// Den [pattern] kann en [`char`] sinn, e Stéck vun [`char`] s, oder eng Funktioun oder Zoumaache déi bestëmmt ob e Charakter entsprécht.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Einfach Musteren:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// E méi komplext Muster, mat enger Zoumaache:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Denkt un de fréiste bekannte Match, korrigéiert et hei ënnen wann
            // leschte Match anescht ass
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SAFETY: `Searcher` ass bekannt fir gëlteg Indizes zréckzeginn.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Gitt e Stringschnëtt mat alle Präfixen, déi engem Muster stëmmen, deen ëmmer erëm ewechgeholl gëtt.
    ///
    /// Den [pattern] kann en `&str`, [`char`], e Stéck vun [`char`] s sinn, oder eng Funktioun oder Zoumaache déi bestëmmt ob e Charakter entsprécht.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Text Direktionalitéit
    ///
    /// E String ass eng Sequenz vu Bytes.
    /// `start` heescht an dësem Kontext déi éischt Positioun vun deem Byte String;fir eng lénks-no-riets Sprooch wéi Englesch oder Russesch, wäert dat lénks Säit sinn, a fir riets-no-lénks Sprooche wéi Arabesch oder Hebräesch, wäert dat déi riets Säit sinn.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // SAFETY: `Searcher` ass bekannt fir gëlteg Indizes zréckzeginn.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Returns eng String Scheif mam Präfix ewechgeholl.
    ///
    /// Wann de String mam Muster `prefix` ufänkt, gëtt de Substring nom Präfix zréck, gewéckelt an `Some`.
    /// Am Géigesaz zu `trim_start_matches` läscht dës Method de Präfix exakt eemol.
    ///
    /// Wann de String net mat `prefix` ufänkt, gëtt `None` zréck.
    ///
    /// Den [pattern] kann en `&str`, [`char`], e Stéck vun [`char`] s sinn, oder eng Funktioun oder Zoumaache déi bestëmmt ob e Charakter entsprécht.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Returns eng String Scheif mam Suffix ewechgeholl.
    ///
    /// Wann de String mam Muster `suffix` endet, gëtt de Substring virum Suffix zréck, gewéckelt an `Some`.
    /// Am Géigesaz zu `trim_end_matches` hëlt dës Method de Suffix exakt eemol ewech.
    ///
    /// Wann de String net mat `suffix` ophält, gëtt `None` zréck.
    ///
    /// Den [pattern] kann en `&str`, [`char`], e Stéck vun [`char`] s sinn, oder eng Funktioun oder Zoumaache déi bestëmmt ob e Charakter entsprécht.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Gitt e Stringschnëtt mat all Suffixen, déi engem Muster entspriechen, deen ëmmer erëm ewechgeholl gëtt.
    ///
    /// Den [pattern] kann en `&str`, [`char`], e Stéck vun [`char`] s sinn, oder eng Funktioun oder Zoumaache déi bestëmmt ob e Charakter entsprécht.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Text Direktionalitéit
    ///
    /// E String ass eng Sequenz vu Bytes.
    /// `end` heescht an dësem Kontext déi lescht Positioun vun deem Byte String;fir eng lénks-no-riets Sprooch wéi Englesch oder Russesch, wäert dat riets sinn, a fir riets-no-lénks Sprooche wéi Arabesch oder Hebräesch, wäert dat déi lénks Säit sinn.
    ///
    ///
    /// # Examples
    ///
    /// Einfach Musteren:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// E méi komplext Muster, mat enger Zoumaache:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SAFETY: `Searcher` ass bekannt fir gëlteg Indizes zréckzeginn.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Gitt e Stringschnëtt mat alle Präfixen, déi engem Muster stëmmen, deen ëmmer erëm ewechgeholl gëtt.
    ///
    /// Den [pattern] kann en `&str`, [`char`], e Stéck vun [`char`] s sinn, oder eng Funktioun oder Zoumaache déi bestëmmt ob e Charakter entsprécht.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Text Direktionalitéit
    ///
    /// E String ass eng Sequenz vu Bytes.
    /// 'Left' heescht an dësem Kontext déi éischt Positioun vun deem Byte String;fir eng Sprooch wéi Arabesch oder Hebräesch déi 'riets op lénks' anstatt 'lénks op riets' ass, wäert dëst d _right_ Säit sinn, net déi lénks.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Gitt e Stringschnëtt mat all Suffixen, déi engem Muster entspriechen, deen ëmmer erëm ewechgeholl gëtt.
    ///
    /// Den [pattern] kann en `&str`, [`char`], e Stéck vun [`char`] s sinn, oder eng Funktioun oder Zoumaache déi bestëmmt ob e Charakter entsprécht.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Text Direktionalitéit
    ///
    /// E String ass eng Sequenz vu Bytes.
    /// 'Right' heescht an dësem Kontext déi lescht Positioun vun deem Byte String;fir eng Sprooch wéi Arabesch oder Hebräesch déi 'riets op lénks' anstatt 'lénks op riets' ass, wäert dëst d _left_ Säit sinn, net déi richteg.
    ///
    ///
    /// # Examples
    ///
    /// Einfach Musteren:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// E méi komplext Muster, mat enger Zoumaache:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Parséiert dës String Scheif an eng aner Aart.
    ///
    /// Well `parse` sou allgemeng ass, kann et Probleemer mat Type Inferenz verursaachen.
    /// Als sou ass `parse` ee vun de wéinegen Zäiten déi Dir d'Syntax gesinn, déi als 'turbofish' bekannt ass: `::<>`.
    ///
    /// Dëst hëlleft den Inferenz Algorithmus speziell ze verstoen zu wéi engem Typ Dir probéiert ze analyséieren.
    ///
    /// `parse` kann an all Typ analyséieren deen den [`FromStr`] trait implementéiert.
    ///

    /// # Errors
    ///
    /// Gitt [`Err`] zréck wann et net méiglech ass dës Stringschnëtt an de gewënschten Typ ze analyséieren.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Basis Benotzung
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Mat der 'turbofish' amplaz `four` ze annotéieren:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Versoen net ze analyséieren:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Kontrolléiert ob all Personnagen an dësem String bannent dem ASCII Beräich sinn.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Mir kënnen all Byte als Charakter hei behandelen: all Multibyte Charaktere fänke mat engem Byte un, deen net am Ascii-Beräich ass, also stoppe mir schonn do.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Kontrolléiert datt zwou Saiten en ASCII Fall-onempfindleche Match sinn.
    ///
    /// Selwecht wéi `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, awer ouni temporäre ze allocéieren an ze kopéieren.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Konvertéiert dëse String zu sengem ASCII-Uewerfall gläichwäerteg op der Plaz.
    ///
    /// ASCII Buschtawen 'a' op 'z' ginn op 'A' op 'Z', awer net ASCII Bréiwer sinn onverännert.
    ///
    /// Fir en neie geschriwwene Wäert zréckzebréngen ouni dee bestehenden ze änneren, benotzt [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // SAFETY: sécher well mir zwou Aarte mam selwechte Layout transmutéieren.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Konvertéiert dëse String op säin ASCII klenggeschriwwenequivalent op der Plaz.
    ///
    /// ASCII Buschtawen 'A' op 'Z' ginn op 'a' op 'z', awer net ASCII Bréiwer sinn onverännert.
    ///
    /// Fir en neie méi nidderege Wäert zréckzebréngen ouni dee bestehenden ze änneren, benotzt [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // SAFETY: sécher well mir zwou Aarte mam selwechte Layout transmutéieren.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Gitt en Iterator zréck, deen all Char am `self` mat [`char::escape_debug`] entkommt.
    ///
    ///
    /// Note: nëmmen erweidert Graphem Codepunkten déi de String ufänken ginn entkomm.
    ///
    /// # Examples
    ///
    /// Als Iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` direkt benotzen:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Béid si gläichwäerteg wéi:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Mat `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Gitt en Iterator zréck, deen all Char am `self` mat [`char::escape_default`] entkommt.
    ///
    ///
    /// # Examples
    ///
    /// Als Iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` direkt benotzen:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Béid si gläichwäerteg wéi:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Mat `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Gitt en Iterator zréck, deen all Char am `self` mat [`char::escape_unicode`] entkommt.
    ///
    ///
    /// # Examples
    ///
    /// Als Iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` direkt benotzen:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Béid si gläichwäerteg wéi:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Mat `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Erstellt en eidelen Str
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Erstellt eng eidel mutabel Str
    #[inline]
    fn default() -> Self {
        // SAFETY: Déi eidel String ass valabel UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// E benennbaren, klonéierbaren fn Typ
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // SAFETY: net sécher
        unsafe { from_utf8_unchecked(bytes) }
    };
}