//! Weeër fir en `str` aus Bytes Slice ze kreéieren.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Konvertéiert e Stéck Bytes an e Stringschnitt.
///
/// E String Slice ([`&str`]) ass aus Bytes ([`u8`]) gemaach, an e Bytes Slice ([`&[u8]`][byteslice]) ass aus Bytes gemaach, sou datt dës Funktioun tëscht deenen zwee konvertéiert.
/// Net all Byte Scheiwen si valabel String Scheiwen, awer: [`&str`] erfuerdert datt et gëlteg UTF-8 ass.
/// `from_utf8()` kontrolléiert fir sécherzestellen datt d'Bytes gëlteg UTF-8 sinn, an dann d'Konversioun mécht.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Wann Dir sécher sidd datt de Byte Slice gëlteg ass UTF-8, an Dir wëllt net d'Iwwerleeung vun der Validitéitskontroll maachen, et gëtt eng onsécher Versioun vun dëser Funktioun, [`from_utf8_unchecked`], déi déiselwecht Verhalen huet awer iwwerpréift de Scheck.
///
///
/// Wann Dir en `String` amplaz en `&str` braucht, da kuckt [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Well Dir en `[u8; N]` stack-allocéiere kënnt, an Dir kënnt en [`&[u8]`][byteslice] dovun huelen, ass dës Funktioun e Wee fir e Stack-allocéierte String ze hunn.Et gëtt e Beispill dovun an der Beispiller hei ënnendrënner.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Retour `Err` wann d'Scheif net UTF-8 ass mat enger Beschreiwung firwat de verschaffene Slice net UTF-8 ass.
///
/// # Examples
///
/// Basis Benotzung:
///
/// ```
/// use std::str;
///
/// // e puer Bytes, an engem vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Mir wëssen datt dës Bytes gëlteg sinn, also benotzt just `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Falsch Bytes:
///
/// ```
/// use std::str;
///
/// // e puer ongëlteg Bytes, an engem vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Kuckt d'Dokumenter fir [`Utf8Error`] fir méi Detailer iwwer d'Zorte vu Feeler déi zréckginn kënne ginn.
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // e puer Bytes, an engem stack-allocéierten Array
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Mir wëssen datt dës Bytes gëlteg sinn, also benotzt just `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // SAFETY: Just leeft Validatioun.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Konvertéiert e mutabelt Stéck Bytes an e mutable String Slice.
///
/// # Examples
///
/// Basis Benotzung:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" als mutéierbar vector
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Wéi mir wëssen datt dës Bytes gëlteg sinn, kënne mir `unwrap()` benotzen
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Falsch Bytes:
///
/// ```
/// use std::str;
///
/// // E puer ongëlteg Bytes an engem mutablen vector
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Kuckt d'Dokumenter fir [`Utf8Error`] fir méi Detailer iwwer d'Zorte vu Feeler déi zréckginn kënne ginn.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // SAFETY: Just leeft Validatioun.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Konvertéiert e Stéck Bytes an e Stringschnitt ouni ze kontrolléieren datt de String gëlteg UTF-8 enthält.
///
/// Kuckt déi sécher Versioun, [`from_utf8`], fir méi Informatiounen.
///
/// # Safety
///
/// Dës Funktioun ass onsécher well se net kontrolléiert datt d'Bytes, déi u si weiderginn, valabel UTF-8 sinn.
/// Wann dës Beschränkung verletzt gëtt, kënnt ondefinéiert Verhalen, well de Rescht vun Rust geet dovun aus datt [`&str`] s valabel UTF-8 sinn.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Basis Benotzung:
///
/// ```
/// use std::str;
///
/// // e puer Bytes, an engem vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // SAFETY: den Uruffer muss garantéieren datt d'Bytes `v` gëlteg UTF-8 sinn.
    // Verléisst och op `&str` an `&[u8]` mat dem selwechte Layout.
    unsafe { mem::transmute(v) }
}

/// Konvertéiert e Stéck Bytes an e Stringschnitt ouni ze kontrolléieren datt de String gëlteg UTF-8 enthält;mutéierbar Versioun.
///
///
/// Kuckt déi onverännerbar Versioun, [`from_utf8_unchecked()`] fir méi Informatioun.
///
/// # Examples
///
/// Basis Benotzung:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // SAFETY: den Uruffer muss garantéieren datt d'Bytes `v`
    // si valabel UTF-8, also ass de Besetzung op `*mut str` sécher.
    // Och den Zeiger Dereferenz ass sécher, well dee Zeiger kënnt aus enger Referenz déi garantéiert gëlteg ass fir ze schreiwen.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}