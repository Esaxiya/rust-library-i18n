//! Trait Implementatiounen fir `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Ëmsetzt Bestellung vu Stréckelen.
///
/// Strings ginn [lexicographically](Ord#lexicographical-comparison) no hire Byte Wäerter bestallt.
/// Dëst bestellt Unicode Code Punkten op Basis vun hire Positiounen an de Code Charts.
/// Dëst ass net onbedéngt déiselwecht wéi d "alphabetical" Bestellung, déi variéiert no Sprooch a Lokal.
/// Strings sortéieren no kulturell akzeptéierte Standarden erfuerdert lokal spezifesch Donnéeën, déi ausserhalb vum Ëmfang vum `str` Typ sinn.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Ëmsetzt Verglach Operatiounen op Strécker.
///
/// Strings ginn [lexicographically](Ord#lexicographical-comparison) mat hire Byte Wäerter verglach.
/// Dëst vergläicht Unicode Code Punkten op Basis vun hire Positiounen an de Code Charts.
/// Dëst ass net onbedéngt déiselwecht wéi d "alphabetical" Bestellung, déi variéiert no Sprooch a Lokal.
/// Sträiche vergläichen no kulturell akzeptéierte Standarden erfuerderen lokalspezifesch Daten, déi ausserhalb vum Ëmfang vum `str`-Typ sinn.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Implementéiert Substring Scheiwen mat Syntax `&self[..]` oder `&mut self[..]`.
///
/// Returns e Stéck vun der ganzer String, dh zréck `&self` oder `&mut self`.Äquivalent mat `&selwer [0 ..
/// len] `oder`&mut selwer [0 ..
/// len]`.
/// Am Géigesaz zu anere Indexéierungsoperatiounen kann dëst ni panic.
///
/// Dës Operatioun ass *O*(1).
///
/// Virun 1.20.0 goufen dës Indexéierungsoperatiounen nach ëmmer duerch direkt Implementatioun vun `Index` an `IndexMut` ënnerstëtzt.
///
/// Gläichwäerteg mat `&self[0 .. len]` oder `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Implementéiert Substring Scheiwen mat Syntax `&self[begin .. end]` oder `&mut self[begin .. end]`.
///
/// Gitt e Stéck vun der gegebene String aus dem Bytesbereich [`ufänken", `end`).
///
/// Dës Operatioun ass *O*(1).
///
/// Virun 1.20.0 goufen dës Indexéierungsoperatiounen nach ëmmer duerch direkt Implementatioun vun `Index` an `IndexMut` ënnerstëtzt.
///
/// # Panics
///
/// Panics wann `begin` oder `end` net op de Startbyte Offset vun engem Charakter hiweisen (wéi definéiert vum `is_char_boundary`), wann `begin > end`, oder wann `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // dës wäerten panic:
/// // Byte 2 läit am `ö`:
/// // &s [2 ..3];
///
/// // Byte 8 läit bannent `老`&s [1 ..
/// // 8];
///
/// // Byte 100 ass ausserhalb vum String&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SAFETY: just kontrolléiert datt `start` an `end` op enger Char Grenz sinn,
            // a mir ginn an enger sécherer Referenz laanscht, sou datt de Retourwäert och een ass.
            // Mir hunn och Char Grenze kontrolléiert, also ass dat gëlteg UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SAFETY: just iwwerpréift datt `start` an `end` op enger Char Grenz sinn.
            // Mir wëssen datt de Zeiger eenzegaarteg ass, well mir hunn et vum `slice` kritt.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SAFETY: den Uruff garantéiert datt `self` a Grenzen vun `slice` ass
        // déi all d'Konditioune fir `add` erfëllen.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SAFETY: kuckt Kommentare fir `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary kontrolléiert datt den Index an [0 ass, .len()] kann net `get` wéi uewe weiderginn, wéinst NLL Probleemer
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SAFETY: just kontrolléiert datt `start` an `end` op enger Char Grenz sinn,
            // a mir ginn an enger sécherer Referenz laanscht, sou datt de Retourwäert och een ass.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Implementéiert Substring Scheiwen mat Syntax `&self[.. end]` oder `&mut self[.. end]`.
///
/// Gitt e Stéck vun der gegebene String aus dem Byteberäich [`0`, `end`).
/// Gläichwäerteg mat `&self[0 .. end]` oder `&mut self[0 .. end]`.
///
/// Dës Operatioun ass *O*(1).
///
/// Virun 1.20.0 goufen dës Indexéierungsoperatiounen nach ëmmer duerch direkt Implementatioun vun `Index` an `IndexMut` ënnerstëtzt.
///
/// # Panics
///
/// Panics wann `end` net op de Startbyte Offset vun engem Charakter hiweist (wéi definéiert vum `is_char_boundary`), oder wann `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SAFETY: just kontrolléiert datt `end` op enger Char Grenz ass,
            // a mir ginn an enger sécherer Referenz laanscht, sou datt de Retourwäert och een ass.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SAFETY: just kontrolléiert datt `end` op enger Char Grenz ass,
            // a mir ginn an enger sécherer Referenz laanscht, sou datt de Retourwäert och een ass.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // SAFETY: just kontrolléiert datt `end` op enger Char Grenz ass,
            // a mir ginn an enger sécherer Referenz laanscht, sou datt de Retourwäert och een ass.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Implementéiert Substring Scheiwen mat Syntax `&self[begin ..]` oder `&mut self[begin ..]`.
///
/// Gitt e Stéck vun der gegebene String aus dem Bytesbereich [`ufänken", `len`).Äquivalent mat `&selwer [fänken ..
/// len] `oder`&mut selwer [fänken ..
/// len]`.
///
/// Dës Operatioun ass *O*(1).
///
/// Virun 1.20.0 goufen dës Indexéierungsoperatiounen nach ëmmer duerch direkt Implementatioun vun `Index` an `IndexMut` ënnerstëtzt.
///
/// # Panics
///
/// Panics wann `begin` net op de Startbyte Offset vun engem Charakter hiweist (wéi definéiert vum `is_char_boundary`), oder wann `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SAFETY: just kontrolléiert datt `start` op enger Char Grenz ass,
            // a mir ginn an enger sécherer Referenz laanscht, sou datt de Retourwäert och een ass.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SAFETY: just kontrolléiert datt `start` op enger Char Grenz ass,
            // a mir ginn an enger sécherer Referenz laanscht, sou datt de Retourwäert och een ass.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SAFETY: den Uruff garantéiert datt `self` a Grenzen vun `slice` ass
        // déi all d'Konditioune fir `add` erfëllen.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SAFETY: identesch mat `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // SAFETY: just kontrolléiert datt `start` op enger Char Grenz ass,
            // a mir ginn an enger sécherer Referenz laanscht, sou datt de Retourwäert och een ass.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Implementéiert Substring Scheiwen mat Syntax `&self[begin ..= end]` oder `&mut self[begin ..= end]`.
///
/// Nees e Stéck vun der gegebene String aus dem Byteberäich [`begin`, `end`].Gläichwäerteg mat `&self [begin .. end + 1]` oder `&mut self[begin .. end + 1]`, ausser wann `end` de maximale Wäert fir `usize` huet.
///
/// Dës Operatioun ass *O*(1).
///
/// # Panics
///
/// Panics wann `begin` net op de Startbyte Offset vun engem Charakter hiweist (wéi definéiert vum `is_char_boundary`), wann `end` net op den Endbyte Offset vun engem Charakter hiweist (`end + 1` ass entweder e Startbyte Offset oder gläich wéi `len`), wann `begin > end`, oder wann `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SAFETY: den Uruff muss de Sécherheetsvertrag fir `get_unchecked` oprechterhalen.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SAFETY: den Uruff muss de Sécherheetsvertrag fir `get_unchecked_mut` oprechterhalen.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Implementéiert Substring Scheiwen mat Syntax `&self[..= end]` oder `&mut self[..= end]`.
///
/// Nees e Stéck vun der gegebene String aus dem Byteberäich [0, `end`].
/// Äquivalent mam `&self [0 .. end + 1]`, ausser wann `end` de maximale Wäert fir `usize` huet.
///
/// Dës Operatioun ass *O*(1).
///
/// # Panics
///
/// Panics wann `end` net op de Schlussbyte Offset vun engem Charakter hiweist (`end + 1` ass entweder e Startbyte Offset wéi definéiert vum `is_char_boundary`, oder gläich wéi `len`), oder wann `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SAFETY: den Uruff muss de Sécherheetsvertrag fir `get_unchecked` oprechterhalen.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SAFETY: den Uruff muss de Sécherheetsvertrag fir `get_unchecked_mut` oprechterhalen.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Analyséiert e Wäert vun enger Seel
///
/// D [`from_str`] Method vun `FromStr` gëtt dacks implizit benotzt, duerch d [`parse`] Method vun [`str`].
/// Kuckt d'Dokumentatioun vum [`parse`] fir Beispiller.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` huet kee Liewensdauer Parameter, a sou kënnt Dir nëmmen Aarte analyséieren déi selwer kee Liewensdauer Parameter enthalen.
///
/// An anere Wierder, Dir kënnt en `i32` mat `FromStr` analyséieren, awer net en `&i32`.
/// Dir kënnt e Struct analyséieren deen en `i32` enthält, awer net deen deen en `&i32` enthält.
///
/// # Examples
///
/// Basis Ëmsetzung vun `FromStr` op e Beispill `Point` Typ:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Den assoziéierte Feeler deen aus der Parsing zréck kënnt.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Analyséiert e String `s` fir e Wäert vun dësem Typ zréckzeginn.
    ///
    /// Wann Parsing erfollegräich ass, bréngt de Wäert bannent [`Ok`] zréck, soss wann d'Strang krankformatéiert ass, gëtt e Feeler spezifesch fir de bannenzeg [`Err`] zréck.
    /// De Feelertyp ass spezifesch fir d'Ëmsetzung vum trait.
    ///
    /// # Examples
    ///
    /// Basisbenotzung mat [`i32`], en Typ deen `FromStr` implementéiert:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Parse en `bool` vun engem String.
    ///
    /// Gitt e `Result<bool, ParseBoolError>`, well `s` kann oder net tatsächlech parséierbar sinn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Notiz, a ville Fäll ass d `.parse()` Method op `str` méi richteg.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}