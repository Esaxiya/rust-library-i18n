//! Definéiert utf8 Feelertyp.

use crate::fmt;

/// Feeler déi optriede kënnen wann een eng Sequenz vun [`u8`] als String interpretéiert.
///
/// Als sou benotzt d `from_utf8` Famill vu Funktiounen a Methoden fir béid [`String`] s an [`&str`] s dëse Feeler, zum Beispill.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Dës Methode vun dësem Feelertyp kënne benotzt ginn fir Funktionalitéit ähnlech wéi `String::from_utf8_lossy` ze kreéieren ouni Heap Memory ze allocéieren:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Gitt den Index an der gegebene String zréck, bis déi gëlteg UTF-8 verifizéiert gouf.
    ///
    /// Et ass de maximalen Index sou datt `from_utf8(&input[..index])` `Ok(_)` zréckbréngt.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// use std::str;
    ///
    /// // e puer ongëlteg Bytes, an engem vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 bréngt en Utf8Error zréck
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // den zweeten Byte ass hei ongëlteg
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Bitt méi Informatiounen iwwer de Feeler:
    ///
    /// * `None`: d'Enn vum Input gouf onerwaart erreecht.
    ///   `self.valid_up_to()` ass 1 bis 3 Bytes vum Enn vum Input.
    ///   Wann e Byte Stream (wéi eng Datei oder e Netzwierksocket) inkrementell dekodéiert gëtt, kann dëst e gëltege `char` sinn, deem seng UTF-8 Byte Sequenz iwwer verschidde Stécker ass.
    ///
    ///
    /// * `Some(len)`: en onerwaartene Byte gouf begéint.
    ///   D'Längt zur Verfügung gestallt ass déi vun der ongülteger Byte-Sequenz déi um Index ufänkt vun `valid_up_to()`.
    ///   Decodéiere soll no där Sequenz (nodeems se en [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] agefouert hunn) am Fall vu verloschterer Entschlësselung weidergoen.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// E Feeler zréck wann d'Parséiere vun engem `bool` mat [`from_str`] feelt
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}