//! Panic Ënnerstëtzung an der Standardbibliothéik.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// E Struktur deen Informatioun iwwer en panic ubitt.
///
/// `PanicInfo` Struktur gëtt un en panic hook weidergeleet vun der [`set_hook`] Funktioun gesat.
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// Retourneiert d'Notzlaascht verbonne mam panic.
    ///
    /// Dëst wäert allgemeng, awer net ëmmer, en `&'static str` oder [`String`] sinn.
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// Wann den `panic!` Macro vum `core` crate (net vun `std`) mat enger Formatéierungsstreng an e puer zousätzlech Argumenter benotzt gouf, gëtt dës Noriicht fäerdeg fir zum Beispill mat [`fmt::write`] benotzt ze ginn
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// Gitt Informatiounen iwwer de Standuert vun deem den panic entstanen ass, wann verfügbar.
    ///
    /// Dës Method wäert de Moment ëmmer [`Some`] zréckginn, awer dëst kann an future Versiounen änneren.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: Wann dëst geännert gëtt fir heiansdo Keen zréckzeginn,
        // mat deem Fall an std::panicking::default_hook an std::panicking::begin_panic_fmt eens ginn.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: mir kënnen net downcast_ref: :<String>() hei
        // well String net an libcore verfügbar ass!
        // D'Notzlaascht ass e String wann `std::panic!` mat méi Argumenter genannt gëtt, awer an deem Fall ass d'Botschaft och verfügbar.
        //

        self.location.fmt(formatter)
    }
}

/// E Struktur mat Informatioun iwwer d'Location vun engem panic.
///
/// Dës Struktur gëtt vum [`PanicInfo::location()`] erstallt.
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// Vergläicher fir Gläichberechtegung a Bestellung ginn an der Datei gemaach, Linn, da Spaltprioritéit.
/// Dateie ginn als Sträicher verglach, net `Path`, wat onerwaart kéint sinn.
/// Kuckt d'Dokumentatioun vum [`Location: : file`] fir méi Diskussioun.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// Gitt d'Quellplaz vum Uruff vun dëser Funktioun zréck.
    /// Wann de Ruff vun där Funktioun annotéiert ass, da gëtt seng Uruffplaz zréckgesat, a sou weider de Stack op den éischten Uruff an engem net verfolgte Funktiounskierper.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// Nees den [`Location`] op deen e genannt gëtt.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// Nees en [`Location`] aus der Definitioun vun dëser Funktioun.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // déiselwecht net verfollegt Funktioun op enger anerer Plaz ze lafen gëtt eis datselwecht Resultat
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // déi verfollegt Funktioun op enger anerer Plaz auszeféieren produzéiert en anere Wäert
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// Gitt den Numm vun der Quelldatei zréck, aus där den panic entstanen ass.
    ///
    /// # `&str`, net `&Path`
    ///
    /// Den zréckgezunnene Numm bezitt sech op e Quellwee um Kompiléierungssystem, awer et ass net valabel dëst direkt als `&Path` duerzestellen.
    /// De kompiléierte Code kann op engem anere System mat enger anerer `Path`-Implementatioun lafen wéi de System deen den Inhalt liwwert an dës Bibliothéik huet de Moment keen aneren "host path"-Typ.
    ///
    /// Dat iwwerraschendst Verhalen tritt op wann d "the same" Datei iwwer verschidde Weeër am Modul System erreechbar ass (normalerweis mam `#[path = "..."]` Attribut oder ähnlech), wat ka verursaache wat identesch Code schéngt verschidde Wäerter vun dëser Funktioun zréckzeginn.
    ///
    ///
    /// # Cross-compilation
    ///
    /// Dëse Wäert ass net gëeegent fir op `Path::new` oder ähnlech Konstruktoren ze goen, wann d'Hostplattform an d'Zilplattform ënnerscheeden.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// Gitt d'Linnennummer zréck vun där den panic entstanen ass.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// Gitt d'Kolonn zréck aus där den panic entstanen ass.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// Eng intern trait benotzt vun libstd fir Date vun libstd op `panic_unwind` an aner panic Betriebsdauer ze weiderginn.
/// Net geduecht fir séier ze stabiliséieren, net benotzt.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// Huelt voll Besëtz vum Inhalt.
    /// De Retourtyp ass tatsächlech `Box<dyn Any + Send>`, awer mir kënnen `Box` net an libcore benotzen.
    ///
    /// Nodeems dës Method ugeruff gouf, bleift nëmmen e puer Dummy-Standardwäerter am `self`.
    /// Dës Method zweemol uruffen oder `get` uruffen nodeems Dir dës Method genannt hutt, ass e Feeler.
    ///
    /// D'Argument gëtt ausgeléint well d'panic Runtime (`__rust_start_panic`) nëmmen e geléinte `dyn BoxMeUp` kritt.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// Prêt just den Inhalt.
    fn get(&mut self) -> &(dyn Any + Send);
}