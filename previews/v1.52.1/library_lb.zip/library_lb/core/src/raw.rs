#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Enthält struct Definitioune fir de Layout vu Compiler agebauten Typen.
//!
//! Si kënnen als Ziler vun Transmuter an onsécherem Code benotzt ginn fir déi réi Representatioune direkt ze manipuléieren.
//!
//!
//! Hir Definitioun soll ëmmer mat dem ABI definéieren, deen an `rustc_middle::ty::layout` definéiert ass.
//!

/// D'Representatioun vun engem trait Objet wéi `&dyn SomeTrait`.
///
/// Dëse Struktur huet dee selwechte Layout wéi Aarte wéi `&dyn SomeTrait` an `Box<dyn AnotherTrait>`.
///
/// `TraitObject` ass garantéiert Layouten ze passen, awer et ass net d'Zort vun trait Objeten (z. B. d'Felder sinn net direkt zougänglech op engem `&dyn SomeTrait`) an et kontrolléiert och net dee Layout (d'Definitioun änneren ännert de Layout vun engem `&dyn SomeTrait` net).
///
/// Et ass nëmmen entwéckelt fir vum onséchere Code benotzt ze ginn, deen déi niddereg Niveau Detailer manipuléiere muss.
///
/// Et gëtt kee Wee fir all trait Objekter generesch ze bezeechnen, also ass deen eenzege Wee fir Wäerter vun dësem Typ ze kreéiere mat Funktiounen wéi [`std::mem::transmute`][transmute].
/// Ähnlech ass deen eenzege Wee fir e richtegen trait Objet aus engem `TraitObject` Wäert ze kreéieren mat `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Synthetiséiere vun engem trait Objet mat net passenden Typen-eent wou de vtable net der Aart vum Wäert entsprécht op deen den Datezeiger weist-ass héchstwahrscheinlech zu ondefinéiertem Verhalen.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // e Beispill trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // loosst de Compiler en trait Objet maachen
/// let object: &dyn Foo = &value;
///
/// // kuckt op d'Ro Representatioun
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // den Datenzeiger ass d'Adress vun `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // konstruéiert en neien Objet, weist op en aneren `i32`, passt op d `i32`-Tabelle vun `object` ze benotzen
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // et sollt funktionnéieren sou wéi wa mir en trait Objet aus `other_value` direkt gebaut hätten
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}