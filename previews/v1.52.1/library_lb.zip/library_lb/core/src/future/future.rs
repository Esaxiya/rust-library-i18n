#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// En future stellt eng asynchron Berechnung duer.
///
/// En future ass e Wäert dee vläicht nach net fäerdeg war ze berechnen.
/// Dës Zort vun "asynchronous value" mécht et méiglech fir e Fuedem weider nëtzlech Aarbecht ze maachen wärend et waart op de Wäert verfügbar ass.
///
///
/// # D `poll` Method
///
/// D'Kärmethod vun future, `poll`,*probéiert* den future an e leschte Wäert ze léisen.
/// Dës Method blockéiert net wann de Wäert net fäerdeg ass.
/// Amplaz ass d'aktuell Aufgab geplangt ze erwächen wann et méiglech ass weider Fortschrëtter ze maachen andeems Dir nach eng Kéier "polling".
/// Den `context`, deen op d `poll` Method weidergeleet gëtt, kann en [`Waker`] ubidden, wat e Grëff ass fir déi aktuell Aufgab ze erwächen.
///
/// Wann Dir en future benotzt, rufft Dir normalerweis net `poll` direkt un, awer statt `.await` de Wäert.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Déi Aart vu Wäert produzéiert nom Ofschloss.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Probéiert den future zu engem definitive Wäert ze léisen, andeems Dir déi aktuell Aufgab fir Wakeup registréiert wann de Wäert nach net verfügbar ass.
    ///
    /// # Retour Wäert
    ///
    /// Dës Funktioun gëtt zréck:
    ///
    /// - [`Poll::Pending`] wann den future nach net fäerdeg ass
    /// - [`Poll::Ready(val)`] mam Resultat `val` vun dësem future wann et erfollegräich fäerdeg war.
    ///
    /// Wann e future fäerdeg ass, sollten d'Clienten et net erëm `poll` maachen.
    ///
    /// Wann en future nach net fäerdeg ass, gëtt `poll` zréck `Poll::Pending` a späichert e Klon vun der [`Waker`] kopéiert vum aktuellen [`Context`].
    /// Dësen [`Waker`] gëtt dann erwächt wann den future Fortschrëtter maache kann.
    /// Zum Beispill, en future waart op e Socket fir liesbar ze ginn, rufft `.clone()` op der [`Waker`] a späichert se.
    /// Wann e Signal anzwousch anescht ukënnt, wat beweist datt de Socket liesbar ass, gëtt [`Waker::wake`] geruff an d'Socket future d'Aufgab erwächt.
    /// Wann eng Aufgab erwächt ass, sollt et probéieren den future erëm `poll` ze maachen, wat eventuell en definitive Wäert produzéiert oder net.
    ///
    /// Bedenkt datt bei méi Uriff op `poll` nëmmen den [`Waker`] vum [`Context`], deen an de jéngste Ruff weiderginn ass, geplangt ass fir e Wakeup ze kréien.
    ///
    /// # Runtime Charakteristiken
    ///
    /// Futures alleng sinn *inert*;si musse *aktiv*"ofgestëmmt" ginn, fir Fortschrëtter ze maachen, dat heescht datt all Kéier wann déi aktuell Aufgab erwächt gëtt, soll se aktiv nei "polléieren" bis op futures, wou et nach ëmmer en Interêt huet.
    ///
    /// D `poll` Funktioun gëtt net widderholl an enger enker Loop genannt-amplaz sollt se just genannt ginn wann den future weist datt se prett ass fir Fortschrëtter ze maachen (andeems Dir `wake()`) nennt.
    /// Wann Dir mat den `poll(2)` oder `select(2)` Syscalls op Unix vertraut sidd, ass et ze bemierken datt futures normalerweis *net* déiselwecht Probleemer vum "all wakeups must poll all events" hunn;si si méi wéi `epoll(4)`.
    ///
    /// Eng Ëmsetzung vun `poll` soll probéieren séier zréckzekommen, a sollt net blockéieren.Zeréck zréckkënnt verhënnert onnéideg Fuedem oder Event-Schleifen ze verstoppen.
    /// Wann et virdru bekannt ass datt en Uruff op `poll` e bëssen Zäit dauert, soll d'Aarbecht an e Fuedempool ofgelueden ginn (oder eppes ähnleches) fir sécher ze sinn datt `poll` séier zréck kënnt.
    ///
    /// # Panics
    ///
    /// Wann e future fäerdeg ass (`Ready` vun `poll` zréckkomm), seng `poll` Method erëm ze nennen kann panic, fir ëmmer blockéieren oder aner Probleemer verursaachen;den `Future` trait stellt keng Ufuerderungen un d'Effekter vun esou engem Uruff.
    /// Wéi och ëmmer, well d `poll` Method net `unsafe` markéiert ass, gëllen déi üblech Regele vum Rust: Uriff däerfen ni ondefinéiert Verhalen verursaachen (Gedächtniskorruptioun, falsch Benotze vun `unsafe` Funktiounen oder ähnleches), onofhängeg vum Zoustand vum future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}