#![stable(feature = "futures_api", since = "1.36.0")]

//! Asynchron Wäerter.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Dësen Typ ass gebraucht well:
///
/// a) Generatoren kënnen net `for<'a, 'b> Generator<&'a mut Context<'b>>` implementéieren, dofir musse mir e rauen Zeiger weiderginn (kuckt <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Raw Zeigefanger an `NonNull` sinn net `Send` oder `Sync`, sou datt et och all future non-Send/Sync géif maachen, a mir wëllen dat net.
///
/// Et vereinfacht och d'HIR Senkung vun `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Wéckel e Generator an engem future.
///
/// Dës Funktioun bréngt en `GenFuture` ënner, awer verstoppt en an `impl Trait` fir besser Feelermeldungen ze ginn (`impl Future` anstatt `GenFuture<[closure.....]>`).
///
// Dëst ass `const` fir extra Feeler ze vermeiden nodeems mir eis vum `const async fn` erhuelen
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Mir vertrauen op d'Tatsaach datt async/await futures onbeweegbar sinn fir selbstverständlech Prêten am Basis Generator ze kreéieren.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // SAFETY: Sécher well mir sinn !Unpin + !Drop, an dëst ass just eng Feldprojektioun.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Weidergaang de Generator, verwandelt den `&mut Context` zu engem `NonNull` roude Pointer.
            // D `.await` Senkung wäert dat sécher zréck op en `&mut Context` werfen.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // SAFETY: den Uruffer muss garantéieren datt `cx.0` e valabelen Zeiger ass
    // dat erfëllt all Viraussetzunge fir eng mutabel Referenz.
    unsafe { &mut *cx.0.as_ptr().cast() }
}