//! E Modul fir mat geléinten Daten ze schaffen.

#![stable(feature = "rust1", since = "1.0.0")]

/// A trait fir Daten ze léinen.
///
/// An Rust ass et heefeg verschidde Representatioune vun engem Typ fir verschidde Benotzungsfäll ze bidden.
/// Zum Beispill d'Späicherplaz an d'Gestioun fir e Wäert kënne speziell als passend fir e bestëmmte Gebrauch iwwer Zeigertypen wéi [`Box<T>`] oder [`Rc<T>`] gewielt ginn.
/// Méi wéi dës generesch Wrapper déi mat all Typ benotzt kënne ginn, ginn et verschidden Aarte optional Facetten déi potenziell deier Funktionalitéit ubidden.
/// E Beispill fir sou en Typ ass [`String`] wat d'Fäegkeet derbäi huet e String op de Basis [`str`] auszebauen.
/// Dëst erfuerdert zousätzlech Informatioun onnéideg ze halen fir eng einfach, onverännerbar String.
///
/// Dës Aarte bidden Zougang zu de Basisdaten duerch Referenzen zu der Aart vun dësen Donnéeën.Si gi gesot "geléint" wéi deen Typ.
/// Zum Beispill kann en [`Box<T>`] als `T` ausgeléint ginn, wärend en [`String`] als `str` kann ausgeléint ginn.
///
/// Typen ausdrécken datt se als Typ `T` ausgeléint kënne ginn andeems se `Borrow<T>` implementéieren, andeems se e Referenz zu engem `T` an der trait's [`borrow`] Method ubidden.En Typ ass gratis ze léinen als verschidden verschidden Zorten.
/// Wann et mutéierbar als Typ léint-erlaabt datt d'Ënnergruppendaten geännert ginn, kann et zousätzlech [`BorrowMut<T>`] implementéieren.
///
/// Weider, wann Dir Implementatioune fir zousätzlech traits ubitt, muss et berécksiichtegt ginn ob se sech identesch mat deene vun der Basislinntyp verhale sollten als Konsequenz vun der Handlung als Duerstellung vun deem Basisdaten Typ.
/// Generesche Code benotzt typesch `Borrow<T>` wann et op dat identescht Verhalen vun dësen zousätzlechen trait Implementéierunge berout.
/// Dës traits wäerte méiglecherweis als zousätzlech trait bounds erschéngen.
///
/// Besonnesch `Eq`, `Ord` an `Hash` musse gläichwäerteg sinn fir geléinte a Besëtz Wäerter: `x.borrow() == y.borrow()` sollt datselwecht Resultat ginn wéi `x == y`.
///
/// Wann de generesche Code just fir all Typ muss funktionnéieren, déi e Referenz zum ähnlechen Typ `T` liwweren, ass et dacks besser [`AsRef<T>`] ze benotzen, well méi Zorten et sécher implementéiere kënnen.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Als Datensammlung huet [`HashMap<K, V>`] souwuel d'Schlësselen wéi d'Wäerter.Wann déi aktuell Date vum Schlëssel an engem Verwaltungsart vun iergendenger gewéckelt sinn, sollt et awer ëmmer nach méiglech sinn e Wäert ze sichen mat enger Referenz zu den Daten vum Schlëssel.
/// Zum Beispill, wann de Schlëssel e String ass, da gëtt et méiglecherweis mat der Hashkaart als [`String`] gelagert, wärend et méiglech wier mat engem [`&str`][`str`] ze sichen.
/// Dofir muss `insert` op engem `String` operéieren, während `get` e `&str` benotze muss.
///
/// Liicht vereinfacht, déi relevant Deeler vun der `HashMap<K, V>` gesinn esou aus:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // Felder ausgelooss
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Déi ganz Hash Kaart ass generesch iwwer e Schlësseltyp `K`.Well dës Schlëssele mat der Hashkaart gelagert sinn, muss dësen Typ d'Date vun de Schlëssel besëtzen.
/// Wann Dir e Schlësselwäerterpaar agefouert hutt, gëtt d'Kaart esou en `K` gegeben a muss de richtegen Hash-Eemer fannen a kontrolléieren ob de Schlëssel scho präsent ass op Basis vun deem `K`.Et erfuerdert dofir `K: Hash + Eq`.
///
/// Wann Dir no engem Wäert op der Kaart sicht, musst Dir awer e Referenz op en `K` als Schlëssel fir no Sich nozeginn, ëmmer sou e Besëtzer ze kreéieren.
/// Fir String Tasten, heescht dat en `String` Wäert muss erstallt ginn just fir d'Sich no Fäll wou nëmmen en `str` verfügbar ass.
///
/// Amplaz datt d `get` Method generesch ass iwwer den Typ vun de Basisdaten Schlësseldaten, genannt `Q` an der Methodsënnerschrëft hei uewen.Et seet datt `K` als `Q` ausléint andeems se den `K: Borrow<Q>` erfuerderen.
/// Duerch zousätzlech `Q: Hash + Eq` ze erfuerderen signaliséiert et d'Ufuerderung datt `K` an `Q` Implementatioune vum `Hash` an `Eq` traits hunn déi identesch Resultater produzéieren.
///
/// D'Ëmsetzung vun `get` setzt besonnesch op identesch Implementéierunge vum `Hash` duerch Bestëmmung vum Hash-Eemer vum Schlëssel andeems en `Hash::hash` op den `Q`-Wert nennt, och wann en de Schlëssel agefouert huet op Basis vum Hashwäert aus dem `K`-Wäert berechent.
///
///
/// Als Konsequenz brécht d'Hash-Kaart wann en `K` en `Q`-Wéckel wéckelt en aneren Hash produzéiert wéi `Q`.Zum Beispill, stellt Iech vir datt Dir en Typ hutt deen e String wéckelt awer ASCII Bréiwer vergläicht an hire Fall ignoréiert:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Well zwee gläich Wäerter dee selwechten Hashwäert musse produzéieren, muss d'Ëmsetzung vum `Hash` och den ASCII Fall ignoréieren:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Kann `CaseInsensitiveString` `Borrow<str>` implementéieren?Et ka sécher eng Referenz zu engem String Scheif iwwer seng enthale Besëtz String bidden.
/// Awer well hir `Hash`-Implementatioun anescht ass, verhält se sech anescht wéi `str` an däerf also net, tatsächlech `Borrow<str>` implementéieren.
/// Wann et aneren Zougang zu der Basis `str` wëllt erlaben, kann et dat iwwer `AsRef<str>` maachen, wat keng extra Ufuerderungen huet.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Immutable léint vun engem eegene Wäert.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// A trait fir mutativ Daten ze léinen.
///
/// Als Begleeder vum [`Borrow<T>`] erlaabt dësen trait en Typ als Basisgrond ze léinen duerch eng mutabel Referenz.
/// Kuckt [`Borrow<T>`] fir méi Informatioun iwwer Prêten als eng aner Aart.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Mutéiert léint vun engem Besëtzwäert.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}