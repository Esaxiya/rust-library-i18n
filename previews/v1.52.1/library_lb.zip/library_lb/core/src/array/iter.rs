//! Definéiert den `IntoIter` Besëtzer Iterator fir Arrays.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// E by-value [array] Iterator.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Dëst ass d'Array wou mir iteréieren.
    ///
    /// Elementer mam Index `i` wou `alive.start <= i < alive.end` nach net noginn a gëlteg Array Entréen sinn.
    /// Elementer mat Indizes `i < alive.start` oder `i >= alive.end` si scho ginn an däerfen net méi zougänglech sinn!Déi dout Elementer kéinten och an engem komplett net-initialiséierten Zoustand sinn!
    ///
    ///
    /// Also d'Invariante sinn:
    /// - `data[alive]` ass lieweg (dh enthält valabel Elementer)
    /// - `data[..alive.start]` an `data[alive.end..]` sinn dout (dh d'Elementer ware scho gelies an däerfen net méi beréiert ginn!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// D'Elementer am `data` déi nach net noginn.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Erstellt en neien Iterator iwwer dee gegebene `array`.
    ///
    /// *Notiz*: dës Method kéint am future, no [`IntoIterator` is implemented for arrays][array-into-iter], entfouert ginn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Déi Zort `value` ass en `i32` hei, amplaz `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // SAFETY: Den Transmute hei ass tatsächlech sécher.D'Docs vun `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` ass garantéiert déiselwecht Gréisst an Ausriichtung ze hunn
        // > wéi `T`.
        //
        // D'Docs weisen och e transmute vun engem Array vun `MaybeUninit<T>` op en Array vun `T`.
        //
        //
        // Domat erfëllt dës Initialiséierung den Invarianten.

        // FIXME(LukasKalbertodt): benotzt `mem::transmute` tatsächlech hei, wann et eemol mat const generics funktionnéiert:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Bis dohinner kënne mir `mem::transmute_copy` benotze fir eng bitvis Kopie als eng aner Aart ze kreéieren, da vergiess `array` sou datt se net fale gelooss gëtt.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Gitt eng onverännerbar Scheif vun allen Elementer déi nach net noginn hunn.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // SAFETY: Mir wëssen datt all Elementer bannent `alive` richteg initialiséiert sinn.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Nees eng mutabel Scheif vun allen Elementer déi nach net noginn hunn.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // SAFETY: Mir wëssen datt all Elementer bannent `alive` richteg initialiséiert sinn.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Kritt den nächsten Index vu vir.
        //
        // D'Erhéijung vum `alive.start` ëm 1 hält den Invarier iwwer `alive`.
        // Wéi och ëmmer, wéinst dëser Ännerung, fir eng kuerz Zäit, ass d'Liewenszon net méi `data[alive]`, awer `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Liest d'Element aus der Array.
            // SAFETY: `idx` ass en Index an déi fréier "alive" Regioun vun der
            // Array.Liest dëst Element heescht datt `data[idx]` elo als dout ugesi gëtt (dh beréiert net).
            // Wéi `idx` den Ufank vun der Live-Zone war, ass d'live Zone elo erëm `data[alive]`, a restauréiert all Invarianten.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Kritt den nächsten Index vun hannen.
        //
        // `alive.end` ëm 1 erofzesetzen hält den Invarier iwwer `alive`.
        // Wéi och ëmmer, wéinst dëser Ännerung, fir eng kuerz Zäit, ass d'Liewenszon net méi `data[alive]`, awer `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Liest d'Element aus der Array.
            // SAFETY: `idx` ass en Index an déi fréier "alive" Regioun vun der
            // Array.Liest dëst Element heescht datt `data[idx]` elo als dout ugesi gëtt (dh beréiert net).
            // Wéi `idx` d'Enn vun der Live-Zone war, ass d'live Zone elo `data[alive]`, a restauréiert all Invarariater.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // SAFETY: Dëst ass sécher: `as_mut_slice` bréngt genau d'Ënnerschnitt zréck
        // vun Elementer déi nach net geréckelt sinn an déi nach fale bleiwen.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Wäert ni ënnerstrouen wéinst dem onverännerleche "lieweg. Start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Den Iterator bericht wierklech déi richteg Längt.
// D'Zuel vun den "alive" Elementer (déi nach ëmmer noginn) ass d'Längt vum Range `alive`.
// Dëse Beräich gëtt an der Längt entweder `next` oder `next_back` dekrementéiert.
// Et gëtt ëmmer vun 1 an dëse Methoden dekrementéiert, awer nëmmen wann `Some(_)` zréck gëtt.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Bemierkung, mir brauche net wierklech dat exakt déiselwecht Liewe Beräich ze passen, sou datt mir just an den Offset 0 klone kënnen, egal wou `self` ass.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Klon all lieweg Elementer.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Schreift e Klon an den neie Array, aktualiséiert duerno säi liewege Beräich.
            // Wa mir panics klonen, fale mer déi virdrun Elementer richteg erof.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Dréckt nëmmen déi Elementer déi nach net noginn waren: mir kënnen net méi op déi erhalent Elementer zougräifen.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}