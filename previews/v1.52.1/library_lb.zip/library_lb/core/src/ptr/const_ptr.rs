use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// Retour `true` wann de Zeiger null ass.
    ///
    /// Bedenkt datt net Gréisst Typen vill méiglech Nullweiser hunn, well nëmmen de roude Dateweiser gëtt berécksiichtegt, net hir Längt, Tabelle, etc.
    /// Dofir kënnen zwee Zeigefanger, déi null sinn, ëmmer nach net gläich matenee vergläichen.
    ///
    /// ## Verhalen während der Const Evaluatioun
    ///
    /// Wann dës Funktioun wärend der const Evaluatioun benotzt gëtt, kann se `false` fir Zeigeféier zréckginn, déi bei der Runtime null sinn.
    /// Spezifesch, wann e Zeiger zu e puer Gedächtnis iwwer seng Grenzen ausgeglach ass sou datt de resultéierende Zeiger null ass, gëtt d'Funktioun ëmmer nach `false` zréck.
    ///
    /// Et gëtt kee Wee fir den CTFE déi absolut Positioun vun deem Gedächtnis ze kennen, also kënne mir net soen ob de Zeiger null ass oder net.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Vergläicht iwwer e Besetzung mat engem dënnen Zeiger, sou datt fett Fändelen nëmmen hiren "data" Deel fir Nullitéit berécksiichtegen.
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// Gitt op e Zeiger vun engem aneren Typ.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// Zerfall en (méiglecherweis breet) Zeiger an d'Adress an d'Metadatekomponenten.
    ///
    /// De Zeiger kann méi spéit mat [`from_raw_parts`] rekonstruéiert ginn.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// Gitt `None` zréck wann de Zeiger null ass, oder soss eng gemeinsam Referenz op de Wäert zréckgezunn an `Some`.Wann de Wäert oninitialiséiert ka ginn, muss [`as_uninit_ref`] amplaz benotzt ginn.
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// Wann Dir dës Method nennt, musst Dir suergen datt *entweder* de Zeiger NULL *oder* all déi folgend ass wouer:
    ///
    /// * De Zeiger muss richteg ausgeriicht sinn.
    ///
    /// * Et muss "dereferencable" sinn am Sënn definéiert an [the module documentation].
    ///
    /// * De Zeiger muss op eng initialiséiert Instanz vun `T` weisen.
    ///
    /// * Dir musst Rust Aliaséierungsregelen duerchsetzen, well d'zréckgesate Liewensdauer `'a` arbiträr gewielt gëtt an net onbedéngt déi aktuell Liewensdauer vun den Date reflektéiert.
    ///   Besonnesch fir d'Dauer vun dëser Liewensdauer däerf d'Erënnerung, op déi de Zeiger weist, net mutéiert ginn (ausser am `UnsafeCell`).
    ///
    /// Dëst gëllt och wann d'Resultat vun dëser Method net benotzt gëtt!
    /// (Deen Deel iwwer d'Initialiséierung ass nach net komplett decidéiert, awer bis et ass, ass déi eenzeg sécher Approche ze suergen datt se wierklech initialiséiert ginn.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Null-onkontrolléiert Versioun
    ///
    /// Wann Dir sécher sidd datt de Zeiger ni null ka sinn a sicht no enger Aart `as_ref_unchecked` déi den `&T` amplaz `Option<&T>` zréckkuckt, wësst datt Dir de Zeiger direkt kann ofleeën.
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // SAFETY: den Uruff muss garantéieren datt `self` gëlteg ass
        // fir eng Referenz wann et net null ass.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Retour `None` wann de Zeiger null ass, oder soss eng gedeelt Referenz op de Wäert zréckgezunn an `Some`.
    /// Am Géigesaz zu [`as_ref`] erfuerdert dëst net datt de Wäert initialiséiert muss ginn.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Wann Dir dës Method nennt, musst Dir suergen datt *entweder* de Zeiger NULL *oder* all déi folgend ass wouer:
    ///
    /// * De Zeiger muss richteg ausgeriicht sinn.
    ///
    /// * Et muss "dereferencable" sinn am Sënn definéiert an [the module documentation].
    ///
    /// * Dir musst Rust Aliaséierungsregelen duerchsetzen, well d'zréckgesate Liewensdauer `'a` arbiträr gewielt gëtt an net onbedéngt déi aktuell Liewensdauer vun den Date reflektéiert.
    ///
    ///   Besonnesch fir d'Dauer vun dëser Liewensdauer däerf d'Erënnerung, op déi de Zeiger weist, net mutéiert ginn (ausser am `UnsafeCell`).
    ///
    /// Dëst gëllt och wann d'Resultat vun dëser Method net benotzt gëtt!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // SAFETY: den Uruffer muss garantéieren datt `self` all den
        // Ufuerderunge fir eng Referenz.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Berechent den Offset vun engem Zeiger.
    ///
    /// `count` ass an Eenheeten vun T;zB, e `count` vun 3 stellt e Zeigeroffset vun `3 * size_of::<T>()` Bytes duer.
    ///
    /// # Safety
    ///
    /// Wann eng vun de folgende Konditioune verletzt gëtt, ass d'Resultat Undefined Behaviour:
    ///
    /// * Souwuel de Start-wéi och de resultéierende Zeiger mussen entweder a Grenzen sinn oder ee Byte laanscht d'Enn vum selwechten zougestellten Objet.
    /// Bedenkt datt an Rust, all (stack-allocated) Variabel als separat zougewisen Objet ugesi gëtt.
    ///
    /// * Déi berechent Offset,**a Bytes**, kann en `isize` net iwwerschreiden.
    ///
    /// * Den Offset a Grenzen kann net op "wrapping around" den Adressraum vertrauen.Dat ass, déi onendlech Präzisiounssomm,**a Bytes** muss an e Usize passen.
    ///
    /// De Compiler an d'Standardbibliothéik probéieren normalerweis ze verdeelen datt d'Allocatiounen ni eng Gréisst erreechen wou en Offset eng Suerg ass.
    /// Zum Beispill, `Vec` an `Box` suergen datt se ni méi wéi `isize::MAX` Bytes allocéieren, sou datt `vec.as_ptr().add(vec.len())` ëmmer sécher ass.
    ///
    /// Déi meescht Plattforme kënne grondsätzlech net esou eng Bewëllegung konstruéieren.
    /// Zum Beispill ka keng bekannte 64-Bit Plattform jeemools eng Ufro fir 2 <sup>63</sup> Bytes déngen wéinst Säiten-Tabell-Aschränkungen oder der Splitterung vum Adressraum.
    /// Wéi och ëmmer, e puer 32-Bit an 16-Bit Plattformen kënnen erfollegräich eng Ufro fir méi wéi `isize::MAX` Bytes mat Saache wéi Physical Address Extension déngen.
    ///
    /// Als sou kann d'Erënnerung direkt vun Allocateuren oder Memory Mapen Dateie *kaaft* ze grouss sinn fir mat dëser Funktioun ze handhaben.
    ///
    /// Betruecht [`wrapping_offset`] amplaz ze benotzen wann dës Contrainten schwéier zefridden sinn.
    /// Deen eenzege Virdeel vun dëser Method ass datt et méi aggressiv Compiler Optimisatiounen erméiglecht.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SAFETY: den Uruff muss de Sécherheetsvertrag fir `offset` oprechterhalen.
        unsafe { intrinsics::offset(self, count) }
    }

    /// Berechent den Offset vun engem Zeiger mat Wrapping-Arithmetik.
    ///
    /// `count` ass an Eenheeten vun T;zB, e `count` vun 3 stellt e Zeigeroffset vun `3 * size_of::<T>()` Bytes duer.
    ///
    /// # Safety
    ///
    /// Dës Operatioun selwer ass ëmmer sécher, awer de resultéierende Zeiger benotzt ass net.
    ///
    /// De resultéierende Zeiger bleiwt mat dem selwechten zougestellten Objet verbonnen datt `self` weist op.
    /// Et kann *net* benotzt ginn fir Zougang zu engem aneren zougestellten Objet ze kréien.Bedenkt datt an Rust, all (stack-allocated) Variabel als separat zougewisen Objet ugesi gëtt.
    ///
    /// An anere Wierder, `let z = x.wrapping_offset((y as isize) - (x as isize))` mécht *net*`z` d'selwecht wéi `y` och wa mir dovun ausgoen datt `T` d'Gréisst `1` huet an et gëtt keen Iwwerlaf: `z` ass nach ëmmer un den Objet verbonnen `x` ass ugeschloss un, an Dereferenzen ass et net definéiert Behuelen ausser `x` an `y` Punkt an déi selwecht zougewisen Objet.
    ///
    /// Am Verglach mat [`offset`], dës Method verzögert am Fong d'Ufuerderung am selwechten zougewisenen Objet ze bleiwen: [`offset`] ass direkt ondefinéiert Behuelen wann Dir Objekt Grenze passéiert `wrapping_offset` produzéiert e Zeiger awer féiert ëmmer nach zu Onbestëmmt Verhalen wann e Zeiger verfeiert gëtt wann et ausserhalb vum Grenze vum Objet ass.
    /// [`offset`] ka besser optiméiert ginn an ass also am Performance-Empfindleche Code preferabel.
    ///
    /// De Verspéidte Scheck berücksichtegt nëmmen de Wäert vum Zeiger deen derferenzéiert gouf, net déi Zwëschewäerter déi während der Berechnung vum Schlussresultat benotzt goufen.
    /// Zum Beispill ass `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` ëmmer déiselwecht wéi `x`.An anere Wierder, den zougewisen Objet ze loossen an duerno méi spéit eranzekommen ass erlaabt.
    ///
    /// Wann Dir Objekt Grenze kräizt, da werft de Zeiger op eng ganz Zuel an maacht d'Armetmetik do.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// // Iteréiert mat engem roude Zeiger an Inkremente vun zwee Elementer
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // Dëse Loop dréckt "1, 3, 5, " aus
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SAFETY: den `arith_offset` intrinsesche huet keng Viraussetzunge fir ze nennen.
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// Berechent d'Distanz tëscht zwee Zeigefanger.De zréckgezunnene Wäert ass an Eenheeten vun T: d'Distanz a Bytes gëtt gedeelt duerch `mem::size_of::<T>()`.
    ///
    /// Dës Funktioun ass déi invers vun [`offset`].
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// Wann eng vun de folgende Konditioune verletzt gëtt, ass d'Resultat Undefined Behaviour:
    ///
    /// * Souwuel de Start-wéi deen aneren Zeiger musse entweder a Grenzen sinn oder ee Byte laanscht d'Enn vum selwechten zougestellten Objet.
    /// Bedenkt datt an Rust, all (stack-allocated) Variabel als separat zougewisen Objet ugesi gëtt.
    ///
    /// * Béid Zeigefanger musse *ofgeleet sinn* vun engem Zeiger zum selwechten Objet.
    ///   (Kuckt hei ënnendrënner fir e Beispill.)
    ///
    /// * D'Distanz tëscht de Weiser, a Bytes, muss e exakt Multiple vun der Gréisst vun `T` sinn.
    ///
    /// * D'Distanz tëscht de Weiser,**a Bytes**, kann en `isize` net iwwerschreiden.
    ///
    /// * D'Distanz a Grenzen kann net op "wrapping around" den Adressraum vertrauen.
    ///
    /// Rust Typen sinn ni méi grouss wéi `isize::MAX` an Rust Allocatiounen wéckelen ni ronderëm den Adressraum, sou datt zwee Zeigefanger bannent engem Wäert vun all Rust Typ `T` ëmmer déi lescht zwou Konditiounen erfëllen.
    ///
    /// D'Standardbibliothéik garantéiert och allgemeng datt d'Allocatiounen ni zu enger Gréisst erreechen wou en Offset eng Suerg ass.
    /// Zum Beispill, `Vec` an `Box` suergen datt se ni méi wéi `isize::MAX` Bytes allocéieren, sou datt `ptr_into_vec.offset_from(vec.as_ptr())` ëmmer déi lescht zwee Konditiounen erfëllt.
    ///
    /// Déi meescht Plattforme kënnen am Fong net emol sou eng grouss Bewëllegung konstruéieren.
    /// Zum Beispill ka keng bekannte 64-Bit Plattform jeemools eng Ufro fir 2 <sup>63</sup> Bytes déngen wéinst Säiten-Tabell-Aschränkungen oder der Splitterung vum Adressraum.
    /// Wéi och ëmmer, e puer 32-Bit an 16-Bit Plattformen kënnen erfollegräich eng Ufro fir méi wéi `isize::MAX` Bytes mat Saache wéi Physical Address Extension déngen.
    /// Als sou kann d'Erënnerung direkt vun Allocateuren oder Memory Mapen Dateie *kaaft* ze grouss sinn fir mat dëser Funktioun ze handhaben.
    /// (Bedenkt datt [`offset`] an [`add`] och eng ähnlech Begrenzung hunn an dofir och net bei sou groussen Allocatiounen benotzt kënne ginn.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Dës Funktioun panics wann `T` en Zero-Gréisst Typ ("ZST") ass.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Falsch* Benotzung:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Maacht ptr2_other en "alias" vun ptr2, awer ofgeleet vu ptr1.
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Well ptr2_other an ptr2 aus Zeigefanger op verschidden Objeten ofgeleet ginn, ass hir Offset net ausgedefinéiert Verhalen ze berechnen, och wa se op déi selwecht Adress weisen!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Net definéiert Behuelen
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // SAFETY: den Uruff muss de Sécherheetsvertrag fir `ptr_offset_from` oprechterhalen.
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// Gitt zréck ob zwee Zeigefanger garantéiert gläich sinn.
    ///
    /// Zu Runtime verhält dës Funktioun sech wéi `self == other`.
    /// Wéi och ëmmer, an e puer Kontexter (z. B. Zesummestellungszäitevaluatioun) ass et net ëmmer méiglech d'Gläichheet vun zwee Zeigefanger ze bestëmmen, sou datt dës Funktioun falsch `false` fir Zeechner zréckbrénge kann, déi spéider tatsächlech gläich ginn.
    ///
    /// Awer wann et `true` zréckkënnt, sinn d'Indikatoren garantéiert gläich.
    ///
    /// Dës Funktioun ass de Spigel vum [`guaranteed_ne`], awer net säin invers.Et gi Pointervergläicher fir déi zwou Funktiounen `false` zréckginn.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// De Retourwäert kann ofhängeg vun der Compiler Versioun änneren an onséchere Code kann net op d'Resultat vun dëser Funktioun vertrauen.
    /// Et gëtt virgeschloen dës Funktioun nëmme fir Performance Optimisatiounen ze benotzen, wou falsch `false` Retour Wäerter vun dëser Funktioun net d'Resultat beaflossen, awer just d'Performance.
    /// D'Konsequenze vun der Benotzung vun dëser Method fir d'Runtime ze maachen an den Zäitkompiléierungscode anescht ze behuelen sinn net exploréiert.
    /// Dës Method sollt net benotzt ginn fir sou Differenzen anzeféieren, an et soll och net stabiliséiert ginn ier mir e bessert Verständnis vun dësem Thema hunn.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// Gitt zréck ob zwee Zeigefanger garantéiert ongläich sinn.
    ///
    /// Zu Runtime verhält dës Funktioun sech wéi `self != other`.
    /// Wéi och ëmmer, an e puer Kontexter (z. B. Zesummestellungsevaluatioun) ass et net ëmmer méiglech d'Ongläichheet vun zwee Zeigefanger ze bestëmmen, sou datt dës Funktioun falsch `false` fir Zeechner zréckbrénge kann, déi spéider tatsächlech ongläich ginn.
    ///
    /// Awer wann et `true` zréckkënnt, sinn d'Zeechner garantéiert ongläich.
    ///
    /// Dës Funktioun ass de Spigel vum [`guaranteed_eq`], awer net säin invers.Et gi Pointervergläicher fir déi zwou Funktiounen `false` zréckginn.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// De Retourwäert kann ofhängeg vun der Compiler Versioun änneren an onséchere Code kann net op d'Resultat vun dëser Funktioun vertrauen.
    /// Et gëtt virgeschloen dës Funktioun nëmme fir Performance Optimisatiounen ze benotzen, wou falsch `false` Retour Wäerter vun dëser Funktioun net d'Resultat beaflossen, awer just d'Performance.
    /// D'Konsequenze vun der Benotzung vun dëser Method fir d'Runtime ze maachen an den Zäitkompiléierungscode anescht ze behuelen sinn net exploréiert.
    /// Dës Method sollt net benotzt ginn fir sou Differenzen anzeféieren, an et soll och net stabiliséiert ginn ier mir e bessert Verständnis vun dësem Thema hunn.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// Berechent den Offset vun engem Zeiger (Komfort fir `.offset(count as isize)`).
    ///
    /// `count` ass an Eenheeten vun T;zB, e `count` vun 3 stellt e Zeigeroffset vun `3 * size_of::<T>()` Bytes duer.
    ///
    /// # Safety
    ///
    /// Wann eng vun de folgende Konditioune verletzt gëtt, ass d'Resultat Undefined Behaviour:
    ///
    /// * Souwuel de Start-wéi och de resultéierende Zeiger mussen entweder a Grenzen sinn oder ee Byte laanscht d'Enn vum selwechten zougestellten Objet.
    /// Bedenkt datt an Rust, all (stack-allocated) Variabel als separat zougewisen Objet ugesi gëtt.
    ///
    /// * Déi berechent Offset,**a Bytes**, kann en `isize` net iwwerschreiden.
    ///
    /// * Den Offset a Grenzen kann net op "wrapping around" den Adressraum vertrauen.Dat ass, déi onendlech Präzisiounszomm muss an en `usize` passen.
    ///
    /// De Compiler an d'Standardbibliothéik probéieren normalerweis ze verdeelen datt d'Allocatiounen ni eng Gréisst erreechen wou en Offset eng Suerg ass.
    /// Zum Beispill, `Vec` an `Box` suergen datt se ni méi wéi `isize::MAX` Bytes allocéieren, sou datt `vec.as_ptr().add(vec.len())` ëmmer sécher ass.
    ///
    /// Déi meescht Plattforme kënne grondsätzlech net esou eng Bewëllegung konstruéieren.
    /// Zum Beispill ka keng bekannte 64-Bit Plattform jeemools eng Ufro fir 2 <sup>63</sup> Bytes déngen wéinst Säiten-Tabell-Aschränkungen oder der Splitterung vum Adressraum.
    /// Wéi och ëmmer, e puer 32-Bit an 16-Bit Plattformen kënnen erfollegräich eng Ufro fir méi wéi `isize::MAX` Bytes mat Saache wéi Physical Address Extension déngen.
    ///
    /// Als sou kann d'Erënnerung direkt vun Allocateuren oder Memory Mapen Dateie *kaaft* ze grouss sinn fir mat dëser Funktioun ze handhaben.
    ///
    /// Betruecht [`wrapping_add`] amplaz ze benotzen wann dës Contrainten schwéier zefridden sinn.
    /// Deen eenzege Virdeel vun dëser Method ass datt et méi aggressiv Compiler Optimisatiounen erméiglecht.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SAFETY: den Uruff muss de Sécherheetsvertrag fir `offset` oprechterhalen.
        unsafe { self.offset(count as isize) }
    }

    /// Berechent den Offset vun engem Zeiger (Komfort fir `.offset ((zielt als isize).wrapping_neg())`).
    ///
    /// `count` ass an Eenheeten vun T;zB, e `count` vun 3 stellt e Zeigeroffset vun `3 * size_of::<T>()` Bytes duer.
    ///
    /// # Safety
    ///
    /// Wann eng vun de folgende Konditioune verletzt gëtt, ass d'Resultat Undefined Behaviour:
    ///
    /// * Souwuel de Start-wéi och de resultéierende Zeiger mussen entweder a Grenzen sinn oder ee Byte laanscht d'Enn vum selwechten zougestellten Objet.
    /// Bedenkt datt an Rust, all (stack-allocated) Variabel als separat zougewisen Objet ugesi gëtt.
    ///
    /// * De berechtegten Offset kann net `isize::MAX`**Bytes** iwwerschreiden.
    ///
    /// * Den Offset a Grenzen kann net op "wrapping around" den Adressraum vertrauen.Dat ass, déi onendlech Präzisiounszomm muss an engem Usize passen.
    ///
    /// De Compiler an d'Standardbibliothéik probéieren normalerweis ze verdeelen datt d'Allocatiounen ni eng Gréisst erreechen wou en Offset eng Suerg ass.
    /// Zum Beispill, `Vec` an `Box` suergen datt se ni méi wéi `isize::MAX` Bytes allocéieren, sou datt `vec.as_ptr().add(vec.len()).sub(vec.len())` ëmmer sécher ass.
    ///
    /// Déi meescht Plattforme kënne grondsätzlech net esou eng Bewëllegung konstruéieren.
    /// Zum Beispill ka keng bekannte 64-Bit Plattform jeemools eng Ufro fir 2 <sup>63</sup> Bytes déngen wéinst Säiten-Tabell-Aschränkungen oder der Splitterung vum Adressraum.
    /// Wéi och ëmmer, e puer 32-Bit an 16-Bit Plattformen kënnen erfollegräich eng Ufro fir méi wéi `isize::MAX` Bytes mat Saache wéi Physical Address Extension déngen.
    ///
    /// Als sou kann d'Erënnerung direkt vun Allocateuren oder Memory Mapen Dateie *kaaft* ze grouss sinn fir mat dëser Funktioun ze handhaben.
    ///
    /// Betruecht [`wrapping_sub`] amplaz ze benotzen wann dës Contrainten schwéier zefridden sinn.
    /// Deen eenzege Virdeel vun dëser Method ass datt et méi aggressiv Compiler Optimisatiounen erméiglecht.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SAFETY: den Uruff muss de Sécherheetsvertrag fir `offset` oprechterhalen.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Berechent den Offset vun engem Zeiger mat Wrapping-Arithmetik.
    /// (Komfort fir `.wrapping_offset(count as isize)`)
    ///
    /// `count` ass an Eenheeten vun T;zB, e `count` vun 3 stellt e Zeigeroffset vun `3 * size_of::<T>()` Bytes duer.
    ///
    /// # Safety
    ///
    /// Dës Operatioun selwer ass ëmmer sécher, awer de resultéierende Zeiger benotzt ass net.
    ///
    /// De resultéierende Zeiger bleiwt mat dem selwechten zougestellten Objet verbonnen datt `self` weist op.
    /// Et kann *net* benotzt ginn fir Zougang zu engem aneren zougestellten Objet ze kréien.Bedenkt datt an Rust, all (stack-allocated) Variabel als separat zougewisen Objet ugesi gëtt.
    ///
    /// An anere Wierder, `let z = x.wrapping_add((y as usize) - (x as usize))` mécht *net*`z` d'selwecht wéi `y` och wa mir dovun ausgoen datt `T` d'Gréisst `1` huet an et gëtt keen Iwwerlaf: `z` ass nach ëmmer un den Objet verbonnen `x` ass ugeschloss un, an Dereferenzen ass et net definéiert Behuelen ausser `x` an `y` Punkt an déi selwecht zougewisen Objet.
    ///
    /// Am Verglach mat [`add`], dës Method verzögert am Fong d'Ufuerderung am selwechten zougewisenen Objet ze bleiwen: [`add`] ass direkt ondefinéiert Behuelen wann Dir Objektengrenze passéiert;`wrapping_add` produzéiert e Zeiger awer féiert ëmmer nach zu Onbestëmmt Verhalen wann e Zeiger verfeiert gëtt wann et ausserhalb vum Grenze vum Objet ass.
    /// [`add`] ka besser optiméiert ginn an ass also am Performance-Empfindleche Code preferabel.
    ///
    /// De Verspéidte Scheck berücksichtegt nëmmen de Wäert vum Zeiger deen derferenzéiert gouf, net déi Zwëschewäerter déi während der Berechnung vum Schlussresultat benotzt goufen.
    /// Zum Beispill ass `x.wrapping_add(o).wrapping_sub(o)` ëmmer déiselwecht wéi `x`.An anere Wierder, den zougewisen Objet ze loossen an duerno méi spéit eranzekommen ass erlaabt.
    ///
    /// Wann Dir Objekt Grenze kräizt, da werft de Zeiger op eng ganz Zuel an maacht d'Armetmetik do.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// // Iteréiert mat engem roude Zeiger an Inkremente vun zwee Elementer
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Dëse Loop dréckt "1, 3, 5, " aus
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Berechent den Offset vun engem Zeiger mat Wrapping-Arithmetik.
    /// (Komfort fir `.wrapping_offset ((zielt als isize).wrapping_neg())`)
    ///
    /// `count` ass an Eenheeten vun T;zB, e `count` vun 3 stellt e Zeigeroffset vun `3 * size_of::<T>()` Bytes duer.
    ///
    /// # Safety
    ///
    /// Dës Operatioun selwer ass ëmmer sécher, awer de resultéierende Zeiger benotzt ass net.
    ///
    /// De resultéierende Zeiger bleiwt mat dem selwechten zougestellten Objet verbonnen datt `self` weist op.
    /// Et kann *net* benotzt ginn fir Zougang zu engem aneren zougestellten Objet ze kréien.Bedenkt datt an Rust, all (stack-allocated) Variabel als separat zougewisen Objet ugesi gëtt.
    ///
    /// An anere Wierder, `let z = x.wrapping_sub((x as usize) - (y as usize))` mécht *net*`z` d'selwecht wéi `y` och wa mir dovun ausgoen datt `T` d'Gréisst `1` huet an et gëtt keen Iwwerlaf: `z` ass nach ëmmer un den Objet verbonnen `x` ass ugeschloss un, an Dereferenzen ass et net definéiert Behuelen ausser `x` an `y` Punkt an déi selwecht zougewisen Objet.
    ///
    /// Am Verglach mat [`sub`], dës Method verzögert am Fong d'Ufuerderung am selwechten zougewisenen Objet ze bleiwen: [`sub`] ass direkt ondefinéiert Behuelen wann Dir Objektengrenze passéiert;`wrapping_sub` produzéiert e Zeiger awer féiert ëmmer nach zu Onbestëmmt Behuelen wann e Zeiger verfeiert gëtt wann et ausserhalb vum Grenzen ass vum Objet un deem et verbonnen ass.
    /// [`sub`] ka besser optiméiert ginn an ass also am Performance-Empfindleche Code preferabel.
    ///
    /// De Verspéidte Scheck berücksichtegt nëmmen de Wäert vum Zeiger deen derferenzéiert gouf, net déi Zwëschewäerter déi während der Berechnung vum Schlussresultat benotzt goufen.
    /// Zum Beispill ass `x.wrapping_add(o).wrapping_sub(o)` ëmmer déiselwecht wéi `x`.An anere Wierder, den zougewisen Objet ze loossen an duerno méi spéit eranzekommen ass erlaabt.
    ///
    /// Wann Dir Objekt Grenze kräizt, da werft de Zeiger op eng ganz Zuel an maacht d'Armetmetik do.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// // Iteréiert mat engem roude Zeiger an Inkremente vun zwee Elementer (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Dëse Loop dréckt "5, 3, 1, " aus
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Setzt den Zeigewäert op `ptr`.
    ///
    /// Am Fall wou `self` en (fat) Zeiger zu engem net Gréisst ass, wäert dës Operatioun nëmmen den Zeiger Deel beaflossen, wärend fir (thin) Zeigefanger zu Gréisstentypen, huet dat déiselwecht Wierkung wéi eng einfach Aufgab.
    ///
    /// De resultéierende Zeiger wäert d'Herzéiung vun `val` hunn, dh fir e Fettzeiger, dës Operatioun ass semantesch d'selwecht wéi en neie Fettzeiger mam Datenweigerwäert vun `val` awer d'Metadaten vun `self`.
    ///
    ///
    /// # Examples
    ///
    /// Dës Funktioun ass haaptsächlech nëtzlech fir Byte-weise Zeechner Arithmetik op potenziell Fettweiser z'erméiglechen:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // wäert "3" drécken
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // SAFETY: Am Fall vun engem dënnem Zeiger sinn dës Operatiounen identesch
        // zu enger einfacher Aufgab.
        // Am Fall vun engem Fettzeiger, mat der aktueller Fettzeiger Layout Implementatioun, ass dat éischt Feld vun esou engem Zeiger ëmmer den Datenzeiger, deen och zougewise gëtt.
        //
        unsafe { *thin = val };
        self
    }

    /// Liest de Wäert vun `self` ouni et ze réckelen.
    /// Dëst léisst d'Erënnerung am `self` onverännert.
    ///
    /// Kuckt [`ptr::read`] fir Sécherheetsprobleemer a Beispiller.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // SAFETY: den Uruff muss de Sécherheetsvertrag fir `read` oprechterhalen.
        unsafe { read(self) }
    }

    /// Féiert eng onbestänneg Liesung vum Wäert vun `self` ouni se ze bewegen.Dëst léisst d'Erënnerung am `self` onverännert.
    ///
    /// Flüchtlëch Operatioune si virgesinn op I/O Gedächtnis ze handelen, a si garantéiert net vum Compiler iwwer aner onbestänneg Operatiounen ofgeleet oder nei bestallt ze ginn.
    ///
    ///
    /// Kuckt [`ptr::read_volatile`] fir Sécherheetsprobleemer a Beispiller.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // SAFETY: den Uruff muss de Sécherheetsvertrag fir `read_volatile` oprechterhalen.
        unsafe { read_volatile(self) }
    }

    /// Liest de Wäert vun `self` ouni et ze réckelen.
    /// Dëst léisst d'Erënnerung am `self` onverännert.
    ///
    /// Am Géigesaz zu `read` kann de Zeiger net ausgeriicht sinn.
    ///
    /// Kuckt [`ptr::read_unaligned`] fir Sécherheetsprobleemer a Beispiller.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // SAFETY: den Uruff muss de Sécherheetsvertrag fir `read_unaligned` oprechterhalen.
        unsafe { read_unaligned(self) }
    }

    /// Kopéiert `count * size_of<T>` Bytes vun `self` op `dest`.
    /// D'Quell an d'Destinatioun kënnen iwwerlappend sinn.
    ///
    /// NOTE: dëst huet d'selwecht * Argumentuerdnung wéi [`ptr::copy`].
    ///
    /// Kuckt [`ptr::copy`] fir Sécherheetsprobleemer a Beispiller.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SAFETY: den Uruff muss de Sécherheetsvertrag fir `copy` oprechterhalen.
        unsafe { copy(self, dest, count) }
    }

    /// Kopéiert `count * size_of<T>` Bytes vun `self` op `dest`.
    /// D'Quell an d'Destinatioun kënnen *net* iwwerlappen.
    ///
    /// NOTE: dëst huet d'selwecht * Argumentuerdnung wéi [`ptr::copy_nonoverlapping`].
    ///
    /// Kuckt [`ptr::copy_nonoverlapping`] fir Sécherheetsprobleemer a Beispiller.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SAFETY: den Uruff muss de Sécherheetsvertrag fir `copy_nonoverlapping` oprechterhalen.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Berechent den Offset deen op de Zeiger muss ugewannt ginn fir en op `align` ausgeriicht ze maachen.
    ///
    /// Wann et net méiglech ass de Zeiger auszestellen, gëtt d'Ëmsetzung `usize::MAX` zréck.
    /// Et ass erlaabt datt d'Ëmsetzung `usize::MAX`*ëmmer* zréckbréngt.
    /// Nëmmen d'Performance vun Ärem Algorithmus kann dovun ofhänken datt een e benotzbaren Offset hei kritt, net seng Richtegkeet.
    ///
    /// Den Offset gëtt an der Zuel vun `T` Elementer ausgedréckt, an net Bytes.De Wäert zréck kann mat der `wrapping_add` Method benotzt ginn.
    ///
    /// Et gi keng Garantien iwwerhaapt datt de Zeechner kompenséiert net iwwerschwemmt oder iwwer d'Allocatioun erausgeet déi de Zeiger weist.
    ///
    /// Et ass un den Uruffer fir ze garantéieren datt de zréckgezunnen Offset korrekt ass an all anere Bedéngungen ausser Ausriichtung.
    ///
    /// # Panics
    ///
    /// D'Funktioun panics wann `align` net eng Power-of-Two ass.
    ///
    /// # Examples
    ///
    /// Zougang zu benachbarte `u8` als `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // wärend de Zeiger iwwer `offset` ausgeriicht ka ginn, géif et ausserhalb vun der Bewëllegung weisen
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // SAFETY: `align` gouf kontrolléiert fir eng Kraaft vun 2 uewen ze sinn
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// Nees d'Längt vun engem réiem Stéck.
    ///
    /// De zréckgezunnene Wäert ass d'Zuel vun **Elementer**, net d'Zuel vu Bytes.
    ///
    /// Dës Funktioun ass sécher, och wann d'Ro Slice net zu enger Scheifreferenz ka gegoss ginn well de Zeiger null oder net ausgeriicht ass.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // SAFETY: dëst ass sécher, well `*const [T]` an `FatPtr<T>` hunn dee selwechte Layout.
            // Nëmmen `std` kann dës Garantie maachen.
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Nees e roude Zeigefanger op de Puffer vun der Scheif.
    ///
    /// Dëst entsprécht dem Goss `self` op `*const T`, awer méi typesécher.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// Nees e roude Zeiger op en Element oder en Ënnerschnitt, ouni Grenzen ze maachen.
    ///
    /// Dës Method mat engem out-of-bounds Index nennen oder wann `self` net derferencabel ass ass *[ondefinéiert Verhalen]* och wann de resultéierenden Zeiger net benotzt gëtt.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // SAFETY: den Uruff garantéiert datt `self` derferencabel ass an `index` bannent Grenzen.
        unsafe { index.get_unchecked(self) }
    }

    /// Retour `None` wann de Zeiger null ass, oder soss e gemeinsame Stéck zréck op de Wäert an `Some` gewéckelt.
    /// Am Géigesaz zu [`as_ref`] erfuerdert dëst net datt de Wäert initialiséiert muss ginn.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Wann Dir dës Method nennt, musst Dir suergen datt *entweder* de Zeiger NULL *oder* all déi folgend ass wouer:
    ///
    /// * De Zeiger muss [valid] sinn fir fir `ptr.len() * mem::size_of::<T>()` vill Bytes ze liesen, an et muss richteg ausgeriicht sinn.Dëst bedeit besonnesch:
    ///
    ///     * De ganze Gedächtnisberäich vun dëser Scheif muss an engem eenzelen zougestellten Objet enthale sinn!
    ///       Scheiwen kënnen ni iwwer verschidde zougewisen Objete spannen.
    ///
    ///     * De Zeiger muss och fir Nulllängt Scheiwen ausgeriicht sinn.
    ///     Ee Grond dofir ass datt Enum Layout Optimiséierungen op Referenzen (abegraff Scheiwen vun all Längt) vertraue kënnen an net null sinn fir se vun aneren Daten z'ënnerscheeden.
    ///
    ///     Dir kënnt e Zeiger kréien deen als `data` benotzbar ass fir Nulllängt Scheiwen mat [`NonNull::dangling()`].
    ///
    /// * D'Gesamtgréisst `ptr.len() * mem::size_of::<T>()` vun der Scheif däerf net méi grouss si wéi `isize::MAX`.
    ///   Kuckt d'Sécherheetsdokumentatioun vun [`pointer::offset`].
    ///
    /// * Dir musst Rust Aliaséierungsregelen duerchsetzen, well d'zréckgesate Liewensdauer `'a` arbiträr gewielt gëtt an net onbedéngt déi aktuell Liewensdauer vun den Date reflektéiert.
    ///   Besonnesch fir d'Dauer vun dëser Liewensdauer däerf d'Erënnerung, op déi de Zeiger weist, net mutéiert ginn (ausser am `UnsafeCell`).
    ///
    /// Dëst gëllt och wann d'Resultat vun dëser Method net benotzt gëtt!
    ///
    /// Kuckt och [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SAFETY: den Uruff muss de Sécherheetsvertrag fir `as_uninit_slice` oprechterhalen.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// Gläichheet fir Zeigefanger
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// Verglach fir Uweiser
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}