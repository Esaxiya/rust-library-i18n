#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Bitt de Zeigefanger Metadaten Typ vun all geziilten Typ.
///
/// # Zeechner Metadaten
///
/// Raw Zeigentypen a Referenzentypen an Rust kënne vun zwee Deeler ugesi ginn:
/// en Datenzeiger deen d'Erënnerung Adress vum Wäert enthält, an e puer Metadaten.
///
/// Fir statesch Gréisst Typen (déi d `Sized` traits implementéieren) wéi och fir `extern` Typen, ginn Indikatoren als "dënn" gesot: Metadate sinn Nullgréisst a säin Typ ass `()`.
///
///
/// Zeigefanger op [dynamically-sized types][dst] si gesot "breet" oder "fett", si hunn net-null-Gréisst Metadaten:
///
/// * Fir Structs, deem säi leschte Feld en DST ass, sinn Metadaten d'Metadate fir dat lescht Feld
/// * Fir den `str` Typ sinn d'Metadaten d'Längt vu Bytes als `usize`
/// * Fir Scheifentypen wéi `[T]`, Metadaten sinn d'Längt vun Elementer wéi `usize`
/// * Fir trait Objete wéi `dyn SomeTrait`, Metadate sinn [`DynMetadata<Self>`][DynMetadata] (z. B. `DynMetadata<dyn SomeTrait>`)
///
/// Am future kann d'Rust Sprooch nei Aarte vun Typen gewannen déi aner Zeigermetadaten hunn.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # Den `Pointee` trait
///
/// De Punkt vun dësem trait ass säin `Metadata` assoziéierten Typ, deen `()` oder `usize` oder `DynMetadata<_>` ass wéi uewen beschriwwen.
/// Et gëtt automatesch fir all Typ implementéiert.
/// Et kann ugeholl ginn datt se an engem generesche Kontext implementéiert ginn, och ouni eng entspriechend Grenz.
///
/// # Usage
///
/// Rohweiser kënnen an d'Datenadress an d'Metadatekomponente mat hirer [`to_raw_parts`] Method ofgebaut ginn.
///
/// Alternativ kënnen Metadaten alleng mat der [`metadata`] Funktioun extrahéiert ginn.
/// Eng Referenz kann op [`metadata`] weiderginn an implizit gezwonge ginn.
///
/// En (possibly-wide) Zeiger kann aus senger Adress a Metadaten mat [`from_raw_parts`] oder [`from_raw_parts_mut`] zréckgesat ginn.
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Den Typ fir Metadaten an Uweiser a Referenzen op `Self`.
    #[lang = "metadata_type"]
    // NOTE: Halen trait bounds an `static_assert_expected_bounds_for_metadata`
    //
    // an `library/core/src/ptr/metadata.rs` synchroniséiert mat deenen hei:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Hiweiser op Typen déi dësen trait Alias implementéieren sinn "dënn".
///
/// Dëst beinhalt statesch-Sized'Typen an `extern` Typen.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: stabiliséieren dëst net ier d'trait Aliasen an der Sprooch stabil sinn?
pub trait Thin = Pointee<Metadata = ()>;

/// Extrait de Metadatenkomponent vun engem Zeiger.
///
/// Wäerter vum Typ `*mut T`, `&T` oder `&mut T` kënnen direkt un dës Funktioun weidergeleet ginn, well se implizit op `* const T` zwéngen.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // SAFETY: Zougang zum Wäert vun der `PtrRepr` Gewerkschaft ass sécher well * const T
    // a PtrComponents<T>hunn déi selwecht Erënnerungslayouten.
    // Nëmmen std kann dës Garantie maachen.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Formt en (possibly-wide) roude Zeiger vun enger Datenadress a Metadaten.
///
/// Dës Funktioun ass sécher awer de zréckgezunnen Zeiger ass net onbedéngt sécher fir Dereferenz.
/// Fir Scheiwen, kuckt d'Dokumentatioun vum [`slice::from_raw_parts`] fir Sécherheetsufuerderungen.
/// Fir trait Objete musse d'Metadate vun engem Zeigefanger op dee selwechten ënnerläit ereased Typ kommen.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // SAFETY: Zougang zum Wäert vun der `PtrRepr` Gewerkschaft ass sécher well * const T
    // a PtrComponents<T>hunn déi selwecht Erënnerungslayouten.
    // Nëmmen std kann dës Garantie maachen.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Féiert déiselwecht Funktionalitéit wéi [`from_raw_parts`], ausser datt e rauen `*mut` Zeiger zréckkomm ass, am Géigesaz zu engem rauen `* const` Zeiger.
///
///
/// Kuckt d'Dokumentatioun vum [`from_raw_parts`] fir méi Detailer.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // SAFETY: Zougang zum Wäert vun der `PtrRepr` Gewerkschaft ass sécher well * const T
    // a PtrComponents<T>hunn déi selwecht Erënnerungslayouten.
    // Nëmmen std kann dës Garantie maachen.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Manuell impl néideg fir `T: Copy` gebonnen ze vermeiden.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Manuell impl néideg fir `T: Clone` gebonnen ze vermeiden.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// D'Metadate fir en `Dyn = dyn SomeTrait` trait Objektyp.
///
/// Et ass e Zeiger zu enger vtabel (virtueller Uruffstabell) déi all néideg Informatioune representéiert fir de konkreten Typ ze manipuléieren an engem trait Objet.
/// Dee Vtabel notamment enthält:
///
/// * Typ Gréisst
/// * Typ Ausriichtung
/// * e Zeigefanger op den Typ `drop_in_place` impl (kann e No-Op fir Einfache-al-Daten sinn)
/// * Hiweiser op all d'Methode fir d'Typ Ëmsetzung vum trait
///
/// Bedenkt datt déi éischt dräi speziell sinn, well se noutwendeg sinn all trait Objet ze allocéieren, drop ze ginn an ze verhandelen.
///
/// Et ass méiglech dësen Struct mat engem Typ Parameter ze nennen deen net en `dyn` trait Objet ass (zum Beispill `DynMetadata<u64>`) awer net e bedeitende Wäert vun deem Struct ze kréien.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// De gemeinsame Präfix vun all Dëscher.Et gëtt gefollegt vu Funktiounsweiser fir trait Methoden.
///
/// Privat Ëmsetzung Detail vun `DynMetadata::size_of` etc.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Gitt d'Gréisst vun der Aart zréck, déi mat dëser Tabelle assoziéiert ass.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Nees d'Ausrichtung vum Typ verbonne mat dëser Tabel.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Gitt d'Gréisst an d'Ausrichtung zesummen als `Layout` zréck
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // SIKKERHET: de Compiler huet dës Tabelle fir e konkreten Rust Typ ausgestallt deen
        // ass bekannt e gültege Layout ze hunn.Selwecht Begrënnung wéi an `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Manuell Implikatiounen néideg fir `Dyn: $Trait` Grenzen ze vermeiden.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}