//! Manuell Erënnerung duerch réi Zeechen managen.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Vill Funktiounen an dësem Modul huele roueg Zeigefanger als Argumenter a liesen oder schreiwen hinnen.Fir dëst sécher ze sinn, mussen dës Uweiser *valabel* sinn.
//! Egal ob e Zeiger gëlteg ass, hänkt vun der Operatioun of, fir déi e benotzt gëtt (liesen oder schreiwen), an d'Ausmooss vun der Erënnerung déi zougeruff gëtt (dh wéivill Bytes sinn read/written).
//! Déi meescht Funktioune benotze `*mut T` an `* const T` fir nëmmen een eenzege Wäert ze kréien, an deem Fall d'Dokumentatioun d'Gréisst ewech léisst an implizit dovun ausgeet datt et `size_of::<T>()` Bytes ass.
//!
//! Déi präzis Regele fir Validitéit sinn nach net festgeluecht.D'Garantien, déi op dësem Punkt geliwwert ginn, si ganz minimal:
//!
//! * En [null] Zeiger ass *ni* gëlteg, och net fir Zougang zu [size zero][zst].
//! * Fir e Zeiger gëlteg ze sinn, ass et noutwendeg, awer net ëmmer genuch, datt de Zeiger *dereferenzéierbar* ass: d'Erënnerungsspektrum vun der bestëmmter Gréisst, déi beim Zeiger ufänkt, muss all an de Grenze vun engem eenzelen zougestellten Objet sinn.
//!
//! Bedenkt datt an Rust, all (stack-allocated) Variabel als separat zougewisen Objet ugesi gëtt.
//! * Och fir Operatiounen vun [size zero][zst], kann de Zeiger net op en Deallocated Memory weisen, dh Deallocation mécht Zeigefanger ongëlteg och fir Nullgréissten Operatiounen.
//! Wéi och ëmmer, all net-Null ganz *wuertwiertlech* an e Zeiger ze geheien ass valabel fir Nullgréissten Zougang, och wann e puer Erënnerungen op där Adress existéieren an ofgedeelt ginn.
//! Dëst entsprécht engem Ären eegenen allocator ze schreiwen: Nullgréissten Objekter ze allocéieren ass net ganz schwéier.
//! De kanonesche Wee fir e Zeiger ze kréien dee valabel ass fir Nullgréisst Zougang ass [`NonNull::dangling`].
//! * All Zougang, déi vu Funktiounen an dësem Modul ausgefouert gëtt, sinn *net-atomesch* am Sënn vun [atomic operations], déi benotzt ginn tëscht de Fiederen ze synchroniséieren.
//! Dëst bedeit datt et ondefinéiert Verhalen ass fir zwee gläichzäiteg Zougang zu der selwechter Plaz aus verschiddene Fäegkeeten auszeféieren, ausser béid Zougang nëmmen aus dem Gedächtnis gelies.
//! Bedenkt datt dëst explizit [`read_volatile`] an [`write_volatile`] enthält: Flüchteg Zougang kann net fir Inter-thread Synchroniséierung benotzt ginn.
//! * D'Resultat vum Verweise vun enger Referenz zu engem Zeiger ass gëlteg soulaang wéi de Basisobjekt lieweg ass a keng Referenz (nëmme réi Zeigefanger) gëtt benotzt fir op datselwecht Gedächtnis ze kommen.
//!
//! Dës Axiome, zesumme mat suergfälteger Benotzung vu [`offset`] fir Zeechner Arithmetik, si genuch fir vill nëtzlech Saachen an onsécherem Code korrekt ëmzesetzen.
//! Méi staark Garantië gi schliisslech, well d [aliasing] Regele festgeluecht ginn.
//! Fir méi Informatioun, kuckt [book] souwéi d'Sektioun an der Referenz gewidmet [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Gülteg Rohweiser wéi uewen definéiert sinn net onbedéngt richteg ausgeriicht (wou "proper" Ausriichtung definéiert ass vum Pointeetyp, dh `*const T` muss op `mem::align_of::<T>()` ausgeriicht sinn).
//! Wéi och ëmmer, déi meescht Funktiounen erfuerderen datt hir Argumenter richteg ausgeriicht sinn, a soen explizit dës Ufuerderung an hirer Dokumentatioun.
//! Bemierkenswäert Ausnamen dozou sinn [`read_unaligned`] an [`write_unaligned`].
//!
//! Wann eng Funktioun eng korrekt Ausriichtung erfuerdert, mécht et dat och wann den Zougang d'Gréisst 0 huet, dh och wann d'Erënnerung net tatsächlech beréiert gëtt.Betruecht [`NonNull::dangling`] an esou Fäll ze benotzen.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Féiert den Zerstéierer aus (wann iwwerhaapt) vum geziilte Wäert.
///
/// Dëst ass semantesch gläichwäerteg mam [`ptr::read`] ze ruffen an d'Resultat ofzeginn, awer huet folgend Virdeeler:
///
/// * Et ass *erfuerderlech*`drop_in_place` ze benotze fir net Gréisst Typen wéi trait Objete falen ze loossen, well se kënnen net op de Stack ausgelies ginn an normalerweis erofgefall sinn.
///
/// * Et ass méi frëndlech fir den Optimizer dëst iwwer [`ptr::read`] ze maachen wann Dir manuell zougewisen Erënnerung fällt (zB an den Implementéierunge vun `Box`/`Rc`/`Vec`), well de Compiler net muss beweisen datt et gutt ass fir d'Kopie z'eliden.
///
///
/// * Et kann benotzt ginn fir [pinned] Daten erofzesetzen wann `T` net `repr(packed)` ass (festgesaten Daten däerfen net geréckelt ginn ier se fale gelooss ginn).
///
/// Net ausgeriicht Wäerter kënnen net op der Plaz fale gelooss ginn, se musse fir d'éischt mat [`ptr::read_unaligned`] op eng ausgeriicht Plaz kopéiert ginn.Fir gepackte Structs gëtt dës Bewegung automatesch vum Compiler gemaach.
/// Dëst bedeit datt d'Felder vu gepackte Strucken net op der Plaz falen.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Verhalen ass ondefinéiert wann eng vun de folgende Konditioune verletzt gëtt:
///
/// * `to_drop` muss [valid] fir béid Liesen a Schreiwe sinn.
///
/// * `to_drop` musse richteg ausgeriicht sinn.
///
/// * De Wäert `to_drop` weist op muss valabel si fir erofzesetzen, dat kann heeschen datt et zousätzlech Invararianer oprecht muss halen, dëst ass ofhängeg vum Typ.
///
/// Zousätzlech, wann `T` net [`Copy`] ass, kann de geziilte Wäert nom `drop_in_place` uruffen ondefinéiert Verhalen verursaachen.Bedenkt datt `*to_drop = foo` als Benotzung zielt well et de Wäert erëm fale léisst.
/// [`write()`] ka benotzt ginn fir Daten ze iwwerschreiwe ouni datt se fale gelooss ginn.
///
/// Bedenkt datt och wann `T` d'Gréisst `0` huet, muss de Zeiger net NULL sinn a richteg ausgeriicht sinn.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Manuell dat lescht Element vun engem vector erofhuelen:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Kritt e roude Zeigefanger op dat lescht Element am `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Kuerz `v` fir ze verhënneren datt de leschten Artikel fale gelooss gëtt.
///     // Mir maachen dat als éischt, fir Probleemer ze vermeiden wann den `drop_in_place` ënner panics.
///     v.set_len(1);
///     // Ouni Uruff `drop_in_place`, wier dat lescht Element ni fale gelooss ginn, an d'Erënnerung, dat et geréiert, géif ausgelaf sinn.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Gitt sécher datt de leschten Artikel erofgefall ass.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Bedenkt datt de Compiler dës Kopie automatesch ausféiert wann se packt Strucke fale loossen, dh Dir musst Iech normalerweis net iwwer sou Themen këmmeren ausser Dir `drop_in_place` manuell urufft.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Code hei spillt keng Roll, dëst gëtt duerch de richtegen Drop Klebstoff vum Compiler ersat.
    //

    // SAFETY: kuckt uewendriwwer Kommentar
    unsafe { drop_in_place(to_drop) }
}

/// Erstellt en null rohen Zeiger.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Erstellt en null mutable roude Zeiger.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Manuell impl néideg fir `T: Clone` gebonnen ze vermeiden.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Manuell impl néideg fir `T: Copy` gebonnen ze vermeiden.
impl<T> Copy for FatPtr<T> {}

/// Formt eng réi Scheif aus engem Zeiger an enger Längt.
///
/// D `len` Argument ass d'Zuel vun **Elementer**, net d'Zuel vu Bytes.
///
/// Dës Funktioun ass sécher, awer tatsächlech mat dem Retourwäert ass onsécher.
/// Kuckt d'Dokumentatioun vum [`slice::from_raw_parts`] fir d'Scheifsécherheetsufuerderungen.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // kreéiert e Stéckzeiger wann Dir mat engem Zeigefanger op dat éischt Element ufänkt
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // SAFETY: Zougang zum Wäert vun der `Repr` Gewerkschaft ass sécher well * const [T]
        //
        // an FatPtr hunn déiselwecht Erënnerungslayouten.Nëmmen std kann dës Garantie maachen.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Féiert déiselwecht Funktionalitéit wéi [`slice_from_raw_parts`], ausser datt eng réi mutabel Scheif zréckbezuelt gëtt, am Géigesaz zu enger rauer onverännerbar Scheif.
///
///
/// Kuckt d'Dokumentatioun vum [`slice_from_raw_parts`] fir méi Detailer.
///
/// Dës Funktioun ass sécher, awer tatsächlech mat dem Retourwäert ass onsécher.
/// Kuckt d'Dokumentatioun vum [`slice::from_raw_parts_mut`] fir d'Scheifsécherheetsufuerderungen.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // uginn e Wäert op en Index an der Scheif
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // SAFETY: Zougang zum Wäert vun der `Repr` Gewerkschaft ass sécher well * mut [T]
        // an FatPtr hunn déiselwecht Erënnerungslayouten
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Tauscht d'Wäerter op zwou mutéierbare Standuerter vum selwechten Typ aus, ouni och deinitialiséieren.
///
/// Awer fir déi folgend zwou Ausnamen ass dës Funktioun semantesch gläichwäerteg mat [`mem::swap`]:
///
///
/// * Et funktionnéiert op réi Hiweiser amplaz vu Referenzen.
/// Wa Referenze verfügbar sinn, sollt [`mem::swap`] bevorzugt ginn.
///
/// * Déi zwee uginn Wäerter kënnen iwwerlappt ginn.
/// Wann d'Wäerter iwwerlappt ginn, da gëtt déi iwwerlappend Regioun vum Erënnerung vum `x` benotzt.
/// Dëst gëtt am zweete Beispill hei ënnendrënner demonstréiert.
///
/// # Safety
///
/// Verhalen ass ondefinéiert wann eng vun de folgende Konditioune verletzt gëtt:
///
/// * Béid `x` an `y` musse [valid] fir béid Liesen a Schreiwe sinn.
///
/// * Béid `x` an `y` musse richteg ausgeriicht sinn.
///
/// Bedenkt datt och wann `T` d'Gréisst `0` huet, mussen d'Uweiser net NULL sinn a richteg ausgeriicht sinn.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Tauscht vun zwee net iwwerlappende Regiounen:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // dëst ass `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // dëst ass `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Tauschen zwee iwwerlappend Regiounen:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // dëst ass `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // dëst ass `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // D'Indizes `1..3` vun der Scheif iwwerlappt tëscht `x` an `y`.
///     // Raisonnabel Resultater wiere fir si `[2, 3]`, sou datt Indizes `0..3` `[1, 2, 3]` sinn (passend `y` virum `swap`);oder fir datt se `[0, 1]` sinn, sou datt Indizes `1..4` `[0, 1, 2]` sinn (passend `x` virum `swap`).
/////
///     // Dës Ëmsetzung ass definéiert fir déi lescht Wiel ze treffen.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Gitt eis e bësse Kratzer fir mat ze schaffen.
    // Mir brauche keng Suergen iwwer Drëpsen: `MaybeUninit` mécht näischt wa se fale gelooss gëtt.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Maacht de Swap SAFETY: den Uruffer muss garantéieren datt `x` an `y` gëlteg sinn fir ze schreiwen an richteg ausgeriicht ze sinn.
    // `tmp` kann weder `x` nach `y` iwwerlappt ginn well `tmp` just um Stack als separat zougewisen Objet zougewisen gouf.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` an `y` kënnen iwwerlappend sinn
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Tauscht `count * size_of::<T>()` Bytes tëscht den zwou Regioune vum Erënnerung un, déi um `x` an `y` ufänken.
/// Déi zwou Regiounen däerfen *net* iwwerlappen.
///
/// # Safety
///
/// Verhalen ass ondefinéiert wann eng vun de folgende Konditioune verletzt gëtt:
///
/// * Béid `x` an `y` musse [valid] sinn fir béid Liesen a Schreiwe vun `Grof *
///   Gréisst_of: :<T>() `Bytes.
///
/// * Béid `x` an `y` musse richteg ausgeriicht sinn.
///
/// * D'Regioun vum Gedächtnis beginn bei `x` mat enger Gréisst vun `Grof *
///   Gréisst_of: :<T>() `Bytes däerfen *net* mat der Regioun vum Gedächtnis iwwerlappt mat der `y` mat der selwechter Gréisst.
///
/// Bedenkt datt och wann déi effektiv kopéiert Gréisst (`count * size_of: :<T>()`) ass `0`, d'Zeechner mussen net NULL sinn a richteg ausgeriicht sinn.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Basis Benotzung:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // SAFETY: den Uruffer muss garantéieren datt `x` an `y` sinn
    // valabel fir schreift a richteg ausgeriicht.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Fir Typen méi kleng wéi d'Blockoptiméierung hei ënnen, tauscht just direkt fir Pessimiséierung vu Codegen ze vermeiden.
    //
    if mem::size_of::<T>() < 32 {
        // SAFETY: den Uruff muss garantéieren datt `x` an `y` gëlteg sinn
        // fir schreift, richteg ausgeriicht an net iwwerlappend.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // SAFETY: den Uruff muss de Sécherheetsvertrag fir `swap_nonoverlapping` oprechterhalen.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // D'Approche hei ass d'Simd ze benotzen fir X&Y effizient auszetauschen.
    // Testing weist datt d'Austausch entweder 32 Bytes oder 64 Bytes gläichzäiteg am effizientsten fir Intel Haswell E Prozessoren ass.
    // LLVM ass méi fäeg ze optimiséieren wa mir engem Struct en #[repr(simd)] ginn, och wa mir dës Struct net tatsächlech direkt benotzen.
    //
    //
    // FIXME repr(simd) gebrach op emscripten a redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Loop duerch x&y, kopéiert se `Block` gläichzäiteg Den Optimizer soll d'Loop voll ausrollen fir déi meescht Zorten NB
    // Mir kënnen net eng For-Loop benotzen well den `range` impl `mem::swap` rekursiv nennt
    //
    let mut i = 0;
    while i + block_size <= len {
        // Erstellt e puer oninitialiséierter Erënnerung als Kratzraum Erkläert `t` hei vermeit de Stack ausriichten wann dës Loop net benotzt gëtt
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // SAFETY: Als `i < len`, a wéi den Uruffer muss garantéieren datt `x` an `y` gëlteg sinn
        // fir `len` Bytes, `x + i` an `y + i` musse gëlteg Adresse sinn, déi de Sécherheetsvertrag fir `add` erfëllen.
        //
        // Och den Uruffer muss garantéieren datt `x` an `y` gëlteg sinn fir ze schreiwen, richteg ausgeriicht an net iwwerlappend, wat de Sécherheetsvertrag fir `copy_nonoverlapping` erfëllt.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Tauscht e Block vu Bytes vun x&y, benotzt t als temporäre Puffer Dëst soll an effizient SIMD Operatiounen optimiséiert ginn, wa verfügbar
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Tauscht all Rescht Bytes
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // SAFETY: kuckt virdrun Sécherheetskommentar.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Beweegt `src` an de spitzegen `dst`, a bréngt de fréiere `dst` Wäert zréck.
///
/// Weder Wäert gëtt gefall.
///
/// Dës Funktioun ass semantesch gläichwäerteg mat [`mem::replace`] ausser datt se op réi Zeigefanger amplaz vu Referenze funktionnéiert.
/// Wa Referenze verfügbar sinn, sollt [`mem::replace`] bevorzugt ginn.
///
/// # Safety
///
/// Verhalen ass ondefinéiert wann eng vun de folgende Konditioune verletzt gëtt:
///
/// * `dst` muss [valid] fir béid Liesen a Schreiwe sinn.
///
/// * `dst` musse richteg ausgeriicht sinn.
///
/// * `dst` muss op e richteg initialiséierte Wäert vum Typ `T` hiweisen.
///
/// Bedenkt datt och wann `T` d'Gréisst `0` huet, muss de Zeiger net NULL sinn a richteg ausgeriicht sinn.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` hätt dee selwechten Effekt ouni den onséchere Block ze erfuerderen.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // SAFETY: den Uruffer muss garantéieren datt `dst` gëlteg ass
    // Goss op eng mutéierbar Referenz (valabel fir schreift, ausgeriicht, initialiséiert), a kann net `src` iwwerlappt well `dst` muss op en ënnerscheet zougewisen Objet hiweisen.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // kann net iwwerlappt ginn
    }
    src
}

/// Liest de Wäert vun `src` ouni et ze réckelen.Dëst léisst d'Erënnerung am `src` onverännert.
///
/// # Safety
///
/// Verhalen ass ondefinéiert wann eng vun de folgende Konditioune verletzt gëtt:
///
/// * `src` muss [valid] sinn fir ze liesen.
///
/// * `src` musse richteg ausgeriicht sinn.Benotzt [`read_unaligned`] wann dëst net de Fall ass.
///
/// * `src` muss op e richteg initialiséierte Wäert vum Typ `T` hiweisen.
///
/// Bedenkt datt och wann `T` d'Gréisst `0` huet, muss de Zeiger net NULL sinn a richteg ausgeriicht sinn.
///
/// # Examples
///
/// Basis Benotzung:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Manuell [`mem::swap`] implementéieren:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Erstellt eng bitwäit Kopie vum Wäert bei `a` bei `tmp`.
///         let tmp = ptr::read(a);
///
///         // Exit op dësem Punkt (entweder duerch explizit zréckkomm oder andeems Dir eng Funktioun nennt déi panics) géif de Wäert am `tmp` fale loossen, während dee selwechte Wäert nach ëmmer vun `a` referenzéiert gëtt.
///         // Dëst kéint ondefinéiert Verhalen ausléisen wann `T` net `Copy` ass.
/////
/////
///
///         // Erstellt eng bitwäit Kopie vum Wäert bei `b` bei `a`.
///         // Dëst ass sécher, well mutabel Referenze kënnen net alias sinn.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Wéi uewen, kann hei erausgoen ondefinéiert Verhalen ausléisen, well dee selwechte Wäert gëtt vun `a` an `b` referenzéiert.
/////
///
///         // Réckelt `tmp` an `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` gouf geplënnert (`write` iwwerhëlt säin zweet Argument), dofir gëtt hei näischt implizit erofgefall.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Besëtz vum zréckgezunnene Wäert
///
/// `read` erstellt eng bitwäit Kopie vun `T`, egal ob `T` [`Copy`] ass.
/// Wann `T` net [`Copy`] ass, kann de Retourwäert an de Wäert bei `*src` mat der Erënnerungssécherheet verstoussen.
/// Bedenkt datt d'Attributioun vun `*src` als Benotzung zielt well et probéiert de Wäert op `* src` erofzesetzen.
///
/// [`write()`] ka benotzt ginn fir Daten ze iwwerschreiwe ouni datt se fale gelooss ginn.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` weist elo op déiselwecht Basis Erënnerung wéi `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Assigning to `s2` verursaacht säin originelle Wäert.
///     // Iwwert dëse Punkt däerf `s` net méi benotzt ginn, well de Basis Erënnerung fräi gouf.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Zoudeelen un `s` géif dozou féieren datt den ale Wäert erëm erofgefall ass, wat zu ondefinéiertem Verhalen resultéiert.
/////
///     // s= String::from("bar");//FEELER
///
///     // `ptr::write` ka benotzt ginn fir e Wäert ze iwwerschreiwe ouni en erofzesetzen.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SAFETY: den Uruff muss garantéieren datt `src` gëlteg ass fir ze liesen.
    // `src` kann net `tmp` iwwerlappt well `tmp` just um Stack als separat zougewisen Objet zougewisen gouf.
    //
    //
    // Och well mir just e gültege Wäert an `tmp` geschriwwen hunn, ass et garantéiert richteg initialiséiert ze ginn.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Liest de Wäert vun `src` ouni et ze réckelen.Dëst léisst d'Erënnerung am `src` onverännert.
///
/// Am Géigesaz zu [`read`] schafft `read_unaligned` mat net ausgeriicht Zeigefanger.
///
/// # Safety
///
/// Verhalen ass ondefinéiert wann eng vun de folgende Konditioune verletzt gëtt:
///
/// * `src` muss [valid] sinn fir ze liesen.
///
/// * `src` muss op e richteg initialiséierte Wäert vum Typ `T` hiweisen.
///
/// Wéi [`read`] erstellt `read_unaligned` eng bitvis Kopie vun `T`, egal ob `T` [`Copy`] ass.
/// Wann `T` net [`Copy`] ass, kann de Retourwäert an de Wäert op `*src` [violate memory safety][read-ownership] benotzen.
///
/// Bedenkt datt och wann `T` d'Gréisst `0` huet, muss de Zeiger net NULL sinn.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Op `packed` Structs
///
/// Et ass de Moment onméiglech fir roude Zeigefanger op net ausgeriicht Felder vun engem gepacktenen Struct ze kreéieren.
///
/// Probéiert e roude Zeiger an en `unaligned` Struct Feld mat engem Ausdrock wéi `&packed.unaligned as *const FieldType` ze kreéieren erstellt eng Zwëschen net ausgeriicht Referenz ier Dir en an e roude Zeiger konvertéiert.
///
/// Datt dës Referenz temporär ass an direkt Goss ass onwichteg wéi de Compiler ëmmer erwaart datt Referenze richteg ausgeriicht sinn.
/// Als Resultat verursaacht d `&packed.unaligned as *const FieldType` direkt* ondefinéiert Verhalen * an Ärem Programm.
///
/// E Beispill vu wat net ze maachen a wéi dëst mam `read_unaligned` ass:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Hei versiche mir d'Adress vun enger 32-Bit ganz Zuel ze huelen déi net ausgeriicht ass.
///     let unaligned =
///         // Eng temporär net ausgeriicht Referenz gëtt hei erstallt wat zu ondefinéiertem Verhalen resultéiert egal ob d'Referenz benotzt gëtt oder net.
/////
///         &packed.unaligned
///         // Goss op e roude Zeiger hëlleft net;de Feeler ass scho geschitt.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Zougang zu net ausgeriicht Felder direkt mat zB `packed.unaligned` ass awer sécher.
///
///
///
///
///
///
// FIXME: Update Dokumenter baséiert op Resultat vum RFC #2582 a Frënn.
/// # Examples
///
/// Liest en Usize-Wäert vun engem Byte-Puffer:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SAFETY: den Uruff muss garantéieren datt `src` gëlteg ass fir ze liesen.
    // `src` kann net `tmp` iwwerlappt well `tmp` just um Stack als separat zougewisen Objet zougewisen gouf.
    //
    //
    // Och well mir just e gültege Wäert an `tmp` geschriwwen hunn, ass et garantéiert richteg initialiséiert ze ginn.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Iwwerschreift eng Erënnerungsplaz mat dem gegebene Wäert ouni den ale Wäert ze liesen oder ze falen.
///
/// `write` fällt net den Inhalt vun `dst`.
/// Dëst ass sécher, awer et kéint Allocatiounen oder Ressourcen lecken, sou datt et oppasse sollt en Objet ze iwwerschreiwe wat sollt fale gelooss ginn.
///
///
/// Zousätzlech fällt et net `src`.Semantesch ass `src` an de Standort geplënnert deen vun `dst` gewisen gëtt.
///
/// Dëst ass ugemoossen fir initialiséierter Erënnerung ze initialiséieren oder Erënnerung ze iwwerschreiwe wat virdrun [`read`] war.
///
/// # Safety
///
/// Verhalen ass ondefinéiert wann eng vun de folgende Konditioune verletzt gëtt:
///
/// * `dst` muss [valid] fir schreift.
///
/// * `dst` musse richteg ausgeriicht sinn.Benotzt [`write_unaligned`] wann dëst net de Fall ass.
///
/// Bedenkt datt och wann `T` d'Gréisst `0` huet, muss de Zeiger net NULL sinn a richteg ausgeriicht sinn.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Basis Benotzung:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Manuell [`mem::swap`] implementéieren:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Erstellt eng bitwäit Kopie vum Wäert bei `a` bei `tmp`.
///         let tmp = ptr::read(a);
///
///         // Exit op dësem Punkt (entweder duerch explizit zréckkomm oder andeems Dir eng Funktioun nennt déi panics) géif de Wäert am `tmp` fale loossen, während dee selwechte Wäert nach ëmmer vun `a` referenzéiert gëtt.
///         // Dëst kéint ondefinéiert Verhalen ausléisen wann `T` net `Copy` ass.
/////
/////
///
///         // Erstellt eng bitwäit Kopie vum Wäert bei `b` bei `a`.
///         // Dëst ass sécher, well mutabel Referenze kënnen net alias sinn.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Wéi uewen, kann hei erausgoen ondefinéiert Verhalen ausléisen, well dee selwechte Wäert gëtt vun `a` an `b` referenzéiert.
/////
///
///         // Réckelt `tmp` an `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` gouf geplënnert (`write` iwwerhëlt säin zweet Argument), dofir gëtt hei näischt implizit erofgefall.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Mir ruffen d'Intrinsiken direkt un fir Funktiounsanrufe am generéierte Code ze vermeiden well `intrinsics::copy_nonoverlapping` eng Wrapperfunktioun ass.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // SAFETY: den Uruffer muss garantéieren datt `dst` gëlteg ass fir ze schreiwen.
    // `dst` kann net `src` iwwerlappt well den Uruffer mutable Zougang zu `dst` huet wärend `src` vun dëser Funktioun gehéiert.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Iwwerschreift eng Erënnerungsplaz mat dem gegebene Wäert ouni den ale Wäert ze liesen oder ze falen.
///
/// Am Géigesaz zu [`write()`] kann de Zeiger net ausgeriicht sinn.
///
/// `write_unaligned` fällt net den Inhalt vun `dst`.Dëst ass sécher, awer et kéint Allocatiounen oder Ressourcen lecken, sou datt et oppasse sollt en Objet ze iwwerschreiwe wat sollt fale gelooss ginn.
///
/// Zousätzlech fällt et net `src`.Semantesch ass `src` an de Standort geplënnert deen vun `dst` gewisen gëtt.
///
/// Dëst ass ugemooss fir net initialiséiert Gedächtnis ze initialiséieren oder Erënnerung ze iwwerschreiwe wat virdru mat [`read_unaligned`] gelies gouf.
///
/// # Safety
///
/// Verhalen ass ondefinéiert wann eng vun de folgende Konditioune verletzt gëtt:
///
/// * `dst` muss [valid] fir schreift.
///
/// Bedenkt datt och wann `T` d'Gréisst `0` huet, muss de Zeiger net NULL sinn.
///
/// [valid]: self#safety
///
/// ## Op `packed` Structs
///
/// Et ass de Moment onméiglech fir roude Zeigefanger op net ausgeriicht Felder vun engem gepacktenen Struct ze kreéieren.
///
/// Probéiert e roude Zeiger an en `unaligned` Struct Feld mat engem Ausdrock wéi `&packed.unaligned as *const FieldType` ze kreéieren erstellt eng Zwëschen net ausgeriicht Referenz ier Dir en an e roude Zeiger konvertéiert.
///
/// Datt dës Referenz temporär ass an direkt Goss ass onwichteg wéi de Compiler ëmmer erwaart datt Referenze richteg ausgeriicht sinn.
/// Als Resultat verursaacht d `&packed.unaligned as *const FieldType` direkt* ondefinéiert Verhalen * an Ärem Programm.
///
/// E Beispill vu wat net ze maachen a wéi dëst mam `write_unaligned` ass:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Hei versiche mir d'Adress vun enger 32-Bit ganz Zuel ze huelen déi net ausgeriicht ass.
///     let unaligned =
///         // Eng temporär net ausgeriicht Referenz gëtt hei erstallt wat zu ondefinéiertem Verhalen resultéiert egal ob d'Referenz benotzt gëtt oder net.
/////
///         &mut packed.unaligned
///         // Goss op e roude Zeiger hëlleft net;de Feeler ass scho geschitt.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Zougang zu net ausgeriicht Felder direkt mat zB `packed.unaligned` ass awer sécher.
///
///
///
///
///
///
///
///
///
// FIXME: Update Dokumenter baséiert op Resultat vum RFC #2582 a Frënn.
/// # Examples
///
/// Schreift en Usize-Wäert an e Byte-Puffer:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // SAFETY: den Uruffer muss garantéieren datt `dst` gëlteg ass fir ze schreiwen.
    // `dst` kann net `src` iwwerlappt well den Uruffer mutable Zougang zu `dst` huet wärend `src` vun dëser Funktioun gehéiert.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Mir ruffen den intrinsesche direkt un fir Funktiounsanrufe am generéierte Code ze vermeiden.
        intrinsics::forget(src);
    }
}

/// Féiert eng onbestänneg Liesung vum Wäert vun `src` ouni se ze bewegen.Dëst léisst d'Erënnerung am `src` onverännert.
///
/// Flüchtlëch Operatioune si virgesinn op I/O Gedächtnis ze handelen, a si garantéiert net vum Compiler iwwer aner onbestänneg Operatiounen ofgeleet oder nei bestallt ze ginn.
///
/// # Notes
///
/// Rust huet am Moment kee rigoréis a formell definéierte Gedächtnismodell, sou datt déi präzis Semantik vun deem wat "volatile" hei bedeit ka mat der Zäit änneren.
/// Wéi gesot, d'Semantik wäert bal ëmmer ganz ähnlech wéi [C11's definition of volatile][c11] sinn.
///
/// De Compiler sollt d'relativ Uerdnung oder d'Zuel vu onbestännege Gedächtnisoperatiounen net änneren.
/// Wéi och ëmmer, onbestänneg Gedächtnisoperatiounen op Nullgréissten Typen (z. B. wann en Nullgréisstentyp op `read_volatile` weidergeleet gëtt) sinn noops a kënnen ignoréiert ginn.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Verhalen ass ondefinéiert wann eng vun de folgende Konditioune verletzt gëtt:
///
/// * `src` muss [valid] sinn fir ze liesen.
///
/// * `src` musse richteg ausgeriicht sinn.
///
/// * `src` muss op e richteg initialiséierte Wäert vum Typ `T` hiweisen.
///
/// Wéi [`read`] erstellt `read_volatile` eng bitvis Kopie vun `T`, egal ob `T` [`Copy`] ass.
/// Wann `T` net [`Copy`] ass, kann de Retourwäert an de Wäert op `*src` [violate memory safety][read-ownership] benotzen.
/// Wéi och ëmmer, net-["Copy"] Aarten am flüchtege Gedächtnis ze späichere si bal sécher falsch.
///
/// Bedenkt datt och wann `T` d'Gréisst `0` huet, muss de Zeiger net NULL sinn a richteg ausgeriicht sinn.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Just wéi an C, ob eng Operatioun onbestänneg ass, huet iwwerhaapt keng Auswierkungen op Froen, déi gläichzäiteg Zougang vu méi Themen hunn.Flüchtlëch Zougang behuelen sech genau wéi net-atomesch Zougang an där Hisiicht.
///
/// Besonnesch eng Course tëscht engem `read_volatile` an all Schreiweoperatioun op der selwechter Plaz ass ondefinéiert Verhalen.
///
/// # Examples
///
/// Basis Benotzung:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Net panikéieren fir Codegen Impakt méi kleng ze halen.
        abort();
    }
    // SAFETY: den Uruff muss de Sécherheetsvertrag fir `volatile_load` oprechterhalen.
    unsafe { intrinsics::volatile_load(src) }
}

/// Féiert eng onbestänneg Schreiwe vun enger Erënnerungsplaz mat dem gegebene Wäert ouni den ale Wäert ze liesen oder ze falen.
///
/// Flüchtlëch Operatioune si virgesinn op I/O Gedächtnis ze handelen, a si garantéiert net vum Compiler iwwer aner onbestänneg Operatiounen ofgeleet oder nei bestallt ze ginn.
///
/// `write_volatile` fällt net den Inhalt vun `dst`.Dëst ass sécher, awer et kéint Allocatiounen oder Ressourcen lecken, sou datt et oppasse sollt en Objet ze iwwerschreiwe wat sollt fale gelooss ginn.
///
/// Zousätzlech fällt et net `src`.Semantesch ass `src` an de Standort geplënnert deen vun `dst` gewisen gëtt.
///
/// # Notes
///
/// Rust huet am Moment kee rigoréis a formell definéierte Gedächtnismodell, sou datt déi präzis Semantik vun deem wat "volatile" hei bedeit ka mat der Zäit änneren.
/// Wéi gesot, d'Semantik wäert bal ëmmer ganz ähnlech wéi [C11's definition of volatile][c11] sinn.
///
/// De Compiler sollt d'relativ Uerdnung oder d'Zuel vu onbestännege Gedächtnisoperatiounen net änneren.
/// Wéi och ëmmer, onbestänneg Gedächtnisoperatiounen op Nullgréissten Typen (z. B. wann en Nullgréisstentyp op `write_volatile` weidergeleet gëtt) sinn noops a kënnen ignoréiert ginn.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Verhalen ass ondefinéiert wann eng vun de folgende Konditioune verletzt gëtt:
///
/// * `dst` muss [valid] fir schreift.
///
/// * `dst` musse richteg ausgeriicht sinn.
///
/// Bedenkt datt och wann `T` d'Gréisst `0` huet, muss de Zeiger net NULL sinn a richteg ausgeriicht sinn.
///
/// [valid]: self#safety
///
/// Just wéi an C, ob eng Operatioun onbestänneg ass, huet iwwerhaapt keng Auswierkungen op Froen, déi gläichzäiteg Zougang vu méi Themen hunn.Flüchtlëch Zougang behuelen sech genau wéi net-atomesch Zougang an där Hisiicht.
///
/// Besonnesch eng Course tëscht engem `write_volatile` an all aner Operatioun (Liesen oder Schreiwen) op der selwechter Plaz ass ondefinéiert Verhalen.
///
/// # Examples
///
/// Basis Benotzung:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Net panikéieren fir Codegen Impakt méi kleng ze halen.
        abort();
    }
    // SAFETY: den Uruff muss de Sécherheetsvertrag fir `volatile_store` oprechterhalen.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Zeiger `p` ausriichten.
///
/// Berechent Offset (wat d'Elementer vun der `stride` Schrëtt ugeet) déi op de Pointer `p` applizéiert muss ginn sou datt de Pointer `p` op `a` ausgeriicht ass.
///
/// Note: Dës Ëmsetzung gouf suergfälteg ugepasst op net panic.Et ass UB fir dëst op panic.
/// Déi eenzeg richteg Ännerung déi hei ka gemaach ginn ass Ännerung vun `INV_TABLE_MOD_16` an assoziéiert Konstante.
///
/// Wa mir jeemools décidéieren et méiglech ze maachen den intrinsesche mam `a` ze nennen, deen net eng Power-of-Two ass, wäert et wuel méi virsiichteg sinn, just zu enger naiver Ëmsetzung z'änneren anstatt dëst z'adaptéieren fir dës Ännerung z'empfänken.
///
///
/// All Froen ginn op@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Direkte Gebrauch vun dësen Intrinsike verbessert Codegen wesentlech um Opt-Niveau <=
    // 1, wou d'Methodversioune vun dësen Operatiounen net gezeechent sinn.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Berechent multiplikativ modulär invers vun `x` modulo `m`.
    ///
    /// Dës Ëmsetzung ass fir `align_offset` ugepasst an huet folgend Viraussetzungen:
    ///
    /// * `m` ass eng Kraaft vun zwee;
    /// * `x < m`; (wann `x ≥ m`, gitt amplaz `x % m`)
    ///
    /// Ëmsetzung vun dëser Funktioun soll net panic sinn.Ëmmer.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Multiplikativ modulär invers Tabell modulo 2⁴=16.
        ///
        /// Bedenkt datt dës Tabelle keng Wäerter enthält wou invers net existéieren (dh fir `0⁻¹ mod 16`, `2⁻¹ mod 16`, asw.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo fir deen den `INV_TABLE_MOD_16` geduecht ass.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // SIKKERHET: `m` ass verlaangt eng Power-of-Two ze sinn, also net null.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Mir iteréieren "up" mat der folgender Formel:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // bis 2²ⁿ ≥ m.Da kënne mir op eise gewënschte `m` reduzéieren andeems Dir d'Resultat `mod m` hëlt.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Bedenkt datt mir Wicklungsoperatiounen hei bewosst benotzen-déi originell Formel benotzt zB Subtraktioun `mod n`.
                // Et ass ganz gutt fir se `mod usize::MAX` ze maachen amplaz, well mir d'Resultat `mod n` souwisou um Enn huelen.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // SAFETY: `a` ass eng Kraaft-vun-Zwee, also net Null.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` Fall kann méi einfach duerch `-p (mod a)` berechent ginn, awer et hemmt d'Fäegkeet vum LLVM fir Instruktiounen wéi `lea` ze wielen.Amplaz mir berechnen
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // déi d'Operatiounen ronderëm de tragende verdeelt, awer de `and` genuch pessiméiere fir datt LLVM déi verschidde Optimiséierunge benotze kann, déi et weess.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Scho ausgeriicht.Yay!
        return 0;
    } else if stride == 0 {
        // Wann de Zeiger net ausgeriicht ass, an d'Element null-Gréisst ass, da gëtt kee Betrag vun Elementer de Zeiger jee ausgeriicht.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // SIKKERHET: a ass Kraaft-vun-zwee also net null.Stride==0 Fall gëtt uewe behandelt.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // SAFETY: gcdpow huet en Uewergrenz dat héchstens d'Zuel vu Stécker an engem Usize ass.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // SAFETY: gcd ass ëmmer méi grouss oder gläich wéi 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Dësen branch léist déi folgend linear Kongruenzgläichung:
        //
        // ` p + so = 0 mod a `
        //
        // `p` hei ass den Zeigewäert, `s`, Stride of `T`, `o` offset an `T`s, an `a`, déi gefrote Ausriichtung.
        //
        // Mat `g = gcd(a, s)`, an déi uewe genannten Zoustand, déi behaapt datt `p` och deelbar vu `g` ass, kënne mir `a' = a/g`, `s' = s/g`, `p' = p/g` bezeechnen, da gëtt dat gläichwäerteg wéi:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Den éischte Begrëff ass "the relative alignment of `p` to `a`" (gedeelt duerch den `g`), den zweete Begrëff ass den "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (erëm gedeelt duerch den `g`).
        //
        // Divisioun duerch `g` ass noutwendeg fir dat invers gutt geformt ze maachen wann `a` an `s` net Co-Prime sinn.
        //
        // Ausserdeem ass d'Resultat vun dëser Léisung net "minimal", also ass et néideg d'Resultat `o mod lcm(s, a)` ze huelen.Mir kënnen `lcm(s, a)` duerch just en `a'` ersetzen.
        //
        //
        //
        //
        //

        // SIKKERHET: `gcdpow` huet en Uewergrenz net méi grouss wéi d'Zuel vun den 0-Bits am `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // SAFETY: `a2` ass net null.Shifting `a` by `gcdpow` kann kee vun de Setbits verréckelen
        // an `a` (dovun huet en exakt een).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // SIKKERHET: `gcdpow` huet en Uewergrenz net méi grouss wéi d'Zuel vun den 0-Bits am `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SIKKERHET: `gcdpow` huet eng iewescht Grenz net méi grouss wéi d'Zuel vun den 0-Bit hannendrun
        // `a`.
        // Ausserdeem kann d'Subtraktioun net iwwerschwemmen, well `a2 = a >> gcdpow` wäert ëmmer méi streng si wéi `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // SAFETY: `a2` ass eng Kraaft-vun-zwee, wéi uewe bewisen.`s2` ass streng manner wéi `a2`
        // well `(s % a) >> gcdpow` streng manner wéi `a >> gcdpow` ass.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Kann guer net ausgeriicht ginn.
    usize::MAX
}

/// Vergläicht Matière Rotschléi fir Gläichheet.
///
/// Dëst ass d'selwecht wéi den `==` Operator ze benotzen, awer manner generesch:
/// d'Argumenter mussen `*const T` rau Zeigefanger sinn, net alles wat `PartialEq` implementéiert.
///
/// Dëst kann benotzt ginn fir `&T` Referenzen ze vergläichen (déi implizit op `*const T` zwéngen) duerch hir Adress anstatt d'Wäerter ze vergläichen op déi se weisen (wat d `PartialEq for &T` Implementatioun mécht).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Scheiwen ginn och no hirer Längt (Fettweiser) verglach:
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits ginn och duerch hir Ëmsetzung verglach:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Uweiser hu gläich Adressen.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Objeten hu gläich Adressen, awer `Trait` huet verschidden Implementatiounen.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Ëmwandlung vun der Referenz zu engem `*const u8` vergläicht mat der Adress.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash e roude Zeiger.
///
/// Dëst kann benotzt ginn fir eng `&T` Referenz ze hashéieren (déi implizit op `*const T` zwéngt) duerch seng Adress anstatt de Wäert op deen et weist (wat d `Hash for &T` Implementatioun mécht).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impls fir Funktiounsweiser
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: De Mëttelbesetzung als Usize ass fir AVR erfuerderlech
                // sou datt den Adressraum vum Quellfunktiounsweiser an der leschter Funktiounsweiser preservéiert gëtt.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: De Mëttelbesetzung als Usize ass fir AVR erfuerderlech
                // sou datt den Adressraum vum Quellfunktiounsweiser an der leschter Funktiounsweiser preservéiert gëtt.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Keng variadesch Funktioune mat 0 Parameteren
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Erstellt en `const` roude Zeiger op eng Plaz, ouni eng Zwëschenreferenz ze kreéieren.
///
/// Eng Referenz mam `&`/`&mut` ze kreéieren ass nëmmen erlaabt wann de Zeiger richteg ausgeriicht ass an op initialiséiert Daten hiweist.
/// Fir Fäll wou dës Ufuerderungen net hale sollten, réi Indikatoren amplaz benotzt ginn.
/// Wéi och ëmmer, `&expr as *const _` erstellt eng Referenz ier se op e rauen Zeiger geheit, an dës Referenz ass ënner de selwechte Regele wéi all aner Referenzen.
///
/// Dëse Makro kann e roude Zeiger *erstellen ouni* als éischt eng Referenz ze kreéieren.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` géif eng net ausgeriicht Referenz kreéieren, an domat Undefined Behaviour sinn!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Erstellt en `mut` roude Zeiger op eng Plaz, ouni eng Zwëschenreferenz ze kreéieren.
///
/// Eng Referenz mam `&`/`&mut` ze kreéieren ass nëmmen erlaabt wann de Zeiger richteg ausgeriicht ass an op initialiséiert Daten hiweist.
/// Fir Fäll wou dës Ufuerderungen net hale sollten, réi Indikatoren amplaz benotzt ginn.
/// Wéi och ëmmer, `&mut expr as *mut _` erstellt eng Referenz ier se op e rauen Zeiger geheit, an dës Referenz ass ënner de selwechte Regele wéi all aner Referenzen.
///
/// Dëse Makro kann e roude Zeiger *erstellen ouni* als éischt eng Referenz ze kreéieren.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` géif eng net ausgeriicht Referenz kreéieren, an domat Undefined Behaviour sinn!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` zwéngt d'Feld ze kopéieren amplaz eng Referenz ze kreéieren.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}