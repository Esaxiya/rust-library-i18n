use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// E Wéckel ronderëm e rau net-null `*mut T` dat weist datt de Besëtzer vun dësem Wéckel de Referent huet.
/// Nëtzlech fir Abstraktioune wéi `Box<T>`, `Vec<T>`, `String` an `HashMap<K, V>` ze bauen.
///
/// Am Géigesaz zu `*mut T`, behuelen `Unique<T>` "as if" et war eng Instanz vun `T`.
/// Et implementéiert `Send`/`Sync` wann `T` `Send`/`Sync` ass.
/// Et implizéiert och d'Aart vu staarken Aliasing garantéiert datt eng Instanz vun `T` kann erwaarden:
/// de Referent vum Zeiger soll net geännert ginn ouni en eenzegaartege Wee zu sengem Besëtz Unique.
///
/// Wann Dir net sécher sidd ob et richteg ass `Unique` fir Är Zwecker ze benotzen, betruecht `NonNull` ze benotzen, déi méi schwaach Semantik huet.
///
///
/// Am Géigesaz zu `*mut T` muss de Zeiger ëmmer net null sinn, och wann de Zeiger ni verfeiert gëtt.
/// Dëst ass sou datt Enums dëse verbuede Wäert als Diskriminant benotze kënnen-`Option<Unique<T>>` huet déiselwecht Gréisst wéi `Unique<T>`.
/// Wéi och ëmmer, de Zeiger kann ëmmer bongelen wann et net ofgeleent gëtt.
///
/// Am Géigesaz zu `*mut T` ass `Unique<T>` covariant iwwer `T`.
/// Dëst sollt ëmmer korrekt sinn fir all Typ deen den Unique aliasing Ufuerderunge respektéiert.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: dëse Marker huet keng Konsequenze fir Varianz, awer ass néideg
    // fir dropck ze verstoen datt mir logesch eng `T` hunn.
    //
    // Fir Detailer, kuckt:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` Zeigefanger sinn `Send` wann `T` `Send` ass well d'Donnéeë fir déi se referenzéieren net ausgeglach sinn.
/// Bedenkt datt dësen Aliasing-Invariant net vum Typ System verstäerkt gëtt;d'Abstraktioun mam `Unique` muss se duerchsetzen.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` Zeigefanger sinn `Sync` wann `T` `Sync` ass well d'Donnéeë fir déi se referenzéieren net ausgeglach sinn.
/// Bedenkt datt dësen Aliasing-Invariant net vum Typ System verstäerkt gëtt;d'Abstraktioun mam `Unique` muss se duerchsetzen.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Erstellt en neien `Unique` dee bongelt, awer gutt ausgeriicht ass.
    ///
    /// Dëst ass nëtzlech fir Typen z'initialiséieren déi liddereg allocéieren, wéi `Vec::new`.
    ///
    /// Bedenkt datt den Zeigewäert potenziell e gültege Zeiger fir en `T` duerstelle kann, dat heescht datt dëst net als "not yet initialized" Sentinellewäert dierf benotzt ginn.
    /// Typen déi faul zouginn, mussen d'Initialiséierung op anere Wee verfollegen.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // SAFETY: mem::align_of() bréngt e gëltegen, net null Zeiger zréck.Den
        // Konditioune fir new_unchecked() ze ruffe ginn esou respektéiert.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Erstellt en neien `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` muss net null sinn.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SAFETY: den Uruff muss garantéieren datt `ptr` net null ass.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Erstellt en neien `Unique` wann `ptr` net null ass.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SAFETY: De Zeiger gouf scho kontrolléiert an ass net null.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Erhält de Basis `*mut` Zeiger.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Stéiert d'Inhalter.
    ///
    /// Déi doraus resultéierend Liewensdauer ass u sech gebonnen, sou datt se sech "as if" verhält et war tatsächlech eng Instanz vun T déi ausgeléint gëtt.
    /// Wann eng méi laang (unbound) Liewensdauer gebraucht gëtt, benotzt `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SAFETY: den Uruffer muss garantéieren datt `self` all den
        // Ufuerderunge fir eng Referenz.
        unsafe { &*self.as_ptr() }
    }

    /// Mutéierend verweist den Inhalt.
    ///
    /// Déi doraus resultéierend Liewensdauer ass u sech gebonnen, sou datt se sech "as if" verhält et war tatsächlech eng Instanz vun T déi ausgeléint gëtt.
    /// Wann eng méi laang (unbound) Liewensdauer gebraucht gëtt, benotzt `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SAFETY: den Uruffer muss garantéieren datt `self` all den
        // Ufuerderunge fir eng mutabel Referenz.
        unsafe { &mut *self.as_ptr() }
    }

    /// Gitt op e Zeiger vun engem aneren Typ.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // SAFETY: Unique::new_unchecked() kreéiert eng nei eenzegaarteg a Bedierfnesser
        // de gegebenen Zeiger fir net null ze sinn.
        // Well mir eis als Zeiger weiderginn, kann et net null sinn.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SAFETY: Eng mutéierbar Referenz kann net null sinn
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}