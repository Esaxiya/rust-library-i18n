use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` awer net null a covariant.
///
/// Dëst ass dacks déi richteg Saach fir ze benotze wann Dir Datestrukture mat roude Weiser baut, awer ass schlussendlech méi geféierlech ze benotzen wéinst sengen zousätzlechen Eegeschaften.Wann Dir net sécher sidd ob Dir `NonNull<T>` benotze sollt, benotzt just `*mut T`!
///
/// Am Géigesaz zu `*mut T` muss de Zeiger ëmmer net null sinn, och wann de Zeiger ni verfeiert gëtt.Dëst ass sou datt Enums dëse verbuede Wäert als Diskriminant benotze kënnen-`Option<NonNull<T>>` huet déiselwecht Gréisst wéi `* mut T`.
/// Wéi och ëmmer, de Zeiger kann ëmmer bongelen wann et net ofgeleent gëtt.
///
/// Am Géigesaz zu `*mut T` gouf `NonNull<T>` gewielt fir covariant iwwer `T` ze sinn.Dëst mécht et méiglech d `NonNull<T>` ze benotzen wann Dir Kovariantentypen baut, awer féiert de Risiko vun der Ongerechtegkeet un wann et an engem Typ benotzt gëtt deen eigentlech net covariant sollt sinn.
/// (Déi entgéintgesate Wiel gouf fir `*mut T` gemaach, och wann technesch d'Unsoundness nëmme verursaacht ka ginn andeems Dir onsécher Funktiounen nennt.)
///
/// Kovarianz ass korrekt fir déi meescht sécher Abstraktiounen, wéi `Box`, `Rc`, `Arc`, `Vec` an `LinkedList`.Dëst ass de Fall well se en ëffentlechen API ubidden deen den normale gemeinsame XOR mutable Regele vun Rust follegt.
///
/// Wann Ären Typ net sécher covariant ka sinn, musst Dir sécherstellen datt en e puer zousätzlech Felder enthält fir Invarianz ze bidden.Oft ass dëst Feld en [`PhantomData`] Typ wéi `PhantomData<Cell<T>>` oder `PhantomData<&'a mut T>`.
///
/// Bedenkt datt `NonNull<T>` eng `From` Instanz fir `&T` huet.Wéi och ëmmer, dëst ännert net d'Tatsaach datt d'Mutatioun duerch en (Zeiger ofgeleet vun engem) gemeinsame Referenz ondefinéiert Verhalen ass, ausser wann d'Mutatioun an engem [`UnsafeCell<T>`] geschitt.Dat selwecht gëlt fir eng mutéierbar Referenz aus enger gemeinsamer Referenz ze kreéieren.
///
/// Wann Dir dës `From` Instanz ouni `UnsafeCell<T>` benotzt, ass et Är Verantwortung ze suergen datt `as_mut` ni geruff gëtt, an `as_ptr` gëtt ni fir Mutatioun benotzt.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` Zeigefanger sinn net `Send` well d'Donnéeë fir déi se referenzéieren aliaséiert kënne sinn.
// NB, dëst Impl ass onnéideg, awer sollt besser Feelermeldungen ubidden.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` Zeigefanger sinn net `Sync` well d'Donnéeë fir déi se referenzéieren aliaséiert kënne sinn.
// NB, dëst Impl ass onnéideg, awer sollt besser Feelermeldungen ubidden.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Erstellt en neien `NonNull` dee bongelt, awer gutt ausgeriicht ass.
    ///
    /// Dëst ass nëtzlech fir Typen z'initialiséieren déi liddereg allocéieren, wéi `Vec::new`.
    ///
    /// Bedenkt datt den Zeigewäert potenziell e gültege Zeiger fir en `T` duerstelle kann, dat heescht datt dëst net als "not yet initialized" Sentinellewäert dierf benotzt ginn.
    /// Typen déi faul zouginn, mussen d'Initialiséierung op anere Wee verfollegen.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // SAFETY: mem::align_of() bréngt en Net-Null Usize zréck, deen dann gegoss gëtt
        // zu engem * mut T.
        // Dofir ass `ptr` net null an d'Konditioune fir new_unchecked() ze ruffe ginn respektéiert.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Nees eng gemeinsam Referenzen op de Wäert.Am Géigesaz zu [`as_ref`] erfuerdert dëst net datt de Wäert initialiséiert muss ginn.
    ///
    /// Fir de mutable Kolleg [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Wann Dir dës Method rufft, musst Dir sécher sinn datt all déi folgend richteg sinn:
    ///
    /// * De Zeiger muss richteg ausgeriicht sinn.
    ///
    /// * Et muss "dereferencable" sinn am Sënn definéiert an [the module documentation].
    ///
    /// * Dir musst Rust Aliaséierungsregelen duerchsetzen, well d'zréckgesate Liewensdauer `'a` arbiträr gewielt gëtt an net onbedéngt déi aktuell Liewensdauer vun den Date reflektéiert.
    ///
    ///   Besonnesch fir d'Dauer vun dëser Liewensdauer däerf d'Erënnerung, op déi de Zeiger weist, net mutéiert ginn (ausser am `UnsafeCell`).
    ///
    /// Dëst gëllt och wann d'Resultat vun dëser Method net benotzt gëtt!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // SAFETY: den Uruffer muss garantéieren datt `self` all den
        // Ufuerderunge fir eng Referenz.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Nees eng eenzegaarteg Referenze fir de Wäert.Am Géigesaz zu [`as_mut`] erfuerdert dëst net datt de Wäert initialiséiert muss ginn.
    ///
    /// Fir de gemeinsame Kolleg [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Wann Dir dës Method rufft, musst Dir sécher sinn datt all déi folgend richteg sinn:
    ///
    /// * De Zeiger muss richteg ausgeriicht sinn.
    ///
    /// * Et muss "dereferencable" sinn am Sënn definéiert an [the module documentation].
    ///
    /// * Dir musst Rust Aliaséierungsregelen duerchsetzen, well d'zréckgesate Liewensdauer `'a` arbiträr gewielt gëtt an net onbedéngt déi aktuell Liewensdauer vun den Date reflektéiert.
    ///
    ///   Besonnesch fir d'Dauer vun dëser Liewensdauer däerf d'Erënnerung, op déi de Zeiger weist, net zougänglech (gelies oder geschriwwe ginn) duerch all aner Zeiger ginn.
    ///
    /// Dëst gëllt och wann d'Resultat vun dëser Method net benotzt gëtt!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // SAFETY: den Uruffer muss garantéieren datt `self` all den
        // Ufuerderunge fir eng Referenz.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Erstellt en neien `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` muss net null sinn.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SAFETY: den Uruff muss garantéieren datt `ptr` net null ass.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Erstellt en neien `NonNull` wann `ptr` net null ass.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SAFETY: De Zeiger ass scho kontrolléiert an ass net null
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Féiert déiselwecht Funktionalitéit wéi [`std::ptr::from_raw_parts`], ausser datt en `NonNull` Zeiger zréckkomm ass, am Géigesaz zu engem rauen `*const` Zeiger.
    ///
    ///
    /// Kuckt d'Dokumentatioun vum [`std::ptr::from_raw_parts`] fir méi Detailer.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // SAFETY: D'Resultat vun `ptr::from::raw_parts_mut` ass net null well `data_address` ass.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Zerfall en (méiglecherweis breet) Zeiger an d'Adress an d'Metadatekomponenten.
    ///
    /// De Zeiger kann méi spéit mat [`NonNull::from_raw_parts`] rekonstruéiert ginn.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Erhält de Basis `*mut` Zeiger.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Nees eng gemeinsam Referenz op de Wäert.Wann de Wäert oninitialiséiert ka ginn, muss [`as_uninit_ref`] amplaz benotzt ginn.
    ///
    /// Fir de mutable Kolleg [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Wann Dir dës Method rufft, musst Dir sécher sinn datt all déi folgend richteg sinn:
    ///
    /// * De Zeiger muss richteg ausgeriicht sinn.
    ///
    /// * Et muss "dereferencable" sinn am Sënn definéiert an [the module documentation].
    ///
    /// * De Zeiger muss op eng initialiséiert Instanz vun `T` weisen.
    ///
    /// * Dir musst Rust Aliaséierungsregelen duerchsetzen, well d'zréckgesate Liewensdauer `'a` arbiträr gewielt gëtt an net onbedéngt déi aktuell Liewensdauer vun den Date reflektéiert.
    ///
    ///   Besonnesch fir d'Dauer vun dëser Liewensdauer däerf d'Erënnerung, op déi de Zeiger weist, net mutéiert ginn (ausser am `UnsafeCell`).
    ///
    /// Dëst gëllt och wann d'Resultat vun dëser Method net benotzt gëtt!
    /// (Deen Deel iwwer d'Initialiséierung ass nach net komplett decidéiert, awer bis et ass, ass déi eenzeg sécher Approche ze suergen datt se wierklech initialiséiert ginn.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SAFETY: den Uruffer muss garantéieren datt `self` all den
        // Ufuerderunge fir eng Referenz.
        unsafe { &*self.as_ptr() }
    }

    /// Nees eng eenzegaarteg Referenz op de Wäert.Wann de Wäert oninitialiséiert ka ginn, muss [`as_uninit_mut`] amplaz benotzt ginn.
    ///
    /// Fir de gemeinsame Kolleg [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Wann Dir dës Method rufft, musst Dir sécher sinn datt all déi folgend richteg sinn:
    ///
    /// * De Zeiger muss richteg ausgeriicht sinn.
    ///
    /// * Et muss "dereferencable" sinn am Sënn definéiert an [the module documentation].
    ///
    /// * De Zeiger muss op eng initialiséiert Instanz vun `T` weisen.
    ///
    /// * Dir musst Rust Aliaséierungsregelen duerchsetzen, well d'zréckgesate Liewensdauer `'a` arbiträr gewielt gëtt an net onbedéngt déi aktuell Liewensdauer vun den Date reflektéiert.
    ///
    ///   Besonnesch fir d'Dauer vun dëser Liewensdauer däerf d'Erënnerung, op déi de Zeiger weist, net zougänglech (gelies oder geschriwwe ginn) duerch all aner Zeiger ginn.
    ///
    /// Dëst gëllt och wann d'Resultat vun dëser Method net benotzt gëtt!
    /// (Deen Deel iwwer d'Initialiséierung ass nach net komplett decidéiert, awer bis et ass, ass déi eenzeg sécher Approche ze suergen datt se wierklech initialiséiert ginn.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SAFETY: den Uruffer muss garantéieren datt `self` all den
        // Ufuerderunge fir eng mutabel Referenz.
        unsafe { &mut *self.as_ptr() }
    }

    /// Gitt op e Zeiger vun engem aneren Typ.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SAFETY: `self` ass en `NonNull` Zeiger deen onbedéngt net null ass
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Erstellt eng net-null Roh Scheif aus engem dënnem Zeiger an enger Längt.
    ///
    /// D `len` Argument ass d'Zuel vun **Elementer**, net d'Zuel vu Bytes.
    ///
    /// Dës Funktioun ass sécher, awer d'Dereferenzéiere vum Retourwäert ass net sécher.
    /// Kuckt d'Dokumentatioun vum [`slice::from_raw_parts`] fir d'Scheifsécherheetsufuerderungen.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // kreéiert e Stéckzeiger wann Dir mat engem Zeigefanger op dat éischt Element ufänkt
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Bedenkt datt dëst Beispill kënschtlech e Gebrauch vun dëser Method beweist, awer `looss Slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // SAFETY: `data` ass en `NonNull` Zeiger deen onbedéngt net null ass
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Nees d'Längt vun engem Net-Null Roh Slice.
    ///
    /// De zréckgezunnene Wäert ass d'Zuel vun **Elementer**, net d'Zuel vu Bytes.
    ///
    /// Dës Funktioun ass sécher, och wann déi net-null Roche Scheif net zu engem Slice kann derereferéiert ginn, well de Zeiger keng gëlteg Adress huet.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Nees en Net-Nullzeiger an de Puffer vun der Scheif.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SAFETY: Mir wëssen datt `self` net null ass.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Nees e roude Zeigefanger op de Puffer vun der Scheif.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Gitt eng gemeinsam Referenz op e Stéck méiglecherweis net initialiséiert Wäerter.Am Géigesaz zu [`as_ref`] erfuerdert dëst net datt de Wäert initialiséiert muss ginn.
    ///
    /// Fir de mutable Kolleg [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Wann Dir dës Method rufft, musst Dir sécher sinn datt all déi folgend richteg sinn:
    ///
    /// * De Zeiger muss [valid] sinn fir fir `ptr.len() * mem::size_of::<T>()` vill Bytes ze liesen, an et muss richteg ausgeriicht sinn.Dëst bedeit besonnesch:
    ///
    ///     * De ganze Gedächtnisberäich vun dëser Scheif muss an engem eenzelen zougestellten Objet enthale sinn!
    ///       Scheiwen kënnen ni iwwer verschidde zougewisen Objete spannen.
    ///
    ///     * De Zeiger muss och fir Nulllängt Scheiwen ausgeriicht sinn.
    ///     Ee Grond dofir ass datt Enum Layout Optimiséierungen op Referenzen (abegraff Scheiwen vun all Längt) vertraue kënnen an net null sinn fir se vun aneren Daten z'ënnerscheeden.
    ///
    ///     Dir kënnt e Zeiger kréien deen als `data` benotzbar ass fir Nulllängt Scheiwen mat [`NonNull::dangling()`].
    ///
    /// * D'Gesamtgréisst `ptr.len() * mem::size_of::<T>()` vun der Scheif däerf net méi grouss si wéi `isize::MAX`.
    ///   Kuckt d'Sécherheetsdokumentatioun vun [`pointer::offset`].
    ///
    /// * Dir musst Rust Aliaséierungsregelen duerchsetzen, well d'zréckgesate Liewensdauer `'a` arbiträr gewielt gëtt an net onbedéngt déi aktuell Liewensdauer vun den Date reflektéiert.
    ///   Besonnesch fir d'Dauer vun dëser Liewensdauer däerf d'Erënnerung, op déi de Zeiger weist, net mutéiert ginn (ausser am `UnsafeCell`).
    ///
    /// Dëst gëllt och wann d'Resultat vun dëser Method net benotzt gëtt!
    ///
    /// Kuckt och [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // SAFETY: den Uruff muss de Sécherheetsvertrag fir `as_uninit_slice` oprechterhalen.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Gitt eng eenzegaarteg Referenz op e Stéck méiglecherweis net initialiséiert Wäerter.Am Géigesaz zu [`as_mut`] erfuerdert dëst net datt de Wäert initialiséiert muss ginn.
    ///
    /// Fir de gemeinsame Kolleg [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Wann Dir dës Method rufft, musst Dir sécher sinn datt all déi folgend richteg sinn:
    ///
    /// * De Zeiger muss [valid] sinn fir ze liesen a schreift fir `ptr.len() * mem::size_of::<T>()` vill Bytes, an et muss richteg ausgeriicht sinn.Dëst bedeit besonnesch:
    ///
    ///     * De ganze Gedächtnisberäich vun dëser Scheif muss an engem eenzelen zougestellten Objet enthale sinn!
    ///       Scheiwen kënnen ni iwwer verschidde zougewisen Objete spannen.
    ///
    ///     * De Zeiger muss och fir Nulllängt Scheiwen ausgeriicht sinn.
    ///     Ee Grond dofir ass datt Enum Layout Optimiséierungen op Referenzen (abegraff Scheiwen vun all Längt) vertraue kënnen an net null sinn fir se vun aneren Daten z'ënnerscheeden.
    ///
    ///     Dir kënnt e Zeiger kréien deen als `data` benotzbar ass fir Nulllängt Scheiwen mat [`NonNull::dangling()`].
    ///
    /// * D'Gesamtgréisst `ptr.len() * mem::size_of::<T>()` vun der Scheif däerf net méi grouss si wéi `isize::MAX`.
    ///   Kuckt d'Sécherheetsdokumentatioun vun [`pointer::offset`].
    ///
    /// * Dir musst Rust Aliaséierungsregelen duerchsetzen, well d'zréckgesate Liewensdauer `'a` arbiträr gewielt gëtt an net onbedéngt déi aktuell Liewensdauer vun den Date reflektéiert.
    ///   Besonnesch fir d'Dauer vun dëser Liewensdauer däerf d'Erënnerung, op déi de Zeiger weist, net zougänglech (gelies oder geschriwwe ginn) duerch all aner Zeiger ginn.
    ///
    /// Dëst gëllt och wann d'Resultat vun dëser Method net benotzt gëtt!
    ///
    /// Kuckt och [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Dëst ass sécher well `memory` gëlteg ass fir ze liesen a schreift fir `memory.len()` vill Bytes.
    /// // Bedenkt datt `memory.as_mut()` uruffen hei net erlaabt ass well den Inhalt kann net initialiséiert ginn.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // SAFETY: den Uruff muss de Sécherheetsvertrag fir `as_uninit_slice_mut` oprechterhalen.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Nees e roude Zeiger op en Element oder en Ënnerschnitt, ouni Grenzen ze maachen.
    ///
    /// Dës Method mat engem out-of-bounds Index nennen oder wann `self` net derferencabel ass ass *[ondefinéiert Verhalen]* och wann de resultéierenden Zeiger net benotzt gëtt.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // SAFETY: den Uruff garantéiert datt `self` derferencabel ass an `index` bannent Grenzen.
        // Als Konsequenz kann de resultéierenden Zeiger net NULL sinn.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // SAFETY: En eenzegaartege Zeiger kann net null sinn, sou d'Konditioune fir
        // new_unchecked() respektéiert ginn.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SAFETY: Eng mutéierbar Referenz kann net null sinn.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // SAFETY: Eng Referenz kann net null sinn, sou d'Konditioune fir
        // new_unchecked() respektéiert ginn.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}