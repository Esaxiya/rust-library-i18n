// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Rotéiert d'Band `[mid-left, mid+right)` sou datt d'Element am `mid` dat éischt Element gëtt.Gläichwäerteg rotéiert d'Band `left` Elementer no lénks oder `right` Elementer no riets.
///
/// # Safety
///
/// De spezifizéierte Beräich muss valabel si fir ze liesen an ze schreiwen.
///
/// # Algorithm
///
/// Algorithmus 1 gëtt fir kleng Wäerter vun `left + right` oder fir grouss `T` benotzt.
/// D'Elementer ginn an hir final Positioune geplënnert ee gläichzäiteg ugefaange bei `mid - left` a viru mat `right` Schrëtt modulo `left + right`, sou datt nëmmen eng temporär gebraucht gëtt.
/// Eventuell komme mir zréck bei `mid - left`.
/// Wéi och ëmmer, wann `gcd(left + right, right)` net 1 ass, sinn déi uewe genannte Schrëtt iwwersprongen iwwer Elementer.
/// Zum Beispill:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Glécklecherweis ass d'Zuel vun den iwwersprongenen Elementer tëscht finaliséierten Elementer ëmmer gläich, sou datt mir eis Ausgangspositioun just kompenséiere kënnen a méi Ronne maachen (d'Gesamtzuel vun de Ronne ass den `gcd(left + right, right)` value).
///
/// D'Enn vum Resultat ass datt all Elementer eemol finaliséiert sinn an nëmmen eemol.
///
/// Algorithmus 2 gëtt benotzt wann `left + right` grouss ass awer `min(left, right)` kleng genuch ass fir op e Stackpuffer ze passen.
/// D `min(left, right)` Elementer ginn op de Puffer kopéiert, `memmove` gëtt op déi aner applizéiert, an déi op de Puffer ginn zréck an d'Lach op der entgéintgesater Säit wou se entstanen sinn.
///
/// Algorithmen, déi vektoriséiert kënne ginn, iwwerstierzen déi uewe genannten eemol `left + right` grouss genuch gëtt.
/// Algorithmus 1 kann duerch chunking a vill Ronnen gläichzäiteg vectoriséiert ginn, awer et ginn ze wéineg Ronnen am Duerchschnëtt bis `left + right` enorm ass, an de schlëmmste Fall vun enger eenzeger Ronn ass ëmmer do.
/// Amplaz benotzt den Algorithmus 3 widderholl Tauschen vun `min(left, right)` Elementer bis e méi klengt Rotatiounsprobleem lénks ass.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// wann `left < right` d'Austausch geschitt amplaz vu lénks.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. déi hei ënnendrënner Algorithmen kënnen ausfalen, wann dës Fäll net kontrolléiert ginn
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algorithmus 1 Microbenchmarks weisen datt d'Duerchschnëttsleistung fir zoufälleg Verrécklunge bis de `left + right == 32` besser ass, awer déi schlëmmste Performance brécht souguer ëm 16.
            // 24 gouf als Mëttelgrond gewielt.
            // Wann d'Gréisst vum `T` méi grouss ass wéi 4 "usize", ass dësen Algorithmus och besser wéi aner Algorithmen.
            //
            //
            let x = unsafe { mid.sub(left) };
            // Ufank vun der éischter Ronn
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` ka viru Hand fonnt ginn andeems Dir `gcd(left + right, right)` berechent, awer et ass méi séier eng Loop ze maachen déi de Gcd als Nieweneffekt berechent, da maacht de Rescht vum Stéck
            //
            //
            let mut gcd = right;
            // Benchmarks weisen datt et méi séier ass temporär de ganzen Wee duerchzetauschen anstatt eng temporär eemol ze liesen, no hannen ze kopéieren, an dann déi temporär ganz um Enn ze schreiwen.
            // Dëst ass méiglecherweis doduerch datt de Wiessel oder Ersatz vun temporäre nëmmen eng Erënnerungsadress an der Loop benotzt anstatt zwee ze managen.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // amplaz `i` eropzesetzen an duerno ze kontrolléieren ob et ausserhalb vun de Grenzen ass, kucke mir ob `i` bei der nächster Inkrement ausserhalb vun de Grenze geet.
                // Dëst vermeit all Wéckelung vun Zeigefanger oder `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // Enn vun der éischter Ronn
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // dës bedingt muss hei sinn wann `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // fäerdeg de Stéck mat méi Ronnen
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` ass keen Nullgréisstentyp, also ass et an der Rei ze deelen duerch seng Gréisst.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algorithmus 2 Den `[T; 0]` hei ass ze garantéieren datt dës passend fir T ausgeriicht ass
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algorithmus 3 Et ass en alternativen Wee fir ze tauschen deen et fënnt wou de leschten Tausch vun dësem Algorithmus wier, an tauschen mat deem leschte Stéck amplaz vun Nopeschstécker ze tauschen wéi dësen Algorithmus mécht, awer dës Manéier ass nach ëmmer méi séier.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algorithmus 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}