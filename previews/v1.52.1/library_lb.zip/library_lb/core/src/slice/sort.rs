//! Scheiwenzortéierung
//!
//! Dëst Modul enthält e Sortéierungsalgorithmus baséiert op dem Orson Peters 'Muster-Néierlag Quicksort, verëffentlecht op: <https://github.com/orlp/pdqsort>
//!
//!
//! Onbestänneg Sortéierung ass kompatibel mat libcore well et keng Erënnerung allocéiert, am Géigesaz zu eiser stabiler Sortéierungsimplementatioun.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Wann erofgefall, Kopie vun `src` op `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // SAFETY: Dëst ass eng Helfer Klass.
        //          Kuckt w.e.g. seng Benotzung fir Richtegkeet.
        //          Nämlech muss ee sécher sinn datt `src` an `dst` net iwwerlappt wéi et vum `ptr::copy_nonoverlapping` erfuerderlech ass.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Verréckelt dat éischt Element no riets bis et e méi grousst oder gläichberechtegt Element begéint.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SAFETY: Déi onsécher Operatiounen hei ënnendrënner involvéieren Indexéierung ouni gebonne Scheck (`get_unchecked` an `get_unchecked_mut`)
    // a kopéieren Erënnerung (`ptr::copy_nonoverlapping`).
    //
    // a.Indexéieren:
    //  1. Mir hunn d'Gréisst vum Array op>=2 kontrolléiert.
    //  2. All d'Indexéierung déi mir maachen ass ëmmer héchstens tëscht {0 <= index < len}.
    //
    // b.Erënnerung kopéieren
    //  1. Mir kréien Uweiser op Referenzen déi garantéiert gëlteg sinn.
    //  2. Si kënnen net iwwerlappt well mir Indikatiounen op Ënnerscheedindizes vun der Scheif kréien.
    //     Nämlech `i` an `i-1`.
    //  3. Wann d'Scheif richteg ausgeriicht ass, sinn d'Elementer richteg ausgeriicht.
    //     Et ass d'Verantwortung vum Uruffer fir sécher ze sinn datt de Steck richteg ausgeriicht ass.
    //
    // Gesinn Kommentaren ënnendrënner fir weider Detailer.
    unsafe {
        // Wann déi éischt zwee Elementer net an der Rei sinn ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Liest dat éischt Element an eng Stack-zougestellte Variabel.
            // Wann eng folgend Verglachsoperatioun panics, `hole` fällt a schreift automatesch d'Element zréck an d'Scheif.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Beweegt `i`-th Element eng Plaz no lénks a verréckelt also d'Lach no riets.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` gëtt erofgefall a kopéiert domat `tmp` an de Rescht Lach am `v`.
        }
    }
}

/// Verréckelt dat lescht Element no lénks bis et e méi klengt oder gläiche Element begéint.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SAFETY: Déi onsécher Operatiounen hei ënnendrënner involvéieren Indexéierung ouni gebonne Scheck (`get_unchecked` an `get_unchecked_mut`)
    // a kopéieren Erënnerung (`ptr::copy_nonoverlapping`).
    //
    // a.Indexéieren:
    //  1. Mir hunn d'Gréisst vum Array op>=2 kontrolléiert.
    //  2. All d'Indexéierung déi mir maachen ass ëmmer héchstens tëscht `0 <= index < len-1`.
    //
    // b.Erënnerung kopéieren
    //  1. Mir kréien Uweiser op Referenzen déi garantéiert gëlteg sinn.
    //  2. Si kënnen net iwwerlappt well mir Indikatiounen op Ënnerscheedindizes vun der Scheif kréien.
    //     Nämlech `i` an `i+1`.
    //  3. Wann d'Scheif richteg ausgeriicht ass, sinn d'Elementer richteg ausgeriicht.
    //     Et ass d'Verantwortung vum Uruffer fir sécher ze sinn datt de Steck richteg ausgeriicht ass.
    //
    // Gesinn Kommentaren ënnendrënner fir weider Detailer.
    unsafe {
        // Wann déi lescht zwee Elementer net an der Rei sinn ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Liest dat lescht Element an eng Stack-zougestellte Variabel.
            // Wann eng folgend Verglachsoperatioun panics, `hole` fällt a schreift automatesch d'Element zréck an d'Scheif.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Beweegt `i`-th Element eng Plaz no riets a verréckelt also d'Lach no lénks.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` gëtt erofgefall a kopéiert domat `tmp` an de Rescht Lach am `v`.
        }
    }
}

/// Deelweis sortéiert e Stéck andeems Dir verschidden ausbestellten Elementer ronderëm verréckelt.
///
/// Retour `true` wann d'Scheif um Enn sortéiert ass.Dës Funktioun ass *O*(*n*) am schlëmmste Fall.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Maximal Unzuel vun ugrenzenden ausseruerdentleche Puer déi verréckelt ginn.
    const MAX_STEPS: usize = 5;
    // Wann d'Scheedung méi kuerz ass wéi dëst, verännert keng Elementer.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // SAFETY: Mir hunn explizit déi gebonne Kontroll mat `i < len` gemaach.
        // All eis uschléissend Indexéierung ass nëmmen am Beräich `0 <= index < len`
        unsafe {
            // Fannt d'nächst Pair vu benachbarten ausbestellten Elementer.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Si mir fäerdeg?
        if i == len {
            return true;
        }

        // Veränner net Elementer op kuerze Arrays, dat huet e Performance kascht.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Tauscht dat fonnt Puer Elementer aus.Dëst setzt se an der richteger Reiefolleg.
        v.swap(i - 1, i);

        // Verréckelt dat méi klengt Element no lénks.
        shift_tail(&mut v[..i], is_less);
        // Verréckelt dat gréissert Element no riets.
        shift_head(&mut v[i..], is_less);
    }

    // Huet et net fäerdeg d'Scheif an der limitéierter Unzuel u Schrëtt ze sortéieren.
    false
}

/// Sortéiert e Stéck mat Insertion Sort, wat *O*(*n*^ 2) am schlëmmste Fall ass.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Sortéiert `v` mat Heapsort, wat *O*(*n*\*log(* n*)) am schlëmmste Fall garantéiert.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Dëse binäre Koup respektéiert den onverännerlechen `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Kanner vun `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Wielt dat gréissert Kand.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Stop wann den Invariant op `node` hält.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Tauscht `node` mam gréissere Kand, réckelt e Schrëtt no ënnen, a weider sift.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Baut de Koup a Linearzäit.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pop maximal Elementer vum Koup.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Partituren `v` an Elementer méi kleng wéi `pivot`, gefollegt vun Elementer méi grouss wéi oder gläich wéi `pivot`.
///
///
/// Gitt d'Zuel vun Elementer méi kleng wéi `pivot` zréck.
///
/// Partitionéiere gëtt block-by-block gemaach fir d'Käschte vun de Verzweigungsoperatiounen ze minimiséieren.
/// Dës Iddi gëtt am [BlockQuicksort][pdf] Pabeier presentéiert.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Zuel vun Elementer an engem typesche Block.
    const BLOCK: usize = 128;

    // De Partitionéierungs Algorithmus widderhëlt déi folgend Schrëtt bis zum Ofschloss:
    //
    // 1. Spuer e Block vun der lénker Säit fir Elementer z'identifizéieren méi grouss wéi oder gläich wéi de Pivot.
    // 2. Verfollegt e Block vun der rietser Säit fir Elementer z'identifizéieren, déi méi kleng si wéi de Pivot.
    // 3. Austausch déi identifizéiert Elementer tëscht lénks a riets.
    //
    // Mir halen déi folgend Variabelen fir e Block vun Elementer:
    //
    // 1. `block` - Zuel vun Elementer am Block.
    // 2. `start` - Start Zeiger an den `offsets` Array.
    // 3. `end` - Endweiser an den `offsets` Array.
    // 4. `Offsets, Indizes vun ausbestellten Elementer am Block.

    // Den aktuelle Block op der lénker Säit (vun `l` op `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Den aktuelle Block op der rietser Säit (vun `r.sub(block_r)` to `r`).
    // SAFETY: D'Dokumentatioun fir .add() ernimmt speziell datt `vec.as_ptr().add(vec.len())` ëmmer sécher ass '
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Wa mir VLAs kréien, probéiert e Layer `min(v.len(), 2 * BLOCK) ze kreéieren éischter
    // wéi zwee fix-Gréisst Arrays vun der Längt `BLOCK`.VLAs kéinte méi cacheeffizient sinn.

    // Gitt d'Zuel vun Elementer tëscht den Zeigefanger `l` (inclusive) an `r` (exclusive) zréck.
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Mir si mat Partitionéierung block-by-block fäerdeg wann `l` an `r` ganz no kommen.
        // Da maache mir e puer Fléckaarbechte fir déi reschtlech Elementer dertëschent ze partitionéieren.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Zuel vun de verbleiwen Elementer (nach ëmmer net am Verglach mam Pivot).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Ajustéiert d'Blockgréissten sou datt de lénksen a richtege Block net iwwerlappt, awer perfekt ausgeriicht gëtt fir de ganze Rescht Lück ze decken.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Trace `block_l` Elementer vun der lénker Säit.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // SAFETY: Déi onsécher Operatiounen hei ënnendrënner beinhalt d'Benotzung vum `offset`.
                //         Geméiss de Konditioune vun der Funktioun erfuerderlech, erfëllen mir se well:
                //         1. `offsets_l` ass Stack-zougewisen, an domat als separat zougewisen Objet.
                //         2. D'Funktioun `is_less` bréngt en `bool` zréck.
                //            Goss en `bool` wäert ni `isize` iwwerschwemmen.
                //         3. Mir hu garantéiert datt `block_l` `<= BLOCK` wäert sinn.
                //            Plus war `end_l` ufanks op de Startzeiger vun `offsets_` gesat, deen am Stack deklaréiert gouf.
                //            Dofir wësse mer datt och am schlëmmste Fall (all Uruffungen vun `is_less` falsch zréckginn) wäerte mir nëmmen héchstens 1 Byte um Enn sinn.
                //        Eng aner Onsécherheetsoperatioun hei ass dereferencing `elem`.
                //        Wéi och ëmmer, `elem` war ufanks de Startzeiger op d'Scheedung déi ëmmer gëlteg ass.
                unsafe {
                    // Branchless Verglach.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Trace `block_r` Elementer vun der rietser Säit.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // SAFETY: Déi onsécher Operatiounen hei ënnendrënner beinhalt d'Benotzung vum `offset`.
                //         Geméiss de Konditioune vun der Funktioun erfuerderlech, erfëllen mir se well:
                //         1. `offsets_r` ass Stack-zougewisen, an domat als separat zougewisen Objet.
                //         2. D'Funktioun `is_less` bréngt en `bool` zréck.
                //            Goss en `bool` wäert ni `isize` iwwerschwemmen.
                //         3. Mir hu garantéiert datt `block_r` `<= BLOCK` wäert sinn.
                //            Plus war `end_r` ufanks op de Startzeiger vun `offsets_` gesat, deen am Stack deklaréiert gouf.
                //            Sou wësse mir datt och am schlëmmste Fall (all Uruffungen vun `is_less` nees richteg sinn) wäerte mir nëmmen héchstens 1 Byte um Enn sinn.
                //        Eng aner Onsécherheetsoperatioun hei ass dereferencing `elem`.
                //        Wéi och ëmmer, `elem` war am Ufank `1 *sizeof(T)` laanscht d'Enn a mir dekrementéiere se vum `1* sizeof(T)` ier Dir op se zougitt.
                //        Plus, `block_r` gouf behaapt manner wéi `BLOCK` ze sinn an `elem` wäert also héchstens op den Ufank vun der Scheif weisen.
                unsafe {
                    // Branchless Verglach.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Zuel vun ausbestellten Elementer fir tëscht lénks a riets ze wiesselen.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Amplaz e Paar zu der Zäit ëmzetauschen ass et méi effizient eng zyklesch Permutatioun ze maachen.
            // Dëst ass net strikt gläichwäerteg mam Tauschen, awer produzéiert en ähnlecht Resultat mat manner Gedächtnisoperatiounen.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // All ausbestellten Elementer am lénke Block goufe geréckelt.Gitt an den nächsten Block.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // All ausbestellten Elementer am richtege Block goufe geréckelt.Plënnert op de fréiere Block.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Alles wat elo bleift ass héchstens e Block (entweder lénks oder riets) mat ausbestellten Elementer déi musse geréckelt ginn.
    // Esou verbleiwen Elementer kënnen einfach op d'Enn bannent hirem Block verréckelt ginn.
    //

    if start_l < end_l {
        // De lénke Block bleift.
        // Beweegt seng verbleiwen ausseruerdentlech Elementer ganz riets.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // De richtege Block bleift.
        // Beweegt seng verbleiwen Elementer ausser Uerdnung ganz lénks.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Näischt anescht ze maachen, mir si fäerdeg.
        width(v.as_mut_ptr(), l)
    }
}

/// Partituren `v` an Elementer méi kleng wéi `v[pivot]`, gefollegt vun Elementer méi grouss wéi oder gläich wéi `v[pivot]`.
///
///
/// Nees eng Tupel vun:
///
/// 1. Zuel vun Elementer méi kleng wéi `v[pivot]`.
/// 2. Richteg wann `v` scho partitionéiert war.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Place de pivot um Ufank vun Slice.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Liest de Pivot an eng Stack-allocéiert Variabel fir Effizienz.
        // Wann eng folgend Vergläichsoperatioun panics, gëtt de Pivot automatesch an d'Scheif zréckgeschriwwen.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Fannt déi éischt Koppel vun ausbestellten Elementer.
        let mut l = 0;
        let mut r = v.len();

        // SAFETY: D'Onsécherheet hei ënnendrënner implizéiert d'Indexéierung vun engem Array.
        // Fir déi éischt: Mir maachen d'Grenze scho mat `l < r`.
        // Fir déi zweet: Mir hunn am Ufank `l == 0` an `r == v.len()` a mir hunn deen `l < r` bei all Indexéierungsoperatioun kontrolléiert.
        //                     Vun hei wësse mer datt `r` op d'mannst `r == l` muss sinn, wat als gëlteg vun der éischter gewise gouf.
        unsafe {
            // Fannt dat éischt Element méi wéi oder gläich wéi de Pivot.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Fannt dat lescht Element méi kleng wéi de Pivot.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` geet aus dem Ëmfang eraus a schreift de Pivot (dat ass eng stack-allocéiert Variabel) zréck an d'Scheif wou et ursprénglech war.
        // Dëse Schrëtt ass kritesch fir d'Sécherheet ze garantéieren!
        //
    };

    // Place de pivot tëscht den zwou Cloisonnementer.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Partituren `v` an Elementer gläich wéi `v[pivot]` gefollegt vun Elementer méi grouss wéi `v[pivot]`.
///
/// Nees d'Zuel vun den Elementer gläich wéi de Pivot.
/// Et gëtt ugeholl datt `v` keng Elementer enthält méi kleng wéi de Pivot.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Place de pivot um Ufank vun Slice.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Liest de Pivot an eng Stack-allocéiert Variabel fir Effizienz.
    // Wann eng folgend Vergläichsoperatioun panics, gëtt de Pivot automatesch an d'Scheif zréckgeschriwwen.
    // SAFETY: De Zeiger hei ass gëlteg well en aus enger Referenz op e Stéck kritt gëtt.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Elo Partitur de Slice.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // SAFETY: D'Onsécherheet hei ënnendrënner implizéiert d'Indexéierung vun engem Array.
        // Fir déi éischt: Mir maachen d'Grenze scho mat `l < r`.
        // Fir déi zweet: Mir hunn am Ufank `l == 0` an `r == v.len()` a mir hunn deen `l < r` bei all Indexéierungsoperatioun kontrolléiert.
        //                     Vun hei wësse mer datt `r` op d'mannst `r == l` muss sinn, wat als gëlteg vun der éischter gewise gouf.
        unsafe {
            // Fannt dat éischt Element méi grouss wéi de Pivot.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Fannt dat lescht Element gläich dem Pivot.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Si mir fäerdeg?
            if l >= r {
                break;
            }

            // Tauscht dat fonnt Paart aus bestellten Elementer.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Mir hunn `l` Elementer gläich wéi de Pivot fonnt.Füügt 1 zu Kont fir de Pivot selwer bäi.
    l + 1

    // `_pivot_guard` geet aus dem Ëmfang eraus a schreift de Pivot (dat ass eng stack-allocéiert Variabel) zréck an d'Scheif wou et ursprénglech war.
    // Dëse Schrëtt ass kritesch fir d'Sécherheet ze garantéieren!
}

/// Versprécht e puer Elementer ronderëm an engem Versuch Muster ze briechen déi onbalancéiert Partituren am Quecksort verursaache kéinten.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Pseudorandom Zuel Generator aus dem "Xorshift RNGs" Pabeier vum George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Huelt zoufälleg Zuelen modulo dës Zuel.
        // D'Zuel passt an `usize` well `len` net méi grouss ass wéi `isize::MAX`.
        let modulus = len.next_power_of_two();

        // E puer Pivot Kandidate wäerten an der Géigend vun dësem Index sinn.Loosst eis se randomiséieren.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Generéiert eng zoufälleg Zuel modulo `len`.
            // Wéi och ëmmer, fir deier Operatiounen ze vermeiden huele mir et fir d'éischt modulo eng Kraaft vun zwee, an da geet et ëm `len` erof bis et an d'Band `[0, len - 1]` passt.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` ass garantéiert manner wéi `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Wielt e Pivot an `v` a gitt den Index an den `true` zréck wann d'Scheedung scho scho sortéiert ass.
///
/// Elementer an `v` kënnen am Prozess nei bestallt ginn.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Mindestlängt fir d'Median-of-Median Method ze wielen.
    // Kuerzer Scheiwen benotzen déi einfach Median-of-Three Method.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Maximal Unzuel vun Swaps déi an dëser Funktioun ausgefouert kënne ginn.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Dräi Indizes bei deenen mir e Pivot wielen.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Zielt d'Gesamtzuel vun de Swaps, déi mir amgaange sinn ze maachen beim Indizéieren.
    let mut swaps = 0;

    if len >= 8 {
        // Tauscht Indizes sou datt `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Tauscht Indizes sou datt `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Fannt de Median vun `v[a - 1], v[a], v[a + 1]` a späichert den Index an `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Fannt Medianer an de Quartiere vun `a`, `b` an `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Fannt de Median tëscht `a`, `b` an `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Déi maximal Unzuel vun Swaps gouf gemaach.
        // Chancen datt d'Scheif erofgeet oder meeschtens erofgeet, sou datt de Reverséiere wahrscheinlech hëlleft méi séier ze sortéieren.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Sortéiert `v` rekursiv.
///
/// Wann de Slice e Virgänger am Original Array hat, gëtt et als `pred` spezifizéiert.
///
/// `limit` ass d'Zuel vun den erlaabt onbalancéierten Partituren ier Dir op `heapsort` wiesselt.
/// Wann null, wäert dës Funktioun direkt op Heapsort wiesselen.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Scheiwen bis zu dëser Längt gi mat der Insertion Zort sortéiert.
    const MAX_INSERTION: usize = 20;

    // Richteg wann déi lescht Partitionéierung raisonnabel ausgeglach war.
    let mut was_balanced = true;
    // Wouer wann déi lescht Partitionéierung Elementer net verschéckt huet (d'Scheedung war schonn agedeelt).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Ganz kuerz Scheiwen ginn duerch Insertion Sort sortéiert.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Wann ze vill schlecht Pivotwahle gemaach goufen, fällt einfach zréck op Heapsort fir `O(n * log(n))` am schlëmmste Fall ze garantéieren.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Wann déi lescht Partitionéierung net ausgeglach war, probéiert d'Muster an der Scheif ze briechen andeems Dir e puer Elementer ronderëm schüttelt.
        // Hoffentlech wäerte mir dës Kéier e bessere Pivot wielen.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Wielt e Pivot a probéiert ze roden ob d'Scheif scho sortéiert ass.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Wann déi lescht Partitionéierung anstänneg ausgeglach war an Elementer net verschéckt huet, a wann Pivot Selektioun virausgesot ass d'Schnitt wahrscheinlech scho sortéiert ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Probéiert verschidden ausbestellten Elementer z'identifizéieren a verréckelt se op korrekt Positiounen.
            // Wann de Slice komplett sortéiert ass, si mir fäerdeg.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Wann de gewielte Pivot gläich wéi de Virgänger ass, da ass et dat klengsten Element an der Scheif.
        // Partitur de Slice an Elementer gläich wéi an Elementer méi grouss wéi de Pivot.
        // Dëse Fall gëtt normalerweis getraff wann de Slice vill duplizéiert Elementer enthält.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Fuert weider Elementer ze sortéieren méi grouss wéi de Pivot.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Partitur de Scheiwen.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Split de Slice an `left`, `pivot` an `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Recurséiert op déi méi kuerz Säit nëmmen fir d'Gesamtzuel vu rekursive Uriff ze minimiséieren a manner Stackplaz ze konsuméieren.
        // Da fuert just mat der längerer Säit weider (dëst ass ähnlech wéi Schwanzrekursioun).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Sortéiert `v` mat Muster-Néierlag Quicksort, dat ass *O*(*n*\*log(* n*)) schlëmmste Fall.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Sortéieren huet kee sënnvoll Verhalen op Nullgréissten Typen.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Limitéiert d'Zuel vun net equilibréiert Partituren op `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Fir Scheiwen bis dës Längt ass et méiglecherweis méi séier se einfach ze sortéieren.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Wielt e Pivot
        let (pivot, _) = choose_pivot(v, is_less);

        // Wann de gewielte Pivot gläich wéi de Virgänger ass, da ass et dat klengsten Element an der Scheif.
        // Partitur de Slice an Elementer gläich wéi an Elementer méi grouss wéi de Pivot.
        // Dëse Fall gëtt normalerweis getraff wann de Slice vill duplizéiert Elementer enthält.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Wa mir eisen Index gepackt hunn, da si mir gutt.
                if mid > index {
                    return;
                }

                // Soss, fuert weider Elementer ze sortéieren méi grouss wéi de Pivot.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Split de Slice an `left`, `pivot` an `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Wa Mëtt==Index, da si mir fäerdeg, well partition() garantéiert datt all Elementer no Mëtt méi grouss wéi oder gläich wéi Mëtt sinn.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Sortéieren huet kee sënnvoll Verhalen op Nullgréissten Typen.Näischt maachen.
    } else if index == v.len() - 1 {
        // Fannt max Element a plazéiert et an der leschter Positioun vum Array.
        // Mir sinn hei fräi `unwrap()` ze benotzen well mir wëssen datt v net däerf eidel sinn.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Fannt min Element a plazéiert et op der éischter Positioun vum Array.
        // Mir sinn hei fräi `unwrap()` ze benotzen well mir wëssen datt v net däerf eidel sinn.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}