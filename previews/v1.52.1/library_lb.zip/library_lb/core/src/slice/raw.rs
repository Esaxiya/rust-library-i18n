//! Gratis Funktiounen fir `&[T]` an `&mut [T]` ze kreéieren.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Formt e Stéck vun engem Zeiger an enger Längt.
///
/// D `len` Argument ass d'Zuel vun **Elementer**, net d'Zuel vu Bytes.
///
/// # Safety
///
/// Verhalen ass ondefinéiert wann eng vun de folgende Konditioune verletzt gëtt:
///
/// * `data` muss [valid] sinn fir fir `len * mem::size_of::<T>()` vill Bytes ze liesen, an et muss richteg ausgeriicht sinn.Dëst bedeit besonnesch:
///
///     * De ganze Gedächtnisberäich vun dëser Scheif muss an engem eenzelen zougestellten Objet enthale sinn!
///       Scheiwen kënnen ni iwwer verschidde zougewisen Objete spannen.Kuckt [below](#incorrect-usage) fir e Beispill falsch wann Dir dëst net berécksiichtegt.
///     * `data` muss net null sinn an och fir Nulllängt Scheiwen ausgeriicht sinn.
///     Ee Grond dofir ass datt Enum Layout Optimiséierungen op Referenzen (abegraff Scheiwen vun all Längt) vertraue kënnen an net null sinn fir se vun aneren Daten z'ënnerscheeden.
///     Dir kënnt e Zeiger kréien deen als `data` benotzbar ass fir Nulllängt Scheiwen mat [`NonNull::dangling()`].
///
/// * `data` muss op `len` hannereneen richteg initialiséiert Wäerter vum Typ `T` weisen.
///
/// * D'Erënnerung referenzéiert vun der zréckgeschniddene Scheif däerf net während der Liewensdauer `'a` mutéiert ginn, ausser an engem `UnsafeCell`.
///
/// * D'Gesamtgréisst `len * mem::size_of::<T>()` vun der Scheif däerf net méi grouss si wéi `isize::MAX`.
///   Kuckt d'Sécherheetsdokumentatioun vun [`pointer::offset`].
///
/// # Caveat
///
/// D'Liewensdauer fir déi zréckgeschéckte Scheif gëtt aus hirem Gebrauch ofgeleet.
/// Fir versehentlech Mëssbrauch ze vermeiden, gëtt et virgeschloen d'Liewensdauer un deem egal wéi d'Liewensdauer vun der Quell sécher ass am Kontext ze verbannen, wéi zum Beispill duerch eng Helferfunktioun déi d'Liewensdauer vun engem Hostwäert fir de Slice hëlt oder duerch explizit Annotatioun.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // manifestéiert e Stéck fir een eenzegt Element
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Falsch Benotzung
///
/// Déi folgend `join_slices` Funktioun ass **net gesond** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // D'Behaaptung hei uewen assuréiert datt `fst` an `snd` ugrenzend sinn, awer si kënnen ëmmer nach an _different allocated objects_ enthale sinn, an deem Fall datt dës Scheif erstallt ass ondefinéiert Verhalen.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` an `b` si verschidden zougestellten Objeten ...
///     let a = 42;
///     let b = 27;
///     // ... wat awer trotzdem kontinuéierlech an Erënnerung geluecht ka ginn: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SAFETY: den Uruff muss de Sécherheetsvertrag fir `from_raw_parts` oprechterhalen.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Féiert déiselwecht Funktionalitéit wéi [`from_raw_parts`], ausser datt eng mutabel Scheif zréck gëtt.
///
/// # Safety
///
/// Verhalen ass ondefinéiert wann eng vun de folgende Konditioune verletzt gëtt:
///
/// * `data` muss [valid] fir béid Liesen a Schreiwe fir `len * mem::size_of::<T>()` vill Bytes sinn, an et muss richteg ausgeriicht sinn.Dëst bedeit besonnesch:
///
///     * De ganze Gedächtnisberäich vun dëser Scheif muss an engem eenzelen zougestellten Objet enthale sinn!
///       Scheiwen kënnen ni iwwer verschidde zougewisen Objete spannen.
///     * `data` muss net null sinn an och fir Nulllängt Scheiwen ausgeriicht sinn.
///     Ee Grond dofir ass datt Enum Layout Optimiséierungen op Referenzen (abegraff Scheiwen vun all Längt) vertraue kënnen an net null sinn fir se vun aneren Daten z'ënnerscheeden.
///
///     Dir kënnt e Zeiger kréien deen als `data` benotzbar ass fir Nulllängt Scheiwen mat [`NonNull::dangling()`].
///
/// * `data` muss op `len` hannereneen richteg initialiséiert Wäerter vum Typ `T` weisen.
///
/// * D'Erënnerung referenzéiert vun der zréckgeschniddene Scheif däerf net iwwer all aner Zeiger zougänglech sinn (net ofgeleet vum Retourwäert) fir d'Dauer vum Liewensdauer `'a`.
///   Béid Lies-a Schreifzugriffe si verbueden.
///
/// * D'Gesamtgréisst `len * mem::size_of::<T>()` vun der Scheif däerf net méi grouss si wéi `isize::MAX`.
///   Kuckt d'Sécherheetsdokumentatioun vun [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SAFETY: den Uruff muss de Sécherheetsvertrag fir `from_raw_parts_mut` oprechterhalen.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Konvertéiert eng Referenz op T an e Stéck vun der Längt 1 (ouni ze kopéieren).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Konvertéiert eng Referenz op T an e Stéck vun der Längt 1 (ouni ze kopéieren).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}