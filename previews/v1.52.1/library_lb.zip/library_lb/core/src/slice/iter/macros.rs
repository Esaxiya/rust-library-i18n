//! Macros benotzt vun Iteratoren vun Slice.

// Inlining is_empty a len mécht en enorme Performance Ënnerscheed
macro_rules! is_empty {
    // De Wee wéi mir d'Längt vun engem ZST-Iterator kodéieren, funktionnéiert dat souwuel fir ZST an net-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Fir e puer Grenzen Kontrollen lass ze ginn (kuckt `position`), berechnen mir d'Längt op e bëssen onerwaarten Wee.
// (Getest vu 'Codegen/Slice-Position-Bounds-Check'.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // mir ginn heiansdo an engem onséchere Block benotzt

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Dësen _cannot_ benotzt `unchecked_sub` well mir hänken of der Verpakung fir d'Längt vu laange ZST Slice Iteratoren duerzestellen.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Mir wëssen datt `start <= end`, also besser ka maachen wéi `offset_from`, déi an ënnerschriwwe Deal handele muss.
            // Duerch e passende Fändel hei kënne mir dem LLVM soen, wat hëlleft et Grenzen ze kontrolléieren.
            // SIKKERHET: Nom Typ invariant, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Duerch och dem LLVM ze soen datt d'Indikatoren vun engem genauen Multiple vun der Typgréisst ausernee sinn, kann et `len() == 0` erof op `start == end` amplaz `(end - start) < size` optimiséieren.
            //
            // SIKKERHET: Nom Typ invariant sinn d'Zeechner ausgeriicht sou datt de
            //         d'Distanz tëscht hinnen muss e Multiple vun der Pointee Gréisst sinn
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Déi gedeelt Definitioun vun den `Iter` an `IterMut` Iteratoren
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Nees dat éischt Element a réckelt den Ufank vum Iterator ëm 1 no vir.
        // Verbessert d'Performance am Verglach zu enger inline Funktioun.
        // Den Iterator däerf net eidel sinn.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Nees dat lescht Element a réckelt d'Enn vum Iterator ëm 1 no hannen.
        // Verbessert d'Performance am Verglach zu enger inline Funktioun.
        // Den Iterator däerf net eidel sinn.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Krëmmt den Iterator wann T en ZST ass, andeems en d'Enn vum Iterator ëm `n` no hannen réckelt.
        // `n` dierf net `self.len()` iwwerschreiden.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Helferfunktioun fir e Stéck aus dem Iterator ze kreéieren.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // SAFETY: den Iterator gouf aus engem Stéck mam Zeiger erstallt
                // `self.ptr` a Längt `len!(self)`.
                // Dëst garantéiert datt all Viraussetzunge fir `from_raw_parts` erfëllt sinn.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Hëllefsfunktioun fir de Start vum Iterator no vir duerch `offset` Elementer ze réckelen, den alen Ufank zréckzeginn.
            //
            // Onsécher well den Offset däerf net `self.len()` iwwerschreiden.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // SAFETY: den Uruffer garantéiert datt `offset` net méi wéi `self.len()` ass,
                    // sou datt dësen neie Zeiger bannen `self` ass an doduerch garantéiert net null ass.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Helferfunktioun fir d'Enn vum Iterator no hannen duerch `offset` Elementer ze réckelen, fir dat neit Enn zréckzebréngen.
            //
            // Onsécher well den Offset däerf net `self.len()` iwwerschreiden.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // SAFETY: den Uruffer garantéiert datt `offset` net méi wéi `self.len()` ass,
                    // wat garantéiert ass en `isize` net ze iwwerschreiden.
                    // Och de resultéierende Zeiger ass a Grenzen vum `slice`, wat déi aner Ufuerderunge fir `offset` erfëllt.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // kéint mat Scheiwen implementéiert ginn, awer dëst vermeit Grenzen Kontrollen

                // SAFETY: `assume` Uriff si sécher zënter e Stéck Startzeiger
                // muss net null sinn, a Scheiwen iwwer Net-ZSTs mussen och en net null Ennzeiger hunn.
                // Den Uruff op `next_unchecked!` ass sécher well mir kontrolléieren ob den Iterator als éischt eidel ass.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Dësen Iterator ass elo eidel.
                    if mem::size_of::<T>() == 0 {
                        // Mir mussen et esou maachen, well `ptr` ni 0 ka sinn, awer `end` kéint sinn (wéinst Verpakung).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // SIKKERHET: Enn kann net 0 sinn wann T net ZST ass well ptr net 0 ass an Enn>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // SAFETY: Mir sinn a Grenzen.`post_inc_start` mécht dat richtegt och fir ZSTs.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Mir iwwerschreiden d'Standardimplementatioun, déi `try_fold` benotzt, well dës einfach Ëmsetzung manner LLVM IR generéiert a méi séier ze kompiléieren ass.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Mir iwwerschreiden d'Standardimplementatioun, déi `try_fold` benotzt, well dës einfach Ëmsetzung manner LLVM IR generéiert a méi séier ze kompiléieren ass.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Mir iwwerschreiden d'Standardimplementatioun, déi `try_fold` benotzt, well dës einfach Ëmsetzung manner LLVM IR generéiert a méi séier ze kompiléieren ass.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Mir iwwerschreiden d'Standardimplementatioun, déi `try_fold` benotzt, well dës einfach Ëmsetzung manner LLVM IR generéiert a méi séier ze kompiléieren ass.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Mir iwwerschreiden d'Standardimplementatioun, déi `try_fold` benotzt, well dës einfach Ëmsetzung manner LLVM IR generéiert a méi séier ze kompiléieren ass.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Mir iwwerschreiden d'Standardimplementatioun, déi `try_fold` benotzt, well dës einfach Ëmsetzung manner LLVM IR generéiert a méi séier ze kompiléieren ass.
            // Och den `assume` vermeit e Grenzscheck.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // SAFETY: mir si garantéiert a Grenzen ze sinn duerch de Loop Invarant:
                        // wann `i >= n`, `self.next()` nees `None` an d'Loop brécht.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Mir iwwerschreiden d'Standardimplementatioun, déi `try_fold` benotzt, well dës einfach Ëmsetzung manner LLVM IR generéiert a méi séier ze kompiléieren ass.
            // Och den `assume` vermeit e Grenzscheck.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // SAFETY: `i` muss méi niddereg si wéi `n` well et bei `n` ufänkt
                        // a geet nëmmen erof.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // SAFETY: den Uruff muss garantéieren datt `i` a Grenzen ass
                // déi ënnerläit Scheif, sou datt den `i` keen `isize` iwwerschwemmt, an déi zréckgezunn Referenzen si garantéiert op en Element vun der Scheif ze referenzéieren an domat garantéiert ze sinn.
                //
                // Bedenkt och datt den Uruffer och garantéiert datt mir ni méi mam selwechten Index geruff ginn, an datt keng aner Methoden, déi Zougang zu dësem Ënnerschnitt kréien, geruff ginn, sou datt et gëlteg ass, datt déi zréckbezuelte Referenz am Fall vun
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // kéint mat Scheiwen implementéiert ginn, awer dëst vermeit Grenzen Kontrollen

                // SIKKERHET: `assume` Uriff si sécher, well de Startzeiger vun engem Slice muss net null sinn,
                // a Scheiwen iwwer Net-ZSTs mussen och en net-null Ennzeiger hunn.
                // Den Uruff op `next_back_unchecked!` ass sécher well mir kontrolléieren ob den Iterator als éischt eidel ass.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Dësen Iterator ass elo eidel.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // SAFETY: Mir sinn a Grenzen.`pre_dec_end` mécht dat richtegt och fir ZSTs.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}