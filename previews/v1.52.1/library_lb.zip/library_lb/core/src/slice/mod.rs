// ignore-tidy-filelength

//! Slice Management a Manipulatioun.
//!
//! Fir méi Detailer kuckt [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Pure rust memchr Ëmsetzung, aus rust-memchr geholl
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Dës Funktioun ass nëmmen ëffentlech well et keen anere Wee ass fir Heapsort ze testen.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Gitt d'Zuel vun den Elementer an der Scheif zréck.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // SAFETY: const Sound well mir d'Längtfeld als Usize auswandelen (wat et muss sinn)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // SAFETY: dëst ass sécher, well `&[T]` an `FatPtr<T>` hunn dee selwechte Layout.
            // Nëmmen `std` kann dës Garantie maachen.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Ersetzt mat `crate::ptr::metadata(self)` wann dat const-stabil ass.
            // Mat dësem Schreiwen verursaacht dëst e "Const-stable functions can only call other const-stable functions" Feeler.
            //

            // SAFETY: Zougang zum Wäert vun der `PtrRepr` Gewerkschaft ass sécher well * const T
            // a PtrComponents<T>hunn déi selwecht Erënnerungslayouten.
            // Nëmmen std kann dës Garantie maachen.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Retour `true` wann d'Scheif eng Längt vun 0 huet.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Nees dat éischt Element vun der Scheif, oder `None` wann et eidel ass.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Gitt e mutabelen Zeiger op dat éischt Element vun der Scheif, oder `None` wann et eidel ass.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Gitt d'éischt an de Rescht vun den Elementer vun der Scheif zréck, oder `None` wann et eidel ass.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Gitt d'éischt an de Rescht vun den Elementer vun der Scheif zréck, oder `None` wann et eidel ass.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Gitt d'lescht an all de Rescht vun den Elementer vun der Scheif zréck, oder `None` wann et eidel ass.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Gitt d'lescht an all de Rescht vun den Elementer vun der Scheif zréck, oder `None` wann et eidel ass.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Nees dat lescht Element vun der Scheif, oder `None` wann et eidel ass.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Nees e mutabelen Zeigefanger op dat lescht Element an der Scheif.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Nees eng Referenz zu engem Element oder engem Ënnerschnitt ofhängeg vun der Aart vum Index.
    ///
    /// - Wann Dir eng Positioun kritt, gitt eng Referenz op d'Element op där Positioun oder `None` wann se ausser Grenzen ass.
    ///
    /// - Wann Dir e Beräich kritt, bréngt de Subslice deen deem Beräich entsprécht zréck, oder `None` wann et ausser Grenzen ass.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Gitt eng mutéierbar Referenz zu engem Element oder Ënnerschnitt ofhängeg vun der Aart vum Index (kuckt [`get`]) oder `None` wann den Index ausser Grenzen ass.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Retourns eng Referenz zu engem Element oder engem Ënnerschnitt, ouni Grenzen ze maachen.
    ///
    /// Fir eng sécher Alternativ [`get`].
    ///
    /// # Safety
    ///
    /// Dës Method mat engem Out-of-Bounds Index nennen ass *[ondefinéiert Verhalen]* och wann déi resultéierend Referenz net benotzt gëtt.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // SAFETY: den Uruff muss déi meescht Sécherheetsufuerderunge fir `get_unchecked` oprechterhalen;
        // de Slice ass verfeinbar well `self` ass eng sécher Referenz.
        // Den zréckgezunnen Zeiger ass sécher, well Imples vun `SliceIndex` musse garantéieren datt et ass.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Gitt eng mutéierbar Referenz zu engem Element oder engem Ënnerschnitt zréck, ouni Grenzen ze kontrolléieren.
    ///
    /// Fir eng sécher Alternativ [`get_mut`].
    ///
    /// # Safety
    ///
    /// Dës Method mat engem Out-of-Bounds Index nennen ass *[ondefinéiert Verhalen]* och wann déi resultéierend Referenz net benotzt gëtt.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // SAFETY: den Uruff muss d'Sécherheetsufuerderunge fir `get_unchecked_mut` oprechterhalen;
        // de Slice ass verfeinbar well `self` ass eng sécher Referenz.
        // Den zréckgezunnen Zeiger ass sécher, well Imples vun `SliceIndex` musse garantéieren datt et ass.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Nees e roude Zeigefanger op de Puffer vun der Scheif.
    ///
    /// De Ruffer muss sécher sinn datt de Slice de Zeiger iwwerlieft dës Funktioun zréckgeet, soss weist et op Müll.
    ///
    /// De Ruffer muss och sécher sinn datt d'Erënnerung op déi de Zeiger (non-transitively) weist op ni geschriwwe gëtt (ausser an engem `UnsafeCell`) mat dësem Zeiger oder all Zeiger dervun ofgeleet.
    /// Wann Dir den Inhalt vun der Scheif mutéiere musst, benotzt [`as_mut_ptr`].
    ///
    /// D'Verännerung vum Container, deen vun dëser Scheif referenzéiert ass, kann dozou féieren, datt säi Puffer nei ëmgesat gëtt, wat och all Hiweiser drop mécht ongëlteg.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Nees en onséchere mutabelen Zeiger an de Puffer vun der Scheif.
    ///
    /// De Ruffer muss sécher sinn datt de Slice de Zeiger iwwerlieft dës Funktioun zréckgeet, soss weist et op Müll.
    ///
    /// D'Verännerung vum Container, deen vun dëser Scheif referenzéiert ass, kann dozou féieren, datt säi Puffer nei ëmgesat gëtt, wat och all Hiweiser drop mécht ongëlteg.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Retourneiert déi zwee réi Zeigefanger, déi de Steck spannen.
    ///
    /// Dee zréckgezunnene Beräich ass hallef op, dat heescht datt den Ennweiger *e leschten* dat lescht Element vun der Scheif weist.
    /// Op dës Manéier gëtt eng eidel Scheif vun zwee gläiche Zeechner duergestallt, an den Ënnerscheed tëscht den zwee Zeigeféier representéiert d'Gréisst vun der Scheif.
    ///
    /// Kuckt [`as_ptr`] fir Warnungen iwwer d'Benotzung vun dësen Zeigefanger.Den Ennzeiger erfuerdert extra Virsiicht, well et weist net op e gültegt Element an der Scheif.
    ///
    /// Dës Funktioun ass nëtzlech fir mat auslänneschen Interfaces ze interagéieren, déi zwee Zeigefanger benotze fir op eng Rei Elementer am Erënnerung ze referenzéieren, wéi dat am C++ üblech ass.
    ///
    ///
    /// Et kann och nëtzlech sinn ze kontrolléieren ob e Zeiger zu engem Element op en Element vun dëser Scheif bezitt:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // SAFETY: Den `add` hei ass sécher, well:
        //
        //   - Béid Zeigefanger sinn Deel vum selwechten Objet, well se direkt laanscht den Objet zielen zielt och.
        //
        //   - D'Gréisst vun der Scheif ass ni méi grouss wéi isize::MAX Bytes, wéi hei festgehalen:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Et ass kee Wéckel involvéiert, well Scheiwen net laanscht d'Enn vum Adressraum wéckelen.
        //
        // Kuckt d'Dokumentatioun vum pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Retournéiert déi zwee onsécher mutéierbar Zeigefanger, déi de Stéck spannen.
    ///
    /// Dee zréckgezunnene Beräich ass hallef op, dat heescht datt den Ennweiger *e leschten* dat lescht Element vun der Scheif weist.
    /// Op dës Manéier gëtt eng eidel Scheif vun zwee gläiche Zeechner duergestallt, an den Ënnerscheed tëscht den zwee Zeigeféier representéiert d'Gréisst vun der Scheif.
    ///
    /// Kuckt [`as_mut_ptr`] fir Warnungen iwwer d'Benotzung vun dësen Zeigefanger.
    /// Den Ennzeiger erfuerdert extra Virsiicht, well et weist net op e gültegt Element an der Scheif.
    ///
    /// Dës Funktioun ass nëtzlech fir mat auslänneschen Interfaces ze interagéieren, déi zwee Zeigefanger benotze fir op eng Rei Elementer am Erënnerung ze referenzéieren, wéi dat am C++ üblech ass.
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // SAFETY: Kuckt as_ptr_range() uewendriwwer firwat `add` hei sécher ass.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Tauscht zwee Elementer an der Scheif.
    ///
    /// # Arguments
    ///
    /// * a, Den Index vum éischten Element
    /// * b, Den Index vum zweeten Element
    ///
    /// # Panics
    ///
    /// Panics wann `a` oder `b` ausser Grenzen sinn.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Kann net zwee mutéierbar Prête vun engem vector huelen, also benotzt roude Zeigefanger.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // SAFETY: `pa` an `pb` sinn aus séchere mutable Referenzen erstallt a referéiert
        // zu Elementer an der Scheif an dofir si garantéiert gëlteg an ausgeriicht.
        // Bedenkt datt Zougang zu den Elementer hannert `a` an `b` gepréift gëtt a wäert panic wann et ausser Grenzen ass.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Ëmgedréit d'Bestellung vun den Elementer an der Scheif, op der Plaz.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Fir ganz kleng Zorten, liest all Eenzelnen am normale Wee schlecht.
        // Mir kënne besser maachen, mat effizienten net ausgeriichtte load/store, andeems mir e méi grousse Stéck lueden an e Register ëmdréinen.
        //

        // Idealerweis géif LLVM dëst fir eis maachen, well et besser weess wéi mir, ob net ausgeriicht Liesungen effizient sinn (well dat ännert zum Beispill tëscht verschiddenen ARM Versiounen) a wat déi bescht Stéck Gréisst wier.
        // Leider, ab dem LLVM 4.0 (2017-05) rullt se nëmmen d'Loop aus, also musse mir dat selwer maachen.
        // (Hypothese: ëmgedréint ass lästeg well d'Säiten anescht ausgeriicht kënne sinn-wäert sinn, wann d'Längt onkomplizéiert ass-also ass et kee Wee fir Viraus-an Ofschloss auszeginn fir voll ausgeriicht SIMD an der Mëtt ze benotzen.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Benotzt den llvm.bswap intrinsesch fir U8s an engem Usize ëmzegoen
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // SAFETY: Et gi verschidde Saachen hei ze kontrolléieren:
                //
                // - Bedenkt datt `chunk` entweder 4 oder 8 ass wéinst dem CFG Kontroll hei uewen.Also `chunk - 1` ass positiv.
                // - Indexéiere mam Index `i` ass gutt wéi de Loopcheck garantéiert
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Indexéiere mam Index `ln - i - chunk = ln - (i + chunk)` ass gutt:
                //   - `i + chunk > 0` ass trivial richteg.
                //   - De Loop Check garantéiert:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, also subtraktioun ënnerstrouft net.
                // - D `read_unaligned` an `write_unaligned` Uriff si gutt:
                //   - `pa` weist op den Index `i` wou `i < ln / 2 - (chunk - 1)` (kuckt hei uewen) an `pb` weist op den Index `ln - i - chunk`, sou datt béid op d'mannst `chunk` vill Bytes vum Enn vum `self` ewech sinn.
                //
                //   - All initialiséiert Erënnerung ass valabel `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Benotzt Rotate-by-16 fir U16s an engem u32 ëmzegoen
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // SAFETY: En net ausgeriichtte u32 kann aus `i` gelies ginn wann `i + 1 < ln`
                // (a selbstverständlech `i < ln`), well all Element ass 2 Bytes a mir liesen 4.
                //
                // `i + chunk - 1 < ln / 2` # während Zoustand
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Well et manner wéi d'Längt gedeelt gëtt duerch 2, da muss et a Grenzen sinn.
                //
                // Dëst bedeit och datt d'Konditioun `0 < i + chunk <= ln` ëmmer respektéiert gëtt, sou datt den `pb` Zeiger sécher ka benotzt ginn.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // SAFETY: `i` ass manner wéi d'Halschent vun der Längt vun der Scheif also
            // Zougang zu `i` an `ln - i - 1` ass sécher (`i` fänkt um 0 un a geet net méi wäit wéi `ln / 2 - 1`).
            // Déi doraus resultéierend Zeigefanger `pa` an `pb` sinn dofir gëlteg an ausgeriicht a kënne vu virgelies a geschriwwe ginn.
            //
            //
            unsafe {
                // Onsécherert Tausch fir d'Grenzen ze vermeiden a sécher Tausch.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Nees en Iterator iwwer de Slice.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Nees en Iterator deen all Wäert ännert.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Nees en Iterator iwwer all angrenzend windows vun der Längt `size`.
    /// Den windows iwwerlappt.
    /// Wann de Slice méi kuerz wéi `size` ass, gëtt den Iterator keng Wäerter zréck.
    ///
    /// # Panics
    ///
    /// Panics wann `size` 0 ass.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Wann d'Scheedung méi kuerz ass wéi `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Nees en Iterator iwwer `chunk_size` Elementer vun der Scheif gläichzäiteg, fänkt um Ufank vun der Scheif un.
    ///
    /// D'Stécker si Scheiwen an iwwerlappt net.Wann `chunk_size` d'Längt vun der Scheif net deelt, da wäert de leschte Stéck keng Längt `chunk_size` hunn.
    ///
    /// Kuckt [`chunks_exact`] fir eng Variante vun dësem Iterator, déi Stécker vun ëmmer genau `chunk_size` Elementer zréckbréngt, an [`rchunks`] fir dee selwechten Iterator awer um Enn vun der Scheif ufänken.
    ///
    ///
    /// # Panics
    ///
    /// Panics wann `chunk_size` 0 ass.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Nees en Iterator iwwer `chunk_size` Elementer vun der Scheif gläichzäiteg, fänkt um Ufank vun der Scheif un.
    ///
    /// D'Stécker si mutéierbar Scheiwen, an iwwerlappt net.Wann `chunk_size` d'Längt vun der Scheif net deelt, da wäert de leschte Stéck keng Längt `chunk_size` hunn.
    ///
    /// Kuckt [`chunks_exact_mut`] fir eng Variante vun dësem Iterator, déi Stécker vun ëmmer genau `chunk_size` Elementer zréckbréngt, an [`rchunks_mut`] fir dee selwechten Iterator awer um Enn vun der Scheif ufänken.
    ///
    ///
    /// # Panics
    ///
    /// Panics wann `chunk_size` 0 ass.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Nees en Iterator iwwer `chunk_size` Elementer vun der Scheif gläichzäiteg, fänkt um Ufank vun der Scheif un.
    ///
    /// D'Stécker si Scheiwen an iwwerlappt net.
    /// Wann `chunk_size` d'Längt vun der Scheif net deelt, da ginn déi lescht bis `chunk_size-1` Elementer ewech gelooss a kënnen aus der `remainder` Funktioun vum Iterator erausgeholl ginn.
    ///
    ///
    /// Wéinst all Stéck mat exakt `chunk_size` Elementer, kann de Compiler de resultéierende Code dacks besser optimiséieren wéi am Fall vun [`chunks`].
    ///
    /// Kuckt [`chunks`] fir eng Variant vun dësem Iterator deen och de Rescht als e méi klenge Stéck zréckbréngt, an [`rchunks_exact`] fir dee selwechten Iterator awer um Enn vun der Tranche ufänkt.
    ///
    /// # Panics
    ///
    /// Panics wann `chunk_size` 0 ass.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Nees en Iterator iwwer `chunk_size` Elementer vun der Scheif gläichzäiteg, fänkt um Ufank vun der Scheif un.
    ///
    /// D'Stécker si mutéierbar Scheiwen, an iwwerlappt net.
    /// Wann `chunk_size` d'Längt vun der Scheif net deelt, da ginn déi lescht bis `chunk_size-1` Elementer ewech gelooss a kënnen aus der `into_remainder` Funktioun vum Iterator erausgeholl ginn.
    ///
    ///
    /// Wéinst all Stéck mat exakt `chunk_size` Elementer, kann de Compiler de resultéierende Code dacks besser optimiséieren wéi am Fall vun [`chunks_mut`].
    ///
    /// Kuckt [`chunks_mut`] fir eng Variant vun dësem Iterator deen och de Rescht als e méi klenge Stéck zréckbréngt, an [`rchunks_exact_mut`] fir dee selwechten Iterator awer um Enn vun der Tranche ufänkt.
    ///
    /// # Panics
    ///
    /// Panics wann `chunk_size` 0 ass.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Deelt d'Scheiwen an e Stéck vun 'N`-Element Arrays, unzehuelen datt et kee Rescht ass.
    ///
    ///
    /// # Safety
    ///
    /// Dëst däerf nëmme genannt ginn wann
    /// - D'Scheedung deelt sech exakt an `N`-Element Stécker (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // SAFETY: 1-Element Stécker hunn ni de Rescht
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // SAFETY: D'Schnëttlängt (6) ass e Multiple vun 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Dës wieren net gesond:
    /// // Stécker loossen: &[[_;5]]= slice.as_chunks_unchecked()//D'Schnitzlängt ass net e Multiple vu 5 lass Stécker:&[[_;0]]= slice.as_chunks_unchecked()//Nulllängt Stécker sinn ni erlaabt
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SAFETY: Eis Viraussetzung ass genau dat wat Dir braucht fir dëst ze nennen
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SAFETY: Mir geheien e Stéck `new_len * N` Elementer an
        // e Stéck `new_len` vill `N` Elementer Stécker.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Deelt de Slice an e Stéck vun 'N`-Element Arrays, fänkt um Ufank vum Slice un, an e Rescht Slice mat enger Längt streng manner wéi `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics wann `N` 0. ass. Dëse Scheck gëtt héchstwahrscheinlech geännert an e Kompiléierungszäitfeeler ier dës Method stabiliséiert gëtt.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // SAFETY: Mir hu scho fir Null panikéiert, a vum Bau gesuergt
        // datt d'Längt vum Ënnerschnitt e Multiple vun N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Deelt de Slice an e Stéck vun 'N`-Element Arrays, fänkt um Enn vum Slice un, an e Rescht Slice mat enger Längt streng manner wéi `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics wann `N` 0. ass. Dëse Scheck gëtt héchstwahrscheinlech geännert an e Kompiléierungszäitfeeler ier dës Method stabiliséiert gëtt.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // SAFETY: Mir hu scho fir Null panikéiert, a vum Bau gesuergt
        // datt d'Längt vum Ënnerschnitt e Multiple vun N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Nees en Iterator iwwer `N` Elementer vun der Scheif gläichzäiteg, fänkt um Ufank vun der Scheif un.
    ///
    /// D'Stécker si Array Referenzen an iwwerlappt net.
    /// Wann `N` d'Längt vun der Scheif net deelt, da ginn déi lescht bis `N-1` Elementer ewech gelooss a kënnen aus der `remainder` Funktioun vum Iterator erausgeholl ginn.
    ///
    ///
    /// Dës Method ass de const generesche Äquivalent vun [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics wann `N` 0. ass. Dëse Scheck gëtt héchstwahrscheinlech geännert an e Kompiléierungszäitfeeler ier dës Method stabiliséiert gëtt.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Deelt d'Scheiwen an e Stéck vun 'N`-Element Arrays, unzehuelen datt et kee Rescht ass.
    ///
    ///
    /// # Safety
    ///
    /// Dëst däerf nëmme genannt ginn wann
    /// - D'Scheedung deelt sech exakt an `N`-Element Stécker (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // SAFETY: 1-Element Stécker hunn ni de Rescht
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // SAFETY: D'Schnëttlängt (6) ass e Multiple vun 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Dës wieren net gesond:
    /// // Stécker loossen: &[[_;5]]= slice.as_chunks_unchecked_mut()//D'Schnitzlängt ass net e Multiple vu 5 lass Stécker:&[[_;0]]= slice.as_chunks_unchecked_mut()//Nulllängt Stécker sinn ni erlaabt
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SAFETY: Eis Viraussetzung ass genau dat wat Dir braucht fir dëst ze nennen
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SAFETY: Mir geheien e Stéck `new_len * N` Elementer an
        // e Stéck `new_len` vill `N` Elementer Stécker.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Deelt de Slice an e Stéck vun 'N`-Element Arrays, fänkt um Ufank vum Slice un, an e Rescht Slice mat enger Längt streng manner wéi `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics wann `N` 0. ass. Dëse Scheck gëtt héchstwahrscheinlech geännert an e Kompiléierungszäitfeeler ier dës Method stabiliséiert gëtt.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // SAFETY: Mir hu scho fir Null panikéiert, a vum Bau gesuergt
        // datt d'Längt vum Ënnerschnitt e Multiple vun N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Deelt de Slice an e Stéck vun 'N`-Element Arrays, fänkt um Enn vum Slice un, an e Rescht Slice mat enger Längt streng manner wéi `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics wann `N` 0. ass. Dëse Scheck gëtt héchstwahrscheinlech geännert an e Kompiléierungszäitfeeler ier dës Method stabiliséiert gëtt.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // SAFETY: Mir hu scho fir Null panikéiert, a vum Bau gesuergt
        // datt d'Längt vum Ënnerschnitt e Multiple vun N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Nees en Iterator iwwer `N` Elementer vun der Scheif gläichzäiteg, fänkt um Ufank vun der Scheif un.
    ///
    /// D'Stécker si mutéierbar Array Referenzen an iwwerlappt net.
    /// Wann `N` d'Längt vun der Scheif net deelt, da ginn déi lescht bis `N-1` Elementer ewech gelooss a kënnen aus der `into_remainder` Funktioun vum Iterator erausgeholl ginn.
    ///
    ///
    /// Dës Method ass de const generesche Äquivalent vun [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics wann `N` 0. ass. Dëse Scheck gëtt héchstwahrscheinlech geännert an e Kompiléierungszäitfeeler ier dës Method stabiliséiert gëtt.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Nees en Iterator iwwerlappend windows vun `N` Elementer vun engem Slice, fänkt um Ufank vum Slice un.
    ///
    ///
    /// Dëst ass de const generesche Äquivalent vun [`windows`].
    ///
    /// Wann `N` méi grouss wéi d'Gréisst vum Slice ass, gëtt et keen windows zréck.
    ///
    /// # Panics
    ///
    /// Panics wann `N` 0 ass.
    /// Dëse Scheck gëtt héchstwahrscheinlech op e Kompiléierungszäitfeeler geännert ier dës Method stabiliséiert gëtt.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Nees en Iterator iwwer `chunk_size` Elementer vun der Scheif gläichzäiteg, fänkt um Enn vun der Scheif un.
    ///
    /// D'Stécker si Scheiwen an iwwerlappt net.Wann `chunk_size` d'Längt vun der Scheif net deelt, da wäert de leschte Stéck keng Längt `chunk_size` hunn.
    ///
    /// Kuckt [`rchunks_exact`] fir eng Variante vun dësem Iterator, déi Stécker vun ëmmer genau `chunk_size` Elementer zréckbréngt, an [`chunks`] fir dee selwechten Iterator awer am Ufank vun der Scheif unzefänken.
    ///
    ///
    /// # Panics
    ///
    /// Panics wann `chunk_size` 0 ass.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Nees en Iterator iwwer `chunk_size` Elementer vun der Scheif gläichzäiteg, fänkt um Enn vun der Scheif un.
    ///
    /// D'Stécker si mutéierbar Scheiwen, an iwwerlappt net.Wann `chunk_size` d'Längt vun der Scheif net deelt, da wäert de leschte Stéck keng Längt `chunk_size` hunn.
    ///
    /// Kuckt [`rchunks_exact_mut`] fir eng Variante vun dësem Iterator, déi Stécker vun ëmmer genau `chunk_size` Elementer zréckbréngt, an [`chunks_mut`] fir dee selwechten Iterator awer am Ufank vun der Scheif unzefänken.
    ///
    ///
    /// # Panics
    ///
    /// Panics wann `chunk_size` 0 ass.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Nees en Iterator iwwer `chunk_size` Elementer vun der Scheif gläichzäiteg, fänkt um Enn vun der Scheif un.
    ///
    /// D'Stécker si Scheiwen an iwwerlappt net.
    /// Wann `chunk_size` d'Längt vun der Scheif net deelt, da ginn déi lescht bis `chunk_size-1` Elementer ewech gelooss a kënnen aus der `remainder` Funktioun vum Iterator erausgeholl ginn.
    ///
    /// Wéinst all Stéck mat exakt `chunk_size` Elementer, kann de Compiler de resultéierende Code dacks besser optimiséieren wéi am Fall vun [`chunks`].
    ///
    /// Kuckt [`rchunks`] fir eng Variant vun dësem Iterator deen och de Rescht als e méi klenge Stéck zréckbréngt, an [`chunks_exact`] fir dee selwechten Iterator awer am Ufank vum Slice.
    ///
    ///
    /// # Panics
    ///
    /// Panics wann `chunk_size` 0 ass.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Nees en Iterator iwwer `chunk_size` Elementer vun der Scheif gläichzäiteg, fänkt um Enn vun der Scheif un.
    ///
    /// D'Stécker si mutéierbar Scheiwen, an iwwerlappt net.
    /// Wann `chunk_size` d'Längt vun der Scheif net deelt, da ginn déi lescht bis `chunk_size-1` Elementer ewech gelooss a kënnen aus der `into_remainder` Funktioun vum Iterator erausgeholl ginn.
    ///
    /// Wéinst all Stéck mat exakt `chunk_size` Elementer, kann de Compiler de resultéierende Code dacks besser optimiséieren wéi am Fall vun [`chunks_mut`].
    ///
    /// Kuckt [`rchunks_mut`] fir eng Variant vun dësem Iterator deen och de Rescht als e méi klenge Stéck zréckbréngt, an [`chunks_exact_mut`] fir dee selwechten Iterator awer am Ufank vum Slice.
    ///
    ///
    /// # Panics
    ///
    /// Panics wann `chunk_size` 0 ass.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Nees en Iterator iwwer de Slice a produzéiert net iwwerlappend Lafe vun Elementer mat dem Predikat fir se ze trennen.
    ///
    /// De Predikat gëtt op zwee Elementer genannt, déi sech selwer follegen, et heescht datt de Predikat op `slice[0]` an `slice[1]` genannt gëtt, dann op `slice[1]` an `slice[2]` a sou weider.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Dës Method kann benotzt ginn fir déi sortéiert Ënnerslicen ze extrahieren:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Nees en Iterator iwwer de Slice a produzéiert net iwwerlappend mutabel Lafe vun Elementer mat dem Predikat fir se ze trennen.
    ///
    /// De Predikat gëtt op zwee Elementer genannt, déi sech selwer follegen, et heescht datt de Predikat op `slice[0]` an `slice[1]` genannt gëtt, dann op `slice[1]` an `slice[2]` a sou weider.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Dës Method kann benotzt ginn fir déi sortéiert Ënnerslicen ze extrahieren:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Deelt eng Scheif an zwee bei engem Index.
    ///
    /// Déi éischt enthält all Indizes vun `[0, mid)` (ausser den Index `mid` selwer) an déi zweet enthält all Indizes vun `[mid, len)` (ausser den Index `len` selwer).
    ///
    ///
    /// # Panics
    ///
    /// Panics wann `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // SAFETY: `[ptr; mid]` an `[mid; len]` si bannent `self`, déi
        // erfëllt d'Ufuerderunge vum `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Deelt eng mutabel Scheif an zwee an engem Index.
    ///
    /// Déi éischt enthält all Indizes vun `[0, mid)` (ausser den Index `mid` selwer) an déi zweet enthält all Indizes vun `[mid, len)` (ausser den Index `len` selwer).
    ///
    ///
    /// # Panics
    ///
    /// Panics wann `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // SAFETY: `[ptr; mid]` an `[mid; len]` si bannent `self`, déi
        // erfëllt d'Ufuerderunge vum `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Deelt eng Scheif an zwee am Index, ouni Grenzen ze maachen.
    ///
    /// Déi éischt enthält all Indizes vun `[0, mid)` (ausser den Index `mid` selwer) an déi zweet enthält all Indizes vun `[mid, len)` (ausser den Index `len` selwer).
    ///
    ///
    /// Fir eng sécher Alternativ [`split_at`].
    ///
    /// # Safety
    ///
    /// Dës Method mat engem Out-of-Bounds Index nennen ass *[ondefinéiert Verhalen]* och wann déi resultéierend Referenz net benotzt gëtt.De Ruffer muss dofir suergen datt `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // SAFETY: De Ruffer muss dee `0 <= mid <= self.len()` kontrolléieren
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Deelt eng mutabel Scheif an zwee am Index, ouni Grenzen ze maachen.
    ///
    /// Déi éischt enthält all Indizes vun `[0, mid)` (ausser den Index `mid` selwer) an déi zweet enthält all Indizes vun `[mid, len)` (ausser den Index `len` selwer).
    ///
    ///
    /// Fir eng sécher Alternativ [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Dës Method mat engem Out-of-Bounds Index nennen ass *[ondefinéiert Verhalen]* och wann déi resultéierend Referenz net benotzt gëtt.De Ruffer muss dofir suergen datt `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // SAFETY: De Ruffer muss dee `0 <= mid <= self.len()` kontrolléieren.
        //
        // `[ptr; mid]` an `[mid; len]` sinn net iwwerlappend, sou datt eng mutabel Referenz zréckgeet.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Nees en Iterator iwwer Ënnerslices getrennt vun Elementer déi mat `pred` passen.
    /// Dat passend Element ass net an de Souslices enthale.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Wann dat éischt Element ugepasst ass, ass eng eidel Scheif deen éischten Element vum Iterator.
    /// Ähnlech wéi wann dat lescht Element an der Scheif passend ass, ass eng eidel Scheif dat lescht Element vum Iterator:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Wann zwee passend Elementer direkt ugrenzend sinn, ass eng eidel Scheif tëscht hinnen:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Nees en Iterator iwwer mutéierbar Ënnerslicen getrennt vun Elementer déi mat `pred` passen.
    /// Dat passend Element ass net an de Souslices enthale.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Nees en Iterator iwwer Ënnerslices getrennt vun Elementer déi mat `pred` passen.
    /// Dat passend Element ass um Enn vum fréiere Subslice als Terminator enthalen.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Wann dat lescht Element vun der Scheif passend ass, gëtt dat Element als den Terminator vun der viregter Scheif ugesinn.
    ///
    /// Dëse Stéck ass dat lescht Element vum Itator zréck.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Nees en Iterator iwwer mutéierbar Ënnerslicen getrennt vun Elementer déi mat `pred` passen.
    /// Dat passend Element ass am fréiere Subslice als Terminator enthalen.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Nees en Iterator iwwer Ënnerslices getrennt vun Elementer déi mat `pred` passen, fänkt um Enn vun der Scheif un a schafft no hannen.
    /// Dat passend Element ass net an de Souslices enthale.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Wéi mat `split()`, wann dat éischt oder lescht Element passend ass, ass eng eidel Scheif deen éischten (oder leschten) Element deen vum Iterator zréckginn.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Nees en Iterator iwwer mutéierbar Ënnerslices getrennt vun Elementer déi mat `pred` passen, um Enn vun der Scheif unzefänken an no hannen ze schaffen.
    /// Dat passend Element ass net an de Souslices enthale.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Nees en Iterator iwwer Ënnerslices getrennt vun Elementer déi mat `pred` passen, limitéiert op héchstens `n` Elementer zréckzekommen.
    /// Dat passend Element ass net an de Souslices enthale.
    ///
    /// Dat lescht Element zréck, wann iwwerhaapt, enthält de Rescht vun der Scheif.
    ///
    /// # Examples
    ///
    /// Dréckt d'Scheedung eemol opgedeelt mat Zuelen deelbar mat 3 (dh `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Nees en Iterator iwwer Ënnerslices getrennt vun Elementer déi mat `pred` passen, limitéiert op héchstens `n` Elementer zréckzekommen.
    /// Dat passend Element ass net an de Souslices enthale.
    ///
    /// Dat lescht Element zréck, wann iwwerhaapt, enthält de Rescht vun der Scheif.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Nees en Iterator iwwer Ënnerslices getrennt vun Elementer déi mat `pred` passen, limitéiert op héchstens `n` Elementer zréckzekommen.
    /// Dëst fänkt um Enn vun der Scheif un a schafft no hannen.
    /// Dat passend Element ass net an de Souslices enthale.
    ///
    /// Dat lescht Element zréck, wann iwwerhaapt, enthält de Rescht vun der Scheif.
    ///
    /// # Examples
    ///
    /// Dréckt de Scheif eng Kéier gespléckt, ugefaang um Enn, mat Nummeren déi deelenbar sinn mat 3 (dh `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Nees en Iterator iwwer Ënnerslices getrennt vun Elementer déi mat `pred` passen, limitéiert op héchstens `n` Elementer zréckzekommen.
    /// Dëst fänkt um Enn vun der Scheif un a schafft no hannen.
    /// Dat passend Element ass net an de Souslices enthale.
    ///
    /// Dat lescht Element zréck, wann iwwerhaapt, enthält de Rescht vun der Scheif.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Retour `true` wann de Slice en Element mat dem gegebene Wäert enthält.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Wann Dir keen `&T` hutt, awer just en `&U` sou datt `T: Borrow<U>` (z. B.
    /// `String: Prêt<str>`), Dir kënnt `iter().any` benotzen:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // Stéck `String`
    /// assert!(v.iter().any(|e| e == "hello")); // sichen mat `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Retour `true` wann `needle` e Präfix vun der Scheif ass.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Gitt ëmmer `true` zréck wann `needle` eng eidel Scheif ass:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Retour `true` wann `needle` e Suffix vum Slice ass.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Gitt ëmmer `true` zréck wann `needle` eng eidel Scheif ass:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Nees e Subslice mam Präfix ewechgeholl.
    ///
    /// Wann de Slice mat `prefix` ufänkt, gëtt de Subslice nom Präfix zréck, gewéckelt an `Some`.
    /// Wann `prefix` eidel ass, gitt einfach d'Original Scheif zréck.
    ///
    /// Wann de Slice net mat `prefix` ufänkt, gëtt `None` zréck.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Dës Funktioun brauch nei ze schreiwen wann a wann SlicePattern méi sophistikéiert gëtt.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Nees e Subslice mat dem Suffix ewechgeholl.
    ///
    /// Wann de Slice mat `suffix` endet, gëtt de Subslice virum Suffix zréck, gewéckelt an `Some`.
    /// Wann `suffix` eidel ass, gitt einfach d'Original Scheif zréck.
    ///
    /// Wann de Slice net mat `suffix` endet, gëtt `None` zréck.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Dës Funktioun brauch nei ze schreiwen wann a wann SlicePattern méi sophistikéiert gëtt.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Binär sicht dës sortéiert Scheif no engem bestëmmten Element.
    ///
    /// Wann de Wäert fonnt gëtt da gëtt [`Result::Ok`] zréck, enthält den Index vum passenden Element.
    /// Wann et verschidde Matcher sinn, da kéint ee vun de Matcher zréck ginn.
    /// Wann de Wäert net fonnt gëtt, gëtt [`Result::Err`] zréckgezunn, enthält den Index wou e passende Element kéint agefouert ginn wärend der sortéierter Uerdnung behalen.
    ///
    ///
    /// Kuckt och [`binary_search_by`], [`binary_search_by_key`], an [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Kuckt eng Serie vu véier Elementer op.
    /// Déi éischt gëtt fonnt, mat enger eenzegaarteg bestëmmter Positioun;déi zweet an drëtt sinn net fonnt;déi véiert kéint mat all Positioun am `[1, 4]` passen.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Wann Dir en Element an e sortéierten vector wëllt aginn, wärend Dir d'Sortefolleg behalen:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Binär sicht dës sortéiert Scheif mat enger Komparatorfunktioun.
    ///
    /// D'Komparatorfunktioun soll eng Bestellung ëmsetzen, déi konsequent mat der Sortéierungsuerdnung vun der Basislëscht ass, an e Bestellcode zréckginn, deen ugëtt, ob säin Argument `Less`, `Equal` oder `Greater` dat gewënschten Zil ass.
    ///
    ///
    /// Wann de Wäert fonnt gëtt da gëtt [`Result::Ok`] zréck, enthält den Index vum passenden Element.Wann et verschidde Matcher sinn, da kéint ee vun de Matcher zréck ginn.
    /// Wann de Wäert net fonnt gëtt, gëtt [`Result::Err`] zréckgezunn, enthält den Index wou e passende Element kéint agefouert ginn wärend der sortéierter Uerdnung behalen.
    ///
    /// Kuckt och [`binary_search`], [`binary_search_by_key`], an [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Kuckt eng Serie vu véier Elementer op.Déi éischt gëtt fonnt, mat enger eenzegaarteg bestëmmter Positioun;déi zweet an drëtt sinn net fonnt;déi véiert kéint mat all Positioun am `[1, 4]` passen.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // SIKKERHET: den Uruff ass sécher gemaach vun de folgenden Invararianer:
            // - `mid >= 0`
            // - `mid < size`: `mid` ass limitéiert op `[left; right)` gebonnen.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // De Grond firwat mir if/else Kontrollstroum anstatt Match benotzen ass well de Match Verglach Operatiounen nei bestellt, wat perfekt sensibel ass.
            //
            // Dëst ass x86 ASM fir u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Binär sicht dës sortéiert Scheif mat enger Schlëssel Extraktioun Funktioun.
    ///
    /// Assuméiert datt d'Scheedung vum Schlëssel sortéiert ass, zum Beispill mat [`sort_by_key`] mat der selwechter Schlëssel Extraktioun Funktioun.
    ///
    /// Wann de Wäert fonnt gëtt da gëtt [`Result::Ok`] zréck, enthält den Index vum passenden Element.
    /// Wann et verschidde Matcher sinn, da kéint ee vun de Matcher zréck ginn.
    /// Wann de Wäert net fonnt gëtt, gëtt [`Result::Err`] zréckgezunn, enthält den Index wou e passende Element kéint agefouert ginn wärend der sortéierter Uerdnung behalen.
    ///
    ///
    /// Kuckt och [`binary_search`], [`binary_search_by`], an [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Kuckt eng Serie vu véier Elementer an engem Stéck Puer zortéiert no hiren zweeten Elementer.
    /// Déi éischt gëtt fonnt, mat enger eenzegaarteg bestëmmter Positioun;déi zweet an drëtt sinn net fonnt;déi véiert kéint mat all Positioun am `[1, 4]` passen.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links ass erlaabt well `slice::sort_by_key` an crate `alloc` ass, a sou existéiert et nach net wann Dir `core` baut.
    //
    // Linken op Downstream crate: #74481.Well Primitiven nëmmen an libstd (#73423) dokumentéiert sinn, féiert dat ni zu futtisse Linken an der Praxis.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Sorts de Slice, awer däerf d'Uerdnung vu gläiche Elementer net erhalen.
    ///
    /// Dës Zort ass onbestänneg (dh ka gläich Elementer nei bestellen), op der Plaz (dh verdeelt net), an *O*(*n*\*log(* n*)) am schlëmmste Fall.
    ///
    /// # Aktuell Ëmsetzung
    ///
    /// Den aktuellen Algorithmus baséiert op [pattern-defeating quicksort][pdqsort] vum Orson Peters, deen de schnelle Duerchschnëttsfall vu randomiséierte Quicksort mat dem schnellste Schlëmmste Fall vun Heapsort kombinéiert, wärend et Linearzäit op Scheiwen mat gewësse Mustere erreecht.
    /// Et benotzt e puer Randomiséierung fir degeneréiert Fäll ze vermeiden, awer mat engem fixen seed fir ëmmer deterministescht Verhalen ze bidden.
    ///
    /// Et ass typesch méi séier wéi stabil Zortéieren, ausser an e puer speziellen Fäll, zB wann d'Scheif aus e puer zesummegesate sortéierte Sequenzen besteet.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Sorts de Slice mat enger Komparatorfunktioun, awer kann d'Uerdnung vu gläichen Elementer net erhalen.
    ///
    /// Dës Zort ass onbestänneg (dh ka gläich Elementer nei bestellen), op der Plaz (dh verdeelt net), an *O*(*n*\*log(* n*)) am schlëmmste Fall.
    ///
    /// D'Komparatorfunktioun muss eng total Bestellung fir d'Elementer an der Scheif definéieren.Wann d'Bestellung net total ass, ass d'Bestellung vun den Elementer net spezifizéiert.Eng Bestellung ass eng total Bestellung wann et ass (fir all `a`, `b` an `c`):
    ///
    /// * total an antisymmetresch: genau ee vun `a < b`, `a == b` oder `a > b` ass wouer, an
    /// * transitiv, `a < b` an `b < c` implizéiert `a < c`.Dat selwecht muss fir béid `==` an `>` halen.
    ///
    /// Zum Beispill, wärend [`f64`] [`Ord`] net implementéiert well `NaN != NaN`, kënne mir `partial_cmp` als Sortfunktioun benotzen wa mir wëssen datt de Slice keen `NaN` enthält.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Aktuell Ëmsetzung
    ///
    /// Den aktuellen Algorithmus baséiert op [pattern-defeating quicksort][pdqsort] vum Orson Peters, deen de schnelle Duerchschnëttsfall vu randomiséierte Quicksort mat dem schnellste Schlëmmste Fall vun Heapsort kombinéiert, wärend et Linearzäit op Scheiwen mat gewësse Mustere erreecht.
    /// Et benotzt e puer Randomiséierung fir degeneréiert Fäll ze vermeiden, awer mat engem fixen seed fir ëmmer deterministescht Verhalen ze bidden.
    ///
    /// Et ass typesch méi séier wéi stabil Zortéieren, ausser an e puer speziellen Fäll, zB wann d'Scheif aus e puer zesummegesate sortéierte Sequenzen besteet.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // ëmgedréint Zortéieren
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Sorts de Slice mat enger Schlëssel Extraktiounsfunktioun, awer kann d'Uerdnung vu gläiche Elementer net erhalen.
    ///
    /// Dës Zort ass onbestänneg (dh ka gläich Elementer nei bestellen), op der Plaz (dh verdeelt net), an *O*(m\* * n *\* log(*n*)) am schlëmmste Fall, wou d'Schlësselfunktioun *O* ass (*m*).
    ///
    /// # Aktuell Ëmsetzung
    ///
    /// Den aktuellen Algorithmus baséiert op [pattern-defeating quicksort][pdqsort] vum Orson Peters, deen de schnelle Duerchschnëttsfall vu randomiséierte Quicksort mat dem schnellste Schlëmmste Fall vun Heapsort kombinéiert, wärend et Linearzäit op Scheiwen mat gewësse Mustere erreecht.
    /// Et benotzt e puer Randomiséierung fir degeneréiert Fäll ze vermeiden, awer mat engem fixen seed fir ëmmer deterministescht Verhalen ze bidden.
    ///
    /// Wéinst senger Schlësselopruffstrategie ass [`sort_unstable_by_key`](#method.sort_unstable_by_key) méiglecherweis méi lues wéi [`sort_by_cached_key`](#method.sort_by_cached_key) a Fäll wou d'Schlësselfunktioun deier ass.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Bestellt d'Scheedung sou datt d'Element bei `index` op der leschter zortéierter Positioun ass.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Bestellt d'Scheedung mat enger Komparatorfunktioun sou datt d'Element bei `index` op senger definitiver sortéierter Positioun ass.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Bestellt d'Scheedung mat enger Schlëssel Extraktiounsfunktioun sou datt d'Element bei `index` op senger definitiver sortéierter Positioun ass.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Bestellt d'Scheedung sou datt d'Element bei `index` op der leschter zortéierter Positioun ass.
    ///
    /// Dës Ëmbestellung huet déi zousätzlech Eegeschaft datt all Wäert op der Positioun `i < index` manner wéi oder gläich wéi all Wäert op enger Positioun `j > index` wäert sinn.
    /// Zousätzlech ass dës Ëmbestellung onbestänneg (dh
    /// all Zuel vu gläiche Elementer kann op der Positioun `index` landen, op der Plaz (dh
    /// allocéiert net), an *O*(*n*) am schlëmmste Fall.
    /// Dës Funktioun ass och bekannt als "kth element" an anere Bibliothéiken.
    /// Et bréngt eng Triplett vun de folgende Wäerter zréck: all Elementer manner wéi deen am gegebenen Index, de Wäert um gegebenen Index, an all Elementer méi grouss wéi deen am gegebenen Index.
    ///
    ///
    /// # Aktuell Ëmsetzung
    ///
    /// Den aktuellen Algorithmus baséiert op dem Queckselect Deel vum selwechte Quicksort Algorithmus deen fir [`sort_unstable`] benotzt gëtt.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics wann `index >= len()`, dat heescht et ëmmer panics op eidel Scheiwen.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Fannt de Median
    /// v.select_nth_unstable(2);
    ///
    /// // Mir sinn nëmme garantéiert datt d'Scheibe ee vun de folgenden ass, baséiert op der Art a Weis wéi mir de spezifizéierten Index sortéieren.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Bestellt d'Scheedung mat enger Komparatorfunktioun sou datt d'Element bei `index` op senger definitiver sortéierter Positioun ass.
    ///
    /// Dës Ëmbestellung huet déi zousätzlech Eegeschaft datt all Wäert op der Positioun `i < index` manner wéi oder gläich wéi all Wäert op enger Positioun `j > index` mat der Vergläicherfunktioun ass.
    /// Zousätzlech ass dës Uerdnung onbestänneg (dh all Zuel vu gläiche Elementer kënnen op der Positioun `index` landen), op der Plaz (dh verdeelt net), an *O*(*n*) am schlëmmste Fall.
    /// Dës Funktioun ass och als "kth element" an anere Bibliothéiken bekannt.
    /// Et bréngt eng Triplett vun de folgende Wäerter zréck: all Elementer manner wéi deen am gegebene Index, de Wäert am gegebenen Index, an all Elementer méi grouss wéi deen am gegebenen Index, mat der virgeluechter Vergläicherfunktioun.
    ///
    ///
    /// # Aktuell Ëmsetzung
    ///
    /// Den aktuellen Algorithmus baséiert op dem Queckselect Deel vum selwechte Quicksort Algorithmus deen fir [`sort_unstable`] benotzt gëtt.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics wann `index >= len()`, dat heescht et ëmmer panics op eidel Scheiwen.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Fannt de Median wéi wann d'Scheif an ofsteigend Uerdnung sortéiert wier.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Mir sinn nëmme garantéiert datt d'Scheibe ee vun de folgenden ass, baséiert op der Art a Weis wéi mir de spezifizéierten Index sortéieren.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Bestellt d'Scheedung mat enger Schlëssel Extraktiounsfunktioun sou datt d'Element bei `index` op senger definitiver sortéierter Positioun ass.
    ///
    /// Dës Ëmbestellung huet déi zousätzlech Eegeschaft datt all Wäert op der Positioun `i < index` manner wéi oder gläich wéi all Wäert op enger Positioun `j > index` mat der Schlëssel Extraktioun Funktioun ass.
    /// Zousätzlech ass dës Uerdnung onbestänneg (dh all Zuel vu gläiche Elementer kënnen op der Positioun `index` landen), op der Plaz (dh verdeelt net), an *O*(*n*) am schlëmmste Fall.
    /// Dës Funktioun ass och als "kth element" an anere Bibliothéiken bekannt.
    /// Et bréngt eng Triplett vun de folgende Wäerter zréck: all Elementer manner wéi deen am gegebenen Index, de Wäert um gegebenen Index, an all Elementer méi grouss wéi deen am gegebenen Index, mat der verschaffter Schlëssel Extraktioun Funktioun.
    ///
    ///
    /// # Aktuell Ëmsetzung
    ///
    /// Den aktuellen Algorithmus baséiert op dem Queckselect Deel vum selwechte Quicksort Algorithmus deen fir [`sort_unstable`] benotzt gëtt.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics wann `index >= len()`, dat heescht et ëmmer panics op eidel Scheiwen.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Gitt de Median zréck wéi wann d'Array nom absoluten Wäert sortéiert wier.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Mir sinn nëmme garantéiert datt d'Scheibe ee vun de folgenden ass, baséiert op der Art a Weis wéi mir de spezifizéierten Index sortéieren.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Beweegt all hannereneen widderhuelend Elementer bis zum Enn vun der Scheif no der [`PartialEq`] trait Ëmsetzung.
    ///
    ///
    /// Retourneiert zwou Scheiwen.Déi éischt enthält keng hannereneen widderhuelend Elementer.
    /// Déi zweet enthält all Duplikaten a keng spezifizéierter Reiefolleg.
    ///
    /// Wann d'Scheif sortéiert ass, enthält déi éischt zréckgeschéckt Scheif keng Duplikater.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Beweegt all ausser déi éischt vun hannereneen Elementer bis zum Schluss vun der Scheif déi eng gegebene Gläichheetsbezéiung zefriddestellen.
    ///
    /// Retourneiert zwou Scheiwen.Déi éischt enthält keng hannereneen widderhuelend Elementer.
    /// Déi zweet enthält all Duplikaten a keng spezifizéierter Reiefolleg.
    ///
    /// D `same_bucket` Funktioun gëtt Referenzen op zwee Elementer aus der Scheif weiderginn a muss bestëmmen ob d'Elementer d'selwecht vergläichen.
    /// D'Elementer ginn am Géigendeel vun hirer Bestellung an der Scheif weiderginn, also wann `same_bucket(a, b)` `true` zréckkënnt, gëtt `a` um Enn vum Slice geréckelt.
    ///
    ///
    /// Wann d'Scheif sortéiert ass, enthält déi éischt zréckgeschéckt Scheif keng Duplikater.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Och wa mir eng mutéierbar Referenz op `self` hunn, kënne mir keng *arbiträr* Ännerunge maachen.D `same_bucket` Uriff kéinten panic, also musse mir sécher sinn datt de Stéck zu all Moment an engem gültege Staat ass.
        //
        // De Wee wéi mir dëst behandelen ass duerch Swaps ze benotzen;mir iteréieren iwwer all d'Elementer, tauschen eis sou hin, datt zum Schluss d'Elementer, déi mir wëlle behalen, virop sinn, an déi, déi mir refuséiere wëllen, sinn hannen.
        // Mir kënnen dann d'Scheedung deelen.
        // Dës Operatioun ass nach ëmmer `O(n)`.
        //
        // Beispill: Mir starten an dësem Zoustand, wou `r` "nächst" duerstellt
        // liesen "an `w` representéiert" next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Vergläichen self[r] géint selwer [w-1], dëst ass keen Duplikat, also tausche mir self[r] an self[w] (keen Effekt als r==w) an erhéije béid r a w, hannerléisst eis mat:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Am Verglach mam self[r] géint sech [w-1] ass dëse Wäert en Duplikat, also erhéije mir `r` awer loossen alles anescht onverännert:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Vergläichen self[r] géint selwer [w-1], dëst ass keen Duplikat, also tauscht self[r] an self[w] a fuert r a w vir:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Net en Duplikat, widderhuelen:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Duplizéiert, advance r. End vun der Scheif.Spalt am w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // SAFETY: den `while` Zoustand garantéiert `next_read` an `next_write`
        // si manner wéi `len`, also si bannent `self`.
        // `prev_ptr_write` weist op en Element virum `ptr_write`, awer `next_write` fänkt bei 1 un, sou datt `prev_ptr_write` ni manner wéi 0 ass a bannent der Scheif ass.
        // Dëst erfëllt d'Ufuerderunge fir Dereferenzen `ptr_read`, `prev_ptr_write` an `ptr_write`, a fir `ptr.add(next_read)`, `ptr.add(next_write - 1)` an `prev_ptr_write.offset(1)` ze benotzen.
        //
        //
        // `next_write` gëtt och héchstens pro Loop héchstens incrementéiert, dat heescht et gëtt keen Element iwwersprongen wann et muss ëmgetosch ginn.
        //
        // `ptr_read` an `prev_ptr_write` weisen ni op datselwecht Element.Dëst ass erfuerderlech fir `&mut *ptr_read`, `&mut* prev_ptr_write` fir sécher ze sinn.
        // D'Erklärung ass einfach datt `next_read >= next_write` ëmmer richteg ass, also `next_read > next_write - 1` och.
        //
        //
        //
        //
        //
        unsafe {
            // Vermeit Grenzen Kontrollen mat roude Zeigefanger.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Beweegt all ausser déi éischt vun hannereneen Elementer bis zum Schluss vun der Scheif déi sech op dee selwechte Schlëssel léisen.
    ///
    ///
    /// Retourneiert zwou Scheiwen.Déi éischt enthält keng hannereneen widderhuelend Elementer.
    /// Déi zweet enthält all Duplikaten a keng spezifizéierter Reiefolleg.
    ///
    /// Wann d'Scheif sortéiert ass, enthält déi éischt zréckgeschéckt Scheif keng Duplikater.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Rotéiert de Slice op der Plaz sou datt déi éischt `mid` Elementer vum Slice bis zum Enn réckele wärend déi lescht `self.len() - mid` Elementer no vir réckelen.
    /// Nodeems ech `rotate_left` opgeruff hunn, gëtt d'Element virdrun am Index `mid` dat éischt Element an der Scheif.
    ///
    /// # Panics
    ///
    /// Dës Funktioun wäert panic wann `mid` méi grouss ass wéi d'Längt vun der Scheif.Bedenkt datt `mid == self.len()` _not_ panic mécht an eng No-op Rotatioun ass.
    ///
    /// # Complexity
    ///
    /// Hëlt Linear (an `self.len()`) Zäit.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Eng Subslice rotéieren:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // SAFETY: D'Gamme `[p.add(mid) - mid, p.add(mid) + k)` ass trivial
        // valabel fir ze liesen an ze schreiwen, wéi et vun `ptr_rotate` erfuerderlech ass.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Rotéiert de Slice op der Plaz sou datt déi éischt `self.len() - k` Elementer vum Slice bis zum Enn réckele wärend déi lescht `k` Elementer no vir réckelen.
    /// Nodeems ech `rotate_right` opgeruff hunn, gëtt d'Element virdrun am Index `self.len() - k` dat éischt Element an der Scheif.
    ///
    /// # Panics
    ///
    /// Dës Funktioun wäert panic wann `k` méi grouss ass wéi d'Längt vun der Scheif.Bedenkt datt `k == self.len()` _not_ panic mécht an eng No-op Rotatioun ass.
    ///
    /// # Complexity
    ///
    /// Hëlt Linear (an `self.len()`) Zäit.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Rotéiert e Subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // SAFETY: D'Gamme `[p.add(mid) - mid, p.add(mid) + k)` ass trivial
        // valabel fir ze liesen an ze schreiwen, wéi et vun `ptr_rotate` erfuerderlech ass.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Fëllt `self` mat Elementer duerch `value` ze klonen.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Fëllt `self` mat Elementer zréck, andeems en ëmmer erëm zougemaach gëtt.
    ///
    /// Dës Method benotzt eng Zoumaache fir nei Wäerter ze kreéieren.Wann Dir [`Clone`] e bestëmmte Wäert léiwer benotzt, benotzt [`fill`].
    /// Wann Dir den [`Default`] trait benotze wëllt fir Wäerter ze generéieren, kënnt Dir [`Default::default`] als Argument weiderginn.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Kopéiert d'Elementer vun `src` an `self`.
    ///
    /// D'Längt vum `src` muss d'selwecht sinn wéi `self`.
    ///
    /// Wann `T` `Copy` implementéiert, kann et méi performant sinn [`copy_from_slice`] ze benotzen.
    ///
    /// # Panics
    ///
    /// Dës Funktioun wäert panic wann déi zwou Scheiwen ënnerschiddlech Längt hunn.
    ///
    /// # Examples
    ///
    /// Klonen vun zwee Elementer vun engem Stéck an en anert:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Well d'Scheiwen d'selwecht Längt musse sinn, schneide mir d'Quellschnitt vu véier Elementer op zwee.
    /// // Et wäert panic wa mir dëst net maachen.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust forcéiert datt et nëmmen eng mutéierbar Referenz ka ginn ouni onverännerbar Referenzen op e bestëmmt Stéck Daten an engem bestëmmten Ëmfang.
    /// Wéinst dësem Versuch `clone_from_slice` op enger eenzeger Scheif ze benotzen wäert zu engem Kompiléierungsausfall resultéieren:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Fir dëst z'ëmgoen, kënne mir [`split_at_mut`] benotze fir zwee verschidde Ënnerschnitter aus engem Slice ze kreéieren:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Kopéiert all Elementer aus `src` an `self`, mat engem Memcpy.
    ///
    /// D'Längt vum `src` muss d'selwecht sinn wéi `self`.
    ///
    /// Wann `T` net `Copy` implementéiert, benotzt [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Dës Funktioun wäert panic wann déi zwou Scheiwen ënnerschiddlech Längt hunn.
    ///
    /// # Examples
    ///
    /// Kopéiert zwee Elementer vun engem Stéck an en anert:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Well d'Scheiwen d'selwecht Längt musse sinn, schneide mir d'Quellschnitt vu véier Elementer op zwee.
    /// // Et wäert panic wa mir dëst net maachen.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust forcéiert datt et nëmmen eng mutéierbar Referenz ka ginn ouni onverännerbar Referenzen op e bestëmmt Stéck Daten an engem bestëmmten Ëmfang.
    /// Wéinst dësem Versuch `copy_from_slice` op enger eenzeger Scheif ze benotzen wäert zu engem Kompiléierungsausfall resultéieren:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Fir dëst z'ëmgoen, kënne mir [`split_at_mut`] benotze fir zwee verschidde Ënnerschnitter aus engem Slice ze kreéieren:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // Den panic Code Wee gouf an eng kal Funktioun gesat fir den Uruff Site net opzeblosen.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // SAFETY: `self` ass valabel fir `self.len()` Elementer no Definitioun, an `src` war
        // iwwerpréift fir déiselwecht Längt ze hunn.
        // D'Scheiwen kënnen net iwwerlappt ginn well mutabel Referenzen exklusiv sinn.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Kopéiert Elementer vun engem Deel vun der Scheif an en aneren Deel vu sech selwer, mat engem Memmove.
    ///
    /// `src` ass d'Gamme vu `self` fir ze kopéieren.
    /// `dest` ass de Startindex vun der Gamme bannent `self` fir ze kopéieren, déi déiselwecht Längt wéi `src` huet.
    /// Déi zwee Reegele kënnen iwwerlappend sinn.
    /// D'Enn vun den zwee Reegele musse manner wéi oder gläich wéi `self.len()` sinn.
    ///
    /// # Panics
    ///
    /// Dës Funktioun wäert panic wann ee Beräich d'Enn vun der Scheif iwwerschreit, oder wann d'Enn vum `src` virum Start ass.
    ///
    ///
    /// # Examples
    ///
    /// Véier Bytes an engem Slice kopéieren:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // SAFETY: d'Konditioune fir `ptr::copy` sinn all uewen iwwerpréift ginn,
        // wéi och déi fir `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Tauscht all Elementer an `self` mat deenen an `other` aus.
    ///
    /// D'Längt vum `other` muss d'selwecht sinn wéi `self`.
    ///
    /// # Panics
    ///
    /// Dës Funktioun wäert panic wann déi zwou Scheiwen ënnerschiddlech Längt hunn.
    ///
    /// # Example
    ///
    /// Tauschen vun zwee Elementer iwwer Scheiwen:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust forcéiert datt et nëmmen eng mutéierbar Referenz zu engem bestëmmten Deel vun Daten an engem bestëmmten Ëmfang ka ginn.
    ///
    /// Wéinst dësem Versuch `swap_with_slice` op enger eenzeger Scheif ze benotzen wäert zu engem Kompiléierungsausfall resultéieren:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Fir dëst z'ëmgoen, kënne mir [`split_at_mut`] benotze fir zwee verschidde mutabel Ënnerschnitter aus engem Slice ze kreéieren:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // SAFETY: `self` ass valabel fir `self.len()` Elementer no Definitioun, an `src` war
        // iwwerpréift fir déiselwecht Längt ze hunn.
        // D'Scheiwen kënnen net iwwerlappt ginn well mutabel Referenzen exklusiv sinn.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Funktioun fir d'Längt vun der Mëtt an de Schlitzschnitt fir `align_to{,_mut}` ze berechnen.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Wat mir iwwer `rest` maachen, ass erauszefannen wéi e Multiple vun "U" mir an eng niddregst Zuel vun "T" setzen.
        //
        // A wéi vill `T`e brauche mir fir all sou "multiple".
        //
        // Betruecht zum Beispill T=u8 U=u16.Da kënne mir 1 U an 2 Ts setzen.Einfach.
        // Betruecht elo zum Beispill e Fall wou size_of: :<T>=16, Gréisst_of::<U>=24.</u>
        // Mir kënnen 2 Us op der Plaz vun all 3 Ts an der `rest` Scheif setzen.
        // E bësse méi komplizéiert.
        //
        // Formel fir dat auszerechnen ass:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Ausgebaut a vereinfacht:
        //
        // Us=Gréisst_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Glécklech well dëst alles konstant bewäert gëtt ... Leeschtung hei ass wichteg!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // iterativen Stein Algorithmus Mir sollten dësen `const fn` nach ëmmer maachen (a réckgängeg maachen op rekursive Algorithmus wa mir et maachen) well mir vertrauen op llvm fir consteval all dëst ass ... gutt, et mécht mech onwuel.
            //
            //

            // SAFETY: `a` an `b` ginn iwwerpréift fir net Null Wäerter ze sinn.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // huelt all Faktore vun 2 aus b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // SAFETY: `b` gëtt gekuckt als Net-Null.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Arméiert mat dësem Wëssen, kënne mir fannen wéi vill `U`e mir passen!
        let us_len = self.len() / ts * us;
        // A wéi vill `T`s sinn an der hannendran Scheif!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Transmutéiert de Stéck op e Stéck vun engem aneren Typ, a garantéiert d'Ausrichtung vun den Zorten erhalen.
    ///
    /// Dës Method deelt d'Scheiwen an dräi verschidde Scheiwen: Präfix, korrekt ausgeriicht Mëttelschnëtt vun engem neien Typ, an d'Suffixschnitt.
    /// D'Methode kann d'Mëtt Slice déi gréisst Längt méiglech fir e bestëmmten Typ an Input Slice maachen, awer nëmmen d'Performance vun Ärem Algorithmus sollt dovun ofhänken, net seng Richtegkeet.
    ///
    /// Et ass erlaabt datt all d'Input Daten als Präfix oder Suffix Slice zréckginn.
    ///
    /// Dës Method huet keen Zweck wann entweder Input Element `T` oder Output Element `U` null Gréisst sinn a wäert d'original Scheif zréckginn ouni eppes opzedeelen.
    ///
    /// # Safety
    ///
    /// Dës Method ass am Wesentlechen en `transmute` mat Bezuch op d'Elementer an der zréckgeschniddene Mëttelscheif, sou datt all déi üblech Opfaassungen betreffend `transmute::<T, U>` och hei gëllen.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Bedenkt datt déi meescht vun dëser Funktioun konstant evaluéiert ginn,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // handhaben ZSTs speziell, dat ass-packen se guer net.
            return (self, &[], &[]);
        }

        // Als éischt fannt Dir op wéi engem Punkt mir tëscht der éischter an der 2. Scheif deelen.
        // Einfach mat ptr.align_offset.
        let ptr = self.as_ptr();
        // SAFETY: Kuckt d `align_to_mut` Method fir den detailléierte Sécherheetskommentar.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // SAFETY: elo ass `rest` definitiv ausgeriicht, sou datt `from_raw_parts` hei drënner ass okay,
            // well den Uruffer garantéiert datt mir `T` op `U` sécher kënnen iwwerdroen.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Transmutéiert de Stéck op e Stéck vun engem aneren Typ, a garantéiert d'Ausrichtung vun den Zorten erhalen.
    ///
    /// Dës Method deelt d'Scheiwen an dräi verschidde Scheiwen: Präfix, korrekt ausgeriicht Mëttelschnëtt vun engem neien Typ, an d'Suffixschnitt.
    /// D'Methode kann d'Mëtt Slice déi gréisst Längt méiglech fir e bestëmmten Typ an Input Slice maachen, awer nëmmen d'Performance vun Ärem Algorithmus sollt dovun ofhänken, net seng Richtegkeet.
    ///
    /// Et ass erlaabt datt all d'Input Daten als Präfix oder Suffix Slice zréckginn.
    ///
    /// Dës Method huet keen Zweck wann entweder Input Element `T` oder Output Element `U` null Gréisst sinn a wäert d'original Scheif zréckginn ouni eppes opzedeelen.
    ///
    /// # Safety
    ///
    /// Dës Method ass am Wesentlechen en `transmute` mat Bezuch op d'Elementer an der zréckgeschniddene Mëttelscheif, sou datt all déi üblech Opfaassungen betreffend `transmute::<T, U>` och hei gëllen.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Bedenkt datt déi meescht vun dëser Funktioun konstant evaluéiert ginn,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // handhaben ZSTs speziell, dat ass-packen se guer net.
            return (self, &mut [], &mut []);
        }

        // Als éischt fannt Dir op wéi engem Punkt mir tëscht der éischter an der 2. Scheif deelen.
        // Einfach mat ptr.align_offset.
        let ptr = self.as_ptr();
        // SAFETY: Hei si mir sécher datt mir ausgeriicht Uweiser fir U benotze fir de
        // Rescht vun der Method.Dëst gëtt gemaach andeems Dir e Zeiger op&[T] mat enger Ausriichtung geziilt fir U. weiderginn.
        // `crate::ptr::align_offset` gëtt mat engem korrekt ausgeriicht a gëltege Zeiger `ptr` genannt (et kënnt vun enger Referenz op `self`) a mat enger Gréisst déi eng Kraaft vun zwee ass (well et kënnt aus der Ausriichtung fir U), wat seng Sécherheetsbeschränkungen zefriddestellt.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Mir kënnen net méi no `rest` benotzen, dat géif säin Alias `mut_ptr` ongëlteg maachen!SAFETY: kuckt d'Kommentarer fir `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Kontrolléiert ob d'Elementer vun dëser Scheif zortéiert sinn.
    ///
    /// Dat ass, fir all Element `a` a säi folgend Element `b`, muss `a <= b` halen.Wann de Slice exakt Null oder een Element bréngt, gëtt `true` zréckginn.
    ///
    /// Bedenkt datt wann `Self::Item` nëmmen `PartialOrd` ass, awer net `Ord`, déi uewe genannte Definitioun implizéiert datt dës Funktioun `false` zréckschéckt wann zwee pafolgende Saache net vergläichbar sinn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Kontrolléiert ob d'Elementer vun dëser Scheif sortéiert gi mat der gegebene Vergläicherfunktioun.
    ///
    /// Amplaz `PartialOrd::partial_cmp` ze benotzen, benotzt dës Funktioun déi gegebene `compare` Funktioun fir d'Bestellung vun zwee Elementer ze bestëmmen.
    /// Ofgesinn dovun ass et gläich wéi [`is_sorted`];kuckt seng Dokumentatioun fir méi Informatioun.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Kontrolléiert ob d'Elementer vun dëser Scheif sortéiert gi mat der gegebene Schlëssel Extraktioun Funktioun.
    ///
    /// Amplaz de Slice Elementer direkt ze vergläichen, vergläicht dës Funktioun d'Schlëssele vun den Elementer, wéi se vum `f` bestëmmt ginn.
    /// Ofgesinn dovun ass et gläich wéi [`is_sorted`];kuckt seng Dokumentatioun fir méi Informatioun.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Gitt den Index vum Partitionspunkt no dem gegebene Predikat (den Index vum éischten Element vun der zweeter Partition) zréck.
    ///
    /// D'Scheif gëtt ugeholl datt se no dem gegebene Predikat partitionéiert sinn.
    /// Dëst bedeit datt all Elementer fir déi de Prädikat richteg ass am Ufank vun der Scheif sinn an all Elementer fir déi d'Predikat falsch zréckkënnt um Enn sinn.
    ///
    /// Zum Beispill ass [7, 15, 3, 5, 4, 12, 6] ënner dem Prädikat x% 2 partitionéiert!=0 (all komesch Zuelen sinn um Ufank, all och um Enn).
    ///
    /// Wann dës Scheif net opgedeelt ass, ass dat zréckkommt Resultat net spezifizéiert a sënnlos, well dës Method eng Aart vu binäre Sich mécht.
    ///
    /// Kuckt och [`binary_search`], [`binary_search_by`], an [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // SAFETY: Wann `left < right`, `left <= mid < right`.
            // Dofir klëmmt `left` ëmmer an `right` geet ëmmer erof, an ee vun hinne gëtt ausgewielt.A béide Fäll ass `left <= right` zefridden.Dofir wann `left < right` an engem Schrëtt ass, ass `left <= right` am nächste Schrëtt zefridden.
            //
            // Dofir soulaang `left != right`, `0 <= left < right <= len` zefridden ass a wann dëse Fall `0 <= mid < len` och zefridden ass.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Mir mussen se explizit op d'selwecht Längt schneiden
        // fir et dem Optimizer méi einfach ze maachen d'Grenzkontroll z'eléieren.
        // Awer well et net ka vertrauen, hu mir och eng explizit Spezialiséierung fir T: Copy.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Erstellt eng eidel Scheif.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Erstellt eng mutabel eidel Scheif.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Musteren a Scheiwen, aktuell, nëmme vun `strip_prefix` an `strip_suffix` benotzt.
/// Zu engem future Punkt hoffe mir d `core::str::Pattern` ze generaliséieren (wat zum Schreiwezeit op `str` limitéiert ass) op Scheiwen, an da gëtt dësen trait ersat oder ofgeschaaft.
///
pub trait SlicePattern {
    /// D'Elementart vun der Scheif déi ugepasst gëtt.
    type Item;

    /// Momentan brauchen d'Konsumenten vun `SlicePattern` e Stéck.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}