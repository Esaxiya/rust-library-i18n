//! Operatiounen op ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Kontrolléiert ob all Bytes an dëser Scheif am ASCII Beräich sinn.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Kontrolléiert datt zwou Scheiwen en ASCII case-onsensitive Match sinn.
    ///
    /// Selwecht wéi `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, awer ouni temporäre ze allocéieren an ze kopéieren.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Konvertéiert dëse Stéck op säin ASCII-Uewerfall gläichwäerteg op der Plaz.
    ///
    /// ASCII Buschtawen 'a' op 'z' ginn op 'A' op 'Z', awer net ASCII Bréiwer sinn onverännert.
    ///
    /// Fir en neie geschriwwene Wäert zréckzebréngen ouni dee bestehenden ze änneren, benotzt [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Konvertéiert dëse Stéck op säin ASCII kleng Fall gläichwäerteg op der Plaz.
    ///
    /// ASCII Buschtawen 'A' op 'Z' ginn op 'a' op 'z', awer net ASCII Bréiwer sinn onverännert.
    ///
    /// Fir en neie méi nidderege Wäert zréckzebréngen ouni dee bestehenden ze änneren, benotzt [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Gitt `true` zréck wann e Byte am Wuert `v` nonascii ass (>=128).
/// Snarfed vun `../str/mod.rs`, wat eppes ähnleches fir utf8 Validatioun mécht.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Optimiséiert ASCII Test deen Usize-at-a-Time Operatiounen amplaz Byte-at-a-Time Operatiounen benotzt (wa méiglech).
///
/// Den Algorithmus dee mir hei benotzen ass relativ einfach.Wann `s` ze kuerz ass, kontrolléiere mir just all Byte a si fäerdeg.Soss:
///
/// - Liest dat éischt Wuert mat enger net ausgeriicht Laascht.
/// - Riicht de Zeiger aus, liest duerno Wierder bis Enn mat ausgeriicht Laaschten.
/// - Liest de leschten `usize` vun `s` mat enger net ausgeriicht Laascht.
///
/// Wann ee vun dëse Laaschten eppes produzéiert fir dat `contains_nonascii` (above) richteg ass, da wësse mer d'Äntwert falsch.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Wa mir näischt vun der Wuert-zu-Zäit-Implementéierung gewannen, fällt zréck op eng skalar Loop.
    //
    // Mir maachen dat och fir Architekturen wou `size_of::<usize>()` net genuch Ausriichtung fir `usize` ass, well et ass e komeschen edge Fall.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Mir liesen ëmmer dat éischt Wuert net ausgeriicht, dat heescht `align_offset` ass
    // 0, géife mir deeselwechte Wäert nach eng Kéier fir den ausgeriichtene Lies liesen.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // SAFETY: Mir verifizéieren `len < USIZE_SIZE` uewen.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Mir hunn dëst uewen iwwerpréift, e bësse implizit.
    // Bedenkt datt `offset_to_aligned` entweder `align_offset` oder `USIZE_SIZE` ass, béid sinn explizit uewen iwwerpréift.
    //
    debug_assert!(offset_to_aligned <= len);

    // SAFETY: word_ptr ass den (richteg ausgeriicht) usize ptr dee mir benotze fir de ze liesen
    // mëttler Stéck vum Stéck.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` ass de Byte Index vun `word_ptr`, benotzt fir Loop End Kontrollen.
    let mut byte_pos = offset_to_aligned;

    // Paranoia kontrolléiert iwwer d'Ausrichtung, well mir sinn amgaang eng Rëtsch ungeriicht Lueden ze maachen.
    // An der Praxis sollt dëst awer onméiglech sinn e Feeler am `align_offset` auszespären.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Liest duerno Wierder bis zum leschte ausgeriichtene Wuert, ausser dat lescht ausgeriichtent Wuert selwer fir méi spéit am Schwanzcheck ze maachen, fir sécherzestellen datt de Schwanz ëmmer en `usize` héchstens fir extra branch `byte_pos == len` ass.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Sanitéit kontrolléiert datt d'Liesen a Grenzen ass
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // An datt eis Viraussetzungen iwwer `byte_pos` halen.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // SAFETY: Mir wëssen datt `word_ptr` richteg ausgeriicht ass (wéinst
        // 'align_offset'), a mir wëssen datt mir genuch Bytes tëscht `word_ptr` an Enn hunn
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // SAFETY: Mir wëssen datt `byte_pos <= len - USIZE_SIZE`, dat heescht dat
        // no dësem `add` wäert `word_ptr` héchstens e Vergaangenheet sinn.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Sanitéitskontroll fir sécherzestellen datt wierklech nëmmen een `usize` nach ass.
    // Dëst sollt duerch eise Loop Zoustand garantéiert sinn.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // SAFETY: Dëst setzt op `len >= USIZE_SIZE`, wat mir am Ufank kontrolléieren.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}