//! Typen déi Daten op seng Plaz am Gedächtnis pinnen.
//!
//! Et ass heiansdo nëtzlech Objeten ze hunn déi garantéiert sinn net ze bewegen, am Sënn datt hir Plazéierung an der Erënnerung net ännert, a kann also op vertrauen.
//! E primescht Beispill vu sou engem Szenario wier d'Selbstbezeechnungstructuren ze bauen, well en Objet mat Zeigefanger u sech beweegt, wäert se ongëlteg maachen, wat kéint ondefinéiert Verhalen verursaachen.
//!
//! Op engem héijen Niveau suergt en [`Pin<P>`] fir datt de Zeigefanger vun all Zeigertyp `P` e stabile Standuert am Gedächtnis huet, dat heescht datt et net anescht geréckelt ka ginn a säi Gedächtnis net verhandelt ka ginn bis et erofgefall ass.Mir soen datt de Pointee "pinned" ass.D'Saache gi méi subtil wann Dir iwwer Diskussiounen iwwer Aarte diskutéiert déi mat net-gespaarte Daten kombinéiert sinn;[see below](#projections-and-structural-pinning) fir méi Detailer.
//!
//! Par défaut sinn all Typen an Rust beweegbar.
//! Rust erlaabt all Typen duerch Wäert ze vermëttelen, a gemeinsam Smart-Pointer-Typen wéi [`Box<T>`] an `&mut T` erlaben d'Wäerter déi se enthalen z'ersetzen an ze réckelen: Dir kënnt aus engem [`Box<T>`] réckelen, oder Dir kënnt [`mem::swap`] benotzen.
//! [`Pin<P>`] wéckelt en Zeiger Typ `P`, also [`Pin`]`<`[`Box`] `<T>> funktionnéiert sou wéi e regelméisseg
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Box`] `<T>> gëtt fale gelooss, also säin Inhalt, an d'Erënnerung kritt
//!
//! ausgedeelt.Ähnlech ass ["Pin"] "<&mut T>" vill wéi `&mut T`.Wéi och ëmmer, [`Pin<P>`] léisst d'Clienten net tatsächlech en [`Box<T>`] oder `&mut T` op gespaarte Daten kréien, wat implizéiert datt Dir keng Operatioune wéi [`mem::swap`] benotze kënnt:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` brauch `&mut T`, awer mir kënnen et net kréien.
//!     // Mir sinn hänke bliwwen, mir kënnen den Inhalt vun dëse Referenzen net austauschen.
//!     // Mir kéinten `Pin::get_unchecked_mut` benotzen, awer dat ass onsécher aus engem Grond:
//!     // mir däerfen et net benotze fir Saachen aus der `Pin` ze réckelen.
//! }
//! ```
//!
//! Et ass derwäert ze widderhuelen datt [`Pin<P>`] d'Tatsaach *net* ännert datt en Rust Compiler all Typ beweeglech betruecht.[`mem::swap`] bleift callable fir all `T`.Amplaz datt [`Pin<P>`] verhënnert datt verschidde *Wäerter*(déi vun Zeigefanger gewéckelt an [`Pin<P>`] gewise ginn) geplënnert ginn andeems et onméiglech ass Methoden ze nennen déi `&mut T` drop erfuerderen (wéi [`mem::swap`]).
//!
//! [`Pin<P>`] ka benotzt ginn fir all Zeigertyp `P` ze wéckelen, a sou interagéiert se mat [`Deref`] an [`DerefMut`].En [`Pin<P>`] wou `P: Deref` als "`P`-style pointer" zu engem gespéngten `P::Target` sollt ugesi ginn-also, e [`Pin`]`<`[`Box`] `<T>>`ass en eegene Zeigefanger zu engem agespaarte `T`, an engem [`Pin`] `<` [`Rc`]`<T>>"ass e Referenzgezeechent Zeiger op e gespaarte `T`.
//! Fir Richtegkeet setzt [`Pin<P>`] op d'Implementéierunge vun [`Deref`] an [`DerefMut`] net aus hirem `self` Parameter ze réckelen, an nëmmen ëmmer e Zeigefanger op festgesaten Donnéeën zréckzeginn wa se op e festgehalem Zeiger geruff ginn.
//!
//! # `Unpin`
//!
//! Vill Zorten sinn ëmmer fräi beweegbar, och wa se festgespaart sinn, well se vertrauen net drop eng stabil Adress ze hunn.Dëst beinhalt all Basistypen (wéi [`bool`], [`i32`] a Referenzen) souwéi Typen déi nëmmen aus dësen Typen bestinn.Typen déi net ëm d'Pinn këmmeren implementéieren den [`Unpin`] Auto-trait, deen den Effekt vun [`Pin<P>`] annuléiert.
//! Fir `T: Unpin`, [`Pin`]`<`[`Box`] `<T>>`an [`Box<T>`] funktionnéieren identesch, sou wéi [`Pin`] `<&mut T>` an `&mut T`.
//!
//! Bedenkt datt Pinning an [`Unpin`] nëmmen de geziilten Typ `P::Target` beaflossen, net de Zeigefanger `P` selwer deen an [`Pin<P>`] gewéckelt ass.Zum Beispill, ob [`Box<T>`] [`Unpin`] ass oder net, huet keen Afloss op d'Behuele vun [`Pin`]`<`[`Box`] `<T>>"(hei, `T` ass den uginn Typ).
//!
//! # Beispill: selbstbezeechnend Struktur
//!
//! Ier mer méi Detailer ginn fir d'Garantien a Choixen, déi mam `Pin<T>` verbonne sinn, z'erklären, diskutéiere mir iwwer Beispiller fir wéi et benotzt ka ginn.
//! Fillt Iech gratis op [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Dëst ass e selbstverweechend Struktur well de Slice Feld weist op d'Datenfeld.
//! // Mir kënnen de Compiler net doriwwer mat enger normaler Referenz informéieren, well dëst Muster net mat den übleche Prêtregele beschriwwe ka ginn.
//! //
//! // Amplaz benotze mir e roude Zeiger, awer een dee bekannt ass net null ze sinn, well mir wëssen datt et op de String weist.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Fir sécherzestellen datt d'Donnéeë sech net bewegen wann d'Funktioun zréckkomm ass, plazéiere mir se an de Koup wou se fir d'Liewensdauer vum Objet bleiwen, an deen eenzege Wee fir Zougang dozou wier duerch e Zeiger drop.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // mir kreéieren nëmmen den Zeiger wann d'Donnéeën op der Plaz sinn soss wäerte se scho geplënnert sinn ier mer iwwerhaapt ugefaang hunn
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // mir wëssen datt dëst sécher ass well e Feld änneren net de ganzen Struct réckelt
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // De Zeiger soll op déi richteg Plaz hiweisen, soulaang de Struktur net geréckelt ass.
//! //
//! // Mëttlerweil si mir fräi de Zeiger ronderëm ze réckelen.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Well eis Aart net Unpin implementéiert, ass dëst net kompiléiert:
//! // looss mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Beispill: opdrénglech duebel verlinkt Lëscht
//!
//! An enger opdrénglecher duebel-verlinkt Lëscht verdeelt d'Sammlung net tatsächlech d'Erënnerung fir d'Elementer selwer.
//! Allocation gëtt vun de Clienten kontrolléiert, an Elementer kënnen op engem Stackframe liewen, dee méi kuerz lieft wéi d'Kollektioun.
//!
//! Fir dëst ze schaffen, huet all Element Indikatiounen op säi Virgänger an säin Nofolger an der Lëscht.Elementer kënnen nëmme bäigefüügt ginn wann se gespaart sinn, well d'Elementer ronderëm réckelen, géifen d'Indikatiounen ongëlteg maachen.Ausserdeem wäert d [`Drop`] Implementatioun vun engem verlinkten Lëscht Element d'Pinters vu sengem Virgänger an Nofolger flécken fir sech selwer aus der Lëscht ze läschen.
//!
//! Entscheedend musse mir eis kënnen drop verloossen datt [`drop`] ugeruff gëtt.Wann en Element kéint Deallocéiert oder anescht ongëlteg gemaach ginn ouni [`drop`] ze ruffen, wäerten d'Zeechner an et vu sengen Nopeschelementer ongëlteg ginn, wat d'Datenstruktur géif briechen.
//!
//! Dofir gëtt Pinning och mat enger [`drop`]-relaterter Garantie.
//!
//! # `Drop` guarantee
//!
//! Den Zweck vum Pinning ass et ze kënnen op d'Plazéierung vun e puer Daten an der Erënnerung ze vertrauen.
//! Fir dëst ze schaffen, ass net nëmmen d'Donnéeë geréckelt limitéiert;Deallokéieren, nei opbauen oder anescht ongëlteg d'Erënnerung benotzt fir d'Daten ze späicheren ass och limitéiert.
//! Konkret, fir festgesaten Daten musst Dir den Invarier behalen datt *säi Gedächtnis net ongëlteg gëtt oder nei repurposéiert gëtt vum Moment wou et gespaart gëtt bis wann [`drop`] genannt gëtt*.Nëmme wann [`drop`] zréckgeet oder panics, kann d'Erënnerung weiderbenotzt ginn.
//!
//! Erënnerung kann "invalidated" duerch Deallocation sinn, awer och andeems en [`Some(v)`] duerch [`None`] ersat gëtt, oder [`Vec::set_len`] op "kill" e puer Elementer aus engem vector nennt.Et kann repurposéiert ginn andeems Dir [`ptr::write`] benotzt fir et ze iwwerschreiwe ouni den Destruktor als éischt ze ruffen.Keen dovu ass erlaabt fir gespaart Daten ouni [`drop`] ze ruffen.
//!
//! Dëst ass genau déi Aart vu Garantie datt déi opdrénglech verlinkt Lëscht aus dem virege Sektioun richteg funktionéiere muss.
//!
//! Bedenkt datt dës Garantie *net* bedeit datt d'Erënnerung net leckt!Et ass nach ëmmer ganz okay net ëmmer [`drop`] op en agespaart Element ze ruffen (z. B. Dir kënnt ëmmer nach [`mem::forget`] op engem [`Pin`]`<`[`Box`] 'nennen<T>> `).Am Beispill vun der duebelverbonne Lëscht bleiwt dat Element just an der Lëscht.Dir kënnt awer d'Späichere *net fräi maachen oder weiderbenotzen ouni [[drop"]* ze ruffen.
//!
//! # `Drop` implementation
//!
//! Wann Ären Typ Pinning benotzt (wéi déi zwee Beispiller hei uewen), musst Dir oppassen wann Dir [`Drop`] implementéiert.D [`drop`] Funktioun hëlt `&mut self`, awer dëst gëtt *genannt och wann Ären Typ virdru gespaart war*!Et ass wéi wann de Compiler automatesch [`Pin::get_unchecked_mut`] genannt gëtt.
//!
//! Dëst kann ni e Problem am séchere Code verursaachen well en Typ implementéieren deen op Pinning setzt erfuerdert onséchere Code, awer sidd bewosst datt Dir decidéiert d'Benotzung vu Pinning an Ärem Typ ze maachen (zum Beispill andeems Dir eng Operatioun op [`Pin`]`<&Selbst implementéiert>`oder [`Pin`] `<&mut Selbst> ') huet och Konsequenze fir Är [`Drop`] Ëmsetzung: wann en Element vun Ärem Typ hätt kënne festgemaach ginn, musst Dir [`Drop`] behandele wéi implizit [[Pin"] <&mut Selwer>.
//!
//!
//! Zum Beispill kënnt Dir `Drop` wéi folgend implementéieren:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` ass okay well mir wëssen datt dëse Wäert ni méi benotzt gëtt nodeems en erofgefall ass.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Tatsächlech Drop Code geet hei.
//!         }
//!     }
//! }
//! ```
//!
//! D'Funktioun `inner_drop` huet den Typ deen [`drop`]*sollt* hunn, sou datt dëst sécher ass datt Dir net zoufälleg `self`/`this` op eng Manéier benotzt déi am Konflikt mam Pinning ass.
//!
//! Ausserdeem, wann Ären Typ `#[repr(packed)]` ass, wäert de Compiler automatesch Felder bewegen fir se fale kënnen.Et kéint et och maachen fir Felder déi genuch ausgeriicht sinn.Als Konsequenz kënnt Dir net mat engem `#[repr(packed)]` Typ pinning benotzen.
//!
//! # Projectiounen a Strukturfaarwen
//!
//! Wann Dir mat pinned Structs schafft, stellt sech d'Fro wéi een op d'Felder vun där Struktur kënnt an enger Method déi just [`Pin`]`<&mut Struct>`dauert.
//! Déi üblech Approche ass Hëllefsmethoden ze schreiwen (sougenannte *Projektiounen*) déi ['Pin'] '<&mut Struct>' an eng Referenz zum Feld maachen, awer wéi eng Zort soll dës Referenz hunn?Ass et [`Pin`]`<&mut Field>`oder `&mut Field`?
//! Déiselwecht Fro stellt sech mat de Felder vun engem `enum`, an och wann Dir container/wrapper Aarte wéi [`Vec<T>`], [`Box<T>`] oder [`RefCell<T>`] berécksiichtegt.
//! (Dës Fro gëlt fir mutéierbar a gedeelt Referenzen, mir benotze just de méi heefegste Fall vu mutable Referenzen hei fir Illustratioun.)
//!
//! Et stellt sech eraus datt et tatsächlech um Autor vun der Datestruktur ass ze entscheeden ob déi festgestallte Projektioun fir e bestëmmt Feld ['Pin'] '<&mut Struct>' an ['Pin'] '<&mut Field>' oder `&mut Field`.Et ginn awer e puer Contrainten, an déi wichtegst Contraint ass *Konsequenz*:
//! all Feld kann *entweder* op eng festgestallte Referenz projezéiert ginn,*oder* als Deel vun der Projektioun gespaart ginn.
//! Wa béid fir datselwecht Feld gemaach ginn, wäert dat wuel net gesond sinn!
//!
//! Als Autor vun enger Datestruktur kënnt Dir fir all Feld entscheeden ob Dir "propagates" op dëst Feld pinnt oder net.
//! Pinning déi propagéiert gëtt och "structural" genannt, well et der Struktur vum Typ follegt.
//! An de folgenden Ënnersektioune beschreiwe mir d'Iwwerleeungen, déi fir eng Wiel musse gemaach ginn.
//!
//! ## Pinning *ass net* strukturell fir `field`
//!
//! Et ka kontra-intuitiv schéngen datt d'Feld vun engem gespéngte Struktur net gespaart ass, awer dat ass eigentlech déi einfachst Wiel: wann e [`Pin`]` <&mut Feld> 'ni erstallt gëtt, kann näischt falsch goen!Also, wann Dir décidéiert datt e puer Felder kee strukturelle Pinning hunn, alles wat Dir maache musst ass datt Dir ni eng agespaart Referenz zu deem Feld erstellt.
//!
//! Felder ouni strukturell Pinnen kënnen eng Projektiounsmethod hunn déi [`Pin`]` <&mut Struct> 'an `&mut Field` mécht:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Dëst ass okay well `field` gëtt ni als gespaart ugesinn.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Dir kënnt och `impl Unpin for Struct`*och wann* d'Zort `field` net [`Unpin`] ass.Wat deen Typ denkt iwwer ze pinnen ass net relevant wa kee [`Pin`]` <&mut Field> 'jeemools erstallt gëtt.
//!
//! ## Pinning *ass* strukturell fir `field`
//!
//! Déi aner Optioun ass ze entscheeden datt Pinning "structural" fir `field` ass, dat heescht datt wann de Struct gespaart ass, sou ass d'Feld.
//!
//! Dëst erlaabt eng Projektioun ze schreiwen déi e [`Pin`] '<&mut Feld>' erstellt, an doduerch Zeien datt d'Feld festgespaart ass:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Dëst ass okay well `field` gespaart ass wann `self` ass.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Wéi och ëmmer, strukturell Pinning kënnt mat e puer Extra Ufuerderungen:
//!
//! 1. De Struct muss nëmmen [`Unpin`] sinn wann all strukturell Felder [`Unpin`] sinn.Dëst ass de Standard, awer [`Unpin`] ass e sécheren trait, also als Autor vum Struct ass et Är Verantwortung *net* fir eppes wéi `impl<T> Unpin for Struct<T>` bäizefügen.
//! "
//! 2. Den Destructor vum Struct däerf keng strukturell Felder aus sengem Argument réckelen.Dëst ass de genauen Punkt deen am [previous section][drop-impl] opgewuess ass: `drop` hëlt `&mut self`, awer de Struktur (an domat seng Felder) kéint virdru festgesat ginn.
//!     Dir musst garantéieren datt Dir kee Feld an Ärer [`Drop`] Implementatioun réckelt.
//!     Besonnesch, wéi virdru erkläert, heescht dat datt Äre Struct *net* muss `#[repr(packed)]` sinn.
//!     Kuckt dës Sektioun fir wéi Dir [`drop`] esou schreift wéi de Compiler Iech hëllefe kënnt net zoufälleg ze knipsen.
//! 3. Dir musst sécher sinn datt Dir den [`Drop` guarantee][drop-guarantee] oprecht hält:
//!     wann Äre Struktur gespaart ass, gëtt d'Erënnerung, déi den Inhalt enthält, net iwwerschriwwen oder Deallokaliséiert ouni den Destruktoren vum Inhalt ze nennen.
//!     Dëst kann komplizéiert sinn, wéi et vun [`VecDeque<T>`] ze gesinn ass: den Destructor vun [`VecDeque<T>`] kann net falen den [`drop`] op all Elementer ze ruffen wann ee vun den Destruktoren panics.Dëst verstéisst géint d [`Drop`] Garantie, well et kann dozou féieren datt Elementer verhandelt ginn ouni datt hiren Destruktor geruff gëtt.([`VecDeque<T>`] huet keng Pinneprojektiounen, sou datt dëst keng Ongerechtegkeet verursaacht.)
//! 4. Dir däerft keng aner Operatiounen ubidden déi dozou féiere kënnen datt Daten aus de strukturelle Felder geréckelt ginn wann Ären Typ gespaart ass.Zum Beispill, wann de Struktur en [`Option<T>`] enthält an et ass eng "take"-ähnlech Operatioun mam Typ `fn(Pin<&mut Struct<T>>) -> Option<T>`, kann dës Operatioun benotzt ginn fir en `T` aus engem gespéngten `Struct<T>` ze réckelen-dat heescht datt Pinning net strukturell ka sinn fir d'Feld dat hält Donnéeën.
//!
//!     Fir e méi komplext Beispill fir Daten aus engem gepéngten Typ ze réckelen, stellt Iech vir, ob [`RefCell<T>`] eng Method `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>` hätt.
//!     Da kéinte mir folgend maachen:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Dëst ass katastrophal, et heescht datt mir als éischt den Inhalt vum [`RefCell<T>`] (mat `RefCell::get_pin_mut`) kënne pinnen an dann deen Inhalt mat der mutéierter Referenz plënneren, déi mir méi spéit kruten.
//!
//! ## Examples
//!
//! Fir en Typ wéi [`Vec<T>`], sinn zwou Méiglechkeeten (strukturell pinnend oder net) Sënn.
//! E [`Vec<T>`] mat strukturellem Pinning kéint `get_pin`/`get_pin_mut` Methoden hunn fir gespaart Referenzen op Elementer ze kréien.Wéi och ëmmer, et konnt *net* erlaben den [`pop`][Vec::pop] op engem gespéngten [`Vec<T>`] ze ruffen, well dat géif (strukturell festgehal) Inhalter bewegen!Och konnt et [`push`][Vec::push] net erlaben, wat kéint nei ëmallocéieren an domat och den Inhalt réckelen.
//!
//! E [`Vec<T>`] ouni strukturell Pinning kéint `impl<T> Unpin for Vec<T>`, well den Inhalt ni gespaart gëtt an den [`Vec<T>`] selwer ass gutt wéi och geréckelt.
//! Zu dësem Zäitpunkt huet d'Pinn just guer keen Effekt op den vector.
//!
//! An der Standardbibliothéik hunn Zeigentypen normalerweis kee strukturelle Pinning, an doduerch bidden se keng Pinneprojektiounen.Dofir hält `Box<T>: Unpin` fir all `T`.
//! Et mécht Sënn dëst fir Zeigentypen ze maachen, well d `Box<T>` bewegen bewegt net tatsächlech den `T`: den [`Box<T>`] ka fräi beweegbar sinn (aka `Unpin`) och wann den `T` net ass.Tatsächlech souguer [`Pin`]`<`[`Box`] `<T>>`an [`Pin`] `<&mut T>` sinn ëmmer [`Unpin`] selwer, aus demselwechte Grond: hiren Inhalt (den `T`) gëtt festgespaart, awer d'Indikate selwer kënne geréckelt ginn ouni déi agespaart Daten ze réckelen.
//! Fir béid [`Box<T>`] an [`Pin`]`<`[`Box`] `<T>>`, ob den Inhalt ugestréckt ass ass ganz onofhängeg dovun datt de Zeiger ugestréckt ass, dat heescht festzehalen ass *net* strukturell.
//!
//! Wann Dir en [`Future`] Kombinator implementéiert, braucht Dir normalerweis strukturell Pinning fir déi verankert futures, well Dir musst gespaart Referenze kréien fir se [`poll`] ze nennen.
//! Awer wann Äre Kombinator aner Daten enthält déi net gespaart musse ginn, kënnt Dir dës Felder net strukturell maachen an dofir fräi zougänglech mat enger mutéierter Referenz och wann Dir just ["Pin"] "<&mut Selbst>" hutt (sou wéi an Ärer eegener [`poll`] Ëmsetzung).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// E gespaarte Pointer.
///
/// Dëst ass e Wéckel ronderëm eng Aart Zeigefanger déi de Zeiger "pin" säi Wäert op der Plaz mécht, verhënnert datt de Wäert vun deem Zeiger referenzéiert ka geréckelt ginn ausser en [`Unpin`] implementéiert.
///
///
/// *Kuckt d [`pin` module] Dokumentatioun fir eng Erklärung vum Pinning.*
///
/// [`pin` module]: self
///
// Note: d `Clone` ofgeleet ënnendrënner verursaacht Ongläichheet wéi et méiglech ass ëmzesetzen
// `Clone` fir mutéierbar Referenzen.
// Kuckt <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> fir méi Detailer.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Déi folgend Implementatiounen ginn net ofgeleet fir Soundnessprobleemer ze vermeiden.
// `&self.pointer` sollt net zougänglech sinn fir net vertraut trait Implementatiounen.
//
// Kuckt <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> fir méi Detailer.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Bauen en neien `Pin<P>` ronderëm e Zeiger zu e puer Daten vun engem Typ deen [`Unpin`] implementéiert.
    ///
    /// Am Géigesaz zu `Pin::new_unchecked` ass dës Method sécher well de Zeiger `P` Dereferenzen zu engem [`Unpin`] Typ, wat d'Pinngarantien annuléiert.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // SAFETY: de Wäert deen drop higewise gëtt ass `Unpin`, an huet also keng Ufuerderungen
        // ronderëm fänken.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Entwéckelt dësen `Pin<P>` deen de Basisliefer zréckgeet.
    ///
    /// Dëst erfuerdert datt d'Donnéeën an dësem `Pin` [`Unpin`] sinn, sou datt mir déi pinnend Invararianer ignoréiere kënnen wann se auszepaken.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Konstruéiert en neien `Pin<P>` ronderëm eng Referenz zu e puer Daten vun engem Typ deen `Unpin` implementéiere kann oder net.
    ///
    /// Wann `pointer` Dereferenzen zu engem `Unpin` Typ, soll `Pin::new` amplaz benotzt ginn.
    ///
    /// # Safety
    ///
    /// Dëse Konstrukteur ass onsécher well mir kënnen net garantéieren datt d'Donnéeë vun `pointer` uginn, gespaart sinn, dat heescht datt d'Donnéeë net geréckelt ginn oder d'Späichere ongëlteg ginn bis se fale gelooss ginn.
    /// Wann de konstruéierte `Pin<P>` net garantéiert datt d'Donnéeën op déi `P` weist festgespaart sinn, ass dat eng Verletzung vum API Kontrakt a kann zu ondefinéiertem Verhalen a spéidere (safe) Operatiounen féieren.
    ///
    /// Mat dëser Method maacht Dir en promise iwwer d `P::Deref` an `P::DerefMut` Implementatiounen, wa se existéieren.
    /// Dat Wichtegst, si däerfen net aus hiren `self` Argumenter réckelen: `Pin::as_mut` an `Pin::as_ref` ruffe `DerefMut::deref_mut` an `Deref::deref`*op de gespaarte Pointer* un an erwaarden datt dës Methoden déi pinnend Invararianer oprechterhalen.
    /// Ausserdeem, andeems Dir dës Method nennt Dir promise datt d'Referenz `P` Dereferenzen net erëm aus geréckelt ginn;besonnesch, et däerf net méiglech sinn en `&mut P::Target` ze kréien an dann aus där Referenz erauszekommen (zum Beispill [`mem::swap`]).
    ///
    ///
    /// Zum Beispill, den `Pin::new_unchecked` op en `&'a mut T` ze ruffen ass onsécher, well wann Dir et fir déi gegebene Liewensdauer `'a` feste kënnt, hutt Dir keng Kontroll iwwer ob et festgehal gëtt wann d `'a` eriwwer ass:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Dëst sollt heeschen datt de Pointee `a` ni méi réckele kann.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // D'Adress vun der `a` geännert op de Stack vum 'b', sou datt den `a` geplënnert ass, och wa mir et virdru festgemaach hunn!Mir hunn de Pinning API Kontrakt verletzt.
    /////
    /// }
    /// ```
    ///
    /// E Wäert, eemol gespaart, muss fir ëmmer gespaart bleiwen (ausser säin Typ implementéiert `Unpin`).
    ///
    /// Ähnlech wéi `Pin::new_unchecked` op en `Rc<T>` ze ruffen ass onsécher well et Aliasen op déiselwecht Date kënne sinn déi net ënner de Pinning Restriktiounen ënnerleien:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Dëst sollt heeschen datt de Pointee ni méi ka réckelen.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Elo, wann `x` déi eenzeg Referenz war, hu mir eng mutéierbar Referenz op Daten déi mir uewen ofgespaart hunn, déi mir kéinte benotze fir se ze réckelen wéi mir am virege Beispill gesinn hunn.
    ///     // Mir hunn de Pinning API Kontrakt verletzt.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Kritt eng gespaart gedeelt Referenz vun dësem gespaarte Pointer.
    ///
    /// Dëst ass eng generesch Method fir vun `&Pin<Pointer<T>>` op `Pin<&T>` ze goen.
    /// Et ass sécher, well als Deel vum Kontrakt vun `Pin::new_unchecked` kann de Pointee net réckelen nodeems de `Pin<Pointer<T>>` erstallt gouf.
    ///
    /// "Malicious" Implementéierunge vun `Pointer::Deref` sinn och ausgeschloss vum Kontrakt vun `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // SAFETY: kuckt Dokumentatioun iwwer dës Funktioun
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Entwéckelt dësen `Pin<P>` deen de Basisliefer zréckgeet.
    ///
    /// # Safety
    ///
    /// Dës Funktioun ass onsécher.Dir musst garantéieren datt Dir weider de Zeigefanger `P` behandelt wéi ugestréckt nodeems Dir dës Funktioun nennt, sou datt d'Invariante vum `Pin` Typ oprechterhalen.
    /// Wann de Code mat dem resultéierende `P` net weider déi pinnend Invararianer hält, déi eng Verletzung vum API Kontrakt ass a kann zu ondefinéiertem Verhalen a spéidere (safe) Operatiounen féieren.
    ///
    ///
    /// Wann d'Basisdaten [`Unpin`] sinn, sollt [`Pin::into_inner`] amplaz benotzt ginn.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Kritt eng gespaart mutabel Referenz vun dësem gespaarte Pointer.
    ///
    /// Dëst ass eng generesch Method fir vun `&mut Pin<Pointer<T>>` op `Pin<&mut T>` ze goen.
    /// Et ass sécher, well als Deel vum Kontrakt vun `Pin::new_unchecked` kann de Pointee net réckelen nodeems de `Pin<Pointer<T>>` erstallt gouf.
    ///
    /// "Malicious" Implementéierunge vun `Pointer::DerefMut` sinn och ausgeschloss vum Kontrakt vun `Pin::new_unchecked`.
    ///
    /// Dës Method ass nëtzlech wann Dir méi Uriff u Funktioune maacht, déi de festgesaten Typ konsuméieren.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // maach eppes
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` verbraucht `self`, also rembourséiert den `Pin<&mut Self>` iwwer `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // SAFETY: kuckt Dokumentatioun iwwer dës Funktioun
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Weist en neie Wäert fir d'Erënnerung hannert der gespaarte Referenz.
    ///
    /// Dëst iwwerschreift festgehal Daten, awer dat ass an der Rei: säin Destructor gëtt lafen ier en iwwerschriwwe gëtt, also gëtt keng Fanggarantie verletzt.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Baut en neie Pin andeems en den Interieurwäert kartéiert.
    ///
    /// Zum Beispill, wann Dir en `Pin` vun engem Feld vun eppes wëllt kréien, kënnt Dir dëst benotze fir Zougang zu deem Feld an enger Zeil Code ze kréien.
    /// Wéi och ëmmer, et gi verschidde Gotchas mat dësen "pinning projections";
    /// kuckt d [`pin` module] Dokumentatioun fir weider Detailer iwwer dëst Thema.
    ///
    /// # Safety
    ///
    /// Dës Funktioun ass onsécher.
    /// Dir musst garantéieren datt d'Daten déi Dir zréckschéckt net sou laang réckelen wéi den Argumentwäert net réckelt (zum Beispill well et ee vun de Felder vun deem Wäert ass), an och datt Dir net aus dem Argument réckelt deen Dir kritt déi bannenzeg Funktioun.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // SAFETY: de Sécherheetsvertrag fir `new_unchecked` muss sinn
        // vum Uruff oprechterhalen.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Kritt eng gemeinsam Referenz aus engem Pin.
    ///
    /// Dëst ass sécher well et net méiglech ass aus enger gemeinsamer Referenz ze réckelen.
    /// Et ka schéngen wéi wann et en Thema hei mat bannenzeger Verännerlechkeet wier: tatsächlech ass *et* méiglech en `T` aus engem `&RefCell<T>` ze réckelen.
    /// Wéi och ëmmer, dëst ass kee Problem soulaang et net och en `Pin<&T>` existéiert deen op déiselwecht Daten hiweist, an `RefCell<T>` léisst Iech net eng agespaart Referenz op hiren Inhalt kreéieren.
    ///
    /// Kuckt d'Diskussioun op ["pinning projections"] fir weider Detailer.
    ///
    /// Note: `Pin` implementéiert och `Deref` zum Zil, wat benotzt ka ginn fir den banneschte Wäert ze kréien.
    /// Wéi och ëmmer, `Deref` bitt nëmmen eng Referenz déi sou laang liewt wéi de Prêt vum `Pin`, net d'Liewensdauer vum `Pin` selwer.
    /// Dës Method erlaabt d `Pin` zu enger Referenz mat der selwechter Liewensdauer wéi den originale `Pin` ze maachen.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Konvertéiert dësen `Pin<&mut T>` an en `Pin<&T>` mat der selwechter Liewensdauer.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Kritt eng mutéierbar Referenz op d'Daten bannent dësem `Pin`.
    ///
    /// Dëst erfuerdert datt d'Donnéeën an dësem `Pin` `Unpin` sinn.
    ///
    /// Note: `Pin` implementéiert och `DerefMut` op d'Daten, déi benotzt kënne ginn fir den banneschte Wäert ze kréien.
    /// Wéi och ëmmer, `DerefMut` bitt nëmmen eng Referenz déi sou laang liewt wéi de Prêt vum `Pin`, net d'Liewensdauer vum `Pin` selwer.
    ///
    /// Dës Method erlaabt d `Pin` zu enger Referenz mat der selwechter Liewensdauer wéi den originale `Pin` ze maachen.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Kritt eng mutéierbar Referenz op d'Daten bannent dësem `Pin`.
    ///
    /// # Safety
    ///
    /// Dës Funktioun ass onsécher.
    /// Dir musst garantéieren datt Dir d'Daten ni aus der mutéierter Referenz réckelt déi Dir kritt wann Dir dës Funktioun nennt, sou datt d'Invariante vum `Pin` Typ oprechterhalen.
    ///
    ///
    /// Wann d'Basisdaten `Unpin` sinn, sollt `Pin::get_mut` amplaz benotzt ginn.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Konstruéiert en neie Pin andeems Dir den Interieurwäert mappt.
    ///
    /// Zum Beispill, wann Dir en `Pin` vun engem Feld vun eppes wëllt kréien, kënnt Dir dëst benotze fir Zougang zu deem Feld an enger Zeil Code ze kréien.
    /// Wéi och ëmmer, et gi verschidde Gotchas mat dësen "pinning projections";
    /// kuckt d [`pin` module] Dokumentatioun fir weider Detailer iwwer dëst Thema.
    ///
    /// # Safety
    ///
    /// Dës Funktioun ass onsécher.
    /// Dir musst garantéieren datt d'Daten déi Dir zréckschéckt net sou laang réckelen wéi den Argumentwäert net réckelt (zum Beispill well et ee vun de Felder vun deem Wäert ass), an och datt Dir net aus dem Argument réckelt deen Dir kritt déi bannenzeg Funktioun.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // SAFETY: den Uruff ass verantwortlech fir de
        // Wäert aus dëser Referenz.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // SAFETY: well de Wäert vun `this` garantéiert ass net ze hunn
        // eraus geréckelt ginn, dësen Uruff op `new_unchecked` ass sécher.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Kritt eng gespaart Referenz vun enger statescher Referenz.
    ///
    /// Dëst ass sécher, well `T` fir d `'static` Liewensdauer geléint gëtt, wat ni ophält.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // SAFETY: De 'statesche Prêt garantéiert d'Donnéeë sinn net
        // moved/invalidated bis et fale gelooss gëtt (wat ni ass).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Kritt eng gespaart mutabel Referenz vun enger statescher mutabler Referenz.
    ///
    /// Dëst ass sécher, well `T` fir d `'static` Liewensdauer geléint gëtt, wat ni ophält.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // SAFETY: De 'statesche Prêt garantéiert d'Donnéeë sinn net
        // moved/invalidated bis et fale gelooss gëtt (wat ni ass).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: dat heescht datt all Impl vun `CoerceUnsized` dat Zwang erlaabt vun
// en Typ deen `Deref<Target=impl !Unpin>` op en Typ implizéiert deen `Deref<Target=Unpin>` impls ass net gesond.
// All sou Impl wier wuel aus anere Grënn onsënneg, dofir musse mir just oppassen datt esou Imps net an std landen.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}