use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// E Wrapper fir de Compiler ze verhënneren datt den T-Destruktor automatesch nennt.
/// Dëse Wrapper ass 0-Käschten.
///
/// `ManuallyDrop<T>` ass déi selwecht Layout Optimiséierunge wéi `T`.
/// Als Konsequenz huet et *keen Effekt* op d'Annahmen déi de Compiler iwwer säin Inhalt mécht.
/// Zum Beispill d'Initialiséierung vun engem `ManuallyDrop<&mut T>` mat [`mem::zeroed`] ass ondefinéiert Verhalen.
/// Wann Dir oninitialiséiert Daten handhabe musst, benotzt [`MaybeUninit<T>`] statt.
///
/// Bedenkt datt Zougang zum Wäert an engem `ManuallyDrop<T>` sécher ass.
/// Dëst bedeit datt en `ManuallyDrop<T>` deem säin Inhalt erofgefall ass net däerf duerch eng ëffentlech sécher API ausgesat ginn.
/// Entspriechend ass `ManuallyDrop::drop` onsécher.
///
/// # `ManuallyDrop` an drop bestellen.
///
/// Rust huet e gutt definéierten [drop order] vu Wäerter.
/// Fir sécherzestellen datt Felder oder Awunner an enger spezifescher Reiefolleg fale gelooss ginn, réckelt d'Deklaratiounen sou datt déi implizit Drop Bestellung déi richteg ass.
///
/// Et ass méiglech `ManuallyDrop` ze benotzen fir d'Drop Uerdnung ze kontrolléieren, awer dëst erfuerdert onséchere Code an ass schwéier korrekt an der Präsenz vun der Entféierung ze maachen.
///
///
/// Zum Beispill, wann Dir wëllt sécher sinn datt e spezifescht Feld no deenen aneren erofgefall ass, maacht et zum leschte Feld vun engem Struct:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` gëtt no `children` fale gelooss.
///     // Rust garantéiert datt Felder am Optrag vun der Deklaratioun fale gelooss ginn.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Wéckel e Wäert fir manuell erofgefall ze ginn.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Dir kënnt nach ëmmer sécher mat dem Wäert operéieren
    /// assert_eq!(*x, "Hello");
    /// // Awer `Drop` wäert net hei lafen
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Extraitéiert de Wäert aus dem `ManuallyDrop` Container.
    ///
    /// Dëst erlaabt de Wäert erëm erofzesetzen.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Dëst fällt den `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Huelt de Wäert vum `ManuallyDrop<T>` Container eraus.
    ///
    /// Dës Method ass haaptsächlech virgesi fir Wäerter am Drop erauszeginn.
    /// Amplaz [`ManuallyDrop::drop`] ze benotze fir de Wäert manuell ze falen, kënnt Dir dës Method benotze fir de Wäert ze huelen a se awer benotze wéi gewënscht.
    ///
    /// Wann ëmmer méiglech ass et léiwer [`into_inner`][`ManuallyDrop::into_inner`] amplaz ze benotzen, wat verhënnert datt den Inhalt vum `ManuallyDrop<T>` duplizéiert gëtt.
    ///
    ///
    /// # Safety
    ///
    /// Dës Funktioun réckelt semantesch de enthale Wäert eraus ouni weider Benotzung ze verhënneren, de Status vun dësem Container onverännert ze loossen.
    /// Et ass Är Verantwortung ze suergen datt dësen `ManuallyDrop` net erëm benotzt gëtt.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // SAFETY: mir liesen aus enger Referenz, déi garantéiert ass
        // fir valabel ze sinn fir ze liesen.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Manuell fällt de enthale Wäert.Dëst ass exakt entspriechend dem [`ptr::drop_in_place`] mat engem Zeiger zum enthale Wäert ze ruffen.
    /// Als sou, ausser de enthale Wäert e packte Struktur ass, gëtt den Destruktor op der Plaz genannt ouni de Wäert ze bewegen, an domat ka benotzt ginn fir [pinned] Daten sécher ze falen.
    ///
    /// Wann Dir Besëtz vum Wäert hutt, kënnt Dir [`ManuallyDrop::into_inner`] amplaz benotzen.
    ///
    /// # Safety
    ///
    /// Dës Funktioun fiert den Zerstéierer vum enthale Wäert.
    /// Anescht wéi Ännerunge vum Destructor selwer, gëtt d'Erënnerung onverännert gelooss, a sou wäit wéi de Compiler betrëfft hält nach ëmmer e Bitmuster dat fir den Typ `T` gëlteg ass.
    ///
    ///
    /// Wéi och ëmmer, dësen "zombie" Wäert soll net dem séchere Code ausgesat sinn, an dës Funktioun sollt net méi wéi eemol genannt ginn.
    /// Fir e Wäert ze benotzen nodeems e fale gelooss gëtt, oder e Wäert e puermol fale kënnt, kann Undefined Behaviour verursaachen (ofhängeg vun deem wat `drop` mécht).
    /// Dëst gëtt normalerweis vum Type System verhënnert, awer Benotzer vun `ManuallyDrop` mussen dës Garantien halen ouni Hëllef vum Compiler.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // SIKKERHET: mir fale de Wäert drop hin, deen duerch eng mutabel Referenz gezeechent gëtt
        // wat garantéiert gëlteg ass fir schreift.
        // Et ass un den Uruffer fir sécher ze sinn datt `slot` net erëm erofgefall ass.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}