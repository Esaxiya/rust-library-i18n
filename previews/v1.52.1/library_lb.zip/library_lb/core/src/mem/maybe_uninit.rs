use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// E Wéckertyp fir oninitialiséiert Instanze vun `T` ze konstruéieren.
///
/// # Initialiséierung onverännerlech
///
/// De Compiler, am allgemenge, geet dovun aus datt eng Variabel korrekt initialiséiert gëtt no den Ufuerderunge vum Typ vun der Variabel.Zum Beispill, eng Variabel vum Referenztyp muss ausgeriicht sinn an net NULL.
/// Dëst ass en Invariant deen *ëmmer* muss oprechterhalen, och an onsécherem Code.
/// Als Konsequenz verursaacht Nullinitialiséierung vun enger Variabel vum Referenztyp direkt [undefined behavior][ub], egal ob dës Referenz jeemools benotzt gëtt fir op Erënnerung ze kommen:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // ondefinéiert Behuelen!⚠️
/// // Den entspriechende Code mat `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // ondefinéiert Behuelen!⚠️
/// ```
///
/// Dëst gëtt vum Compiler fir verschidde Optimisatiounen ausgenotzt, wéi zum Beispill Eliminatioun vu Run-Time Checks an Optimiséierung vum `enum` Layout.
///
/// Ähnlech kann ganz oninitialiséiert Erënnerung all Inhalt hunn, wärend en `bool` ëmmer `true` oder `false` muss sinn.Dofir ass en oninitialiséierten `bool` ze kreéieren ass ondefinéiert Verhalen:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // ondefinéiert Behuelen!⚠️
/// // Den entspriechende Code mat `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // ondefinéiert Behuelen!⚠️
/// ```
///
/// Ausserdeem ass oninitialiséiert Erënnerung speziell datt et kee feste Wäert huet ("fixed" dat heescht "it won't change without being written to").Déiselwecht oninitialiséiert Byte méi oft ze liesen ka verschidde Resultater ginn.
/// Dëst mécht et ondefinéiert Verhalen oninitialiséiert Daten an enger Variabel ze hunn och wann dës Variabel en ganz Zuelen huet, wat soss all *fix* Bit Muster kann halen:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // ondefinéiert Behuelen!⚠️
/// // Den entspriechende Code mat `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // ondefinéiert Behuelen!⚠️
/// ```
/// (Bedenkt datt d'Regele ronderëm net-initialiséiert Zuelen nach net finaliséiert sinn, awer bis se et sinn, ass et ze roden ze vermeiden.)
///
/// Zousätzlech, erënners datt déi meescht Zorten zousätzlech Invararianen hunn ausser datt se just um Typniveau initialiséiert ginn.
/// Zum Beispill gëtt en '1`-initialiséierte [`Vec<T>`] als initialiséiert betruecht (ënner der aktueller Implementatioun; dëst bedeit keng stabil Garantie) well déi eenzeg Ufuerderung déi de Compiler doriwwer weess ass datt den Datezeiger muss net null sinn.
/// Sou en `Vec<T>` ze kreéieren verursaacht net *direkt* ondefinéiert Verhalen, awer verursaacht ondefinéiert Verhalen mat de meescht sécher Operatiounen (abegraff drop).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` déngt fir onséchere Code z'aktivéieren fir mat net-initialiséierten Daten ëmzegoen.
/// Et ass e Signal fir de Compiler wat beweist datt d'Daten hei *net* initialiséiert kënne ginn:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Erstellt eng explizit net initialiséiert Referenz.
/// // De Compiler weess datt Daten an engem `MaybeUninit<T>` ongëlteg sinn, an dofir ass dat net UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Set et op e gültege Wäert.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Extraitéiert déi initialiséiert Donnéeën-dat ass nëmmen erlaabt *nodeems*`x` richteg initialiséiert gouf!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// De Compiler weess da keng falsch Viraussetzungen oder Optimisatiounen op dësem Code ze maachen.
///
/// Dir kënnt u `MaybeUninit<T>` denken wéi e bësse wéi `Option<T>` awer ouni ee vun der Run-Time Tracking an ouni Sécherheetschecken.
///
/// ## out-pointers
///
/// Dir kënnt `MaybeUninit<T>` benotze fir "out-pointers" z'implementéieren: Amplaz d'Donnéeë vun enger Funktioun zréckzeginn, gitt en Zeigefanger an e puer (uninitialized) Gedächtnis fir d'Resultat anzesetzen.
/// Dëst kann nëtzlech sinn wann et wichteg ass fir den Uruffer ze kontrolléieren wéi d'Erënnerung d'Resultat gespäichert ass kritt zougewisen, an Dir wëllt onnéideg Bewegunge vermeiden.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` fällt den alen Inhalt net erof, wat wichteg ass.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Elo wësse mer datt `v` initialiséiert ass!Dëst mécht och sécher datt den vector richteg erofgesat gëtt.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Initialiséiere vun engem Array Element-by-Element
///
/// `MaybeUninit<T>` ka benotzt ginn fir e grousst Array Element-by-Element ze initialiséieren:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Erstellt en net-initialiséierten Array vun `MaybeUninit`.
///     // Den `assume_init` ass sécher well den Typ dee mir behaapten hei initialiséiert ze hunn ass eng Rëtsch vu "MaybeUninit`s, déi keng Initialiséierung erfuerderen.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // En `MaybeUninit` falen mécht näischt.
///     // Dofir benotzt d'Benotzung vun der rouder Zeigerattribut amplaz `ptr::write` net datt den alen net-initialiséierte Wäert fale gelooss gëtt.
/////
///     // Och wann et en panic wärend dëser Loop ass, hu mir e Memory Leak, awer et gëtt kee Gedächtnis Sécherheetsprobleem.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Alles gëtt initialiséiert.
///     // Transmute d'Array op den initialiséierten Typ.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Dir kënnt och mat deelweis initialiséierte Arrays schaffen, déi a nidderegen Niveau Datastrukture fonnt goufen.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Erstellt en net-initialiséierten Array vun `MaybeUninit`.
/// // Den `assume_init` ass sécher well den Typ dee mir behaapten hei initialiséiert ze hunn ass eng Rëtsch vu "MaybeUninit`s, déi keng Initialiséierung erfuerderen.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Zielt d'Zuel vun Elementer déi mir zougewisen hunn.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Fir all Element an der Array, fale wann mir et zougewisen hunn.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Initialiséiere vun engem Struct Feld fir Feld
///
/// Dir kënnt `MaybeUninit<T>` an den [`std::ptr::addr_of_mut`] Makro benotze fir Structs Feld fir Feld ze initialiséieren:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Initialiséiere vum `name` Feld
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Initialiséiere vum `list` Feld Wann et en panic hei ass, da leeft den `String` am `name` Feld.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // All d'Felder sinn initialiséiert, dofir nenne mir `assume_init` fir en initialiséierte Foo ze kréien.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` ass garantéiert déiselwecht Gréisst, Ausriichtung an ABI wéi `T` ze hunn:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Denkt awer drun datt en Typ *deen* en `MaybeUninit<T>` enthält net onbedéngt dee selwechte Layout ass;Rust garantéiert net allgemeng datt d'Felder vun engem `Foo<T>` déiselwecht Uerdnung hunn wéi en `Foo<U>` och wann `T` an `U` déiselwecht Gréisst an Ausriichtung hunn.
///
/// Ausserdeem well all Bitwäert fir en `MaybeUninit<T>` gëlteg ass, kann de Compiler keng non-zero/niche-filling Optimiséierungen uwenden, wat méiglecherweis zu enger méi grousser Gréisst kënnt:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Wann `T` FFI-sécher ass, dann ass et och `MaybeUninit<T>`.
///
/// Wärend `MaybeUninit` `#[repr(transparent)]` ass (wat bedeit datt et déiselwecht Gréisst, Ausrichtung an ABI als `T` garantéiert), ännert dëst *keng* vun de fréiere Virbehalt.
/// `Option<T>` an `Option<MaybeUninit<T>>` hu vläicht nach verschidde Gréissten, an Typen, déi e Feld vum Typ `T` enthalen, kënnen anescht ausgeluecht ginn (a grouss ginn) wéi wann dat Feld `MaybeUninit<T>` wier.
/// `MaybeUninit` ass e Gewerkschaftstyp, an `#[repr(transparent)]` op Gewerkschaften ass onbestänneg (kuckt [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Mat der Zäit kënnen déi exakt Garantië vun `#[repr(transparent)]` op Gewerkschaften evoluéieren, an `MaybeUninit` kann `#[repr(transparent)]` bleiwen oder net.
/// Dat gesot, `MaybeUninit<T>` wäert *ëmmer* garantéieren datt et déiselwecht Gréisst, Ausrichtung an ABI wéi `T` huet;et ass just datt de Wee wéi `MaybeUninit` dës Garantie implementéiert sech entwéckele kann.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Langt Element sou datt mir aner Zorten dra wéckele kënnen.Dëst ass nëtzlech fir Generatoren.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Net `T::clone()` uruffen, mir kënnen net wëssen ob mir genuch dofir initialiséiert sinn.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Erstellt en neien `MaybeUninit<T>` initialiséiert mat dem gegebene Wäert.
    /// Et ass sécher [`assume_init`] op de Retourwäert vun dëser Funktioun ze ruffen.
    ///
    /// Bedenkt datt en `MaybeUninit<T>` erofzesetzen den Dropcode net "T" nennt.
    /// Et ass Är Verantwortung ze suergen datt `T` fällt wann et initialiséiert gouf.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Erstellt en neien `MaybeUninit<T>` an engem net-initialiséierten Zoustand.
    ///
    /// Bedenkt datt en `MaybeUninit<T>` erofzesetzen den Dropcode net "T" nennt.
    /// Et ass Är Verantwortung ze suergen datt `T` fällt wann et initialiséiert gouf.
    ///
    /// Kuckt d [type-level documentation][MaybeUninit] fir e puer Beispiller.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Erstellt en neit Array vun `MaybeUninit<T>` Artikelen, an engem net initialiséierten Zoustand.
    ///
    /// Note: an enger future Rust Versioun kann dës Method onnéideg ginn wann de wuertwiertleche Syntax [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) erlaabt.
    ///
    /// D'Beispill hei ënnen kéint dann `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` benotzen.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Gitt e (méiglecherweis méi kleng) Stéck Daten déi tatsächlech gelies goufen
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // SAFETY: En net-initialiséierten `[MaybeUninit<_>; LEN]` ass valabel.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Erstellt en neien `MaybeUninit<T>` an engem net-initialiséierten Zoustand, mat der Erënnerung mat `0` Bytes gefëllt.Et hänkt vum `T` of, ob dat scho fir eng richteg Initialiséierung mécht.
    ///
    /// Zum Beispill gëtt `MaybeUninit<usize>::zeroed()` initialiséiert, awer `MaybeUninit<&'static i32>::zeroed()` ass net well Referenzen däerfen net null sinn.
    ///
    /// Bedenkt datt en `MaybeUninit<T>` erofzesetzen den Dropcode net "T" nennt.
    /// Et ass Är Verantwortung ze suergen datt `T` fällt wann et initialiséiert gouf.
    ///
    /// # Example
    ///
    /// Korrekt Benotzung vun dëser Funktioun: Initialiséiere vun engem Struct mat Null, wou all Felder vum Struct d'Bitmuster 0 als valabele Wäert hale kënnen.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Falsch* Benotzung vun dëser Funktioun: `x.zeroed().assume_init()` nennen wann `0` net e gëltege Bitmuster fir den Typ ass:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // An engem Paar kreéiere mir en `NotZero` deen net e gültegen Diskriminant huet.
    /// // Dëst ass ondefinéiert Verhalen.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // SAFETY: `u.as_mut_ptr()` weist op zougewisen Erënnerung.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Setzt de Wäert vun der `MaybeUninit<T>`.
    /// Dëst iwwerschreift all fréiere Wäert ouni et ze falen, also passt op dëst net zweemol ze benotzen ausser Dir wëllt den Destruktor lafen.
    ///
    /// Fir Äert Komfort gëtt dëst och eng mutéierbar Referenz op den (elo sécher initialiséierten) Inhalt vun `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // SAFETY: Mir hunn dëse Wäert just initialiséiert.
        unsafe { self.assume_init_mut() }
    }

    /// Kritt e Zeigefanger op de enthale Wäert.
    /// Liesen vun dësem Zeiger oder en zu enger Referenz maachen ass ondefinéiert Verhalen ausser wann den `MaybeUninit<T>` initialiséiert gëtt.
    /// Schreift an d'Erënnerung datt dësen Zeiger (non-transitively) weist op ass ondefinéiert Verhalen (ausser an engem `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Korrekt Benotzung vun dëser Method:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Erstellt eng Referenz an den `MaybeUninit<T>`.Dëst ass ok well mir hunn et initialiséiert.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Falsch* Benotzung vun dëser Method:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Mir hunn eng Referenz op en net-initialiséierten vector erstallt!Dëst ass ondefinéiert Verhalen.⚠️
    /// ```
    ///
    /// (Bedenkt datt d'Regele ronderëm Referenzen un net initialiséierter Daten nach net finaliséiert sinn, awer bis se sinn, ass et ze recommandéieren se ze vermeiden.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` an `ManuallyDrop` sinn allebéid `repr(transparent)` sou datt mir de Zeigefanger kënne werfen.
        self as *const _ as *const T
    }

    /// Kritt e verännerbaren Zeiger zum enthale Wäert.
    /// Liesen vun dësem Zeiger oder en zu enger Referenz maachen ass ondefinéiert Verhalen ausser wann den `MaybeUninit<T>` initialiséiert gëtt.
    ///
    /// # Examples
    ///
    /// Korrekt Benotzung vun dëser Method:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Erstellt eng Referenz an den `MaybeUninit<Vec<u32>>`.
    /// // Dëst ass ok well mir hunn et initialiséiert.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Falsch* Benotzung vun dëser Method:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Mir hunn eng Referenz op en net-initialiséierten vector erstallt!Dëst ass ondefinéiert Verhalen.⚠️
    /// ```
    ///
    /// (Bedenkt datt d'Regele ronderëm Referenzen un net initialiséierter Daten nach net finaliséiert sinn, awer bis se sinn, ass et ze recommandéieren se ze vermeiden.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` an `ManuallyDrop` sinn allebéid `repr(transparent)` sou datt mir de Zeigefanger kënne werfen.
        self as *mut _ as *mut T
    }

    /// Extraitéiert de Wäert aus dem `MaybeUninit<T>` Container.Dëst ass e super Wee fir ze garantéieren datt d'Donnéeë fale gelooss ginn, well de resultéierende `T` ënner dem gewéinleche Drop Handling ass.
    ///
    /// # Safety
    ///
    /// Et ass un den Uruffer ze garantéieren datt den `MaybeUninit<T>` wierklech an engem initialiséierte Staat ass.Dëst nennen wann den Inhalt nach net komplett initialiséiert ass verursaacht direkt ondefinéiert Verhalen.
    /// Den [type-level documentation][inv] enthält méi Informatioun iwwer dësen Initialiséierungsvarianter.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Zousätzlech, erënners datt déi meescht Zorten zousätzlech Invararianen hunn ausser datt se just um Typniveau initialiséiert ginn.
    /// Zum Beispill gëtt en '1`-initialiséierte [`Vec<T>`] als initialiséiert betruecht (ënner der aktueller Implementatioun; dëst bedeit keng stabil Garantie) well déi eenzeg Ufuerderung déi de Compiler doriwwer weess ass datt den Datezeiger muss net null sinn.
    ///
    /// Sou en `Vec<T>` ze kreéieren verursaacht net *direkt* ondefinéiert Verhalen, awer verursaacht ondefinéiert Verhalen mat de meescht sécher Operatiounen (abegraff drop).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Korrekt Benotzung vun dëser Method:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Falsch* Benotzung vun dëser Method:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` war nach net initialiséiert ginn, sou datt dës lescht Zeil ondefinéiert Verhalen verursaacht huet.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // SAFETY: den Uruff muss garantéieren datt `self` initialiséiert gëtt.
        // Dëst bedeit och datt `self` eng `value` Variant muss sinn.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Liest de Wäert vum `MaybeUninit<T>` Container.De resultéierende `T` ass ënner dem gewéinleche Drop Handling.
    ///
    /// Wann ëmmer méiglech ass et léiwer [`assume_init`] amplaz ze benotzen, wat verhënnert datt den Inhalt vum `MaybeUninit<T>` duplizéiert gëtt.
    ///
    /// # Safety
    ///
    /// Et ass un den Uruffer ze garantéieren datt den `MaybeUninit<T>` wierklech an engem initialiséierte Staat ass.Dëst nennen wann den Inhalt nach net komplett initialiséiert ass verursaacht ondefinéiert Verhalen.
    /// Den [type-level documentation][inv] enthält méi Informatioun iwwer dësen Initialiséierungsvarianter.
    ///
    /// Ausserdeem léisst dëst eng Kopie vun de selwechten Daten hannendrun am `MaybeUninit<T>`.
    /// Wann Dir méi Kopie vun den Daten benotzt (andeems Dir `assume_init_read` méi oft urufft, oder als éischt `assume_init_read` an dann [`assume_init`] urufft), ass et Är Verantwortung ze suergen datt dës Date wierklech duplizéiert kënne ginn.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Korrekt Benotzung vun dëser Method:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` ass `Copy`, also kënne mir méi oft liesen.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // En `None` Wäert duplizéieren ass okay, also kënne mir méi oft liesen.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Falsch* Benotzung vun dëser Method:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Mir hunn elo zwee Exemplare vum selwechte vector erstallt, wat zu engem duebelfrei leading️ féiert wann se allebéid erofgefall sinn!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // SAFETY: den Uruff muss garantéieren datt `self` initialiséiert gëtt.
        // Liesen vun `self.as_ptr()` ass sécher well `self` sollt initialiséiert ginn.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Drops de enthale Wäert op der Plaz.
    ///
    /// Wann Dir Besëtzer vun der `MaybeUninit` hutt, kënnt Dir [`assume_init`] amplaz benotzen.
    ///
    /// # Safety
    ///
    /// Et ass un den Uruffer ze garantéieren datt den `MaybeUninit<T>` wierklech an engem initialiséierte Staat ass.Dëst nennen wann den Inhalt nach net komplett initialiséiert ass verursaacht ondefinéiert Verhalen.
    ///
    /// Ausserdeem mussen all zousätzlech Invararianer vum Typ `T` zefridden sinn, well d `Drop` Ëmsetzung vun `T` (oder seng Memberen) kann drop vertrauen.
    /// Zum Beispill gëtt en '1`-initialiséierte [`Vec<T>`] als initialiséiert betruecht (ënner der aktueller Implementatioun; dëst bedeit keng stabil Garantie) well déi eenzeg Ufuerderung déi de Compiler doriwwer weess ass datt den Datezeiger muss net null sinn.
    ///
    /// Eroplueden sou en `Vec<T>` wäert awer ondefinéiert Verhalen verursaachen.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // SAFETY: den Uruffer muss garantéieren datt `self` initialiséiert gëtt an
        // zefridden all invariants vun `T`.
        // De Wäert op der Plaz fale loossen ass sécher wann dat de Fall ass.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Kritt eng gemeinsam Referenz zum enthale Wäert.
    ///
    /// Dëst kann nëtzlech sinn wa mir op en `MaybeUninit` zougräifen deen initialiséiert gouf awer kee Besëtz vun der `MaybeUninit` (verhënnert d'Benotzung vun `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Dëst ze ruffen wann den Inhalt nach net komplett initialiséiert ass verursaacht ondefinéiert Verhalen: et ass un den Uruffer ze garantéieren datt den `MaybeUninit<T>` wierklech an engem initialiséierte Staat ass.
    ///
    ///
    /// # Examples
    ///
    /// ### Korrekt Benotzung vun dëser Method:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Initialiséiert `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Elo datt eis `MaybeUninit<_>` bekannt ass initialiséiert ze ginn, ass et okay eng gemeinsam Referenz drop ze kreéieren:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // SAFETY: `x` gouf initialiséiert.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Falsch* Utilisatioune vun dëser Method:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Mir hunn eng Referenz op en net-initialiséierten vector erstallt!Dëst ass ondefinéiert Verhalen.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Initialiséiert den `MaybeUninit` mat `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Referenz op en net-initialiséierten `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // SAFETY: den Uruff muss garantéieren datt `self` initialiséiert gëtt.
        // Dëst bedeit och datt `self` eng `value` Variant muss sinn.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Kritt eng mutéierbar (unique) Referenz zum enthale Wäert.
    ///
    /// Dëst kann nëtzlech sinn wa mir op en `MaybeUninit` zougräifen deen initialiséiert gouf awer kee Besëtz vun der `MaybeUninit` (verhënnert d'Benotzung vun `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Dëst ze ruffen wann den Inhalt nach net komplett initialiséiert ass verursaacht ondefinéiert Verhalen: et ass un den Uruffer ze garantéieren datt den `MaybeUninit<T>` wierklech an engem initialiséierte Staat ass.
    /// Zum Beispill kann `.assume_init_mut()` net benotzt ginn fir en `MaybeUninit` initialiséieren.
    ///
    /// # Examples
    ///
    /// ### Korrekt Benotzung vun dëser Method:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Initialiséiert *all* d'Bytes vum Input-Puffer.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Initialiséiert `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Elo wësse mer datt `buf` initialiséiert gouf, also kéinte mer et `.assume_init()` maachen.
    /// // Wéi och ëmmer, mat `.assume_init()` kann en `memcpy` vun den 2048 Bytes ausléisen.
    /// // Fir ze behaapten datt eise Puffer initialiséiert gouf ouni en ze kopéieren, upgrade mir den `&mut MaybeUninit<[u8; 2048]>` op en `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // SAFETY: `buf` gouf initialiséiert.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Elo kënne mir `buf` als normale Scheif benotzen:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Falsch* Utilisatioune vun dëser Method:
    ///
    /// Dir kënnt net `.assume_init_mut()` benotze fir e Wäert initialiséieren:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Mir hunn eng (mutable) Referenz op en net-initialiséierten `bool` erstallt!
    ///     // Dëst ass ondefinéiert Verhalen.⚠️
    /// }
    /// ```
    ///
    /// Zum Beispill kënnt Dir net [`Read`] an en net-initialiséierte Puffer:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) Referenz op net-initialiséiert Erënnerung!
    ///                             // Dëst ass ondefinéiert Verhalen.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Dir kënnt och net direkt Feldzugriff benotze fir Feld fir Feld graduell Initialiséierung ze maachen:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) Referenz op net-initialiséiert Erënnerung!
    ///                  // Dëst ass ondefinéiert Verhalen.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) Referenz op net-initialiséiert Erënnerung!
    ///                  // Dëst ass ondefinéiert Verhalen.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Mir vertrauen de Moment drop datt déi uewe falsch sinn, dh mir hunn Referenzen op net-initialiséiert Daten (z. B. an `libcore/fmt/float.rs`).
    // Mir sollten eng definitiv Entscheedung iwwer d'Reegele virum Stabiliséiere maachen.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // SAFETY: den Uruff muss garantéieren datt `self` initialiséiert gëtt.
        // Dëst bedeit och datt `self` eng `value` Variant muss sinn.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Extraitéiert d'Wäerter aus engem Array vu `MaybeUninit` Container.
    ///
    /// # Safety
    ///
    /// Et ass un den Uruffer ze garantéieren datt all Elementer vum Array an engem initialiséierte Staat sinn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // SAFETY: Elo sécher wéi mir all Elementer initialiséiert hunn
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * De Ruff garantéiert datt all Elementer vum Array initialiséiert ginn
        // * `MaybeUninit<T>` an T si garantéiert de selwechte Layout ze hunn
        // * MaybeUnint fällt net, sou datt et keng Duebelfreie sinn An domat ass d'Konversioun sécher
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Unzehuelen datt all d'Elementer initialiséiert sinn, kritt e Stéck drop.
    ///
    /// # Safety
    ///
    /// Et ass un den Uruffer ze garantéieren datt d `MaybeUninit<T>` Elementer wierklech an engem initialiséierte Staat sinn.
    ///
    /// Dëst nennen wann den Inhalt nach net komplett initialiséiert ass verursaacht ondefinéiert Verhalen.
    ///
    /// Kuckt [`assume_init_ref`] fir méi Detailer a Beispiller.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // SAFETY: e Stéck op en `*const [T]` geheien ass sécher well den Uruffer dat garantéiert
        // `slice` ass initialiséiert, an `MaybeUninit` ass garantéiert dee selwechte Layout wéi `T`.
        // De kritt Zeiger ass valabel well et bezitt sech op e Gedächtnis vum `slice` dat ass eng Referenz an ass also garantéiert gëlteg fir ze liesen.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Unzehuelen datt all d'Elementer initialiséiert sinn, kritt e mutable Stéck hinnen.
    ///
    /// # Safety
    ///
    /// Et ass un den Uruffer ze garantéieren datt d `MaybeUninit<T>` Elementer wierklech an engem initialiséierte Staat sinn.
    ///
    /// Dëst nennen wann den Inhalt nach net komplett initialiséiert ass verursaacht ondefinéiert Verhalen.
    ///
    /// Kuckt [`assume_init_mut`] fir méi Detailer a Beispiller.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // SAFETY: ähnlech wéi Sécherheetsnote fir `slice_get_ref`, awer mir hunn e
        // mutéierbar Referenz déi och garantéiert gëlteg ass fir ze schreiwen.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Kritt e Zeigefanger op dat éischt Element vum Array.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Kritt e verännerbaren Zeiger zum éischten Element vum Array.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Kopéiert d'Elementer vun `src` op `this`, a bréngt eng mutéierbar Referenz op den elo initaliséierten Inhalt vun `this` zréck.
    ///
    /// Wann `T` net `Copy` implementéiert, benotzt [`write_slice_cloned`]
    ///
    /// Dëst ass ähnlech wéi [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Dës Funktioun wäert panic wann déi zwou Scheiwen ënnerschiddlech Längt hunn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SIKKERHET: mir hunn all d'Elementer vu len an déi Ersatzkapazitéit just kopéiert
    /// // déi éischt src.len() Elementer vum Vec sinn elo valabel.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // SAFETY: &[T] an&[MaybeUninit<T>] hunn dee selwechte Layout
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // SAFETY: Gülteg Elementer si just an `this` kopéiert sou datt et initaliséiert gëtt
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Klonéiert d'Elementer vun `src` op `this`, a bréngt eng mutéierbar Referenz op den elo initaliséierten Inhalt vun `this` zréck.
    /// All schonn initaliséiert Elementer ginn net fale gelooss.
    ///
    /// Wann `T` `Copy` implementéiert, benotzt [`write_slice`]
    ///
    /// Dëst ass ähnlech wéi [`slice::clone_from_slice`] awer fällt existent Elementer net erof.
    ///
    /// # Panics
    ///
    /// Dës Funktioun wäert panic wann déi zwou Scheiwen ënnerschiddlech Längt hunn, oder wann d'Ëmsetzung vun `Clone` panics.
    ///
    /// Wann et en panic gëtt, ginn déi scho gekloont Elementer fale gelooss.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SAFETY: mir hunn just all d'Elementer vu Len an d'Sparenkapazitéit gekloont
    /// // déi éischt src.len() Elementer vum Vec sinn elo valabel.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // am Géigesaz zu copy_from_slice heescht dat net clone_from_slice op der Scheif dëst ass well `MaybeUninit<T: Clone>` net Klon implementéiert.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // SAFETY: dës réi Scheif enthält nëmmen initialiséiert Objeten
                // dofir ass et erlaabt et ze falen.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Mir mussen se explizit op d'selwecht Längt schneiden
        // fir d'Grenzkontroll z'elidéieren, an den Optimizer generéiert memcpy fir einfache Fäll (zum Beispill T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // Garde ass gebraucht b/c panic ka während engem Klon geschéien
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // SAFETY: Gëlteg Elementer si just an `this` geschriwwe ginn, sou datt et initaliséiert gëtt
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}