//! Basis Funktiounen fir mam Gedächtnis ëmzegoen.
//!
//! Dëst Modul enthält Funktiounen fir d'Gréisst an d'Ausriichtung vun den Aarten ze froen, Erënnerung initialiséieren a manipuléieren.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Huelt Eegentum an "forgets" iwwer de Wäert **ouni säi Destructor** auszeféieren.
///
/// All Ressourcen, déi de Wäert geréiert, wéi Haapegedächtnis oder e Dateiehandle, bleiwe fir ëmmer an engem net erreechbaren Zoustand.Wéi och ëmmer, et garantéiert net datt Zeigefanger zu dësem Gedächtnis valabel bleiwen.
///
/// * Wann Dir Gedächtnis leckere wëllt, kuckt [`Box::leak`].
/// * Wann Dir e roude Zeiger an d'Erënnerung wëllt kréien, kuckt [`Box::into_raw`].
/// * Wann Dir e Wäert richteg entsuergt wëllt a säi Destructor ausféiert, kuckt [`mem::drop`].
///
/// # Safety
///
/// `forget` ass net als `unsafe` markéiert, well d'Sécherheetsgarantien vum Rust keng Garantie enthalen datt Destruktoren ëmmer lafen.
/// Zum Beispill kann e Programm e Referenzzyklus mat [`Rc`][rc] erstellen, oder den [`process::exit`][exit] uruffen fir auszegoen ouni Destruktoren auszeféieren.
/// Dofir erlaabt d `mem::forget` aus dem séchere Code net de Sécherheetsgarantien vun Rust grondsätzlech z'änneren.
///
/// Dat gesot, Ressourcen wéi Erënnerung oder I/O Objete lecken ass normalerweis onerwënscht.
/// De Bedierfnes kënnt an e puer spezialiséiert Notzungsfäll fir FFI oder onséchere Code op, awer och da gëtt [`ManuallyDrop`] normalerweis bevorzugt.
///
/// Well e Wäert vergiessen erlaabt ass, muss all `unsafe` Code deen Dir schreift fir dës Méiglechkeet erlaben.Dir kënnt kee Wäert zréckschécken an erwaarden datt den Uruff onbedéngt de Destruktor vum Wäert ausféiert.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// De kanonesche séchere Gebrauch vun `mem::forget` ass e Werdestruktor ëmzesetzen, deen vum `Drop` trait implementéiert gëtt.Zum Beispill gëtt dëst en `File`, dh
/// recuperéiert de Raum vun der Variabel, awer schreift nie déi Basis Systemressource zou:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Dëst ass nëtzlech wann d'Besëtzerung vun der ënnerierdescher Ressource virdru op Code ausserhalb vun Rust transferéiert gouf, zum Beispill andeems de roude Dateibeschreiwung op C Code weiderginn ass.
///
/// # Bezéiung mat `ManuallyDrop`
///
/// Wärend `mem::forget` kann och benotzt ginn fir *Gedächtnis* Eegentum ze transferéieren, ass dat falsch ufälleg.
/// [`ManuallyDrop`] soll amplaz benotzt ginn.Betruecht zum Beispill dëse Code:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Baut en `String` mam Inhalt vum `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // leck `v` well säi Gedächtnis elo vun `s` verwalt gëtt
/// mem::forget(v);  // FEELER, v ass ongëlteg an däerf net op eng Funktioun weiderginn
/// assert_eq!(s, "Az");
/// // `s` gëtt implizit fale gelooss a säi Gedächtnis ëmgeleet.
/// ```
///
/// Et ginn zwou Themen mam uewe genannte Beispill:
///
/// * Wa méi Code tëscht dem Bau vun `String` an der Uruffung vun `mem::forget()` derbäigesat gouf, géif en panic dobannen en Duebelfräi verursaachen, well déiselwecht Erënnerung vu `v` an `s` behandelt gëtt.
/// * Nodeems Dir den `v.as_mut_ptr()` urufft an de Besëtz vun den Daten op `s` weiderginn hutt, ass den `v` Wäert ongëlteg.
/// Och wann e Wäert just op `mem::forget` geréckelt gëtt (deen et net kontrolléiert), hunn verschidden Zorten strikt Ufuerderungen un hir Wäerter déi se ongëlteg maachen wann se hänken oder net méi am Besëtz sinn.
/// Ongëlteg Wäerter op iergendeng Aart a Weis ze benotzen, och se weiderzeginn oder se aus Funktiounen zréckzeginn, ass ondefinéiert Verhalen a kann d'Annahmen vum Compiler briechen.
///
/// Wiesselen op `ManuallyDrop` vermeit béid Problemer:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Ier mer `v` a seng rau Deeler ofmontéieren, gitt sécher datt se net fale gelooss gëtt!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Elo `v` ofmontéieren.Dës Operatiounen kënnen net panic sinn, sou datt et kee Leck ka sinn.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Endlech baut en `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` gëtt implizit fale gelooss a säi Gedächtnis ëmgeleet.
/// ```
///
/// `ManuallyDrop` hält robust duebelfrei vir well mir desaktivéieren `v` ier mer eppes anescht maachen.
/// `mem::forget()` erlaabt dëst net well et säin Argument verbraucht, an zwéngt eis et nëmmen ze ruffen nodeems mir alles wat mir aus `v` brauchen extrahéiert.
/// Och wann en panic tëscht dem Bau vun `ManuallyDrop` an dem Bau vun der String agefouert gouf (wat net am Code ka geschéien wéi gewisen), géif et zu engem Leck an net zu engem Duebelfrei féieren.
/// An anere Wierder, `ManuallyDrop` fehlerhaft op der Säit vum Fuite amplaz op der Säit vum (duebelen) erofsetzen.
///
/// Och `ManuallyDrop` verhënnert datt mir op "touch" `v` mussen no der Vermëttlung vum Besëtz op `s`-de leschte Schrëtt fir mat `v` ze interagéieren fir se ze entsuergen ouni säin Destructor ze lafen ass ganz vermeit.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Wéi [`forget`], awer acceptéiert och net grouss Wäerter.
///
/// Dës Funktioun ass just e Shim dee soll ewechgeholl ginn wann d `unsized_locals` Feature stabiliséiert gëtt.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Gitt d'Gréisst vun engem Typ vu Bytes zréck.
///
/// Méi spezifesch ass dëst den Offset a Bytes tëscht successive Elementer an engem Array mat deem Artikeltyp inklusive Ausriichtungspadding.
///
/// Also, fir all Typ `T` a Längt `n`, huet `[T; n]` eng Gréisst vun `n * size_of::<T>()`.
///
/// Am Allgemengen ass d'Gréisst vun engem Typ net stabil iwwer Kompilatiounen, awer spezifesch Aarte wéi Primitiven sinn.
///
/// Déi folgend Tabell gëtt d'Gréisst fir Primitiven.
///
/// Typ |Gréisst_vun: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 Char |4
///
/// Ausserdeem hunn `usize` an `isize` déiselwecht Gréisst.
///
/// D'Typen `*const T`, `&T`, `Box<T>`, `Option<&T>` an `Option<Box<T>>` hunn all déiselwecht Gréisst.
/// Wann `T` Gréisst ass, hunn all dës Zorten déiselwecht Gréisst wéi `usize`.
///
/// D'Mutabilitéit vun engem Zeiger ännert net seng Gréisst.Als sou hunn `&T` an `&mut T` déiselwecht Gréisst.
/// Och fir `*const T` an `* mut T`.
///
/// # Gréisst vun `#[repr(C)]` Artikelen
///
/// D `C` Representatioun fir Artikelen huet e definéierte Layout.
/// Mat dësem Layout ass d'Gréisst vun Artikelen och stabil soulaang all Felder eng stabil Gréisst hunn.
///
/// ## Gréisst vun Structs
///
/// Fir `structs` gëtt d'Gréisst vum folgenden Algorithmus bestëmmt.
///
/// Fir all Feld am Struktur bestallt duerch Deklaratiounsuerdnung:
///
/// 1. Füügt d'Gréisst vum Feld derbäi.
/// 2. Ronn déi aktuell Gréisst op déi nooste Multiple vum [alignment] vum nächste Feld.
///
/// Schlussendlech ronderëm d'Gréisst vum Struct zum nooste Multiple vu sengem [alignment].
/// D'Ausriichtung vum Struct ass normalerweis déi gréissten Ausriichtung vun all senge Felder;dëst ka mat der Benotzung vun `repr(align(N))` geännert ginn.
///
/// Am Géigesaz zu `C` sinn Nullgréisst Structs net bis zu engem Byte an der Gréisst gerundet.
///
/// ## Gréisst vun Enums
///
/// Enums déi keng aner Date wéi den Diskriminant hunn, hunn déiselwecht Gréisst wéi C enums op der Plattform fir déi se zesummegestallt sinn.
///
/// ## Gréisst vun de Gewerkschaften
///
/// D'Gréisst vun enger Gewerkschaft ass d'Gréisst vun hirem gréisste Feld.
///
/// Am Géigesaz zum `C` sinn d'Gewerkschafte mat Null net bis zu engem Byte an der Gréisst ofgeronnt.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // E puer Primitiven
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // E puer Arrays
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Uweiser Gréisst Gläichheet
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// `#[repr(C)]` benotzen.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // D'Gréisst vum éischte Feld ass 1, also füügt 1 zu der Gréisst bäi.Gréisst ass 1.
/// // D'Ausriichtung vum zweete Feld ass 2, also füügt 1 zu der Gréisst fir Padding bäi.Gréisst ass 2.
/// // D'Gréisst vum zweete Feld ass 2, also füügt 2 der Gréisst bäi.Gréisst ass 4.
/// // D'Ausriichtung vum drëtte Feld ass 1, also füügt 0 zu der Gréisst fir Padding bäi.Gréisst ass 4.
/// // D'Gréisst vum drëtte Feld ass 1, also füügt 1 zu der Gréisst bäi.Gréisst ass 5.
/// // Schlussendlech ass d'Ausriichtung vum Struct 2 (well déi gréissten Ausriichtung tëscht senge Felder 2 ass), füügt also 1 zu der Gréisst fir Padding bäi.
/// // Gréisst ass 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tupel Strucken befollegen déi selwecht Regelen.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Bedenkt datt d'Felder nei bestellen d'Gréisst erofsetze kann.
/// // Mir kënne béid Padding Bytes erofhuelen andeems mir `third` virum `second` setzen.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Uniounsgréisst ass d'Gréisst vum gréisste Feld.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Gitt d'Gréisst vum gezeechente Wäert a Bytes zréck.
///
/// Dëst ass normalerweis d'selwecht wéi `size_of::<T>()`.
/// Wéi och ëmmer, wann `T` * keng statesch bekannte Gréisst huet, zB e Stéck [`[T]`][slice] oder en [trait object], da kann `size_of_val` benotzt ginn fir déi dynamesch bekannt Gréisst ze kréien.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // SAFETY: `val` ass eng Referenz, also ass et e gültege roude Zeiger
    unsafe { intrinsics::size_of_val(val) }
}

/// Gitt d'Gréisst vum gezeechente Wäert a Bytes zréck.
///
/// Dëst ass normalerweis d'selwecht wéi `size_of::<T>()`.Wéi och ëmmer, wann `T` * keng statesch bekannte Gréisst huet, zB e Stéck [`[T]`][slice] oder eng [trait object], da kann `size_of_val_raw` benotzt ginn fir déi dynamesch bekannt Gréisst ze kréien.
///
/// # Safety
///
/// Dës Funktioun ass nëmme sécher ze ruffen wann déi folgend Konditioune festhalen:
///
/// - Wann `T` `Sized` ass, ass dës Funktioun ëmmer sécher ze ruffen.
/// - Wann den onsize Schwanz vun `T` ass:
///     - e [slice], da muss d'Längt vum Scheifschwanz eng initialiséiert ganz Zuel sinn, an d'Gréisst vum *ganze Wäert*(dynamesch Schwanzlängt + statesch Gréisst Präfix) muss an `isize` passen.
///     - e [trait object], da muss de vtabelen Deel vum Zeiger op eng gëlteg vtabel weisen, déi vun engem onsizeierenden Zwang kritt ass, an d'Gréisst vum *ganze Wäert*(dynamesch Schwanzlängt + statesch Gréisst Präfix) muss an `isize` passen.
///
///     - en (unstable) [extern type], dann ass dës Funktioun ëmmer sécher ze ruffen, awer kann panic oder soss de falsche Wäert zréckginn, well de Layout vum externen Typ net bekannt ass.
///     Dëst ass datselwecht Verhalen wéi [`size_of_val`] op eng Referenz zu engem Typ mat engem externen Typ Schwanz.
///     - soss ass et konservativ net erlaabt dës Funktioun ze nennen.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SIKKERHET: den Uruffer muss e gültege roude Zeiger ubidden
    unsafe { intrinsics::size_of_val(val) }
}

/// Retourns déi [ABI] erfuerdert Mindestausrichtung vun engem Typ.
///
/// All Referenz zu engem Wäert vum Typ `T` muss e Multiple vun dëser Zuel sinn.
///
/// Dëst ass d'Ausriichtung fir Strukturfelder benotzt.Et ka méi kleng si wéi déi bevorzugt Ausriichtung.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Retourns déi [ABI] erfuerdert Mindestausrichtung vun der Aart vum Wäert op deen `val` weist.
///
/// All Referenz zu engem Wäert vum Typ `T` muss e Multiple vun dëser Zuel sinn.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // SAFETY: val ass eng Referenz, also ass et e gültege roude Zeiger
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Retourns déi [ABI] erfuerdert Mindestausrichtung vun engem Typ.
///
/// All Referenz zu engem Wäert vum Typ `T` muss e Multiple vun dëser Zuel sinn.
///
/// Dëst ass d'Ausriichtung fir Strukturfelder benotzt.Et ka méi kleng si wéi déi bevorzugt Ausriichtung.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Retourns déi [ABI] erfuerdert Mindestausrichtung vun der Aart vum Wäert op deen `val` weist.
///
/// All Referenz zu engem Wäert vum Typ `T` muss e Multiple vun dëser Zuel sinn.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // SAFETY: val ass eng Referenz, also ass et e gültege roude Zeiger
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Retourns déi [ABI] erfuerdert Mindestausrichtung vun der Aart vum Wäert op deen `val` weist.
///
/// All Referenz zu engem Wäert vum Typ `T` muss e Multiple vun dëser Zuel sinn.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Dës Funktioun ass nëmme sécher ze ruffen wann déi folgend Konditioune festhalen:
///
/// - Wann `T` `Sized` ass, ass dës Funktioun ëmmer sécher ze ruffen.
/// - Wann den onsize Schwanz vun `T` ass:
///     - e [slice], da muss d'Längt vum Scheifschwanz eng initialiséiert ganz Zuel sinn, an d'Gréisst vum *ganze Wäert*(dynamesch Schwanzlängt + statesch Gréisst Präfix) muss an `isize` passen.
///     - e [trait object], da muss de vtabelen Deel vum Zeiger op eng gëlteg vtabel weisen, déi vun engem onsizeierenden Zwang kritt ass, an d'Gréisst vum *ganze Wäert*(dynamesch Schwanzlängt + statesch Gréisst Präfix) muss an `isize` passen.
///
///     - en (unstable) [extern type], dann ass dës Funktioun ëmmer sécher ze ruffen, awer kann panic oder soss de falsche Wäert zréckginn, well de Layout vum externen Typ net bekannt ass.
///     Dëst ass datselwecht Verhalen wéi [`align_of_val`] op eng Referenz zu engem Typ mat engem externen Typ Schwanz.
///     - soss ass et konservativ net erlaabt dës Funktioun ze nennen.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SIKKERHET: den Uruffer muss e gültege roude Zeiger ubidden
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Gitt `true` zréck wann d'Wäerter vum Typ `T` falen.
///
/// Dëst ass reng en Optimiséierungs Hiweis a kann konservativ implementéiert ginn:
/// et kann `true` zréckginn fir Typen déi net tatsächlech fale mussen.
/// Als sou ëmmer `true` zréck wier eng valabel Ëmsetzung vun dëser Funktioun.Awer wann dës Funktioun tatsächlech `false` zréckkënnt, da kënnt Dir sécher sinn datt den `T` keen Nieweneffekt huet.
///
/// Implementéierungen op nidderegen Niveau vu Saache wéi Sammlungen, déi hir Donnéeë manuell fale mussen, sollten dës Funktioun benotzen fir ze vermeiden onnéideg ze probéieren all hiren Inhalt erofzesetzen, wa se zerstéiert ginn.
///
/// Dëst kéint keen Ënnerscheed an de Release-Builds maachen (wou eng Loop déi keng Niewewierkungen huet einfach festgestallt an eliminéiert gëtt), awer ass dacks e grousse Gewënn fir Debug-Builds.
///
/// Bedenkt datt [`drop_in_place`] dëse Scheck scho mécht, also wann Är Aarbechtspensioun op e puer kleng Zuel vun [`drop_in_place`] Uriff reduzéiert ka ginn, ass dat net néideg.
/// Besonnesch bemierkt datt Dir e Stéck [`drop_in_place`] kënnt, an dat mécht een eenzege Besoensdrop Kontroll fir all d'Wäerter.
///
/// Typen wéi Vec dofir just `drop_in_place(&mut self[..])` ouni `needs_drop` explizit ze benotzen.
/// Typen wéi [`HashMap`], op der anerer Säit, musse Wäerter gläichzäiteg fale loossen a sollten dës API benotzen.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Hei ass e Beispill wéi eng Sammlung den `needs_drop` benotze kann:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // fale d'Daten
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Nees de Wäert vum Typ `T` representéiert vum All-Null Byte Muster.
///
/// Dëst bedeit datt zum Beispill de Paddingbyte am `(u8, u16)` net onbedéngt null ass.
///
/// Et gëtt keng Garantie datt en All-Null Byte-Muster e gültege Wäert vun iergendengem Typ `T` duerstellt.
/// Zum Beispill ass den All-Null-Byte-Muster net e gültege Wäert fir Referenztypen (`&T`, `&mut T`) a Funktiounsweiser.
/// `zeroed` op sou Aarte benotzt verursaacht direkt [undefined behavior][ub] well [the Rust compiler assumes][inv] datt et ëmmer e gültege Wäert an enger Variabel ass déi se als initialiséiert betruecht.
///
///
/// Dëst huet déiselwecht Wierkung wéi [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Et ass nëtzlech fir FFI heiansdo, awer sollt allgemeng vermeit ginn.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Korrekt Benotzung vun dëser Funktioun: eng ganz Zuel mat Null initialiséieren.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Falsch* Benotze vun dëser Funktioun: Initialiséiere vun enger Referenz mat Null.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Onbestëmmt Behuelen!
/// let _y: fn() = unsafe { mem::zeroed() }; // An nach eng Kéier!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // SAFETY: den Uruffer muss garantéieren datt en all-null Wäert fir `T` gëlteg ass.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Bypasses Rust's normale Gedächtnisinitialiséierungskontrollen andeems se sech virmaachen e Wäert vum Typ `T` ze produzéieren, wärend se guer näischt maachen.
///
/// **Dës Funktioun gëtt entfouert.** Benotzt amplaz [`MaybeUninit<T>`].
///
/// De Grond fir Entféierung ass datt d'Funktioun am Fong net richteg ka benotzt ginn: et huet dee selwechten Effekt wéi [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Wéi den [`assume_init` documentation][assume_init] erkläert, ass [the Rust compiler assumes][inv] déi Wäerter richteg initialiséiert.
/// Als Konsequenz, ruffen z
/// `mem::uninitialized::<bool>()` verursaacht direkt ondefinéiert Verhalen fir en `bool` zréckzekommen, deen net definitiv entweder `true` oder `false` ass.
/// Méi schlëmm, wierklech oninitialiséiert Erënnerung wéi dat wat hei zréck kënnt ass speziell, well de Compiler weess datt et kee feste Wäert huet.
/// Dëst mécht et ondefinéiert Verhalen oninitialiséiert Daten an enger Variabel ze hunn och wann dës Variabel en ganz Zuelen huet.
/// (Bedenkt datt d'Regele ronderëm net-initialiséiert Zuelen nach net finaliséiert sinn, awer bis se et sinn, ass et ze roden ze vermeiden.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // SAFETY: den Uruffer muss garantéieren datt en unitiséierte Wäert fir `T` gëlteg ass.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Tauscht d'Wäerter op zwou mutéierbare Plazen of, ouni een ze deinitialiséieren.
///
/// * Wann Dir mat engem Standard-oder Dummy-Wäert tausche wëllt, kuckt [`take`].
/// * Wann Dir mat engem passéierte Wäert austausche wëllt, den alen Wäert zréckbréngt, kuckt [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // SIKKERHET: déi réi Zeechner goufen aus sécherem mutabele Referenzen erstallt, déi all
    // Aschränkungen op `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Ersetzt `dest` mam Standardwäert vun `T`, zréckgëtt de fréiere `dest` Wäert.
///
/// * Wann Dir d'Wäerter vun zwou Variablen ersetze wëllt, kuckt [`swap`].
/// * Wann Dir mat engem passéierte Wäert amplaz vum Standardwert ersetze wëllt, kuckt [`replace`].
///
/// # Examples
///
/// En einfacht Beispill:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` erlaabt d'Besëtz vun engem Struct Feld ze huelen andeems en duerch en "empty" Wäert ersat gëtt.
/// Ouni `take` kënnt Dir op Problemer wéi dës lafen:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Bedenkt datt `T` net onbedéngt [`Clone`] implementéiert, sou datt et net mol `self.buf` klone kann a reset.
/// Awer `take` kann benotzt ginn fir den urspréngleche Wäert vun `self.buf` vum `self` z'associéieren, sou datt et zréck kënnt:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Beweegt `src` an de referenzéierten `dest`, an de fréiere `dest` Wäert zréck.
///
/// Weder Wäert gëtt gefall.
///
/// * Wann Dir d'Wäerter vun zwou Variablen ersetze wëllt, kuckt [`swap`].
/// * Wann Dir mat engem Standardwert ersetze wëllt, kuckt [`take`].
///
/// # Examples
///
/// En einfacht Beispill:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` erlaabt de Verbrauch vun engem Struct Feld andeems en en anere Wäert ersetzt.
/// Ouni `replace` kënnt Dir op Problemer wéi dës lafen:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Bedenkt datt `T` net onbedéngt [`Clone`] implementéiert, also kënne mir net mol `self.buf[i]` klonen fir de Wee ze vermeiden.
/// Awer `replace` kann benotzt ginn fir den urspréngleche Wäert op dësem Index vun `self` ze desassociéieren, sou datt et zréck kënnt:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // SAFETY: Mir liesen vun `dest` awer schreiwen direkt `src` dran,
    // sou datt den ale Wäert net duplizéiert gëtt.
    // Näischt fällt an näischt hei kann panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Entsuergt e Wäert.
///
/// Dëst mécht dëst andeems d'Argument d'Ëmsetzung vun [`Drop`][drop] genannt gëtt.
///
/// Dëst mécht effektiv näischt fir Typen déi `Copy` implementéieren, z
/// integers.
/// Esou Wäerter ginn kopéiert an _then_ an d'Funktioun geréckelt, sou datt de Wäert no dësem Funktiounsopruff bestoe bleift.
///
///
/// Dës Funktioun ass net magesch;et ass wuertwiertlech definéiert als
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Well `_x` an d'Funktioun geréckelt gëtt, gëtt se automatesch fale gelooss ier d'Funktioun zréckgeet.
///
/// [drop]: Drop
///
/// # Examples
///
/// Basis Benotzung:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // explizit den vector falen
/// ```
///
/// Well [`RefCell`] d'Léintregele bei der Runtime duerchféiert, kann `drop` en [`RefCell`] Prêt fräilooss:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // de mutable Prêt op dësem Slot ofginn
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Ganzzuelen an aner Zorten, déi [`Copy`] implementéieren, sinn net beaflosst vun `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // eng Kopie vun `x` gëtt geréckelt a fale gelooss
/// drop(y); // eng Kopie vun `y` gëtt geréckelt a fale gelooss
///
/// println!("x: {}, y: {}", x, y.0); // nach verfügbar
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Interpretéiert `src` als Typ `&U`, a liest dann `src` ouni de enthale Wäert ze bewegen.
///
/// Dës Funktioun wäert onsécher dovun ausgoen datt den Zeiger `src` fir [`size_of::<U>`][size_of] Bytes gëlteg ass andeems en `&T` op `&U` transmutéiert an duerno den `&U` gelies gëtt (ausser datt dëst op eng Manéier gemaach gëtt déi richteg ass och wann `&U` méi streng Ausriichtungsufuerderunge mécht wéi `&T`).
/// Et wäert och onsécher eng Kopie vum enthale Wäert kreéieren anstatt aus `src` erauszekommen.
///
/// Et ass net e Kompiléierungsfehler wann `T` an `U` verschidde Gréissten hunn, awer et ass héich encouragéiert dës Funktioun nëmmen unzegoen wou `T` an `U` déiselwecht Gréisst hunn.Dës Funktioun ausléist [undefined behavior][ub] wann `U` méi grouss ass wéi `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Kopéiert d'Donnéeë vum 'foo_array' a behandelt se als 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Ännert déi kopéiert Date
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Den Inhalt vun 'foo_array' sollt net geännert hunn
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Wann U eng méi héich Ausriichtungsufuerderung huet, kann src net passend ausgeriicht sinn.
    if align_of::<U>() > align_of::<T>() {
        // SAFETY: `src` ass eng Referenz déi garantéiert gëlteg ass fir ze liesen.
        // Den Uruffer muss garantéieren datt déi aktuell Transmutatioun sécher ass.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // SAFETY: `src` ass eng Referenz déi garantéiert gëlteg ass fir ze liesen.
        // Mir hu just kontrolléiert datt `src as *const U` richteg ausgeriicht war.
        // Den Uruffer muss garantéieren datt déi aktuell Transmutatioun sécher ass.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Opaken Typ deen den Diskriminant vun engem Enum duerstellt.
///
/// Kuckt d [`discriminant`] Funktioun an dësem Modul fir méi Informatioun.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Dës trait Implementéierungen kënnen net ofgeleet ginn well mir keng Grenzen op T wëllen.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Gitt e Wäert deen eenzegaarteg d'Enum Variant am `v` identifizéiert.
///
/// Wann `T` net enum ass, wäert dës Funktioun uruffen net zu ondefinéiertem Verhalen resultéieren, awer de Retourwäert ass net spezifizéiert.
///
///
/// # Stability
///
/// Den Diskriminant vun enger Enum Variant ka sech änneren wann d'Enum Definitioun ännert.
/// En Diskriminant vun enger Variant ännert sech net tëscht Compilatiounen mam selwechte Compiler.
///
/// # Examples
///
/// Dëst kann benotzt ginn fir Enumer ze vergläichen déi Daten droen, wärend Dir déi aktuell Donnéeën ignoréiert:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Gitt d'Zuel vun de Varianten am Enum Typ `T` zréck.
///
/// Wann `T` net enum ass, wäert dës Funktioun uruffen net zu ondefinéiertem Verhalen resultéieren, awer de Retourwäert ass net spezifizéiert.
/// Och wann `T` en Enum mat méi Varianten ass wéi `usize::MAX` ass de Retourwäert net spezifizéiert.
/// Onbewunnte Varianten ginn gezielt.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}