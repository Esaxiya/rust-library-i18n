//! Utilities fir ze formatéieren an Drécker ze drécken.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// Méiglech Ausriichtungen zréck vun `Formatter::align`
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Indikatioun datt Inhalter lénks ausgeriicht solle sinn.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Indikatioun datt Inhalter sollten ausgeriicht sinn.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Indikatioun datt Inhalter sollten zentral ausgeriicht sinn.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// Den Typ gëtt mat Formatéiermethoden zréckginn.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// De Feelertyp dee vum Formatéiere vun enger Noriicht an e Stream zréckkommt.
///
/// Dësen Typ ënnerstëtzt keng Iwwerdroung vun engem anere Feeler wéi datt e Feeler geschitt ass.
/// All extra Informatioun muss arrangéiert ginn fir iwwer aner Weeër ze weiderginn.
///
/// Eng wichteg Saach ze vergiessen ass datt den Typ `fmt::Error` net mat [`std::io::Error`] oder [`std::error::Error`] verwiesselt sollt ginn, wat Dir och am Ëmfang hutt.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// En trait fir ze schreiwen oder ze formatéieren an Unicode-akzeptéierend Puffer oder Stréimungen.
///
/// Dësen trait acceptéiert nëmmen UTF-8-kodéiert Daten an ass net [flushable].
/// Wann Dir nëmmen Unicode akzeptéiere wëllt an Dir braucht net ze spullen, sollt Dir dësen trait implementéieren;
/// soss sollt Dir [`std::io::Write`] implementéieren.
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// Schreift e Stringschnitt an dëse Schrëftsteller, zréckgoen ob d'Schreiwe gelongen ass.
    ///
    /// Dës Method kann nëmmen erfollegräich sinn wann de ganze String Slice erfollegräich geschriwwe gouf, an dës Method kënnt net zréck bis all d'Donnéeë geschriwwe sinn oder e Feeler geschitt.
    ///
    ///
    /// # Errors
    ///
    /// Dës Funktioun gëtt eng Instanz vun [`Error`] op Feeler zréck.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// Schreift en [`char`] an dëse Schrëftsteller, zréckgoen ob d'Schreiwe gelongen ass.
    ///
    /// Eng eenzeg [`char`] kann als méi wéi ee Byte kodéiert sinn.
    /// Dës Method kann nëmme geléngen, wann déi ganz Byte-Sequenz erfollegräich geschriwwe gouf, an dës Method kënnt net zréck bis all d'Donnéeë geschriwwe sinn oder e Feeler geschitt.
    ///
    ///
    /// # Errors
    ///
    /// Dës Funktioun gëtt eng Instanz vun [`Error`] op Feeler zréck.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// Pech fir d'Benotzung vum [`write!`] Macro mat Implementateure vun dësem trait.
    ///
    /// Dës Method soll normalerweis net manuell ugeruff ginn, mä éischter duerch den [`write!`] Macro selwer.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// Konfiguratioun fir Formatéieren.
///
/// A `Formatter` representéiert verschidden Optiounen am Zesummenhang mat Formatéierung.
/// D'Benotzer konstruéiere net `Formatter`s direkt;eng mutéierbar Referenz zu engem gëtt op d `fmt` Method vun all Formatéierung traits weiderginn, wéi [`Debug`] an [`Display`].
///
///
/// Fir mat engem `Formatter` ze interagéieren, rufft Dir verschidde Methoden fir déi verschidde Optiounen am Zesummenhang mat Formatéierung z'änneren.
/// Fir Beispiller kuckt w.e.g. d'Dokumentatioun vun de Methoden, déi op `Formatter` definéiert sinn.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// Argument ass wesentlech eng optiméiert deelweis applizéiert Formatéierungsfunktioun, entspriechend `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result`.

extern "C" {
    type Opaque;
}

/// Dëse Struktur stellt de generesche "argument" duer, dee vun der Xprintf Famill vu Funktioune geholl gëtt.Et enthält eng Funktioun fir de gegebene Wäert ze formatéieren.
/// Zu der Kompiléierungszäit ass garantéiert datt d'Funktioun an de Wäert déi richteg Typen hunn, an da gëtt dëse Struct benotzt fir Argumenter zu engem Typ ze kanonikaliséieren.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// Dëst garantéiert een eenzege stabile Wäert fir de Funktiounszeiger deen mam indices/counts an der Formatéierungsinfrastruktur assoziéiert ass.
//
// Bedenkt datt eng Funktioun als sou definéiert net korrekt wier wéi d'Funktiounen ëmmer onbenannt_addr mat der aktueller Senkung op LLVM IR markéiert sinn, sou datt hir Adress net als wichteg fir LLVM ugesi gëtt a wéi esou den as_usize Besetzung kéint falsch kompiléiert ginn.
//
// An der Praxis ruffe mir ni as_usize op net benotzbar Daten mat (als Matière vun der statescher Generatioun vun de Formatéierungsargumenter), also ass dat nëmmen en zousätzleche Scheck.
//
// Mir wëllen haaptsächlech sécherstellen datt de Funktiounszeiger bei `USIZE_MARKER` eng Adress huet déi *nëmmen* entsprécht fir Funktiounen déi och `&usize` als éischt Argument huelen.
// De read_volatile hei garantéiert datt mir e Usize vun der passéierter Referenz sécher kënne prett maachen an datt dës Adress net op eng net benotzbar Funktioun weist.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // SAFETY: ptr ass eng Referenz
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // SAFETY: `mem::transmute(x)` ass sécher well
        //     1. `&'b T` hält d'Liewensdauer, déi se mat `'b` entstanen ass (fir keng onbegrenzte Liewensdauer ze hunn)
        //     2.
        //     `&'b T` an `&'b Opaque` hunn déiselwecht Memory Layout (wann `T` `Sized` ass, wéi et hei ass) `mem::transmute(f)` ass sécher well `fn(&T, &mut Formatter<'_>) -> Result` an `fn(&Opaque, &mut Formatter<'_>) -> Result` déiselwecht ABI hunn (soulaang `T` `Sized` ass)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // SAFETY: Den `formatter` Feld ass nëmmen op USIZE_MARKER gesat wann
            // de Wäert ass e Gebrauch, also ass dat sécher
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// Fändelen verfügbar am v1 Format vun format_args
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// Wann Dir de Format_args! () Macro benotzt, gëtt dës Funktioun benotzt fir d'Argumenter Struktur ze generéieren.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// Dës Funktioun gëtt benotzt fir net-Standard Formatéierungsparameteren ze spezifizéieren.
    /// De `pieces` Array muss op d'mannst esou laang sinn wéi den `fmt` fir eng gëlteg Argumenterstruktur ze bauen.
    /// Och all `Count` bannent `fmt` dat `CountIsParam` oder `CountIsNextParam` ass, muss op en Argument hiweisen dat mam `argumentusize` erstallt gouf.
    ///
    /// Wéi och ëmmer, dat net ze verursaache keng Onsécherheet, awer ignoréiert ongëlteg.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// Schätzt d'Längt vum formatéierten Text.
    ///
    /// Dëst soll fir d'Astellung vun der éischter `String` Kapazitéit benotzt ginn wann Dir `format!` benotzt.
    /// Note: dëst ass weder déi ënnescht nach déi iewescht Grenz.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // Wann d'Formatstreng mat engem Argument ufänkt, preallocéiert näischt, ausser d'Längt vu Stécker ass bedeitend.
            //
            //
            0
        } else {
            // Et ginn e puer Argumenter, sou datt all zousätzlech Push de String nei verdeelt.
            //
            // Fir dat ze vermeiden, si mir d "pre-doubling" d'Kapazitéit hei.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// Dës Struktur stellt eng sécher viraus kompiléiert Versioun vun engem Format String a sengen Argumenter duer.
/// Dëst kann net bei der Runtime generéiert ginn well et net sécher ka gemaach ginn, dofir gi keng Konstruktoren uginn an d'Felder si privat fir d'Verännerung ze vermeiden.
///
///
/// Den [`format_args!`] Macro wäert sécher eng Instanz vun dëser Struktur erstellen.
/// De Macro validéiert d'Formatstreng bei der Kompiléierzäit sou datt d'Benotzung vun den [`write()`] an [`format()`] Funktioune sécher duerchgefouert ka ginn.
///
/// Dir kënnt den `Arguments<'a>` benotzen deen [`format_args!`] an `Debug` an `Display` Kontexter zréckkënnt wéi hei ënnendrënner.
/// D'Beispill weist och datt `Debug` an `Display` Format op déiselwecht Saach: déi interpoléiert Format String an `format_args!`.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // Formatéiert Stringstécker fir ze drécken.
    pieces: &'a [&'static str],

    // Plazhaler Spezifikatiounen, oder `None` wann all Spezifikatioune Standard sinn (wéi an "{}{}").
    fmt: Option<&'a [rt::v1::Argument]>,

    // Dynamesch Argumenter fir Interpolatioun, mat Sträichstécker interleaved ze ginn.
    // (All Argument gëtt mat engem Stringstéck virgeluecht.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// Kritt de formatéierte String, wann et keng Argumenter huet fir ze formatéieren.
    ///
    /// Dëst kann benotzt ginn fir Allocatiounen am trivialsten Fall ze vermeiden.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` sollt d'Ausgab an engem Programméierer konfrontéieren, Debuggen Kontext formatéieren.
///
/// Allgemeng sollt Dir just `derive` eng `Debug` Ëmsetzung maachen.
///
/// Wann et mam alternativen Format Spezifizéierer `#?` benotzt gëtt, ass d'Ausgab zimmlech gedréckt.
///
/// Fir méi Informatiounen iwwer Formateuren, kuckt [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// Dësen trait kann mat `#[derive]` benotzt ginn wann all Felder `Debug` implementéieren.
/// Wann "ofgeleet" d fir Structs, wäert et den Numm vum `struct` benotzen, dann `{`, dann eng Komma-getrennte Lëscht vum Numm vum Feld an dem `Debug` Wäert, dann `}`.
/// Fir `enum`s benotzt et den Numm vun der Variant an, wann zoutreffend, `(`, dann d `Debug` Wäerter vun de Felder, dann `)`.
///
/// # Stability
///
/// Ofgeleet `Debug` Formate sinn net stabil, a kënne sech also mat future Rust Versiounen änneren.
/// Zousätzlech sinn `Debug` Implementéierunge vun Typen, déi vun der Standardbibliothéik geliwwert ginn (`libstd`, `libcore`, `liballoc`, asw.) Net stabil, a kënne sech och mat future Rust Versioune veränneren.
///
///
/// # Examples
///
/// Eng Implementatioun ofleeden:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Manuell Ëmsetzung:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Et ginn eng Rei Hellefsmethoden op der [`Formatter`] struct fir Iech mat manuellen Implementatiounen ze hëllefen, wéi [`debug_struct`].
///
/// `Debug` Implementéierungen entweder `derive` oder den Debug Builder API op [`Formatter`] ënnerstëtzen zimmlech drucken mam alternativen Fändel: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// Zimmlech Dréckerei mat `#?`:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// Formatéiert de Wäert mat dem gegebene Formater.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// Separat Modul fir de Makro `Debug` vun prelude neiexportéieren ouni den trait `Debug`.
pub(crate) mod macros {
    /// Ofleeft Makro generéiert en Impl vun der trait `Debug`.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// Format trait fir eidel Format, `{}`.
///
/// `Display` ass ähnlech wéi [`Debug`], awer `Display` ass fir de Benotzer konfrontéiert Ausgang, a kann also net ofgeleet ginn.
///
///
/// Fir méi Informatiounen iwwer Formateuren, kuckt [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Implementéiere vun `Display` op engem Typ:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// Formatéiert de Wäert mat dem gegebene Formater.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// Den `Octal` trait soll seng Ausgab als Nummer an base-8 formatéieren.
///
/// Fir primitiv ënnerschriwwe ganz Zuelen (`i8` bis `i128`, an `isize`) ginn negativ Wäerter als déi zwee Ergänzungsrepresentatioun formatéiert.
///
///
/// Den alternativen Fändel, `#`, füügt en `0o` virun der Ausgab bäi.
///
/// Fir méi Informatiounen iwwer Formateuren, kuckt [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Basis Benotzung mat `i32`:
///
/// ```
/// let x = 42; // 42 ass '52' am Oktal
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// Implementéiere vun `Octal` op engem Typ:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // Delegéierte fir d'3232 Ëmsetzung
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// Formatéiert de Wäert mat dem gegebene Formater.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// Den `Binary` trait soll seng Ausgab als Zuel am Binär formatéieren.
///
/// Fir primitiv ënnerschriwwe ganz Zuelen ([`i8`] bis [`i128`], an [`isize`]) ginn negativ Wäerter als déi zwee Ergänzungsrepresentatioun formatéiert.
///
///
/// Den alternativen Fändel, `#`, füügt en `0b` virun der Ausgab bäi.
///
/// Fir méi Informatiounen iwwer Formateuren, kuckt [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Basis Benotzung mat [`i32`]:
///
/// ```
/// let x = 42; // 42 ass '101010' a binär
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// Implementéiere vun `Binary` op engem Typ:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // Delegéierte fir d'3232 Ëmsetzung
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// Formatéiert de Wäert mat dem gegebene Formater.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// Den `LowerHex` trait soll seng Ausgab als Nummer an hexadecimal formatéieren, mat `a` duerch `f` a klenge Buschtawen.
///
/// Fir primitiv ënnerschriwwe ganz Zuelen (`i8` bis `i128`, an `isize`) ginn negativ Wäerter als déi zwee Ergänzungsrepresentatioun formatéiert.
///
///
/// Den alternativen Fändel, `#`, füügt en `0x` virun der Ausgab bäi.
///
/// Fir méi Informatiounen iwwer Formateuren, kuckt [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Basis Benotzung mat `i32`:
///
/// ```
/// let x = 42; // 42 ass '2a' an Hex
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// Implementéiere vun `LowerHex` op engem Typ:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // Delegéierte fir d'3232 Ëmsetzung
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// Formatéiert de Wäert mat dem gegebene Formater.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// Den `UpperHex` trait soll seng Ausgab als Nummer an hexadecimal formatéieren, mat `A` bis `F` am grousse Fall.
///
/// Fir primitiv ënnerschriwwe ganz Zuelen (`i8` bis `i128`, an `isize`) ginn negativ Wäerter als déi zwee Ergänzungsrepresentatioun formatéiert.
///
///
/// Den alternativen Fändel, `#`, füügt en `0x` virun der Ausgab bäi.
///
/// Fir méi Informatiounen iwwer Formateuren, kuckt [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Basis Benotzung mat `i32`:
///
/// ```
/// let x = 42; // 42 ass '2A' an Hex
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// Implementéiere vun `UpperHex` op engem Typ:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // Delegéierte fir d'3232 Ëmsetzung
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// Formatéiert de Wäert mat dem gegebene Formater.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// Den `Pointer` trait soll seng Ausgab als Memory Location formatéieren.
/// Dëst gëtt allgemeng als hexadecimal duergestallt.
///
/// Fir méi Informatiounen iwwer Formateuren, kuckt [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Basis Benotzung mat `&i32`:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // dëst produzéiert eppes wéi '0x7f06092ac6d0'
/// ```
///
/// Implementéiere vun `Pointer` op engem Typ:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // benotzt `as` fir en `*const T` ze konvertéieren, deen de Pointer implementéiert, dee mir kënne benotzen
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// Formatéiert de Wäert mat dem gegebene Formater.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// Den `LowerExp` trait soll seng Ausgab an der wëssenschaftlecher Notatioun mat engem klengen Fall `e` formatéieren.
///
/// Fir méi Informatiounen iwwer Formateuren, kuckt [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Basis Benotzung mat `f64`:
///
/// ```
/// let x = 42.0; // 42.0 ass '4.2e1' a wëssenschaftlecher Notatioun
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// Implementéiere vun `LowerExp` op engem Typ:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // Delegéiert an d'Ëmsetzung vun der f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// Formatéiert de Wäert mat dem gegebene Formater.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// Den `UpperExp` trait soll seng Ausgab an der wëssenschaftlecher Notatioun mat engem grousse `E` formatéieren.
///
/// Fir méi Informatiounen iwwer Formateuren, kuckt [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Basis Benotzung mat `f64`:
///
/// ```
/// let x = 42.0; // 42.0 ass '4.2E1' a wëssenschaftlecher Notatioun
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// Implementéiere vun `UpperExp` op engem Typ:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // Delegéiert an d'Ëmsetzung vun der f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// Formatéiert de Wäert mat dem gegebene Formater.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// D `write` Funktioun hëlt en Output Stream, an en `Arguments` Struct dee ka mam `format_args!` Macro virkompiléiert ginn.
///
///
/// D'Argumenter ginn no dem spezifizéierte Format String an den ugebuede Output Format formatéiert.
///
/// # Examples
///
/// Basis Benotzung:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// Maacht weg datt d [`write!`] benotzt ka preferabel sinn.Beispill:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // Mir kënne Standardformatéierungsparameter fir all Argumenter benotzen.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // All Spezifikatioun huet en entspriechend Argument dat viru String Stéck virläit.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // SAFETY: arg an args.args kommen aus déiselwecht Argumenter,
                // wat garantéiert datt d'Indexen ëmmer bannent Grenzen sinn.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // Et kann nëmmen een hënnescht Stringstéck sinn.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // SAFETY: arg an args kommen aus demselwechten Argumenter,
    // wat garantéiert datt d'Indexen ëmmer bannent Grenzen sinn.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // Extrait de richtegen Argument
    debug_assert!(arg.position < args.len());
    // SAFETY: arg an args kommen aus demselwechten Argumenter,
    // wat garantéiert datt säin Index ëmmer a Grenzen ass.
    let value = unsafe { args.get_unchecked(arg.position) };

    // Dann tatsächlech e puer Dréckerei
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // SAFETY: cnt an args kommen aus demselwechten Argumenter,
            // wat dësen Index garantéiert ass ëmmer a Grenzen.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// Padding nom Enn vun eppes.Zréckgesat vun `Formatter::padding`.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// Schreift dëse Post padding.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // Mir wëllen dëst änneren
            buf: wrap(self.buf),

            // A behalen dës
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // Hëllefsmethoden, déi benotzt gi fir d'Formatéierungsargumenter ze padden an ze verschaffen, déi all traits formatéiere kënnen.
    //

    /// Féiert de richtege Padding fir eng ganz Zuel déi schonn an eng str ausgestraalt gouf.
    /// De Str sollt *net* d'Zeeche fir d'ganz Zuel enthalen, dat gëtt mat dëser Method derbäigesat.
    ///
    /// # Arguments
    ///
    /// * ass_negativ, egal ob d'originell ganz Zuel entweder positiv oder null war.
    /// * Präfix, wann den '#' Charakter (Alternate) virgesinn ass, ass dat de Präfix fir virun der Nummer ze setzen.
    ///
    /// * buf, de Byte-Array, op deen d'Zuel formatéiert gouf
    ///
    /// Dës Funktioun wäert d'Fändele geliwwert an och d'Mindestbreet korrekt berechnen.
    /// Et wäert d'Präzisioun net berécksiichtegen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // Mir mussen "-" aus der Nummerausgang eraushuelen.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // Schreift d'Zeechen wann et existéiert, an dann de Präfix wann et gefrot gouf
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // D `width` Feld ass méi vun engem `min-width` Parameter op dësem Punkt.
        match self.width {
            // Wann et keng Mindestlängtufuerderunge gëtt, da kënne mir just d'Bytes schreiwen.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Kontrolléiert ob mir iwwer déi minimal Breet sinn, wa jo, da kënne mir och just d'Bytes schreiwen.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // D'Schëld an de Präfix gi virum Padding wann de Füllcharakter null ass
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // Soss geet d'Zeechen an de Präfix nom Padding
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Dës Funktioun hëlt e Stringschnitt an emittéiert se an den interne Puffer no der Uwendung vun den zoustännege Formatéierungsfändelen.
    /// D'Fändele fir generesch Strings unerkannt sinn:
    ///
    /// * Breet, déi Mindestbreet vun deem wat ausgitt
    /// * fill/align - wat ze emittéieren a wou et emittéiert wann d'Streng ugebuede muss gepolstert ginn
    /// * Präzisioun, déi maximal Längt fir z'emisséieren, d'Stréck gëtt ofgeschnidden wann se méi laang wéi dës Längt ass
    ///
    /// Notamment dës Funktioun ignoréiert d `flag` Parameteren.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // Gitt sécher datt et e schnelle Wee vir ass
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // Den `precision` Feld kann als `max-width` interpretéiert ginn fir de String deen formatéiert gëtt.
        //
        let s = if let Some(max) = self.precision {
            // Wann eise String méi laang ass wéi d'Präzisioun, da musse mir Trunkerung hunn.
            // Wéi och ëmmer aner Fändele wéi `fill`, `width` an `align` musse wéi ëmmer handelen.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // LLVM hei kann net beweisen datt `..i` net panic `&s[..i]` wäert sinn, awer mir wëssen datt et net panic kann.
                // Benotzt `get` + `unwrap_or` fir `unsafe` ze vermeiden a soss gitt hei keen panic-verbonne Code aus.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // D `width` Feld ass méi vun engem `min-width` Parameter op dësem Punkt.
        match self.width {
            // Wa mir ënner der maximaler Längt sinn, an et gëtt keng Mindestlängtufuerderungen, da kënne mir just d'Streng ausginn
            //
            None => self.buf.write_str(s),
            // Wa mir ënner der maximaler Breet sinn, kontrolléiert ob mir iwwer déi Mindestbreet sinn, wa jo, et ass sou einfach wéi just d'Streng ofginn.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // Wa mir ënner der maximaler an der minimaler Breet sinn, fëllt dann d'Mindestbreedung mat der spezifizéierter String + eng Ausrichtung.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Schreift de Pre-padding an zréck déi ongeschriwwe Post-padding.
    /// D'Uruffer si verantwortlech fir no der Padding no der Saach geschriwwen ze ginn, déi gepolst gëtt.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// Huelt déi formatéiert Deeler an applizéiert de Padding.
    /// Ugeholl datt den Uruffer d'Deeler mat erfuerderter Präzisioun gemaach huet, sou datt `self.precision` ignoréiert ka ginn.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // fir d'Zeechenbewosst Null padding, gi mir d'Zeechen als éischt vir a behuelen eis wéi wa mir vun Ufank un keen Zeechen hätten.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // en Zeechen geet ëmmer als éischt
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // huelt d'Zeeche vun de formatéierten Deeler ewech
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // déi reschtlech Deeler ginn duerch den ordinäre Polsterprozess.
            let len = formatted.len();
            let ret = if width <= len {
                // nee padding
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // dëst ass de gemeinsame Fall a mir huelen eng Ofkiirzung
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // SAFETY: Dëst gëtt fir `flt2dec::Part::Num` an `flt2dec::Part::Copy` benotzt.
            // Et ass sécher fir `flt2dec::Part::Num` ze benotzen well all Char `c` tëscht `b'0'` an `b'9'` ass, dat heescht `s` ass valabel UTF-8.
            // Et ass och wahrscheinlech sécher an der Praxis fir `flt2dec::Part::Copy(buf)` ze benotzen well `buf` soll ASCII sinn, awer et ass méiglech datt een e schlechte Wäert fir `buf` an `flt2dec::to_shortest_str` weiderginn well et eng ëffentlech Funktioun ass.
            //
            // FIXME: Bestëmmt ob dëst zu UB kënnt.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 Nullen
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// Schreift e puer Daten un de Basispuffer, deen an dësem Formatéierer enthale gëtt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // Dëst entsprécht:
    ///         // schreiwen! (Formatéierer, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// Schreift e puer formatéiert Informatioun an dës Instanz.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// Fändele fir ze formatéieren
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// Charakter als 'fill' benotzt wann et Ausriichtung ass.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // Mir setzen d'Ausrichtung no riets mat ">".
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// Fändel wat ugëtt wéi eng Form vun Ausriichtung gefrot gouf.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// Optional spezifizéiert ganz Zollbreedung déi d'Ausgab soll sinn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // Wa mir eng Breet kritt hunn, benotze mir se
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // Soss maache mir näischt Spezielles
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// Optional präziséiert Präzisioun fir numeresch Typen.
    /// Alternativ déi maximal Breet fir Stringtypen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // Wa mir eng Präzisioun kréien, benotze mir déi.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // Soss hu mir op 2 Standard.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// Bestëmmt ob den `+` Fändel spezifizéiert gouf.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// Bestëmmt ob den `-` Fändel spezifizéiert gouf.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // Dir wëllt e Minus Zeechen?Hunn eng!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// Bestëmmt ob den `#` Fändel spezifizéiert gouf.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// Bestëmmt ob den `0` Fändel spezifizéiert gouf.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // Mir ignoréieren d'Optiounen vum Formater.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: Entscheed wéi eng ëffentlech API mir fir dës zwee Fändele wëllen.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// Erstellt en [`DebugStruct`] Builder entwéckelt fir mat der Schafung vun [`fmt::Debug`] Implementatiounen fir Struct ze hëllefen.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// Erstellt en `DebugTuple` Builder deen entwéckelt ass fir mat der Schafung vun `fmt::Debug` Implementatiounen fir Tupelstrucken z'ënnerstëtzen.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// Erstellt en `DebugList` Builder entwéckelt fir mat der Schafung vun `fmt::Debug` Implementéierungen fir Lëschtähnlech Strukturen ze hëllefen.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// Erstellt en `DebugSet` Builder entwéckelt fir ze hëllefen mat der Schafung vun `fmt::Debug` Implementatiounen fir set-like Strukturen.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// An dësem méi komplexe Beispill benotze mir [`format_args!`] an `.debug_set()` fir eng Lëscht mat Matchaarmen ze bauen:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// Erstellt en `DebugMap` Builder entwéckelt fir mat der Schafung vun `fmt::Debug` Implementéierungen fir kaartähnlech Strukturen ze hëllefen.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// Implementatiounen vum Kärformatéierung traits

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // Wann Char brauch ze flüchten, spull de Réckstand bis elo a schreift, soss sprangen
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // Den alternativen Fändel gëtt scho vum LowerHex als speziell behandelt-et bezeechent ob e mat 0x e Präfix ass.
        // Mir benotze se fir erauszefannen ob Null verlängert oder net, an dann onbedéngt gesat fir de Präfix ze kréien.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// Ëmsetzung vun Display/Debug fir verschidde Kärentypen

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // D'RefCell ass mutéiert ausgeléint sou datt mir net op säi Wäert hei kënne kucken.
                // Weist amplaz e Plazhaler.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// Wann Dir Tester erwaart hutt hei ze sinn, kuckt anstatt d core/tests/fmt.rs Datei, et ass vill méi einfach wéi all d rt::Piece Strukturen hei ze kreéieren.
//
// Et ginn och Tester an der Allocatioun crate, fir déi déi Allocatiounen brauchen.