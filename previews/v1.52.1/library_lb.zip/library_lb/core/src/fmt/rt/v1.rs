//! Dëst ass en internen Modul deen vum ifmt benotzt gëtt!Lafzäit.Dës Strukture ginn op statesch Arrays emittéiert fir Formatstrings viraus ze kompiléieren.
//!
//! Dës Definitioune sinn ähnlech wéi hir `ct` Äquivalenter, awer ënnerscheede sech datt dës statesch zougewise kënne ginn a liicht optiméiert sinn fir d'Runtime
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Méiglech Ausriichtungen déi als Deel vun enger Formatéierungsdirektiv ugefrot kënne ginn.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Indikatioun datt Inhalter lénks ausgeriicht solle sinn.
    Left,
    /// Indikatioun datt Inhalter sollten ausgeriicht sinn.
    Right,
    /// Indikatioun datt Inhalter sollten zentral ausgeriicht sinn.
    Center,
    /// Keng Ausriichtung gouf gefrot.
    Unknown,
}

/// Benotzt vun [width](https://doc.rust-lang.org/std/fmt/#width) an [precision](https://doc.rust-lang.org/std/fmt/#precision) Spezifizéierer.
#[derive(Copy, Clone)]
pub enum Count {
    /// Spezifizéiert mat enger wuertwiertlecher Zuel, speichert de Wäert
    Is(usize),
    /// Spezifizéiert mat `$` an `*` Syntaxen, speichert den Index an `args`
    Param(usize),
    /// Net uginn
    Implied,
}