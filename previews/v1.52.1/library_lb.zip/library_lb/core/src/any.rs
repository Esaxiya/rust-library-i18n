//! Dëst Modul implementéiert den `Any` trait, wat dynamesch Tippen vun all `'static` Typ duerch Runtime Reflexioun erméiglecht.
//!
//! `Any` selwer ka benotzt ginn fir en `TypeId` ze kréien, an huet méi Features wann en als trait Objet benotzt gëtt.
//! Als `&dyn Any` (e geléinten trait Objet) huet et d `is` an d `downcast_ref` Methoden, fir ze testen ob de enthale Wäert vun engem bestëmmten Typ ass, a fir eng Referenz op de banneschte Wäert als Typ ze kréien.
//! Als `&mut dyn Any` gëtt et och d `downcast_mut` Method, fir eng mutéierbar Referenz op de banneschte Wäert ze kréien.
//! `Box<dyn Any>` füügt d `downcast` Method bäi, déi probéiert op en `Box<T>` ze konvertéieren.
//! Kuckt d [`Box`] Dokumentatioun fir déi komplett Detailer.
//!
//! Bedenkt datt `&dyn Any` limitéiert ass fir ze testen ob e Wäert vun engem spezifizéierte Beton ass, a kann net benotzt ginn fir ze testen ob en Typ en trait implementéiert.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Smart Zeigefanger an `dyn Any`
//!
//! E Stéck Verhalen fir am Kapp ze behalen wann Dir `Any` als trait Objet benotzt, besonnesch mat Typen wéi `Box<dyn Any>` oder `Arc<dyn Any>`, ass datt einfach `.type_id()` op de Wäert nennt `TypeId` vum *Container* produzéiert, net de Basis trait Objet.
//!
//! Dëst kann vermeit ginn andeems de Smart Pointer an en `&dyn Any` ëmgewandelt gëtt, deen den Objet `TypeId` zréckbréngt.
//! Zum Beispill:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Dir sidd méi wahrscheinlech dëst ze wëllen:
//! let actual_id = (&*boxed).type_id();
//! // ... wéi dëst:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Betruecht eng Situatioun wou mir e Wäert ofginn, deen op eng Funktioun weidergeleet gëtt.
//! Mir wëssen de Wäert wou mir un Implugéieren Debug schaffen, awer mir wësse net wat et konkret ass.Mir wëllen e speziellen Typ vu speziellen Behandlungen ginn: an dësem Fall Dréck d'Längt vu String Wäerter virun hirem Wäert.
//! Mir wëssen net déi konkret Aart vun eisem Wäert bei der Kompiléierung, also musse mir d'Runtime Reflexioun benotzen.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Loggerfunktioun fir all Typ deen Debug implementéiert.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Probéiert eise Wäert op en `String` ze konvertéieren.
//!     // Wann et erfollegräich ass, wëlle mir d'Längt vun der String wéi och hire Wäert ausginn.
//!     // Wann net, ass et en anert Typ: dréckt et einfach ongeschmiert aus.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Dës Funktioun wëll säi Parameter aloggen ier se mat der Aarbecht mécht.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... eng aner Aarbecht maachen
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// All trait
///////////////////////////////////////////////////////////////////////////////

/// En trait fir dynamesch Tippen z'emuléieren.
///
/// Déi meescht Typen implementéieren `Any`.Wéi och ëmmer, all Typ deen eng net "statesch" Referenz enthält net.
/// Kuckt d [module-level documentation][mod] fir méi Detailer.
///
/// [mod]: crate::any
// Dësen trait ass net onsécher, awer mir vertrauen op d'Spezifizitéite vun der eenzeger impl `type_id` 1X Funktioun an onsécherem Code (z. B. `downcast`).Normalerweis wier dat e Problem, awer well deen eenzegen Impl vun `Any` eng Decken Ëmsetzung ass, kann keen anere Code `Any` implementéieren.
//
// Mir kéinten dës trait onsécher maachen-et géif kee Broch verursaachen, well mir all d'Implementéierungen kontrolléieren-awer mir wielen net well dat ass net wierklech noutwendeg a kënne Benotzer duerch d'Ënnerscheedung vun onsécher traits an onsécher Methoden duercherneen bréngen (dh `type_id` wier ëmmer nach sécher ze ruffen, awer mir wëllen als Dokumentatioun esou uginn).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Kritt den `TypeId` vun der `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Erweiderung Methode fir all trait Objeten.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Gitt sécher datt d'Resultat vun zB, mat engem Fuedem verbonne ka gedréckt ginn an dofir mat `unwrap` benotzt gëtt.
// Kann eventuell net méi gebraucht ginn wann Expeditioun mat Upcasting funktionnéiert.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Retour `true` wann de gekësstentyp d'selwecht ass wéi `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Gitt `TypeId` vun deem Typ mat deem dës Funktioun instantiéiert gëtt.
        let t = TypeId::of::<T>();

        // Gitt `TypeId` vum Typ am trait Objet (`self`).
        let concrete = self.type_id();

        // Vergläicht béid "TypeId`s iwwer d'Gläichheet.
        t == concrete
    }

    /// Retourneiert e puer Referenzen op de Këschtwäert wann et vum Typ `T` ass, oder `None` wann et net ass.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // SAFETY: just iwwerpréift ob mir op de richtegen Typ weisen, a mir kënnen drop vertrauen
            // dee kontrolléiert op d'Sécherheetssécherheet well mir Any fir all Typ implementéiert hunn;keng aner impls kënnen existéieren well se mat eisem impl.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Retourneiert e puer mutéierbar Referenz op de Këschtwäert wann et vum Typ `T` ass, oder `None` wann et net ass.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // SAFETY: just iwwerpréift ob mir op de richtegen Typ weisen, a mir kënnen drop vertrauen
            // dee kontrolléiert op d'Sécherheetssécherheet well mir Any fir all Typ implementéiert hunn;keng aner impls kënnen existéieren well se mat eisem impl.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Weiderginn op d'Method déi um Typ `Any` definéiert ass.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Weiderginn op d'Method déi um Typ `Any` definéiert ass.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Weiderginn op d'Method déi um Typ `Any` definéiert ass.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Weiderginn op d'Method déi um Typ `Any` definéiert ass.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Weiderginn op d'Method déi um Typ `Any` definéiert ass.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Weiderginn op d'Method déi um Typ `Any` definéiert ass.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID a seng Methoden
///////////////////////////////////////////////////////////////////////////////

/// A `TypeId` stellt e weltwäit eenzegaartegen Identifizéierer fir en Typ duer.
///
/// All `TypeId` ass en onduerchsiichtegen Objet deen et net erlaabt d'Inspektioun vu wat dobannen ass, awer Basis Operatiounen ze erlaben wéi Klonen, Verglach, Drécken a weisen.
///
///
/// En `TypeId` ass de Moment nëmme verfügbar fir Typen déi `'static` zouschreiwen, awer dës Begrenzung kann am future ofgeschaaft ginn.
///
/// Wärend `TypeId` `Hash`, `PartialOrd` an `Ord` implementéiert, ass et ze bemierken datt d'Hashen an d'Bestellung tëscht Rust Verëffentlechungen variéieren.
/// Passt op op se vertrauen bannent Ärem Code!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Nees den `TypeId` vum Typ mat deem dës generesch Funktioun instantiéiert gouf.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Nees den Numm vun engem Typ als Stringschnitt.
///
/// # Note
///
/// Dëst ass fir diagnostesch Benotzung geduecht.
/// De genauen Inhalt an d'Format vum String zréck ginn net spezifizéiert, ausser datt et eng beschten Ustrengung Beschreiwung vum Typ ass.
/// Zum Beispill, ënner de Sträicher déi `type_name::<Option<String>>()` zréckginn, sinn `"Option<String>"` an `"std::option::Option<std::string::String>"`.
///
///
/// Déi zréckgezunn String däerf net als eenzegaartegen Identifizéierer vun engem Typ ugesi ginn, well méi Zorten op deeselwechten Typennumm kaarte kënnen.
/// Ähnlech ass et keng Garantie datt all Deeler vun engem Typ am zréckgezunnene String erschéngen: zum Beispill Liewensdauer Spezifizéierer sinn de Moment net abegraff.
/// Zousätzlech kann d'Ausgab tëscht Versioune vum Compiler änneren.
///
/// Déi aktuell Implementatioun benotzt déiselwecht Infrastruktur wéi Compiler Diagnostics an Debuginfo, awer dëst ass net garantéiert.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Nees den Numm vun der Aart vun der uginn-als Wäert als String Slice.
/// Dëst ass d'selwecht wéi `type_name::<T>()`, awer ka benotzt ginn, wou d'Zort vun enger Variabel net einfach verfügbar ass.
///
/// # Note
///
/// Dëst ass fir diagnostesch Benotzung geduecht.De genauen Inhalt an d'Format vun der String sinn net spezifizéiert, ausser datt se eng beschten Ustrengungsbeschreiwung vum Typ sinn.
/// Zum Beispill, `type_name_of_val::<Option<String>>(None)` kéint `"Option<String>"` oder `"std::option::Option<std::string::String>"` zréckginn, awer net `"foobar"`.
///
/// Zousätzlech kann d'Ausgab tëscht Versioune vum Compiler änneren.
///
/// Dës Funktioun léist trait Objete net, dat heescht datt `type_name_of_val(&7u32 as &dyn Debug)` `"dyn Debug"` zréckbrénge kann, awer net `"u32"`.
///
/// Den Typ Numm sollt net als eenzegaartegen Identifizéierer vun engem Typ betruecht ginn;
/// méi Zorten kënnen dee selwechten Typ Numm deelen.
///
/// Déi aktuell Implementatioun benotzt déiselwecht Infrastruktur wéi Compiler Diagnostics an Debuginfo, awer dëst ass net garantéiert.
///
/// # Examples
///
/// Dréckt d'Default ganz Zuel an d'Flottentypen.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}