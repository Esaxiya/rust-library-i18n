//! Traits fir Konversiounen tëscht Typen.
//!
//! Den traits an dësem Modul bitt e Wee fir vun engem Typ an en aneren Typ ze konvertéieren.
//! All trait déngt en aneren Zweck:
//!
//! - Implementéiert den [`AsRef`] trait fir bëlleg Referenz-Referenz-Conversiounen
//! - Implementéiert den [`AsMut`] trait fir bëlleg mutabel-zu-mutabel Konversiounen
//! - Implementéiert den [`From`] trait fir Wäerter-a-Wäert Conversiounen ze verbrauchen
//! - Implementéiert den [`Into`] trait fir Wäerter-a-Wäert Conversiounen ze konsuméieren fir Aarten ausserhalb vun der aktueller crate
//! - D [`TryFrom`] an [`TryInto`] traits behuelen sech wéi [`From`] an [`Into`], awer sollten ëmgesat ginn wann d'Konversioun fällt.
//!
//! D'traits an dësem Modul ginn dacks als trait bounds fir generesch Funktioune benotzt sou datt zu Argumenter vu verschiddenen Zorten ënnerstëtzt ginn.Kuckt d'Dokumentatioun vun all trait fir Beispiller.
//!
//! Als Bibliothéiksautor sollt Dir ëmmer léiwer d [`From<T>`][`From`] oder [`TryFrom<T>`][`TryFrom`] implementéieren anstatt [`Into<U>`][`Into`] oder [`TryInto<U>`][`TryInto`], well [`From`] an [`TryFrom`] méi Flexibilitéit ubidden a gläichwäerteg [`Into`] oder [`TryInto`] Implementatiounen gratis ubidden, dank enger Deckenimplementatioun an der Standardbibliothéik.
//! Wann Dir op eng Versioun virum Rust 1.41 gezielt hutt, kann et néideg sinn [`Into`] oder [`TryInto`] direkt ëmzesetzen wann Dir en Typ ausserhalb vun der aktueller crate konvertéiert.
//!
//! # Generesch Implementatiounen
//!
//! - [`AsRef`] an [`AsMut`] Auto-Dereferenz wann den banneschten Typ eng Referenz ass
//! - [`From`]`<U>fir T` implizéiert [`Into`]`</u><T><U>fir U`</u>
//! - [`TryFrom`]`<U>fir T` implizéiert [`TryInto`]`</u><T><U>fir U`</u>
//! - [`From`] an [`Into`] sinn reflexiv, dat heescht datt all Typ selwer `into` kann an `from` selwer kënne maachen
//!
//! Kuckt all trait fir Beispiller fir Benotzung.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// D'Identitéit Funktioun.
///
/// Zwou Saache si wichteg ze notéieren iwwer dës Funktioun:
///
/// - Et ass net ëmmer gläichwäerteg mat enger Zoumaache wéi `|x| x`, well d'Zoumaache kann `x` an eng aner Aart zwéngen.
///
/// - Et plënnert den Input `x` un d'Funktioun weiderginn.
///
/// Obwuel et komesch wierkt eng Funktioun ze hunn, déi just den Input zréckbréngt, ginn et e puer interessant Utilisatiounen.
///
///
/// # Examples
///
/// `identity` benotze fir näischt an enger Sequenz vun aneren, interessante Funktiounen ze maachen:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Loosst eis maachen wéi wann een derbäi wier eng interessant Funktioun.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Benotzt `identity` als "do nothing" Basis Fall an engem bedingten:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Maacht méi interessant Saachen ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Mat `identity` fir d `Some` Varianten vun engem Iterator vun `Option<T>` ze halen:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Benotzt fir eng bëlleg Referenz-Referenz Konversioun ze maachen.
///
/// Dësen trait ass ähnlech wéi [`AsMut`] déi benotzt gëtt fir tëscht mutable Referenzen ze konvertéieren.
/// Wann Dir eng deier Konversioun maache musst ass et besser [`From`] mam Typ `&T` ëmzesetzen oder eng personaliséiert Funktioun ze schreiwen.
///
/// `AsRef` huet déi selwecht Ënnerschrëft wéi [`Borrow`], awer [`Borrow`] ass an e puer Aspekter anescht:
///
/// - Am Géigesaz zu `AsRef` huet [`Borrow`] eng Decken impl fir all `T`, a ka benotzt ginn entweder eng Referenz oder e Wäert ze akzeptéieren.
/// - [`Borrow`] erfuerdert och datt [`Hash`], [`Eq`] an [`Ord`] fir geléinte Wäert gläichwäerteg sinn wéi déi vum Besëtzwäert.
/// Aus dësem Grond, wann Dir nëmmen en eenzelt Feld vun engem Struct léine wëllt, kënnt Dir `AsRef` implementéieren, awer net [`Borrow`].
///
/// **Note: Dësen trait däerf net feelen **.Wann d'Conversioun ka faalen, benotzt eng speziell Method déi en [`Option<T>`] oder en [`Result<T, E>`] zréckbréngt.
///
/// # Generesch Implementatiounen
///
/// - `AsRef` Auto-Dereferenzen wann den banneschten Typ eng Referenz oder eng mutabel Referenz ass (zB: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Mat der Benotzung vun trait bounds kënne mir Argumenter vun verschiddenen Aarte akzeptéieren soulaang se an de spezifizéierten Typ `T` ëmgewandelt kënne ginn.
///
/// Zum Beispill: Mat der Erstellung vun enger generescher Funktioun déi en `AsRef<str>` hëlt, drécke mir aus datt mir all Referenzen akzeptéiere wëllen déi op [`&str`] als Argument ëmgewandelt kënne ginn.
/// Well béid [`String`] an [`&str`] `AsRef<str>` implementéieren, kënne mir als Input Argument akzeptéieren.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Féiert d'Konversioun aus.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Benotzt fir eng bëlleg mutable-to-mutable Referenzkonversioun ze maachen.
///
/// Dësen trait ass ähnlech wéi [`AsRef`] awer benotzt fir Konvertéierung tëscht mutable Referenzen.
/// Wann Dir eng deier Konversioun maache musst ass et besser [`From`] mam Typ `&mut T` ëmzesetzen oder eng personaliséiert Funktioun ze schreiwen.
///
/// **Note: Dësen trait däerf net feelen **.Wann d'Conversioun ka faalen, benotzt eng speziell Method déi en [`Option<T>`] oder en [`Result<T, E>`] zréckbréngt.
///
/// # Generesch Implementatiounen
///
/// - `AsMut` Auto-Dereferenzen wann den banneschten Typ eng verännerbar Referenz ass (zB: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Mat `AsMut` als trait bound fir eng generesch Funktioun kënne mir all mutéierbar Referenzen akzeptéieren déi ëmgewandelt kënne ginn zum Typ `&mut T`.
/// Well [`Box<T>`] `AsMut<T>` implementéiert kënne mir eng Funktioun `add_one` schreiwen déi all Argumenter hëlt déi op `&mut u64` ëmgewandelt kënne ginn.
/// Well [`Box<T>`] `AsMut<T>` implementéiert, acceptéiert `add_one` och Argumenter vum Typ `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Féiert d'Konversioun aus.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Eng Wäert-zu-Wäert Konversioun déi den Input Wäert verbraucht.De Géigendeel vun [`From`].
///
/// Et sollt vermeiden datt [`Into`] implementéiert gëtt an amplaz [`From`] implementéiert.
/// Implementéiere vun [`From`] gëtt automatesch eng mat enger Implementatioun vun [`Into`] dank der Deckenimplementatioun an der Standardbibliothéik.
///
/// Benotzt léiwer [`Into`] iwwer [`From`] wann Dir trait bounds op enger generescher Funktioun spezifizéiert fir sécher ze sinn datt Zorten déi nëmmen [`Into`] implementéieren och kënne benotzt ginn.
///
/// **Note: Dësen trait däerf net feelen **.Wann d'Konversioun ka faalen, benotzt [`TryInto`].
///
/// # Generesch Implementatiounen
///
/// - [`Vun`]`<T>fir U` implizéiert `Into<U> for T`
/// - [`Into`] ass reflexiv, dat heescht datt `Into<T> for T` implementéiert gëtt
///
/// # Implementéiere [`Into`] fir Konversiounen op extern Aarten an al Versioune vun Rust
///
/// Virun Rust 1.41, wann den Destinatiounstyp net Deel vum aktuellen crate war, konnt Dir [`From`] net direkt implementéieren.
/// Zum Beispill, huelt dëse Code:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Dëst wäert net an al Versioune vun der Sprooch kompiléieren, well d'Erléisungsregele vum Rust fréier e bësse méi streng waren.
/// Fir dëst z'ëmgoen, kënnt Dir [`Into`] direkt implementéieren:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Et ass wichteg ze verstoen datt [`Into`] keng [`From`]-Implementatioun ubitt (wéi [`From`] mat [`Into`] mécht).
/// Dofir sollt Dir ëmmer probéieren [`From`] ëmzesetzen an dann zréck op [`Into`] falen wann [`From`] net implementéiert ka ginn.
///
/// # Examples
///
/// [`String`] implementéiert [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Fir auszedrécken datt mir eng generesch Funktioun fir all Argumenter ze huelen déi zu engem spezifizéierten Typ `T` konvertéiert kënne ginn, kënne mir en trait bound vun [`Into]] 'benotzen<T>`.
///
/// Zum Beispill: D'Funktioun `is_hello` hëlt all Argumenter déi kënnen an e [`Vec`]`<`[`u8`] `>` ëmgewandelt ginn.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Féiert d'Konversioun aus.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Benotzt fir Wäert-zu-Wäert Conversiounen ze maachen beim Input Wäert.Et ass d'Géigesäitegkeet vun [`Into`].
///
/// Ee sollt ëmmer léiwer d `From` iwwer [`Into`] implementéieren, well d'Ëmsetzung vun `From` automatesch engem eng Implementéierung vun [`Into`] gëtt dank der Deckenimplementatioun an der Standardbibliothéik.
///
///
/// Ëmsetzt nëmmen [`Into`] wann Dir eng Versioun viséiert virum Rust 1.41 a konvertéiert an eng Aart ausserhalb vun der aktueller crate.
/// `From` war net fäeg dës Aart vu Conversiounen a fréiere Versiounen ze maachen wéinst den Orphanregelen vum Rust.
/// Kuckt [`Into`] fir méi Detailer.
///
/// Benotzt léiwer [`Into`] iwwer `From` wann Dir trait bounds op eng generesch Funktioun spezifizéiert.
/// Dëse Wee, Typen déi direkt [`Into`] implementéieren kënnen och als Argumenter benotzt ginn.
///
/// Den `From` ass och ganz nëtzlech beim Feelerbehandlung.Wann Dir eng Funktioun konstruéiert déi fäeg ass ze falen, ass de Retourtyp normalerweis vun der Form `Result<T, E>`.
/// Den `From` trait vereinfacht d'Fehlerbehandlung doduerch datt eng Funktioun een eenzege Feelertyp zréckkritt deen e puer Feelertypen ëmkapselt.Kuckt de "Examples" Sektioun an [the book][book] fir méi Detailer.
///
/// **Note: Dësen trait däerf net feelen **.Wann d'Konversioun ka faalen, benotzt [`TryFrom`].
///
/// # Generesch Implementatiounen
///
/// - `From<T> for U` implizéiert [`Into`]`<U>fir T`</u>
/// - `From` ass reflexiv, dat heescht datt `From<T> for T` implementéiert gëtt
///
/// # Examples
///
/// [`String`] implementéiert `From<&str>`:
///
/// Eng explizit Konversioun vun engem `&str` an e String gëtt wéi follegt gemaach:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Beim Fehlerbehandlung ass et dacks nëtzlech `From` fir Ären eegene Feelertyp ëmzesetzen.
/// Duerch Ëmwandlung vun de Basisfeelertypen op eisen eegene personaliséierte Feelertyp, deen de Basisfeeler Feelertyp ëmkapselt, kënne mir een eenzege Feelertyp zréckschécken ouni Informatioun iwwer d'Ursaach ze verléieren.
/// Den '?' Betreiber konvertéiert automatesch de Basisfehler-Typ an eise personaliséierte Feelertyp andeems en `Into<CliError>::into` urufft deen automatesch zur Verfügung gestallt gëtt wann Dir `From` implementéiert.
/// De Compiler leet dann eraus wéi eng Ëmsetzung vun `Into` soll benotzt ginn.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Féiert d'Konversioun aus.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// E versichten Ëmbau deen `self` verbraucht, wat och net deier ass.
///
/// Bibliothéiksautoren sollten dësen trait normalerweis net direkt ëmsetzen, awer léiwer d [`TryFrom`] trait ëmsetzen, wat méi Flexibilitéit bitt an eng gläichwäerteg `TryInto` Implementatioun gratis gëtt, dank enger Deckenimplementatioun an der Standardbibliothéik.
/// Fir méi Informatiounen iwwer dëst, kuckt d'Dokumentatioun fir [`Into`].
///
/// # Ëmsetzung vun `TryInto`
///
/// Dëst leid déiselwecht Restriktiounen a Begrënnung wéi d [`Into`] ëmzesetzen, kuckt do fir Detailer.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Den Typ deen am Fall vun engem Konversiounsfeeler zréck ass.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Féiert d'Konversioun aus.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Einfach a sécher Typkonversiounen déi ënner kontrolléierten Ëmstänn op kontrolléierter Manéier fale kënnen.Et ass d'Géigesäitegkeet vun [`TryInto`].
///
/// Dëst ass nëtzlech wann Dir eng Zort Konversioun maacht déi trivial erfollegräich kann awer och e speziellen Ëmgang brauch.
/// Zum Beispill ass et kee Wee fir en [`i64`] an en [`i32`] mat der [`From`] trait ze konvertéieren, well en [`i64`] kann e Wäert enthalen deen en [`i32`] net duerstellt an sou datt d'Konversioun Daten verléiert.
///
/// Dëst kéint gehandhabt ginn andeems den [`i64`] op en [`i32`] gekierzt gëtt (am Fong den ["i64"] säi Wäert modulo [`i32::MAX`] gëtt) oder duerch einfach [`i32::MAX`] zréckzeginn, oder duerch eng aner Method.
/// Den [`From`] trait ass fir perfekt Conversiounen geduecht, sou datt den `TryFrom` trait de Programméierer informéiert wann eng Aart Konversioun ka schlecht goen a léisst se entscheeden wéi se et packen.
///
/// # Generesch Implementatiounen
///
/// - `TryFrom<T> for U` implizéiert [`TryInto`]`<U>fir T`</u>
/// - [`try_from`] ass reflexiv, dat heescht datt `TryFrom<T> for T` implementéiert gëtt an net ausfale kann-deen assoziéierten `Error` Typ fir `T::try_from()` op e Wäert vum Typ `T` ze ruffen ass [`Infallible`].
/// Wann den [`!`] Typ stabiliséiert ass, sinn [`Infallible`] an [`!`] gläichwäerteg.
///
/// `TryFrom<T>` ka folgend ëmgesat ginn:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Wéi beschriwwen implementéiert [`i32`] `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Roueg trunktéiert `big_number`, erfuerdert Trunkerung no der Tatsaach ze detektéieren an ze behandelen.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Nees e Feeler well `big_number` ze grouss ass fir an en `i32` ze passen.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Retour `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Den Typ deen am Fall vun engem Konversiounsfeeler zréck ass.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Féiert d'Konversioun aus.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// GENERISCH IMPLS
////////////////////////////////////////////////////////////////////////////////

// Wéi Lifter iwwer&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Wéi Lifter iwwer &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): ersetzt déi uewe impls fir&/&mut mat der folgender méi allgemenger:
// // Wéi Lifter iwwer Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Gréisst> AsRef <U>fir D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut heft iwwer &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): ersetzt den uewegen Impl fir &mut mat der folgender méi allgemenger:
// // AsMut heft iwwer DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Gréisst> AsMut <U>fir D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Vun implizéiert Into
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Vun (an domat Into) ass reflexiv
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Stabilitéit Notiz:** Dës Impl existéiert nach net, awer mir sinn "reserving space" fir se an d'future bäizefügen.
/// Kuckt [rust-lang/rust#64715][#64715] fir Detailer.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): maach e prinzipiellen Fix amplaz.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom implizéiert TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Infallible Conversiounen si semantesch gläichwäerteg mat fallible Conversiounen mat engem onbewunnte Feelertyp.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// BETON IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// DEN KENG Feeler Feeler TYPE
////////////////////////////////////////////////////////////////////////////////

/// De Feelertyp fir Feeler déi ni kënne geschéien.
///
/// Well dësen Enum keng Variant huet, kann e Wäert vun dësem Typ ni existéieren.
/// Dëst kann nëtzlech sinn fir generesch APIen déi [`Result`] benotzen an de Feelertyp parameteriséieren, fir unzeginn datt d'Resultat ëmmer [`Ok`] ass.
///
/// Zum Beispill huet d [`TryFrom`] trait (Konversioun déi en [`Result`] zréckbréngt) eng Deckenimplementatioun fir all Typen wou eng ëmgedréint [`Into`] Implementatioun existéiert.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future Kompatibilitéit
///
/// Dësen Enum huet déiselwecht Roll wéi [the `!`“never”type][never], déi onbestänneg an dëser Versioun vun Rust ass.
/// Wann `!` stabiliséiert ass, plangen mir `Infallible` zu engem Typalias dozou ze maachen:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... a schliisslech `Infallible` ofschafen.
///
/// Wéi och ëmmer, et ass ee Fall wou `!` Syntax ka benotzt ginn ier `!` als vollwäerteg Typ stabiliséiert gëtt: an der Positioun vum Retourtyp vun enger Funktioun.
/// Spezifesch ass et méiglech Implementéierunge fir zwou verschidde Funktioun Zeigentypen:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Mat `Infallible` als enum ass dëse Code gëlteg.
/// Wéi och ëmmer, wann `Infallible` en Alias gëtt fir den never type, fänken déi zwee "Impl" un ze iwwerlappelen an dofir ginn se vun der Sprooch trait Kohärenzregelen erlaabt.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}