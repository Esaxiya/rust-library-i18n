//! Compiler intrinsesch.
//!
//! Déi entspriechend Definitioune sinn an `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Déi entspriechend const Implementéierungen sinn an `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const intrinsics
//!
//! Note: all Ännerunge vun der Konstanz vun der Intrinsik solle mam Sproochenteam diskutéiert ginn.
//! Dëst beinhalt d'Verännerunge vun der Stabilitéit vun der Konstanz.
//!
//! Fir eng intrinsesch benotzbar bei der Kompiléierung ze maachen, muss een d'Ëmsetzung vun <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> op `compiler/rustc_mir/src/interpret/intrinsics.rs` kopéieren an en `#[rustc_const_unstable(feature = "foo", issue = "01234")]` der intrinsescher derbäi bäifügen.
//!
//!
//! Wann en intrinsesche soll vun engem `const fn` mat engem `rustc_const_stable` Attribut benotzt ginn, muss den intrinsesche Attribut och `rustc_const_stable` sinn.
//! Sou eng Ännerung däerf net ouni T-Lang Consultatioun gemaach ginn, well se eng Feature an d'Sprooch bakt déi net am Usercode ouni Compiler Support replikéiert ka ginn.
//!
//! # Volatiles
//!
//! Déi onbestänneg Intrinsik bitt Operatiounen déi virgesi sinn op den I/O Gedächtnis ze handelen, déi garantéiert sinn net vum Compiler iwwer aner onbestänneg Intrinsiken ëmbestallt ze ginn.Kuckt d'LLVM Dokumentatioun op [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Déi atomesch Intrinsike bidden allgemeng atomesch Operatiounen op Maschinnwierder, mat ville méiglechen Erënnerungsuerdnungen.Si befollegen déiselwecht Semantik wéi C++ 11.Kuckt d'LLVM Dokumentatioun op [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Eng séier Erfrëschung beim Gedächtnisbestellen:
//!
//! * Kaaft, eng Barrière fir eng Spär ze kréien.Duerno liest a schreift no der Barrière statt.
//! * Fräisetzung, eng Barrière fir eng Spär fräisetzen.Virdru liest a schreift statt virun der Barrière.
//! * Sequentiell konsequent, sequentiell konsequent Operatioune si garantéiert an Uerdnung ze geschéien.Dëst ass de Standardmodus fir mat Atomtypen ze schaffen an entsprécht dem Java `volatile`.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Dës Importer gi benotzt fir intra-doc Links ze vereinfachen
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // SAFETY: kuckt `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, dës Intrinsike huelen roude Zeigefanger, well se aliaséiert Gedächtnis mutéieren, wat weder fir `&` nach `&mut` valabel ass.
    //

    /// Späichert e Wäert wann den aktuelle Wäert d'selwecht ass wéi de `old` Wäert.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `compare_exchange` Method verfügbar andeems se [`Ordering::SeqCst`] als `success` an `failure` Parameter weiderginn.
    ///
    /// Zum Beispill, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Späichert e Wäert wann den aktuelle Wäert d'selwecht ass wéi de `old` Wäert.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `compare_exchange` Method verfügbar andeems se [`Ordering::Acquire`] als `success` an `failure` Parameter weiderginn.
    ///
    /// Zum Beispill, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Späichert e Wäert wann den aktuelle Wäert d'selwecht ass wéi de `old` Wäert.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `compare_exchange` Method verfügbar andeems se [`Ordering::Release`] als `success` an [`Ordering::Relaxed`] als `failure` Parameter weiderginn.
    /// Zum Beispill, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Späichert e Wäert wann den aktuelle Wäert d'selwecht ass wéi de `old` Wäert.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `compare_exchange` Method verfügbar andeems se [`Ordering::AcqRel`] als `success` an [`Ordering::Acquire`] als `failure` Parameter weiderginn.
    /// Zum Beispill, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Späichert e Wäert wann den aktuelle Wäert d'selwecht ass wéi de `old` Wäert.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `compare_exchange` Method verfügbar andeems se [`Ordering::Relaxed`] als `success` an `failure` Parameter weiderginn.
    ///
    /// Zum Beispill, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Späichert e Wäert wann den aktuelle Wäert d'selwecht ass wéi de `old` Wäert.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `compare_exchange` Method verfügbar andeems se [`Ordering::SeqCst`] als `success` an [`Ordering::Relaxed`] als `failure` Parameter weiderginn.
    /// Zum Beispill, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Späichert e Wäert wann den aktuelle Wäert d'selwecht ass wéi de `old` Wäert.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `compare_exchange` Method verfügbar andeems se [`Ordering::SeqCst`] als `success` an [`Ordering::Acquire`] als `failure` Parameter weiderginn.
    /// Zum Beispill, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Späichert e Wäert wann den aktuelle Wäert d'selwecht ass wéi de `old` Wäert.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `compare_exchange` Method verfügbar andeems se [`Ordering::Acquire`] als `success` an [`Ordering::Relaxed`] als `failure` Parameter weiderginn.
    /// Zum Beispill, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Späichert e Wäert wann den aktuelle Wäert d'selwecht ass wéi de `old` Wäert.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `compare_exchange` Method verfügbar andeems se [`Ordering::AcqRel`] als `success` an [`Ordering::Relaxed`] als `failure` Parameter weiderginn.
    /// Zum Beispill, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Späichert e Wäert wann den aktuelle Wäert d'selwecht ass wéi de `old` Wäert.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `compare_exchange_weak` Method verfügbar andeems se [`Ordering::SeqCst`] als `success` an `failure` Parameter weiderginn.
    ///
    /// Zum Beispill, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Späichert e Wäert wann den aktuelle Wäert d'selwecht ass wéi de `old` Wäert.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `compare_exchange_weak` Method verfügbar andeems se [`Ordering::Acquire`] als `success` an `failure` Parameter weiderginn.
    ///
    /// Zum Beispill, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Späichert e Wäert wann den aktuelle Wäert d'selwecht ass wéi de `old` Wäert.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `compare_exchange_weak` Method verfügbar andeems se [`Ordering::Release`] als `success` an [`Ordering::Relaxed`] als `failure` Parameter weiderginn.
    /// Zum Beispill, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Späichert e Wäert wann den aktuelle Wäert d'selwecht ass wéi de `old` Wäert.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `compare_exchange_weak` Method verfügbar andeems se [`Ordering::AcqRel`] als `success` an [`Ordering::Acquire`] als `failure` Parameter weiderginn.
    /// Zum Beispill, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Späichert e Wäert wann den aktuelle Wäert d'selwecht ass wéi de `old` Wäert.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `compare_exchange_weak` Method verfügbar andeems se [`Ordering::Relaxed`] als `success` an `failure` Parameter weiderginn.
    ///
    /// Zum Beispill, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Späichert e Wäert wann den aktuelle Wäert d'selwecht ass wéi de `old` Wäert.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `compare_exchange_weak` Method verfügbar andeems se [`Ordering::SeqCst`] als `success` an [`Ordering::Relaxed`] als `failure` Parameter weiderginn.
    /// Zum Beispill, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Späichert e Wäert wann den aktuelle Wäert d'selwecht ass wéi de `old` Wäert.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `compare_exchange_weak` Method verfügbar andeems se [`Ordering::SeqCst`] als `success` an [`Ordering::Acquire`] als `failure` Parameter weiderginn.
    /// Zum Beispill, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Späichert e Wäert wann den aktuelle Wäert d'selwecht ass wéi de `old` Wäert.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `compare_exchange_weak` Method verfügbar andeems se [`Ordering::Acquire`] als `success` an [`Ordering::Relaxed`] als `failure` Parameter weiderginn.
    /// Zum Beispill, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Späichert e Wäert wann den aktuelle Wäert d'selwecht ass wéi de `old` Wäert.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `compare_exchange_weak` Method verfügbar andeems se [`Ordering::AcqRel`] als `success` an [`Ordering::Relaxed`] als `failure` Parameter weiderginn.
    /// Zum Beispill, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Luet den aktuelle Wäert vum Zeiger.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `load` Method verfügbar andeems se [`Ordering::SeqCst`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Luet den aktuelle Wäert vum Zeiger.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `load` Method verfügbar andeems se [`Ordering::Acquire`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Luet den aktuelle Wäert vum Zeiger.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `load` Method verfügbar andeems se [`Ordering::Relaxed`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Späichert de Wäert op der spezifizéierter Erënnerungsplaz.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `store` Method verfügbar andeems se [`Ordering::SeqCst`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Späichert de Wäert op der spezifizéierter Erënnerungsplaz.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `store` Method verfügbar andeems se [`Ordering::Release`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Späichert de Wäert op der spezifizéierter Erënnerungsplaz.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `store` Method verfügbar andeems se [`Ordering::Relaxed`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Späichert de Wäert op der spezifizéierter Erënnerungsplaz, zréckgëtt den ale Wäert.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `swap` Method verfügbar andeems se [`Ordering::SeqCst`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Späichert de Wäert op der spezifizéierter Erënnerungsplaz, zréckgëtt den ale Wäert.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `swap` Method verfügbar andeems se [`Ordering::Acquire`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Späichert de Wäert op der spezifizéierter Erënnerungsplaz, zréckgëtt den ale Wäert.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `swap` Method verfügbar andeems se [`Ordering::Release`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Späichert de Wäert op der spezifizéierter Erënnerungsplaz, zréckgëtt den ale Wäert.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `swap` Method verfügbar andeems se [`Ordering::AcqRel`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Späichert de Wäert op der spezifizéierter Erënnerungsplaz, zréckgëtt den ale Wäert.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `swap` Method verfügbar andeems se [`Ordering::Relaxed`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Füügt zum aktuelle Wäert bäi, gëtt de fréiere Wäert zréck.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `fetch_add` Method verfügbar andeems se [`Ordering::SeqCst`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Füügt zum aktuelle Wäert bäi, gëtt de fréiere Wäert zréck.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `fetch_add` Method verfügbar andeems se [`Ordering::Acquire`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Füügt zum aktuelle Wäert bäi, gëtt de fréiere Wäert zréck.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `fetch_add` Method verfügbar andeems se [`Ordering::Release`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Füügt zum aktuelle Wäert bäi, gëtt de fréiere Wäert zréck.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `fetch_add` Method verfügbar andeems se [`Ordering::AcqRel`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Füügt zum aktuelle Wäert bäi, gëtt de fréiere Wäert zréck.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `fetch_add` Method verfügbar andeems se [`Ordering::Relaxed`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Huelt vum aktuelle Wäert of, gitt de fréiere Wäert zréck.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `fetch_sub` Method verfügbar andeems se [`Ordering::SeqCst`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Huelt vum aktuelle Wäert of, gitt de fréiere Wäert zréck.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `fetch_sub` Method verfügbar andeems se [`Ordering::Acquire`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Huelt vum aktuelle Wäert of, gitt de fréiere Wäert zréck.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `fetch_sub` Method verfügbar andeems se [`Ordering::Release`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Huelt vum aktuelle Wäert of, gitt de fréiere Wäert zréck.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `fetch_sub` Method verfügbar andeems se [`Ordering::AcqRel`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Huelt vum aktuelle Wäert of, gitt de fréiere Wäert zréck.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `fetch_sub` Method verfügbar andeems se [`Ordering::Relaxed`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitweise a mam aktuelle Wäert, zréckgoe vum fréiere Wäert.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `fetch_and` Method verfügbar andeems se [`Ordering::SeqCst`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweise a mam aktuelle Wäert, zréckgoe vum fréiere Wäert.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `fetch_and` Method verfügbar andeems se [`Ordering::Acquire`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweise a mam aktuelle Wäert, zréckgoe vum fréiere Wäert.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `fetch_and` Method verfügbar andeems se [`Ordering::Release`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweise a mam aktuelle Wäert, zréckgoe vum fréiere Wäert.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `fetch_and` Method verfügbar andeems se [`Ordering::AcqRel`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweise a mam aktuelle Wäert, zréckgoe vum fréiere Wäert.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `fetch_and` Method verfügbar andeems se [`Ordering::Relaxed`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitweise nand mam aktuelle Wäert, andeems de fréiere Wäert zréckgeet.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche gëtt am [`AtomicBool`] Typ iwwer d `fetch_nand` Method verfügbar andeems Dir [`Ordering::SeqCst`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweise nand mam aktuelle Wäert, andeems de fréiere Wäert zréckgeet.
    ///
    /// Déi stabiliséierter Versioun vun dësem intrinsesche gëtt am [`AtomicBool`] Typ iwwer d `fetch_nand` Method verfügbar andeems Dir [`Ordering::Acquire`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweise nand mam aktuelle Wäert, andeems de fréiere Wäert zréckgeet.
    ///
    /// Déi stabiliséierter Versioun vun dësem intrinsesche gëtt am [`AtomicBool`] Typ iwwer d `fetch_nand` Method verfügbar andeems Dir [`Ordering::Release`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweise nand mam aktuelle Wäert, andeems de fréiere Wäert zréckgeet.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche gëtt am [`AtomicBool`] Typ iwwer d `fetch_nand` Method verfügbar andeems Dir [`Ordering::AcqRel`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweise nand mam aktuelle Wäert, andeems de fréiere Wäert zréckgeet.
    ///
    /// Déi stabiliséierter Versioun vun dësem intrinsesche gëtt am [`AtomicBool`] Typ iwwer d `fetch_nand` Method verfügbar andeems Dir [`Ordering::Relaxed`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitweise oder mam aktuelle Wäert, andeems de fréiere Wäert zréckgeet.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `fetch_or` Method verfügbar andeems se [`Ordering::SeqCst`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweise oder mam aktuelle Wäert, andeems de fréiere Wäert zréckgeet.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `fetch_or` Method verfügbar andeems se [`Ordering::Acquire`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweise oder mam aktuelle Wäert, andeems de fréiere Wäert zréckgeet.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `fetch_or` Method verfügbar andeems se [`Ordering::Release`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweise oder mam aktuelle Wäert, andeems de fréiere Wäert zréckgeet.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `fetch_or` Method verfügbar andeems se [`Ordering::AcqRel`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweise oder mam aktuelle Wäert, andeems de fréiere Wäert zréckgeet.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `fetch_or` Method verfügbar andeems se [`Ordering::Relaxed`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitweise xor mam aktuelle Wäert, andeems de fréiere Wäert zréckgeet.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `fetch_xor` Method verfügbar andeems se [`Ordering::SeqCst`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweise xor mam aktuelle Wäert, andeems de fréiere Wäert zréckgeet.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `fetch_xor` Method verfügbar andeems se [`Ordering::Acquire`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweise xor mam aktuelle Wäert, andeems de fréiere Wäert zréckgeet.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `fetch_xor` Method verfügbar andeems se [`Ordering::Release`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweise xor mam aktuelle Wäert, andeems de fréiere Wäert zréckgeet.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `fetch_xor` Method verfügbar andeems se [`Ordering::AcqRel`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitweise xor mam aktuelle Wäert, andeems de fréiere Wäert zréckgeet.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] Typen iwwer d `fetch_xor` Method verfügbar andeems se [`Ordering::Relaxed`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maximum mam aktuelle Wäert mat engem ënnerschriwwene Verglach.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] ënnerschriwwe ganz Zorten iwwer d `fetch_max` Method verfügbar andeems se [`Ordering::SeqCst`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum mam aktuelle Wäert mat engem ënnerschriwwene Verglach.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] ënnerschriwwe ganz Zorten iwwer d `fetch_max` Method verfügbar andeems se [`Ordering::Acquire`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum mam aktuelle Wäert mat engem ënnerschriwwene Verglach.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] ënnerschriwwe ganz Zorten iwwer d `fetch_max` Method verfügbar andeems se [`Ordering::Release`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum mam aktuelle Wäert mat engem ënnerschriwwene Verglach.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] ënnerschriwwe ganz Zorten iwwer d `fetch_max` Method verfügbar andeems se [`Ordering::AcqRel`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum mam aktuelle Wäert.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] ënnerschriwwe ganz Zorten iwwer d `fetch_max` Method verfügbar andeems se [`Ordering::Relaxed`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum mam aktuelle Wäert mat engem ënnerschriwwene Verglach.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] ënnerschriwwe ganz Zorten iwwer d `fetch_min` Method verfügbar andeems se [`Ordering::SeqCst`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum mam aktuelle Wäert mat engem ënnerschriwwene Verglach.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] ënnerschriwwe ganz Zorten iwwer d `fetch_min` Method verfügbar andeems se [`Ordering::Acquire`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum mam aktuelle Wäert mat engem ënnerschriwwene Verglach.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] ënnerschriwwe ganz Zorten iwwer d `fetch_min` Method verfügbar andeems se [`Ordering::Release`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum mam aktuelle Wäert mat engem ënnerschriwwene Verglach.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] ënnerschriwwe ganz Zorten iwwer d `fetch_min` Method verfügbar andeems se [`Ordering::AcqRel`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum mam aktuelle Wäert mat engem ënnerschriwwene Verglach.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] ënnerschriwwe ganz Zorten iwwer d `fetch_min` Method verfügbar andeems se [`Ordering::Relaxed`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum mam aktuelle Wäert mat engem net signéierte Verglach.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche gëtt et op den [`atomic`] net ënnerschriwwe ganz Zorten iwwer d `fetch_min` Method andeems [`Ordering::SeqCst`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum mam aktuelle Wäert mat engem net signéierte Verglach.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche gëtt et op den [`atomic`] net ënnerschriwwe ganz Zorten iwwer d `fetch_min` Method andeems [`Ordering::Acquire`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum mam aktuelle Wäert mat engem net signéierte Verglach.
    ///
    /// Déi stabiliséiert Versioun vun dëser intrinsescher ass op den [`atomic`] net ënnerschriwwe ganz Zorten iwwer d `fetch_min` Method verfügbar andeems se [`Ordering::Release`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum mam aktuelle Wäert mat engem net signéierte Verglach.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche gëtt et op den [`atomic`] net ënnerschriwwe ganz Zorten iwwer d `fetch_min` Method andeems [`Ordering::AcqRel`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum mam aktuelle Wäert mat engem net signéierte Verglach.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche gëtt et op den [`atomic`] net ënnerschriwwe ganz Zorten iwwer d `fetch_min` Method andeems [`Ordering::Relaxed`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maximum mam aktuelle Wäert mat engem net signéierte Verglach.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche gëtt et op den [`atomic`] net ënnerschriwwe ganz Zorten iwwer d `fetch_max` Method andeems [`Ordering::SeqCst`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum mam aktuelle Wäert mat engem net signéierte Verglach.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche gëtt et op den [`atomic`] net ënnerschriwwe ganz Zorten iwwer d `fetch_max` Method andeems [`Ordering::Acquire`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum mam aktuelle Wäert mat engem net signéierte Verglach.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche gëtt et op den [`atomic`] net ënnerschriwwe ganz Zorten iwwer d `fetch_max` Method andeems [`Ordering::Release`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum mam aktuelle Wäert mat engem net signéierte Verglach.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche gëtt et op den [`atomic`] net ënnerschriwwe ganz Zorten iwwer d `fetch_max` Method andeems [`Ordering::AcqRel`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum mam aktuelle Wäert mat engem net signéierte Verglach.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche gëtt et op den [`atomic`] net ënnerschriwwe ganz Zorten iwwer d `fetch_max` Method andeems [`Ordering::Relaxed`] als `order` weiderginn.
    /// Zum Beispill, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Den `prefetch` intrinsic ass en Hiweis op de Code Generator fir eng Prefetch Instruktioun anzeginn wann ënnerstëtzt;anescht ass et en No-Op.
    /// Prefetches hunn keen Effekt op d'Behuele vum Programm awer kënne seng Performance Charakteristiken änneren.
    ///
    /// D `locality` Argument muss eng konstant ganz Zuel sinn an ass e temporäre Lokalitéitsspezifizéierer vun (0), keng Uertschaft, bis (3), extrem lokal am Cache.
    ///
    ///
    /// Dëst intrinsescht huet kee stabile Kolleg.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Den `prefetch` intrinsic ass en Hiweis op de Code Generator fir eng Prefetch Instruktioun anzeginn wann ënnerstëtzt;anescht ass et en No-Op.
    /// Prefetches hunn keen Effekt op d'Behuele vum Programm awer kënne seng Performance Charakteristiken änneren.
    ///
    /// D `locality` Argument muss eng konstant ganz Zuel sinn an ass e temporäre Lokalitéitsspezifizéierer vun (0), keng Uertschaft, bis (3), extrem lokal am Cache.
    ///
    ///
    /// Dëst intrinsescht huet kee stabile Kolleg.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Den `prefetch` intrinsic ass en Hiweis op de Code Generator fir eng Prefetch Instruktioun anzeginn wann ënnerstëtzt;anescht ass et en No-Op.
    /// Prefetches hunn keen Effekt op d'Behuele vum Programm awer kënne seng Performance Charakteristiken änneren.
    ///
    /// D `locality` Argument muss eng konstant ganz Zuel sinn an ass e temporäre Lokalitéitsspezifizéierer vun (0), keng Uertschaft, bis (3), extrem lokal am Cache.
    ///
    ///
    /// Dëst intrinsescht huet kee stabile Kolleg.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Den `prefetch` intrinsic ass en Hiweis op de Code Generator fir eng Prefetch Instruktioun anzeginn wann ënnerstëtzt;anescht ass et en No-Op.
    /// Prefetches hunn keen Effekt op d'Behuele vum Programm awer kënne seng Performance Charakteristiken änneren.
    ///
    /// D `locality` Argument muss eng konstant ganz Zuel sinn an ass e temporäre Lokalitéitsspezifizéierer vun (0), keng Uertschaft, bis (3), extrem lokal am Cache.
    ///
    ///
    /// Dëst intrinsescht huet kee stabile Kolleg.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// En Atomzaang.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche gëtt et an [`atomic::fence`] andeems [`Ordering::SeqCst`] als `order` weiderginn.
    ///
    ///
    pub fn atomic_fence();
    /// En Atomzaang.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche gëtt et an [`atomic::fence`] andeems [`Ordering::Acquire`] als `order` weiderginn.
    ///
    ///
    pub fn atomic_fence_acq();
    /// En Atomzaang.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche gëtt et an [`atomic::fence`] andeems [`Ordering::Release`] als `order` weiderginn.
    ///
    ///
    pub fn atomic_fence_rel();
    /// En Atomzaang.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche gëtt et an [`atomic::fence`] andeems [`Ordering::AcqRel`] als `order` weiderginn.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Eng Compiler nëmmen Erënnerung Barrière.
    ///
    /// Memory Accesses ginn ni iwwer dës Barrière vum Compiler nei bestallt, awer keng Instruktioune ginn dofir ausgestraalt.
    /// Dëst ass ugemoossen fir Operatiounen op deemselwechte Fuedem, dee virgesi ka ginn, wéi zum Beispill wann Dir mat Signalhändler interagéiert.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche gëtt et an [`atomic::compiler_fence`] andeems [`Ordering::SeqCst`] als `order` weiderginn.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Eng Compiler nëmmen Erënnerung Barrière.
    ///
    /// Memory Accesses ginn ni iwwer dës Barrière vum Compiler nei bestallt, awer keng Instruktioune ginn dofir ausgestraalt.
    /// Dëst ass ugemoossen fir Operatiounen op deemselwechte Fuedem, dee virgesi ka ginn, wéi zum Beispill wann Dir mat Signalhändler interagéiert.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche gëtt et an [`atomic::compiler_fence`] andeems [`Ordering::Acquire`] als `order` weiderginn.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Eng Compiler nëmmen Erënnerung Barrière.
    ///
    /// Memory Accesses ginn ni iwwer dës Barrière vum Compiler nei bestallt, awer keng Instruktioune ginn dofir ausgestraalt.
    /// Dëst ass ugemoossen fir Operatiounen op deemselwechte Fuedem, dee virgesi ka ginn, wéi zum Beispill wann Dir mat Signalhändler interagéiert.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche gëtt et an [`atomic::compiler_fence`] andeems [`Ordering::Release`] als `order` weiderginn.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Eng Compiler nëmmen Erënnerung Barrière.
    ///
    /// Memory Accesses ginn ni iwwer dës Barrière vum Compiler nei bestallt, awer keng Instruktioune ginn dofir ausgestraalt.
    /// Dëst ass ugemoossen fir Operatiounen op deemselwechte Fuedem, dee virgesi ka ginn, wéi zum Beispill wann Dir mat Signalhändler interagéiert.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche gëtt et an [`atomic::compiler_fence`] andeems [`Ordering::AcqRel`] als `order` weiderginn.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Magesch intrinsesch déi seng Bedeitung ofleeft aus Attributer déi un der Funktioun verbonne sinn.
    ///
    /// Zum Beispill, Dataflow benotzt dëst fir statesch Behaaptungen ze sprëtzen, sou datt `rustc_peek(potentially_uninitialized)` tatsächlech duebel kontrolléiere géif dat Dateflow wierklech ausgerechent huet datt et zu deem Zäitpunkt am Kontrollfloss uninitialiséiert ass.
    ///
    ///
    /// Dës intrinsesch sollt net ausserhalb vum Compiler benotzt ginn.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Ofbriechen d'Ausféierung vum Prozess.
    ///
    /// Eng méi userfrëndlech a stabil Versioun vun dëser Operatioun ass [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Informéiert den Optimizer datt dëse Punkt am Code net erreechbar ass, fir weider Optimisatiounen z'erméiglechen.
    ///
    /// NB, dëst ass ganz anescht wéi den `unreachable!()` Macro: Am Géigesaz zum Macro, deen panics wann en ausgefouert gëtt, ass et *ondefinéiert Verhalen* fir de Code mat dëser Funktioun ze erreechen.
    ///
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Informéiert den Optimizer datt eng Bedingung ëmmer richteg ass.
    /// Wann d'Konditioun falsch ass, ass d'Verhalen net definéiert.
    ///
    /// Keen Code gëtt fir dësen intrinsesche generéiert, awer den Optimizer probéiert et ze bewahren (a säin Zoustand) tëscht de Passagen, wat mat der Optimiséierung vum Ëmgéigendcode ka stéieren an d'Performance reduzéiere kann.
    /// Et sollt net benotzt ginn wann den Invariant eleng vum Optimizer entdeckt ka ginn, oder wann et keng bedeitend Optimisatiounen aktivéiert.
    ///
    /// Dëst intrinsescht huet kee stabile Kolleg.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Tipps fir de Compiler datt d'branch Zoustand méiglecherweis richteg ass.
    /// Retourneiert de Wäert deen et weiderginn ass.
    ///
    /// All aner Benotzung wéi mat `if` Aussoen wäert wuel keen Effekt hunn.
    ///
    /// Dëst intrinsescht huet kee stabile Kolleg.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Tipps fir de Compiler datt d'branch Zoustand wahrscheinlech falsch ass.
    /// Retourneiert de Wäert deen et weiderginn ass.
    ///
    /// All aner Benotzung wéi mat `if` Aussoen wäert wuel keen Effekt hunn.
    ///
    /// Dëst intrinsescht huet kee stabile Kolleg.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Féiert eng Breakpoint Trap aus, fir d'Inspektioun vun engem Debugger.
    ///
    /// Dëst intrinsescht huet kee stabile Kolleg.
    pub fn breakpoint();

    /// D'Gréisst vun engem Typ vu Bytes.
    ///
    /// Méi spezifesch ass dëst den Offset a Bytes tëscht successive Saache vum selwechten Typ, och Ausriichtungspadding.
    ///
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Déi minimal Ausriichtung vun engem Typ.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Déi bevorzugt Ausriichtung vun engem Typ.
    ///
    /// Dëst intrinsescht huet kee stabile Kolleg.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// D'Gréisst vum referenzéierte Wäert a Bytes.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Déi erfuerderlech Ausriichtung vum referenzéierte Wäert.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Kritt eng statesch String Scheif mat dem Numm vun engem Typ.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Kritt en Identifizéierer dee weltwäit eenzegaarteg ass fir dee spezifizéierten Typ.
    /// Dës Funktioun wäert dee selwechte Wäert fir en Typ zréckschécken, egal wéi eng crate se opgeruff gëtt.
    ///
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// E Bewaacher fir onsécher Funktiounen déi ni kënne ausgefouert ginn wann `T` onbewunnt ass:
    /// Dëst wäert statesch entweder panic, oder näischt maachen.
    ///
    /// Dëst intrinsescht huet kee stabile Kolleg.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// E Bewaacher fir onsécher Funktiounen, déi ni kënne ausgefouert ginn, wann `T` keng Nullinitialiséierung erlaabt: Dëst wäert statesch entweder panic, oder näischt maachen.
    ///
    ///
    /// Dëst intrinsescht huet kee stabile Kolleg.
    pub fn assert_zero_valid<T>();

    /// E Bewaacher fir onsécher Funktiounen déi ni kënne ausgefouert ginn wann `T` ongëlteg Bitmuster huet: Dëst wäert statesch entweder panic, oder näischt maachen.
    ///
    ///
    /// Dëst intrinsescht huet kee stabile Kolleg.
    pub fn assert_uninit_valid<T>();

    /// Kritt eng Referenz op e stateschen `Location` wat ugëtt wou et geruff gouf.
    ///
    /// Betruecht benotzt [`core::panic::Location::caller`](crate::panic::Location::caller) amplaz.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Beweegt e Wäert aus dem Ëmfang ouni Drëps Klebstoff auszeféieren.
    ///
    /// Dëst existéiert nëmme fir [`mem::forget_unsized`];normal `forget` benotzt amplaz `ManuallyDrop`.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Reinterprets de Stécker vun engem Wäert vun engem Typ als en aneren Typ.
    ///
    /// Béid Typen mussen déiselwecht Gréisst hunn.
    /// Weder d'Original, nach d'Resultat, kann en [invalid value](../../nomicon/what-unsafe-does.html) sinn.
    ///
    /// `transmute` ass semantesch gläichwäerteg mat enger bësseger Bewegung vun engem Typ an en aneren.Et kopéiert d'Bits aus dem Quellwäert an den Zilwäert, vergiess dann d'Original.
    /// Et ass gläichwäerteg dem C's `memcpy` ënner der Kapuze, genau wéi `transmute_copy`.
    ///
    /// Well `transmute` eng by-value Operatioun ass, ass d'Ausriichtung vun de *transmutéierte Wäerter selwer* keng Suerg.
    /// Wéi mat all aner Funktiounen ass de Compiler scho sécher datt `T` an `U` richteg ausgeriicht sinn.
    /// Wéi och ëmmer, wann Wäerter iwwerdroe ginn, déi *anzwousch* weisen (wéi Uweiser, Referenzen, Këschten ...), muss den Uruff eng korrekt Ausriichtung vun de gewisen Wäerter garantéieren.
    ///
    /// `transmute` ass **onheemlech** onsécher.Et gi vill Weeër fir [undefined behavior][ub] mat dëser Funktioun ze verursaachen.`transmute` soll den absoluten leschten Auswee sinn.
    ///
    /// Den [nomicon](../../nomicon/transmutes.html) huet zousätzlech Dokumentatioun.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Et ginn e puer Saachen déi `transmute` wierklech nëtzlech ass.
    ///
    /// En Zeigefanger zu engem Funktiounsweiger verwandelen.Dëst ass *net* portabel fir Maschinnen wou Funktiounsweiser an Datenweiser verschidde Gréissten hunn.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Liewensdauer verlängeren, oder eng onverännerlech Liewensdauer verkierzen.Dëst ass fortgeschratt, ganz onsécher Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Verzweifelt net: vill Utilisatioune vu `transmute` kënnen duerch aner Weeër erreecht ginn.
    /// Hei drënner sinn allgemeng Uwendungen vun `transmute` déi mat méi séchere Konstrukten ersat kënne ginn.
    ///
    /// Rohen bytes(`&[u8]`) op `u32`, `f64`, etc dréinen:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // benotzt `u32::from_ne_bytes` amplaz
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // oder benotzt `u32::from_le_bytes` oder `u32::from_be_bytes` fir d'Endlechkeet ze spezifizéieren
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Ee Zeigefanger an en `usize` maachen:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Benotzt en `as` Besetzung amplaz
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// En `*mut T` an en `&mut T` maachen:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Benotzt e Widderhuelung amplaz
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// En `&mut T` an en `&mut U` maachen:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Elo, `as` zesummesetzen an nei ze léinen, notéiert d'Kettenung vun `as` `as` ass net transitiv
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// En `&str` an en `&[u8]` maachen:
    ///
    /// ```
    /// // dëst ass net e gudde Wee dëst ze maachen.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Dir kéint `str::as_bytes` benotzen
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Oder, just eng Byte String benotzen, wann Dir Kontroll iwwer de String wuertwiertlech hutt
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Maacht en `Vec<&T>` an en `Vec<Option<&T>>`.
    ///
    /// Fir den banneschten Typ vum Inhalt vun engem Container ze transmutéieren, musst Dir sécher sinn datt Dir keng vun de Containerinvariante verletzt.
    /// Fir `Vec` heescht dat, datt d'Gréisst *an d'Ausriichtung* vun den banneschten Typen mussen passen.
    /// Aner Container kéinten op d'Gréisst vum Typ, d'Ausrichtung oder och d `TypeId` vertrauen, an deem Fall Transmutéiere guer net méiglech wier ouni Containerinvaréierer ze verletzen.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // klon den vector wéi mir se spéider weiderbenotzen
    /// let v_clone = v_orig.clone();
    ///
    /// // Mat Transmute benotzen: dëst setzt op den net spezifizéierten Datelayout vun `Vec`, wat eng schlecht Iddi ass a kéint ondefinéiert Behuelen verursaachen.
    /////
    /// // Wéi och ëmmer, et ass keng Kopie.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Dëst ass de virgeschloene, séchere Wee.
    /// // Et kopéiert de ganzen vector awer an eng nei Array.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Dëst ass de richtege keng Kopie, onsécher Manéier vu "transmuting" a `Vec`, ouni op den Datelayout ze vertrauen.
    /// // Amplaz wuertwiertlech `transmute` ze nennen, féiere mir e Zeigefangerbesetzung, awer wat d'originell bannent Aart (`&i32`) an den neien (`Option<&i32>`) ëmsetzt, huet dat all déiselwecht Virbehalt.
    /////
    /// // Nieft den uewe genannten Informatioune kuckt och d [`from_raw_parts`] Dokumentatioun.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Update dëst wann vec_into_raw_parts stabiliséiert ass.
    ///     // Gitt sécher datt den originale vector net fale gelooss gëtt.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Implementéiere vun `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Et gi verschidde Weeër fir dëst ze maachen, an et gi verschidde Probleemer mat der folgender (transmute) Manéier.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // als éischt: transmute ass net sécher;alles wat et kontrolléiert ass datt T an
    ///         // U sidd vun der selwechter Gréisst.
    ///         // Zweetens, direkt hei, hutt Dir zwee mutéierbar Referenzen déi op déiselwecht Erënnerung weisen.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Dëst kritt d'Typ Sécherheetsprobleemer lass;`&mut *` wäert* nëmmen *Iech en `&mut T` vun engem `&mut T` oder `* mut T` ginn.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // awer, Dir hutt nach ëmmer zwou mutéierbar Referenzen déi op déiselwecht Erënnerung weisen.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Dëst ass wéi d'Standardbibliothéik et mécht.
    /// // Dëst ass déi bescht Method, wann Dir esou eppes maache musst
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Dëst huet elo dräi mutabel Referenzen déi op déiselwecht Erënnerung weisen.`slice`, de rvalue ret.0, an de rvalue ret.1.
    ///         // `slice` gëtt ni nom `let ptr = ...` benotzt, an dofir kann een et als "dead" behandelen, an dofir hutt Dir nëmmen zwou richteg mutabel Scheiwen.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Och wann dëst den intrinsesche const stabil mécht, hu mir e puer personaliséierte Code am const fn
    // Schecken déi d'Benotzung bannent `const fn` verhënneren.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Retour `true` wann den aktuellen Typ deen als `T` uginn ass drop Koll erfuerdert;gëtt `false` zréck wann den aktuellen Typ fir `T` virgesinn `Copy` implementéiert.
    ///
    ///
    /// Wann den aktuellen Typ weder drop Klebstoff erfuerdert nach `Copy` implementéiert, da gëtt de Retourwäert vun dëser Funktioun net spezifizéiert.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Berechent den Offset vun engem Zeiger.
    ///
    /// Dëst gëtt als intrinsesch ëmgesat fir ze vermeiden datt et zu a vun enger ganzer ass, well d'Konversioun aliaséierend Informatioun géif verschwannen.
    ///
    /// # Safety
    ///
    /// Souwuel de Start-wéi och de resultéierende Zeiger mussen entweder a Grenzen sinn oder ee Byte laanscht d'Enn vun engem zougestellten Objet.
    /// Wann entweder Zeiger ausser Grenzen ass oder arithmetesch Iwwerschwemmung geschitt, da féiert all weider Notzung vum zréckgezunnene Wuert zu ondefinéiertem Verhalen.
    ///
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Berechent den Offset vun engem Zeiger, potenziell Wécklung.
    ///
    /// Dëst gëtt als intrinsesch implementéiert fir ze vermeiden datt d'Ëmwandlung an a vun enger ganzer Zuel ass, well d'Konversioun bestëmmte Optimisatiounen hemmt.
    ///
    /// # Safety
    ///
    /// Am Géigesaz zum `offset` intrinsesche beschränkt dës intrinsesch net de resultéierende Zeiger fir an oder e Byte laanscht d'Enn vun engem zugewiesenen Objet ze weisen, an et wéckelt sech mat zwou Ergänzungsarithmetik.
    /// De resultéierende Wäert ass net onbedéngt gëlteg fir ze benotzen fir tatsächlech op Erënnerung ze kommen.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Äquivalent mam passenden `llvm.memcpy.p0i8.0i8.*` intrinsesche, mat enger Gréisst vun `count`*`size_of::<T>()` an enger Ausriichtung vun
    ///
    /// `min_align_of::<T>()`
    ///
    /// De flüchtege Parameter ass op `true` gesat, sou datt et net optimiséiert gëtt ausser d'Gréisst ass null.
    ///
    /// Dëst intrinsescht huet kee stabile Kolleg.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Gläichwäerteg dem passenden `llvm.memmove.p0i8.0i8.*` intrinsesche, mat enger Gréisst vun `count* size_of::<T>()` an enger Ausriichtung vun
    ///
    /// `min_align_of::<T>()`
    ///
    /// De flüchtege Parameter ass op `true` gesat, sou datt et net optimiséiert gëtt ausser d'Gréisst ass null.
    ///
    /// Dëst intrinsescht huet kee stabile Kolleg.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Äquivalent mam passenden `llvm.memset.p0i8.*` intrinsesche, mat enger Gréisst vun `count* size_of::<T>()` an enger Ausriichtung vun `min_align_of::<T>()`.
    ///
    ///
    /// De flüchtege Parameter ass op `true` gesat, sou datt et net optimiséiert gëtt ausser d'Gréisst ass null.
    ///
    /// Dëst intrinsescht huet kee stabile Kolleg.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Féiert eng onbestänneg Belaaschtung vum `src` Zeiger.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Féiert e liichtflüchtege Geschäft zum `dst` Zeiger.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Féiert eng onbestänneg Belaaschtung vum `src` Zeiger De Zeiger ass net erfuerderlech ausgeriicht ze sinn.
    ///
    ///
    /// Dëst intrinsescht huet kee stabile Kolleg.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Féiert e liichtflüchtege Geschäft zum `dst` Zeiger.
    /// De Zeiger ass net erfuerderlech ausgeriicht ze sinn.
    ///
    /// Dëst intrinsescht huet kee stabile Kolleg.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Gitt d'Quadratwurzel vun engem `f32` zréck
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Gitt d'Quadratwurzel vun engem `f64` zréck
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Erhieft en `f32` op eng ganz Muecht.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Erhieft en `f64` op eng ganz Muecht.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Nees de Sinus vun engem `f32`.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Nees de Sinus vun engem `f64`.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Retour de Kosinus vun engem `f32`.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Retour de Kosinus vun engem `f64`.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Erhieft en `f32` op eng `f32` Muecht.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Erhieft en `f64` op eng `f64` Kraaft.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Nees d'Exponential vun engem `f32`.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Nees d'Exponential vun engem `f64`.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Returns 2 erhéicht un d'Kraaft vun engem `f32`.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Returns 2 erhéicht un d'Kraaft vun engem `f64`.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Nees den natierleche Logarithmus vun engem `f32`.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Nees den natierleche Logarithmus vun engem `f64`.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Gitt d'Basis 10 Logarithmus vun engem `f32` zréck.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Gitt d'Basis 10 Logarithmus vun engem `f64` zréck.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Gitt d'Basis 2 Logarithmus vun engem `f32` zréck.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Gitt d'Basis 2 Logarithmus vun engem `f64` zréck.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Retour `a * b + c` fir `f32` Wäerter.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Retour `a * b + c` fir `f64` Wäerter.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Nees den absolute Wäert vun engem `f32`.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Nees den absolute Wäert vun engem `f64`.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Nees de Minimum vun zwou `f32` Wäerter.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Nees de Minimum vun zwou `f64` Wäerter.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Nees de Maximum vun zwee `f32` Wäerter.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Nees de Maximum vun zwee `f64` Wäerter.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Kopéiert d'Zeeche vun `y` op `x` fir `f32` Wäerter.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Kopéiert d'Zeeche vun `y` op `x` fir `f64` Wäerter.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Gitt déi gréisst ganz Zuel manner wéi oder gläich wéi en `f32`.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Gitt déi gréisst ganz Zuel manner wéi oder gläich wéi en `f64`.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Gitt déi klengst ganz Zuel méi grouss wéi oder gläich wéi en `f32`.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Gitt déi klengst ganz Zuel méi grouss wéi oder gläich wéi en `f64`.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Nees den ganzen Deel vun engem `f32`.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Nees den ganzen Deel vun engem `f64`.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Gitt d'nächst ganz Zuel op en `f32` zréck.
    /// Kann eng inexakt Schwammpunkt Ausnam erhéijen wann d'Argument net eng ganz Zuel ass.
    pub fn rintf32(x: f32) -> f32;
    /// Gitt d'nächst ganz Zuel op eng `f64` zréck.
    /// Kann eng inexakt Schwammpunkt Ausnam erhéijen wann d'Argument net eng ganz Zuel ass.
    pub fn rintf64(x: f64) -> f64;

    /// Gitt d'nächst ganz Zuel op en `f32` zréck.
    ///
    /// Dëst intrinsescht huet kee stabile Kolleg.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Gitt d'nächst ganz Zuel op eng `f64` zréck.
    ///
    /// Dëst intrinsescht huet kee stabile Kolleg.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Gitt d'nächst ganz Zuel op eng `f32` zréck.Ronn hallef Weeër ewech vun Null.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Gitt d'nächst ganz Zuel op eng `f64` zréck.Ronn hallef Weeër ewech vun Null.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Float Additioun déi Optimiséierungen op Basis vun algebraesche Regelen erlaabt.
    /// Kann ugeholl datt d'Inputen endlech sinn.
    ///
    /// Dëst intrinsescht huet kee stabile Kolleg.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Float Subtraktioun déi Optimiséierungen op Basis vun algebraesche Regelen erlaabt.
    /// Kann ugeholl datt d'Inputen endlech sinn.
    ///
    /// Dëst intrinsescht huet kee stabile Kolleg.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Float Multiplikatioun déi Optimiséierungen op Basis vun algebraesche Regelen erlaabt.
    /// Kann ugeholl datt d'Inputen endlech sinn.
    ///
    /// Dëst intrinsescht huet kee stabile Kolleg.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Float Divisioun déi Optimiséierungen op Basis vun algebraesche Regelen erlaabt.
    /// Kann ugeholl datt d'Inputen endlech sinn.
    ///
    /// Dëst intrinsescht huet kee stabile Kolleg.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Float Rescht dat Optimiséierungen op Basis vun algebraesche Regelen erlaabt.
    /// Kann ugeholl datt d'Inputen endlech sinn.
    ///
    /// Dëst intrinsescht huet kee stabile Kolleg.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Konvertéiert mat LLVM's fptoui/fptosi, wat kann undef fir Wäerter ausserhalb vun der Gamme zréckginn
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Stabiliséiert als [`f32::to_int_unchecked`] an [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Gitt d'Zuel vun de Stécker déi an engem ganz Zuelen `T` gesat sinn
    ///
    /// Déi stabiliséiert Versioune vun dësem intrinsesche sinn op der ganzer Primitiv iwwer d `count_ones` Method verfügbar.
    /// Zum Beispill,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Gitt d'Zuel vun de féierenden net gesaten Bits (zeroes) an enger ganzer Zuel `T` zréck.
    ///
    /// Déi stabiliséiert Versioune vun dësem intrinsesche sinn op der ganzer Primitiv iwwer d `leading_zeros` Method verfügbar.
    /// Zum Beispill,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// En `x` mam Wäert `0` wäert d'Bitebreet vun `T` zréckbréngen.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Wéi `ctlz`, awer extra onsécher wéi et `undef` zréckgitt wann en `x` mat Wäert `0` gëtt.
    ///
    ///
    /// Dëst intrinsescht huet kee stabile Kolleg.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Gitt d'Zuel vun de verfollegen unset Bits (zeroes) an enger ganzer Zuel `T` zréck.
    ///
    /// Déi stabiliséiert Versioune vun dësem intrinsesche sinn op der ganzer Primitiv iwwer d `trailing_zeros` Method verfügbar.
    /// Zum Beispill,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// En `x` mam Wäert `0` wäert d'Bitebreet vun `T` zréckginn:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Wéi `cttz`, awer extra onsécher wéi et `undef` zréckgitt wann en `x` mat Wäert `0` gëtt.
    ///
    ///
    /// Dëst intrinsescht huet kee stabile Kolleg.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Ëmgedréit d'Bytes an enger ganzer Zuel `T`.
    ///
    /// Déi stabiliséiert Versioune vun dësem intrinsesche sinn op der ganzer Primitiv iwwer d `swap_bytes` Method verfügbar.
    /// Zum Beispill,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Ëmgedréit d'Bits an enger ganzer Zuel `T`.
    ///
    /// Déi stabiliséiert Versioune vun dësem intrinsesche sinn op der ganzer Primitiv iwwer d `reverse_bits` Method verfügbar.
    /// Zum Beispill,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Féiert kontrolléiert ganz Zousaz.
    ///
    /// Déi stabiliséiert Versioune vun dësem intrinsesche sinn op der ganzer Primitiv iwwer d `overflowing_add` Method verfügbar.
    /// Zum Beispill,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Féiert gepréift ganz Zuelen subtrahéieren
    ///
    /// Déi stabiliséiert Versioune vun dësem intrinsesche sinn op der ganzer Primitiv iwwer d `overflowing_sub` Method verfügbar.
    /// Zum Beispill,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Féiert iwwerpréift ganz Zuel Multiplikatioun
    ///
    /// Déi stabiliséiert Versioune vun dësem intrinsesche sinn op der ganzer Primitiv iwwer d `overflowing_mul` Method verfügbar.
    /// Zum Beispill,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Féiert eng exakt Divisioun aus, wat zu ondefinéiertem Verhalen resultéiert wou `x % y != 0` oder `y == 0` oder `x == T::MIN && y == -1`
    ///
    ///
    /// Dëst intrinsescht huet kee stabile Kolleg.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Féiert eng onkontrolléiert Divisioun, wat zu ondefinéiertem Verhalen resultéiert wou `y == 0` oder `x == T::MIN && y == -1`
    ///
    ///
    /// Sécher Wrappers fir dës intrinsesch sinn op der ganzer Primitiv iwwer d `checked_div` Method verfügbar.
    /// Zum Beispill,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Gitt de Rescht vun enger onkontrolléierter Divisioun zréck, wat zu ondefinéiertem Verhalen resultéiert wann `y == 0` oder `x == T::MIN && y == -1`
    ///
    ///
    /// Sécher Wrappers fir dës intrinsesch sinn op der ganzer Primitiv iwwer d `checked_rem` Method verfügbar.
    /// Zum Beispill,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Féiert eng onkontrolléiert lénks Verschiebung aus, wat zu ondefinéiertem Verhalen resultéiert wann `y < 0` oder `y >= N`, wou N d'Breet vun T a Bits ass.
    ///
    ///
    /// Sécher Wrappers fir dës intrinsesch sinn op der ganzer Primitiv iwwer d `checked_shl` Method verfügbar.
    /// Zum Beispill,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Féiert eng onkontrolléiert riets Verschiebung aus, wat zu ondefinéiertem Verhalen resultéiert wann `y < 0` oder `y >= N`, wou N d'Breet vun T a Bits ass.
    ///
    ///
    /// Sécher Wrappers fir dës intrinsesch sinn op der ganzer Primitiv iwwer d `checked_shr` Method verfügbar.
    /// Zum Beispill,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Gitt d'Resultat vun enger onkontrolléierter Ergänzung zréck, wat zu ondefinéiertem Verhalen resultéiert wann `x + y > T::MAX` oder `x + y < T::MIN`.
    ///
    ///
    /// Dëst intrinsescht huet kee stabile Kolleg.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Gitt d'Resultat vun enger onkontrolléierter Subtraktioun zréck, wat zu ondefinéiertem Verhalen resultéiert wann `x - y > T::MAX` oder `x - y < T::MIN`.
    ///
    ///
    /// Dëst intrinsescht huet kee stabile Kolleg.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Gitt d'Resultat vun enger onkontrolléierter Multiplikatioun zréck, wat zu ondefinéiertem Verhalen resultéiert wann `x *y > T::MAX` oder `x* y < T::MIN`.
    ///
    ///
    /// Dëst intrinsescht huet kee stabile Kolleg.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Féiert rotéiert lénks.
    ///
    /// Déi stabiliséiert Versioune vun dësem intrinsesche sinn op der ganzer Primitiv iwwer d `rotate_left` Method verfügbar.
    /// Zum Beispill,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Leeschtunge rotéieren richteg.
    ///
    /// Déi stabiliséiert Versioune vun dësem intrinsesche sinn op der ganzer Primitiv iwwer d `rotate_right` Method verfügbar.
    /// Zum Beispill,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Returns (a + b) mod 2 <sup>N</sup>, wou N d'Breet vun T a Bits ass.
    ///
    /// Déi stabiliséiert Versioune vun dësem intrinsesche sinn op der ganzer Primitiv iwwer d `wrapping_add` Method verfügbar.
    /// Zum Beispill,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Returns (a, b) mod 2 <sup>N</sup>, wou N d'Breet vun T a Bits ass.
    ///
    /// Déi stabiliséiert Versioune vun dësem intrinsesche sinn op der ganzer Primitiv iwwer d `wrapping_sub` Method verfügbar.
    /// Zum Beispill,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Returns (a * b) mod 2 <sup>N</sup>, wou N d'Breet vun T a Bits ass.
    ///
    /// Déi stabiliséiert Versioune vun dësem intrinsesche sinn op der ganzer Primitiv iwwer d `wrapping_mul` Method verfügbar.
    /// Zum Beispill,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Berechent `a + b`, saturéiert mat numeresche Grenzen.
    ///
    /// Déi stabiliséiert Versioune vun dësem intrinsesche sinn op der ganzer Primitiv iwwer d `saturating_add` Method verfügbar.
    /// Zum Beispill,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Berechent `a - b`, saturéiert mat numeresche Grenzen.
    ///
    /// Déi stabiliséiert Versioune vun dësem intrinsesche sinn op der ganzer Primitiv iwwer d `saturating_sub` Method verfügbar.
    /// Zum Beispill,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Gitt de Wäert vum Diskriminant fir d'Variant am 'v' zréck;
    /// wann `T` keen Diskriminant huet, gëtt `0` zréck.
    ///
    /// Déi stabiliséiert Versioun vun dësem intrinsesche ass [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Gitt d'Zuel vun de Varianten vum Typ `T` op eng `usize` zréck;
    /// wann `T` keng Varianten huet, gëtt `0` zréck.Onbewunnte Varianten ginn gezielt.
    ///
    /// Déi ze stabiliséiere Versioun vun dësem intrinsesche ass [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust's "try catch" Konstrukt déi de Funktionszeiger `try_fn` mam Datenzeiger `data` oprufft.
    ///
    /// Dat drëtt Argument ass eng Funktioun genannt wann en panic geschitt.
    /// Dës Funktioun hëlt den Datenzeiger an e Zeiger zum zilspezifeschen Ausnamobjekt dee gefaange gouf.
    ///
    /// Fir méi Informatioun kuckt d'Quell vum Compiler souwéi d'std Fangimplementatioun.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Emittéiert en `!nontemporal` Geschäft no LLVM (kuckt hir Dokumenter).
    /// Wahrscheinlech wäert ni stabil ginn.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Kuckt Dokumentatioun vun `<*const T>::offset_from` fir Detailer.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Kuckt Dokumentatioun vun `<*const T>::guaranteed_eq` fir Detailer.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Kuckt Dokumentatioun vun `<*const T>::guaranteed_ne` fir Detailer.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Allocéiert zu kompiléierter Zäit.Sollt net bei der Runtime geruff ginn.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// E puer Funktioune sinn hei definéiert well se zoufälleg an dësem Modul op stabil zur Verfügung gestallt goufen.
// Kuckt <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` fällt och an dës Kategorie, awer et kann net agewéckelt ginn wéinst der Kontroll datt `T` an `U` déiselwecht Gréisst hunn.)
//

/// Kontrolléiert ob `ptr` richteg ausgeriicht ass par rapport zu `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Kopéiert `count *size_of::<T>()` Bytes vun `src` op `dst`.D'Quell an d'Destinatioun mussen* net * iwwerlappen.
///
/// Fir Regioune vu Gedächtnis déi iwwerlappend sinn, benotzt [`copy`] statt.
///
/// `copy_nonoverlapping` ass semantesch gläichwäerteg mam C [`memcpy`], awer mat der Argumentuerdnung ausgetosch.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Verhalen ass ondefinéiert wann eng vun de folgende Konditioune verletzt gëtt:
///
/// * `src` muss [valid] sinn fir Liese vun `count * size_of::<T>()` Bytes.
///
/// * `dst` muss [valid] sinn fir `count * size_of::<T>()` Bytes ze schreiwen.
///
/// * Béid `src` an `dst` musse richteg ausgeriicht sinn.
///
/// * D'Regioun vum Gedächtnis beginn bei `src` mat enger Gréisst vun `Grof *
///   Gréisst_of: :<T>() `Bytes däerfen *net* mat der Regioun vum Gedächtnis iwwerlappt mat der `dst` mat der selwechter Gréisst.
///
/// Wéi [`read`] erstellt `copy_nonoverlapping` eng bitvis Kopie vun `T`, egal ob `T` [`Copy`] ass.
/// Wann `T` net [`Copy`] ass, benotze *béid* d'Wäerter an der Regioun déi um `*src` ufänkt an d'Regioun déi um `* dst` ufänkt kann [violate memory safety][read-ownership].
///
///
/// Bedenkt datt och wann déi effektiv kopéiert Gréisst (`count * size_of: :<T>()`) ass `0`, d'Zeechner mussen net NULL sinn a richteg ausgeriicht sinn.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Manuell [`Vec::append`] implementéieren:
///
/// ```
/// use std::ptr;
///
/// /// Beweegt all d'Elementer vun `src` an `dst`, léisst `src` eidel.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Gitt sécher datt `dst` genuch Kapazitéit huet fir all `src` ze halen.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Den Opruff zum Offset ass ëmmer sécher, well `Vec` wäert ni méi wéi `isize::MAX` Bytes allocéieren.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Truncate `src` ouni säin Inhalt erofzesetzen.
///         // Mir maachen dat als éischt, fir Probleemer ze vermeiden am Fall eppes méi wäit erof panics.
///         src.set_len(0);
///
///         // Déi zwou Regiounen kënnen net iwwerlappt ginn well mutabel Referenzen net alias sinn, an zwou verschidde vectors kënnen net datselwecht Gedächtnis hunn.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Matdeelt `dst` datt et elo den Inhalt vun `src` hält.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Maacht dës Kontrollen nëmmen a Laafzäit
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Net panikéieren fir Codegen Impakt méi kleng ze halen.
        abort();
    }*/

    // SAFETY: de Sécherheetsvertrag fir `copy_nonoverlapping` muss sinn
    // vum Uruff oprechterhalen.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Kopéiert `count * size_of::<T>()` Bytes vun `src` op `dst`.D'Quell an d'Destinatioun kënnen iwwerlappend sinn.
///
/// Wann d'Quell an d'Destinatioun *ni* iwwerlappt, kann [`copy_nonoverlapping`] amplaz benotzt ginn.
///
/// `copy` ass semantesch gläichwäerteg mam C [`memmove`], awer mat der Argumentuerdnung ausgetosch.
/// Kopéieren fënnt wéi wann d'Bytes vun `src` op eng temporär Array kopéiert goufen an da vun der Array op `dst` kopéiert goufen.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Verhalen ass ondefinéiert wann eng vun de folgende Konditioune verletzt gëtt:
///
/// * `src` muss [valid] sinn fir Liese vun `count * size_of::<T>()` Bytes.
///
/// * `dst` muss [valid] sinn fir `count * size_of::<T>()` Bytes ze schreiwen.
///
/// * Béid `src` an `dst` musse richteg ausgeriicht sinn.
///
/// Wéi [`read`] erstellt `copy` eng bitvis Kopie vun `T`, egal ob `T` [`Copy`] ass.
/// Wann `T` net [`Copy`] ass, kënne béid Wäerter an der Regioun mat `*src` an der Regioun mat `* dst` ufänken [violate memory safety][read-ownership] benotzen.
///
///
/// Bedenkt datt och wann déi effektiv kopéiert Gréisst (`count * size_of: :<T>()`) ass `0`, d'Zeechner mussen net NULL sinn a richteg ausgeriicht sinn.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Effizient erstellen en Rust vector aus engem onsécherem Puffer:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` muss fir seng Aart an Net-Null richteg ausgeriicht sinn.
/// /// * `ptr` musse valabel si fir d'Liese vun `elts` ugestouss Elementer vum Typ `T`.
/// /// * Dës Elementer däerfen net benotzt ginn nodeems Dir dës Funktioun opgeruff hutt ausser `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // SAFETY: Eis Viraussetzung garantéiert datt d'Quell ausgeriicht a valabel ass,
///     // an `Vec::with_capacity` garantéiert datt mir brauchbar Plaz hunn fir se ze schreiwen.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // SAFETY: Mir hunn et mat dëser viller Kapazitéit fréier erstallt,
///     // an de fréiere `copy` huet dës Elementer initialiséiert.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Maacht dës Kontrollen nëmmen a Laafzäit
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Net panikéieren fir Codegen Impakt méi kleng ze halen.
        abort();
    }*/

    // SAFETY: de Sécherheetsvertrag fir `copy` muss vum Uruff oprechterhale ginn.
    unsafe { copy(src, dst, count) }
}

/// Setzt `count * size_of::<T>()` Bytes vum Gedächtnis ugefaange bei `dst` bis `val`.
///
/// `write_bytes` ass ähnlech wéi C's [`memset`], awer setzt `count * size_of::<T>()` Bytes op `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Verhalen ass ondefinéiert wann eng vun de folgende Konditioune verletzt gëtt:
///
/// * `dst` muss [valid] sinn fir `count * size_of::<T>()` Bytes ze schreiwen.
///
/// * `dst` musse richteg ausgeriicht sinn.
///
/// Zousätzlech muss den Uruffer dofir suergen datt `count * size_of::<T>()` Bytes an déi gegebene Speicherregioun zu engem gültege Wäert vun `T` resultéiert.
/// Eng Regioun vu Gedächtnis ze benotzen déi als `T` getippt gëtt an en ongëltege Wäert vun `T` enthält ass ondefinéiert Verhalen.
///
/// Bedenkt datt och wann déi effektiv kopéiert Gréisst (`count * size_of: :<T>()`) ass `0`, de Zeiger muss net NULL sinn a richteg ausgeriicht sinn.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Basis Benotzung:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// En ongëltege Wäert erstellen:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Leckt de virdru gehalene Wäert andeems Dir den `Box<T>` mat engem Nullzeiger iwwerschreift.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Zu dësem Zäitpunkt benotzt oder fällt `v` Resultater am ondefinéiert Verhalen.
/// // drop(v); // ERROR
///
/// // Och `v` "uses" leckert et, an dofir ass ondefinéiert Verhalen.
/// // mem::forget(v); // ERROR
///
/// // Tatsächlech ass `v` ongëlteg no Basis Typ Layout Invararianer, also *all* Operatioun déi et beréiert ass ondefinéiert Verhalen.
/////
/// // loosst v2 =v;//FEELER
///
/// unsafe {
///     // Loosst eis statt e gültege Wäert setzen
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Elo ass d'Këscht gutt
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // SAFETY: de Sécherheetsvertrag fir `write_bytes` muss vum Uruff oprechterhale ginn.
    unsafe { write_bytes(dst, val, count) }
}