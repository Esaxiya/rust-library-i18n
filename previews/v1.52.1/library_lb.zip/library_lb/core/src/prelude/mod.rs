//! D'libcore prelude
//!
//! Dëst Modul ass fir Benotzer vu libcore geduecht déi och net op libstd verknëppelen.
//! Dëse Modul gëtt standardméisseg importéiert wann `#![no_std]` op déiselwecht Aart a Weis wéi d'prelude vun der Standardbibliothéik benotzt gëtt.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// D'2015 Versioun vum Kär prelude.
///
/// Kuckt de [module-level documentation](self) fir méi.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// D'2018 Versioun vum Kär prelude.
///
/// Kuckt de [module-level documentation](self) fir méi.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// D'2021 Versioun vum Kär prelude.
///
/// Kuckt de [module-level documentation](self) fir méi.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Füügt méi Saache bäi.
}