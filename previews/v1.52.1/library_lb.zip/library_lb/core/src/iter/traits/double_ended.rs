use crate::ops::{ControlFlow, Try};

/// En Iterator deen Elementer vu béiden Enden ergëtt.
///
/// Eppes wat `DoubleEndedIterator` implementéiert huet eng extra Fäegkeet iwwer eppes wat [`Iterator`] implementéiert: d'Fäegkeet fir och "Artikel" vun hannen ze huelen, souwéi d'Front.
///
///
/// Et ass wichteg ze bemierken datt béid hin an hier am selwechte Beräich funktionnéieren, an net kräizen: d'Iteratioun ass eriwwer wa se an der Mëtt treffen.
///
/// An enger ähnlecher Aart wéi den [`Iterator`] Protokoll, wann e `DoubleEndedIterator` [`None`] vun engem [`next_back()`] zréckbréngt, nennt et erëm [`Some`] zréck oder net.
/// [`next()`] an [`next_back()`] sinn austauschbar fir dësen Zweck.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Basis Benotzung:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Läscht an zréck en Element aus dem Enn vum Iterator.
    ///
    /// Retour `None` wann et net méi Elementer gëtt.
    ///
    /// D [trait-level] Dokumenter enthalen méi Detailer.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// D'Elementer déi duerch "DoubleEndedIterator" Methoden erginn kënnen ënnerscheede sech vun deene vun ["Iterator"] Methoden:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Féiert d'Iterator vun hannen duerch `n` Elementer vir.
    ///
    /// `advance_back_by` ass d'Réckversioun vun [`advance_by`].Dës Method iwwerspréngt gären `n` Elementer, déi vun hannen ufänken, andeems se [`next_back`] bis `n` mol uruffen, bis [`None`] gestouss ass.
    ///
    /// `advance_back_by(n)` wäert [`Ok(())`] zréckbréngen wann den Iterator mat Erfolleg vun `n` Elementer virukënnt, oder [`Err(k)`] wann [`None`] begéint ass, wou `k` d'Zuel vun den Elementer ass, déi den Iterator virgezunn ass ier en aus Elementer leeft
    /// d'Längt vum Iterator).
    /// Bedenkt datt `k` ëmmer manner wéi `n` ass.
    ///
    /// `advance_back_by(0)` uruffen verbraucht keng Elementer an ëmmer zréck [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // nëmmen `&3` gouf iwwersprongen
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Nees den 'n'th Element vum Enn vum Iterator.
    ///
    /// Dëst ass wesentlech déi ëmgedréint Versioun vum [`Iterator::nth()`].
    /// Obwuel wéi déi meescht Indexéierungsoperatiounen, fänkt de Grof vun Null un, sou datt den `nth_back(0)` den éischte Wäert vum Enn zréckgeet, den `nth_back(1)` deen zweeten, a sou weider.
    ///
    ///
    /// Bedenkt datt all Elementer tëscht dem Enn an dem zréckgezunnen Element verbraucht ginn, och dat zréckkommt Element.
    /// Dëst bedeit och datt `nth_back(0)` méi oft op deem selwechten Iterator urufft verschidden Elementer zréckbréngt.
    ///
    /// `nth_back()` wäert [`None`] zréckbréngen wann `n` méi grouss wéi oder gläich wéi d'Längt vum Itator ass.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// `nth_back()` méi oft uruffen réckelt den Iterator net zréck:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// `None` zréckzeginn wann et manner wéi `n + 1` Elementer sinn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Dëst ass d'Réckversioun vum [`Iterator::try_fold()`]: et hëlt Elementer un, déi vun der Réck vum Itator ufänken.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Well et kuerzgeschloen ass, sinn déi reschtlech Elementer nach ëmmer iwwer den Iterator verfügbar.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Eng Iteratormethod déi d'Iterator Elementer op een eenzegen, endgültege Wäert reduzéiert, ab der Réck.
    ///
    /// Dëst ass d'Réckversioun vum [`Iterator::fold()`]: et hëlt Elementer un, déi vun der Réck vum Itator ufänken.
    ///
    /// `rfold()` hëlt zwee Argumenter: en éischte Wäert, an eng Zoumaache mat zwee Argumenter: en 'accumulator', an en Element.
    /// D'Fermeture bréngt de Wäert zréck deen den Akkumulator fir déi nächst Iteratioun soll hunn.
    ///
    /// Den initialen Wäert ass de Wäert deen den Akkumulator beim éischten Uruff huet.
    ///
    /// Nodeems dës Zoumaache fir all Element vum Iterator applizéiert gouf, gëtt `rfold()` den Akkumulator zréck.
    ///
    /// Dës Operatioun gëtt heiansdo 'reduce' oder 'inject' genannt.
    ///
    /// Folding ass nëtzlech wann Dir eng Sammlung vun eppes hutt, an een eenzege Wäert doraus produzéiere wëllt.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // der Zomm vun all den Elementer vun engem
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Dëst Beispill baut eng String, fänkt mat engem initialen Wäert un a féiert mat all Element vun hannen bis vir un:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Sich no engem Element vun engem Iterator vum Réck, deen e Predikat erfëllt.
    ///
    /// `rfind()` hëlt eng Fermeture déi `true` oder `false` zréckbréngt.
    /// Et gëlt dës Zoumaache fir all Element vum Iterator, fänkt um Enn un, a wann ee vun hinnen `true` zréckbréngt, da gëtt `rfind()` [`Some(element)`] zréck.
    /// Wann se all `false` zréckginn, gëtt et [`None`] zréck.
    ///
    /// `rfind()` ass kuerz-Circuit;an anere Wierder, et hält d'Veraarbechtung op soubal d'Zoumaache `true` zréckbréngt.
    ///
    /// Well `rfind()` eng Referenz hëlt, a vill Iteratoren iwwer Referenzen iteréieren, féiert dëst zu enger eventuell konfus Situatioun wou d'Argument eng duebel Referenz ass.
    ///
    /// Dir kënnt dësen Effekt an de Beispiller hei ënnen gesinn, mat `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Stop beim éischten `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // mir kënnen nach ëmmer `iter` benotzen, well et méi Elementer ginn.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}