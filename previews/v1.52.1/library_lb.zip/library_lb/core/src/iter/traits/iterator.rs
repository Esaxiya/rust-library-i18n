// ignoréieren-uerdentlech-Dateilängt Dës Datei besteet bal ausschliisslech aus der Definitioun vun `Iterator`.
// Mir kënnen dat net a méi Dateie splécken.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Eng Interface fir mat Iteratoren ëmzegoen.
///
/// Dëst ass den Haapt iterator trait.
/// Fir méi iwwer d'Konzept vun Iteratoren allgemeng, kuckt weg d [module-level documentation].
/// Besonnesch, Dir wëllt wësse wéi [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Déi Zort vun den Elementer déi iwwer iteréiert ginn.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Fortschrëtt den Iterator a bréngt den nächste Wäert zréck.
    ///
    /// Retour [`None`] wann d'Iteratioun fäerdeg ass.
    /// Eenzel Iterator-Implementatiounen kënnen wielen d'Iteratioun erëm opzehuelen, a sou kann een den `next()` erëm uruffen eventuell [`Some(Item)`] iergendwann erëm zréckginn.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // En Uruff op next() bréngt den nächste Wäert zréck ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... an dann Keen eemol et eriwwer ass.
    /// assert_eq!(None, iter.next());
    ///
    /// // Méi Uriff kënnen `None` zréckginn oder net.Hei wäerte se ëmmer.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Gitt d'Grenzen op déi reschtlech Längt vum Iterator zréck.
    ///
    /// Besonnesch `size_hint()` bréngt eng Tuple zréck wou dat éischt Element déi ënnescht Grenz ass, an dat zweet Element déi iewescht Grenz ass.
    ///
    /// Déi zweet Halschent vun der Tuple, déi zréckkomm ass, ass eng [`Option`]`<`[`usize`] `>".
    /// A [`None`] hei heescht datt entweder et kee bekannten Uewergrenz ass, oder datt d'Uewergrenz méi grouss ass wéi [`usize`].
    ///
    /// # Implementéierungsnotizen
    ///
    /// Et gëtt net duerchgesat datt eng Iterator-Implementatioun déi deklaréiert Zuel vun Elementer ergëtt.E Buggy-Iterator ka manner wéi déi ënnescht Grenz oder méi wéi d'Uewergrenz vun Elementer ginn.
    ///
    /// `size_hint()` ass haaptsächlech fir Optimisatiounen benotzt ze ginn, wéi zum Beispill Plaz fir d'Elementer vum Iterator ze reservéieren, awer däerf net vertraut sinn, zB Grenzkontrollen an onsécherem Code auszeleeën.
    /// Eng falsch Ëmsetzung vun `size_hint()` soll net zu Gedächtnis Sécherheetsverletzunge féieren.
    ///
    /// Wéi gesot, d'Ëmsetzung sollt eng korrekt Estimatioun ubidden, well soss wier et eng Verletzung vum trait Protokoll.
    ///
    /// D'Standardimplementatioun bréngt "(0," ["Keen"] ") zréck" wat fir all Iterator korrekt ass.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// E méi komplex Beispill:
    ///
    /// ```
    /// // Déi gläich Zuelen vun null op zéng.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Mir kënne vu null bis zéng Mol iteréieren.
    /// // Wësse datt et fënnef ass, wier net méiglech ouni filter() auszeféieren.
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Loosst eis fënnef weider Zuelen mat chain() bäifügen
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // elo ginn déi zwou Grenzen ëm fënnef eropgesat
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// `None` fir eng iewescht Grenz zréckzeginn:
    ///
    /// ```
    /// // en onendlechen Iterator huet keng Uewergrenz an déi maximal méiglech ënnescht Grenz
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Verbraucht den Iterator, zielt d'Zuel vun Iteratiounen an zréck.
    ///
    /// Dës Method wäert [`next`] ëmmer ruffen bis [`None`] gestouss ass, d'Zuel vun den Zäite wou se [`Some`] gesinn huet zréck.
    /// Bedenkt datt [`next`] op d'mannst eemol muss ugeruff ginn och wann de Iterator keng Elementer huet.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Iwwerlaf Verhalen
    ///
    /// D'Methode schützt net géint Iwwerlaf, sou datt Elementer vun engem Iterator mat méi wéi [`usize::MAX`] Elementer entweder dat falscht Resultat oder panics produzéieren.
    ///
    /// Wann Debug Behaaptungen aktivéiert sinn, ass en panic garantéiert.
    ///
    /// # Panics
    ///
    /// Dës Funktioun kéint panic wann den Iterator méi wéi [`usize::MAX`] Elementer huet.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Verbraucht den Iterator, bréngt dat lescht Element zréck.
    ///
    /// Dës Method wäert den Iterator evaluéieren bis en [`None`] zréckbréngt.
    /// Dobäi hält et dem aktuellen Element no.
    /// Nodeems [`None`] zréckkomm ass, wäert `last()` dann dat lescht Element zréckginn, dat et gesinn huet.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Fortschrëtt den Iterator duerch `n` Elementer.
    ///
    /// Dës Method iwwerspréngt gären `n` Elementer andeems en [`next`] bis `n` mol rufft bis [`None`] begéint ass.
    ///
    /// `advance_by(n)` wäert [`Ok(())`][Ok] zréckbréngen wann den Iterator erfollegräich mat `n` Elementer virukënnt, oder [`Err(k)`][Err] wann [`None`] begéint ass, wou `k` d'Zuel vun den Elementer ass, déi de Iterator virgezunn ass ier en aus Elementer leeft (dh
    /// d'Längt vum Iterator).
    /// Bedenkt datt `k` ëmmer manner wéi `n` ass.
    ///
    /// `advance_by(0)` uruffen verbraucht keng Elementer an ëmmer zréck [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // nëmmen `&4` gouf iwwersprongen
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Nees den 'n'th Element vum Iterator.
    ///
    /// Wéi déi meescht Indexéierungsoperatiounen fänkt de Grof vun Null un, sou datt den `nth(0)` den éischte Wäert zréckbréngt, den `nth(1)` deen zweeten, a sou weider.
    ///
    /// Bedenkt datt all virdrun Elementer, souwéi dat zréckkommt Element, vum Iterator verbraucht ginn.
    /// Dat heescht datt déi viregt Elementer verworf ginn, an och datt `nth(0)` méi oft op deem selwechten Iterator urufft verschidden Elementer zréckginn.
    ///
    ///
    /// `nth()` wäert [`None`] zréckbréngen wann `n` méi grouss wéi oder gläich wéi d'Längt vum Itator ass.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// `nth()` méi oft uruffen réckelt den Iterator net zréck:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// `None` zréckzeginn wann et manner wéi `n + 1` Elementer sinn:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Erstellt en Iterator dee fänkt um selwechte Punkt un, awer trëtt mat deem gegebene Betrag bei all Iteratioun.
    ///
    /// Notiz 1: Dat éischt Element vum Iterator gëtt ëmmer zréckginn, onofhängeg vum Schrëtt.
    ///
    /// Notiz 2: D'Zäit zu där ignoréiert Elementer gezunn ginn ass net fixéiert.
    /// `StepBy` behëlt sech wéi d'Sequenz `next(), nth(step-1), nth(step-1),…`, awer ass och fräi wéi d'Sequenz ze behuelen
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Wéi eng Aart a Weis benotzt ka fir verschidden Iteratoren aus Performance Grënn änneren.
    /// Den zweete Wee féiert den Iterator méi fréi a ka méi Saache konsuméieren.
    ///
    /// `advance_n_and_return_first` ass gläichwäerteg vun:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// D'Method wäert panic wann de gegebene Schrëtt `0` ass.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Huelt zwee Iteratoren a kreéiert en neien Iterator iwwer béid an der Sequenz.
    ///
    /// `chain()` bréngt en neien Iterator zréck, deen als éischt iwwer Wäerter vum éischten Iterator iteréiert an dann iwwer Wäerter vum zweeten Iterator.
    ///
    /// An anere Wierder, et verbënnt zwee Iteratoren zesummen, an enger Kette.🔗
    ///
    /// [`once`] gëtt allgemeng benotzt fir een eenzege Wäert an eng Kette vun aneren Aarte vun Impressioun unzepassen.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Well d'Argument op `chain()` [`IntoIterator`] benotzt, kënne mir alles weiderginn, wat an en [`Iterator`] ëmgewandelt ka ginn, net nëmmen en [`Iterator`] selwer.
    /// Zum Beispill, Scheiwen (`&[T]`) implementéieren [`IntoIterator`], a kënne sou direkt op `chain()` weidergeleet ginn:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Wann Dir mat Windows API schafft, wëllt Dir [`OsStr`] op `Vec<u16>` konvertéieren:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Zips' zwee Iteratoren an een eenzegen Iterator vu Puer op.
    ///
    /// `zip()` bréngt en neien Iterator zréck, deen iwwer zwee aner Iterator iteréiert, an en Tupel zréckbréngt, wou dat éischt Element aus dem éischten Iterator kënnt, an dat zweet Element aus dem zweeten Iterator kënnt.
    ///
    ///
    /// An anere Wierder, zips zwee Iteratoren zesummen, an eng eenzeg.
    ///
    /// Wann entweder Iterator [`None`] zréckbréngt, gëtt [`next`] aus dem zippéierten Iterator [`None`] zréck.
    /// Wann den éischten Iterator [`None`] zréckkoum, wäert den `zip` kuerz-Circuit maachen an den `next` gëtt net op der zweeter Iterator geruff.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Well d'Argument op `zip()` [`IntoIterator`] benotzt, kënne mir alles weiderginn, wat an en [`Iterator`] ëmgewandelt ka ginn, net nëmmen en [`Iterator`] selwer.
    /// Zum Beispill, Scheiwen (`&[T]`) implementéieren [`IntoIterator`], a kënne sou direkt op `zip()` weidergeleet ginn:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` gëtt dacks benotzt fir en onendlechen Iterator zu engem endlechen ze zip.
    /// Dëst funktionnéiert well de finite Iterator eventuell [`None`] zréckbréngt an den Zipper z'erreechen.Zipping mat `(0..)` ka vill wéi [`enumerate`] ausgesinn:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Erstellt en neien Iterator deen eng Kopie vum `separator` tëscht Nopesch Elementer vum Original Iterator plazéiert.
    ///
    /// Am Fall wou `separator` net [`Clone`] implementéiert oder all Kéier muss berechent ginn, benotzt [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Dat éischt Element vun `a`.
    /// assert_eq!(a.next(), Some(&100)); // De Separator.
    /// assert_eq!(a.next(), Some(&1));   // Dat nächst Element vun `a`.
    /// assert_eq!(a.next(), Some(&100)); // De Separator.
    /// assert_eq!(a.next(), Some(&2));   // Déi lescht Element vun `a`.
    /// assert_eq!(a.next(), None);       // Den Iterator ass fäerdeg.
    /// ```
    ///
    /// `intersperse` ka ganz nëtzlech sinn fir Artikele vun engem Itator mat engem gemeinsamen Element matzemaachen:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Erstellt en neien Iterator deen en Element generéiert vum `separator` tëscht Nopesch Elementer vum Original Iterator plazéiert.
    ///
    /// D'Fermeture gëtt genau eemol genannt all Kéier wann en Element tëscht zwee ugrenzend Elementer aus dem Basisgrond Iterator plazéiert ass;
    /// speziell ass d'Schléissung net genannt wann de Basislidder Iterator manner wéi zwee Elementer liwwert an nom leschte Element noginn ass.
    ///
    ///
    /// Wann den Iterator Element [`Clone`] implementéiert, kann et méi einfach sinn [`intersperse`] ze benotzen.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Dat éischt Element vun `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // De Separator.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Dat nächst Element vun `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // De Separator.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Dat lescht Element vu vun `v`.
    /// assert_eq!(it.next(), None);               // Den Iterator ass fäerdeg.
    /// ```
    ///
    /// `intersperse_with` kann a Situatiounen benotzt ginn, wou de Separator muss berechent ginn:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // D'Fermeture léint mutativ säi Kontext fir en Element ze generéieren.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Maacht eng Zoumaache a kreéiert en Iterator deen dës Ofschloss op all Element nennt.
    ///
    /// `map()` transforméiert een Iterator an en aneren, duerch säin Argument:
    /// eppes wat [`FnMut`] implementéiert.Et produzéiert en neien Iterator deen dës Schließung op all Element vum Original Itator nennt.
    ///
    /// Wann Dir gutt sidd an Typen ze denken, kënnt Dir un `map()` esou denken:
    /// Wann Dir en Iterator hutt deen Iech Elementer vun engem Typ `A` gëtt, an Dir wëllt en Iterator vun engem aneren Typ `B`, kënnt Dir `map()` benotzen, andeems Dir eng Zoumaache passéiert déi en `A` hëlt an en `B` zréckbréngt.
    ///
    ///
    /// `map()` ass konzeptuell ähnlech wéi eng [`for`] Loop.Wéi och ëmmer, well `map()` faul ass, gëtt et am beschten benotzt wann Dir scho mat aneren Iteratoren schafft.
    /// Wann Dir eng Zort Looping fir e Nieweneffekt maacht, gëtt et als méi idiomatesch ugesinn [`for`] wéi `map()` ze benotzen.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Wann Dir eng Zort Nieweneffekt maacht, léiwer [`for`] op `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // maach dat net:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // et wäert net emol ausféieren, well et faul ass.Rust warnt Iech iwwer dëst.
    ///
    /// // Amplaz, benotzt fir:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Nennt eng Ofschlossung op all Element vun engem Iterator.
    ///
    /// Dëst entsprécht der Benotzung vun enger [`for`] Loop um Itator, och wann `break` an `continue` net méiglech sinn aus enger Fermeture.
    /// Et ass normalerweis méi idiomatesch eng `for` Loop ze benotzen, awer `for_each` ka méi liesbar sinn wann Dir Artikelen um Enn vu méi laange Iteratorketten veraarbecht.
    ///
    /// A verschiddene Fäll kann `for_each` och méi séier si wéi eng Loop, well et intern Iteratioun op Adaptere wéi `Chain` benotzt.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Fir sou e klengt Beispill kann eng `for` Loop méi propper sinn, awer `for_each` kéint léiwer si fir e funktionelle Stil mat méi laange Itatoren ze halen:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Erstellt en Iterator deen eng Zoumaache benotzt fir festzestellen ob en Element soll ginn.
    ///
    /// Gitt en Element, muss de Fermeture `true` oder `false` zréckbréngen.Den zréckgoen Iterator bréngt nëmmen d'Elementer fir déi d'Zoumaache stëmmt.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Well d'Zoumaache vun der `filter()` eng Referenz hëlt, a vill Iteratoren iwwer Referenze iteréieren, féiert dat zu enger méiglecher konfuser Situatioun, wou d'Art vun der Zoumaache eng duebel Referenz ass:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // brauch zwee * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Et ass heefeg amplaz destrukturéierend am Argument ze benotzen fir eent ze entfernen:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // béid&an *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// oder béid:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // zwee &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// vun dëse Schichten.
    ///
    /// Bedenkt datt `iter.filter(f).next()` entsprécht `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Erstellt en Iterator dee souwuel filtert wéi och Kaarten.
    ///
    /// Den zréckgoen Iterator liwwert nëmmen de "Wäert" fir deen déi geliwwert Zoumaache `Some(value)` zréckbréngt.
    ///
    /// `filter_map` kënne benotzt ginn fir Ketten vun [`filter`] an [`map`] méi präzis ze maachen.
    /// D'Beispill hei ënnendrënner weist wéi en `map().filter().map()` zu engem eenzegen Uruff op `filter_map` verkierzt ka ginn.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Hei ass datselwecht Beispill, awer mat [`filter`] an [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Erstellt en Iterator deen den aktuellen Iterationszuel gëtt wéi och den nächste Wäert.
    ///
    /// Den Iterator zréckkomm bréngt Pairen `(i, val)`, wou `i` den aktuellen Index vun der Impressioun ass an den `val` de Wäert vum Iterator ass.
    ///
    ///
    /// `enumerate()` hält seng Zuel als [`usize`].
    /// Wann Dir mat enger anerer Gréisst ganz ziele wëllt, gëtt d [`zip`] Funktioun ähnlech Funktionalitéit.
    ///
    /// # Iwwerlaf Verhalen
    ///
    /// D'Methode schützt net géint Iwwerlaf, sou datt méi wéi [`usize::MAX`] Elementer opgezielt ginn entweder dat falscht Resultat oder panics produzéiert.
    /// Wann Debug Behaaptungen aktivéiert sinn, ass en panic garantéiert.
    ///
    /// # Panics
    ///
    /// Den zréckgoen Iterator kéint panic wann den ze ginn zréck Index en [`usize`] iwwerschwemmt.
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Erstellt en Iterator deen [`peek`] benotze kann fir dat nächst Element vum Iterator ze kucken ouni et ze verbrauchen.
    ///
    /// Füügt eng [`peek`] Method op en Iterator bäi.Kuckt seng Dokumentatioun fir méi Informatioun.
    ///
    /// Bedenkt datt den zugronnenden Iterator nach fortgeschratt ass wann den [`peek`] fir d'éischt geruff gëtt: Fir dat nächst Element erëmzefannen, gëtt [`next`] op de Basis Iterator geruff, dofir Niewewierkungen (d.h.
    ///
    /// alles anescht wéi den nächste Wäert ze sichen) vun der [`next`] Method wäert optrieden.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() loosst eis an d'future kucken
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // mir kënnen peek() méi Mol, den Iterator geet net virun
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // nom Iterator fäerdeg ass och peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Erstellt en Iterator deen [`Skip`] Elementer baséieren op engem Predikat.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` hëlt eng Zoumaache als Argument.Et nennt dës Schließung op all Element vum Iterator, an ignoréiert Elementer bis et `false` zréckgeet.
    ///
    /// Nodeems `false` zréck ass, ass `skip_while()`'s Aarbecht eriwwer, an de Rescht vun den Elementer ginn erginn.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Well d'Zoumaache vun der `skip_while()` eng Referenz hëlt, a vill Iteratoren iwwer Referenzen iteréieren, féiert dëst zu enger méiglecher konfuser Situatioun, wou d'Art vum Schließargument eng duebel Referenz ass:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // brauch zwee * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stoppen no engem éischte `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // wärend dëst falsch gewiescht wier, well mer scho falsch hunn, gëtt skip_while() net méi benotzt
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Erstellt en Iterator deen Elementer gëtt op Basis vun engem Predikat.
    ///
    /// `take_while()` hëlt eng Zoumaache als Argument.Et nennt dës Schließung op all Element vum Iterator, a gitt Elementer wärend et `true` zréckbréngt.
    ///
    /// Nom `false` zréck ass, ass `take_while()`'s Aarbecht eriwwer, an de Rescht vun den Elementer ginn ignoréiert.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Well d'Zoumaache vun `take_while()` eng Referenz hëlt, a vill Iteratoren iwwer Referenze iteréieren, féiert dat zu enger méiglecher konfuser Situatioun, wou d'Art vun der Zoumaache eng duebel Referenz ass:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // brauch zwee * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stoppen no engem éischte `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Mir hu méi Elementer déi manner wéi Null sinn, awer well mer scho falsch sinn, gëtt take_while() net méi benotzt
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Well `take_while()` de Wäert muss ukucke fir ze kucken ob e sollt mat abegraff sinn oder net, konsuméiere Iteratoren gesinn datt e geläscht gëtt:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// Den `3` ass net méi do, well et gouf verbraucht fir ze kucken ob d'Iteratioun sollt ophalen, awer net an den Iterator plazéiert ass.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Erstellt en Iterator dee béid Elementer leet baséiert op engem Predikat a Kaarten.
    ///
    /// `map_while()` hëlt eng Zoumaache als Argument.
    /// Et nennt dës Schließung op all Element vum Iterator, a gitt Elementer wärend et [`Some(_)`][`Some`] zréckbréngt.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Hei ass datselwecht Beispill, awer mat [`take_while`] an [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stoppen no engem éischte [`None`]:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Mir hu méi Elementer déi an u32 (4, 5) passen, awer `map_while` huet `None` fir `-3` zréckgezunn (wéi den `predicate` `None` zréckkoum) an `collect` stoppt bei der éischter `None` begéint.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Well `map_while()` de Wäert muss ukucke fir ze kucken ob e sollt mat abegraff sinn oder net, konsuméiere Iteratoren gesinn datt e geläscht gëtt:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// Den `-3` ass net méi do, well et gouf verbraucht fir ze kucken ob d'Iteratioun sollt ophalen, awer net an den Iterator plazéiert ass.
    ///
    /// Bedenkt datt am Géigesaz zu [`take_while`] dësen Iterator **net** fusionéiert ass.
    /// Et gëtt och net spezifizéiert wat dësen Iterator erëmkënnt nodeems den éischte [`None`] zréck ass.
    /// Wann Dir fusionéiert Iterator braucht, benotzt [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Erstellt en Iterator deen déi éischt `n` Elementer iwwerspréngt.
    ///
    /// Nodeems se verbraucht goufen, ginn de Rescht vun den Elementer erginn.
    /// Anstatt dës Method direkt ze iwwerschreiden, amplaz d `nth` Method z'iwwerschreiwen.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Erstellt en Iterator deen seng éischt `n` Elementer gëtt.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` gëtt dacks mat engem onendlechen Iterator benotzt, fir et endlech ze maachen:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Wa manner wéi `n` Elementer verfügbar sinn, limitéiert `take` sech op d'Gréisst vum Basis Iterator:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// En Iteratoradapter ähnlech wéi [`fold`] deen internen Zoustand hält an en neien Iterator produzéiert.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` hëlt zwee Argumenter: en Ufankswäert deen den internen Zoustand seet, an eng Zoumaache mat zwee Argumenter, déi éischt eng mutéierbar Referenz op den internen Zoustand an déi zweet en iterator Element.
    ///
    /// D'Schléissung kann dem internen Zoustand zielen fir de Staat tëscht Iteratiounen ze deelen.
    ///
    /// Op Iteratioun gëtt d'Zoumaache fir all Element vum Iterator applizéiert an de Retourwäert vun der Zoumaache, en [`Option`], gëtt vum Iterator erginn.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // all Iteratioun multiplizéieren mir de Staat mam Element
    ///     *state = *state * x;
    ///
    ///     // da gi mir d'Negatioun vum Staat
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Erstellt en Iterator dee funktionnéiert wéi eng Kaart, awer eng verschaffte Struktur verflaacht.
    ///
    /// Den [`map`] Adapter ass ganz nëtzlech, awer nëmmen wann de Schließargument Wäerter produzéiert.
    /// Wann et en Iterator produzéiert amplaz, ass et eng extra Schicht vun Indirektioun.
    /// `flat_map()` wäert dës extra Schicht eleng ewechhuelen.
    ///
    /// Dir kënnt den `flat_map(f)` als semantescht Äquivalent vum [`map`] Ping denken, an duerno [`flaach`] wéi an `map(f).flatten()`.
    ///
    /// Eng aner Manéier fir iwwer `flat_map()` ze denken: ['map'] 's Zoumaache bréngt een Element fir all Element zréck, an `flat_map()`'s Zoumaache bréngt en Iterator fir all Element zréck.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() bréngt en Iterator zréck
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Erstellt en Iterator deen déi verschaffte Struktur platt mécht.
    ///
    /// Dëst ass nëtzlech wann Dir en Iterator vun Iteratoren oder en Iterator vu Saachen hutt déi zu Iteratoren kënne ginn an Dir wëllt een Niveau vun der Indirektioun läschen.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Mapping an duerno flaach:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() bréngt en Iterator zréck
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Dir kënnt dëst och a Saache [`flat_map()`] ëmschreiwen, wat an dësem Fall léiwer ass, well et d'Intent méi kloer vermëttelt:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() bréngt en Iterator zréck
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Offlaachung hëlt nëmmen een Niveau vun der Nistung gläichzäiteg ewech:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Hei gesi mir datt `flatten()` keng "deep" Fläch mécht.
    /// Amplaz gëtt nëmmen een Niveau vun der Nistung ewechgeholl.Dat ass, wann Dir en dreidimensionalen Array `flatten()` hutt, gëtt d'Resultat zweedimensional an net eendimensional.
    /// Fir eng eendimensional Struktur ze kréien, musst Dir erëm `flatten()`.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Erstellt en Iterator deen nom éischten [`None`] endet.
    ///
    /// Nodeems en Iterator [`None`] zréckbréngt, kënnen future Uriff [`Some(T)`] erëm erabréngen.
    /// `fuse()` passt en Iterator un, a garantéiert datt no engem [`None`] gëtt et ëmmer [`None`] zréck.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// // en Iterator deen alternéiert tëscht Some a None
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // wann et souguer ass, Some(i32), soss Keen
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // mir kënnen eisen Iterator hin an hier gesinn
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // awer eemol mir et fusionéieren ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // et wäert ëmmer `None` no der éischter Kéier zréckkommen.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Maacht eppes mat all Element vun engem Iterator, weiderginn de Wäert weider.
    ///
    /// Wann Dir Iteratoren benotzt, keatst Dir dacks e puer vun hinnen zesummen.
    /// Wann Dir u sou engem Code schafft, wëllt Dir vläicht kucken wat op verschidden Deeler an der Pipeline geschitt.Fir dat ze maachen, gitt en Uruff op `inspect()`.
    ///
    /// Et ass méi heefeg datt `inspect()` als Debugging-Tool benotzt gëtt wéi et an Ärem finalen Code existéiert, awer Uwendungen kënnen et a gewësse Situatiounen nëtzlech fannen wann Feeler protokolléiert musse ginn ier se verworf ginn.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // dës Iterator-Sequenz ass komplex.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // loosst eis e puer inspect() Uriff bäifügen fir z'ënnersichen wat geschitt
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Dëst dréckt:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Feeler umellen ier se ewechgehäit ginn:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Dëst dréckt:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Prêt en Iterator, anstatt et ze konsuméieren.
    ///
    /// Dëst ass nëtzlech fir d'Iterator-Adapter z'applizéieren, wärend se nach ëmmer de Besëtz vum Original Iterator behalen.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // wa mir versichen iter erëm ze benotzen, da funktionnéiert et net.
    /// // Déi folgend Zeil gëtt "Feeler: Benotzung vum geréckte Wäert: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // probéiere mer dat nach eng Kéier
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // amplaz, addéiere mer an engem .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // elo ass dat just gutt:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Transforméiert en Iterator an eng Sammlung.
    ///
    /// `collect()` kann näischt iterabeles huelen, an et zu enger relevanter Sammlung maachen.
    /// Dëst ass eng vun de méi mächtege Methoden an der Standardbibliothéik, déi a verschiddene Kontexter benotzt ginn.
    ///
    /// Dat meescht Basis Muster an deem `collect()` benotzt gëtt ass eng Sammlung an eng aner ze maachen.
    /// Dir huelt eng Sammlung, rufft [`iter`] drop, maacht eng Rëtsch Transformatiounen, an dann `collect()` um Enn.
    ///
    /// `collect()` kann och Instanzen vun Typen erstellen déi net typesch Sammlungen sinn.
    /// Zum Beispill kann en [`String`] aus [`char`] gebaut ginn, an en Iterator vun [`Result<T, E>`][`Result`] Elementer kann an `Result<Collection<T>, E>` gesammelt ginn.
    ///
    /// Kuckt d'Beispiller hei ënnendrënner fir méi.
    ///
    /// Well `collect()` sou allgemeng ass, kann et Probleemer mat Type Inferenz verursaachen.
    /// Als sou ass `collect()` ee vun de wéinegen Zäiten déi Dir d'Syntax gesinn, déi als 'turbofish' bekannt ass: `::<>`.
    /// Dëst hëlleft den Inferenz Algorithmus speziell ze verstoen an wéi eng Sammlung Dir versicht ze sammelen.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Bedenkt datt mir den `: Vec<i32>` op der lénkser Säit gebraucht hunn.Dëst ass well mir an zum Beispill en [`VecDeque<T>`] amplaz sammele kënnen:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Mat der 'turbofish' amplaz `doubled` ze annotéieren:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Well `collect()` nëmmen drëm këmmert wat Dir sammelt, kënnt Dir ëmmer nach en deelweisen Tipp, `_`, mam Turbofish benotzen:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Mat `collect()` fir en [`String`] ze maachen:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Wann Dir eng Lëscht mat [`Resultat<T, E>`][`Resultat`] s, Dir kënnt `collect()` benotze fir ze kucken ob ee vun hinnen ausgefall ass:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // gitt eis den éischte Feeler
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // gitt eis d'Lëscht vun den Äntwerten
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Verbraucht en Iterator, kreéiert zwou Sammlungen dovun.
    ///
    /// De Predikat deen op `partition()` weiderginn ass, kann `true`, oder `false` zréckginn.
    /// `partition()` bréngt e Paar zréck, all d'Elementer fir déi et `true` zréckginn huet, an all Elementer fir déi et `false` zréckginn huet.
    ///
    ///
    /// Kuckt och [`is_partitioned()`] an [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Ordnéiert d'Elementer vun dësem Iterator *op der Plaz* no dem gegebene Predikat, sou datt all déi, déi `true` zréckkucken, virun all deenen, déi `false` zréckginn.
    ///
    /// Gitt d'Zuel vun de fonnt `true` Elementer zréck.
    ///
    /// Déi relativ Uerdnung vu partiséierten Elementer gëtt net oprechterhalen.
    ///
    /// Kuckt och [`is_partitioned()`] an [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Partition op der Plaz tëscht Gläicher a Quoten
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: solle mir eis Suergen iwwer de Grof iwwerschloen?Deen eenzege Wee fir méi wéi
        // `usize::MAX` mutéierbar Referenzen si mat ZSTs, déi net nëtzlech sinn fir ze partitionéieren ...

        // Dës Fermeture "factory" Funktiounen existéieren fir Generizitéit an `Self` ze vermeiden.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Fannt ëmmer erëm den éischte `false` a wiesselt et mat der leschter `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Kontrolléiert ob d'Elementer vun dësem Iterator no dem gegebene Predikat partitionéiert sinn, sou datt all déi, déi `true` zréckkommen, viru all déi, déi `false` zréckginn.
    ///
    ///
    /// Kuckt och [`partition()`] an [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Entweder all Elementer testen `true`, oder déi éischt Klausel stoppt bei `false` a mir kontrolléieren datt et net méi `true` Elementer duerno sinn.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Eng Iteratormethod déi eng Funktioun applizéiert soulaang se erfollegräich zréckkënnt an een eenzege leschte Wäert produzéiert.
    ///
    /// `try_fold()` hëlt zwee Argumenter: en éischte Wäert, an eng Zoumaache mat zwee Argumenter: en 'accumulator', an en Element.
    /// D'Fermeture kënnt entweder erfollegräich zréck, mat dem Wäert deen den Akkumulator fir déi nächst Iteratioun soll hunn, oder et gëtt e Feeler zréck, mat engem Feelerwäert deen direkt un den Uruff propagéiert gëtt (short-circuiting).
    ///
    ///
    /// Den initialen Wäert ass de Wäert deen den Akkumulator beim éischten Uruff wäert hunn.Wann d'Zoumaache vun der Zoumaache géint all Element vum Iterator gelongen ass, gëtt den `try_fold()` de Schlussakkumulator als Erfolleg zréck.
    ///
    /// Folding ass nëtzlech wann Dir eng Sammlung vun eppes hutt, an een eenzege Wäert doraus produzéiere wëllt.
    ///
    /// # Notiz fir Implementoren
    ///
    /// Verschidde vun den aneren (forward) Methoden hunn Standardimplementatiounen a Bezuch op dës, also probéiert et explizit ëmzesetzen wann et eppes besser maache kann wéi déi Standard `for` Loop-Implementatioun.
    ///
    /// Besonnesch probéiert dësen Uruff `try_fold()` op den internen Deeler ze hunn aus deem dësen Iterator komponéiert ass.
    /// Wa verschidde Ruffe gebraucht ginn, kann de `?` Betreiber bequem sinn fir den Akkumulatorwäert mateneen ze verbannen, awer passt op all Invarianer op, déi mussen oprecht erhalen ier déi fréi zréck ginn.
    /// Dëst ass eng `&mut self` Method, sou datt d'Iteratioun muss resumabel sinn nodeems Dir e Feeler hei getraff hutt.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // déi kontrolléiert Zomm vun allen Elementer vum Array
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Dës Zomm leeft iwwer wann een den 100 Element bäifügt
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Well et kuerzgeschloen ass, sinn déi reschtlech Elementer nach ëmmer iwwer den Iterator verfügbar.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Eng Iteratormethod déi eng falsch Funktioun op all Element am Iterator applizéiert, beim éischte Feeler stoppt an dee Feeler zréckbréngt.
    ///
    ///
    /// Dëst kann och als fallible Form vun [`for_each()`] oder als stateless Versioun vum [`try_fold()`] ugesi ginn.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Et huet kuerz geschalt, sou datt déi reschtlech Artikelen nach ëmmer am Iterator sinn:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Klappt all Element an en Akkumulator andeems en eng Operatioun applizéiert, an d'final Resultat zréckbréngt.
    ///
    /// `fold()` hëlt zwee Argumenter: en éischte Wäert, an eng Zoumaache mat zwee Argumenter: en 'accumulator', an en Element.
    /// D'Fermeture bréngt de Wäert zréck deen den Akkumulator fir déi nächst Iteratioun soll hunn.
    ///
    /// Den initialen Wäert ass de Wäert deen den Akkumulator beim éischten Uruff huet.
    ///
    /// Nodeems dës Zoumaache fir all Element vum Iterator applizéiert gouf, gëtt `fold()` den Akkumulator zréck.
    ///
    /// Dës Operatioun gëtt heiansdo 'reduce' oder 'inject' genannt.
    ///
    /// Folding ass nëtzlech wann Dir eng Sammlung vun eppes hutt, an een eenzege Wäert doraus produzéiere wëllt.
    ///
    /// Note: `fold()`, an ähnlech Methoden, déi de ganzen Iterator duerchsträichen, kënnen net fir onendlech Iteratoren ophalen, och net op traits fir déi e Resultat a begrenzter Zäit bestëmmbar ass.
    ///
    /// Note: [`reduce()`] kann benotzt ginn fir dat éischt Element als Ufankswäert ze benotzen, wann den Akkumulatortyp an den Artikeltyp d'selwecht ass.
    ///
    /// # Notiz fir Implementoren
    ///
    /// Verschidde vun den aneren (forward) Methoden hunn Standardimplementatiounen a Bezuch op dës, also probéiert et explizit ëmzesetzen wann et eppes besser maache kann wéi déi Standard `for` Loop-Implementatioun.
    ///
    ///
    /// Besonnesch probéiert dësen Uruff `fold()` op den internen Deeler ze hunn aus deem dësen Iterator komponéiert ass.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // d'Zomm vun all den Elementer vum Array
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Loosst eis duerch all Schrëtt vun der Iteratioun hei goen:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// An esou, eist lescht Resultat, `6`.
    ///
    /// Et ass heefeg fir Leit déi Iteratoren net vill benotzt hunn eng `for` Loop mat enger Lëscht vu Saachen ze benotzen fir e Resultat opzebauen.Déi kënnen an `fold()`s ëmgewandelt ginn:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // fir Loop:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // si sinn déi selwecht
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Reduzéiert d'Elementer zu engem eenzegen, andeems se ëmmer erëm eng reduzéierend Operatioun uwenden.
    ///
    /// Wann den Iterator eidel ass, gëtt [`None`] zréck;anescht, gëtt d'Resultat vun der Reduktioun zréck.
    ///
    /// Fir Iteratoren mat op d'mannst engem Element ass dat d'selwecht wéi [`fold()`] mat dem éischten Element vum Iterator als Ufankswäert, a fällt all uschléissend Element dran.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Fannt de maximale Wäert:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Tester wann all Element vum Iterator engem Predikat entsprécht.
    ///
    /// `all()` hëlt eng Fermeture déi `true` oder `false` zréckbréngt.Et gëlt dës Zoumaache fir all Element vum Iterator, a wa se all `true` zréckginn, da mécht et och `all()`.
    /// Wann ee vun hinnen `false` zréckbréngt, gëtt et `false` zréck.
    ///
    /// `all()` ass kuerzfristeg;an anere Wierder, et stoppt d'Veraarbechtung soubal et en `false` fënnt, well egal wat soss geschitt, d'Resultat wäert och `false` sinn.
    ///
    ///
    /// En eidelen Iterator gëtt `true` zréck.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Stop beim éischten `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // mir kënnen nach ëmmer `iter` benotzen, well et méi Elementer ginn.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Tester wann en Element vum Iterator engem Predikat entsprécht.
    ///
    /// `any()` hëlt eng Fermeture déi `true` oder `false` zréckbréngt.Et gëlt dës Schließung op all Element vum Iterator, a wann ee vun hinnen `true` zréckbréngt, da mécht et och `any()`.
    /// Wann se all `false` zréckginn, gëtt et `false` zréck.
    ///
    /// `any()` ass kuerzfristeg;an anere Wierder, et stoppt d'Veraarbechtung soubal et en `true` fënnt, well egal wat soss geschitt, d'Resultat wäert och `true` sinn.
    ///
    ///
    /// En eidelen Iterator gëtt `false` zréck.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Stop beim éischten `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // mir kënnen nach ëmmer `iter` benotzen, well et méi Elementer ginn.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Sich no engem Element vun engem Iterator deen e Predikat entsprécht.
    ///
    /// `find()` hëlt eng Fermeture déi `true` oder `false` zréckbréngt.
    /// Et gëlt dës Zoumaache fir all Element vum Iterator, a wann ee vun hinnen `true` zréckbréngt, da gëtt `find()` [`Some(element)`] zréck.
    /// Wann se all `false` zréckginn, gëtt et [`None`] zréck.
    ///
    /// `find()` ass kuerz-Circuit;an anere Wierder, et hält d'Veraarbechtung op soubal d'Zoumaache `true` zréckbréngt.
    ///
    /// Well `find()` eng Referenz hëlt, a vill Iteratoren iwwer Referenzen iteréieren, féiert dëst zu enger eventuell konfus Situatioun wou d'Argument eng duebel Referenz ass.
    ///
    /// Dir kënnt dësen Effekt an de Beispiller hei ënnen gesinn, mat `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Stop beim éischten `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // mir kënnen nach ëmmer `iter` benotzen, well et méi Elementer ginn.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Bedenkt datt `iter.find(f)` entsprécht `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Gëlt d'Funktioun fir d'Elementer vum Iterator a bréngt dat éischt net-kee Resultat zréck.
    ///
    ///
    /// `iter.find_map(f)` entsprécht `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Gëlt d'Funktioun fir d'Elementer vum Iterator a bréngt dat éischt richteg Resultat oder den éischte Feeler zréck.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Sich no engem Element an engem Iterator, zréckgëtt säin Index.
    ///
    /// `position()` hëlt eng Fermeture déi `true` oder `false` zréckbréngt.
    /// Et gëlt dës Zoumaache fir all Element vum Iterator, a wann ee vun hinnen `true` zréckbréngt, da gëtt `position()` [`Some(index)`] zréck.
    /// Wann all vun hinnen zréck `false`, et zréck [`None`].
    ///
    /// `position()` ass kuerzfristeg;an anere Wierder, et stoppt d'Veraarbechtung soubal et en `true` fënnt.
    ///
    /// # Iwwerlaf Verhalen
    ///
    /// D'Methode schützt net géint Iwwerlaf, also wann et méi wéi [`usize::MAX`] net-passende Elementer sinn, produzéiert se entweder dat falscht Resultat oder panics.
    ///
    /// Wann Debug Behaaptungen aktivéiert sinn, ass en panic garantéiert.
    ///
    /// # Panics
    ///
    /// Dës Funktioun kéint panic wann den Iterator méi wéi `usize::MAX` net-passende Elementer huet.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Stop beim éischten `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // mir kënnen nach ëmmer `iter` benotzen, well et méi Elementer ginn.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Den zréckgezunnene Index hänkt vum Iterator-Staat of
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Sich no engem Element an engem Iterator vu riets, zréckgëtt säin Index.
    ///
    /// `rposition()` hëlt eng Fermeture déi `true` oder `false` zréckbréngt.
    /// Et gëlt dës Zoumaache fir all Element vum Iterator, ab dem Enn, a wann ee vun hinnen `true` zréckbréngt, da gëtt `rposition()` [`Some(index)`] zréck.
    ///
    /// Wann all vun hinnen zréck `false`, et zréck [`None`].
    ///
    /// `rposition()` ass kuerzfristeg;an anere Wierder, et stoppt d'Veraarbechtung soubal et en `true` fënnt.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Stop beim éischten `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // mir kënnen nach ëmmer `iter` benotzen, well et méi Elementer ginn.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Kee Besoin fir en Iwwerlaf Kontroll hei, well `ExactSizeIterator` implizéiert datt d'Zuel vun Elementer an en `usize` passt.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Gitt de maximalen Element vun engem Iterator zréck.
    ///
    /// Wa verschidden Elementer gläich maximal sinn, gëtt dat lescht Element zréckginn.
    /// Wann den Iterator eidel ass, gëtt [`None`] zréck.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Gitt de Mindestelement vun engem Iterator zréck.
    ///
    /// Wann e puer Elementer gläich Minimum sinn, gëtt dat éischt Element zréck.
    /// Wann den Iterator eidel ass, gëtt [`None`] zréck.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Returns d'Element dat maximal Wäert vun der spezifizéierter Funktioun gëtt.
    ///
    ///
    /// Wa verschidden Elementer gläich maximal sinn, gëtt dat lescht Element zréckginn.
    /// Wann den Iterator eidel ass, gëtt [`None`] zréck.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Nees d'Element dat maximal Wäert gëtt mat Respekt un der spezifizéierter Verglach Funktioun.
    ///
    ///
    /// Wa verschidden Elementer gläich maximal sinn, gëtt dat lescht Element zréckginn.
    /// Wann den Iterator eidel ass, gëtt [`None`] zréck.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Nees d'Element dat de Mindestwäert vun der spezifizéierter Funktioun gëtt.
    ///
    ///
    /// Wann e puer Elementer gläich Minimum sinn, gëtt dat éischt Element zréck.
    /// Wann den Iterator eidel ass, gëtt [`None`] zréck.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Nees d'Element dat de Mindestwäert mat Bezuch op déi spezifizéiert Verglachfunktioun gëtt.
    ///
    ///
    /// Wann e puer Elementer gläich Minimum sinn, gëtt dat éischt Element zréck.
    /// Wann den Iterator eidel ass, gëtt [`None`] zréck.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Ëmgedréit d'Richtung vun engem Iterator.
    ///
    /// Normalerweis iteréieren iteréiere vu lénks no riets.
    /// Nom `rev()` benotzt gëtt en Iterator amplaz vu riets no lénks iteréiert.
    ///
    /// Dëst ass nëmme méiglech wann den Iterator en Enn huet, sou datt `rev()` nëmmen op [`DoubleEndedIterator`] funktionnéiert.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Konvertéiert en Iterator vu Puer an e puer Container.
    ///
    /// `unzip()` verbraucht e ganzen Iterator vu Puer, produzéiert zwou Sammlungen: eng vun de lénksen Elementer vun de Pairen, an eng vun de richtegen Elementer.
    ///
    ///
    /// Dës Funktioun ass, a gewësse Sënn, de Géigendeel vun [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Erstellt en Iterator deen all seng Elementer kopéiert.
    ///
    /// Dëst ass nëtzlech wann Dir en Iterator iwwer `&T` hutt, awer Dir braucht en Iterator iwwer `T`.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // kopéiert ass d'selwecht wéi .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Erstellt en Iterator deen ["Klon"] all seng Elementer ass.
    ///
    /// Dëst ass nëtzlech wann Dir en Iterator iwwer `&T` hutt, awer Dir braucht en Iterator iwwer `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // gekloont ass d'selwecht wéi .map(|&x| x), fir ganz Zuelen
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Widderhëlt en Iterator onendlech.
    ///
    /// Amplaz um [`None`] ze stoppen, fänkt den Iterator amplaz erëm un, vun Ufank un.Nodeems et erëm iteréiert huet, fänkt et erëm am Ufank un.An nach eng Kéier.
    /// An nach eng Kéier.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Summéiert d'Elementer vun engem Iterator.
    ///
    /// Huelt all Element, füügt se zesummen, a bréngt d'Resultat zréck.
    ///
    /// En eidelen Iterator gëtt den Nullwäert vum Typ zréck.
    ///
    /// # Panics
    ///
    /// Wann Dir `sum()` urufft an e primitivt Gezeltyp zréck gëtt, gëtt dës Method panic wann d'Berechnung iwwerschwemmt an Debugbehaaptungen aktivéiert sinn.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Iteréiert iwwer de ganzen Iterator, multiplizéieren all d'Elementer
    ///
    /// En eidelen Iterator gëtt de Wäert vum Typ zréck.
    ///
    /// # Panics
    ///
    /// Wann Dir `product()` urufft an e primitivt ganz Typ gëtt zréckginn, gëtt d'Method panic wann d'Berechnung iwwerschwemmt an Debugbehaaptungen aktivéiert sinn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) vergläicht d'Elementer vun dësem [`Iterator`] mat deenen vun engem aneren.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) vergläicht d'Elementer vun dësem [`Iterator`] mat deenen vun engem aneren am Bezuch op déi spezifizéiert Verglachfunktioun.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) vergläicht d'Elementer vun dësem [`Iterator`] mat deenen vun engem aneren.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) vergläicht d'Elementer vun dësem [`Iterator`] mat deenen vun engem aneren am Bezuch op déi spezifizéiert Verglachfunktioun.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Bestëmmt ob d'Elementer vun dësem [`Iterator`] gläich sinn wéi déi vun engem aneren.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Bestëmmt ob d'Elementer vun dësem [`Iterator`] gläich sinn wéi déi vun engem aneren a Relatioun mat der spezifizéierter Gläichheetsfunktioun.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Bestëmmt ob d'Elementer vun dësem [`Iterator`] ongläich sinn wéi déi vun engem aneren.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Bestëmmt ob d'Elementer vun dësem [`Iterator`] [lexicographically](Ord#lexicographical-comparison) manner si wéi déi vun engem aneren.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Bestëmmt ob d'Elementer vun dësem [`Iterator`] [lexicographically](Ord#lexicographical-comparison) manner oder wéi déi vun engem aneren sinn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Bestëmmt ob d'Elementer vun dësem [`Iterator`] [lexicographically](Ord#lexicographical-comparison) méi grouss si wéi déi vun engem aneren.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Bestëmmt ob d'Elementer vun dësem [`Iterator`] [lexicographically](Ord#lexicographical-comparison) méi grouss si wéi oder gläich wéi déi vun engem aneren.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Kontrolléiert ob d'Elementer vun dësem Iterator sortéiert sinn.
    ///
    /// Dat ass, fir all Element `a` a säi folgend Element `b`, muss `a <= b` halen.Wann den Iterator exakt Null oder een Element ergëtt, gëtt `true` zréckginn.
    ///
    /// Bedenkt datt wann `Self::Item` nëmmen `PartialOrd` ass, awer net `Ord`, déi uewe genannte Definitioun implizéiert datt dës Funktioun `false` zréckschéckt wann zwee pafolgende Saache net vergläichbar sinn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Kontrolléiert ob d'Elementer vun dësem Iterator mat der gegebene Komparatorfunktioun sortéiert sinn.
    ///
    /// Amplaz `PartialOrd::partial_cmp` ze benotzen, benotzt dës Funktioun déi gegebene `compare` Funktioun fir d'Bestellung vun zwee Elementer ze bestëmmen.
    /// Ofgesinn dovun ass et gläich wéi [`is_sorted`];kuckt seng Dokumentatioun fir méi Informatioun.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Kontrolléiert ob d'Elementer vun dësem Iterator mat der bestëmmter Schlëssel Extraktioun Funktioun sortéiert sinn.
    ///
    /// Amplaz direkt d'Iterator Elementer ze vergläichen, vergläicht dës Funktioun d'Schlëssele vun den Elementer, wéi se vum `f` bestëmmt ginn.
    /// Ofgesinn dovun ass et gläich wéi [`is_sorted`];kuckt seng Dokumentatioun fir méi Informatioun.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Kuckt [TrustedRandomAccess]
    // Den ongewéinlechen Numm ass Nummkollisiounen an der Methodopléisung ze vermeiden kuck #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}