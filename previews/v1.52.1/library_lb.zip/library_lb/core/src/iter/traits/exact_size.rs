/// En Iterator dee seng genau Längt weess.
///
/// Vill ["Iterator"] wëssen net wéi oft se iteréieren, awer e puer wëssen.
/// Wann en Iterator weess wéi oft et kann iteréieren, kann Zougang zu där Informatioun nëtzlech sinn.
/// Zum Beispill, wann Dir wëllt no hannen iteréieren, e gudde Start ass ze wëssen wou d'Enn ass.
///
/// Wann Dir en `ExactSizeIterator` implementéiert, musst Dir och [`Iterator`] implementéieren.
/// Wann Dir dëst maacht, muss d'Ëmsetzung vun [`Iterator::size_hint`]*déi genau Gréisst vum Iterator* zréckginn.
///
/// D [`len`] Method huet eng Standardimplementatioun, also sollt Dir se normalerweis net implementéieren.
/// Wéi och ëmmer, Dir kënnt fäeg sinn eng méi performant Ëmsetzung wéi de Standard ze bidden, sou datt et an dësem Fall Sënn mécht.
///
///
/// Bedenkt datt dësen trait e sécheren trait ass a wéi esou *net* an *kann* net garantéieren datt déi zréckgezunnen Längt korrekt ass.
/// Dëst bedeit datt den `unsafe` Code **däerf net** op d'Richtegkeet vun [`Iterator::size_hint`] vertrauen.
/// Déi onbestänneg an onsécher [`TrustedLen`](super::marker::TrustedLen) trait gëtt dës zousätzlech Garantie.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Basis Benotzung:
///
/// ```
/// // eng endlech Gamme weess genau wéi dacks se iteréiert
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Am [module-level docs] hu mir en [`Iterator`] implementéiert, `Counter`.
/// Loosst eis och `ExactSizeIterator` dofir implementéieren:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Mir kënnen d'rescht Zuel vun Iteratiounen einfach ausrechnen.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // An elo kënne mir et benotzen!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Gitt d'exakt Längt vum Iterator zréck.
    ///
    /// D'Ëmsetzung garantéiert datt den Iterator exakt `len()` méi Mol en [`Some(T)`] Wäert zréckbréngt, ier en [`None`] zréckgitt.
    ///
    /// Dës Method huet eng Standardimplementatioun, also sollt Dir se normalerweis net direkt implementéieren.
    /// Wéi och ëmmer, wann Dir eng méi effizient Ëmsetzung liwwert, kënnt Dir dat maachen.
    /// Kuckt d [trait-level] Dokumenter fir e Beispill.
    ///
    /// Dës Funktioun huet déiselwecht Sécherheetsgarantien wéi d [`Iterator::size_hint`] Funktioun.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// // eng endlech Gamme weess genau wéi dacks se iteréiert
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Dës Behaaptung ass ze defensiv, awer et kontrolléiert den Invarier
        // garantéiert vun der trait.
        // Wann dësen trait rust-intern wier, kéinte mir debug_assert benotzen !;assert_eq!kontrolléiert och all Rust Benotzerimplementatiounen.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Gitt `true` zréck wann de Iterator eidel ass.
    ///
    /// Dës Method huet eng Standardimplementéierung mat [`ExactSizeIterator::len()`], sou datt Dir se net selwer implementéiere musst.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}