/// En Iterator deen ëmmer weider `None` ergëtt wann en erschöpft ass.
///
/// Nächsten op engem fusionéierte Iterator ze ruffen deen den `None` eemol zréckbruecht huet ass garantéiert den [`None`] erëm zréckzekommen.
/// Dësen trait soll vun all Iteratoren implementéiert ginn, déi sech esou behuelen, well et [`Iterator::fuse()`] optiméiert.
///
///
/// Note: Am Allgemengen sollt Dir `FusedIterator` net a generesche Grenzen benotzen wann Dir e fusionéierte Iterator braucht.
/// Amplaz sollt Dir just [`Iterator::fuse()`] um Iterator uruffen.
/// Wann den Iterator scho fusionéiert ass, gëtt den zousätzleche [`Fuse`] Wrapper en No-Op ouni Leeschtungstrof.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// En Iterator deen eng genau Längt mat Size_hint mellt.
///
/// Den Iterator bericht e Gréisstentipp wou et entweder exakt ass (ënnescht Grenz ass gläich wéi Uewergrenz), oder d'Uewergrenz ass [`None`].
///
/// Déi iewescht Grenz däerf nëmmen [`None`] sinn, wann déi aktuell Iteratorlängt méi grouss ass wéi [`usize::MAX`].
/// An deem Fall muss déi ënnescht Grenz [`usize::MAX`] sinn, wat zu engem [`Iterator::size_hint()`] vun `(usize::MAX, None)` resultéiert.
///
/// Den Iterator muss genau d'Zuel vun Elementer produzéieren, déi e gemellt huet oder divergéiere virum Enn.
///
/// # Safety
///
/// Dësen trait muss nëmme implementéiert ginn wann de Kontrakt oprecht gëtt.
/// Konsumenten vun dësem trait mussen d [`Iterator::size_hint()`]’s Uewergrenz iwwerpréiwen.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// En Iterator deen wann en Artikel kritt op d'mannst een Element aus sengem Basis [`SourceIter`] geholl huet.
///
/// All Method nennen, déi den Iterator viru bréngt, z
/// [`next()`] oder [`try_fold()`], garantéiert datt fir all Schrëtt op d'mannst ee Wäert vun der Basis vun der Iterator Quell geplënnert ass an d'Resultat vun der Iteratorkette kéint op seng Plaz agefouert ginn, unzehuelen strukturell Contrainten vun der Quell erlaben esou eng Insertion.
///
/// An anere Wierder dës trait weist datt eng Iterator Pipeline kann op der Plaz gesammelt ginn.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}