/// Konversioun vun engem [`Iterator`].
///
/// Wann Dir `FromIterator` fir en Typ implementéiert, definéiert Dir wéi et aus engem Iterator erstallt gëtt.
/// Dëst ass heefeg fir Typen déi eng Sammlung vun iergendenger beschreiwen.
///
/// [`FromIterator::from_iter()`] gëtt selten explizit genannt, a gëtt amplaz vun der [`Iterator::collect()`] Method benotzt.
///
/// Kuckt [`Iterator::collect()`]'s Dokumentatioun fir méi Beispiller.
///
/// Kuck och: [`IntoIterator`].
///
/// # Examples
///
/// Basis Benotzung:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// [`Iterator::collect()`] benotze fir implizit `FromIterator` ze benotzen:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Implementéiere vun `FromIterator` fir Ären Typ:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Eng Probe Sammlung, dat ass just e Wéckel iwwer Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Loosst eis et e puer Methoden ginn sou datt mir eng erstellen a Saache bäifügen.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // a mir implementéieren FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Elo kënne mir en neien Iterator maachen ...
/// let iter = (0..5).into_iter();
///
/// // ... a maacht eng MyCollection draus
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // sammelt och Wierker!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Erstellt e Wäert vun engem Iterator.
    ///
    /// Kuckt de [module-level documentation] fir méi.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Ëmwandlung an en [`Iterator`].
///
/// Wann Dir `IntoIterator` fir en Typ implementéiert, definéiert Dir wéi et an en Iterator ëmgewandelt gëtt.
/// Dëst ass heefeg fir Typen déi eng Sammlung vun iergendenger beschreiwen.
///
/// Ee Virdeel vun der Ëmsetzung vun `IntoIterator` ass datt Ären Typ [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator) ass.
///
///
/// Kuck och: [`FromIterator`].
///
/// # Examples
///
/// Basis Benotzung:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Implementéiere vun `IntoIterator` fir Ären Typ:
///
/// ```
/// // Eng Probe Sammlung, dat ass just e Wéckel iwwer Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Loosst eis et e puer Methoden ginn sou datt mir eng erstellen a Saache bäifügen.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // a mir implementéieren IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Elo kënne mir eng nei Kollektioun maachen ...
/// let mut c = MyCollection::new();
///
/// // ... füügt e puer Saachen derbäi ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... a maach et an en Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Et ass heefeg `IntoIterator` als trait bound ze benotzen.Dëst erlaabt den Input Sammlungstyp z'änneren, soulaang et nach ëmmer en Iterator ass.
/// Zousätzlech Grenze kënne spezifizéiert ginn andeems se op beschränken
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Déi Zort vun den Elementer déi iwwer iteréiert ginn.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Wéi eng Zort Iterator maachen mir dëst an?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Erstellt en Iterator aus engem Wäert.
    ///
    /// Kuckt de [module-level documentation] fir méi.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Verlängert eng Sammlung mam Inhalt vun engem Iterator.
///
/// Iteratoren produzéieren eng Serie vu Wäerter, a Sammlunge kënnen och als eng Serie vu Wäerter ugesi ginn.
/// Den `Extend` trait iwwerbréckt dës Lück, et erlaabt Iech eng Sammlung ze verlängeren andeems en den Inhalt vun deem Iterator enthält.
/// Wann Dir eng Sammlung mat engem scho existente Schlëssel verlängert, gëtt dësen Entrée aktualiséiert oder, am Fall vu Sammlungen déi méi Entréen mat gläiche Schlësselen erlaben, gëtt dësen Entrée agebaut.
///
///
/// # Examples
///
/// Basis Benotzung:
///
/// ```
/// // Dir kënnt e String mat e puer Zeeche verlängeren:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Implementéiere vun `Extend`:
///
/// ```
/// // Eng Probe Sammlung, dat ass just e Wéckel iwwer Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Loosst eis et e puer Methoden ginn sou datt mir eng erstellen a Saache bäifügen.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // well MyCollection eng Lëscht vun i32s huet, implementéiere mir Extend fir i32
/// impl Extend<i32> for MyCollection {
///
///     // Dëst ass e bësse méi einfach mat der konkreter Ënnerschrëft: mir kënne ruffe verlängeren op alles wat kann zu engem Iterator ginn deen eis i32s gëtt.
///     // Well mir i32s brauchen fir a MyCollection ze setzen.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // D'Ëmsetzung ass ganz einfach: Loop duerch den Iterator, an add() all Element fir eis selwer.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // loosst eis Sammlung mat dräi méi Zuelen ausbauen
/// c.extend(vec![1, 2, 3]);
///
/// // mir hunn dës Elementer um Enn bäigefüügt
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Verlängert eng Sammlung mam Inhalt vun engem Iterator.
    ///
    /// Well dëst déi eenzeg erfuerderlech Method fir dësen trait ass, enthalen d [trait-level] Dokumenter méi Detailer.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// // Dir kënnt e String mat e puer Zeeche verlängeren:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Verlängert eng Sammlung mat genau engem Element.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Reservéiert Kapazitéit an enger Sammlung fir déi gegeben Unzuel vun zousätzlechen Elementer.
    ///
    /// D'Standardimplementatioun mécht näischt.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}