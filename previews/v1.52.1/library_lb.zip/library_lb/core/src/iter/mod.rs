//! Komposéierbar extern Iteratioun.
//!
//! Wann Dir Iech mat enger Sammlung vun iergendengem fonnt hutt, an Dir braucht eng Operatioun op den Elementer vun der gesammter Sammlung ze maachen, gitt Dir séier op 'iterators'.
//! Iteratoren gi staark am idiomateschen Rust Code benotzt, dofir ass et derwäert sech mat hinnen ze vertraut.
//!
//! Ier mer méi erkläre loossen, schwätze mer wéi dëse Modul strukturéiert ass:
//!
//! # Organization
//!
//! Dëst Modul ass gréisstendeels nom Typ organiséiert:
//!
//! * [Traits] sinn den Haaptdeel: dës traits definéieren wéi eng Iteratoren existéieren a wat Dir mat hinnen maache kënnt.D'Methode vun dësen traits sinn derwäert eng extra Studienzäit anzesetzen.
//! * [Functions] gitt e puer hëllefräich Weeër fir e puer Basis Iteratoren ze kreéieren.
//! * [Structs] sinn dacks d'Retourtypen vun de verschiddene Methoden op dësem traits Modul.Dir wëllt normalerweis op d'Methode kucken déi den `struct` erstellt, anstatt d `struct` selwer.
//! Fir méi Detailer iwwer firwat, kuckt '[Implementing Iterator](#implementing-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Dat ass et!Loosst eis an Iteratoren gräifen.
//!
//! # Iterator
//!
//! D'Häerz an d'Séil vun dësem Modul ass den [`Iterator`] trait.De Kär vum [`Iterator`] gesäit sou aus:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! En Iterator huet eng Method, [`next`], déi wa se geruff ginn, eng [`Option`] 'zréckbréngt<Item>`.
//! [`next`] wäert [`Some(Item)`] zréckginn soulaang et Elementer sinn, a wann se all erschöpft sinn, wäert `None` zréckgoen fir unzeginn datt d'Iteratioun fäerdeg ass.
//! Eenzel Iteratoren kënnen entscheeden d'Iteratioun opzehuelen, a sou kann een den [`next`] erëm uruffen eventuell ufänken iergendwann [`Some(Item)`] zréckzekommen (zum Beispill [`TryIter`]).
//!
//!
//! ['Iterator`] Voll Definitioun enthält och eng Rei aner Methoden, awer si sinn Standardmethoden, uewen op [`next`] gebaut, an dofir kritt Dir se gratis.
//!
//! Iteratoren sinn och komponéierbar, an et ass heefeg se mateneen ze verbannen fir méi komplex Forme vun der Veraarbechtung ze maachen.Kuckt de [Adapters](#adapters) Sektioun hei ënnendrënner fir méi Detailer.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Déi dräi Forme vun Iteratioun
//!
//! Et ginn dräi gemeinsam Methoden déi Iteratoren aus enger Sammlung erstellen:
//!
//! * `iter()`, déi iwwer `&T` iteréiert.
//! * `iter_mut()`, déi iwwer `&mut T` iteréiert.
//! * `into_iter()`, déi iwwer `T` iteréiert.
//!
//! Verschidde Saachen an der Standardbibliothéik kënnen een oder méi vun den dräi implementéieren, wou passend.
//!
//! # Implementéieren Iterator
//!
//! En eegene Iterator ze kreéieren involvéiert zwee Schrëtt: en `struct` erstellen fir dem Iterator säi Staat ze halen, an dann [`Iterator`] fir deen `struct` ëmzesetzen.
//! Dofir sinn et sou vill `struct`s an dësem Modul: et gëtt een fir all Iterator an Iteratoradapter.
//!
//! Loosst eis en Iterator mam Numm `Counter` maachen, deen vun `1` op `5` zielt:
//!
//! ```
//! // Als éischt de Struct:
//!
//! /// En Iterator dee vun engem bis fënnef zielt
//! struct Counter {
//!     count: usize,
//! }
//!
//! // mir wëllen datt eise Grof bei engem ufänkt, also addéiere mer eng new() Method fir ze hëllefen.
//! // Dëst ass net streng néideg, awer ass bequem.
//! // Bedenkt datt mir `count` op Null starten, mir kucken firwat an der `next()`'s Ëmsetzung ënnendrënner.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Dann implementéiere mir `Iterator` fir eis `Counter`:
//!
//! impl Iterator for Counter {
//!     // mir ziele mat Usize
//!     type Item = usize;
//!
//!     // next() ass déi eenzeg erfuerderlech Method
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Inkrementéiert eise Grof.Duerfir hu mir bei Null ugefaang.
//!         self.count += 1;
//!
//!         // Kontrolléiert ze gesinn, ob mir fäerdeg sinn ze zielen oder net.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // An elo kënne mir et benotzen!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! [`next`] op dës Manéier uruffen gëtt repetitiv.Rust huet e Konstrukt deen [`next`] op Ärem Itator ruffe kann, bis et `None` erreecht.Loosst eis iwwer dat nächst goen.
//!
//! Bedenkt och datt `Iterator` eng Standardimplementatioun vu Methoden wéi `nth` an `fold` bitt déi intern `next` nennen.
//! Wéi och ëmmer, et ass och méiglech eng personaliséiert Implementatioun vu Methoden wéi `nth` an `fold` ze schreiwen wann en Iterator se méi effizient ka berechnen ouni `next` ze ruffen.
//!
//! # `for` Schlëff an `IntoIterator`
//!
//! Rust's `for` Loop Syntax ass tatsächlech Zocker fir Iteratoren.Hei ass e Basis Beispill vu `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Dëst dréckt d'Nummeren eng bis fënnef, all op hir eege Linn.Awer Dir wäert eppes hei bemierken: mir hunn ni eppes op eiser vector ugeruff fir en Iterator ze produzéieren.Wat gëtt?
//!
//! Et ass en trait an der Standardbibliothéik fir eppes an en Iterator ze konvertéieren: [`IntoIterator`].
//! Dësen trait huet eng Method, [`into_iter`], déi d'Saach ëmsetzt déi [`IntoIterator`] an en Iterator ëmsetzen.
//! Loosst eis dës `for` Loop nach eng Kéier kucken, a wat de Compiler se konvertéiert an:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-Zocker dëst an:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Als éischt nenne mir `into_iter()` op de Wäert.Dann passen mir op dem Iterator deen zréckkomm ass, rufft ëmmer erëm [`next`] bis mir en `None` gesinn.
//! Zu dësem Zäitpunkt si mir `break` aus der Loop eraus, a mir si fäerdeg iteréieren.
//!
//! Hei ass e méi subtile Bit hei: d'Standardbibliothéik enthält eng interessant Implementatioun vun [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! An anere Wierder, all ["Iterator"] implementéieren [`IntoIterator`], andeems se just selwer zréckginn.Dëst bedeit zwou Saachen:
//!
//! 1. Wann Dir en [`Iterator`] schreift, kënnt Dir se mat enger `for` Loop benotzen.
//! 2. Wann Dir eng Sammlung erstellt, andeems Dir [`IntoIterator`] dofir implementéiert erlaabt Är Sammlung mat der `for` Loop ze benotzen.
//!
//! # Iteréieren duerch Referenz
//!
//! Zënter [`into_iter()`] `self` nom Wäert hëlt, verbraucht eng `for` Loop fir iwwer eng Sammlung ze iteréieren déi Sammlung.Oft kënnt Dir iwwer eng Sammlung iteréieren ouni se ze konsuméieren.
//! Vill Sammlunge bidden Methoden déi Iteratoren iwwer Referenzen ubidden, konventionell `iter()` respektiv `iter_mut()` genannt:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` ass nach ëmmer vun dëser Funktioun.
//! ```
//!
//! Wann eng Sammlungstyp `C` `iter()` ubitt, implementéiert se normalerweis och `IntoIterator` fir `&C`, mat enger Ëmsetzung déi just `iter()` nennt.
//! Och eng Sammlung `C` déi `iter_mut()` liefert implementéiert allgemeng `IntoIterator` fir `&mut C` andeems se op `iter_mut()` delegéiert ginn.Dëst erméiglecht e bequemen Shorthand:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // selwecht wéi `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // selwecht wéi `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Wärend vill Sammlungen `iter()` ubidden, bidden net all `iter_mut()` un.
//! Zum Beispill d'Mutéiere vun de Schlëssele vun engem [`HashSet<T>`] oder [`HashMap<K, V>`] kéint d'Sammlung an en inkonsistente Staat setzen, wann de Schlësselhash ännert, sou datt dës Sammlungen nëmmen `iter()` ubidden.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Funktiounen déi en [`Iterator`] huelen an en anert [`Iterator`] zréckginn, ginn dacks "iterator Adapter" genannt, well se eng Form vum 'Adapter sinn
//! pattern'.
//!
//! Gemeinsam Iterator-Adapter enthalen [`map`], [`take`] an [`filter`].
//! Fir méi, kuckt hir Dokumentatioun.
//!
//! Wann en Iterator-Adapter panics, den Iterator an engem net spezifizéierten (awer Gedächtnis sécher) Zoustand.
//! Dëse Staat ass och net garantéiert dee selwechten ze bleiwen iwwer Versioune vun Rust, also sollt Dir vermeiden datt Dir op déi exakt Wäerter zréckgräift, déi vun engem Iterator zréckginn, dee panikéiert ass.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iteratoren (an Iterator [adapters](#adapters)) si *faul*. Dëst bedeit datt just en Iterator erstallt net _do_ ganz vill ass. Näischt geschitt wierklech bis Dir [`next`] nennt.
//! Dëst ass heiansdo eng Quell vu Verwirrung wann Dir en Iterator eleng fir seng Nebenwirkungen erstellt.
//! Zum Beispill rifft d [`map`] Method eng Zoumaache vun all Element iwwer dat et itéiert:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Dëst dréckt keng Wäerter, well mir nëmmen en Iterator erstallt hunn, anstatt et ze benotzen.De Compiler warnt eis iwwer dës Aart vu Behuelen:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Den idiomatesche Wee fir en [`map`] fir seng Nebenwirkungen ze schreiwen ass eng `for` Loop ze benotzen oder d [`for_each`] Method ze nennen:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! En anere gemeinsame Wee fir en Iterator ze evaluéieren ass d [`collect`] Method fir eng nei Sammlung ze produzéieren.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iteratoren mussen net endlech sinn.Als Beispill ass en oppent Sortiment en onendlechen Iterator:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Et ass heefeg den [`take`] Iterator Adapter ze benotzen fir en onendlechen Iterator zu engem endlechen ze maachen:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Dëst dréckt d'Nummeren `0` duerch `4`, all op hir eege Linn.
//!
//! Denkt drun datt Methoden op onendlech Iteratoren, och déi fir déi e Resultat mathematesch a begrenzter Zäit ka bestëmmen, net ofschléisse kënnen.
//! Speziell Methode wéi [`min`], déi am allgemenge Fall erfuerderlech all Element am Iterator iwwerschreiden, si méiglecherweis net erfollegräich fir all onendlech Iteratoren zréckzekommen.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Oh nee!Eng onendlech Loop!
//! // `ones.min()` verursaacht eng onendlech Loop, sou datt mir dëse Punkt net erreechen!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;