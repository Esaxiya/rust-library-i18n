use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// Objeten déi e Begrëff vun *Nofolger* an *Virgänger* Operatiounen hunn.
///
/// Déi *Nofolger* Operatioun geet op Wäerter déi méi grouss vergläichen.
/// Déi *Virgänger* Operatioun geet op Wäerter déi manner vergläichen.
///
/// # Safety
///
/// Dësen trait ass `unsafe` well seng Ëmsetzung fir d'Sécherheet vun den `unsafe trait TrustedLen` Implementéierunge muss korrekt sinn, an d'Resultater vun der Benotzung vun dësem trait kënne soss mam `unsafe` Code vertraut gi fir richteg ze sinn an déi opgelëscht Obligatiounen ze erfëllen.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// Gitt d'Zuel vun *Nofolger* Schrëtt erfuerderlech fir vun `start` op `end` ze kommen.
    ///
    /// Retour `None` wann d'Zuel vu Schrëtt `usize` iwwerschwemmt (oder onendlech ass, oder wann `end` ni géif erreecht ginn).
    ///
    ///
    /// # Invariants
    ///
    /// Fir all `a`, `b` an `n`:
    ///
    /// * `steps_between(&a, &b) == Some(n)` wann an nëmmen wann `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` wann an nëmmen wann `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` nëmmen wann `a <= b`
    ///   * Corollary: `steps_between(&a, &b) == Some(0)` wann an nëmmen wann `a == b`
    ///   * Bedenkt datt `a <= b` _not_ heescht `steps_between(&a, &b) != None` heescht;
    ///     dëst ass de Fall wann et méi wéi `usize::MAX` Schrëtt erfuerderen fir op `b` ze kommen
    /// * `steps_between(&a, &b) == None` wann `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// Gitt de Wäert zréck, deen duerch den *Nofolger* vun `self` `count` Mol kritt gëtt.
    ///
    /// Wann dëst d'Gamme vu Wäerter, déi vun `Self` ënnerstëtzt ginn, iwwerschwemmt, gëtt `None` zréck.
    ///
    /// # Invariants
    ///
    /// Fir all `a`, `n` an `m`:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// Fir all `a`, `n` an `m` wou `n + m` net iwwerschwemmt:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// Fir all `a` an `n`:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// Gitt de Wäert zréck, deen duerch den *Nofolger* vun `self` `count` Mol kritt gëtt.
    ///
    /// Wann dëst d'Gamme vu Wäerter, déi vun `Self` ënnerstëtzt ginn, iwwerschwemmt, ass dës Funktioun erlaabt panic, wrap oder saturéiert.
    ///
    /// Dat virgeschloent Verhalen ass zu panic wann Debug-Behaaptungen aktivéiert sinn, an anescht ze packen oder ze saturéieren.
    ///
    /// Onsécherere Code sollt net op d'Korrektheet vum Verhalen nom Iwwerlaf vertrauen.
    ///
    /// # Invariants
    ///
    /// Fir all `a`, `n` an `m`, wou keen Iwwerlaf geschitt:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// Fir all `a` an `n`, wou keen Iwwerlaf geschitt:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// Gitt de Wäert zréck, deen duerch den *Nofolger* vun `self` `count` Mol kritt gëtt.
    ///
    /// # Safety
    ///
    /// Et ass ondefinéiert Verhalen fir dës Operatioun de Wäerterberäich vun `Self` z'iwwerfalen.
    /// Wann Dir net ka garantéieren datt dëst net iwwerschwemmt, benotzt `forward` oder `forward_checked` statt.
    ///
    /// # Invariants
    ///
    /// Fir all `a`:
    ///
    /// * wann et `b` gëtt sou datt `b > a`, ass et sécher `Step::forward_unchecked(a, 1)` ze ruffen
    /// * wann et `b`, `n` existéiert sou datt `steps_between(&a, &b) == Some(n)`, ass et sécher `Step::forward_unchecked(a, m)` fir all `m <= n` ze ruffen.
    ///
    ///
    /// Fir all `a` an `n`, wou keen Iwwerlaf geschitt:
    ///
    /// * `Step::forward_unchecked(a, n)` entsprécht `Step::forward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// Gitt de Wäert zréck, dee kritt gëtt andeems de *Virgänger* vun `self` `count` Mol geholl gëtt.
    ///
    /// Wann dëst d'Gamme vu Wäerter, déi vun `Self` ënnerstëtzt ginn, iwwerschwemmt, gëtt `None` zréck.
    ///
    /// # Invariants
    ///
    /// Fir all `a`, `n` an `m`:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// Fir all `a` an `n`:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// Gitt de Wäert zréck, dee kritt gëtt andeems de *Virgänger* vun `self` `count` Mol geholl gëtt.
    ///
    /// Wann dëst d'Gamme vu Wäerter, déi vun `Self` ënnerstëtzt ginn, iwwerschwemmt, ass dës Funktioun erlaabt panic, wrap oder saturéiert.
    ///
    /// Dat virgeschloent Verhalen ass zu panic wann Debug-Behaaptungen aktivéiert sinn, an anescht ze packen oder ze saturéieren.
    ///
    /// Onsécherere Code sollt net op d'Korrektheet vum Verhalen nom Iwwerlaf vertrauen.
    ///
    /// # Invariants
    ///
    /// Fir all `a`, `n` an `m`, wou keen Iwwerlaf geschitt:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// Fir all `a` an `n`, wou keen Iwwerlaf geschitt:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// Gitt de Wäert zréck, dee kritt gëtt andeems de *Virgänger* vun `self` `count` Mol geholl gëtt.
    ///
    /// # Safety
    ///
    /// Et ass ondefinéiert Verhalen fir dës Operatioun de Wäerterberäich vun `Self` z'iwwerfalen.
    /// Wann Dir net ka garantéieren datt dëst net iwwerschwemmt, benotzt `backward` oder `backward_checked` statt.
    ///
    /// # Invariants
    ///
    /// Fir all `a`:
    ///
    /// * wann et `b` gëtt sou datt `b < a`, ass et sécher `Step::backward_unchecked(a, 1)` ze ruffen
    /// * wann et `b`, `n` existéiert sou datt `steps_between(&b, &a) == Some(n)`, ass et sécher `Step::backward_unchecked(a, m)` fir all `m <= n` ze ruffen.
    ///
    ///
    /// Fir all `a` an `n`, wou keen Iwwerlaf geschitt:
    ///
    /// * `Step::backward_unchecked(a, n)` entsprécht `Step::backward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// Dës ginn nach ëmmer makro-generéiert well déi ganz Literal op verschidden Zorten opléisen.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // SAFETY: den Uruff muss garantéieren datt `start + n` net iwwerschwemmt.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // SAFETY: den Uruff muss garantéieren datt `start - n` net iwwerschwemmt.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // Am Debug baut, ausléise en panic beim Iwwerlaf.
            // Dëst soll optimal a Fräiloossung baut optimiséieren.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // Maacht Wéckelrechnung fir z.B. `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // Am Debug baut, ausléise en panic beim Iwwerlaf.
            // Dëst soll optimal a Fräiloossung baut optimiséieren.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // Maacht Wéckelrechnung fir z.B. `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Dëst setzt op $u_narrower <=usize
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // wann n ausserhalb ass, ass `unsigned_start + n` och
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // wann n ausserhalb ass, ass `unsigned_start - n` och
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Dëst setzt op $i_narrower <=usize
                        //
                        // Casting to isize verlängert d'Breet awer erhält d'Zeechen.
                        // Benotzt wrapping_sub am isize Raum a cast fir ze benotze fir den Ënnerscheed ze berechnen deen net an der Gamme vun isize passt.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Wrapping behandelt Fäll wéi `Step::forward(-120_i8, 200) == Some(80_i8)`, och wann 200 ausserhalb vu Range fir i8 ass.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // Zousaz iwwerflësseg
                            }
                        }
                        // Wann n ausserhalb ass vun z
                        // u8, dann ass et méi grouss wéi déi ganz Gamme fir i8 ass breet sou datt `any_i8 + n` onbedéngt iwwer i8 iwwerschwemmt.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Wrapping behandelt Fäll wéi `Step::forward(-120_i8, 200) == Some(80_i8)`, och wann 200 ausserhalb vu Range fir i8 ass.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // Subtraktioun iwwerschwemmt
                            }
                        }
                        // Wann n ausserhalb ass vun z
                        // u8, dann ass et méi grouss wéi déi ganz Gamme fir i8 ass breet, sou datt `any_i8 - n` onbedéngt iwwer i8 iwwerschwemmt.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // Wann den Ënnerscheed ze grouss ass fir z
                            // i128, et wäert och ze grouss sinn fir mat manner Bits ze benotzen.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // SAFETY: res ass e gëltege Unicode Skalar
            // (ënner 0x110000 an net an 0xD800..0xE000)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // SAFETY: res ass e gëltege Unicode Skalar
        // (ënner 0x110000 an net an 0xD800..0xE000)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // SAFETY: den Uruffer muss garantéieren datt dëst net iwwerschwemmt
        // der Gamme vu Wäerter fir eng Char.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // SAFETY: den Uruffer muss garantéieren datt dëst net iwwerschwemmt
            // der Gamme vu Wäerter fir eng Char.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // SAFETY: wéinst dem fréiere Kontrakt ass dëst garantéiert
        // vum Uruff e gëltege Char ze sinn.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // SAFETY: den Uruffer muss garantéieren datt dëst net iwwerschwemmt
        // der Gamme vu Wäerter fir eng Char.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // SAFETY: den Uruffer muss garantéieren datt dëst net iwwerschwemmt
            // der Gamme vu Wäerter fir eng Char.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // SAFETY: wéinst dem fréiere Kontrakt ass dëst garantéiert
        // vum Uruff e gëltege Char ze sinn.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // SAFETY: just gepréift Viraussetzung
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // SAFETY: just gepréift Viraussetzung
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// Dës Makroen generéieren `ExactSizeIterator` Impls fir verschidde Reegentypen.
//
// * `ExactSizeIterator::len` ass gefrot fir ëmmer e genauen `usize` zréckzebréngen, sou datt kee Beräich méi laang wéi `usize::MAX` ka sinn.
//
// * Fir ganz Zorten an `Range<_>` ass dat de Fall fir Aarte méi schmuel wéi oder sou breet wéi `usize`.
//   Fir ganz Zorten an `RangeInclusive<_>` ass dat de Fall fir Typen *streng méi enk* wéi `usize` zënter z
//   `(0..=u64::MAX).len()` wier `u64::MAX + 1`.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // Dës sinn inkorekt no de Begrënnungen hei uewen, awer se ewechzehuelen wär eng brechend Ännerung wéi se am Rust 1.0.0 stabiliséiert goufen.
    // Also zB
    // `(0..66_000_u32).len()` wäert zum Beispill ouni Feeler oder Warnungen op 16-Bit Plattformen kompiléieren, awer weider e falscht Resultat ginn.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // Dës sinn inkorekt no de Begrënnungen hei uewen, awer se ewechzehuelen wär eng brechend Ännerung wéi se am Rust 1.26.0 stabiliséiert goufen.
    // Also zB
    // `(0..=u16::MAX).len()` wäert zum Beispill ouni Feeler oder Warnungen op 16-Bit Plattformen kompiléieren, awer weider e falscht Resultat ginn.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // SAFETY: just gepréift Viraussetzung
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // SAFETY: just gepréift Viraussetzung
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // SAFETY: just gepréift Viraussetzung
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // SAFETY: just gepréift Viraussetzung
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // SAFETY: just gepréift Viraussetzung
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // SAFETY: just gepréift Viraussetzung
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}