use crate::iter::{FusedIterator, TrustedLen};

/// Erstellt en neien Iterator deen Elementer vum Typ `A` onendlech widderhëlt andeems se de verschaffene Schluss, de Repeater, `F: FnMut() -> A`.
///
/// D `repeat_with()` Funktioun rifft de Repeater ëmmer erëm.
///
/// Onendlech Iteratoren wéi `repeat_with()` ginn dacks mat Adaptere wéi [`Iterator::take()`] benotzt, fir se endlech ze maachen.
///
/// Wann d'Element Element vum Iterator Dir [`Clone`] braucht implementéiert, an et ass OK fir de Quellelement am Gedächtnis ze halen, sollt Dir amplaz d [`repeat()`] Funktioun benotzen.
///
///
/// En Iterator produzéiert vum `repeat_with()` ass keen [`DoubleEndedIterator`].
/// Wann Dir `repeat_with()` braucht fir en [`DoubleEndedIterator`] zréckzebréngen, maacht w.e.g. eng GitHub Ausgab op, déi Äre Benotzungsfall erkläert.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Basis Benotzung:
///
/// ```
/// use std::iter;
///
/// // loosst eis dovun ausgoen datt mir e Wäert vun engem Typ hunn deen net `Clone` ass oder deen net an Erënnerung wëllt hunn just well et deier ass:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // e besonnesche Wäert fir ëmmer:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Mat Mutatioun a geet endlech:
///
/// ```rust
/// use std::iter;
///
/// // Vum Null op déi drëtt Kraaft vun zwee:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... an elo si mir fäerdeg
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// En Iterator deen Elementer vum Typ `A` onendlech widderhëlt andeems en de verschaffene Schluss `F: FnMut() -> A` applizéiert.
///
///
/// Dësen `struct` gëtt vun der [`repeat_with()`] Funktioun erstallt.
/// Kuckt seng Dokumentatioun fir méi.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}