use crate::fmt;

/// Erstellt en neien Iterator, wou all Iteratioun de verschaffene Schluss `F: FnMut() -> Option<T>` nennt.
///
/// Dëst erlaabt e personaliséierten Iterator mat all Verhalen ze kreéieren ouni déi méi verbose Syntax ze benotzen fir en dedizéierten Typ ze kreéieren an d [`Iterator`] trait dofir z'implementéieren.
///
/// Bedenkt datt den `FromFn` Iterator keng Viraussetzungen iwwer d'Behuele vun der Fermeture mécht, an dofir konservativ [`FusedIterator`] net implementéiert, oder [`Iterator::size_hint()`] vu sengem Standard `(0, None)` iwwerschreift.
///
///
/// D'Zoumaache kann Erfaassungen a säin Ëmfeld benotze fir de Staat iwwer Iteratiounen ze verfollegen.Ofhängeg dovun wéi den Iterator benotzt gëtt, kann dëst e [`move`] Schlësselwuert op der Zoumaache spezifizéieren.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Loosst eis de Konteriterator vun [module-level documentation] nei implementéieren:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Inkrementéiert eise Grof.Duerfir hu mir bei Null ugefaang.
///     count += 1;
///
///     // Kontrolléiert ze gesinn, ob mir fäerdeg sinn ze zielen oder net.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// En Iterator wou all Iteratioun déi virgesinn Zoumaache `F: FnMut() -> Option<T>` nennt.
///
/// Dësen `struct` gëtt vun der [`iter::from_fn()`] Funktioun erstallt.
/// Kuckt seng Dokumentatioun fir méi.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}