use crate::iter::{FusedIterator, TrustedLen};

/// Erstellt en Iterator deen en Element exakt eemol bréngt.
///
/// Dëst gëtt allgemeng benotzt fir een eenzege Wäert an en [`chain()`] vun aneren Aarte vun der Impressioun unzepassen.
/// Vläicht hutt Dir en Iterator dee bal alles ofdeckt, awer Dir braucht en extra Spezialfall.
/// Vläicht hutt Dir eng Funktioun déi op Iteratoren funktionnéiert, awer Dir braucht nëmmen ee Wäert ze verarbeiten.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Basis Benotzung:
///
/// ```
/// use std::iter;
///
/// // een ass déi allengste Zuel
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // just een, dat ass alles wat mir kréien
/// assert_eq!(None, one.next());
/// ```
///
/// Ketten zesumme mat engem aneren Iterator.
/// Loosst eis soen datt mir iwwer all Datei vum `.foo` Verzeechnes iteréieren wëllen, awer och eng Konfiguratiounsdatei,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // mir musse vun engem Iterator vun DirEntry-s an en Iterator vu PathBufs konvertéieren, also benotze mir Kaart
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // elo, eisen Iterator just fir eis Configuratiounsdatei
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // Ketten déi zwee Iteratoren zesummen zu engem groussen Iterator
/// let files = dirs.chain(config);
///
/// // dëst wäert eis all d'Fichieren an .foo wéi och .foorc ginn
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// En Iterator deen en Element exakt eemol bréngt.
///
/// Dësen `struct` gëtt vun der [`once()`] Funktioun erstallt.Kuckt seng Dokumentatioun fir méi.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}