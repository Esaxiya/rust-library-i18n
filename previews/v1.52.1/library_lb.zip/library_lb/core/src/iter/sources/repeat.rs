use crate::iter::{FusedIterator, TrustedLen};

/// Erstellt en neien Iterator deen endlos een eenzegt Element widderhëlt.
///
/// D `repeat()` Funktioun widderhëlt een eenzege Wäert ëmmer erëm.
///
/// Onendlech Iteratoren wéi `repeat()` ginn dacks mat Adaptere wéi [`Iterator::take()`] benotzt, fir se endlech ze maachen.
///
/// Wann den Elementstyp vum Iterator deen Dir braucht net `Clone` implementéiert, oder wann Dir dat widderhuelend Element net an Erënnerung wëllt halen, kënnt Dir amplaz d [`repeat_with()`] Funktioun benotzen.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Basis Benotzung:
///
/// ```
/// use std::iter;
///
/// // d'Nummer véier 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // yup, nach ëmmer véier
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Endlech mat [`Iterator::take()`] goen:
///
/// ```
/// use std::iter;
///
/// // dat lescht Beispill war ze vill Fours.Loosst eis nëmme véier Véier hunn.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... an elo si mir fäerdeg
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// En Iterator deen en Element onendlech widderhëlt.
///
/// Dësen `struct` gëtt vun der [`repeat()`] Funktioun erstallt.Kuckt seng Dokumentatioun fir méi.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}