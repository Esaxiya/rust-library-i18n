use crate::iter::{FusedIterator, TrustedLen};

/// Erstellt en Iterator deen liddereg e Wäert genau eemol generéiert andeems en op déi virgesinn Zoumaache kënnt.
///
/// Dëst gëtt allgemeng benotzt fir een eenzege Wäertgenerator an en [`chain()`] vun aneren Aarte vun der Impressioun unzepassen.
/// Vläicht hutt Dir en Iterator dee bal alles ofdeckt, awer Dir braucht en extra Spezialfall.
/// Vläicht hutt Dir eng Funktioun déi op Iteratoren funktionnéiert, awer Dir braucht nëmmen ee Wäert ze verarbeiten.
///
/// Am Géigesaz zu [`once()`] wäert dës Funktioun faul de Wäert op Ufro generéieren.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Basis Benotzung:
///
/// ```
/// use std::iter;
///
/// // een ass déi allengste Zuel
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // just een, dat ass alles wat mir kréien
/// assert_eq!(None, one.next());
/// ```
///
/// Ketten zesumme mat engem aneren Iterator.
/// Loosst eis soen datt mir iwwer all Datei vum `.foo` Verzeechnes iteréieren wëllen, awer och eng Konfiguratiounsdatei,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // mir musse vun engem Iterator vun DirEntry-s an en Iterator vu PathBufs konvertéieren, also benotze mir Kaart
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // elo, eisen Iterator just fir eis Configuratiounsdatei
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // Ketten déi zwee Iteratoren zesummen zu engem groussen Iterator
/// let files = dirs.chain(config);
///
/// // dëst wäert eis all d'Fichieren an .foo wéi och .foorc ginn
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// En Iterator deen een eenzegt Element vum Typ `A` ergëtt andeems en de verschaffene Schließung `F: FnOnce() -> A` applizéiert.
///
///
/// Dësen `struct` gëtt vun der [`once_with()`] Funktioun erstallt.
/// Kuckt seng Dokumentatioun fir méi.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}