use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Dësen trait bitt transitiven Zougang zu der Quell-Bühn an enger Interator-Adapter Pipeline ënner de Konditioune déi
/// * d'Iterator Quell `S` selwer implementéiert `SourceIter<Source = S>`
/// * et gëtt eng delegéierend Ëmsetzung vun dësem trait fir all Adapter an der Pipeline tëscht der Quell an dem Pipeline Konsument.
///
/// Wann d'Quell en Besëtzer Iterator Struct ass (normalerweis `IntoIter` genannt), da kann dëst nëtzlech sinn fir [`FromIterator`] Implementéierungen ze spezialiséieren oder déi reschtlech Elementer ze recuperéieren nodeems en Iterator deelweis erschöpft gouf.
///
///
/// Bedenkt datt Implementatiounen net onbedéngt Zougang zu der banneschten Quell vun enger Pipeline musse bidden.E stateschen Zwëschenadapter kéint en Deel vun der Pipeline gäeren evaluéieren an hir intern Späichere wéi Quell aussetzen.
///
/// Den trait ass onsécher well d'Implementateuren zousätzlech Sécherheetseegenschafte mussen oprechterhalen.
/// Kuckt [`as_inner`] fir Detailer.
///
/// # Examples
///
/// Eng deelweis verbrauchte Quell recuperéieren:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Eng Quellstuf an enger Iterator Pipeline.
    type Source: Iterator;

    /// Recuperéieren d'Quell vun enger Iterator Pipeline.
    ///
    /// # Safety
    ///
    /// Implementatioune vu mussen déiselwecht mutéierbar Referenz fir hir Liewensdauer zréckginn, ausser wann se duerch en Uruff ersat ginn.
    /// Callers däerfen nëmmen d'Referenz ersetzen wann se d'Iteratioun gestoppt hunn an d'Iterator Pipeline erofsetzen nodeems se d'Quell extrahéiert hunn.
    ///
    /// Dëst bedeit Iterator Adapter kënnen op d'Quell vertrauen déi sech net während der Iteratioun ännert awer se kënnen net drop vertrauen an hir Drop Implementatiounen.
    ///
    /// Dës Method z'implementéieren heescht Adaptere verzichten op nëmmen eenzegen Zougang zu hirer Quell a kënnen nëmme vertrauen op Garantien, déi op Basis vu Methode Empfängerarten gemaach ginn.
    /// De Mangel u limitéierten Zougang erfuerdert och datt Adapter d'ëffentlech API vun der Quell mussen oprechterhalen och wa se Zougang zu senge Bannen hunn.
    ///
    /// D'Callers mussen hirersäits erwaarden datt d'Quell an all Zoustand ass, dee mat senger ëffentlecher API konsequent ass, well Adapter, déi tëscht hinnen an der Quell sëtzen, dee selwechten Zougang hunn.
    /// Besonnesch en Adapter kann méi Elementer verbrauchen wéi strikt noutwendeg.
    ///
    /// D'Gesamtziel vun dësen Ufuerderungen ass de Konsument vun enger Pipeline benotzen ze loossen
    /// * wat an der Quell bleift nodeems d'Iteratioun gestoppt ass
    /// * d'Erënnerung dat onbenotzt ginn ass duerch e verbrauchenden Iterator virzegoen
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// En Iterator-Adapter deen Ausgang produzéiert soulaang wéi deen ënnerläiten Iterator `Result::Ok` Wäerter produzéiert.
///
///
/// Wann e Feeler begéint ass, stoppt den Iterator an de Feeler gëtt gespäichert.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Veraarbecht de gegebene Iterator wéi wann et en `T` amplaz vun engem `Result<T, _>` géif ginn.
/// All Feeler stoppen den banneschten Iterator an d'Gesamtresultat wäert e Feeler sinn.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}