#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// En `RawWaker` erlaabt dem Implementateur vun engem Task executor en [`Waker`] ze kreéieren deen e personaliséiert Wakeup Verhalen ubitt.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Et besteet aus engem Datenzeiger an engem [virtual function pointer table (vtable)][vtable] deen d'Behuele vum `RawWaker` personaliséiert.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// En Datenzeiger, dee ka benotzt ginn fir arbiträr Daten ze späichere wéi vum Exekutor erfuerderlech.
    /// Dëst kéint z
    /// en typ geläschte Pointer op en `Arc` dee mat der Aufgab assoziéiert ass.
    /// De Wäert vun dësem Feld gëtt un all Funktiounen weiderginn, déi als éischte Parameter Deel vun der vtable sinn.
    ///
    data: *const (),
    /// Virtuell Funktioun Zeigentabell déi d'Behuele vun dësem Waker personaliséiert.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Erstellt en neien `RawWaker` aus dem verschaffene `data` Zeiger an `vtable`.
    ///
    /// Den `data` Zeiger kann benotzt ginn fir arbiträr Daten ze späicheren wéi vum Exekutor erfuerderlech.Dëst kéint z
    /// en typ geläschte Pointer op en `Arc` dee mat der Aufgab assoziéiert ass.
    /// De Wäert vun dësem Zeiger gëtt un all Funktiounen weiderginn déi als éischt Parameter Deel vum `vtable` sinn.
    ///
    /// Den `vtable` personaliséiert d'Behuele vun engem `Waker` deen aus engem `RawWaker` erstallt gëtt.
    /// Fir all Operatioun op der `Waker` gëtt déi assoziéiert Funktioun am `vtable` vun der Basis `RawWaker` genannt.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Eng virtuell Funktioun Zeiger Dësch (vtable) déi d'Behuele vun engem [`RawWaker`] spezifizéiert.
///
/// De Zeiger deen un all Funktiounen an der vtable weiderginn ass ass den `data` Zeiger vum zouenen [`RawWaker`] Objet.
///
/// D'Funktiounen an dësem Struktur si just geduecht fir op den `data` Zeiger vun engem richteg gebauten [`RawWaker`] Objet aus der [`RawWaker`] Ëmsetzung geruff ze ginn.
/// Eng vun den enthale Funktiounen ze ruffen mat engem aneren `data` Zeiger verursaacht ondefinéiert Verhalen.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Dës Funktioun gëtt genannt wann den [`RawWaker`] gekloont gëtt, zB wann den [`Waker`] an deem den [`RawWaker`] gespäichert gëtt gekloont gëtt.
    ///
    /// D'Ëmsetzung vun dëser Funktioun muss all Ressourcen behalen déi fir dës zousätzlech Instanz vun enger [`RawWaker`] an assoziéiert Aufgab erfuerderlech sinn.
    /// `wake` op de resultéierende [`RawWaker`] ze ruffen sollt zu enger Erwäche vun der selwechter Aufgab resultéieren déi vum Original [`RawWaker`] erwächt wier.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Dës Funktioun gëtt genannt wann `wake` op der [`Waker`] geruff gëtt.
    /// Et muss d'Aufgab mat dësem [`RawWaker`] erwächen.
    ///
    /// D'Ëmsetzung vun dëser Funktioun muss sécher sinn, all Ressourcen ze verëffentlechen, déi mat dëser Instanz vun enger [`RawWaker`] an assoziéiert Aufgab verbonne sinn.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Dës Funktioun gëtt genannt wann `wake_by_ref` op der [`Waker`] geruff gëtt.
    /// Et muss d'Aufgab mat dësem [`RawWaker`] erwächen.
    ///
    /// Dës Funktioun ass ähnlech wéi `wake`, awer däerf den ugebuedenen Datenzeiger net verbrauchen.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Dës Funktioun gëtt geruff wann en [`RawWaker`] fällt.
    ///
    /// D'Ëmsetzung vun dëser Funktioun muss sécher sinn, all Ressourcen ze verëffentlechen, déi mat dëser Instanz vun enger [`RawWaker`] an assoziéiert Aufgab verbonne sinn.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Erstellt en neien `RawWakerVTable` vun den ugebuedenen `clone`-, `wake`-, `wake_by_ref`-an `drop`-Funktiounen.
    ///
    /// # `clone`
    ///
    /// Dës Funktioun gëtt genannt wann den [`RawWaker`] gekloont gëtt, zB wann den [`Waker`] an deem den [`RawWaker`] gespäichert gëtt gekloont gëtt.
    ///
    /// D'Ëmsetzung vun dëser Funktioun muss all Ressourcen behalen déi fir dës zousätzlech Instanz vun enger [`RawWaker`] an assoziéiert Aufgab erfuerderlech sinn.
    /// `wake` op de resultéierende [`RawWaker`] ze ruffen sollt zu enger Erwäche vun der selwechter Aufgab resultéieren déi vum Original [`RawWaker`] erwächt wier.
    ///
    /// # `wake`
    ///
    /// Dës Funktioun gëtt genannt wann `wake` op der [`Waker`] geruff gëtt.
    /// Et muss d'Aufgab mat dësem [`RawWaker`] erwächen.
    ///
    /// D'Ëmsetzung vun dëser Funktioun muss sécher sinn, all Ressourcen ze verëffentlechen, déi mat dëser Instanz vun enger [`RawWaker`] an assoziéiert Aufgab verbonne sinn.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Dës Funktioun gëtt genannt wann `wake_by_ref` op der [`Waker`] geruff gëtt.
    /// Et muss d'Aufgab mat dësem [`RawWaker`] erwächen.
    ///
    /// Dës Funktioun ass ähnlech wéi `wake`, awer däerf den ugebuedenen Datenzeiger net verbrauchen.
    ///
    /// # `drop`
    ///
    /// Dës Funktioun gëtt geruff wann en [`RawWaker`] fällt.
    ///
    /// D'Ëmsetzung vun dëser Funktioun muss sécher sinn, all Ressourcen ze verëffentlechen, déi mat dëser Instanz vun enger [`RawWaker`] an assoziéiert Aufgab verbonne sinn.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// Den `Context` vun enger asynchroner Aufgab.
///
/// De Moment ass `Context` nëmmen fir Zougang zu engem `&Waker` ze bidden deen benotzt ka ginn fir déi aktuell Aufgab ze erwächen.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Gitt sécher datt mir future-Beweis géint Varianz Ännerungen andeems d'Liewensdauer forcéiert gëtt onverännerlech ze sinn (Argument-Positiouns Liewensdauer sinn contravariant wärend d'Liwwerzäiten zréckginn Positioun covariant sinn).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Erstellt en neien `Context` vun engem `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Nees eng Referenz op den `Waker` fir déi aktuell Aufgab.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// En `Waker` ass e Grëff fir eng Aufgab ze erwächen andeems en dem Exekutor Bescheed seet datt et fäerdeg ass ze lafen.
///
/// Dëse Grëff ëmfaasst eng [`RawWaker`] Instanz, déi dat exekutor-spezifescht Wakeup Verhalen definéiert.
///
///
/// Ëmsetzt [`Clone`], [`Send`] an [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Erwächt d'Aufgab mat dësem `Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Den aktuellen Wakeup Call gëtt iwwer e virtuelle Funktiounsappel un d'Ëmsetzung delegéiert déi vum Exekutor definéiert ass.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Rufft net `drop` un-de Waker gëtt vu `wake` verbraucht.
        crate::mem::forget(self);

        // SAFETY: Dëst ass sécher well `Waker::from_raw` deen eenzege Wee ass
        // fir `wake` an `data` ze initialiséieren an erfuerderlech datt de Benotzer unerkennt datt de Kontrakt vun `RawWaker` oprecht ass.
        //
        unsafe { (wake)(data) };
    }

    /// Erwächt d'Aufgab mat dësem `Waker` assoziéiert ouni den `Waker` ze verbrauchen.
    ///
    /// Dëst ass ähnlech wéi `wake`, awer ka liicht manner effizient sinn am Fall wou en eegene `Waker` verfügbar ass.
    /// Dës Method sollt léiwer wéi `waker.clone().wake()` uruffen.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Den aktuellen Wakeup Call gëtt iwwer e virtuelle Funktiounsappel un d'Ëmsetzung delegéiert déi vum Exekutor definéiert ass.
        //

        // SAFETY: kuckt `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Retour `true` wann dësen `Waker` an eng aner `Waker` déi selwecht Aufgab erwächt hunn.
    ///
    /// Dës Funktioun funktionnéiert op beschten Ustrengungsbasis a ka falsch zréckkommen och wann d 'Waker déiselwecht Aufgab erwächen.
    /// Wéi och ëmmer, wann dës Funktioun `true` zréckbréngt, ass et garantéiert datt d '"Waker`s déiselwecht Aufgab erwächen.
    ///
    /// Dës Funktioun gëtt haaptsächlech fir Optimiséierungszwecker benotzt.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Erstellt en neien `Waker` vun [`RawWaker`].
    ///
    /// D'Behuele vum zréckgekéierte `Waker` ass ondefinéiert wann de Kontrakt definéiert an der ["RawWaker"] an ["RawWakerVTable"] Dokumentatioun net agehale gëtt.
    ///
    /// Dofir ass dës Method onsécher.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // SAFETY: Dëst ass sécher well `Waker::from_raw` deen eenzege Wee ass
            // fir `clone` an `data` ze initialiséieren an erfuerderlech datt de Benotzer unerkennt datt de Kontrakt vun [`RawWaker`] oprecht ass.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // SAFETY: Dëst ass sécher well `Waker::from_raw` deen eenzege Wee ass
        // fir `drop` an `data` ze initialiséieren an erfuerderlech datt de Benotzer unerkennt datt de Kontrakt vun `RawWaker` oprecht ass.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}