#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Erweidert entweder op `$crate::panic::panic_2015` oder `$crate::panic::panic_2021` ofhängeg vun der Editioun vum Uruff.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Behaapt datt zwee Ausdréck gläiche mateneen (mat [`PartialEq`]).
///
/// Op panic dréckt dëse Makro d'Wäerter vun den Ausdréck mat hiren Debug-Representatioune.
///
///
/// Wéi [`assert!`] huet dëse Macro eng zweet Form, wou e personaliséierten panic Message ka ginn.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // D'Remboursementer hei ënnendrënner si bewosst.
                    // Ouni si gëtt de Stack Slot fir de Prêt initialiséiert och ier d'Wäerter verglach ginn, wat zu enger merkbarer Verlangsamung féiert.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // D'Remboursementer hei ënnendrënner si bewosst.
                    // Ouni si gëtt de Stack Slot fir de Prêt initialiséiert och ier d'Wäerter verglach ginn, wat zu enger merkbarer Verlangsamung féiert.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Behaapt datt zwee Ausdréck net gläich matenee sinn (mat [`PartialEq`]).
///
/// Op panic dréckt dëse Makro d'Wäerter vun den Ausdréck mat hiren Debug-Representatioune.
///
///
/// Wéi [`assert!`] huet dëse Macro eng zweet Form, wou e personaliséierten panic Message ka ginn.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // D'Remboursementer hei ënnendrënner si bewosst.
                    // Ouni si gëtt de Stack Slot fir de Prêt initialiséiert och ier d'Wäerter verglach ginn, wat zu enger merkbarer Verlangsamung féiert.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // D'Remboursementer hei ënnendrënner si bewosst.
                    // Ouni si gëtt de Stack Slot fir de Prêt initialiséiert och ier d'Wäerter verglach ginn, wat zu enger merkbarer Verlangsamung féiert.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Behaapt datt e booleschen Ausdrock `true` bei der Runtime ass.
///
/// Dëst wäert den [`panic!`] Macro opruffen wann de geliwwert Ausdrock net bei der Runtime op `true` evaluéiert ka ginn.
///
/// Wéi [`assert!`] huet dëse Macro och eng zweet Versioun, wou e personaliséierten panic Message ka geliwwert ginn.
///
/// # Uses
///
/// Am Géigesaz zu [`assert!`] sinn `debug_assert!` Aussoen nëmmen an net optimiséiertem Build standardméisseg aktivéiert.
/// En optimiséierte Build wäert `debug_assert!` Aussoen net ausféieren, ausser `-C debug-assertions` gëtt un de Compiler weiderginn.
/// Dëst mécht `debug_assert!` nëtzlech fir Kontrollen déi ze deier sinn fir an engem Release-Build präsent ze sinn awer kënne wärend der Entwécklung hëllefräich sinn.
/// D'Resultat vum `debug_assert!` erweideren ass ëmmer gepréift.
///
/// Eng onkontrolléiert Behaaptung erlaabt e Programm an engem onkonsequenten Zoustand weider ze lafen, wat onerwaart Konsequenze kéint hunn awer net Onsécherheet aféiert soulaang dëst nëmmen am séchere Code geschitt.
///
/// D'Leeschtungskäschte vu Behaaptungen sinn awer net moossbar am Allgemengen.
/// Den [`assert!`] duerch den `debug_assert!` z'ersetzen gëtt also nëmmen no grëndlecher Profiléierung encouragéiert, a méi wichteg, nëmmen am séchere Code!
///
/// # Examples
///
/// ```
/// // d'panic Message fir dës Behaaptungen ass de strenge Wäert vum Ausdrock.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // eng ganz einfach Funktioun
/// debug_assert!(some_expensive_computation());
///
/// // behaapten mat engem personaliséierte Message
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Behaapt datt zwee Ausdréck gläiche mateneen.
///
/// Op panic dréckt dëse Makro d'Wäerter vun den Ausdréck mat hiren Debug-Representatioune.
///
/// Am Géigesaz zu [`assert_eq!`] sinn `debug_assert_eq!` Aussoen nëmmen an net optimiséiertem Build standardméisseg aktivéiert.
/// En optimiséierte Build wäert `debug_assert_eq!` Aussoen net ausféieren, ausser `-C debug-assertions` gëtt un de Compiler weiderginn.
/// Dëst mécht `debug_assert_eq!` nëtzlech fir Kontrollen déi ze deier sinn fir an engem Release-Build präsent ze sinn awer kënne wärend der Entwécklung hëllefräich sinn.
///
/// D'Resultat vum `debug_assert_eq!` erweideren ass ëmmer gepréift.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Behaapt datt zwee Ausdréck net gläich matenee sinn.
///
/// Op panic dréckt dëse Makro d'Wäerter vun den Ausdréck mat hiren Debug-Representatioune.
///
/// Am Géigesaz zu [`assert_ne!`] sinn `debug_assert_ne!` Aussoen nëmmen an net optimiséiertem Build standardméisseg aktivéiert.
/// En optimiséierte Build wäert `debug_assert_ne!` Aussoen net ausféieren, ausser `-C debug-assertions` gëtt un de Compiler weiderginn.
/// Dëst mécht `debug_assert_ne!` nëtzlech fir Kontrollen déi ze deier sinn fir an engem Release-Build präsent ze sinn awer kënne wärend der Entwécklung hëllefräich sinn.
///
/// D'Resultat vum `debug_assert_ne!` erweideren ass ëmmer gepréift.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Gitt zréck ob de gegebenen Ausdrock mat engem vun de gegebene Mustere passt.
///
/// Wéi an engem `match` Ausdrock, kann d'Muster eventuell vun `if` gefollegt ginn an e Schutzausdrock deen Zougang zu Nimm huet, déi vum Muster gebonne sinn.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Entwéckelt e Resultat oder propagéiert säi Feeler.
///
/// Den `?` Operator gouf derbäi fir den `try!` z'ersetzen a sollt amplaz benotzt ginn.
/// Ausserdeem ass `try` e reservéiert Wuert am Rust 2018, also wann Dir et benotze musst, musst Dir d [raw-identifier syntax][ris] benotzen: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` passt op de gegebene [`Result`].Am Fall vun der `Ok` Variant huet den Ausdrock de Wäert vum agewéckelte Wäert.
///
/// Am Fall vun der `Err` Variant kritt et den internen Feeler.`try!` féiert dann Konversioun mat `From` aus.
/// Dëst bitt automatesch Konversioun tëscht spezialiséierte Feeler a méi allgemengen.
/// De resultéierende Feeler gëtt dann direkt zréckginn.
///
/// Wéinst dem fréie Retour kann `try!` nëmmen a Funktiounen benotzt ginn déi [`Result`] zréckginn.
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Déi bevorzugte Method fir séier zréckzekommen Feeler
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Déi fréier Method fir séier zréckzekommen Feeler
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Dëst entsprécht:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Schreift formatéiert Daten an e Puffer.
///
/// Dëse Makro acceptéiert en 'writer', e Formatstrang an eng Lëscht vun Argumenter.
/// Argumenter ginn no der spezifizéierter Formatstring formatéiert an d'Resultat gëtt un de Schrëftsteller weiderginn.
/// De Schrëftsteller kann all Wäert mat enger `write_fmt` Method sinn;generell kënnt dat vun enger Ëmsetzung vun entweder der [`fmt::Write`] oder der [`io::Write`] trait.
/// De Macro zréckkënnt egal wéi d `write_fmt` Method zréckgeet;normalerweis eng [`fmt::Result`], oder en [`io::Result`].
///
/// Kuckt [`std::fmt`] fir méi Informatioun iwwer d'Format String Syntax.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// E Modul ka béid `std::fmt::Write` an `std::io::Write` importéieren an `write!` op Objeten nennen, déi entweder implementéieren, well Objeten normalerweis net béid implementéieren.
///
/// Wéi och ëmmer, de Modul muss d'traits qualifizéiert importéieren sou datt hir Nimm net konfliktéieren:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // benotzt fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // benotzt io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Dëse Makro kann och an `no_std` Setups benotzt ginn.
/// An engem `no_std` Setup sidd Dir verantwortlech fir d'Ëmsetzungsdetailer vun de Komponenten.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Schreift formatéiert Daten an e Puffer, mat enger Newline bäigefüügt.
///
/// Op alle Plattformen ass déi nei Linn de LINE FEED Charakter (`\n`/`U+000A`) eleng (keng zousätzlech FRAUGESCHREIWEN (`\r`/`U+000D`).
///
/// Fir méi Informatioun, kuckt [`write!`].Fir Informatiounen iwwer d'Format String Syntax, kuckt [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// E Modul ka béid `std::fmt::Write` an `std::io::Write` importéieren an `write!` op Objeten nennen, déi entweder implementéieren, well Objeten normalerweis net béid implementéieren.
/// Wéi och ëmmer, de Modul muss d'traits qualifizéiert importéieren sou datt hir Nimm net konfliktéieren:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // benotzt fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // benotzt io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Weist net erreechbare Code.
///
/// Dëst ass nëtzlech all Moment wou de Compiler net ka bestëmmen datt e Code net erreechbar ass.Zum Beispill:
///
/// * Match Äerm mat Wuechtbedingungen.
/// * Loopen déi dynamesch ophalen.
/// * Iteratoren déi dynamesch ophalen.
///
/// Wann d'Bestëmmung datt de Code net erreechbar ass falsch ass, gëtt de Programm direkt mat engem [`panic!`] ofgeschloss.
///
/// Den onséchere Kolleg vun dësem Makro ass d [`unreachable_unchecked`] Funktioun, déi ondefinéiert Verhalen verursaache wann de Code erreecht gëtt.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Dëst wäert ëmmer [`panic!`].
///
/// # Examples
///
/// Match Waffen:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // Feeler kompiléieren wann kommentéiert
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // eng vun den äermsten Implementéierunge vun x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Weist onimplementéiert Code duerch Panik mat enger Noriicht vun "not implemented".
///
/// Dëst erlaabt Äre Code ze typechecken, wat nëtzlech ass wann Dir e trait prototypéiert oder implementéiert déi verschidde Methoden erfuerdert déi Dir net plangt all ze benotzen.
///
/// Den Ënnerscheed tëscht `unimplemented!` an [`todo!`] ass datt wärend `todo!` en Intent vermëttelt d'Funktionalitéit méi spéit z'implementéieren an d'Botschaft "not yet implemented" ass, mécht `unimplemented!` keng sou Fuerderungen.
/// Säi Message ass "not implemented".
/// Och e puer IDEe markéieren "Todo!` S.
///
/// # Panics
///
/// Dëst wäert ëmmer [`panic!`] well `unimplemented!` just eng Kuerzaarbecht fir `panic!` mat engem fixen, spezifesche Message ass.
///
/// Wéi `panic!` huet dëse Makro eng zweet Form fir personaliséiert Wäerter ze weisen.
///
/// # Examples
///
/// Sot mir hunn en trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Mir wëllen `Foo` fir 'MyStruct' implementéieren, awer aus irgendege Grënn mécht et nëmme Sënn d `bar()` Funktioun ëmzesetzen.
/// `baz()` an `qux()` mussen nach ëmmer an eiser Implementatioun vun `Foo` definéiert ginn, awer mir kënnen `unimplemented!` an hiren Definitioune benotze fir eise Code ze kompiléieren.
///
/// Mir wëllen nach ëmmer datt eise Programm ophält wann déi net implementéiert Methoden erreecht ginn.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Et mécht kee Sënn `baz` engem `MyStruct`, also hu mir guer keng Logik hei.
/////
///         // Dëst wäert "thread 'main' panicked at 'not implemented'" affichéieren.
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Mir hunn hei Logik, Mir kënnen e Message derbäi unimplementéiert!fir eis Auslousung ze weisen.
///         // Dëst weist: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Weist net fäerdeg Code.
///
/// Dëst kann nëtzlech sinn wann Dir Prototyping sidd a sicht just fir Äre Code Typecheck ze hunn.
///
/// Den Ënnerscheed tëscht [`unimplemented!`] an `todo!` ass datt wärend `todo!` en Intent vermëttelt d'Funktionalitéit spéider ëmzesetzen an d'Botschaft "not yet implemented" ass, mécht `unimplemented!` keng Fuerderungen.
/// Säi Message ass "not implemented".
/// Och e puer IDEe markéieren "Todo!` S.
///
/// # Panics
///
/// Dëst wäert ëmmer [`panic!`].
///
/// # Examples
///
/// Hei ass e Beispill vu Code amgaang.Mir hunn en trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Mir wëllen `Foo` op eng vun eisen Typen implementéieren, awer mir wëllen och als éischt just op `bar()` schaffen.Fir eise Code ze kompiléieren, musse mir `baz()` implementéieren, sou datt mir `todo!` benotze kënnen:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // Ëmsetzung geet hei
///     }
///
///     fn baz(&self) {
///         // loosst eis keng Suergen iwwer d'Ëmsetzung vun baz() fir de Moment
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // mir benotze mol net baz(), also ass dat gutt.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Definitiounen vun agebaute Makroen.
///
/// Déi meescht Makro-Eegeschafte (Stabilitéit, Visibilitéit, asw.) Ginn hei vum Quellcode geholl, mat Ausnam vun Expansiounsfunktiounen, déi Makroingänge an Ausgänge transforméieren, dës Funktioune gi vum Compiler zur Verfügung gestallt.
///
///
pub(crate) mod builtin {

    /// Verursaacht datt Kompiléierung mat der gegebene Feelermeldung ausfält wann se begéint sinn.
    ///
    /// Dëse Makro soll benotzt ginn wann en crate eng bedingt Kompiléierungsstrategie benotzt fir besser Feelermeldunge fir falsch Bedéngungen ze bidden.
    ///
    /// Et ass de Compiler-Niveau Form vun [`panic!`], awer emittéiert e Feeler wärend *Kompiléierung* anstatt bei *Runtime*.
    ///
    /// # Examples
    ///
    /// Zwee sou Beispiller si Makroen an `#[cfg]` Ëmfeld.
    ///
    /// Emitt e bessere Compiler Feeler wann e Macro ongëlteg Wäerter weiderginn ass.
    /// Ouni de leschte branch, géif de Compiler nach ëmmer e Feeler emittéieren, awer de Feeler säi Message géif déi zwee gëlteg Wäerter net ernimmen.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Emitt Compiler Feeler wann ee vun enger Zuel vu Featuren net verfügbar ass.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Konstruéiert Parameter fir déi aner String-Formatéierung Makroen.
    ///
    /// Dëse Makro funktionnéiert andeems en Formatéierungs String wuertwiertlech enthält mat `{}` fir all weider Argument weiderginn.
    /// `format_args!` bereet déi zousätzlech Parameter vir, fir sécher ze sinn, datt d'Ausgab als String interpretéiert ka ginn an d'Argumenter zu engem eenzegen Typ kanonikaliséiert.
    /// All Wäert deen den [`Display`] trait implementéiert kann op `format_args!` weidergeleet ginn, sou wéi all [`Debug`] Ëmsetzung un en `{:?}` an der Formatéierungsstreng weiderginn.
    ///
    ///
    /// Dëse Makro produzéiert e Wäert vum Typ [`fmt::Arguments`].Dëse Wäert kann op d'Makroen bannent [`std::fmt`] weidergeleet gi fir nëtzlech Viruleedung auszeféieren.
    /// All aner Formatéiermakroen ([`Format!`], [`write!`], [`println!`], asw.) Ginn duerch dësen proxiert.
    /// `format_args!`, am Géigesaz zu de ofgeleete Makroen, vermeit Koup Allocatiounen.
    ///
    /// Dir kënnt den [`fmt::Arguments`] Wäert benotzen deen `format_args!` an `Debug` an `Display` Kontexter zréckkuckt wéi hei ënnendrënner.
    /// D'Beispill weist och datt `Debug` an `Display` Format op déiselwecht Saach: déi interpoléiert Format String an `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Fir méi Informatioun, kuckt d'Dokumentatioun am [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Selwecht wéi `format_args`, füügt awer um Enn eng Newline bäi.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Inspizéiert eng Ëmweltvariabel beim Zesummestellen.
    ///
    /// Dëse Makro wäert sech op de Wäert vun der genannter Ëmweltvariabel bei der Kompiléierungszäit erweideren, wat en Ausdrock vum Typ `&'static str` gëtt.
    ///
    ///
    /// Wann d'Ëmweltvariabel net definéiert ass, da gëtt e Kompilatiounsfeeler ausgestraalt.
    /// Fir kee Kompiléierungsfeeler auszestellen, benotzt den [`option_env!`] Macro amplaz.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Dir kënnt d'Feelermeldung personaliséieren andeems Dir e String als zweete Parameter weidergitt:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Wann d `documentation` Ëmfeldvariabel net definéiert ass, kritt Dir de folgende Feeler:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Optional inspizeiert eng Ëmweltvariabel beim Zesummestellen.
    ///
    /// Wann déi genannte Ëmfeldvariabel bei der Kompiléierzäit präsent ass, wäert dëst sech an en Ausdrock vum Typ `Option<&'static str>` erweideren, deem säi Wäert `Some` vum Wäert vun der Ëmweltvariabel ass.
    /// Wann d'Ëmweltvariabel net präsent ass, da wäert dëst op `None` erweidert ginn.
    /// Kuckt [`Option<T>`][Option] fir méi Informatiounen iwwer dësen Typ.
    ///
    /// E Kompiléierungszäitfeel gëtt ni emittéiert wann Dir dëse Makro benotzt, egal ob d'Ëmweltvariabel präsent ass oder net.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatenates Identificateuren an een Identifizéierer.
    ///
    /// Dëse Makro hëlt all Zuel vu Komma-getrennten Identifizéierer, a verbannt se all an een, wat en Ausdrock gëtt wat en neien Identifizéierer ass.
    /// Bedenkt datt Hygiène et sou mécht datt dëse Makro keng lokal Variabelen erfaasst.
    /// Och als allgemeng Regel sinn Makroen nëmmen an der Artikel, der Erklärung oder der Ausdréckspositioun erlaabt.
    /// Dat heescht wann Dir dëse Makro benotze kënnt fir op existent Variabelen, Funktiounen oder Moduler etc ze referenzéieren, kënnt Dir keen neien domat definéieren.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (nei, lëschteg, Numm) { }//net benotzbar op dës Manéier!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Verknëppelt Literaler an eng statesch String Scheif.
    ///
    /// Dëse Makro hëlt eng Zuel vu kommaseparéierte Literaler, wat en Ausdrock vum Typ `&'static str` ergëtt, deen all déi literar verknëppelt lénks-no-riets duerstellt.
    ///
    ///
    /// Integer a Floating Point Literaler gi striktéiert fir matenee verbonnen ze ginn.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Erweidert sech op d'Linnennummer op déi en opgeruff gouf.
    ///
    /// Mat [`column!`] an [`file!`] ginn dës Makroen Debugging Informatioun fir Entwéckler iwwer de Standort an der Quell.
    ///
    /// Den erweiderten Ausdrock huet den Typ `u32` an ass 1-baséiert, sou datt déi éischt Zeil an all Datei op 1, déi zweet op 2, etc.
    /// Dëst ass konsequent mat Feelermeldunge vu gemeinsame Compiler oder populär Editoren.
    /// Déi zréckgezunn Linn ass *net onbedéngt* d'Linn vun der `line!` Opruff selwer, mä éischter déi éischt Makro Uropféierung déi bis zur Opruffung vum `line!` Makro féiert.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Erweidert sech op d'Kolonnennummer wou se opgeruff gouf.
    ///
    /// Mat [`line!`] an [`file!`] ginn dës Makroen Debugging Informatioun fir Entwéckler iwwer de Standort an der Quell.
    ///
    /// Den erweiderten Ausdrock huet den Typ `u32` an ass 1-baséiert, sou datt déi éischt Kolonn an all Zeil op 1, déi zweet op 2, etc.
    /// Dëst ass konsequent mat Feelermeldunge vu gemeinsame Compiler oder populär Editoren.
    /// Déi zréckkomm Kolonn ass *net onbedéngt* d'Linn vun der `column!` Opruff selwer, mä éischter déi éischt Makro Uruffung féiert zu der Opruffung vum `column!` Makro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Erweidert sech op den Dateinumm an deem en opgeruff gouf.
    ///
    /// Mat [`line!`] an [`column!`] ginn dës Makroen Debugging Informatioun fir Entwéckler iwwer de Standort an der Quell.
    ///
    /// Den erweiderten Ausdrock huet den Typ `&'static str`, an déi zréckgeschéckte Datei ass net d'Aufruffung vum `file!` Macro selwer, mä éischter déi éischt Macro Invitatioun déi zu der Opruffung vum `file!` Macro féiert.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Stringéiert seng Argumenter.
    ///
    /// Dëse Makro gëtt en Ausdrock vum Typ `&'static str`, wat d'Strengifikatioun vun all den tokens ass, deen dem Makro weiderginn ass.
    /// Keng Restriktioune ginn op d'Syntax vun der Makro-Uruff selwer gesat.
    ///
    /// Bedenkt datt déi erweidert Resultater vum Input tokens sech am future ännere kënnen.Dir sollt oppassen wann Dir op d'Ausgab vertrauen.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Enthält eng UTF-8 kodéiert Datei als String.
    ///
    /// D'Datei läit relativ zu der aktueller Datei (ähnlech wéi Moduler fonnt ginn).
    /// De geliwwertene Wee gëtt op kompiléierter Zäit plattformspezifesch Manéier interpretéiert.
    /// Also, zum Beispill, eng Opruff mat engem Windows Wee mat Réckschréiegt `\` géif net korrekt op Unix kompiléieren.
    ///
    ///
    /// Dëse Makro gëtt en Ausdrock vum Typ `&'static str`, deen den Inhalt vun der Datei ass.
    ///
    /// # Examples
    ///
    /// Assume et ginn zwee Dateien am selwechte Verzeechnes mat folgendem Inhalt:
    ///
    /// Datei 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Datei 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// 'main.rs' ze kompiléieren an de resultéierende Binär auszeféieren dréckt "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Enthält eng Datei als Referenz zu engem Byte Array.
    ///
    /// D'Datei läit relativ zu der aktueller Datei (ähnlech wéi Moduler fonnt ginn).
    /// De geliwwertene Wee gëtt op kompiléierter Zäit plattformspezifesch Manéier interpretéiert.
    /// Also, zum Beispill, eng Opruff mat engem Windows Wee mat Réckschréiegt `\` géif net korrekt op Unix kompiléieren.
    ///
    ///
    /// Dëse Makro gëtt en Ausdrock vum Typ `&'static [u8; N]`, deen den Inhalt vun der Datei ass.
    ///
    /// # Examples
    ///
    /// Assume et ginn zwee Dateien am selwechte Verzeechnes mat folgendem Inhalt:
    ///
    /// Datei 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Datei 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// 'main.rs' ze kompiléieren an de resultéierende Binär auszeféieren dréckt "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Erweidert sech op e String deen den aktuelle Modul Wee duerstellt.
    ///
    /// Den aktuelle Modul Wee kann als d'Hierarchie vu Moduler geduecht ginn, déi zréck an d'crate root féieren.
    /// Den éischte Bestanddeel vum Wee zréck ass den Numm vum crate deen am Moment kompiléiert gëtt.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Evaluéiert boolesch Kombinatioune vu Konfiguratiounsfändelen am Zesummestellen.
    ///
    /// Nieft dem `#[cfg]` Attribut gëtt dëse Makro zur Verfügung gestallt fir de Boolschen Ausdrock Evaluatioun vu Konfiguratiounsfändelen z'erméiglechen.
    /// Dëst féiert dacks zu manner verduebelte Code.
    ///
    /// D'Syntax, déi dësem Makro gëtt, ass déiselwecht Syntax wéi den [`cfg`] Attribut.
    ///
    /// `cfg!`, am Géigesaz zu `#[cfg]`, léisst kee Code ewech a bewäert nëmmen op richteg oder falsch.
    /// Zum Beispill, all Blocen an engem if/else Ausdrock musse valabel sinn wann `cfg!` fir d'Konditioun benotzt gëtt, egal wéi `cfg!` evaluéiert.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Parséiert eng Datei als Ausdrock oder en Element nom Kontext.
    ///
    /// D'Datei läit relativ zu der aktueller Datei (ähnlech wéi Moduler fonnt ginn).De geliwwertene Wee gëtt op kompiléierter Zäit plattformspezifesch Manéier interpretéiert.
    /// Also, zum Beispill, eng Opruff mat engem Windows Wee mat Réckschréiegt `\` géif net korrekt op Unix kompiléieren.
    ///
    /// Dëse Macro benotzen ass dacks eng schlecht Iddi, well wann d'Datei als Ausdrock analyséiert gëtt, gëtt et onhygienesch an de Code ronderëm gesat.
    /// Dëst kéint zu Variabelen oder Funktiounen resultéieren, déi anescht sinn wéi dat wat d'Datei erwaart huet wann et Variabelen oder Funktiounen déi de selwechten Numm an der aktueller Datei hunn.
    ///
    ///
    /// # Examples
    ///
    /// Assume et ginn zwee Dateien am selwechte Verzeechnes mat folgendem Inhalt:
    ///
    /// Datei 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Datei 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 'main.rs' ze kompiléieren an de resultéierende Binär auszeféieren dréckt "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Behaapt datt e booleschen Ausdrock `true` bei der Runtime ass.
    ///
    /// Dëst wäert den [`panic!`] Macro opruffen wann de geliwwert Ausdrock net bei der Runtime op `true` evaluéiert ka ginn.
    ///
    /// # Uses
    ///
    /// Behaaptungen ginn ëmmer a béid Debug-a Release-Builds kontrolléiert a kënnen net ausgeschalt ginn.
    /// Kuckt [`debug_assert!`] fir Behaaptungen déi net an der Verëffentlechung baut standardméisseg aktivéiert.
    ///
    /// Onsécherere Code kann op `assert!` vertrauen fir Run-Time Invararianer duerchzesetzen, déi, wa verletzt ginn, zu Onsécherheet féiere kënnen.
    ///
    /// Aner Notzungsfäll vun `assert!` schloen Testen an Duerchféierung vu Laafzäit-Invarianter a séchere Code (deem seng Verstouss net zu Onsécherheet féiere kann).
    ///
    ///
    /// # Benotzerdefinéiert Messagen
    ///
    /// Dëse Makro huet eng zweet Form, wou e personaliséierten panic Message mat oder ouni Argumenter fir Formatéiere geliwwert ka ginn.
    /// Kuckt [`std::fmt`] fir Syntax fir dës Form.
    /// Ausdréck, déi als Formatargumenter benotzt ginn, ginn nëmmen evaluéiert wann d'Behaaptung net klappt.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // d'panic Message fir dës Behaaptungen ass de strenge Wäert vum Ausdrock.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // eng ganz einfach Funktioun
    ///
    /// assert!(some_computation());
    ///
    /// // behaapten mat engem personaliséierte Message
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Inline Assemblée.
    ///
    /// Liest d [unstable book] fir d'Benotzung.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM-Stil Inline Assemblée.
    ///
    /// Liest d [unstable book] fir d'Benotzung.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Modulniveau Inline Assemblée.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Drécker hunn tokens an de Standardausgang weiderginn.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Aktivéiert oder deaktivéiert Tracefunktionalitéit benotzt fir Debuggen vun anere Makroen.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Attributmakro benotzt fir ofgeleet Makroen anzesetzen.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Attributmakro op eng Funktioun applizéiert fir en zu engem Eenheetstest ze maachen.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Attributmakro ugewannt op eng Funktioun fir se an e Benchmarktest ze maachen.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// En Ëmsetzung Detail vun den `#[test]` an `#[bench]` Makroen.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Attributmakro op eng statesch applizéiert fir en als globalen Allocateur anzeschreiwen.
    ///
    /// Kuckt och [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Hält den Artikel op deen et ugewannt gëtt wann de weidere Wee zougänglech ass, a läscht en anescht.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Erweidert all `#[cfg]` an `#[cfg_attr]` Attributer am Codefragment op deen et applizéiert gëtt.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Onbestänneg Implementatioun Detail vum `rustc` Compiler, benotzt net.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Onbestänneg Implementatioun Detail vum `rustc` Compiler, benotzt net.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}