Panics den aktuelle Fuedem.

Dëst erlaabt e Programm direkt ofzeschléissen a Feedback fir den Uruff vum Programm ze ginn.
`panic!` soll benotzt ginn wann e Programm en net erhuelbare Staat erreecht.

Dëse Makro ass de perfekte Wee fir Konditiounen am Beispillcode an an Tester ze behaapten.
`panic!` ass enk mat der `unwrap` Method vu béid [`Option`][ounwrap] an [`Result`][runwrap] enums gebonnen.
Béid Implementatiounen nennen `panic!` wa se op [`None`] oder [`Err`] Varianten gesat sinn.

Wann Dir `panic!()` benotzt, kënnt Dir eng String Notzlaascht spezifizéieren, déi mat der [`format!`] Syntax gebaut gëtt.
Déi Notzlaascht gëtt benotzt wann Dir den panic an den Uruff Rust thread injizéiert, wouduerch de Fuedem ganz op panic verursaacht.

D'Verhalen vum Standard `std` hook, d
de Code deen direkt leeft nodeems den panic opgeruff gëtt, ass d'Notzlaascht vun der Noriicht op `stderr` ze drécken zesumme mat der file/line/column Informatioun vum `panic!()` Uruff.

Dir kënnt den panic hook mat [`std::panic::set_hook()`] iwwerschreiwe.
Bannen am hook kann een panic als `&dyn Any + Send` opruffen, deen entweder en `&str` oder `String` enthält fir regelméisseg `panic!()` Uruffungen.
Zu panic mat engem Wäert vun engem aneren aneren Typ, kann [`panic_any`] benotzt ginn.

[`Result`] enum ass dacks eng besser Léisung fir sech vu Feeler erëmzefannen wéi den `panic!` Macro.
Dëse Makro soll benotzt ginn fir ze vermeiden datt Dir falsch Wäerter benotzt, wéi aus externen Quellen.
Detailléiert Informatioun iwwer Feelerbehandlung gëtt am [book] fonnt.

Kuckt och de Macro [`compile_error!`], fir Feeler bei der Kompiléierung ze erhéijen.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Aktuell Ëmsetzung

Wann den Haaptthema panics all Är Themen ofschléisst an Äre Programm mam Code `101` ofschléisst.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





