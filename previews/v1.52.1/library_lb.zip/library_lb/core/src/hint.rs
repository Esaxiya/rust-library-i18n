#![stable(feature = "core_hint", since = "1.27.0")]

//! Tipps fir de Compiler dee beaflosst wéi de Code soll emittéiert oder optimiséiert ginn.
//! Hiweiser kënnen d'Zäit oder d'Runtime kompiléieren.

use crate::intrinsics;

/// Informéiert de Compiler datt dëse Punkt am Code net erreechbar ass, fir weider Optimisatiounen z'erméiglechen.
///
/// # Safety
///
/// Dës Funktioun z'erreechen ass komplett *ondefinéiert Verhalen*(UB).Besonnesch de Compiler geet dovun aus datt all UB ni dierf geschéien, an dofir all Branchen eliminéiert déi zu engem Uruff op `unreachable_unchecked()` kommen.
///
/// Wéi all Instanzen vun UB, wann dës Virgab falsch ass, dh den `unreachable_unchecked()` Uruff ass tatsächlech erreechbar bei all méigleche Kontrollfloss, wäert de Compiler déi falsch Optimisatiounsstrategie uwenden, a kann heiansdo souguer korrupte scheinbar net verknëppelte Code korruptéieren, wat e schwéier Problemer ze debuggen.
///
///
/// Benotzt dës Funktioun nëmmen wann Dir beweise kënnt datt de Code et ni nennt.
/// Soss betruecht den [`unreachable!`] Macro ze benotzen, deen net Optimiséierungen erlaabt awer panic wann se ausgefouert gëtt.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` ass ëmmer positiv (net null), dofir wäert `checked_div` ni `None` zréckginn.
/////
///     // Dofir ass déi aner branch net erreechbar.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // SAFETY: de Sécherheetsvertrag fir `intrinsics::unreachable` muss
    // vum Uruff oprechterhalen.
    unsafe { intrinsics::unreachable() }
}

/// Emittéiert eng Maschinninstruktioun fir de Prozessor ze signaliséieren datt hien an enger beschäftegter Waart Spin-Loop ("Spin-Lock") leeft.
///
/// Beim Empfang vum Spin-Loop Signal kann de Prozessor säi Verhalen optimiséieren andeems se zum Beispill Stroum spuert oder hyper-Threaden wiesselt.
///
/// Dës Funktioun ass anescht wéi [`thread::yield_now`] déi direkt dem System Plänger gëtt, wärend `spin_loop` net mam Betribssystem interagéiert.
///
/// E gemeinsame Benotzungsfall fir `spin_loop` implementéiert begrenzte optimistesch Spinning an engem CAS Loop a Synchroniséierungsprimitiven.
/// Fir Probleemer wéi Prioritéit Inversioun ze vermeiden, ass et staark recommandéiert datt d'Spin Loop no engem endleche Betrag vun Iteratiounen ofgeschloss gëtt an eng entspriechend Blockéierungssyscall gemaach gëtt.
///
///
/// **Notiz**: Op Plattformen déi keng Empfang vu Spin-Loop Tipps ënnerstëtzen, mécht dës Funktioun guer näischt.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // E gemeinsame atomesche Wäert dee Fuedem benotze fir ze koordinéieren
/// let live = Arc::new(AtomicBool::new(false));
///
/// // An engem Hannergrond Fuedem setzen mir eventuell de Wäert
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Maacht eng Aarbecht, da maacht de Wäert live
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Zréck op eisem aktuellen Fuedem waart mir op de Wäert gesat gëtt
/// while !live.load(Ordering::Acquire) {
///     // D'Spin-Loop ass en Hiweis op d'CPU datt mir waarden, awer wahrscheinlech net ganz laang
/////
///     hint::spin_loop();
/// }
///
/// // De Wäert ass elo gesat
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // SAFETY: den `cfg` attr garantéiert datt mir dëst nëmmen op x86 Ziler ausféieren.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // SAFETY: den `cfg` attr garantéiert datt mir dëst nëmmen op x86_64 Ziler ausféieren.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // SAFETY: den `cfg` attr garantéiert datt mir dëst nëmmen op aarch64 Ziler ausféieren.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // SAFETY: den `cfg` attr garantéiert datt mir dëst nëmmen op Aarmziler ausféieren
            // mat Ënnerstëtzung fir d v6 Feature.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Eng Identitéitsfunktioun déi *__ den __* Hiweiser __ * un de Compiler fir maximal pessimistesch ze sinn iwwer wat `black_box` kéint maachen.
///
/// Am Géigesaz zu [`std::convert::identity`] gëtt en Rust Compiler encouragéiert unzehuelen datt `black_box` `dummy` op all méiglech valabel Manéier benotze kann datt den Rust Code erlaabt ass ouni ondefinéiert Verhalen am Ruffcode anzeféieren.
///
/// Dëse Besëtz mécht `black_box` nëtzlech fir Code ze schreiwen an deem gewësse Optimiséierungen net gewënscht sinn, wéi zum Beispill Benchmarks.
///
/// Bedenkt awer datt `black_box` nëmmen (a kann nëmme sinn) op enger "best-effort" Basis geliwwert ginn.D'Ausmooss wéi et Optimisatiounen blockéiere kann variéieren jee no der Plattform an dem Code-gen Backend benotzt.
/// Programmer kënnen net op `black_box` fir *Korrektheet* op iergendeng Manéier vertrauen.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Mir mussen d'Argument "use" iergendwéi LLVM net introspektéieren, an op Ziler déi et ënnerstëtzen kënne mir normalerweis Inline Assemblée benotze fir dëst ze maachen.
    // D'Interpretatioun vum LLVM vun der Inline Assemblée ass datt et gutt ass eng schwaarz Këscht.
    // Dëst ass net déi gréissten Ëmsetzung well et wahrscheinlech méi deoptimiséiert wéi mir wëllen, awer et ass bis elo gutt genuch.
    //
    //

    #[cfg(not(miri))] // Dëst ass just en Hiweis, also ass et gutt an Miri ze sprangen.
    // SAFETY: d'Inline Assemblée ass en No-op.
    unsafe {
        // FIXME: Kann net `asm!` benotzen well et MIPS an aner Architekturen net ënnerstëtzt.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}