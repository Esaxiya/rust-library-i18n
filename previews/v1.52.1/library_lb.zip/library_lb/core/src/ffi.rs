#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! Utilities am Zesummenhang mat auslännesche Funktiounsinterface (FFI) Bindungen.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// Äquivalent mam C's `void` Typ wann se als [pointer] benotzt gëtt.
///
/// Am Wesentlechen ass `*const c_void` gläichwäerteg dem C's `const void*` an `*mut c_void` entsprécht dem C's `void*`.
/// Dat gesot, dëst ass *net* déiselwecht wéi C's `void` Retourtyp, wat Rust's `()` Typ ass.
///
/// Fir Zeigefanger op opaken Typen am FFI ze modelléieren, bis `extern type` stabiliséiert ass, ass et recommandéiert en newtype Wrapper ronderëm en eidelen Byte Array ze benotzen.
///
/// Kuckt d [Nomicon] fir Detailer.
///
/// Et kéint een `std::os::raw::c_void` benotzen wann se en alen Rust Compiler bis op 1.1.0 wëllen ënnerstëtzen.
/// Nom Rust 1.30.0 gouf et vun dëser Definitioun nei exportéiert.
/// Fir méi Informatioun liest w.e.g. [RFC 2521].
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB, fir datt LLVM de Void Zeigerentyp erkennt an duerch Extensiounsfunktiounen wéi malloc(), musse mir et als i8 * am LLVM Bitcode duerstellen.
// Den enum benotzt hei garantéiert dëst a verhënnert Mëssbrauch vum "raw" Typ andeems nëmme privat Varianten hunn.
// Mir brauchen zwou Varianten, well de Compiler beschwéiert sech iwwer d'Repr Attribut anescht a mir brauche mindestens eng Variant well soss wier den Enum onbewunnt an op d'mannst Dereferenzéiere sou Zeigeféier UB.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// Basis Ëmsetzung vun engem `va_list`.
// Den Numm ass WIP, benotzt `VaListImpl` fir elo.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // Invariant iwwer `'f`, sou datt all `VaListImpl<'f>` Objet un d'Regioun vun der Funktioun gebonnen ass an där et definéiert ass
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 ABI Ëmsetzung vun engem `va_list`.
/// Kuckt d [AArch64 Procedure Call Standard] fir méi Detailer.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC ABI Ëmsetzung vun engem `va_list`.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 ABI Ëmsetzung vun engem `va_list`.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// E Wrapper fir en `va_list`
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Konvertéiert en `VaListImpl` an en `VaList` dee binär-kompatibel mat C's `va_list` ass.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Konvertéiert en `VaListImpl` an en `VaList` dee binär-kompatibel mat C's `va_list` ass.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// De VaArgSafe trait muss an ëffentlechen Interfaces benotzt ginn, awer d'trait selwer däerf net ausserhalb vun dësem Modul benotzt ginn.
// D'Benotzer erlaben den trait fir en neien Typ ëmzesetzen (doduerch datt de va_arg intrinsesch op engem neien Typ ka benotzt ginn) wäert méiglecherweis ondefinéiert Verhalen verursaachen.
//
// FIXME(dlrobertson): Fir de VaArgSafe trait an enger ëffentlecher Interface ze benotzen awer och sécherzestellen datt et net anzwuesch benotzt ka ginn, muss den trait ëffentlech an engem private Modul sinn.
// Wann den RFC 2145 implementéiert ass, kuckt no dëst ze verbesseren.
//
//
//
//
mod sealed_trait {
    /// Trait wat erlaabt erlaabt Zorten mat [super::VaListImpl::arg] ze benotzen.
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Fortschrëtt zum nächsten Arg.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // SAFETY: den Uruff muss de Sécherheetsvertrag fir `va_arg` oprechterhalen.
        unsafe { va_arg(self) }
    }

    /// Kopéiert den `va_list` op der aktueller Plaz.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // SAFETY: den Uruff muss de Sécherheetsvertrag fir `va_end` oprechterhalen.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // SAFETY: mir schreiwen op d `MaybeUninit`, also ass se initialiséiert an `assume_init` ass legal
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: dëst soll `va_end` nennen, awer et gëtt kee proppere Wee fir
        // garantéiert datt `drop` ëmmer an säin Uruff gezeechent gëtt, sou datt den `va_end` direkt vun der selwechter Funktioun wéi den entspriechende `va_copy` geruff gëtt.
        // `man va_end` seet datt C dëst erfuerdert, an LLVM follegt am Fong d'C Semantik, also musse mir sécher sinn datt `va_end` ëmmer vun der selwechter Funktioun wéi `va_copy` genannt gëtt.
        //
        // Fir méi Detailer, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // Dëst funktionnéiert elo, well `va_end` ass en No-Op op all aktuellen LLVM Ziler.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// Zerstéiert d'Arglist `ap` no der Initialiséierung mat `va_start` oder `va_copy`.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// Kopéiert déi aktuell Lag vun der arglist `src` op d'arglist `dst`.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// Luet en Argument vum Typ `T` vum `va_list` `ap` a vergréissert d'Argument `ap` weist op.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}