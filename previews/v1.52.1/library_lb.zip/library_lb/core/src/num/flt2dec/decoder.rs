//! Enkodéiert e Schwammpunktwäert an eenzel Deeler a Feelerberäicher.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Decodéiert net signéiert endleche Wäert, sou datt:
///
/// - Den originale Wäert ass gläich wéi `mant * 2^exp`.
///
/// - All Zuel vun `(mant - minus)*2^exp` bis `(mant + plus)* 2^exp` wäert den originelle Wäert ofrennen.
/// D'Sortiment ass nëmmen inklusiv wann `inclusive` `true` ass.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Déi skaléiert Mantissa.
    pub mant: u64,
    /// Déi ënnescht Feeler Gamme.
    pub minus: u64,
    /// Den ieweschte Feelerberäich.
    pub plus: u64,
    /// Dee gedeelt Exponent an der Basis 2.
    pub exp: i16,
    /// Wouer wann de Feelerberäich inklusiv ass.
    ///
    /// Am IEEE 754 ass dat richteg wann d'original Mantissa souguer war.
    pub inclusive: bool,
}

/// Decodéiert net ënnerschriwwe Wäert.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Onendlechkeeten, entweder positiv oder negativ.
    Infinite,
    /// Null, entweder positiv oder negativ.
    Zero,
    /// Endlech Zuelen mat weideren dekodéierte Felder.
    Finite(Decoded),
}

/// E Floating Point Typ dee kann 'decodéieren' d.
pub trait DecodableFloat: RawFloat + Copy {
    /// De Minimum positive normaliséierte Wäert.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Returns en Zeechen (richteg wann negativ) an `FullDecoded` Wäert vun der uginn Schwammpunkt Zuel.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // Noperen: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode erhält ëmmer den Exponent, sou datt d'Mantissa fir Ënnernormale skaléiert gëtt.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // Noperen: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // wou maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // Noperen: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}