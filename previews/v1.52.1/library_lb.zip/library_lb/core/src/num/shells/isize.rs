//! Konstanten fir den Zeigefangergréisst ënnerschriwwenen ganzzuelegen Typ.
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! Neie Code soll d'assoziéiert Konstante direkt op der primitiver Zort benotzen.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }