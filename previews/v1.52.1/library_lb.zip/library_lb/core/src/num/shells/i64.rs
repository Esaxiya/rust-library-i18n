//! Konstante fir de 64-Bit ënnerschriwwe ganz Zuelentyp.
//!
//! *[See also the `i64` primitive type][i64].*
//!
//! Neie Code soll d'assoziéiert Konstante direkt op der primitiver Zort benotzen.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i64`"
)]

int_module! { i64 }