//! Konstante fir den 8-Bit net ënnerschriwwe ganzt Typ.
//!
//! *[See also the `u8` primitive type][u8].*
//!
//! Neie Code soll d'assoziéiert Konstante direkt op der primitiver Zort benotzen.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u8`"
)]

int_module! { u8 }