//! Benotzerdefinéiert arbiträr-Präzisioun Zuel (bignum) Ëmsetzung.
//!
//! Dëst ass entwéckelt fir de Koup Bewëllegung op Käschte vum Stack Gedächtnis ze vermeiden.
//! De stäerkste benotzt bignum Typ, `Big32x40`, ass limitéiert vun 32 × 40=1.280 bëssen an dauert héchstens 160 Bytes Stack Erënnerung.
//! Dëst ass méi wéi genuch fir all méiglech endlech `f64` Wäerter ze verdrängen.
//!
//! Prinzipiell ass et méiglech verschidde Bignumtypen fir verschidden Inputs ze hunn, awer mir maachen dat net fir de Code bloat ze vermeiden.
//!
//! All Bignum gëtt nach no den aktuellen Usagen verfollegt, also ass et normalerweis egal.
//!

// Dëst Modul ass nëmme fir dec2flt a flt2dec, an nëmmen ëffentlech wéinst Koretests.
// Et ass net virgesinn ze stabiliséieren.
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// Arithmetesch Operatiounen erfuerderlech vu Bignums.
pub trait FullOps: Sized {
    /// Retour `(carry', v')` sou datt `carry' * 2^W + v' = self + other + carry`, wou `W` d'Zuel vu Stécker an `Self` ass.
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// Retour `(carry', v')` sou datt `carry'*2^W + v' = self* other + carry`, wou `W` d'Zuel vu Stécker an `Self` ass.
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// Retour `(carry', v')` sou datt `carry'*2^W + v' = self* other + other2 + carry`, wou `W` d'Zuel vu Stécker an `Self` ass.
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// Retour `(quo, rem)` sou datt `borrow *2^W + self = quo* other + rem` an `0 <= rem < other`, wou `W` d'Zuel vu Bits an `Self` ass.
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // Dëst kann net iwwerflësseg sinn;d'Ausgab ass tëscht `0` an `2 * 2^nbits - 1`.
                    // FIXME: wäert LLVM dëst an ADC oder ähnlech optiméieren?
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // Dëst kann net iwwerflësseg sinn;
                    // d'Ausgab ass tëscht `0` an `2^nbits * (2^nbits - 1)`.
                    // FIXME: wäert LLVM dëst an ADC oder ähnlech optiméieren?
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // Dëst kann net iwwerflësseg sinn;
                    // d'Ausgab ass tëscht `0` an `2^nbits * (2^nbits - 1)`.
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // Dëst kann net iwwerflësseg sinn;d'Ausgab ass tëscht `0` an `other * (2^nbits - 1)`.
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // Kuckt de RFC #521 fir dëst z'aktivéieren.
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// Dësch vun de Kräfte vu 5 representéierbar a Zifferen.Speziell de gréisste {u8, u16, u32} Wäert dat ass eng Kraaft vu fënnef, plus de korrespondéierte Exponent.
/// Benotzt an `mul_pow5`.
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// Stack zougewisen arbiträr Präzisioun (bis zu gewësse Limite) ganz.
        ///
        /// Dëst gëtt ënnerstëtzt vun enger fixer Gréisst Array vu bestëmmten Typ ("digit").
        /// Wärend den Array net ganz grouss ass (normalerweis e puer honnert Bytes), kann et kopéieren ouni Récksiicht zum Performance Hit ze féieren.
        ///
        /// Dofir ass dëst bewosst net `Copy`.
        ///
        /// All Operatiounen verfügbar fir bignums panic am Fall vun Iwwerflëss.
        /// Den Uruffer ass verantwortlech fir grouss genuch Bignumtypen ze benotzen.
        pub struct $name {
            /// Ee plus den Offset op de Maximum "digit" am Gebrauch.
            /// Dëst fällt net erof, also sidd bewosst vun der Berechnungsuerdnung.
            /// `base[size..]` soll null sinn.
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` representéiert `a + b *2^W + c* 2^(2W) + ...` wou `W` d'Zuel vu Bits am Zifferentyp ass.
            base: [$ty; $n],
        }

        impl $name {
            /// Maacht e Bignum aus enger Ziffer.
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// Maacht e Bignum vum `u64` Wäert.
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// Gitt d'intern Zifferen als e Stéck `[a, b, c, ...]` sou datt den numeresche Wäert `a + b *2^W + c* 2^(2W) + ...` ass wou `W` d'Zuel vu Bits am Zifferentyp ass.
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// Retourneiert den 'i'-th Bit wou Bit 0 am mannsten bedeitenden ass.
            /// An anere Wierder, de bësse mat Gewiicht `2^i`.
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// Retour `true` wann de Bignum Null ass.
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// Gitt d'Zuel vun de Stécker noutwendeg fir dëse Wäert duerzestellen.
            /// Bedenkt datt Null als 0 Bits ugesi gëtt.
            pub fn bit_length(&self) -> usize {
                // Skip iwwer déi bedeitendst Zifferen déi Null sinn.
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // Et gi keng Null Zifferen, dh d'Zuel ass Null.
                    return 0;
                }
                // Dëst kéint mat leading_zeros() a Bitverschiebungen optimiséiert ginn, awer dat ass wahrscheinlech net de Wäert wäert.
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// Füügt `other` u sech selwer zréck a bréngt seng eege mutéierbar Referenz zréck.
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// Subtraktéiert `other` vu sech selwer a bréngt seng eege mutéierbar Referenz zréck.
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// Multiplizéiert sech mat engem Ziffergréisst `other` a bréngt seng eege mutabel Referenz zréck.
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// Multiplizéiert sech vu `2^bits` a bréngt seng eege mutabel Referenz zréck.
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // Verréckelung vun `digits * digitbits` Bits
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // Verréckelung vun `bits` Bits
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // self.base [.. Zifferen] ass Null, et ass net néideg ze wiesselen
                }

                self.size = sz;
                self
            }

            /// Multiplizéiert sech vu `5^e` a bréngt seng eege mutabel Referenz zréck.
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // Et gi genau n hannendrun Nullen op 2 ^ n, an déi eenzeg relevant Ziffergréissten sinn hannerenee Kräfte vun zwee, sou datt dëst gutt geegent Index fir den Dësch ass.
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // Multiplizéiert mat der gréisster eenzegziffereger Kraaft sou laang wéi méiglech ...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... dann de Rescht fäerdeg.
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// Multiplizéiert sech mat enger Nummer beschriwwen vun `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` (wou `W` d'Zuel vu Bits am Zifferentyp ass) a bréngt seng eege mutéierbar Referenz zréck.
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // déi intern Routine.funktionnéiert am beschten wann aa.len() <= bb.len().
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// Deelt sech duerch eng Ziffergréisst `other` a bréngt seng eege mutabel Referenz *an* de Rescht zréck.
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// Deelt selwer mat engem anere Bignum, iwwerschreift `q` mam Quotient an `r` mam Rescht.
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // Domm lues base-2 laang Divisioun geholl vun
                // https://en.wikipedia.org/wiki/Division_algorithm
                // FIXME benotzt eng méi grouss Basis ($ty) fir déi laang Divisioun.
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // Set Bit `i` vu q op 1.
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// Den Zifferentyp fir `Big32x40`.
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// dësen gëtt nëmme fir Testen benotzt.
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}