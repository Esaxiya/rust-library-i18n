//! Déi verschidde Algorithmen aus dem Pabeier.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Zuel vu signifikante Bits am Fp
const P: u32 = 64;

// Mir späichere ganz einfach déi bescht Approximatioun fir *all* Exponenten, sou datt d'Variabel "h" an d'assoziéiert Konditioune kënnen ewech gelooss ginn.
// Dëst handelt Leeschtung fir e puer Kilobyte Plaz.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// In de meeschten Architekturen hunn d'Floating Point Operatiounen eng explizit Bitgréisst, dofir gëtt d'Präzisioun vun der Berechnung op enger Operatiounsbasis bestëmmt.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Op x86 gëtt d x87 FPU fir Flott Operatiounen benotzt wann d SSE/SSE2 Extensiounen net verfügbar sinn.
// D x87 FPU funktionnéiert mat 80 Bits vu Präzisioun par défaut, dat heescht datt d'Operatiounen op 80 Bits ronderëm ginn, sou datt duebel Ofrënnung geschitt wann d'Wäerter eventuell als duergestallt ginn
//
// 32/64 bësse fléissend Wäerter.Fir dëst ze iwwerwannen, kann de FPU Kontrollwuert sou gesat ginn datt d'Berechnunge mat der gewënschter Präzisioun ausgefouert ginn.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Eng Struktur déi benotzt gëtt fir den urspréngleche Wäert vum FPU Kontrollwuert ze konservéieren, sou datt et restauréiert ka ginn wann d'Struktur erofgefall ass.
    ///
    ///
    /// Den x87 FPU ass e 16-Bits Register, deem seng Felder folgend sinn:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// D'Dokumentatioun fir all d'Felder ass verfügbar am IA-32 Architectures Software Developer's Manual (Volume 1).
    ///
    /// Dat eenzegt Feld dat relevant ass fir de folgende Code ass PC, Präzisiounskontroll.
    /// Dëst Feld bestëmmt d'Präzisioun vun den Operatioune vun der FPU.
    /// Et kann op gesat ginn:
    ///  - 0b00, eenzeg Präzisioun dh 32-Bits
    ///  - 0b10, duebel Präzisioun dh 64 Stécker
    ///  - 0b11, duebel verlängert Präzisioun dh 80-Bits (Standardzoustand) De 0b01 Wäert ass reservéiert a soll net benotzt ginn.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // SAFETY: d `fldcw` Instruktioun gouf gepréift fir richteg mat ze schaffen
        // all `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Mir benotzen ATT Syntax fir LLVM 8 a LLVM 9 z'ënnerstëtzen.
                options(att_syntax, nostack),
            )
        }
    }

    /// Setzt d'Präzisiounsfeld vun der FPU op `T` a bréngt en `FPUControlWord` zréck.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Berechent de Wäert fir dat Precision Control Feld dat passend fir `T` ass.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 Bits
            8 => 0x0200, // 64 Stécker
            _ => 0x0300, // Standard, 80 Bits
        };

        // Kritt den originelle Wäert vum Kontrollwuert fir et spéider erëm ze restauréieren, wann d `FPUControlWord` Struktur SÄFERHEET fale gelooss gëtt: d `fnstcw` Uweisung gouf gepréift fir korrekt mat all `u16` ze schaffen
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Mir benotzen ATT Syntax fir LLVM 8 a LLVM 9 z'ënnerstëtzen.
                options(att_syntax, nostack),
            )
        }

        // Setzt d'Kontrollwuert op déi gewënschte Präzisioun.
        // Dëst gëtt erreecht andeems Dir déi al Präzisioun (Bits 8 an 9, 0x300) maskéiert an ersetzt duerch de Präzisiounsfändel deen uewe berechent gëtt.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// De schnelle Wee vu Bellerophon mat maschinngréissten Zuelen a Flotten.
///
/// Dëst gëtt an eng getrennte Funktioun extrahéiert sou datt et probéiert ka ginn ier e Bignum gebaut gëtt.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Mir vergläichen de genaue Wäert op MAX_SIG um Enn, dëst ass just eng séier, bëlleg Oflehnung (a befreit och de Rescht vum Code vum Suergen iwwer de Stroum).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Dee schnelle Wee hänkt entscheedend vun der Arithmetik ofgerënnt op déi richteg Unzuel vu Stécker ouni Zwëscherofronn.
    // Op x86 (ouni SSE oder SSE2) erfuerdert d'Präzisioun vum x87 FPU Stack geännert sou datt et direkt op 64/32 Bit ronderëm.
    // D `set_precision` Funktioun këmmert sech ëm d'Präzisioun op Architekturen ze setzen, déi et erfuerderen andeems se de globalen Zoustand änneren (wéi d'Kontrollwuert vum x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // De Fall e <0 kann net an deen aneren branch gefaltet ginn.
    // Negativ Kräfte féieren zu engem widderhuelende Brochdeel am Duebelstäresystem, deen ofgerënnt ass, wat wierklech (an heiansdo zimlech bedeitend!) Feeler am Schlussresultat verursaacht.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algorithmus Bellerophon ass triviale Code gerechtfäerdegt duerch net-trivial numeresch Analyse.
///
/// Et ronderëm "f" op e Float mat 64 Bit Bedeitung a multiplizéiert et mat der beschter Approximatioun vun `10^e` (am selwechte Floating Point Format).Dëst ass dacks genuch fir dat korrekt Resultat ze kréien.
/// Wéi och ëmmer, wann d'Resultat no bei der Halschent tëscht zwee benachbarte (ordinary) Floats ass, heescht de Compound Rounding Feeler vu multiplizéieren zwee Approximatioun datt d'Resultat e puer Bits ausmaache kann.
/// Wann dëst passéiert, fixéiert den iterativen Algorithmus R d'Saachen.
///
/// Den handwellege "close to halfway" gëtt präzis gemaach duerch déi numeresch Analyse am Pabeier.
/// An de Wierder vum Clinger:
///
/// > Slop, ausgedréckt an Eenheete vum mannst bedeitende Bit, ass eng inklusiv Grenz fir de Feeler
/// > cumuléiert wärend der Schwammpunkt Berechnung vun der Approximatioun op f * 10 ^ e.(Slop ass
/// > net fir de richtege Feeler gebonnen, awer limitéiert den Ënnerscheed tëscht der Approximatioun z an
/// > déi bescht méiglech Approximatioun déi p Bits vu Bedeitung benotzt.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // D'Fäll abs(e) <log5(2^N) sinn an fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Ass de Slop grouss genuch fir en Ënnerscheed ze maachen wann een op n Bits ofrënnt?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// En iterativen Algorithmus deen e Schwammpunkt Approximatioun vun `f * 10^e` verbessert.
///
/// All Iteratioun kritt eng Eenheet op der leschter Plaz méi no, wat natierlech schrecklech laang dauert fir ze konvergéieren wann `z0` souguer liicht aus ass.
/// Glécklech, wann als Réckfall fir Bellerophon benotzt gëtt, ass d'Startnormatioun héchstens eng ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Fannt positive ganz Zuelen `x`, `y` sou datt `x / y` genau `(f *10^e) / (m* 2^k)` ass.
        // Dëst vermeit net nëmmen mat den Zeeche vun `e` an `k` ze handelen, mir eliminéieren och d'Kraaft vun zwee gemeinsam zu `10^e` an `2^k` fir d'Zuelen méi kleng ze maachen.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Dëst gëtt e bësse schweier geschriwwen well eis Bignums keng negativ Zuelen ënnerstëtzen, dofir benotze mir den absolute Wäert + Zeech Informatioun.
        // D'Multiplikatioun mat m_digits kann net iwwerfléissen.
        // Wann `x` oder `y` grouss genuch sinn, datt mir eis iwwer Iwwerlaf Suerge musse maachen, da si se och grouss genuch datt `make_ratio` d'Fraktioun mat engem Faktor vun 2 ^ 64 oder méi reduzéiert huet.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Braucht net x méi, späichert en clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Brauch nach ëmmer y, maacht eng Kopie.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Gitt `x = f` an `y = m` wou `f` Input Dezimalziffere representéieren wéi gewinnt an `m` ass de Bedeitung vun enger Schwammpunkt Approximatioun, maacht de Verhältnis `x / y` gläich wéi `(f *10^e) / (m* 2^k)`, méiglecherweis reduzéiert duerch eng Kraaft vun zwee déi all gemeinsam hunn.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, ausser datt mir d'Fraktioun ëm e bësse Kraaft vun zwee reduzéieren.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Dëst kann net iwwerschwemmen well et erfuerdert positiv `e` an negativ `k`, wat nëmme ka geschéien fir Wäerter extrem no bei 1, dat heescht datt `e` an `k` vergläichbar winzeg sinn.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Dëst kann och net iwwerschwemmen, kuckt hei uewen.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), erëm duerch eng gemeinsam Kraaft vun zwee reduzéiert.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Konzeptuell ass den Algorithmus M deen einfachste Wee fir en Dezimalzuel an e Schwammen ëmzewandelen.
///
/// Mir bilden e Verhältnis dat gläich ass wéi `f * 10^e`, a geheien dann d'Kraaft vun zwee bis et e gültege Schwämm bedeit.
/// De binäre Exponent `k` ass d'Zuel vun de Mol, déi mir den Teller oder den Nenner mat zwee multiplizéiert hunn, dh ëmmer `f *10^e` ass gläich wéi `(u / v)* 2^k`.
/// Wa mir bedeitend erausfonnt hunn, brauche mir nëmmen ofzeschléissen andeems mir de Rescht vun der Divisioun inspizéieren, wat an Helferfunktioune méi wäit ënnendrënner gemaach gëtt.
///
///
/// Dëse Algorithmus ass super lues, och mat der Optimiséierung, déi am `quick_start()` beschriwwe gëtt.
/// Wéi och ëmmer, et ass déi einfachst vun den Algorithmen fir sech fir Iwwerlaf, Ënnerstroum an Ënnernormal Resultater unzepassen.
/// Dës Ëmsetzung iwwerhëlt wann de Bellerophon an den Algorithmus R iwwerwältegt sinn.
/// Underflow an Iwwerstroum ze detektéieren ass einfach: D'Verhältnis ass ëmmer nach net an der Gamme bedeitend, awer den minimum/maximum Exponent ass erreecht.
/// Am Fall vum Iwwerlaf komme mer einfach onendlech zréck.
///
/// Ëmgank mat Ënnerstroum an Ënnernormaler ass méi komplizéiert.
/// E grousse Problem ass datt, mam Minimum Exponent, d'Verhältnis nach ëmmer ze grouss ka sinn fir e bedeitendst.
/// Kuckt underflow() fir Detailer.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME méiglech Optimiséierung: generaliséieren big_to_fp sou datt mir hei d'Äquivalent vun fp_to_float(big_to_fp(u)) maache kënnen, nëmmen ouni d'duebel Ronn.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Mir musse beim Minimum Exponent stoppen, wa mir bis `k < T::MIN_EXP_INT` waarden, da wiere mir mat engem Faktor vun zwee.
            // Leider heescht dat, datt mir normal Zuele mam Minimum Exponent musse spezialiséieren.
            // FIXME fënnt eng méi elegant Formuléierung, awer fuert den `tiny-pow10` Test fir sécher ze sinn datt et tatsächlech richteg ass!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Spréngt iwwer déi meescht Algorithmus M Widderhuelungen duerch d'Bitlängt ze kontrolléieren.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // D'Bitlängt ass eng Schätzung vun der Basis zwee Logarithmus, an log(u / v) = log(u), log(v).
    // D'Schätzung ass vu héchstens 1 aus, awer ëmmer en Ënnerschätzung, sou datt de Feeler op log(u) an log(v) vum selwechte Schëld ass a annuléiert (wa béid grouss sinn).
    // Dofir ass de Feeler fir log(u / v) héchstens och.
    // D'Zilverhältnis ass eng wou u/v an engem Bereich bedeit ass.Also ass eis Kündungsbedingung log2(u / v) déi bedeitendst Bits, plus/minus een.
    // FIXME Den zweeten Bit kucken kéint den Devis verbesseren an e puer méi Divisiounen vermeiden.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Ënnerstroum oder subnormal.Loosst et zu der Haaptfunktioun.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Iwwerlaf.Loosst et zu der Haaptfunktioun.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Verhältnis ass net en In-Range Bedeitung mat dem Minimum Exponent, also musse mir iwwerschësseg Bits ofrennen an den Exponent deemno upassen.
    // De richtege Wäert gesäit elo esou aus:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(vertrueden duerch rem)
    //
    // Dofir, wann déi ofgerënnt Bits!= 0.5 ULP sinn, entscheede se d'Rundung eleng.
    // Wa se gläich sinn an de Rescht net-Null ass, muss de Wäert nach ofgeronnt ginn.
    // Nëmme wann déi ofgerënnt Bits 1/2 sinn an de Rescht Null ass, hu mir eng hallef bis gläich Situatioun.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Gewéinlech Ronn-bis-gläichméisseg, verschleeft andeems een op der Basis vum Rescht vun enger Divisioun muss ronderëm.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}