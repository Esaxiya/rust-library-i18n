//! Utility Funktioune fir Bignums déi net ze vill Sënn maachen a Methoden ëmzegoen.

// FIXME Dëse Modul säin Numm ass e bëssen onglécklech, well aner Moduler och `core::num` importéieren.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Test ob all Bits manner bedeitend wéi `ones_place` ofgeschnidden ass e relative Feeler manner, gläich oder méi grouss wéi 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Wann all Rescht Bits null sinn, ass et= 0.5 ULP, soss> 0.5 Wann et net méi Bits sinn (half_bit==0), gëtt d'ënnescht och richteg Gläich.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Konvertéiert eng ASCII String déi nëmmen Dezimalzuelen an en `u64` enthält.
///
/// Maacht keng Kontrollen fir Iwwerlaf oder ongëlteg Zeechen, also wann den Uruff net virsiichteg ass, ass d'Resultat falsch a kann panic (awer et wäert net `unsafe` sinn).
/// Zousätzlech ginn eidel Strécker als Null behandelt.
/// Dës Funktioun existéiert well
///
/// 1. `FromStr` op `&[u8]` ze benotzen erfuerdert `from_utf8_unchecked`, wat schlecht ass, an
/// 2. d'Resultater vun `integral.parse()` an `fractional.parse()` zesummesetzen ass méi komplizéiert wéi dës ganz Funktioun.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Konvertéiert e String vun ASCII Zifferen an e Bignum.
///
/// Wéi `from_str_unchecked`, setzt dës Funktioun op der Parser fir Net-Zifferen ofzewéckelen.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Entwéckelt e Bignum an eng 64 Bit ganz.Panics wann d'Zuel ze grouss ass.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Extraitéiert eng Rei vu Bits.

/// Index 0 ass dat mannst bedeitendst Stéck an d'Band ass wéi ëmmer hallef op.
/// Panics wa gefrot méi Stécker ze extrahéiere wéi an de Retourtyp passen.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}