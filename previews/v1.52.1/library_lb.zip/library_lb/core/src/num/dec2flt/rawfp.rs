//! Bësse fiddelen op positive IEEE 754 Floats.Negativ Zuelen sinn net a musse net behandelt ginn.
//! Normal Schwammpunktzuelen hunn eng kanonesch Representatioun als (frac, exp) sou datt de Wäert 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) wou N d'Zuel vu Stécker ass.
//!
//! Ënnernormale si liicht anescht a komesch, awer dee selwechte Prinzip gëllt.
//!
//! Hei stellen mir se awer als (sig, k) mat f positiv duer, sou datt de Wäert f * ass
//! 2 <sup>e</sup> .Nieft dem "hidden bit" explizit ze maachen, ännert dëst den Exponent duerch de sougenannte Mantissa Shift.
//!
//! Anescht ausgedréckt, normalerweis schwammen ginn als (1) geschriwwen awer hei gi se als (2) geschriwwen:
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Mir nennen (1) d '**Brochvertriedung** an (2) déi **integral Representatioun**.
//!
//! Vill Funktiounen an dësem Modul behandelen nëmmen normal Zuelen.Déi dec2flt Routinen huelen konservativ den universell-korrekte luesen Wee (Algorithmus M) fir ganz kleng a ganz grouss Zuelen.
//! Deen Algorithmus brauch nëmmen next_float() deen Ënnernormaler an Nullen behandelt.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// En Helfer trait fir ze vermeiden datt am Fong all de Konversiounscode fir `f32` an `f64` duplizéiert gëtt.
///
/// Kuckt den Dokter Kommentar vum Elteremodul firwat dëst noutwendeg ass.
///
/// Sollt **ni** fir aner Typen ëmgesat ginn oder ausserhalb vum dec2flt Modul benotzt ginn.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Typ benotzt vun `to_bits` an `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Féiert eng rau Transmutatioun op eng ganz Zuel.
    fn to_bits(self) -> Self::Bits;

    /// Féiert eng rau Transmutatioun vun enger ganzer.
    fn from_bits(v: Self::Bits) -> Self;

    /// Gitt d'Kategorie zréck, an déi dës Zuel fällt.
    fn classify(self) -> FpCategory;

    /// Gitt d'Mantissa zréck, d'Exponent an ënnerschreift als ganz Zuelen.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Decodéiert de Floss.
    fn unpack(self) -> Unpacked;

    /// Goss aus enger klenger ganz Zuel déi genau duergestallt ka ginn.
    /// Panic wann d'ganz Zuel net kann duergestallt ginn, gëtt deen anere Code an dësem Modul sécher datt dat ni geschitt.
    fn from_int(x: u64) -> Self;

    /// Kritt de Wäert 10 <sup>e</sup> vun engem viraus berechneten Dësch.
    /// Panics fir `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Wat den Numm seet.
    /// Et ass méi einfach ze haarde Code wéi mat intrinsics jongléieren an hoffen datt d'LLVM et konstant klappt.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Eng konservativ gebonnen un den Dezimalziffere vun Inputen déi net iwwerlaf oder null oder produzéiere kënnen
    /// Ënnernormalen.Wahrscheinlech den Dezimal Exponent vum maximalen normale Wäert, dohier den Numm.
    const MAX_NORMAL_DIGITS: usize;

    /// Wann déi bedeitendst Dezimalzuel e Plazwäert méi grouss ass wéi dëst, ass d'Zuel sécher op Onendlechkeet.
    ///
    const INF_CUTOFF: i64;

    /// Wann déi bedeitendst Dezimalzuel e Plazwäert manner huet wéi dëst, ass d'Zuel sécher op Null ofgerënnt.
    ///
    const ZERO_CUTOFF: i64;

    /// D'Zuel vu Bits am Exponent.
    const EXP_BITS: u8;

    /// D'Zuel vun de Bits an der Bedeitung,*abegraff* de verstoppte Bit.
    const SIG_BITS: u8;

    /// D'Zuel vun de Stécker an der Bedeitung, * ausser de verstoppte Bit.
    const EXPLICIT_SIG_BITS: u8;

    /// De maximale legale Exponent a fraktionéierter Representatioun.
    const MAX_EXP: i16;

    /// De Minimum legal exponent a fraktionéierter Representatioun, ausser Ënnernormaler.
    const MIN_EXP: i16;

    /// `MAX_EXP` fir integral Representatioun, dh mat der Verréckelung ugewannt.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` kodéiert (dh mat offset Bias)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` fir integral Representatioun, dh mat der Verréckelung ugewannt.
    const MIN_EXP_INT: i16;

    /// Déi maximal normaliséiert Bedeitung an integraler Representatioun.
    const MAX_SIG: u64;

    /// Déi minimal normaliséiert Bedeitung an integraler Representatioun.
    const MIN_SIG: u64;
}

// Meeschtens eng Léisung fir #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Gitt d'Mantissa zréck, d'Exponent an ënnerschreift als ganz Zuelen.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Exponent Bias + Mantissa Verréckelung
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe ass onsécher ob `as` korrekt op all Plattforme ronderëm ass.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Gitt d'Mantissa zréck, d'Exponent an ënnerschreift als ganz Zuelen.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Exponent Bias + Mantissa Verréckelung
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe ass onsécher ob `as` korrekt op all Plattforme ronderëm ass.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Konvertéiert en `Fp` zum nootste Maschinneflottyp.
/// Handelt net subnormal Resultater.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f ass 64 Bit, also huet xe eng Mantissa-Verrécklung vun 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Ronn de 64-Bit bedeitend bis T::SIG_BITS Bits mat hallef bis gläich.
/// Handelt net exponent iwwerlaf.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Ajustéiert Mantissa Verschibung
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Invers vun `RawFloat::unpack()` fir normaliséiert Zuelen.
/// Panics wann de significand oder exponent net fir normaliséiert Zuelen valabel sinn.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Ewechzehuelen der verstoppt bëssen
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Ajustéiert den Exponent fir exponent Viraussiicht a Mantissa Verschibung
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Loosst Zeechebit bei 0 ("+"), eis Zuelen sinn all positiv
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Konstruéiert e subnormal.Eng Mantissa vun 0 ass erlaabt a baut Null.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Kodéiert Exponent ass 0, d'Zeechebit ass 0, also musse mir d'Bits just nei interpretéieren.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Ongeféier e Bignum mat engem Fp.Ronn bannent 0.5 ULP mat hallef bis gläich.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Mir hunn all Bits virum Index `start` ofgeschnidden, dh effektiv verréckele mir mat engem Betrag vun `start`, also ass dëst och den Exponent dee mir brauchen.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Ronn (half-to-even) ofhängeg vun den ofgeschniddene Bits.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Fannt déi gréisst Schwammpunkt Nummer méi streng wéi d'Argument.
/// Handelt net Ënnernormaler, Null oder Exponent Underflow.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Fannt déi klengst Schwammpunkt Nummer streng méi grouss wéi d'Argument.
// Dës Operatioun ass saturéierend, dh next_float(inf) ==inf.
// Am Géigesaz zu de meeschte Code an dësem Modul, handelt dës Funktioun mat Null, Ënnernormaler an Onendlechkeeten.
// Wéi och all anere Code hei beschäftegt et sech awer net mat NaN an negativ Zuelen.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Dëst schéngt ze gutt fir richteg ze sinn, awer et funktionnéiert.
        // 0.0 ass als alles-null Wuert kodéiert.Ënnernormale sinn 0x000m ... m wou m d'Mantissa ass.
        // Besonnesch déi klengst subnormal ass 0x0 ... 01 an déi gréisst 0x000F ... F.
        // Déi klengst normal Zuel ass 0x0010 ... 0, sou datt dësen Eckfall och funktionnéiert.
        // Wann d'Inkrement d'Mantissa iwwerschwemmt, erhéicht de Carry Bit den Exponent wéi mir wëllen, an d'Mantissa Bits ginn Null.
        // Wéinst der verstoppter Bitkonventioun ass dat och genau dat wat mir wëllen!
        // Endlech, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}