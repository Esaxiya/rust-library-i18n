//! Erënnerung Bewëllegung APIen

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Den `AllocError` Feeler weist en Allocatiounsfehler un, dee wéinst Ressourcenauspuff oder eppes falsch ka sinn, wann déi gegebenen Input Argumenter mat dësem allocator kombinéiert ginn.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (mir brauchen dëst fir downstream impl vun trait Feeler)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Eng Ëmsetzung vun `Allocator` kann zoufälleg Datenblocken iwwer [`Layout`][] beschreiwen allocéieren, wuessen, verréngeren an Deallokaliséieren.
///
/// `Allocator` ass entwéckelt fir op ZSTs, Referenzen oder Smart Indikatoren ëmgesat ze ginn, well en Allocator wéi `MyAlloc([u8; N])` kann net geréckelt ginn, ouni d'Uweiser op dat zougedeelt Gedächtnis ze aktualiséieren.
///
/// Am Géigesaz zu [`GlobalAlloc`][] sinn Nullgréisst Bewëllegungen am `Allocator` erlaabt.
/// Wann en ënnerläitene Verdeeler dëst net ënnerstëtzt (wéi Jemalloc) oder e Nullweiger zréckbréngt (wéi `libc::malloc`), da muss dës vun der Ëmsetzung gefaang ginn.
///
/// ### Moment zougewisen Erënnerung
///
/// E puer vun de Methoden erfuerderen datt e Memoryblock *aktuell* iwwer en allocator zougedeelt gëtt.Dëst bedeit datt:
///
/// * d'Startadress fir dee Memoryblock gouf virdru vun [`allocate`], [`grow`] oder [`shrink`] zréckginn, an
///
/// * de Memory Block ass net duerno Deallocéiert ginn, wou Blocken entweder Deallocated ginn andeems se op [`deallocate`] weiderginn oder geännert goufen andeems se op [`grow`] oder [`shrink`] weiderginn, déi `Ok` zréckbréngt.
///
/// Wann `grow` oder `shrink` `Err` zréckginn hunn, bleift de weideren Zeigefanger valabel.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Erënnerung passend
///
/// E puer vun de Methoden erfuerderen datt e Layout *passt* e Memoryblock.
/// Wat et heescht fir e Layout op "fit" e Memory Block bedeit (oder gläichwäerteg fir e Memory Block zu "fit" e Layout) ass datt déi folgend Konditioune musse festhalen:
///
/// * De Block muss mat der selwechter Ausriichtung als [`layout.align()`] zougewise ginn, an
///
/// * De geliwwert [`layout.size()`] muss am Beräich `min ..= max` falen, wou:
///   - `min` ass d'Gréisst vum Layout déi viru kuerzem benotzt gouf fir de Block ze allocéieren, an
///   - `max` ass déi lescht tatsächlech Gréisst vun [`allocate`], [`grow`] oder [`shrink`] zréck.
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Erënnerungsblocken, déi vun engem allocator zréckginn, musse op e gëltegt Gedächtnis weisen an hir Gültegkeet behalen bis d'Instanz an all seng Klone fale gelooss,
///
/// * klonen oder bewegen vum Allocateur däerfen d'Gedächtnisblocken aus dësem allocator net ongëlteg maachen.E gekloonten allocator muss sech wéi dee selwechten allocator behuelen, an
///
/// * all Zeiger an e Memoryblock deen [*currently allocated*] ass, kann op all aner Method vum Allocateur weiderginn.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Versich e Block vum Erënnerung ze verdeelen.
    ///
    /// Beim Erfolleg gëtt en [`NonNull<[u8]>`][NonNull] zréck mat der Gréisst an der Ausriichtungsgarantien vun `layout`.
    ///
    /// Den zréckgezunnene Block kann eng méi grouss Gréisst hunn wéi vun `layout.size()` spezifizéiert, a kann oder net säin Inhalt initialiséiert hunn.
    ///
    /// # Errors
    ///
    /// `Err` zréckzekommen weist datt entweder Erënnerung erschöpft ass oder `layout` entsprécht der Gréisst oder Ausriichtungsbeschränkungen net.
    ///
    /// Implementatiounen ginn encouragéiert `Err` zréckzebréngen op Erënnerung Erschöpfung anstatt panikéieren oder ofbriechen, awer dëst ass net eng strikt Fuerderung.
    /// (Spezifesch: et ass *legal* dës trait op der Basis vun enger ënnerierdescher natierlecher Allocatiounsbibliothéik z'implementéieren déi op Erënnerung erschöpft.)
    ///
    /// Clienten déi d'Berechnung ofbriechen als Äntwert op en Allocatiounsfehler ginn encouragéiert d [`handle_alloc_error`] Funktioun ze ruffen, anstatt direkt op `panic!` oder ähnlech ze beruffen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Behuelt sech wéi `allocate`, awer suergt och datt de zréckgezunnene Gedächtnis null initialiséiert ass.
    ///
    /// # Errors
    ///
    /// `Err` zréckzekommen weist datt entweder Erënnerung erschöpft ass oder `layout` entsprécht der Gréisst oder Ausriichtungsbeschränkungen net.
    ///
    /// Implementatiounen ginn encouragéiert `Err` zréckzebréngen op Erënnerung Erschöpfung anstatt panikéieren oder ofbriechen, awer dëst ass net eng strikt Fuerderung.
    /// (Spezifesch: et ass *legal* dës trait op der Basis vun enger ënnerierdescher natierlecher Allocatiounsbibliothéik z'implementéieren déi op Erënnerung erschöpft.)
    ///
    /// Clienten déi d'Berechnung ofbriechen als Äntwert op en Allocatiounsfehler ginn encouragéiert d [`handle_alloc_error`] Funktioun ze ruffen, anstatt direkt op `panic!` oder ähnlech ze beruffen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // SAFETY: `alloc` bréngt e gültege Gedächtnisblock zréck
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Deallocéiert d'Erënnerung referenzéiert vun `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` muss e Block vum Gedächtnis [*currently allocated*] iwwer dësen allocator bezeechnen, an
    /// * `layout` muss [*fit*] dee Block vum Gedächtnis.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Versich de Memory Block ze verlängeren.
    ///
    /// Nees en neien [`NonNull<[u8]>`][NonNull] mat engem Zeigefanger an der aktueller Gréisst vum zougestellten Erënnerung.De Zeiger ass passend fir Date vun `new_layout` beschriwwen ze halen.
    /// Fir dëst z'erreechen, kann den Allocateur d'Allocatioun vun `ptr` referenzéiert fir den neie Layout ze passen.
    ///
    /// Wann dëst `Ok` zréckkoum, ass d'Besëtz vum Memoryblock referenzéiert vun `ptr` un dësen Allocator transferéiert.
    /// D'Erënnerung kann oder vläicht net befreit ginn, a sollt als net benotzbar ugesinn ginn, ausser wann et erëm zréck op den Uruff iwwer de Retourwäert vun dëser Method transferéiert gouf.
    ///
    /// Wann dës Method `Err` zréckbréngt, ass d'Besëtz vum Memory Memory net un dësen allocator transferéiert ginn, an den Inhalt vum Memory Block ass onverännert.
    ///
    /// # Safety
    ///
    /// * `ptr` muss e Block vum Gedächtnis [*currently allocated*] iwwer dësen allocator bezeechnen.
    /// * `old_layout` muss [*fit*] dee Block vum Gedächtnis (Den `new_layout` Argument brauch et net ze passen.).
    /// * `new_layout.size()` muss méi grouss wéi oder gläich wéi `old_layout.size()` sinn.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Retour `Err` wann den neie Layout net der Gréisst vun der allocator an Ausriichtungsbeschränkungen vum allocator entsprécht, oder wann et anescht wiisst net klappt.
    ///
    /// Implementatiounen ginn encouragéiert `Err` zréckzebréngen op Erënnerung Erschöpfung anstatt panikéieren oder ofbriechen, awer dëst ass net eng strikt Fuerderung.
    /// (Spezifesch: et ass *legal* dës trait op der Basis vun enger ënnerierdescher natierlecher Allocatiounsbibliothéik z'implementéieren déi op Erënnerung erschöpft.)
    ///
    /// Clienten déi d'Berechnung ofbriechen als Äntwert op en Allocatiounsfehler ginn encouragéiert d [`handle_alloc_error`] Funktioun ze ruffen, anstatt direkt op `panic!` oder ähnlech ze beruffen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SAFETY: well `new_layout.size()` muss méi grouss wéi oder gläich sinn
        // `old_layout.size()`, déi al an déi nei Erënnerung Bewëllegung ass valabel fir ze liesen a schreift fir `old_layout.size()` Bytes.
        // Och well déi al Bewëllegung nach net Deallocéiert war, kann se net `new_ptr` iwwerlappt.
        // Dofir ass den Uruff op `copy_nonoverlapping` sécher.
        // De Sécherheetsvertrag fir `dealloc` muss vum Appeller oprechterhalen.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Behuelt sech wéi `grow`, awer suergt och fir datt den neien Inhalt op Null gesat gëtt ier e zréck gëtt.
    ///
    /// De Memory Block enthält de folgenden Inhalt no engem erfollegräichen Uruff un
    /// `grow_zeroed`:
    ///   * Bytes `0..old_layout.size()` ginn aus der Original Bewëllegung konservéiert.
    ///   * Bytes `old_layout.size()..old_size` ginn entweder konservéiert oder null, ofhängeg vun der Ëmsetzung vun der allocator.
    ///   `old_size` bezitt sech op d'Gréisst vum Memoryblock virum `grow_zeroed` Uruff, dee ka méi grouss si wéi d'Gréisst déi ursprénglech gefrot gouf wéi se zougewisen gouf.
    ///   * Bytes `old_size..new_size` sinn null.`new_size` bezitt sech op d'Gréisst vum Memoryblock, deen duerch den `grow_zeroed` Call zréckgaang ass.
    ///
    /// # Safety
    ///
    /// * `ptr` muss e Block vum Gedächtnis [*currently allocated*] iwwer dësen allocator bezeechnen.
    /// * `old_layout` muss [*fit*] dee Block vum Gedächtnis (Den `new_layout` Argument brauch et net ze passen.).
    /// * `new_layout.size()` muss méi grouss wéi oder gläich wéi `old_layout.size()` sinn.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Retour `Err` wann den neie Layout net der Gréisst vun der allocator an Ausriichtungsbeschränkungen vum allocator entsprécht, oder wann et anescht wiisst net klappt.
    ///
    /// Implementatiounen ginn encouragéiert `Err` zréckzebréngen op Erënnerung Erschöpfung anstatt panikéieren oder ofbriechen, awer dëst ass net eng strikt Fuerderung.
    /// (Spezifesch: et ass *legal* dës trait op der Basis vun enger ënnerierdescher natierlecher Allocatiounsbibliothéik z'implementéieren déi op Erënnerung erschöpft.)
    ///
    /// Clienten déi d'Berechnung ofbriechen als Äntwert op en Allocatiounsfehler ginn encouragéiert d [`handle_alloc_error`] Funktioun ze ruffen, anstatt direkt op `panic!` oder ähnlech ze beruffen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SAFETY: well `new_layout.size()` muss méi grouss wéi oder gläich sinn
        // `old_layout.size()`, déi al an déi nei Erënnerung Bewëllegung ass valabel fir ze liesen a schreift fir `old_layout.size()` Bytes.
        // Och well déi al Bewëllegung nach net Deallocéiert war, kann se net `new_ptr` iwwerlappt.
        // Dofir ass den Uruff op `copy_nonoverlapping` sécher.
        // De Sécherheetsvertrag fir `dealloc` muss vum Appeller oprechterhalen.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Versicht de Memoryblock ze schrumpelen.
    ///
    /// Nees en neien [`NonNull<[u8]>`][NonNull] mat engem Zeigefanger an der aktueller Gréisst vum zougestellten Erënnerung.De Zeiger ass passend fir Date vun `new_layout` beschriwwen ze halen.
    /// Fir dëst z'erreechen, kann d'Allocatioun d'Zuelung referenzéiert vun `ptr` referenzéiert fir den neie Layout ze passen.
    ///
    /// Wann dëst `Ok` zréckkoum, ass d'Besëtz vum Memoryblock referenzéiert vun `ptr` un dësen Allocator transferéiert.
    /// D'Erënnerung kann oder vläicht net befreit ginn, a sollt als net benotzbar ugesinn ginn, ausser wann et erëm zréck op den Uruff iwwer de Retourwäert vun dëser Method transferéiert gouf.
    ///
    /// Wann dës Method `Err` zréckbréngt, ass d'Besëtz vum Memory Memory net un dësen allocator transferéiert ginn, an den Inhalt vum Memory Block ass onverännert.
    ///
    /// # Safety
    ///
    /// * `ptr` muss e Block vum Gedächtnis [*currently allocated*] iwwer dësen allocator bezeechnen.
    /// * `old_layout` muss [*fit*] dee Block vum Gedächtnis (Den `new_layout` Argument brauch et net ze passen.).
    /// * `new_layout.size()` muss méi kleng wéi oder gläich wéi `old_layout.size()` sinn.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Retour `Err` wann den neie Layout net der Bewëllegung Gréisst an Ausriichtung Aschränkungen vun der Bewëllegung entsprécht, oder wann verrëngeren soss net klappt.
    ///
    /// Implementatiounen ginn encouragéiert `Err` zréckzebréngen op Erënnerung Erschöpfung anstatt panikéieren oder ofbriechen, awer dëst ass net eng strikt Fuerderung.
    /// (Spezifesch: et ass *legal* dës trait op der Basis vun enger ënnerierdescher natierlecher Allocatiounsbibliothéik z'implementéieren déi op Erënnerung erschöpft.)
    ///
    /// Clienten déi d'Berechnung ofbriechen als Äntwert op en Allocatiounsfehler ginn encouragéiert d [`handle_alloc_error`] Funktioun ze ruffen, anstatt direkt op `panic!` oder ähnlech ze beruffen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SAFETY: well `new_layout.size()` muss manner wéi oder gläich sinn
        // `old_layout.size()`, déi al an déi nei Erënnerung Bewëllegung ass valabel fir ze liesen a schreift fir `new_layout.size()` Bytes.
        // Och well déi al Bewëllegung nach net Deallocéiert war, kann se net `new_ptr` iwwerlappt.
        // Dofir ass den Uruff op `copy_nonoverlapping` sécher.
        // De Sécherheetsvertrag fir `dealloc` muss vum Appeller oprechterhalen.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Erstellt en "by reference" Adapter fir dës Instanz vun `Allocator`.
    ///
    /// Den zréckgezunnene Adapter implementéiert och `Allocator` a wäert dëst einfach léinen.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // SAFETY: de Sécherheetsvertrag muss vum Uruff oprechterhale ginn
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SAFETY: de Sécherheetsvertrag muss vum Uruff oprechterhale ginn
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SAFETY: de Sécherheetsvertrag muss vum Uruff oprechterhale ginn
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SAFETY: de Sécherheetsvertrag muss vum Uruff oprechterhale ginn
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}