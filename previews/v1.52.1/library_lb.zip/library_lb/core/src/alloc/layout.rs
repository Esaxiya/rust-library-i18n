use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Wärend dës Funktioun op enger Plaz benotzt gëtt an hir Ëmsetzung kéint gezeechent ginn, hunn déi viregt Versich dat gemaach rustc méi lues gemaach:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Layout vun engem Block vum Erënnerung.
///
/// Eng Instanz vun `Layout` beschreift e besonnesche Layout vum Gedächtnis.
/// Dir baut en `Layout` erop als Input fir engem allocator ze ginn.
///
/// All Layouten hunn eng assoziéiert Gréisst an eng Power-of-Two Ausriichtung.
///
/// (Bedenkt datt Layout *net* erfuerderlech sinn fir net Null Gréisst ze hunn, och wann `GlobalAlloc` erfuerdert datt all Erënnerungsufroen net Null an der Gréisst sinn.
/// En Uruffer muss entweder dofir suergen, datt sou Bedéngungen erfëllt sinn, spezifesch Allocateure mat méi lockeren Ufuerderunge benotzen oder déi méi schwaach `Allocator` Interface benotzen.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // Gréisst vum gefrote Block vum Erënnerung, gemooss a Bytes.
    size_: usize,

    // Ausriichtung vum gefrote Block vum Erënnerung, gemooss a Bytes.
    // mir suergen datt dëst ëmmer e Power-of-Two ass, well API's wéi `posix_memalign` et erfuerderen an et ass eng raisonnabel Contraint fir Layoutkonstruktoren opzesetzen.
    //
    //
    // (Mir brauchen awer net analog `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Baut en `Layout` aus engem gegebene `size` an `align`, oder gëtt `LayoutError` zréck wa keng vun de folgende Konditioune net erfëllt sinn:
    ///
    /// * `align` däerf net null sinn,
    ///
    /// * `align` muss eng Kraaft vun zwee sinn,
    ///
    /// * `size`, wann op déi nooste Multiple vun `align` ofgerënnt, däerf net iwwerschwemmen (dh de gerundete Wäert muss manner wéi oder gläich wéi `usize::MAX` sinn).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (Power-of-Two implizéiert Ausriichtung!=0.)

        // Ofgerënnt Gréisst ass:
        //   size_rounded_up=(Gréisst + align, 1)&! (align, 1);
        //
        // Mir wëssen vun uewen dat ausriichten!=0.
        // Wann d'Addéieren (alignéieren, 1) net iwwerschwemmt, da wier d'Ofrondung gutt.
        //
        // Ëmgedréit,&-maskéiere mat! (Align, 1) zitt nëmmen niddereg Uerdnung-Bits of.
        // Also wann Iwwerfluss mat der Zomm geschitt, kann&-mask net genuch subtrahéieren fir deen Iwwerlaf z'entdroen.
        //
        //
        // Uewen implizéiert datt d'Kontrolléiere vu Summatiounsiwwerlaf noutwendeg a genuch ass.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // SAFETY: d'Konditioune fir `from_size_align_unchecked` waren
        // uewen iwwerpréift.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Erstellt e Layout, Contournement all Schecken.
    ///
    /// # Safety
    ///
    /// Dës Funktioun ass onsécher well se d'Viraussetzunge vum [`Layout::from_size_align`] net verifizéiert.
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // SAFETY: den Uruffer muss sécherstellen datt `align` méi grouss wéi Null ass.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Déi Mindestgréisst a Bytes fir e Memoryblock vun dësem Layout.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// De Minimum Byte Ausriichtung fir e Memoryblock vun dësem Layout.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Baut en `Layout` passend fir e Wäert vum Typ `T` ze halen.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // SAFETY: d'Ausrichtung ass garantéiert vun Rust eng Kraaft vun zwee an
        // der Gréisst + align Combo ass garantéiert an eise Adressraum ze passen.
        // Als Resultat benotzt den onkontrolléierten Konstruktor hei fir ze vermeiden datt Code agefouert gëtt panics wann et net gutt genuch optiméiert ass.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produzéiert Layout deen e Rekord beschreift deen benotzt ka ginn fir Backing Struktur fir `T` ze allocéieren (wat kéint en trait oder aner net Gréisst wéi e Slice sinn).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SAFETY: kuckt Begrënnung am `new` firwat dëst déi onsécher Variant benotzt
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produzéiert Layout deen e Rekord beschreift deen benotzt ka ginn fir Backing Struktur fir `T` ze allocéieren (wat kéint en trait oder aner net Gréisst wéi e Slice sinn).
    ///
    /// # Safety
    ///
    /// Dës Funktioun ass nëmme sécher ze ruffen wann déi folgend Konditioune festhalen:
    ///
    /// - Wann `T` `Sized` ass, ass dës Funktioun ëmmer sécher ze ruffen.
    /// - Wann den onsize Schwanz vun `T` ass:
    ///     - eng [slice], da muss d'Längt vum Scheifschwanz eng intialiséiert ganz Zuel sinn, an d'Gréisst vum *ganze Wäert*(dynamesch Schwanzlängt + statesch Gréisst Präfix) muss an `isize` passen.
    ///     - e [trait object], da muss de vtabelen Deel vum Zeiger op eng gëlteg vtabel fir den Typ `T` weisen, deen duerch en net gréisseren Zesummelaf kritt, an d'Gréisst vum *ganze Wäert*(dynamesch Schwanzlängt + statesch Gréisst Präfix) muss an `isize` passen.
    ///
    ///     - en (unstable) [extern type], dann ass dës Funktioun ëmmer sécher ze ruffen, awer kann panic oder soss de falsche Wäert zréckginn, well de Layout vum externen Typ net bekannt ass.
    ///     Dëst ass datselwecht Verhalen wéi [`Layout::for_value`] op eng Referenz zu engem externen Typ Schwanz.
    ///     - soss ass et konservativ net erlaabt dës Funktioun ze nennen.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // SAFETY: mir ginn d'Viraussetzunge vun dëse Funktiounen un den Uruff laanscht
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SAFETY: kuckt Begrënnung am `new` firwat dëst déi onsécher Variant benotzt
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Erstellt en `NonNull` dee bongelt, awer gutt ausgeriicht fir dës Layout.
    ///
    /// Bedenkt datt de Zeigewäert potenziell e gëltege Zeiger duerstellt, dat heescht datt dëst net als "not yet initialized" Sentinel-Wäert däerf benotzt ginn.
    /// Typen déi faul zouginn, mussen d'Initialiséierung op anere Wee verfollegen.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // SAFETY: align ass garantéiert net null
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Erstellt e Layout deen de Rekord beschreift deen e Wäert vum selwechte Layout wéi `self` hält, awer deen och ausgeriicht ass mat der Ausriichtung `align` (gemooss a Bytes).
    ///
    ///
    /// Wann `self` scho mat der virgeschriwwener Ausriichtung entsprécht, da gëtt `self` zréck.
    ///
    /// Bedenkt datt dës Method kee Polsterung zu der Gesamtgréisst bäifügt, egal ob de zréckgezunnene Layout eng aner Ausriichtung huet.
    /// An anere Wierder, wann `K` d'Gréisst 16 huet, wäert `K.align_to(32)`*nach* d'Gréisst 16 hunn.
    ///
    /// Gitt e Feeler wann d'Kombinatioun vun `self.size()` an dem gegebene `align` d'Konditioune verstouss an [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Gitt de Betrag vum Polster zréck, dee mir no `self` musse setzen fir sécher ze sinn, datt déi folgend Adress den `align` zefriddestellt (gemooss a Bytes).
    ///
    /// zB wann `self.size()` 9 ass, da gëtt `self.padding_needed_for(4)` 3 zréck, well dat ass déi Mindestzuel vu Bytes vu Padding déi néideg sinn fir eng 4-ausgeriicht Adress ze kréien (unzehuelen datt den entspriechende Gedächtnisblock bei enger 4-ausgeriicht Adress fänkt).
    ///
    ///
    /// De Retourwäert vun dëser Funktioun huet keng Bedeitung wann `align` keng Power-of-Two ass.
    ///
    /// Bedenkt datt d'Utilitéit vum zréckgezunnene Wäert erfuerdert datt `align` manner wéi oder gläich ass wéi d'Ausrichtung vun der Startadress fir de ganze zougespaarte Späicher.Ee Wee fir dës Beschränkung zefridden ze stellen ass `align <= self.align()` ze garantéieren.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Ofgerënnt Wäert ass:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // an da gi mir de Polsterunterschied zréck: `len_rounded_up - len`.
        //
        // Mir benotze modulär Arithmetik ganz:
        //
        // 1. align ass garantéiert> 0, also align, 1 ass ëmmer gëlteg.
        //
        // 2.
        // `len + align - 1` kann héchstens `align - 1` iwwerschreiden, sou datt&-mask mat `!(align - 1)` dofir suergt datt am Fall vun Iwwerlaf `len_rounded_up` selwer 0 ass.
        //
        //    Dofir gëtt de Retourpolster, wann et zu `len` bäigefüügt gëtt, 0, wat trivial der Ausriichtung `align` entsprécht.
        //
        // (Natierlech, Versich fir Blocen vum Gedächtnis ze verdeelen, deenen hir Gréisst a Polsterung op déi uewe genannte Manéier iwwerschreiden, sollten den Allocateur souwisou e Feeler ginn.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Erstellt e Layout andeems d'Gréisst vun dësem Layout bis op e Multiple vun der Ausriichtung vum Layout ofgerënnt.
    ///
    ///
    /// Dëst entsprécht derbäi d'Resultat vun `padding_needed_for` zu der aktueller Gréisst vum Layout.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Dëst kann net iwwerflësseg sinn.Zitéiere vum Invariant vum Layout:
        // > `size`, wann ofgerënnt bis zum nooste Multiple vun `align`,
        // > däerf net iwwerschwemmen (dh de gerundete Wäert muss manner si wéi
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Erstellt e Layout deen de Rekord fir `n` Instanzen vun `self` beschreift, mat engem passenden Betrag vu Padding tëscht all fir ze garantéieren datt all Instanz seng gefrote Gréisst an Ausriichtung kritt.
    /// Beim Erfolleg gëtt `(k, offs)` zréck wou `k` de Layout vum Array ass an `offs` d'Distanz tëscht dem Start vun all Element am Array ass.
    ///
    /// Beim arithmetesche Iwwerlaf gëtt `LayoutError` zréck.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Dëst kann net iwwerflësseg sinn.Zitéiere vum Invariant vum Layout:
        // > `size`, wann ofgerënnt bis zum nooste Multiple vun `align`,
        // > däerf net iwwerschwemmen (dh de gerundete Wäert muss manner si wéi
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // SAFETY: self.align ass scho bekannt als gëlteg an alloc_size war
        // gepolstert schonn.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Erstellt e Layout deen de Rekord beschreift fir `self` gefollegt vun `next`, och all noutwendeg Polsterung fir ze garantéieren datt `next` richteg ausgeriicht ass, awer *keen hënneschte Padding*.
    ///
    /// Fir de C Representatiounslayout `repr(C)` ze passen, sollt Dir `pad_to_align` uruffen nodeems Dir de Layout mat alle Felder verlängert hutt.
    /// (Et gëtt kee Wee fir de Standard Rust Representatioun Layout `repr(Rust)`, as it is unspecified.) ze passen
    ///
    /// Bedenkt datt d'Ausriichtung vum resultéierende Layout de Maximum vun deene vun `self` an `next` ass, fir d'Ausriichtung vun deenen zwee Deeler ze garantéieren.
    ///
    /// Retour `Ok((k, offset))`, wou `k` Layout vum zesummegesate Rekord ass an `offset` d'relativ Plaz ass, a Bytes, vum Ufank vum `next` an der zesummegesate Rekord agebett (unzehuelen datt de Rekord selwer beim Offset 0 ufänkt).
    ///
    ///
    /// Beim arithmetesche Iwwerlaf gëtt `LayoutError` zréck.
    ///
    /// # Examples
    ///
    /// Fir de Layout vun enger `#[repr(C)]` Struktur ze berechnen an d'Offsetze vun de Felder aus de Felder Layouten:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Denkt drun mat `pad_to_align` ze finaliséieren!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // Test datt et funktionnéiert
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Erstellt e Layout deen de Rekord fir `n` Instanzen vun `self` beschreift, ouni Padding tëscht all Instanz.
    ///
    /// Bedenkt datt, am Géigesaz zu `repeat`, `repeat_packed` net garantéiert datt d'widderhuelte Fäll vu `self` richteg ausgeriicht sinn, och wann e bestëmmten Beispill vun `self` richteg ausgeriicht ass.
    /// An anere Wierder, wann de Layout vun `repeat_packed` zréckgezunn gëtt fir en Array ze allocéieren, ass et net garantéiert datt all Elementer an der Array richteg ausgeriicht sinn.
    ///
    /// Beim arithmetesche Iwwerlaf gëtt `LayoutError` zréck.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Erstellt e Layout deen de Rekord fir `self` beschreift, gefollegt vun `next` ouni zousätzlech Polsterung tëscht deenen zwee.
    /// Well kee Padding agebaut ass, ass d'Ausriichtung vum `next` irrelevant, an ass guer net * an den entstane Layout agebaut.
    ///
    ///
    /// Beim arithmetesche Iwwerlaf gëtt `LayoutError` zréck.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Erstellt e Layout deen de Rekord fir en `[T; n]` beschreift.
    ///
    /// Beim arithmetesche Iwwerlaf gëtt `LayoutError` zréck.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// D'Parameter déi dem `Layout::from_size_align` oder engem aneren `Layout` Konstruktor ginn, erfëllen net seng dokumentéiert Contrainten.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (mir brauchen dëst fir downstream impl vun trait Feeler)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}