use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// E Memory Allocator deen als Standardbibliothéiks Standard duerch den `#[global_allocator]` Attribut registréiert ka ginn.
///
/// E puer vun de Methoden erfuerderen datt e Memoryblock *aktuell* iwwer en allocator zougedeelt gëtt.Dëst bedeit datt:
///
/// * d 'Startadress fir dee Gedächtnisblock gouf virdru vun engem fréieren Uruff un eng Allokatiounsmethod wéi `alloc` zréckginn, an
///
/// * den Erënnerungsblock ass net duerno verhandelt ginn, wou Blocen entweder verdeelt ginn andeems se op eng Deallocation Method wéi `dealloc` weidergeleet ginn oder duerch eng Reallocation Method weiderginn déi en net-null Zeiger zréckbréngt.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// Den `GlobalAlloc` trait ass en `unsafe` trait aus e puer Grënn, an d'Implementateure musse sécherstellen datt se dëse Kontrakter halen:
///
/// * Et ass ondefinéiert Verhalen wann weltwäit Allocateuren ofbauen.Dës Restriktioun kann an der future opgehuewe ginn, awer am Moment kann en panic vun enger vun dëse Funktiounen zu Erënnerungssécherheet féieren.
///
/// * `Layout` Ufroen a Berechnungen am Allgemenge musse richteg sinn.Anruferer vun dësem trait dierfen op d'Kontrakter vertrauen, déi op all Method definéiert sinn, an d'Implementateure musse sécherstellen, datt sou Kontrakter richteg bleiwen.
///
/// * Dir kënnt net vertrauen datt d'Allocatiounen tatsächlech passéieren, och wann et explizit Haapttildelen an der Quell sinn.
/// Den Optimizer kann onbenotzten Allocatiounen detektéieren, déi et entweder ganz eliminéiere kënnen oder op de Stack réckelen an doduerch ni den Allocator opruffen.
/// Den Optimizer kann weider dovun ausgoen datt d'Allocatioun onfeelbar ass, sou datt de Code dee fréier duerch Allocator Feeler ausgefall ass, elo op eemol funktionéiere kann well den Optimizer ronderëm d'Bedierfnes vun enger Allocatioun geschafft huet.
/// Méi konkret ass de folgenden Code Beispill net gesond, egal ob Äre personaliséiert Allocator erlaabt ze zielen wéi vill Allocatiounen geschitt sinn.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Bedenkt datt déi uewe genannten Optimiséierungen net déi eenzeg Optimiséierung sinn déi ugewannt kënne ginn.Dir kënnt normalerweis net op Koup Allocatioune vertrauen wann se ofgeholl kënne ginn ouni de Programmverhalen z'änneren.
///   Egal ob Allocatiounen passéieren oder net ass net Deel vum Programmverhalen, och wann et iwwer en Allocator festgestallt gouf deen d'Allocations duerch Dréckerei verfollegt oder soss Niewewierkungen huet.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Zougeuerdnete Gedächtnis wéi et vun der gegebener `layout` beschriwwe gëtt.
    ///
    /// Gitt e Zeiger fir nei zougewisen Erënnerung, oder null fir d'Allocatiounsfehler unzeginn.
    ///
    /// # Safety
    ///
    /// Dës Funktioun ass onsécher well ondefinéiert Verhalen entsteet wann den Uruffer net garantéiert datt `layout` Net-Null Gréisst huet.
    ///
    /// (Extension Subtraite kéinte méi spezifesch Grenze fir d'Behuele bidden, zB Garantie vun enger Sentinel Adress oder engem Nullzeiger als Äntwert op eng Nullgréisst Bewëllegungsufro.)
    ///
    /// Den zougestellten Erënnerungsspär kann oder vläicht net initialiséiert ginn.
    ///
    /// # Errors
    ///
    /// Wann Dir en Nullzeiger zréckschéckt, weist datt entweder d'Erënnerung erschöpft ass oder `layout` entsprécht der Gréisst oder der Ausriichtungsbeschränkung vun dësem Allocateur.
    ///
    /// Implementatiounen ginn encouragéiert null op Erënnerung Erschöpfung zréckzeginn anstatt ofzebriechen, awer dëst ass net eng strikt Fuerderung.
    /// (Spezifesch: et ass *legal* dës trait op der Basis vun enger ënnerierdescher natierlecher Allocatiounsbibliothéik z'implementéieren déi op Erënnerung erschöpft.)
    ///
    /// Clienten déi d'Berechnung ofbriechen als Äntwert op en Allocatiounsfehler ginn encouragéiert d [`handle_alloc_error`] Funktioun ze ruffen, anstatt direkt op `panic!` oder ähnlech ze beruffen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Deallocéiert de Block vum Gedächtnis beim gegebene `ptr` Zeiger mam gegebene `layout`.
    ///
    /// # Safety
    ///
    /// Dës Funktioun ass onsécher well ondefinéiert Verhalen entsteet wann den Uruffer net all vun de folgenden assuréiert:
    ///
    ///
    /// * `ptr` muss e Block vum Gedächtnis bezeechnen dee momentan iwwer dësen allocator zougewisen ass,
    ///
    /// * `layout` muss dee selwechte Layout sinn dee benotzt gouf fir dee Block vum Erënnerung ze verdeelen.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Behuelt sech wéi `alloc`, awer suergt och datt den Inhalt op Null gesat gëtt ier e zréck gëtt.
    ///
    /// # Safety
    ///
    /// Dës Funktioun ass net sécher aus deene selwechte Grënn wéi `alloc`.
    /// Wéi och ëmmer, den zougewisenen Erënnerungsblock ass garantéiert initialiséiert ze ginn.
    ///
    /// # Errors
    ///
    /// Wann Dir en Nullzeiger zréckschéckt, weist datt entweder d'Erënnerung erschöpft ass oder `layout` net der Gréisst oder der Ausriichtungsbeschränkung entsprécht, sou wéi am `alloc`.
    ///
    /// Clienten déi d'Berechnung ofbriechen als Äntwert op en Allocatiounsfehler ginn encouragéiert d [`handle_alloc_error`] Funktioun ze ruffen, anstatt direkt op `panic!` oder ähnlech ze beruffen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // SAFETY: de Sécherheetsvertrag fir `alloc` muss vum Uruff oprechterhale ginn.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // SAFETY: wéi d'Allocatioun gelongen ass, d'Regioun vun `ptr`
            // vun der Gréisst `size` ass garantéiert gëlteg fir ze schreiwen.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Schrëft oder wuesse e Block vum Erënnerung un dee gegebene `new_size`.
    /// De Block gëtt vum gegebene `ptr` Zeiger an `layout` beschriwwen.
    ///
    /// Wann dëst en Net-Nullzeiger zréckschéckt, ass d'Besëtz vum Memoryblock referenzéiert vun `ptr` un dësen Allocator transferéiert.
    /// D'Erënnerung ass oder vläicht net deallocéiert gewiescht, a sollt als net benotzbar ugesinn ginn (ausser et ass natierlech erëm zréckgeruff op den Uruff iwwer de Retourwäert vun dëser Method).
    /// Den neie Memoryblock gëtt mat `layout` zougewisen, awer mat der `size` op `new_size` aktualiséiert.
    /// Dësen neie Layout soll benotzt ginn wann Dir den neie Memoryblock mat `dealloc` verhandelt.
    /// D'Band `0..min(layout.size(), new_size) `vum neie Memoryblock ass garantéiert déiselwecht Wäerter wéi den Original Block.
    ///
    /// Wann dës Method null zréckgeet, ass d'Besëtz vum Memoryblock net un dësen allocator transferéiert ginn, an den Inhalt vum Memoryblock ass onverännert.
    ///
    /// # Safety
    ///
    /// Dës Funktioun ass onsécher well ondefinéiert Verhalen entsteet wann den Uruffer net all vun de folgenden assuréiert:
    ///
    /// * `ptr` muss de Moment iwwer dësen Allocateur zougewise ginn,
    ///
    /// * `layout` muss dee selwechte Layout sinn deen benotzt gouf fir dee Block vum Erënnerung ze verdeelen,
    ///
    /// * `new_size` muss méi grouss wéi null sinn.
    ///
    /// * `new_size`, wann op déi nooste Multiple vun `layout.align()` ofgeronnt ass, däerf net iwwerschwemmen (dh de gerundete Wäert muss manner wéi `usize::MAX` sinn).
    ///
    /// (Extension Subtraite kéinte méi spezifesch Grenze fir d'Behuele bidden, zB Garantie vun enger Sentinel Adress oder engem Nullzeiger als Äntwert op eng Nullgréisst Bewëllegungsufro.)
    ///
    /// # Errors
    ///
    /// Nees zréck wann den neie Layout net d'Gréisst an d'Ausriichtungsbeschränkungen vum Allocateur entsprécht, oder wann d'Reallocation anescht fällt.
    ///
    /// Implementatiounen ginn encouragéiert Null zréck op Erënnerung Erschöpfung anstatt ze panikéieren oder ofzebriechen, awer dëst ass net eng strikt Fuerderung.
    /// (Spezifesch: et ass *legal* dës trait op der Basis vun enger ënnerierdescher natierlecher Allocatiounsbibliothéik z'implementéieren déi op Erënnerung erschöpft.)
    ///
    /// Clienten déi d'Berechnung ofbriechen als Äntwert op e Reallocation Feeler ginn encouragéiert d [`handle_alloc_error`] Funktioun ze ruffen, anstatt direkt op `panic!` oder ähnlech ze beruffen.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // SAFETY: den Uruffer muss sécherstellen datt den `new_size` net iwwerschwemmt.
        // `layout.align()` kënnt vun engem `Layout` a gëtt domat garantéiert gëlteg.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // SAFETY: den Uruffer muss sécherstellen datt `new_layout` méi grouss wéi Null ass.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // SAFETY: de fréier zougewisenen Block kann den nei zougewisenen Block net iwwerlappen.
            // De Sécherheetsvertrag fir `dealloc` muss vum Appeller oprechterhalen.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}