//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Deen héchste gültege Code Punkt deen e `char` kann hunn.
    ///
    /// A `char` ass e [Unicode Scalar Value], dat heescht datt et en [Code Point] ass, awer nëmmen an engem gewësse Beräich.
    /// `MAX` ass deen héchste valabele Code Punkt deen e gëltege [Unicode Scalar Value] ass.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () gëtt an Unicode benotzt fir en Enkodéierungsfeeler duerzestellen.
    ///
    /// Et kann zum Beispill optriede wa schlecht geformte UTF-8 Bytes zu [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy) ginn.
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// D'Versioun vum [Unicode](http://www.unicode.org/) op déi d'Unicode Deeler vun `char` an `str` Methode baséieren.
    ///
    /// Nei Versioune vun Unicode gi reegelméisseg verëffentlecht an duerno ginn all Methoden an der Standardbibliothéik ofhängeg vun Unicode aktualiséiert.
    /// Dofir ännert d'Behuele vun e puer `char` an `str` Methoden an de Wäert vun dëser konstanter mat der Zäit.
    /// Dëst gëtt *net* als brechend Ännerung ugesinn.
    ///
    /// D'Versiounsnummerschema gëtt an [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) erkläert.
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Erstellt en Iterator iwwer d UTF-16 kodéiert Code Punkten an `iter`, zréckgoen onpaart Surrogaten als `Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// E verloschteren Decoder kann duerch Ersetzen vun `Err` Resultater mam Ersatzcharakter kritt ginn:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Konvertéiert en `u32` op en `char`.
    ///
    /// Bedenkt datt all `char`s valabel [`u32`] s sinn, a kënnen zu engem mat gegoss ginn
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Wéi och ëmmer, de Géigendeel ass net wouer: net all gëlteg [`u32`] si valabel`char`s.
    /// `from_u32()` wäert `None` zréckginn wann den Input net e gültege Wäert fir en `char` ass.
    ///
    /// Fir eng onsécher Versioun vun dëser Funktioun déi dës Kontrollen ignoréiert, kuckt [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// `None` zréckzeginn wann den Input net e gültege `char` ass:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Konvertéiert en `u32` op en `char`, ignoréiert d'Gëltegkeet.
    ///
    /// Bedenkt datt all `char`s valabel [`u32`] s sinn, a kënnen zu engem mat gegoss ginn
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Wéi och ëmmer, de Géigendeel ass net wouer: net all gëlteg [`u32`] si valabel`char`s.
    /// `from_u32_unchecked()` wäert dëst ignoréieren, a blann op `char` geheien, méiglecherweis en ongëltegen.
    ///
    ///
    /// # Safety
    ///
    /// Dës Funktioun ass onsécher, well se ongëlteg `char` Wäerter konstruéiere kann.
    ///
    /// Fir eng sécher Versioun vun dëser Funktioun, kuckt d [`from_u32`] Funktioun.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // SAFETY: de Sécherheetsvertrag muss vum Uruff oprechterhale ginn.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Konvertéiert eng Ziffer am gegebene Radix op en `char`.
    ///
    /// A 'radix' hei gëtt heiansdo och 'base' genannt.
    /// E Radix vun zwee weist eng binär Zuel un, e Radix vun zéng, Dezimalzuel an eng Radix vu siechzéng, hexadecimal, fir e puer gemeinsam Wäerter ze ginn.
    ///
    /// Arbiträr Radise ginn ënnerstëtzt.
    ///
    /// `from_digit()` wäert `None` zréckkommen wann den Input net eng Ziffer am gegebene Radix ass.
    ///
    /// # Panics
    ///
    /// Panics wann e Radix méi grouss wéi 36 gëtt.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Dezimal 11 ass eng eenzeg Ziffer an der Basis 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// `None` zréckzeginn wann den Input net eng Ziffer ass:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Passéiert e grousse Radix, wouduerch en panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Kontrolléiert ob en `char` eng Ziffer am bestëmmte Radix ass.
    ///
    /// A 'radix' hei gëtt heiansdo och 'base' genannt.
    /// E Radix vun zwee weist eng binär Zuel un, e Radix vun zéng, Dezimalzuel an eng Radix vu siechzéng, hexadecimal, fir e puer gemeinsam Wäerter ze ginn.
    ///
    /// Arbiträr Radise ginn ënnerstëtzt.
    ///
    /// Am Verglach mam [`is_numeric()`] erkennt dës Funktioun nëmmen d'Charaktere `0-9`, `a-z` an `A-Z`.
    ///
    /// 'Digit' ass definéiert nëmmen déi folgend Zeechen:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Fir e méi ëmfaassend Verständnis vun 'digit', kuckt [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics wann e Radix méi grouss wéi 36 gëtt.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Passéiert e grousse Radix, wouduerch en panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Konvertéiert en `char` op eng Ziffer am bestëmmte Radix.
    ///
    /// A 'radix' hei gëtt heiansdo och 'base' genannt.
    /// E Radix vun zwee weist eng binär Zuel un, e Radix vun zéng, Dezimalzuel an eng Radix vu siechzéng, hexadecimal, fir e puer gemeinsam Wäerter ze ginn.
    ///
    /// Arbiträr Radise ginn ënnerstëtzt.
    ///
    /// 'Digit' ass definéiert nëmmen déi folgend Zeechen:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Retour `None` wann den `char` net op eng Ziffer am bestëmmte Radix bezitt.
    ///
    /// # Panics
    ///
    /// Panics wann e Radix méi grouss wéi 36 gëtt.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Net-Ziffer weiderginn ergëtt en Echec:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Passéiert e grousse Radix, wouduerch en panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // de Code gëtt hei opgedeelt fir d'Ausféierung Geschwindegkeet ze verbesseren fir Fäll wou den `radix` konstant an 10 oder méi kleng ass
        //
        let val = if likely(radix <= 10) {
            // Wann net eng Ziffer, gëtt eng Zuel méi grouss wéi Radix erstallt.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Nees en Iterator deen den hexadecimalen Unicode Flucht vun engem Charakter als `char`s bréngt.
    ///
    /// Dëst entkommen Zeeche mat der Rust Syntax vun der Form `\u{NNNNNN}` wou `NNNNNN` eng hexadecimal Representatioun ass.
    ///
    ///
    /// # Examples
    ///
    /// Als Iterator:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` direkt benotzen:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Béid si gläichwäerteg wéi:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Mat `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // oder-ing 1 suergt datt fir c==0 de Code rechent datt eng Ziffer soll gedréckt ginn an (wat d'selwecht ass) vermeit den (31, 32) Ënnerfloss
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // den Index vun der bedeitendster Hex Ziffer
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Eng erweidert Versioun vum `escape_debug` déi optional erlaabt ze verlängeren Erweidert Grapheme Kodepunkten.
    /// Dëst erlaabt eis Charaktere wéi nonspacing marks besser ze formatéieren wa se um Ufank vun enger Zeil sinn.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Nees en Iterator deen de wuertwiertleche Fluchtcode vun engem Charakter als `char`s gëtt.
    ///
    /// Dëst wäert d'Charaktere wéi d `Debug` Implementéierunge vun `str` oder `char` entkommen.
    ///
    ///
    /// # Examples
    ///
    /// Als Iterator:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` direkt benotzen:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Béid si gläichwäerteg wéi:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Mat `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Nees en Iterator deen de wuertwiertleche Fluchtcode vun engem Charakter als `char`s gëtt.
    ///
    /// De Standard gëtt gewielt mat enger Viraussiicht fir Literaler ze produzéieren déi legal a ville Sprooche sinn, inklusiv C++ 11 an ähnlech C-Famill Sproochen.
    /// Déi genau Regele sinn:
    ///
    /// * Tab ass als `\t` entkomm.
    /// * Won zréck ass als `\r` entkomm.
    /// * Linnefudder ass als `\n` entkomm.
    /// * Eenzegt Zitat gëtt als `\'` entkomm.
    /// * Duebel Devis gëtt als `\"` entkomm.
    /// * Backslash ass als `\\` entkomm.
    /// * All Charakter am 'Printable ASCII' Beräich `0x20` .. `0x7e` inklusiv ass net entkomm.
    /// * All aner Charaktere gi hexadecimal Unicode Flucht;gesinn [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Als Iterator:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` direkt benotzen:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Béid si gläichwäerteg wéi:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Mat `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Gitt d'Zuel vu Bytes zréck, déi dësen `char` brauch wann se an UTF-8 kodéiert sinn.
    ///
    /// Déi Zuel vu Bytes ass ëmmer tëscht 1 a 4, inklusiv.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Den `&str` Typ garantéiert datt säin Inhalt UTF-8 ass, a sou kënne mir d'Längt vergläichen déi et géif huelen wann all Code Punkt als `char` géintiwwer an der `&str` selwer duergestallt gouf:
    ///
    ///
    /// ```
    /// // wéi chars
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // béid kënnen als dräi Bytes duergestallt ginn
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // als &str sinn dës zwee an UTF-8 kodéiert
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // mir kënne gesinn datt se sechs Bytes insgesamt huelen ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... genau wéi den &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Gitt d'Zuel vun 16-Bit Code Eenheeten zréck, déi dësen `char` brauch wann se an UTF-16 kodéiert sinn.
    ///
    ///
    /// Kuckt d'Dokumentatioun fir [`len_utf8()`] fir méi Erklärung vun dësem Konzept.
    /// Dës Funktioun ass e Spigel, awer fir UTF-16 amplaz UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Kodéiert dëse Charakter als UTF-8 an de verschaffene Byte-Puffer, an dann de Subslice vum Puffer zréck, deen de kodéierte Charakter enthält.
    ///
    ///
    /// # Panics
    ///
    /// Panics wann de Puffer net grouss genuch ass.
    /// E Puffer vun der Längt véier ass grouss genuch fir all `char` ze kodéieren.
    ///
    /// # Examples
    ///
    /// A béide Beispiller hëlt 'ß' zwee Bytes fir ze kodéieren.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// E Puffer deen ze kleng ass:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // SAFETY: `char` ass keen Ersatzspiller, also ass dat gëlteg UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Kodéiert dëse Charakter als UTF-16 an den ugebuedenen `u16` Puffer, an dann de Subslice vum Puffer zréck, deen de kodéierte Charakter enthält.
    ///
    ///
    /// # Panics
    ///
    /// Panics wann de Puffer net grouss genuch ass.
    /// E Puffer vun der Längt 2 ass grouss genuch fir all `char` ze kodéieren.
    ///
    /// # Examples
    ///
    /// A béide Beispiller brauch '𝕊' zwee "u16" fir ze kodéieren.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// E Puffer deen ze kleng ass:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Retour `true` wann dësen `char` d `Alphabetic` Propriétéit huet.
    ///
    /// `Alphabetic` gëtt am Kapitel 4 (Charaktereigenschaften) vum [Unicode Standard] beschriwwen an an der [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] spezifizéiert.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // Léift ass vill Saachen, awer et ass net alfabetesch
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Retour `true` wann dësen `char` d `Lowercase` Propriétéit huet.
    ///
    /// `Lowercase` gëtt am Kapitel 4 (Charaktereigenschaften) vum [Unicode Standard] beschriwwen an an der [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] spezifizéiert.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Déi verschidde chinesesch Scripten a Punktuéierung hu kee Fall, an esou:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Retour `true` wann dësen `char` d `Uppercase` Propriétéit huet.
    ///
    /// `Uppercase` gëtt am Kapitel 4 (Charaktereigenschaften) vum [Unicode Standard] beschriwwen an an der [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] spezifizéiert.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Déi verschidde chinesesch Scripten a Punktuéierung hu kee Fall, an esou:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Retour `true` wann dësen `char` d `White_Space` Propriétéit huet.
    ///
    /// `White_Space` gëtt an der [Unicode Character Database][ucd] [`PropList.txt`] spezifizéiert.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // en net briechende Raum
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Retour `true` wann dësen `char` entweder [`is_alphabetic()`] oder [`is_numeric()`] entsprécht.
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Retour `true` wann dësen `char` déi allgemeng Kategorie fir Kontrollcoden huet.
    ///
    /// Kontrollcodes (Codepunkte mat der allgemenger Kategorie vun `Cc`) ginn am Kapitel 4 (Charakter Properties) vum [Unicode Standard] beschriwwen an an der [Unicode Character Database][ucd] [`UnicodeData.txt`] spezifizéiert.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// // U + 009C, STRÄNGUNG
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Retour `true` wann dësen `char` d `Grapheme_Extend` Propriétéit huet.
    ///
    /// `Grapheme_Extend` gëtt an [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] beschriwwen an an der [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] spezifizéiert.
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Retour `true` wann dësen `char` eng vun den allgemenge Kategorien fir Zuelen huet.
    ///
    /// Déi allgemeng Kategorie fir Zuelen (`Nd` fir Dezimalzifferen, `Nl` fir Buschtawen-Zifferen an `No` fir aner numeresch Zeechen) ginn an der [Unicode Character Database][ucd] [`UnicodeData.txt`] spezifizéiert.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Nees en Iterator deen de klenge Bus vun dëser `char` als een oder méi gëtt
    /// `char`s.
    ///
    /// Wann dësen `char` keng kleng kleng Mapping huet, liwwert den Iterator déiselwecht `char`.
    ///
    /// Wann dësen `char` eng een-zu-eent kleng Mapping huet, déi vum [Unicode Character Database][ucd] [`UnicodeData.txt`] gëtt, liwwert den Iterator deen `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Wann dësen `char` speziell Considératiounen erfuerdert (z. B. méi "char`s") liwwert den Iterator de"Char" (n) vun [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Dës Operatioun mécht eng bedingungslos Kaartung ouni Mooss.Dat ass, d'Konversioun ass onofhängeg vu Kontext a Sprooch.
    ///
    /// Am [Unicode Standard], Kapitel 4 (Charaktereigenschaften) diskutéiert Fallmapping am Allgemengen an Kapitel 3 (Conformance) diskutéiert de Standardalgorithmus fir Fallkonversioun.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Als Iterator:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` direkt benotzen:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Béid si gläichwäerteg wéi:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Mat `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Heiansdo ass d'Resultat méi wéi ee Charakter:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Personnagen déi net grouss a kleng Buschtawen hunn, konvertéieren a sech selwer.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Nees en Iterator deen de grousse Buschtawen vun dësem `char` als een oder méi gëtt
    /// `char`s.
    ///
    /// Wann dësen `char` keng grouss Buschtawen huet, liwwert den Iterator déiselwecht `char`.
    ///
    /// Wann dësen `char` eng een-zu-eent grouss Kaarte gëtt, déi vum [Unicode Character Database][ucd] [`UnicodeData.txt`] gëtt, liwwert den Iterator deen `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Wann dësen `char` speziell Considératiounen erfuerdert (z. B. méi "char`s") liwwert den Iterator de"Char" (n) vun [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Dës Operatioun mécht eng bedingungslos Kaartung ouni Mooss.Dat ass, d'Konversioun ass onofhängeg vu Kontext a Sprooch.
    ///
    /// Am [Unicode Standard], Kapitel 4 (Charaktereigenschaften) diskutéiert Fallmapping am Allgemengen an Kapitel 3 (Conformance) diskutéiert de Standardalgorithmus fir Fallkonversioun.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Als Iterator:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` direkt benotzen:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Béid si gläichwäerteg wéi:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Mat `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Heiansdo ass d'Resultat méi wéi ee Charakter:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Personnagen déi net grouss a kleng Buschtawen hunn, konvertéieren a sech selwer.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Notiz op Lokal
    ///
    /// Op tierkesch huet d'Äquivalent vun 'i' am Latäin fënnef Formen anstatt zwee:
    ///
    /// * 'Dotless': Ech/ı, heiansdo geschriwwen ï
    /// * 'Dotted': I/i
    ///
    /// Bedenkt datt kleng Buschtawen gestippelt 'i' d'selwecht ass wéi d'Latäin.Dofir:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// De Wäert vun `upper_i` hänkt hei vun der Sprooch vum Text of: wa mir am `en-US` sinn, sollt et `"I"` sinn, awer wa mir am `tr_TR` sinn, sollt et `"İ"` sinn.
    /// `to_uppercase()` hëlt dat net a Betruecht, an esou:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// hält iwwer Sproochen.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Kontrolléiert ob de Wäert am ASCII Beräich ass.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Maacht eng Kopie vum Wäert a sengem ASCII-Groussfall.
    ///
    /// ASCII Buschtawen 'a' op 'z' ginn op 'A' op 'Z', awer net ASCII Bréiwer sinn onverännert.
    ///
    /// Fir de Wäert op der Plaz grouss ze maachen, benotzt [`make_ascii_uppercase()`].
    ///
    /// Fir ASCII Charaktere grouss ze maachen an zousätzlech zu net ASCII Zeechen, benotzt [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Maacht eng Kopie vum Wäert a sengem ASCII Klenggläichwäerteg.
    ///
    /// ASCII Buschtawen 'A' op 'Z' ginn op 'a' op 'z', awer net ASCII Bréiwer sinn onverännert.
    ///
    /// Fir de Wäert op der Plaz kleng ze maachen, benotzt [`make_ascii_lowercase()`].
    ///
    /// Fir ASCII Charaktere kleng ze maachen an zousätzlech zu net ASCII Charaktere benotzt [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Kontrolléiert datt zwou Wäerter en ASCII case-onsensitive Match sinn.
    ///
    /// Gläichwäerteg zu `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Konvertéiert dësen Typ zu sengem ASCII-Uewerfall gläichwäerteg op der Plaz.
    ///
    /// ASCII Buschtawen 'a' op 'z' ginn op 'A' op 'Z', awer net ASCII Bréiwer sinn onverännert.
    ///
    /// Fir en neie geschriwwene Wäert zréckzebréngen ouni dee bestehenden ze änneren, benotzt [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Konvertéiert dësen Typ op säin ASCII kleng Fall gläichwäerteg op der Plaz.
    ///
    /// ASCII Buschtawen 'A' op 'Z' ginn op 'a' op 'z', awer net ASCII Bréiwer sinn onverännert.
    ///
    /// Fir en neie méi nidderege Wäert zréckzebréngen ouni dee bestehenden ze änneren, benotzt [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Kontrolléiert ob de Wäert en ASCII alfabetesche Charakter ass:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', oder
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Kontrolléiert ob de Wäert en ASCII grousse Buschtaw ass:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Kontrolléiert ob de Wäert en ASCII kleng Buschtaf ass:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Kontrolléiert ob de Wäert en ASCII alphanumeresche Charakter ass:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', oder
    /// - U + 0061 'a' ..=U + 007A 'z', oder
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Kontrolléiert ob de Wäert eng ASCII Dezimalzuel ass:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Kontrolléiert ob de Wäert eng ASCII hexadecimal Ziffer ass:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', oder
    /// - U + 0041 'A' ..=U + 0046 'F', oder
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Kontrolléiert ob de Wäert en ASCII Punktuéierungskarakter ass:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, oder
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, oder
    /// - U + 005B ..=U + 0060 "[\] ^ _" ``, oder
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Kontrolléiert ob de Wäert en ASCII Grafik Charakter ass:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Kontrolléiert ob de Wäert en ASCII Wäissraum Charakter ass:
    /// U + 0020 RAUM, U + 0009 HORIZONTALE TAB, U + 000A LINNFUEDER, U + 000C FORMFUER, oder U + 000D KARRETUR RETOUR.
    ///
    /// Rust benotzt dem WhatWG Infra Standard säin [definition of ASCII whitespace][infra-aw].Et gi verschidden aner Definitiounen am grousse Gebrauch.
    /// Zum Beispill, [the POSIX locale][pct] enthält U + 000B VERTICAL TAB wéi och all déi uewe genannten Zeechen, awer-vun der selwechter Spezifizéierung-[d'Standardregel fir "field splitting" an der Bourne shell][bfs] betruecht *nëmmen* SPACE, HORIZONTAL TAB, an LINE FEED als Wäissraum.
    ///
    ///
    /// Wann Dir e Programm schreift deen e existent Dateiformat veraarbecht, préift wat d'Definitioun vum Format vu Wäissraum ass ier Dir dës Funktioun benotzt.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Kontrolléiert ob de Wäert en ASCII Kontrollcharakter ass:
    /// U + 0000 NUL ..=U + 001F EENHEET SEPARATOR, oder U + 007F DELETE.
    /// Bedenkt datt déi meescht ASCII Wäissraum Zeeche Kontrollzeeche sinn, awer SPACE net.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Kodéiert e roude u32-Wäert als UTF-8 an de verschaffene Byte-Puffer, an dann de Subslice vum Puffer zréck, deen de kodéierte Charakter enthält.
///
///
/// Am Géigesaz zu `char::encode_utf8`, behandelt dës Method och Kodepunkten am Ersatzberäich.
/// (Erstelle vun engem `char` am Ersatzberäich ass UB.) D'Resultat ass gëlteg [generalized UTF-8] awer net gëlteg UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics wann de Puffer net grouss genuch ass.
/// E Puffer vun der Längt véier ass grouss genuch fir all `char` ze kodéieren.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Kodéiert e roude u32-Wäert als UTF-16 an den ugebuedenen `u16`-Puffer, an dann de Subslice vum Puffer zréck, deen de kodéierte Charakter enthält.
///
///
/// Am Géigesaz zu `char::encode_utf16`, behandelt dës Method och Kodepunkten am Ersatzberäich.
/// (E `char` am Ersatzberäich erstellen ass UB.)
///
/// # Panics
///
/// Panics wann de Puffer net grouss genuch ass.
/// E Puffer vun der Längt 2 ass grouss genuch fir all `char` ze kodéieren.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // SIKKERHET: all Aarm kontrolléiert ob et genuch Bits sinn fir an ze schreiwen
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // De BMP fällt duerch
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Zousätzlech Fliger briechen an Ersatzstécker.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}