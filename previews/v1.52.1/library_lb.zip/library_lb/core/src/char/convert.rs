//! Charakter Konversiounen.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Konvertéiert en `u32` op en `char`.
///
/// Bedenkt datt all [`char`] s sinn valabel [`u32`] s, a kënne mat engem gegoss ginn
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Wéi och ëmmer, de Géigendeel ass net wouer: net all gëlteg [`u32`] si valabel [`char`] s.
/// `from_u32()` wäert `None` zréckginn wann den Input net e gültege Wäert fir en [`char`] ass.
///
/// Fir eng onsécher Versioun vun dëser Funktioun déi dës Kontrollen ignoréiert, kuckt [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Basis Benotzung:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// `None` zréckzeginn wann den Input net e gültege [`char`] ass:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Konvertéiert en `u32` op en `char`, ignoréiert d'Gëltegkeet.
///
/// Bedenkt datt all [`char`] s sinn valabel [`u32`] s, a kënne mat engem gegoss ginn
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Wéi och ëmmer, de Géigendeel ass net wouer: net all gëlteg [`u32`] si valabel [`char`] s.
/// `from_u32_unchecked()` wäert dëst ignoréieren, a blann op [`char`] geheien, méiglecherweis en ongëltegen.
///
///
/// # Safety
///
/// Dës Funktioun ass onsécher, well se ongëlteg `char` Wäerter konstruéiere kann.
///
/// Fir eng sécher Versioun vun dëser Funktioun, kuckt d [`from_u32`] Funktioun.
///
/// # Examples
///
/// Basis Benotzung:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // SAFETY: den Uruffer muss garantéieren datt `i` e gültege Char-Wäert ass.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Konvertéiert en [`char`] an en [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Konvertéiert en [`char`] an en [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // De Char gëtt op de Wäert vum Code Punkt geworf, duerno null verlängert op 64 Bit.
        // Kuckt [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Konvertéiert en [`char`] an en [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // De Char gëtt op de Wäert vum Code Punkt gegoss, duerno null op 128 Bit verlängert.
        // Kuckt [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Kaart e Byte an 0x00 ..=0xFF zu engem `char` deem säi Code Punkt dee selwechte Wäert huet, an U + 0000 ..=U + 00FF.
///
/// Unicode ass sou entwéckelt datt dëst effektiv Bytes mat der Zeechekodéierung decodéiert déi IANA ISO-8859-1 nennt.
/// Dës Kodéierung ass kompatibel mat ASCII.
///
/// Bedenkt datt dëst anescht ass wéi ISO/IEC 8859-1 aka
/// ISO 8859-1 (mat engem manner Bindestrich), deen e puer "blanks", Byte Wäerter hannerléisst, déi engem Charakter net zougewisen sinn.
/// ISO-8859-1 (den IANA eent) zielt se un d C0 an C1 Kontrollcoden.
///
/// Bedenkt datt dëst *och* anescht ass wéi Windows-1252 aka
/// Codesäit 1252, wat e Superset ISO/IEC 8859-1 ass, deen e puer (net all!) Leerzeechen a Punktuéierung a verschidde laténgesch Zeechen zougëtt.
///
/// Fir d'Saache weider ze verwiessele sinn [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` an `windows-1252` all Aliasen fir en Superset vu Windows-1252 déi déi verbleiwen eidel Felder mat entspriechende C0 an C1 Kontrollcoden fëllen.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Konvertéiert en [`u8`] an en [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// E Feeler deen zréckkoum wann een Char charéiert.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // SAFETY: gepréift datt et e legale Unicode-Wäert ass
            Ok(unsafe { transmute(i) })
        }
    }
}

/// De Feelertyp zréckkomm wann eng Konversioun vun u32 op Char ausfällt.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Konvertéiert eng Ziffer am gegebene Radix op en `char`.
///
/// A 'radix' hei gëtt heiansdo och 'base' genannt.
/// E Radix vun zwee weist eng binär Zuel un, e Radix vun zéng, Dezimalzuel an eng Radix vu siechzéng, hexadecimal, fir e puer gemeinsam Wäerter ze ginn.
///
/// Arbiträr Radise ginn ënnerstëtzt.
///
/// `from_digit()` wäert `None` zréckkommen wann den Input net eng Ziffer am gegebene Radix ass.
///
/// # Panics
///
/// Panics wann e Radix méi grouss wéi 36 gëtt.
///
/// # Examples
///
/// Basis Benotzung:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Dezimal 11 ass eng eenzeg Ziffer an der Basis 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// `None` zréckzeginn wann den Input net eng Ziffer ass:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Passéiert e grousse Radix, wouduerch en panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}