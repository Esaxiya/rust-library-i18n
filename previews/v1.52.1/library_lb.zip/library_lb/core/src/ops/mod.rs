//! Overloadable Betreiber.
//!
//! Dës traits ëmzesetzen erlaabt Iech verschidde Betreiber ze iwwerlueden.
//!
//! E puer vun dësen traits gi vum prelude importéiert, sou datt se an all Rust Programm verfügbar sinn.Nëmme Betreiber ënnerstëtzt vun traits kënnen iwwerlaascht ginn.
//! Zum Beispill kann den Zousazoperateur (`+`) iwwer den [`Add`] trait iwwerlaascht ginn, awer well den Aufgabebedreiwer (`=`) kee Support trait huet, gëtt et kee Wee fir seng Semantik ze iwwerlueden.
//! Zousätzlech gëtt dëst Modul kee Mechanismus fir nei Betreiber ze kreéieren.
//! Wann traitlos Iwwerbelaaschtung oder personaliséiert Bedreiwer erfuerderlech sinn, sollt Dir a Makroen oder Compiler Plugins kucken fir d'Syntax vum Rust ze verlängeren.
//!
//! Implementatioune vum Bedreiwer traits sollen an hire jeeweilege Kontexter net iwwerraschend sinn, andeems se hir üblech Bedeitungen an [operator precedence] am Kapp behalen.
//! Zum Beispill, wann Dir [`Mul`] implementéiert, sollt d'Operatioun e puer Ähnlechkeet mat Multiplikatioun hunn (an erwaart Eegeschafte wéi Associativitéit deelen).
//!
//! Bedenkt datt d `&&` an d `||` Betreiber Kuerzschluss, dh se evaluéieren nëmmen hir zweet Operand wann et zum Resultat bäidréit.Well dëst Verhalen net duerch traits duerchsetzbar ass, ginn `&&` an `||` net als iwwerluedbar Betreiber ënnerstëtzt.
//!
//! Vill vun de Bedreiwer huelen hir Operanden no Wäert.An net-generesche Kontexter mat agebaute Typen ass dëst normalerweis kee Problem.
//! Wéi och ëmmer, dës Bedreiwer am generesche Code ze benotzen, erfuerdert e puer Opmierksamkeet wann Wäerter musse weiderbenotzt ginn am Géigesaz zum Bedreiwe vun de Bedreiwer.Eng Optioun ass heiansdo [`clone`] ze benotzen.
//! Eng aner Optioun ass op d'Typen ze vertrauen déi zousätzlech Operatorimplementatioune fir Referenzen ubidden.
//! Zum Beispill, fir e benotzerdefinéierten Typ `T` deen supposéiert ass fir Zousaz z'ënnerstëtzen, ass et wuel eng gutt Iddi fir `T` an `&T` déi traits [`Add<T>`][`Add`] an [`Add<&T>`][`Add`] ëmzesetzen sou datt de generesche Code ouni onnéideg Klone geschriwwe ka ginn.
//!
//!
//! # Examples
//!
//! Dëst Beispill erstellt en `Point`-Struktur deen [`Add`] an [`Sub`] implementéiert, a weist dann op Zousaz an ofzéien vun zwee `Point`s.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Kuckt d'Dokumentatioun fir all trait fir e Beispill Ëmsetzung.
//!
//! D [`Fn`], [`FnMut`] an [`FnOnce`] traits ginn duerch Typen implementéiert déi wéi Funktiounen opgeruff kënne ginn.Bedenkt datt [`Fn`] `&self`, [`FnMut`] `&mut self` an [`FnOnce`] `self` hëlt.
//! Dës entspriechen den dräi Aarte vu Methoden déi op eng Instanz kënnen opgeruff ginn: Call-by-Reference, Call-by-Mutable-Referenz, a Call-by-Value.
//! Déi meescht üblech Benotzung vun dësen traits ass als Grenze fir méi héije Funktiounen ze handelen déi Funktiounen oder Ofschloss als Argumenter huelen.
//!
//! Huelt en [`Fn`] als Parameter:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Huelt en [`FnMut`] als Parameter:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Huelt en [`FnOnce`] als Parameter:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` verbraucht seng gefaange Variabelen, sou datt et net méi wéi eemol lafe kann
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Probéiert de `func()` nach eng Kéier unzeruffen geheit en `use of moved value` Feeler fir `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` kann op dësem Punkt net méi ugeruff ginn
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;