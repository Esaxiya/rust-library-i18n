use crate::marker::Unpin;
use crate::pin::Pin;

/// D'Resultat vun engem Generator Widderhuelung.
///
/// Dësen Enum gëtt vun der `Generator::resume` Method zréckgezunn a weist d'méiglech Retourwäerter vun engem Generator un.
/// De Moment entsprécht dëst entweder e Suspension Punkt (`Yielded`) oder en Terminatiounspunkt (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// De Generator mat engem Wäert suspendéiert.
    ///
    /// Dëse Staat weist datt e Generator suspendéiert gouf an entsprécht normalerweis enger `yield` Ausso.
    /// De Wäert deen an dëser Variant geliwwert gëtt entsprécht dem Ausdrock deen op `yield` weidergeleet gëtt an erlaabt Generatoren e Wäert ze ginn all Kéiers wann se ofginn.
    ///
    ///
    Yielded(Y),

    /// De Generator mat engem Retourwäert ofgeschloss.
    ///
    /// Dëse Staat weist datt e Generator d'Ausféierung mat dem angebote Wäert fäerdeg ass.
    /// Wann e Generator `Complete` zréckbruecht huet, gëtt et als Programméierer Feeler ugesinn `resume` erëm ze ruffen.
    ///
    Complete(R),
}

/// Den trait implementéiert vu Builtin Generator Typen.
///
/// Generatoren, och allgemeng als Coroutine bezeechent, sinn de Moment eng experimentell Sproochfeature am Rust.
/// Zu [RFC 2033] Generatoren bäigefüügt sinn de Moment virgesinn fir haaptsächlech e Bausteng fir async/await Syntax ze bidden awer wäert sech wuel ausbauen fir och eng ergonomesch Definitioun fir Iteratoren an aner Primitiven ze bidden.
///
///
/// D'Syntax a Semantik fir Generatoren ass onbestänneg a brauch e weidere RFC fir Stabiliséierung.Zu dëser Zäit ass d'Syntax awer zou:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Méi Dokumentatioun vu Generateure fannt Dir am instabile Buch.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Déi Aart vu Wäert dee Generator liwwert.
    ///
    /// Dësen assoziéierten Typ entsprécht dem `yield` Ausdrock an de Wäerter déi all Kéier zréckginn däerfen wann e Generator ergëtt.
    ///
    /// Zum Beispill en Iterator-als-Generator hätt dësen Typ wuel als `T`, deen Typ gëtt iwwerschratt.
    ///
    type Yield;

    /// Déi Aart vu Wäert deen dëse Generator zréckbréngt.
    ///
    /// Dëst entsprécht dem Typ deen aus engem Generator entweder mat enger `return` Ausso oder implizit als leschten Ausdrock vun engem Generator wuertwiertlech zréckkomm ass.
    /// Zum Beispill futures géif dat als `Result<T, E>` benotzen well et e fäerdegen future duerstellt.
    ///
    ///
    type Return;

    /// Hëlt d'Ausféierung vun dësem Generator erëm op.
    ///
    /// Dës Funktioun hëlt d'Ausféierung vum Generator erëm op oder fänkt d'Ausféierung un wann et dat nach net war.
    /// Dësen Opruff wäert zréck an de Generator säi leschte Suspensionspunkt zréckgoen, a féiert d'Ausféierung vum leschten `yield` op.
    /// De Generator wäert weider ausféieren bis en entweder ergëtt oder zréckgeet, a wéi engem Moment dës Funktioun zréckgeet.
    ///
    /// # Retour Wäert
    ///
    /// Den `GeneratorState` Enum zréck vun dëser Funktioun weist un wéi engem Zoustand de Generator ass beim Retour.
    /// Wann d `Yielded` Variant zréckkomm ass, huet de Generator e Suspension Punkt erreecht an e Wäert gouf erginn.
    /// Generatoren an dësem Staat sinn zur Widderhuelung zu engem spéidere Moment verfügbar.
    ///
    /// Wann `Complete` zréckkomm ass, ass de Generator komplett fäerdeg mat dem uginnene Wäert.Et ass ongëlteg fir de Generator erëm opzehuelen.
    ///
    /// # Panics
    ///
    /// Dës Funktioun kann panic wann et genannt gëtt nodeems d `Complete` Variant virdrun zréckgaang ass.
    /// Wärend Generatorliteraler an der Sprooch panic garantéiert sinn, nodeems se no `Complete` erëm opgeholl ginn, ass dëst net fir all Implementéierunge vum `Generator` trait garantéiert.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}