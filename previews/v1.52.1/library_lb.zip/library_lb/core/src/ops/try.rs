/// En trait fir d'Behuele vum `?` Operator ze personaliséieren.
///
/// En Typ deen `Try` implementéiert ass een deen e kanonesche Wee huet fir en a Bezuch op eng success/failure Dichotomie ze gesinn.
/// Dësen trait erlaabt et déi Erfollegs-oder Versoenwäerter aus enger existenter Instanz ze extrahieren an eng nei Instanz aus engem Erfollegs-oder Versoenwäert ze kreéieren.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Déi Zort vun dësem Wäert wann et als Erfolleg gekuckt gëtt.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Déi Aart vun dësem Wäert wann et als ausgefall gekuckt gëtt.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Gëlt den "?" Bedreiwer.E Retour vun `Ok(t)` bedeit datt d'Ausféierung normalerweis weiderfuere soll, an d'Resultat vun `?` ass de Wäert `t`.
    /// E Retour vun `Err(e)` bedeit datt d'Ausféierung soll branch op déi bannenzegst zougemaach `catch`, oder zréck vun der Funktioun.
    ///
    /// Wann en `Err(e)` Resultat zréckkomm ass, ass de Wäert `e` "wrapped" am Retourtyp vum ëmfaassenden Ëmfang (dee selwer `Try` implementéiere muss).
    ///
    /// Spezifesch gëtt de Wäert `X::from_error(From::from(e))` zréckkomm, wou `X` de Retourtyp vun der Ofschlossfunktioun ass.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Wéckel e Feelerwäert fir de Komposit Resultat ze konstruéieren.
    /// Zum Beispill, `Result::Err(x)` an `Result::from_error(x)` sinn gläichwäerteg.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Wéckel en OK Wäert fir de Komposit Resultat ze konstruéieren.
    /// Zum Beispill, `Result::Ok(x)` an `Result::from_ok(x)` sinn gläichwäerteg.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}