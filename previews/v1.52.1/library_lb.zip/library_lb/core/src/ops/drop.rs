/// Benotzerdefinéiert Code am Destructor.
///
/// Wann e Wäert net méi gebraucht gëtt, fiert Rust en "destructor" op deem Wäert.
/// Déi meescht üblech Manéier datt e Wäert net méi gebraucht gëtt ass wann et ausserhalb geet.Destruktoren kënnen nach ëmmer an aneren Ëmstänn lafen, awer mir fokusséieren op Ëmfang fir d'Beispiller hei.
/// Fir iwwer e puer vun deenen anere Fäll ze léieren, kuckt w.e.g. [the reference] Sektioun iwwer Destruktoren.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Dëse Destructor besteet aus zwee Komponenten:
/// - En Uruff op `Drop::drop` fir dee Wäert, wann dëse speziellen `Drop` trait fir säin Typ implementéiert gëtt.
/// - Déi automatesch generéiert "drop glue" déi recursiv d'Destruktoren vun alle Felder vun dësem Wäert nennt.
///
/// Wéi Rust automatesch d'Destruktoren vun all enthale Felder nennt, musst Dir an de meeschte Fäll net `Drop` implementéieren.
/// Awer et gi verschidde Fäll wou et nëtzlech ass, zum Beispill fir Typen déi direkt eng Ressource managen.
/// Dës Ressource kann Erënnerung sinn, et kann e Dateibeschreiwer sinn, et kann e Netzwierksocket sinn.
/// Wann e Wäert vun deem Typ net méi benotzt gëtt, sollt et "clean up" seng Ressource maachen andeems se de Gedächtnis befreit oder d'Datei oder de Socket zoumaachen.
/// Dëst ass d'Aarbecht vun engem Zerstéierer, an dofir d'Aarbecht vum `Drop::drop`.
///
/// ## Examples
///
/// Fir Destruktoren an Aktioun ze gesinn, kucke mer op de folgende Programm:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust rufft fir d'éischt `Drop::drop` fir `_x` an dann fir béid `_x.one` an `_x.two`, dat heescht datt dëst leeft wann Dir dréckt
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Och wa mir d'Ëmsetzung vun `Drop` fir `HasTwoDrop` erofhuelen, ginn d'Destruktoren vu senge Felder nach ëmmer genannt.
/// Dëst géif zu Resultat kommen
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Dir kënnt net `Drop::drop` selwer uruffen
///
/// Well `Drop::drop` benotzt gëtt fir e Wäert ze botzen, kann et geféierlech sinn dëse Wäert ze benotzen nodeems d'Methode geruff gouf.
/// Well `Drop::drop` keen Input vu sengem Input iwwerhëlt, verhënnert Rust Mëssbrauch andeems Dir Iech net erlaabt `Drop::drop` direkt ze ruffen.
///
/// An anere Wierder, wann Dir probéiert hutt `Drop::drop` explizit an dësem Beispill ze nennen, kritt Dir e Compiler Feeler.
///
/// Wann Dir explizit den Destruktor vun engem Wäert nennt, kann [`mem::drop`] amplaz benotzt ginn.
///
/// [`mem::drop`]: drop
///
/// ## Drop Bestellung
///
/// Wéi eng vun eisen zwee `HasDrop` fällt awer als éischt?Fir Structs ass et déiselwecht Uerdnung datt se deklaréiert ginn: éischt `one`, dann `two`.
/// Wann Dir dëst selwer wëllt probéieren, kënnt Dir d `HasDrop` uewen änneren fir Daten ze enthalen, wéi eng ganz Zuel, an dann an der `println!` am `Drop` benotzen.
/// Dëst Verhalen ass vun der Sprooch garantéiert.
///
/// Am Géigesaz zu Structs gi lokal Variabelen am Géigendeel gefall:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Dëst wäert Drécken
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Kuckt w.e.g. [the reference] fir déi komplett Regelen.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` an `Drop` sinn exklusiv
///
/// Dir kënnt net béid [`Copy`] an `Drop` um selwechten Typ implementéieren.Typen déi `Copy` sinn, ginn implizit vum Compiler verduebelt, et mécht et ganz schwéier virauszegesinn wéini a wéi dacks Destruktoren ausgefouert ginn.
///
/// Als esou kënnen dës Aarte keng Destruktoren hunn.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Féiert den Destruktor fir dësen Typ aus.
    ///
    /// Dës Method gëtt implizit genannt wann de Wäert ausserhalb geet, a kann net explizit genannt ginn (dëst ass Compiler Feeler [E0040]).
    /// Wéi och ëmmer, d [`mem::drop`] Funktioun am prelude kann benotzt ginn fir d'Argument d `Drop` Ëmsetzung ze nennen.
    ///
    /// Wann dës Method genannt gouf, ass `self` nach net deallocéiert.
    /// Dat geschitt nëmmen nodeems d'Method eriwwer ass.
    /// Wann dëst net de Fall wier, wier `self` eng hängend Referenz.
    ///
    /// # Panics
    ///
    /// Entscheet datt en [`panic!`] `drop` nennt wéi se ofklappt, wäert all [`panic!`] an enger `drop`-Implementatioun wahrscheinlech ofbriechen.
    ///
    /// Bedenkt datt och wann dësen panics de Wäert als fale gelooss gëtt;
    /// Dir däerft net dozou féieren datt `drop` erëm opgeruff gëtt.
    /// Dëst gëtt normalerweis automatesch vum Compiler gehandhabt, awer wann Dir onsécher Code benotzt, kann heiansdo ongewollt optrieden, besonnesch wann Dir [`ptr::drop_in_place`] benotzt.
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}