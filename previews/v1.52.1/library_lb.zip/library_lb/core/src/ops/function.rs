/// D'Versioun vum Ruffbedreiwer déi en onverännerbaren Empfänger hëlt.
///
/// Instanze vun `Fn` kënnen ëmmer erëm genannt ginn ouni de Staat ze mutéieren.
///
/// *Dësen trait (`Fn`) ass net ze verwiessele mat [function pointers] (`fn`).*
///
/// `Fn` gëtt automatesch duerch Zoumaache implementéiert déi nëmmen onverännerbar Referenze fir ageholl Variablen huelen oder guer näischt fänken, souwéi (safe) [function pointers] (mat e puer Virwërf, kuckt hir Dokumentatioun fir méi Detailer).
///
/// Zousätzlech fir all Typ `F` deen `Fn` implementéiert, implementéiert `&F` och `Fn`.
///
/// Well béid [`FnMut`] an [`FnOnce`] Supertraits vun `Fn` sinn, kann all Beispill vun `Fn` als Parameter benotzt ginn, wou en [`FnMut`] oder [`FnOnce`] erwaart gëtt.
///
/// Benotzt `Fn` als gebonnen wann Dir e Parameter vun der Funktiounsähnlech Aart akzeptéiere wëllt an et ëmmer erëm ruffe muss an ouni de Staat ze mutéieren (z. B. wann Dir et gläichzäiteg nennt).
/// Wann Dir net sou streng Ufuerderunge braucht, benotzt [`FnMut`] oder [`FnOnce`] als Grenzen.
///
/// Kuckt d [chapter on closures in *The Rust Programming Language*][book] fir méi Informatiounen iwwer dëst Thema.
///
/// Och ze bemierken ass déi speziell Syntax fir `Fn` traits (z. B.
/// `Fn(usize, bool) -> usize ').Déi interesséiert un den techneschen Detailer dovun kënnen op [the relevant section in the *Rustonomicon*][nomicon] bezéien.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Opruff enger Zoumaache
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Mat engem `Fn` Parameter
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // sou datt regex dee `&str: !FnMut` kann vertrauen
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Féiert d'Opruff Operatioun.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// D'Versioun vum Ruffbedreiwer déi e mutablen Empfänger hëlt.
///
/// Instanzen vun `FnMut` kënnen ëmmer erëm genannt ginn a kënne Staat mutéieren.
///
/// `FnMut` gëtt automatesch duerch Zoumaache implementéiert déi mutéierbar Referenze fir ageholl Variablen huelen, souwéi all Typen déi [`Fn`] implementéieren, zB (safe) [function pointers] (zënter `FnMut` ass eng Supertrait vun [`Fn`]).
/// Zousätzlech fir all Typ `F` deen `FnMut` implementéiert, implementéiert `&mut F` och `FnMut`.
///
/// Well [`FnOnce`] e Supertrait vun `FnMut` ass, kann all Beispill vun `FnMut` benotzt ginn wou en [`FnOnce`] erwaart gëtt, a well [`Fn`] en Ënnertrait vun `FnMut` ass, kann all Beispill vun [`Fn`] benotzt ginn wou `FnMut` erwaart gëtt.
///
/// Benotzt `FnMut` als gebonnen wann Dir e Parameter vun der Funktiounsähnlech Aart akzeptéiere wëllt a se ëmmer erëm uruffe musst, wärend et erlaabt de Staat ze mutéieren.
/// Wann Dir net wëllt datt de Parameter de Staat mutéiert, benotzt [`Fn`] als gebonnen;wann Dir et net ëmmer ruffe musst, benotzt [`FnOnce`].
///
/// Kuckt d [chapter on closures in *The Rust Programming Language*][book] fir méi Informatiounen iwwer dëst Thema.
///
/// Och ze bemierken ass déi speziell Syntax fir `Fn` traits (z. B.
/// `Fn(usize, bool) -> usize ').Déi interesséiert un den techneschen Detailer dovun kënnen op [the relevant section in the *Rustonomicon*][nomicon] bezéien.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Vocatioun engem mutably festhält Zoumaache
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Mat engem `FnMut` Parameter
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // sou datt regex dee `&str: !FnMut` kann vertrauen
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Féiert d'Opruff Operatioun.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// D'Versioun vum Ruffbedreiwer déi e By-Value Empfänger hëlt.
///
/// Instanzen vun `FnOnce` kënne geruff ginn, awer vläicht net méi oft uruffbar sinn.Wéinst deem, wann dat eenzegt wat iwwer en Typ bekannt ass ass datt et `FnOnce` implementéiert, kann et nëmmen eemol genannt ginn.
///
/// `FnOnce` gëtt automatesch duerch Zoumaache implementéiert déi gefaange Variabelen konsuméiere kéinten, souwéi all Typen déi [`FnMut`] implementéieren, zB (safe) [function pointers] (zënter `FnOnce` ass eng Supertrait vun [`FnMut`]).
///
///
/// Well béid [`Fn`] an [`FnMut`] Subtraite vun `FnOnce` sinn, kann all Beispill vun [`Fn`] oder [`FnMut`] benotzt ginn wou en `FnOnce` erwaart gëtt.
///
/// Benotzt `FnOnce` als gebonne wann Dir e Parameter vun der Funktiounsähnlech Aart akzeptéiere wëllt a just en eemol uruffe musst.
/// Wann Dir de Parameter ëmmer ruffe musst, benotzt [`FnMut`] als gebonnen;wann Dir et och braucht fir de Staat net ze mutéieren, benotzt [`Fn`].
///
/// Kuckt d [chapter on closures in *The Rust Programming Language*][book] fir méi Informatiounen iwwer dëst Thema.
///
/// Och ze bemierken ass déi speziell Syntax fir `Fn` traits (z. B.
/// `Fn(usize, bool) -> usize ').Déi interesséiert un den techneschen Detailer dovun kënnen op [the relevant section in the *Rustonomicon*][nomicon] bezéien.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Mat engem `FnOnce` Parameter
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` verbraucht seng gefaange Variabelen, sou datt et net méi wéi eemol lafe kann.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Probéiert de `func()` nach eng Kéier unzeruffen geheit en `use of moved value` Feeler fir `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` kann op dësem Punkt net méi ugeruff ginn
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // sou datt regex dee `&str: !FnMut` kann vertrauen
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Den zréckgoen Typ nodeems de Ruffbedreiwer benotzt gëtt.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Féiert d'Opruff Operatioun.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}