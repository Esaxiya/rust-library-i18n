use crate::marker::Unsize;

/// Trait dat weist datt dëst e Zeiger oder e Wéckel fir een ass, wou d'Ongréisse kënnen op der Pointee ausgefouert ginn.
///
/// Kuckt d [DST coercion RFC][dst-coerce] an d [the nomicon entry on coercion][nomicon-coerce] fir méi Detailer.
///
/// Fir agebaute Zeigentypen, Zeigefanger op `T` zwéngen Zeigefanger op `U` wann `T: Unsize<U>` duerch Konvertéierung vun engem dënnen Zeiger an e Fettzeiger.
///
/// Fir personaliséiert Zorten funktionnéiert d'Zwang hei duerch Zwang `Foo<T>` op `Foo<U>`, wann en Impl vun `CoerceUnsized<Foo<U>> for Foo<T>` existéiert.
/// Sou en Im kann nëmme geschriwwe ginn wann `Foo<T>` nëmmen een eenzegt net-phantomdata Feld huet mat `T`.
/// Wann d'Zort vun deem Feld `Bar<T>` ass, muss eng Implementatioun vun `CoerceUnsized<Bar<U>> for Bar<T>` existéieren.
/// D'Zwang funktionnéiert andeems de `Bar<T>` Feld an `Bar<U>` zwéngt an de Rescht vun de Felder aus `Foo<T>` ausfëllt fir en `Foo<U>` ze kreéieren.
/// Dëst wäert effektiv op e Zeigefeld drillen an dat zwéngen.
///
/// Allgemeng, fir intelligent Zeigefanger implementéiert Dir `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, mat engem optionalen `?Sized` gebonnen op `T` selwer.
/// Fir Wrapperaarten déi `T` wéi `Cell<T>` an `RefCell<T>` direkt embedden, kënnt Dir direkt `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` implementéieren.
///
/// Dëst léisst Zwang vun Typen wéi `Cell<Box<T>>` funktionnéieren.
///
/// [`Unsize`][unsize] gëtt benotzt fir Zorten ze markéieren déi zu DSTs gezwonge kënne ginn wann hannert Zeigefanger.Et gëtt automatesch vum Compiler implementéiert.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Dëst gëtt fir Objektsécherheet benotzt, fir ze kontrolléieren datt de Empfängerart vun enger Method verschéckt ka ginn.
///
/// E Beispill Ëmsetzung vun der trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}