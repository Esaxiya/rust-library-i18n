/// Benotzt fir onverännerbar Dereferenzen Operatiounen, wéi `*v`.
///
/// Zousätzlech fir explizit Dereferenzéierungsoperatioune mam (unary) `*` Operator an onverännerbare Kontexter benotzt ze ginn, gëtt `Deref` och implizit vum Compiler a ville Ëmstänn benotzt.
/// Dëse Mechanismus gëtt ['`Deref` coercion'][more] genannt.
/// A mutable Kontexter gëtt [`DerefMut`] benotzt.
///
/// D'Ëmsetzung vun der `Deref` fir intelligent Zeigefanger mécht den Zougang zu den Daten hannert hinnen bequem, dofir implementéiere se `Deref`.
/// Op der anerer Säit goufen d'Reegele betreffend `Deref` an [`DerefMut`] speziell entwéckelt fir intelligent Zeigefanger z'empfänken.
/// Wéinst dësem soll **"Deref" nëmme fir intelligent Indikatoren ëmgesat ginn** fir Duercherneen ze vermeiden.
///
/// Aus ähnleche Grënn,**dës trait sollt ni ausfalen**.Feeler beim Dereferencing kann extrem konfus sinn wann `Deref` implizit opgeruff gëtt.
///
/// # Méi iwwer `Deref` Zwang
///
/// Wann `T` `Deref<Target = U>` implementéiert, an `x` e Wäert vum Typ `T` ass, da:
///
/// * An onverännerbaren Kontexter ass `*x` (wou `T` weder eng Referenz nach e roude Zeiger ass) gläichwäerteg mat `* Deref::deref(&x)`.
/// * Wäerter vum Typ `&T` ginn u Wäerter vum Typ `&U` gezwongen
/// * `T` implizit all d (immutable) Methode vum Typ `U` implementéiert.
///
/// Fir méi Detailer besicht [the chapter in *The Rust Programming Language*][book] wéi och d'Referenz Sektiounen op [the dereference operator][ref-deref-op], [method resolution] an [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// E Struktur mat engem eenzege Feld wat zougänglech ass andeems Dir de Struktur verfeiert.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Déi doraus resultéierend Zort no derferferencing.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Dereferenzen de Wäert.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Benotzt fir mutabel Dereferenzen Operatiounen, wéi an `*v = 1;`.
///
/// Zousätzlech fir explizit dereferencing Operatioune mam (unary) `*` Bedreiwer a mutabele Kontexter benotzt ze ginn, gëtt `DerefMut` och implizit vum Compiler a ville Ëmstänn benotzt.
/// Dëse Mechanismus gëtt ['`Deref` coercion'][more] genannt.
/// An onverännerbaren Kontexter gëtt [`Deref`] benotzt.
///
/// Duerch d'Ëmsetzung vun `DerefMut` fir intelligent Zeigefanger gëtt d'Daten hannert hinne mutéiert bequem, dofir implementéiere se `DerefMut`.
/// Op der anerer Säit goufen d'Reegele betreffend [`Deref`] an `DerefMut` speziell entwéckelt fir intelligent Zeigefanger z'empfänken.
/// Wéinst dësem **soll "DerefMut" nëmme fir intelligent Zeigefanger ëmgesat ginn** fir Duercherneen ze vermeiden.
///
/// Aus ähnleche Grënn,**dës trait sollt ni ausfalen**.Feeler beim Dereferencing kann extrem konfus sinn wann `DerefMut` implizit opgeruff gëtt.
///
/// # Méi iwwer `Deref` Zwang
///
/// Wann `T` `DerefMut<Target = U>` implementéiert, an `x` e Wäert vum Typ `T` ass, da:
///
/// * A verännerbaren Kontexter ass `*x` (wou `T` weder eng Referenz nach e roude Zeiger ass) gläichwäerteg mat `* DerefMut::deref_mut(&mut x)`.
/// * Wäerter vum Typ `&mut T` ginn u Wäerter vum Typ `&mut U` gezwongen
/// * `T` implizit all d (mutable) Methode vum Typ `U` implementéiert.
///
/// Fir méi Detailer besicht [the chapter in *The Rust Programming Language*][book] wéi och d'Referenz Sektiounen op [the dereference operator][ref-deref-op], [method resolution] an [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// E Struktur mat engem eenzege Feld wat verännerbar ass andeems Dir de Struktur verfeiert.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Mutéierend verweist de Wäert.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Weist datt e Struct kann als Methodempfänger benotzt ginn, ouni d `arbitrary_self_types` Feature.
///
/// Dëst gëtt vu stdlib Zeigentypen wéi `Box<T>`, `Rc<T>`, `&T` an `Pin<P>` implementéiert.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}