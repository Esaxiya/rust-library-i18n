use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Eng Interface fir mat asynchrone Iteratoren ëmzegoen.
///
/// Dëst ass den Haaptstroum trait.
/// Fir méi iwwer d'Konzept vu Stroum allgemeng, kuckt w.e.g. [module-level documentation].
/// Besonnesch, Dir wëllt wësse wéi [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Déi Zort vun Artikelen, déi vum Stroum noginn.
    type Item;

    /// Probéiert de nächste Wäert vun dësem Stream erauszezéien, déi aktuell Aufgab fir Wakeup unzemellen wann de Wäert nach net verfügbar ass, an zréck `None` wann de Stream erschöpft ass.
    ///
    /// # Retour Wäert
    ///
    /// Et gi verschidde méiglech Retourwäerter, déi all en ënnerschiddleche Stroumzoustand uginn:
    ///
    /// - `Poll::Pending` heescht datt de nächste Wäert vun dësem Stream nach net fäerdeg ass.Implementatiounen suergen dofir datt déi aktuell Aufgab matgedeelt gëtt wann den nächste Wäert fäerdeg ka sinn.
    ///
    /// - `Poll::Ready(Some(val))` heescht datt de Stroum erfollegräich e Wäert produzéiert huet, `val`, a ka weider Wäerter op uschléissend `poll_next` Uriff produzéieren.
    ///
    /// - `Poll::Ready(None)` heescht datt de Stream ofgeschloss ass, an `poll_next` sollt net erëm opgeruff ginn.
    ///
    /// # Panics
    ///
    /// Wann e Stream fäerdeg ass (zréck `Ready(None)` from `poll_next`), rufft seng `poll_next` Method erëm kann panic, fir ëmmer blockéieren oder aner Aarte vu Probleemer verursaachen; `Stream` trait stellt keng Ufuerderungen un d'Effekter vun esou engem Uruff.
    ///
    /// Wéi och ëmmer, well d `poll_next` Method net `unsafe` markéiert ass, gëllen déi üblech Regele vum Rust: Uriff däerfen ni ondefinéiert Verhalen (Gedächtniskorruptioun, falsch Benotze vun `unsafe` Funktiounen oder ähnleches) verursaachen, onofhängeg vum Streamszoustand.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Gitt d'Grenzen op der verbleiwender Längt vum Stroum zréck.
    ///
    /// Besonnesch `size_hint()` bréngt eng Tuple zréck wou dat éischt Element déi ënnescht Grenz ass, an dat zweet Element déi iewescht Grenz ass.
    ///
    /// Déi zweet Halschent vun der Tuple, déi zréckkomm ass, ass eng [`Option`]`<`[`usize`] `>".
    /// A [`None`] hei heescht datt entweder et kee bekannten Uewergrenz ass, oder datt d'Uewergrenz méi grouss ass wéi [`usize`].
    ///
    /// # Implementéierungsnotizen
    ///
    /// Et gëtt net duerchgesat datt eng Streamimplementatioun déi deklaréiert Zuel vun Elementer ergëtt.E Buggy Stroum ka manner wéi déi ënnescht Grenz oder méi wéi déi iewescht Grenz vun Elementer ginn.
    ///
    /// `size_hint()` ass haaptsächlech fir Optimisatiounen benotzt ze ginn wéi zum Beispill Plaz fir d'Elementer vum Stroum reservéieren, awer däerf net vertraut sinn zB, Grenzen Kontrollen an onsécherem Code ewech ze loossen.
    /// Eng falsch Ëmsetzung vun `size_hint()` soll net zu Gedächtnis Sécherheetsverletzunge féieren.
    ///
    /// Wéi gesot, d'Ëmsetzung sollt eng korrekt Estimatioun ubidden, well soss wier et eng Verletzung vum trait Protokoll.
    ///
    /// D'Standardimplementatioun zréck "(0,` [`Keen`]`)`wat fir all Stream korrekt ass.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}