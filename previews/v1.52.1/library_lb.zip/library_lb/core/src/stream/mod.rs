//! Komposéierbar asynchrone Iteratioun.
//!
//! Wann futures asynchrone Wäerter sinn, da si Stréimungen asynchron Iteratoren.
//! Wann Dir Iech mat enger asynchroner Sammlung vun iergendengem fonnt hutt, an Dir braucht eng Operatioun op den Elementer vun der gesammelter Sammlung auszeféieren, gitt Dir séier op 'streams'.
//! Stréimunge gi staark an idiomateschen asynchronen Rust Code benotzt, sou datt et derwäert ass sech mat hinnen ze vertraut.
//!
//! Ier mer méi erkläre loossen, schwätze mer wéi dëse Modul strukturéiert ass:
//!
//! # Organization
//!
//! Dëst Modul ass gréisstendeels nom Typ organiséiert:
//!
//! * [Traits] sinn den Haaptdeel: dës traits definéieren wéi eng Stréimunge existéieren a wat Dir mat hinne maache kënnt.D'Methode vun dësen traits sinn derwäert eng extra Studienzäit anzesetzen.
//! * Funktioune bidden e puer hëllefräich Weeër fir e puer Basisstroum ze kreéieren.
//! * Structs sinn dacks d'Retourtypen vun de verschiddene Methoden op dësem traits.Dir wëllt normalerweis op d'Methode kucken déi den `struct` erstellt, anstatt d `struct` selwer.
//! Fir méi Detailer iwwer firwat, kuckt '[Implementing Stream](#implement-stream)'.
//!
//! [Traits]: #traits
//!
//! Dat ass et!Loosst eis a Stréimunge gräifen.
//!
//! # Stream
//!
//! D'Häerz an d'Séil vun dësem Modul ass den [`Stream`] trait.De Kär vum [`Stream`] gesäit sou aus:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Am Géigesaz zu `Iterator` mécht `Stream` en Ënnerscheed tëscht der [`poll_next`] Method déi benotzt gëtt wann Dir en `Stream` implementéiert an eng (to-be-implemented) `next` Method déi benotzt gëtt wann Dir e Stream verbraucht.
//!
//! Konsumenten vun `Stream` mussen nëmmen `next` berécksiichtegen, déi wann et geruff gëtt, en future zréckbréngt deen `Option<Stream::Item>` gëtt.
//!
//! Den future zréck vun `next` wäert `Some(Item)` ginn soulaang et Elementer sinn, a wann se all erschöpft sinn, gëtt `None` fir unzeginn datt d'Iteratioun fäerdeg ass.
//! Wa mir op eppes asynchron wëlle fir ze léisen, waart den future bis de Stroum erëm fäerdeg ass.
//!
//! Eenzel Stréimunge kënne wielen d'Iteratioun erëm opzehuelen, a sou kann een den `next` erëm uruffen eventuell `Some(Item)` iergendwann erëm erabréngen.
//!
//! ['Stream'] 's voll Definitioun enthält och eng Rei aner Methoden, awer si sinn Standardmethoden, uewen op [`poll_next`] gebaut, a sou kritt Dir se gratis.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Ëmsetzung Stream
//!
//! En eegene Stroum ze kreéieren involvéiert zwee Schrëtt: en `struct` erstallt fir de Streamszoustand ze halen, an dann [`Stream`] fir deen `struct` ëmzesetzen.
//!
//! Loosst eis e Stream mam Numm `Counter` maachen deen vun `1` op `5` zielt:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Als éischt de Struct:
//!
//! /// Eng Baach déi vun engem bis fënnef zielt
//! struct Counter {
//!     count: usize,
//! }
//!
//! // mir wëllen datt eise Grof bei engem ufänkt, also addéiere mer eng new() Method fir ze hëllefen.
//! // Dëst ass net streng néideg, awer ass bequem.
//! // Bedenkt datt mir `count` op Null starten, mir kucken firwat an der `poll_next()`'s Ëmsetzung ënnendrënner.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Dann implementéiere mir `Stream` fir eis `Counter`:
//!
//! impl Stream for Counter {
//!     // mir ziele mat Usize
//!     type Item = usize;
//!
//!     // poll_next() ass déi eenzeg erfuerderlech Method
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Inkrementéiert eise Grof.Duerfir hu mir bei Null ugefaang.
//!         self.count += 1;
//!
//!         // Kontrolléiert ze gesinn, ob mir fäerdeg sinn ze zielen oder net.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Streams sinn *liddereg*.Dëst bedeit datt just e Stream erstellen net _do_ ganz vill.Näischt geschitt wierklech bis Dir `next` nennt.
//! Dëst ass heiansdo eng Quell vu Verwirrung wann Dir e Stream eleng fir seng Nebenwirkungen erstellt.
//! De Compiler warnt eis iwwer dës Aart vu Behuelen:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;