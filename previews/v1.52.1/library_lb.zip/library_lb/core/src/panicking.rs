//! Panic Ënnerstëtzung fir libcore
//!
//! D'Kärbibliothéik kann net Panik definéieren, awer et *deklaréiert* Panik.
//! Dëst bedeit datt d'Funktiounen am Libcore panic erlaabt sinn, awer fir nëtzlech ze sinn muss en Upstream crate Panik definéieren fir Libcore ze benotzen.
//! Déi aktuell Interface fir Panik ass:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Dës Definitioun erlaabt Panik mat allgemenger Noriicht, awer et erlaabt et net mat engem `Box<Any>` Wäert ze feelen.
//! (`PanicInfo` enthält just en `&(dyn Any + Send)`, fir deen mir en Dummy-Wäert an `PanicInfo: : internal_constructor` ausfëllen.) De Grond dofir ass datt libcore net erlaabt ass ze allocéieren.
//!
//!
//! Dëst Modul enthält e puer aner Panikfunktiounen, awer dës si just déi néideg lang Artikele fir de Compiler.All panics ginn duerch dës eng Funktioun getrennt.
//! Dat aktuellt Symbol gëtt duerch den `#[panic_handler]` Attribut deklaréiert.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Déi ënnerläit Implementatioun vum Libcore `panic!` Macro wa keng Formatéierung benotzt gëtt.
#[cold]
// ni inline ausser panic_immediate_abort fir ze vermeiden datt de Code op den Uruffsäiten sou vill wéi méiglech bloat
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // gebraucht vu Codegen fir panic op Iwwerlaf an aner `Assert` MIR Terminatoren
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Benotzt Arguments::new_v1 amplaz format_args! ("{}", Expr) fir eventuell d'Gréisst uewen ze reduzéieren.
    // De Format_args!Macro benotzt str's Display trait fir expr ze schreiwen, wat Formatter::pad nennt, wat String Trunkerung a Padding upasse muss (och wann hei kee benotzt gëtt).
    //
    // Mat Arguments::new_v1 kann de Compiler erlaabt den Formatter::pad aus dem Ausgangsbinär auszeleeën, bis zu e puer Kilobytes.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // gebraucht fir const-evaluéiert panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // gebraucht vu Codegen fir panic op OOB array/slice Zougang
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Déi ënnerläit Implementatioun vum XcoreX-Makro vun libcore wann d'Formatéierung benotzt gëtt.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // OPGEPASST Dës Funktioun passéiert ni d'FFI Grenz;et ass en Rust-zu-Rust Uruff deen op d `#[panic_handler]` Funktioun geléist gëtt.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // SAFETY: `panic_impl` ass definéiert am sécheren Rust Code an ass also sécher ze ruffen.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Intern Funktioun fir `assert_eq!` an `assert_ne!` Makroen
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}