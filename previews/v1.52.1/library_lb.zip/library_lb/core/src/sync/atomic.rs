//! Atomtypen
//!
//! Atomtypen bidden primitiv Shared-Memory Kommunikatioun tëscht Fiedem, a sinn d'Bausteng vun anere gläichzäitegen Typen.
//!
//! Dëse Modul definéiert Atomversiounen vun enger gewielter Unzuel u primitiven Typen, dorënner [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], etc.
//! Atomtypen presentéieren Operatiounen déi, wa se richteg benotzt ginn, Updates tëscht Threads synchroniséieren.
//!
//! All Method hëlt en [`Ordering`] wat d'Stäerkt vun der Erënnerungsbarrière fir dës Operatioun duerstellt.Dës Bestellunge sinn déiselwecht wéi den [C++20 atomic orderings][1].Fir méi Informatioun kuckt [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Atomesch Variabelen si sécher tëscht Themen ze deelen (se implementéieren [`Sync`]) awer si ginn net selwer de Mechanismus fir ze deelen an dem [threading model](../../../std/thread/index.html#the-threading-model) vun Rust ze verfollegen.
//!
//! Déi meescht üblech Manéier fir eng atomar Variabel ze teelen ass et an en [`Arc`][arc] ze setzen (en atomesch mat Referenz gezielt gedeeltem Zeiger).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Atomtypen kënnen a statesch Variabelen gelagert ginn, initialiséiert mat konstante Initialiséierer wéi [`AtomicBool::new`].Atomstatik ginn dacks fir liddereg global Initialiséierung benotzt.
//!
//! # Portability
//!
//! All Atomtypen an dësem Modul si garantéiert [lock-free] wann se verfügbar sinn.Dëst bedeit datt se net intern e globalen Mutex kréien.Atomtypen an Operatiounen sinn net garantéiert waartfräi ze sinn.
//! Dëst bedeit datt Operatiounen wéi `fetch_or` mat engem Compare-and-Swap Loop implementéiert kënne ginn.
//!
//! Atomesch Operatiounen kënnen an der Instruktiounsschicht mat méi grousser Atomer implementéiert ginn.Zum Beispill benotze verschidde Plattforme 4-Byte atomesch Instruktiounen fir `AtomicI8` ëmzesetzen.
//! Bedenkt datt dës Emulatioun keen Afloss op d'Korrektheet vum Code soll hunn, et ass just eppes ze wëssen.
//!
//! D'Atomtypen an dësem Modul kënnen net op all Plattformen verfügbar sinn.D'Atomtypen hei sinn all wäit verfügbar, awer a kënne meeschtens op existent vertrauen.E puer bemierkenswäert Ausnamen sinn:
//!
//! * PowerPC an MIPS Plattformen mat 32-Bit Zeigefanger hunn net `AtomicU64` oder `AtomicI64` Typen.
//! * ARM Plattforme wéi `armv5te` déi net fir Linux sinn nëmmen `load` an `store` Operatiounen ubidden, an ënnerstëtzen net vergläichen a wiesselen (CAS) Operatiounen, wéi `swap`, `fetch_add`, etc.
//! Zousätzlech op Linux ginn dës CAS Operatiounen iwwer [operating system support] implementéiert, wat mat enger Leeschtungstrof kënnt.
//! * ARM Ziler mat `thumbv6m` bidden nëmmen `load` an `store` Operatiounen, an ënnerstëtzen net Compare a Swap (CAS) Operatiounen, wéi `swap`, `fetch_add`, etc.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Bedenkt datt future Plattformen derbäigesat kënne ginn, déi och keng Ënnerstëtzung fir e puer atomesch Operatiounen hunn.Maximal portable Code wëll virsiichteg sinn iwwer déi Atomtypen benotzt ginn.
//! `AtomicUsize` an `AtomicIsize` si meeschtens déi portabelst, awer och da sinn se net iwwerall verfügbar.
//! Als Referenz erfuerdert d `std` Bibliothéik Zeigefërmeg Atomer, obwuel `core` net.
//!
//! Momentan musst Dir `#[cfg(target_arch)]` haaptsächlech benotze fir bedingt am Code mat Atomer ze kompiléieren.Et ass en onbestännegen `#[cfg(target_has_atomic)]`, deen och an der future stabiliséiert ka ginn.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Eng einfach Spinlock:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Waart bis deen anere Fuedem de Schlass fräigelooss huet
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Halt e globalen Ziel vu Live Threads:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// E booleschen Typ dee sécher tëscht de Fiedem gedeelt ka ginn.
///
/// Dësen Typ huet déiselwecht In-Memory Representatioun wéi en [`bool`].
///
/// **Notiz**: Dësen Typ ass nëmme verfügbar op Plattformen déi atomesch Laaschten a Geschäfter vun `u8` ënnerstëtzen.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Erstellt en `AtomicBool` initialiséiert op `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Send gëtt implizit fir AtomicBool implementéiert.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// E roude Zeigentyp deen sëcher tëscht Themen gedeelt ka ginn.
///
/// Dësen Typ huet déiselwecht In-Memory Representatioun wéi en `*mut T`.
///
/// **Notiz**: Dësen Typ ass nëmme verfügbar op Plattformen déi atomar Belaaschtungen a Späicher vun Zeigner ënnerstëtzen.
/// Seng Gréisst hänkt vun der Gréisst vum Zilzeiger of.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Erstellt en null `AtomicPtr<T>`.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Atomesch Gedächtnisbestellungen
///
/// Erënnerungsbestellunge spezifizéieren de Wee wéi atomesch Operatiounen Erënnerung synchroniséieren.
/// A sengem schwaachsten [`Ordering::Relaxed`] gëtt nëmmen d'Erënnerung direkt beréiert vun der Operatioun synchroniséiert.
/// Op der anerer Säit synchroniséiert e Store-Load-Paar vun [`Ordering::SeqCst`] Operatiounen aner Erënnerung wärend se zousätzlech eng Gesamtuerdnung vun esou Operatiounen iwwer all Fiedere konservéieren.
///
///
/// D'Erënnerungsuerdnunge vum Rust sinn [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// Fir méi Informatioun kuckt [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Keng Bestellungsbeschränkungen, nëmmen atomesch Operatiounen.
    ///
    /// Entsprécht [`memory_order_relaxed`] am C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Wann et mat engem Geschäft gekoppelt ass, ginn all fréier Operatiounen bestallt virun all Laascht vun dësem Wäert mat [`Acquire`] (oder méi staark) Bestellung.
    ///
    /// Besonnesch all fréier Schreiwe gi fir all Themen sichtbar, déi eng [`Acquire`] (oder méi staark) Laascht vun dësem Wäert maachen.
    ///
    /// Bedenkt datt d'Benotzung vun dëser Bestellung fir eng Operatioun déi Laaschten a Geschäfter kombinéiert féiert zu enger [`Relaxed`] Laaschtoperatioun!
    ///
    /// Dës Bestellung ass nëmmen uwendbar fir Operatiounen déi e Geschäft ausféiere kënnen.
    ///
    /// Entsprécht [`memory_order_release`] am C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Wa gekoppelt mat enger Belaaschtung, wann de geluedene Wäert vun enger Geschäftsoperatioun mat [`Release`] (oder méi staarker) Bestellung geschriwwe gouf, da ginn all spéider Operatiounen no deem Geschäft bestallt.
    /// Besonnesch all spéider Belaaschtunge gesinn Daten, déi virum Buttek geschriwwe sinn.
    ///
    /// Bedenkt datt dës Bestellung fir eng Operatioun benotzt déi Laaschten a Geschäfter kombinéiert féiert zu enger [`Relaxed`] Geschäftsoperatioun!
    ///
    /// Dës Bestellung ass nëmmen uwendbar fir Operatiounen déi eng Belaaschtung maache kënnen.
    ///
    /// Entsprécht [`memory_order_acquire`] am C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Huet d'Effekter vu béiden [`Acquire`] an [`Release`] zesummen:
    /// Fir Luede benotzt se [`Acquire`] Bestellung.Fir Geschäfter benotzt se d [`Release`] Bestellung.
    ///
    /// Bedenkt datt am Fall vun `compare_and_swap` et méiglech ass datt d'Operatioun am Endeffekt kee Geschäft mécht an dofir huet et just [`Acquire`] Bestellung.
    ///
    /// Wéi och ëmmer, `AcqRel` wäert ni [`Relaxed`] Zougang maachen.
    ///
    /// Dës Bestellung ass nëmmen uwendbar fir Operatiounen déi Chargen a Geschäfter kombinéieren.
    ///
    /// Entsprécht [`memory_order_acq_rel`] am C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Wéi [`Acquire`]/[`Release`]/[`AcqRel`](fir Lueden, Späicheren a Luede mat Geschäfter respektiv) mat der zousätzlecher Garantie datt all Fuedem all sequentiell konsequent Operatiounen an der selwechter Reiefolleg gesinn .
    ///
    ///
    /// Entsprécht [`memory_order_seq_cst`] am C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// En [`AtomicBool`] initialiséiert op `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Erstellt en neien `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Nees eng mutéierbar Referenz zu der Basis [`bool`].
    ///
    /// Dëst ass sécher, well déi mutabel Referenz garantéiert datt keng aner Fäegkeete gläichzäiteg op d'Atomdaten zougräifen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // SAFETY: déi mutabel Referenz garantéiert en eenzegaartegt Eegentum.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Kritt atomeschen Zougang zu engem `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // SAFETY: déi mutabel Referenz garantéiert en eenzegaartegt Eegentum, an
        // Ausriichtung vu béiden `bool` an `Self` ass 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Verbraucht d'Atom a bréngt de enthale Wäert zréck.
    ///
    /// Dëst ass sécher, well de `self` duerch de Wäert weiderginn, garantéiert datt keng aner Fäegkeete gläichzäiteg op d'Atomdaten zougräifen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Luet e Wäert vum bool.
    ///
    /// `load` hëlt en [`Ordering`] Argument wat d'Erënnerungsuerdnung vun dëser Operatioun beschreift.
    /// Méiglech Wäerter sinn [`SeqCst`], [`Acquire`] an [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics wann `order` [`Release`] oder [`AcqRel`] ass.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // SIKKERHET: all Datenrennen gi vun der atomarer Intrinsik an der Roh verhënnert
        // Zeigefanger weiderginn ass valabel well mir hunn et vun enger Referenz.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Späichert e Wäert an den bool.
    ///
    /// `store` hëlt en [`Ordering`] Argument wat d'Erënnerungsuerdnung vun dëser Operatioun beschreift.
    /// Méiglech Wäerter sinn [`SeqCst`], [`Release`] an [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics wann `order` [`Acquire`] oder [`AcqRel`] ass.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // SIKKERHET: all Datenrennen gi vun der atomarer Intrinsik an der Roh verhënnert
        // Zeigefanger weiderginn ass valabel well mir hunn et vun enger Referenz.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Späichert e Wäert an den bool, andeems de fréiere Wäert zréckgeet.
    ///
    /// `swap` hëlt en [`Ordering`] Argument wat d'Erënnerungsuerdnung vun dëser Operatioun beschreift.All Bestellmodi si méiglech.
    /// Bedenkt datt d'Benotzung [`Acquire`] de Buttek Deel vun dëser Operatioun [`Relaxed`] mécht, a benotzt [`Release`] mécht de Laascht Deel [`Relaxed`].
    ///
    ///
    /// **Note:** Dës Method ass nëmme verfügbar op Plattformen déi atomesch Operatiounen op `u8` ënnerstëtzen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // SIKKERHET: Datenrennen gi vun der atomarer Intrinsik verhënnert.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Späichert e Wäert an den [`bool`] wann den aktuelle Wäert d'selwecht ass wéi den `current` Wäert.
    ///
    /// De Retourwäert ass ëmmer de fréiere Wäert.Wann et gläich wéi `current` ass, da gouf de Wäert aktualiséiert.
    ///
    /// `compare_and_swap` hëlt och en [`Ordering`] Argument wat d'Erënnerungsuerdnung vun dëser Operatioun beschreift.
    /// Bedenkt datt och wann Dir [`AcqRel`] benotzt, kann d'Operatioun ausfalen an dofir just eng `Acquire` Laascht ausféieren, awer net `Release` Semantik.
    /// Benotzung vun [`Acquire`] mécht de Buttek Deel vun dëser Operatioun [`Relaxed`] wann et geschitt, a benotzt [`Release`] mécht de Laascht Deel [`Relaxed`].
    ///
    /// **Note:** Dës Method ass nëmme verfügbar op Plattformen déi atomesch Operatiounen op `u8` ënnerstëtzen.
    ///
    /// # Migréieren op `compare_exchange` an `compare_exchange_weak`
    ///
    /// `compare_and_swap` ass entspriechend `compare_exchange` mat der folgender Mapping fir Gedächtnisbestellungen:
    ///
    /// Original |Erfolleg |Feeler
    /// -------- | ------- | -------
    /// Relax |Relax |Relax Erfaassen |Kaaft |Fräisetzung kréien |Fräisetzung |Relaxéiert AcqRel |AcqRel |Kaaft SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` ass erlaabt falsch ze versoen och wann de Verglach geléngt, wat dem Compiler erlaabt e bessere Montage Code ze generéieren wann de Verglach an de Swap an enger Loop benotzt gëtt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Späichert e Wäert an den [`bool`] wann den aktuelle Wäert d'selwecht ass wéi den `current` Wäert.
    ///
    /// De Retourwäert ass e Resultat dat weist ob den neie Wäert geschriwwe gouf an dee virege Wäert enthält.
    /// Beim Erfolleg ass dëse Wäert garantéiert gläich wéi `current`.
    ///
    /// `compare_exchange` hëlt zwee [`Ordering`] Argumenter fir d'Erënnerungsuerdnung vun dëser Operatioun ze beschreiwen.
    /// `success` beschreift déi erfuerderlech Bestellung fir d'Lies-Modify-Write Operatioun déi stattfënnt wann de Verglach mam `current` geléngt.
    /// `failure` beschreift déi erfuerderlech Bestellung fir d'Belaaschtungsoperatioun déi stattfënnt wann de Verglach fällt.
    /// Benotzt [`Acquire`] als Erfollegsbestellung mécht de Buttek Deel vun dëser Operatioun [`Relaxed`], a benotzt [`Release`] mécht déi erfollegräich Laascht [`Relaxed`].
    ///
    /// D'Fehlbestellung kann nëmme [`SeqCst`], [`Acquire`] oder [`Relaxed`] sinn a muss gläichwäerteg sinn oder méi schwaach sinn wéi d'Erfollegsbestellung.
    ///
    /// **Note:** Dës Method ass nëmme verfügbar op Plattformen déi atomesch Operatiounen op `u8` ënnerstëtzen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SIKKERHET: Datenrennen gi vun der atomarer Intrinsik verhënnert.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Späichert e Wäert an den [`bool`] wann den aktuelle Wäert d'selwecht ass wéi den `current` Wäert.
    ///
    /// Am Géigesaz zu [`AtomicBool::compare_exchange`] ass dës Funktioun erlaabt falsch ze versoen och wann de Verglach geléngt, wat zu méi effiziente Code op e puer Plattforme féiere kann.
    ///
    /// De Retourwäert ass e Resultat dat weist ob den neie Wäert geschriwwe gouf an dee virege Wäert enthält.
    ///
    /// `compare_exchange_weak` hëlt zwee [`Ordering`] Argumenter fir d'Erënnerungsuerdnung vun dëser Operatioun ze beschreiwen.
    /// `success` beschreift déi erfuerderlech Bestellung fir d'Lies-Modify-Write Operatioun déi stattfënnt wann de Verglach mam `current` geléngt.
    /// `failure` beschreift déi erfuerderlech Bestellung fir d'Belaaschtungsoperatioun déi stattfënnt wann de Verglach fällt.
    /// Benotzt [`Acquire`] als Erfollegsbestellung mécht de Buttek Deel vun dëser Operatioun [`Relaxed`], a benotzt [`Release`] mécht déi erfollegräich Laascht [`Relaxed`].
    /// D'Fehlbestellung kann nëmme [`SeqCst`], [`Acquire`] oder [`Relaxed`] sinn a muss gläichwäerteg sinn oder méi schwaach sinn wéi d'Erfollegsbestellung.
    ///
    /// **Note:** Dës Method ass nëmme verfügbar op Plattformen déi atomesch Operatiounen op `u8` ënnerstëtzen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SIKKERHET: Datenrennen gi vun der atomarer Intrinsik verhënnert.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Logesch "and" mat engem boolesche Wäert.
    ///
    /// Féiert eng logesch "and" Operatioun um aktuelle Wäert an dem Argument `val`, a setzt den neie Wäert op d'Resultat.
    ///
    /// Nees de fréiere Wäert.
    ///
    /// `fetch_and` hëlt en [`Ordering`] Argument wat d'Erënnerungsuerdnung vun dëser Operatioun beschreift.All Bestellmodi si méiglech.
    /// Bedenkt datt d'Benotzung [`Acquire`] de Buttek Deel vun dëser Operatioun [`Relaxed`] mécht, a benotzt [`Release`] mécht de Laascht Deel [`Relaxed`].
    ///
    ///
    /// **Note:** Dës Method ass nëmme verfügbar op Plattformen déi atomesch Operatiounen op `u8` ënnerstëtzen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // SIKKERHET: Datenrennen gi vun der atomarer Intrinsik verhënnert.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Logesch "nand" mat engem boolesche Wäert.
    ///
    /// Féiert eng logesch "nand" Operatioun um aktuelle Wäert an dem Argument `val`, a setzt den neie Wäert op d'Resultat.
    ///
    /// Nees de fréiere Wäert.
    ///
    /// `fetch_nand` hëlt en [`Ordering`] Argument wat d'Erënnerungsuerdnung vun dëser Operatioun beschreift.All Bestellmodi si méiglech.
    /// Bedenkt datt d'Benotzung [`Acquire`] de Buttek Deel vun dëser Operatioun [`Relaxed`] mécht, a benotzt [`Release`] mécht de Laascht Deel [`Relaxed`].
    ///
    ///
    /// **Note:** Dës Method ass nëmme verfügbar op Plattformen déi atomesch Operatiounen op `u8` ënnerstëtzen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Mir kënnen net atomic_nand hei benotzen well et kann zu engem bool mat engem ongëltege Wäert resultéieren.
        // Dëst passéiert well déi atomesch Operatioun mat enger 8-Bit ganz Zuel intern gemaach gëtt, déi déi iewescht 7 Bits setzen.
        //
        // Also benotze mir just fetch_xor oder tauschen amplaz.
        if val {
            // ! (x&richteg)== !x Mir mussen den bool invertéieren.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&falsch)==richteg Mir mussen den bool op richteg setzen.
            //
            self.swap(true, order)
        }
    }

    /// Logesch "or" mat engem boolesche Wäert.
    ///
    /// Féiert eng logesch "or" Operatioun um aktuelle Wäert an dem Argument `val`, a setzt den neie Wäert op d'Resultat.
    ///
    /// Nees de fréiere Wäert.
    ///
    /// `fetch_or` hëlt en [`Ordering`] Argument wat d'Erënnerungsuerdnung vun dëser Operatioun beschreift.All Bestellmodi si méiglech.
    /// Bedenkt datt d'Benotzung [`Acquire`] de Buttek Deel vun dëser Operatioun [`Relaxed`] mécht, a benotzt [`Release`] mécht de Laascht Deel [`Relaxed`].
    ///
    ///
    /// **Note:** Dës Method ass nëmme verfügbar op Plattformen déi atomesch Operatiounen op `u8` ënnerstëtzen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // SIKKERHET: Datenrennen gi vun der atomarer Intrinsik verhënnert.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Logesch "xor" mat engem boolesche Wäert.
    ///
    /// Féiert eng logesch "xor" Operatioun um aktuelle Wäert an dem Argument `val`, a setzt den neie Wäert op d'Resultat.
    ///
    /// Nees de fréiere Wäert.
    ///
    /// `fetch_xor` hëlt en [`Ordering`] Argument wat d'Erënnerungsuerdnung vun dëser Operatioun beschreift.All Bestellmodi si méiglech.
    /// Bedenkt datt d'Benotzung [`Acquire`] de Buttek Deel vun dëser Operatioun [`Relaxed`] mécht, a benotzt [`Release`] mécht de Laascht Deel [`Relaxed`].
    ///
    ///
    /// **Note:** Dës Method ass nëmme verfügbar op Plattformen déi atomesch Operatiounen op `u8` ënnerstëtzen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // SIKKERHET: Datenrennen gi vun der atomarer Intrinsik verhënnert.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Nees e mutablen Zeiger op de Basis [`bool`].
    ///
    /// Net-atomesch Liesen a Schreiwe maachen op déi resultéierend ganz Zuel kann eng Datecourse sinn.
    /// Dës Method ass meeschtens nëtzlech fir FFI, wou d'Funktiounsënnerschrëft `*mut bool` amplaz `&AtomicBool` benotze kann.
    ///
    /// En `*mut` Zeiger zréckzebréngen vun enger gemeinsamer Referenz zu dësem Atom ass sécher, well d'Atomtypen mat bannener Verännerlechkeet schaffen.
    /// All Modifikatioune vun engem Atom änneren de Wäert duerch eng gemeinsam Referenz, a kënne sou sécher maachen soulaang se atomesch Operatiounen benotzen.
    /// All Benotzung vum zréckgekéierte rouden Zeiger erfuerdert en `unsafe` Block a muss nach ëmmer déiselwecht Restriktioun oprecht halen: Operatiounen drop musse atomesch sinn.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Hëlt de Wäert, a benotzt eng Funktioun drop, déi en optionale neie Wäert zréckbréngt.Nees en `Result` vun `Ok(previous_value)` wann d'Funktioun `Some(_)` zréckgeet, soss `Err(previous_value)`.
    ///
    /// Note: Dëst kann d'Funktioun méi oft nennen wann de Wäert an der Tëschenzäit vun anere Fäegkeete geännert gouf, soulaang d'Funktioun `Some(_)` zréckkënnt, awer d'Funktioun nëmmen eemol op de gespäicherte Wäert applizéiert gouf.
    ///
    ///
    /// `fetch_update` hëlt zwee [`Ordering`] Argumenter fir d'Erënnerungsuerdnung vun dëser Operatioun ze beschreiwen.
    /// Déi éischt beschreift déi erfuerderlech Bestellung fir wann d'Operatioun endlech erfollegräich ass, an déi zweet beschreift déi erfuerderlech Bestellung fir Laaschten.
    /// Dës entspriechen den Erfollegs-an Ausfallbestellunge vun [`AtomicBool::compare_exchange`] respektiv.
    ///
    /// Benotzt [`Acquire`] als Erfollegsbestellung mécht de Buttek Deel vun dëser Operatioun [`Relaxed`], a benotzt [`Release`] mécht déi lescht erfollegräich Luede [`Relaxed`].
    /// D (failed) Laaschtbestellung kann nëmme [`SeqCst`], [`Acquire`] oder [`Relaxed`] sinn a muss gläichwäerteg sinn oder méi schwaach sinn wéi d'Erfollegsbestellung.
    ///
    /// **Note:** Dës Method ass nëmme verfügbar op Plattformen déi atomesch Operatiounen op `u8` ënnerstëtzen.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Erstellt en neien `AtomicPtr`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Nees eng mutéierbar Referenz zum Basisgrondweiger.
    ///
    /// Dëst ass sécher, well déi mutabel Referenz garantéiert datt keng aner Fäegkeete gläichzäiteg op d'Atomdaten zougräifen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Kritt atomeschen Zougang zu engem Zeiger.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - déi mutabel Referenz garantéiert eenzegaarteg Besëtz.
        //  - d'Ausriichtung vun `*mut T` an `Self` ass déiselwecht op all Plattformen ënnerstëtzt vun rust, wéi uewe verifizéiert.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Verbraucht d'Atom a bréngt de enthale Wäert zréck.
    ///
    /// Dëst ass sécher, well de `self` duerch de Wäert weiderginn, garantéiert datt keng aner Fäegkeete gläichzäiteg op d'Atomdaten zougräifen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Luet e Wäert vum Zeiger.
    ///
    /// `load` hëlt en [`Ordering`] Argument wat d'Erënnerungsuerdnung vun dëser Operatioun beschreift.
    /// Méiglech Wäerter sinn [`SeqCst`], [`Acquire`] an [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics wann `order` [`Release`] oder [`AcqRel`] ass.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // SIKKERHET: Datenrennen gi vun der atomarer Intrinsik verhënnert.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Späichert e Wäert an de Zeiger.
    ///
    /// `store` hëlt en [`Ordering`] Argument wat d'Erënnerungsuerdnung vun dëser Operatioun beschreift.
    /// Méiglech Wäerter sinn [`SeqCst`], [`Release`] an [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics wann `order` [`Acquire`] oder [`AcqRel`] ass.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // SIKKERHET: Datenrennen gi vun der atomarer Intrinsik verhënnert.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Späichert e Wäert an de Zeigefanger, gitt de fréiere Wäert zréck.
    ///
    /// `swap` hëlt en [`Ordering`] Argument wat d'Erënnerungsuerdnung vun dëser Operatioun beschreift.All Bestellmodi si méiglech.
    /// Bedenkt datt d'Benotzung [`Acquire`] de Buttek Deel vun dëser Operatioun [`Relaxed`] mécht, a benotzt [`Release`] mécht de Laascht Deel [`Relaxed`].
    ///
    ///
    /// **Note:** Dës Method ass nëmme verfügbar op Plattformen déi atomesch Operatiounen op Zeigner ënnerstëtzen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // SIKKERHET: Datenrennen gi vun der atomarer Intrinsik verhënnert.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Späichert e Wäert an de Zeiger wann den aktuelle Wäert d'selwecht ass wéi den `current` Wäert.
    ///
    /// De Retourwäert ass ëmmer de fréiere Wäert.Wann et gläich wéi `current` ass, da gouf de Wäert aktualiséiert.
    ///
    /// `compare_and_swap` hëlt och en [`Ordering`] Argument wat d'Erënnerungsuerdnung vun dëser Operatioun beschreift.
    /// Bedenkt datt och wann Dir [`AcqRel`] benotzt, kann d'Operatioun ausfalen an dofir just eng `Acquire` Laascht ausféieren, awer net `Release` Semantik.
    /// Benotzung vun [`Acquire`] mécht de Buttek Deel vun dëser Operatioun [`Relaxed`] wann et geschitt, a benotzt [`Release`] mécht de Laascht Deel [`Relaxed`].
    ///
    /// **Note:** Dës Method ass nëmme verfügbar op Plattformen déi atomesch Operatiounen op Zeigner ënnerstëtzen.
    ///
    /// # Migréieren op `compare_exchange` an `compare_exchange_weak`
    ///
    /// `compare_and_swap` ass entspriechend `compare_exchange` mat der folgender Mapping fir Gedächtnisbestellungen:
    ///
    /// Original |Erfolleg |Feeler
    /// -------- | ------- | -------
    /// Relax |Relax |Relax Erfaassen |Kaaft |Fräisetzung kréien |Fräisetzung |Relaxéiert AcqRel |AcqRel |Kaaft SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` ass erlaabt falsch ze versoen och wann de Verglach geléngt, wat dem Compiler erlaabt e bessere Montage Code ze generéieren wann de Verglach an de Swap an enger Loop benotzt gëtt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Späichert e Wäert an de Zeiger wann den aktuelle Wäert d'selwecht ass wéi den `current` Wäert.
    ///
    /// De Retourwäert ass e Resultat dat weist ob den neie Wäert geschriwwe gouf an dee virege Wäert enthält.
    /// Beim Erfolleg ass dëse Wäert garantéiert gläich wéi `current`.
    ///
    /// `compare_exchange` hëlt zwee [`Ordering`] Argumenter fir d'Erënnerungsuerdnung vun dëser Operatioun ze beschreiwen.
    /// `success` beschreift déi erfuerderlech Bestellung fir d'Lies-Modify-Write Operatioun déi stattfënnt wann de Verglach mam `current` geléngt.
    /// `failure` beschreift déi erfuerderlech Bestellung fir d'Belaaschtungsoperatioun déi stattfënnt wann de Verglach fällt.
    /// Benotzt [`Acquire`] als Erfollegsbestellung mécht de Buttek Deel vun dëser Operatioun [`Relaxed`], a benotzt [`Release`] mécht déi erfollegräich Laascht [`Relaxed`].
    ///
    /// D'Fehlbestellung kann nëmme [`SeqCst`], [`Acquire`] oder [`Relaxed`] sinn a muss gläichwäerteg sinn oder méi schwaach sinn wéi d'Erfollegsbestellung.
    ///
    /// **Note:** Dës Method ass nëmme verfügbar op Plattformen déi atomesch Operatiounen op Zeigner ënnerstëtzen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SIKKERHET: Datenrennen gi vun der atomarer Intrinsik verhënnert.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Späichert e Wäert an de Zeiger wann den aktuelle Wäert d'selwecht ass wéi den `current` Wäert.
    ///
    /// Am Géigesaz zu [`AtomicPtr::compare_exchange`] ass dës Funktioun erlaabt falsch ze versoen och wann de Verglach geléngt, wat zu méi effiziente Code op e puer Plattforme féiere kann.
    ///
    /// De Retourwäert ass e Resultat dat weist ob den neie Wäert geschriwwe gouf an dee virege Wäert enthält.
    ///
    /// `compare_exchange_weak` hëlt zwee [`Ordering`] Argumenter fir d'Erënnerungsuerdnung vun dëser Operatioun ze beschreiwen.
    /// `success` beschreift déi erfuerderlech Bestellung fir d'Lies-Modify-Write Operatioun déi stattfënnt wann de Verglach mam `current` geléngt.
    /// `failure` beschreift déi erfuerderlech Bestellung fir d'Belaaschtungsoperatioun déi stattfënnt wann de Verglach fällt.
    /// Benotzt [`Acquire`] als Erfollegsbestellung mécht de Buttek Deel vun dëser Operatioun [`Relaxed`], a benotzt [`Release`] mécht déi erfollegräich Laascht [`Relaxed`].
    /// D'Fehlbestellung kann nëmme [`SeqCst`], [`Acquire`] oder [`Relaxed`] sinn a muss gläichwäerteg sinn oder méi schwaach sinn wéi d'Erfollegsbestellung.
    ///
    /// **Note:** Dës Method ass nëmme verfügbar op Plattformen déi atomesch Operatiounen op Zeigner ënnerstëtzen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SAFETY: Dës intrinsesch ass onsécher well se op engem rauem Zeiger funktionnéiert
        // awer mir wësse sécher datt de Zeiger gëlteg ass (mir hunn et just vun engem `UnsafeCell` kritt dee mir duerch Referenz hunn) an déi atomesch Operatioun selwer erlaabt eis den `UnsafeCell` Inhalt sécher ze mutéieren.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Hëlt de Wäert, a benotzt eng Funktioun drop, déi en optionale neie Wäert zréckbréngt.Nees en `Result` vun `Ok(previous_value)` wann d'Funktioun `Some(_)` zréckgeet, soss `Err(previous_value)`.
    ///
    /// Note: Dëst kann d'Funktioun méi oft nennen wann de Wäert an der Tëschenzäit vun anere Fäegkeete geännert gouf, soulaang d'Funktioun `Some(_)` zréckkënnt, awer d'Funktioun nëmmen eemol op de gespäicherte Wäert applizéiert gouf.
    ///
    ///
    /// `fetch_update` hëlt zwee [`Ordering`] Argumenter fir d'Erënnerungsuerdnung vun dëser Operatioun ze beschreiwen.
    /// Déi éischt beschreift déi erfuerderlech Bestellung fir wann d'Operatioun endlech erfollegräich ass, an déi zweet beschreift déi erfuerderlech Bestellung fir Laaschten.
    /// Dës entspriechen den Erfollegs-an Ausfallbestellunge vun [`AtomicPtr::compare_exchange`] respektiv.
    ///
    /// Benotzt [`Acquire`] als Erfollegsbestellung mécht de Buttek Deel vun dëser Operatioun [`Relaxed`], a benotzt [`Release`] mécht déi lescht erfollegräich Luede [`Relaxed`].
    /// D (failed) Laaschtbestellung kann nëmme [`SeqCst`], [`Acquire`] oder [`Relaxed`] sinn a muss gläichwäerteg sinn oder méi schwaach sinn wéi d'Erfollegsbestellung.
    ///
    /// **Note:** Dës Method ass nëmme verfügbar op Plattformen déi atomesch Operatiounen op Zeigner ënnerstëtzen.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Konvertéiert en `bool` an en `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Dëse Makro gëtt op e puer Architekturen net benotzt.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// En ganz Zuelen Typ dee ka sécher tëscht Themen gedeelt ginn.
        ///
        /// Dësen Typ huet déiselwecht In-Memory Representatioun wéi de Basisdaten ganz Zuelen, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// Fir méi iwwer d'Differenzen tëscht Atomtypen an Net-Atomtypen souwéi Informatioun iwwer d'Portabilitéit vun dësem Typ, kuckt w.e.g. [module-level documentation].
        ///
        ///
        /// **Note:** Dësen Typ ass nëmme verfügbar op Plattformen déi atomar Laaschten a Geschäfter vun [`ënnerstëtzen
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Eng atomesch ganz Zuel initialiséiert op `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Schécken ass implizit ëmgesat.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Erstellt eng nei atomarer ganz Zuel.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Gitt eng mutéierbar Referenz zu der Basis vun der ganzer Zuel.
            ///
            /// Dëst ass sécher, well déi mutabel Referenz garantéiert datt keng aner Fäegkeete gläichzäiteg op d'Atomdaten zougräifen.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// looss mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (e puer_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - déi mutabel Referenz garantéiert eenzegaarteg Besëtz.
                //  - d'Ausriichtung vun `$int_type` an `Self` ass d'selwecht, wéi versprach vum $cfg_align an uewe verifizéiert.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Verbraucht d'Atom a bréngt de enthale Wäert zréck.
            ///
            /// Dëst ass sécher, well de `self` duerch de Wäert weiderginn, garantéiert datt keng aner Fäegkeete gläichzäiteg op d'Atomdaten zougräifen.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Luet e Wäert vun der atomarer ganzer.
            ///
            /// `load` hëlt en [`Ordering`] Argument wat d'Erënnerungsuerdnung vun dëser Operatioun beschreift.
            /// Méiglech Wäerter sinn [`SeqCst`], [`Acquire`] an [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics wann `order` [`Release`] oder [`AcqRel`] ass.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // SIKKERHET: Datenrennen gi vun der atomarer Intrinsik verhënnert.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Späichert e Wäert an déi atomar ganz Zuel.
            ///
            /// `store` hëlt en [`Ordering`] Argument wat d'Erënnerungsuerdnung vun dëser Operatioun beschreift.
            ///  Méiglech Wäerter sinn [`SeqCst`], [`Release`] an [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics wann `order` [`Acquire`] oder [`AcqRel`] ass.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // SIKKERHET: Datenrennen gi vun der atomarer Intrinsik verhënnert.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Späichert e Wäert an déi atomar ganz Zuel, zréck de fréiere Wäert zréck.
            ///
            /// `swap` hëlt en [`Ordering`] Argument wat d'Erënnerungsuerdnung vun dëser Operatioun beschreift.All Bestellmodi si méiglech.
            /// Bedenkt datt d'Benotzung [`Acquire`] de Buttek Deel vun dëser Operatioun [`Relaxed`] mécht, a benotzt [`Release`] mécht de Laascht Deel [`Relaxed`].
            ///
            ///
            /// **Notiz**: Dës Method ass nëmme verfügbar op Plattformen déi atomesch Operatiounen ënnerstëtzen
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIKKERHET: Datenrennen gi vun der atomarer Intrinsik verhënnert.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Späichert e Wäert an déi atomar ganz Zuel wann den aktuelle Wäert d'selwecht ass wéi den `current` Wäert.
            ///
            /// De Retourwäert ass ëmmer de fréiere Wäert.Wann et gläich wéi `current` ass, da gouf de Wäert aktualiséiert.
            ///
            /// `compare_and_swap` hëlt och en [`Ordering`] Argument wat d'Erënnerungsuerdnung vun dëser Operatioun beschreift.
            /// Bedenkt datt och wann Dir [`AcqRel`] benotzt, kann d'Operatioun ausfalen an dofir just eng `Acquire` Laascht ausféieren, awer net `Release` Semantik.
            ///
            /// Benotzung vun [`Acquire`] mécht de Buttek Deel vun dëser Operatioun [`Relaxed`] wann et geschitt, a benotzt [`Release`] mécht de Laascht Deel [`Relaxed`].
            ///
            /// **Notiz**: Dës Method ass nëmme verfügbar op Plattformen déi atomesch Operatiounen ënnerstëtzen
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Migréieren op `compare_exchange` an `compare_exchange_weak`
            ///
            /// `compare_and_swap` ass entspriechend `compare_exchange` mat der folgender Mapping fir Gedächtnisbestellungen:
            ///
            /// Original |Erfolleg |Feeler
            /// -------- | ------- | -------
            /// Relax |Relax |Relax Erfaassen |Kaaft |Fräisetzung kréien |Fräisetzung |Relaxéiert AcqRel |AcqRel |Kaaft SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` ass erlaabt falsch ze versoen och wann de Verglach geléngt, wat dem Compiler erlaabt e bessere Montage Code ze generéieren wann de Verglach an de Swap an enger Loop benotzt gëtt.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Späichert e Wäert an déi atomar ganz Zuel wann den aktuelle Wäert d'selwecht ass wéi den `current` Wäert.
            ///
            /// De Retourwäert ass e Resultat dat weist ob den neie Wäert geschriwwe gouf an dee virege Wäert enthält.
            /// Beim Erfolleg ass dëse Wäert garantéiert gläich wéi `current`.
            ///
            /// `compare_exchange` hëlt zwee [`Ordering`] Argumenter fir d'Erënnerungsuerdnung vun dëser Operatioun ze beschreiwen.
            /// `success` beschreift déi erfuerderlech Bestellung fir d'Lies-Modify-Write Operatioun déi stattfënnt wann de Verglach mam `current` geléngt.
            /// `failure` beschreift déi erfuerderlech Bestellung fir d'Belaaschtungsoperatioun déi stattfënnt wann de Verglach fällt.
            /// Benotzt [`Acquire`] als Erfollegsbestellung mécht de Buttek Deel vun dëser Operatioun [`Relaxed`], a benotzt [`Release`] mécht déi erfollegräich Laascht [`Relaxed`].
            ///
            /// D'Fehlbestellung kann nëmme [`SeqCst`], [`Acquire`] oder [`Relaxed`] sinn a muss gläichwäerteg sinn oder méi schwaach sinn wéi d'Erfollegsbestellung.
            ///
            /// **Notiz**: Dës Method ass nëmme verfügbar op Plattformen déi atomesch Operatiounen ënnerstëtzen
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // SIKKERHET: Datenrennen gi vun der atomarer Intrinsik verhënnert.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Späichert e Wäert an déi atomar ganz Zuel wann den aktuelle Wäert d'selwecht ass wéi den `current` Wäert.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// dës Funktioun ass erlaabt falsch ze versoen och wann de Verglach geléngt, wat zu méi effizienten Code op e puer Plattformen resultéiere kann.
            /// De Retourwäert ass e Resultat dat weist ob den neie Wäert geschriwwe gouf an dee virege Wäert enthält.
            ///
            /// `compare_exchange_weak` hëlt zwee [`Ordering`] Argumenter fir d'Erënnerungsuerdnung vun dëser Operatioun ze beschreiwen.
            /// `success` beschreift déi erfuerderlech Bestellung fir d'Lies-Modify-Write Operatioun déi stattfënnt wann de Verglach mam `current` geléngt.
            /// `failure` beschreift déi erfuerderlech Bestellung fir d'Belaaschtungsoperatioun déi stattfënnt wann de Verglach fällt.
            /// Benotzt [`Acquire`] als Erfollegsbestellung mécht de Buttek Deel vun dëser Operatioun [`Relaxed`], a benotzt [`Release`] mécht déi erfollegräich Laascht [`Relaxed`].
            ///
            /// D'Fehlbestellung kann nëmme [`SeqCst`], [`Acquire`] oder [`Relaxed`] sinn a muss gläichwäerteg sinn oder méi schwaach sinn wéi d'Erfollegsbestellung.
            ///
            /// **Notiz**: Dës Method ass nëmme verfügbar op Plattformen déi atomesch Operatiounen ënnerstëtzen
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// looss mut alt= val.load(Ordering::Relaxed);
            /// Loop {loosst nei=al * 2;
            ///     Match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // SIKKERHET: Datenrennen gi vun der atomarer Intrinsik verhënnert.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Füügt zum aktuelle Wäert bäi, gëtt de fréiere Wäert zréck.
            ///
            /// Dës Operatioun wéckelt sech um Iwwerlaf.
            ///
            /// `fetch_add` hëlt en [`Ordering`] Argument wat d'Erënnerungsuerdnung vun dëser Operatioun beschreift.All Bestellmodi si méiglech.
            /// Bedenkt datt d'Benotzung [`Acquire`] de Buttek Deel vun dëser Operatioun [`Relaxed`] mécht, a benotzt [`Release`] mécht de Laascht Deel [`Relaxed`].
            ///
            ///
            /// **Notiz**: Dës Method ass nëmme verfügbar op Plattformen déi atomesch Operatiounen ënnerstëtzen
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIKKERHET: Datenrennen gi vun der atomarer Intrinsik verhënnert.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Subtraktéiert vum aktuelle Wäert, andeems de fréiere Wäert zréckgeet.
            ///
            /// Dës Operatioun wéckelt sech um Iwwerlaf.
            ///
            /// `fetch_sub` hëlt en [`Ordering`] Argument wat d'Erënnerungsuerdnung vun dëser Operatioun beschreift.All Bestellmodi si méiglech.
            /// Bedenkt datt d'Benotzung [`Acquire`] de Buttek Deel vun dëser Operatioun [`Relaxed`] mécht, a benotzt [`Release`] mécht de Laascht Deel [`Relaxed`].
            ///
            ///
            /// **Notiz**: Dës Method ass nëmme verfügbar op Plattformen déi atomesch Operatiounen ënnerstëtzen
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIKKERHET: Datenrennen gi vun der atomarer Intrinsik verhënnert.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitwise "and" mam aktuelle Wäert.
            ///
            /// Féiert eng bitzeg "and" Operatioun op den aktuelle Wäert an d'Argument `val`, a setzt den neie Wäert op d'Resultat.
            ///
            /// Nees de fréiere Wäert.
            ///
            /// `fetch_and` hëlt en [`Ordering`] Argument wat d'Erënnerungsuerdnung vun dëser Operatioun beschreift.All Bestellmodi si méiglech.
            /// Bedenkt datt d'Benotzung [`Acquire`] de Buttek Deel vun dëser Operatioun [`Relaxed`] mécht, a benotzt [`Release`] mécht de Laascht Deel [`Relaxed`].
            ///
            ///
            /// **Notiz**: Dës Method ass nëmme verfügbar op Plattformen déi atomesch Operatiounen ënnerstëtzen
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIKKERHET: Datenrennen gi vun der atomarer Intrinsik verhënnert.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitwise "nand" mam aktuelle Wäert.
            ///
            /// Féiert eng bitzeg "nand" Operatioun op den aktuelle Wäert an d'Argument `val`, a setzt den neie Wäert op d'Resultat.
            ///
            /// Nees de fréiere Wäert.
            ///
            /// `fetch_nand` hëlt en [`Ordering`] Argument wat d'Erënnerungsuerdnung vun dëser Operatioun beschreift.All Bestellmodi si méiglech.
            /// Bedenkt datt d'Benotzung [`Acquire`] de Buttek Deel vun dëser Operatioun [`Relaxed`] mécht, a benotzt [`Release`] mécht de Laascht Deel [`Relaxed`].
            ///
            ///
            /// **Notiz**: Dës Method ass nëmme verfügbar op Plattformen déi atomesch Operatiounen ënnerstëtzen
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIKKERHET: Datenrennen gi vun der atomarer Intrinsik verhënnert.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitwise "or" mam aktuelle Wäert.
            ///
            /// Féiert eng bitzeg "or" Operatioun op den aktuelle Wäert an d'Argument `val`, a setzt den neie Wäert op d'Resultat.
            ///
            /// Nees de fréiere Wäert.
            ///
            /// `fetch_or` hëlt en [`Ordering`] Argument wat d'Erënnerungsuerdnung vun dëser Operatioun beschreift.All Bestellmodi si méiglech.
            /// Bedenkt datt d'Benotzung [`Acquire`] de Buttek Deel vun dëser Operatioun [`Relaxed`] mécht, a benotzt [`Release`] mécht de Laascht Deel [`Relaxed`].
            ///
            ///
            /// **Notiz**: Dës Method ass nëmme verfügbar op Plattformen déi atomesch Operatiounen ënnerstëtzen
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIKKERHET: Datenrennen gi vun der atomarer Intrinsik verhënnert.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise "xor" mam aktuelle Wäert.
            ///
            /// Féiert eng bitzeg "xor" Operatioun op den aktuelle Wäert an d'Argument `val`, a setzt den neie Wäert op d'Resultat.
            ///
            /// Nees de fréiere Wäert.
            ///
            /// `fetch_xor` hëlt en [`Ordering`] Argument wat d'Erënnerungsuerdnung vun dëser Operatioun beschreift.All Bestellmodi si méiglech.
            /// Bedenkt datt d'Benotzung [`Acquire`] de Buttek Deel vun dëser Operatioun [`Relaxed`] mécht, a benotzt [`Release`] mécht de Laascht Deel [`Relaxed`].
            ///
            ///
            /// **Notiz**: Dës Method ass nëmme verfügbar op Plattformen déi atomesch Operatiounen ënnerstëtzen
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIKKERHET: Datenrennen gi vun der atomarer Intrinsik verhënnert.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Hëlt de Wäert, a benotzt eng Funktioun drop, déi en optionale neie Wäert zréckbréngt.Nees en `Result` vun `Ok(previous_value)` wann d'Funktioun `Some(_)` zréckgeet, soss `Err(previous_value)`.
            ///
            /// Note: Dëst kann d'Funktioun méi oft nennen wann de Wäert an der Tëschenzäit vun anere Fäegkeete geännert gouf, soulaang d'Funktioun `Some(_)` zréckkënnt, awer d'Funktioun nëmmen eemol op de gespäicherte Wäert applizéiert gouf.
            ///
            ///
            /// `fetch_update` hëlt zwee [`Ordering`] Argumenter fir d'Erënnerungsuerdnung vun dëser Operatioun ze beschreiwen.
            /// Déi éischt beschreift déi erfuerderlech Bestellung fir wann d'Operatioun endlech erfollegräich ass, an déi zweet beschreift déi erfuerderlech Bestellung fir Laaschten.Dës entspriechen den Erfollegs-an Ausfallsbestellunge vun
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Benotzt [`Acquire`] als Erfollegsbestellung mécht de Buttek Deel vun dëser Operatioun [`Relaxed`], a benotzt [`Release`] mécht déi lescht erfollegräich Luede [`Relaxed`].
            /// D (failed) Laaschtbestellung kann nëmme [`SeqCst`], [`Acquire`] oder [`Relaxed`] sinn a muss gläichwäerteg sinn oder méi schwaach sinn wéi d'Erfollegsbestellung.
            ///
            /// **Notiz**: Dës Method ass nëmme verfügbar op Plattformen déi atomesch Operatiounen ënnerstëtzen
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Bestellung: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Bestellung: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Maximum mam aktuelle Wäert.
            ///
            /// Fannt de Maximum vum aktuelle Wäert an d'Argument `val`, a setzt den neie Wäert op d'Resultat.
            ///
            /// Nees de fréiere Wäert.
            ///
            /// `fetch_max` hëlt en [`Ordering`] Argument wat d'Erënnerungsuerdnung vun dëser Operatioun beschreift.All Bestellmodi si méiglech.
            /// Bedenkt datt d'Benotzung [`Acquire`] de Buttek Deel vun dëser Operatioun [`Relaxed`] mécht, a benotzt [`Release`] mécht de Laascht Deel [`Relaxed`].
            ///
            ///
            /// **Notiz**: Dës Method ass nëmme verfügbar op Plattformen déi atomesch Operatiounen ënnerstëtzen
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// lass Bar=42;
            /// loosst max_foo=foo.fetch_max (Bar, Ordering::SeqCst).max(bar);
            /// behaapten! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIKKERHET: Datenrennen gi vun der atomarer Intrinsik verhënnert.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Minimum mam aktuelle Wäert.
            ///
            /// Fannt de Minimum vum aktuelle Wäert an d'Argument `val`, a setzt den neie Wäert op d'Resultat.
            ///
            /// Nees de fréiere Wäert.
            ///
            /// `fetch_min` hëlt en [`Ordering`] Argument wat d'Erënnerungsuerdnung vun dëser Operatioun beschreift.All Bestellmodi si méiglech.
            /// Bedenkt datt d'Benotzung [`Acquire`] de Buttek Deel vun dëser Operatioun [`Relaxed`] mécht, a benotzt [`Release`] mécht de Laascht Deel [`Relaxed`].
            ///
            ///
            /// **Notiz**: Dës Method ass nëmme verfügbar op Plattformen déi atomesch Operatiounen ënnerstëtzen
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// lass Bar=12;
            /// loosst min_foo=foo.fetch_min (Bar, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIKKERHET: Datenrennen gi vun der atomarer Intrinsik verhënnert.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Gitt e mutabelen Zeiger op déi ënnerlännesch ganz Zuel.
            ///
            /// Net-atomesch Liesen a Schreiwe maachen op déi resultéierend ganz Zuel kann eng Datecourse sinn.
            /// Dës Method ass meeschtens nëtzlech fir FFI, wou d'Funktiounsënnerschrëft ka benotzen
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// En `*mut` Zeiger zréckzebréngen vun enger gemeinsamer Referenz zu dësem Atom ass sécher, well d'Atomtypen mat bannener Verännerlechkeet schaffen.
            /// All Modifikatioune vun engem Atom änneren de Wäert duerch eng gemeinsam Referenz, a kënne sou sécher maachen soulaang se atomesch Operatiounen benotzen.
            /// All Benotzung vum zréckgekéierte rouden Zeiger erfuerdert en `unsafe` Block a muss nach ëmmer déiselwecht Restriktioun oprecht halen: Operatiounen drop musse atomesch sinn.
            ///
            ///
            /// # Examples
            ///
            /// "ignoréieren (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// extern "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // SAFETY: Sécher soulaang `my_atomic_op` atomesch ass.
            /// onsécher {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // SAFETY: den Uruff muss de Sécherheetsvertrag fir `atomic_store` oprechterhalen.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // SAFETY: den Uruff muss de Sécherheetsvertrag fir `atomic_load` oprechterhalen.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: den Uruff muss de Sécherheetsvertrag fir `atomic_swap` oprechterhalen.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Gitt de fréiere Wäert zréck (wéi __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: den Uruff muss de Sécherheetsvertrag fir `atomic_add` oprechterhalen.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Gitt de fréiere Wäert zréck (wéi __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: den Uruff muss de Sécherheetsvertrag fir `atomic_sub` oprechterhalen.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SAFETY: den Uruff muss de Sécherheetsvertrag fir `atomic_compare_exchange` oprechterhalen.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SAFETY: den Uruff muss de Sécherheetsvertrag fir `atomic_compare_exchange_weak` oprechterhalen.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: den Uruff muss de Sécherheetsvertrag fir `atomic_and` oprechterhalen
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: den Uruff muss de Sécherheetsvertrag fir `atomic_nand` oprechterhalen
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: den Uruff muss de Sécherheetsvertrag fir `atomic_or` oprechterhalen
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: den Uruff muss de Sécherheetsvertrag fir `atomic_xor` oprechterhalen
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// bréngt de maximale Wäert zréck (ënnerschriwwe Verglach)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: den Uruff muss de Sécherheetsvertrag fir `atomic_max` oprechterhalen
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// bréngt de Min Wäert zréck (ënnerschriwwe Verglach)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: den Uruff muss de Sécherheetsvertrag fir `atomic_min` oprechterhalen
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// bréngt de maximale Wäert zréck (net ënnerschriwwe Verglach)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: den Uruff muss de Sécherheetsvertrag fir `atomic_umax` oprechterhalen
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// bréngt de Min Wäert zréck (net ënnerschriwwe Verglach)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: den Uruff muss de Sécherheetsvertrag fir `atomic_umin` oprechterhalen
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// En Atomzaang.
///
/// Ofhängeg vun der spezifizéierter Uerdnung verhënnert e Fence de Compiler an de CPU aus verschidden Aarte vu Gedächtnisoperatiounen ronderëm ze bestellen.
/// Dat kreéiert synchroniséiert-mat Bezéiungen tëscht et an atomarer Operatiounen oder Zaiten an anere Fiedem.
///
/// E Zonk 'A' deen (op d'mannst) [`Release`] Semantik huet, synchroniséiert mat engem Zonk 'B' mat (op d'mannst) [`Acquire`] Semantik, wann an nëmmen wann et Operatiounen X an Y gëtt, déi allen op engem atomeschen Objet 'M' funktionnéieren sou datt A virgezunn ass X, Y gëtt synchroniséiert virum B an Y observéiert d'Ännerung op M.
/// Dëst bitt eng ofhängeg Ofhängegkeet tëscht A a B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Atomesch Operatiounen mat [`Release`] oder [`Acquire`] Semantik kënnen och mat engem Zonk synchroniséieren.
///
/// E Fechter deen d [`SeqCst`] Bestellung huet, zousätzlech zu der [`Acquire`] an der [`Release`] Semantik, bedeelegt sech un der globaler Programmuerdnung vun den aneren [`SeqCst`] Operatiounen an/oder Zaiten.
///
/// Akzeptéiert [`Acquire`], [`Release`], [`AcqRel`] an [`SeqCst`] Bestellungen.
///
/// # Panics
///
/// Panics wann `order` [`Relaxed`] ass.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Eng géigesäiteg Ausgrenzung primitiv baséiert op Spinlock.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Waart bis den ale Wäert `false` ass.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Dëse Fence synchroniséiert-mat Geschäft an `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // SIKKERHET: mat engem atomesche Fechter ass sécher.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// E Compiler Memory Fence.
///
/// `compiler_fence` emittéiert kee Maschinncode, awer beschränkt d'Arte vun der Erënnerung, déi de Compiler nei bestellt, erlaabt ass.Spezifesch, ofhängeg vun der gegebene [`Ordering`] Semantik, kann de Compiler net erlaabt ze liesen oder ze schreiwe vu vir oder nom Ruff op déi aner Säit vum Uruff op `compiler_fence`.Bedenkt datt et **net** verhënnert datt *Hardware* sou Re-Ordering mécht.
///
/// Dëst ass net e Problem an engem eenzege Fuedem, Ausféierungskontext, awer wann aner Fäegkeete gläichzäiteg Gedächtnis ännere kënnen, gi méi staark Synchroniséierungsprimitiven wéi [`fence`] erfuerderlech.
///
/// D'Ëmbestellung verhënnert duerch déi verschidde Bestellungssemantik sinn:
///
///  - mat [`SeqCst`] ass keng Neibestellung vu Liesen a Schreiwe iwwer dëse Punkt erlaabt.
///  - mat [`Release`], viregt Liesen a Schreiwe kënnen net laanscht déi nächst Schreiwe geréckelt ginn.
///  - mat [`Acquire`], uschléissend Liesungen a Schreiwe kënnen net viru virege Liesunge geréckelt ginn.
///  - mat [`AcqRel`] gi béid uewe genannte Regelen duerchgesat.
///
/// `compiler_fence` ass normalerweis nëmmen nëtzlech fir ze verhënneren datt e Fuedem mat sech selwer *leeft*.Dat ass, wann e gegebene Fuedem e Code Code ausféiert, a gëtt dann ënnerbrach, a fänkt Code anzwuesch auszeféieren (wärend nach ëmmer am selwechte Fuedem, a konzeptuell nach ëmmer am selwechte Kär).An traditionelle Programmer kann dëst nëmme geschéien wann e Signalhändler registréiert ass.
/// A méi nidderegen Code kënnen esou Situatiounen och entstoen wann Dir Ënnerbriechungen handelt, wann Dir gréng Fiedem mat Virdeelung implementéiert, asw.
/// Virwëtzeg Lieser ginn encouragéiert d'Diskussioun vum Linux Kernel iwwer [memory barriers] ze liesen.
///
/// # Panics
///
/// Panics wann `order` [`Relaxed`] ass.
///
/// # Examples
///
/// Ouni `compiler_fence` ass den `assert_eq!` am folgende Code *net* garantéiert ze erfollegen, trotz alles an engem eenzege Fuedem geschitt.
/// Fir ze kucken firwat, erënnert datt de Compiler gratis ass d'Geschäfter op `IMPORTANT_VARIABLE` an `IS_READ` ze wiesselen well se allebéid `Ordering::Relaxed` sinn.Wann et et mécht, an de Signalhändler direkt no der Aktualiséierung vum `IS_READY` opgeruff gëtt, da gesäit de Signalhändler `IS_READY=1`, awer `IMPORTANT_VARIABLE=0`.
/// Mat engem `compiler_fence` remedéiert dës Situatioun.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // verhënneren datt fréier Schreiwe méi wäit wéi dëse Punkt geréckelt ginn
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // SIKKERHET: mat engem atomesche Fechter ass sécher.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Signaliséiert de Prozessor datt et an enger beschäftegter Waart Spin-Loop ("Spin Lock") ass.
///
/// Dës Funktioun gëtt zugonschte vun [`hint::spin_loop`] ofgeleent.
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}