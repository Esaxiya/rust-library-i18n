use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Dëst ass net stabil Uewerfläch, awer hëlleft `?` bëlleg tëscht hinnen ze halen, och wann LLVM net ëmmer dovu profitéiere kann.
    //
    // (Leider sinn d'Resultat an d'Optioun net konsequent, sou datt ControlFlow net mat deenen zwee passen.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}