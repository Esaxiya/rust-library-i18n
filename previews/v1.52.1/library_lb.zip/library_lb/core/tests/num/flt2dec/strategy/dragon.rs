use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri ass ze lues
fn exact_sanity_test() {
    // Dësen Test leeft um Enn wat ech nëmmen unhuelen ass e Corner-ish Fall vun der `exp2` Bibliothéiksfunktioun, definéiert an egal wéi enger C Runtime déi mir benotzen.
    // Am VS 2013 hat dës Funktioun anscheinend e Feeler well dësen Test net klappt wann e verlinkt ass, awer mat VS 2015 schéngt de Feeler fix wéi den Test just gutt leeft.
    //
    // De Käfer schéngt en Ënnerscheed am Retourwäert vun `exp2(-1057)` ze sinn, wou am VS 2013 en Duebel mat dem Bitmuster 0x2 zréckgeet an am VS 2015 nees 0x20000.
    //
    //
    // Fir elo just dësen Test ganz op MSVC ignoréieren well et souwisou soss getest gëtt a mir sinn net super interesséiert d exp2 Implementatioun vun all Plattform ze testen.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}