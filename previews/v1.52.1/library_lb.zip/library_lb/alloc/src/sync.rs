#![stable(feature = "rust1", since = "1.0.0")]

//! Fuedersécher Referenzzuelweiser.
//!
//! Kuckt d [`Arc<T>`][Arc] Dokumentatioun fir méi Detailer.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Eng mëll Limit fir de Betrag vun de Referenzen déi op en `Arc` gemaach kënne ginn.
///
/// Iwwert dës Limit ze goen wäert Äre Programm ofbriechen (awer net onbedéngt) bei _exactly_ `MAX_REFCOUNT + 1` Referenzen.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer ënnerstëtzt keng Gedächtnisdicher.
// Fir falsch positiv Berichter an Arc/Weak Implementatioun ze vermeiden benotzt Dir Atomlasten fir Synchroniséierung amplaz.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// E thread-séchere Referenz zielen Zeiger.'Arc' steet fir 'Atomically Reference Counted'.
///
/// Den Typ `Arc<T>` bitt e gemeinsame Besëtz vun engem Wäert vum Typ `T`, zougewisen am Koup.Opruffen [`clone`][clone] op `Arc` produzéiert eng nei `Arc` Instanz, déi op déiselwecht Bewëllegung op de Koup weist wéi d'Quell `Arc`, wärend e Referenzzuel erhéicht gëtt.
/// Wann de leschten `Arc` Zeiger zu enger bestëmmter Bewëllegung zerstéiert gëtt, gëtt de Wäert an der Bewëllegung (dacks als "inner value" bezeechent) och fale gelooss.
///
/// Gedeelt Referenzen an Rust verbidden d'Mutatioun als Standard, an `Arc` ass keng Ausnahm: Dir kënnt normalerweis net eng mutéierbar Referenz op eppes an engem `Arc` kréien.Wann Dir duerch en `Arc` mutéiere musst, benotzt [`Mutex`][mutex], [`RwLock`][rwlock] oder ee vun den [`Atomic`][atomic] Typen.
///
/// ## Fuedem Sécherheet
///
/// Am Géigesaz zu [`Rc<T>`] benotzt `Arc<T>` atomesch Operatiounen fir seng Referenzzählung.Dëst bedeit datt et thread-sécher ass.De Nodeel ass datt atomesch Operatiounen méi deier si wéi gewéinlech Erënnerung Zougang.Wann Dir keng Referenz gezielt Allocatiounen tëscht Themen deelt, betruecht [`Rc<T>`] fir méi niddereg Overhead ze benotzen.
/// [`Rc<T>`] ass e séchere Standard, well de Compiler fënnt all Versuch en [`Rc<T>`] tëscht Themen ze schécken.
/// Wéi och ëmmer, eng Bibliothéik kéint `Arc<T>` wielen fir Bibliothéik Konsumenten méi Flexibilitéit ze ginn.
///
/// `Arc<T>` wäert [`Send`] an [`Sync`] implementéieren soulaang d `T` [`Send`] an [`Sync`] implementéiert.
/// Firwat kënnt Dir en net-thread-sécheren Typ `T` an en `Arc<T>` setzen, fir en thread-safe ze maachen?Dëst kann ufanks e bësse kontra-intuitiv sinn: schliisslech ass net de Punkt vun der `Arc<T>` Fuedem Sécherheet?De Schlëssel ass dëst: `Arc<T>` mécht et thread sécher e puer Eegentum vun de selwechten Daten ze hunn, awer et füügt d'Sécherheetssécherheet net zu sengen Daten bäi.
///
/// Betruecht `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] ass net [`Sync`], a wann `Arc<T>` ëmmer [`Send`] war, `Arc <` [`RefCell<T>`]`>`wier och.
/// Awer dann hätte mer e Problem:
/// [`RefCell<T>`] ass net thread sécher;et verfollegt de Prêtzuel mat net-atomarer Operatiounen.
///
/// Am Endeffekt heescht dat datt Dir `Arc<T>` mat enger Zort [`std::sync`]-Typ, normalerweis [`Mutex<T>`][mutex], braucht ze koppelen.
///
/// ## Breaking Cycles mat `Weak`
///
/// D [`downgrade`][downgrade] Method kann benotzt ginn fir en net eegene [`Weak`] Zeiger ze kreéieren.En [`Weak`] Zeiger kann [`Upgrade`][Upgrade] d op en `Arc` sinn, awer dëst wäert [`None`] zréckginn, wann de Wäert, deen an der Bewëllegung gespäichert gouf, scho fale gelooss gouf.
/// An anere Wierder, `Weak` Zeigefanger halen de Wäert net an der Bewëllegung lieweg;awer, se *halen* d'Allocatioun (de Backing Store fir de Wäert) lieweg.
///
/// En Zyklus tëscht `Arc` Zeigefanger gëtt ni Deallokaliséiert.
/// Aus dësem Grond gëtt [`Weak`] benotzt fir Zyklen ze briechen.Zum Beispill kéint e Bam staark `Arc` Zeigefanger vun Elterenknäpp fir Kanner hunn, an [`Weak`] Zeigefanger vu Kanner zréck bei hir Elteren.
///
/// # Klonen Referenzen
///
/// Erstelle vun enger neier Referenz vun engem existente Referenz gezielt Zeiger gëtt mat der `Clone` trait gemaach fir [`Arc<T>`][Arc] an [`Weak<T>`][Weak] implementéiert.
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Déi zwou Syntaxen hei ënnendrënner sinn gläichwäerteg.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b a foo sinn all Béi déi op déi selwecht Erënnerungsplaz hiweisen
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` automatesch Dereferenzen op `T` (iwwer den [`Deref`][deref] trait), sou datt Dir 'T' Methoden op e Wäert vum Typ `Arc<T>` nennen.Fir Nummkonflikter mat "T" Methoden ze vermeiden, sinn d'Methode vum `Arc<T>` selwer assoziéiert Funktiounen, genannt [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>D'Ëmsetzung vun traits wéi `Clone` kann och mat vollqualifizéierter Syntax genannt ginn.
/// E puer Leit benotze léiwer vollqualifizéiert Syntax, anerer benotze léiwer Method-Call Syntax.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Method-Call Syntax
/// let arc2 = arc.clone();
/// // Vollqualifizéiert Syntax
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] mécht keen Auto-Dereferenz zu `T`, well de banneschte Wäert scho fale gelooss ass.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// E puer onverännerbar Daten tëscht Fiedelen deelen:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Bedenkt datt mir **net** dës Tester hei ausféieren.
// D windows Builder gi super onglécklech wann e Fuedem den Haaptthread iwwerlieft an dann zur selwechter Zäit erausgeet (eppes Deadlocks), sou datt mir dat ganz vermeiden andeems mir dës Tester net ausféieren.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Deelen vun engem mutablen [`AtomicUsize`]:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Kuckt d [`rc` documentation][rc_examples] fir méi Beispiller fir Referenz zielen am Allgemengen.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` ass eng Versioun vun [`Arc`] déi eng net bezittend Referenz zu der verwaltter Allocatioun hält.
/// D'Allocatioun ass zougänglech andeems Dir [`upgrade`] um `Weak` Zeiger urufft, deen eng ["Option"] <<[[Arc]] "<T>>`.
///
/// Zënter enger `Weak` Referenz zielt net zum Eegentum, et wäert net verhënneren datt de Wäert, deen an der Bewëllegung gespäichert ass, fale gelooss gëtt, an `Weak` selwer mécht keng Garantien iwwer de Wäert, deen nach ëmmer do ass.
///
/// Sou kann et [`None`] zréckginn wann [`upgrade`] d.
/// Bedenkt awer datt eng `Weak` Referenz * verhënnert datt d'Allocatioun selwer (de Backing Store) ausgedeelt gëtt.
///
/// En `Weak` Zeiger ass nëtzlech fir eng temporär Referenz zu der Bewëllegung ze halen, déi vum [`Arc`] verwalt gëtt, ouni datt säi banneschte Wäert fällt.
/// Et gëtt och benotzt fir kreesfërmeg Referenzen tëscht [`Arc`] Zeigefanger ze vermeiden, well géigesäiteg Besëtzer Referenzen ni erlaben datt entweder [`Arc`] fale gelooss gëtt.
/// Zum Beispill kéint e Bam staark [`Arc`] Zeigefanger vun Elterenknäpp fir Kanner hunn, an `Weak` Zeigefanger vu Kanner zréck bei hir Elteren.
///
/// Den typesche Wee fir en `Weak` Zeiger ze kréien ass den [`Arc::downgrade`] ze ruffen.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Dëst ass en `NonNull` fir d'Gréisst vun dësem Typ an Enums ze optimiséieren, awer et ass net onbedéngt e gëltege Zeiger.
    //
    // `Weak::new` setzt dëst op `usize::MAX` sou datt et kee Raum um Koup brauch ze verdeelen.
    // Dat ass net e Wäert deen e richtege Zeiger je wäert hunn well RcBox Ausriichtung op d'mannst 2 huet.
    // Dëst ass nëmme méiglech wann `T: Sized`;unsized `T` ni bengelen.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Dëst ass repr(C) bis future-Beweis géint méiglech Felduerdnung, wat anescht sécher [into|from]_raw() vu transmutierbaren bannent Typen stéieren.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // de Wäert usize::MAX handelt als Sentinel fir temporär "locking" d'Fäegkeet fir schwaach Zeigefanger ze upgraden oder staark ze degradéieren;dëst gëtt benotzt fir Rennen an `make_mut` an `get_mut` ze vermeiden.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Baut en neien `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Start de schwaache Zeigerziel als 1 dat ass dee schwaache Zeiger deen vun all de staarken Zeigefanger (kinda) gehal gëtt, kuckt std/rc.rs fir méi Info
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Baut en neien `Arc<T>` mat enger schwaacher Referenz op sech selwer.
    /// Probéiert déi schwaach Referenz ze aktualiséieren ier dës Funktioun zréckkomm ass, gëtt zu engem `None` Wäert.
    /// Wéi och ëmmer, déi schwaach Referenz ka fräi gekloont ginn a spéider gespäichert ginn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Konstruéiert den Innen am "uninitialized" Staat mat enger eenzeger schwaacher Referenz.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Et ass wichteg datt mir de Besëtz vum schwaache Zeiger net opginn, soss kéint d'Erënnerung fräi gi wéi d `data_fn` zréck ass.
        // Wa mir wierklech d'Besëtzer weidergoe wollten, kéinte mir en zousätzleche schwaache Zeiger fir eis selwer kreéieren, awer dëst géif zu zousätzlechen Aktualiséierunge vum schwaache Referenzzuel resultéieren, wat soss net néideg wier.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Elo kënne mir de banneschte Wäert initialiséieren an eis schwaach Referenz zu enger staarker Referenz maachen.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Den uewe genannten Schreiwe fir den Datefeld muss sichtbar sinn fir all Fiedem déi en net null staarke Grof beobachten.
            // Dofir brauche mir op d'mannst "Release" Bestellung fir mat der `compare_exchange_weak` am `Weak::upgrade` ze synchroniséieren.
            //
            // "Acquire" Bestellen ass net erfuerderlech.
            // Wann Dir d'méiglech Verhalen vun `data_fn` berécksiichtegt, musse mir nëmmen kucken wat et mat enger Referenz zu engem net upgradéierbaren `Weak` maache kéint:
            //
            // - Et kann den `Weak` * klonéieren, wouduerch de schwaache Referenzzuel erhéicht gëtt.
            // - Et kann dës Klone falen, de schwaache Referenzzuel erofsetzen (awer ni op Null).
            //
            // Dës Nebenwirkungen beaflossen eis op kee Fall, a keng aner Nebenwirkungen si méiglech mat séchere Code eleng.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Staark Referenze solle kollektiv eng gemeinsam schwaach Referenz besëtzen, also féiert den Destruktor net fir eis al schwaach Referenz.
        //
        mem::forget(weak);
        strong
    }

    /// Baut en neien `Arc` mat uninitialiséierten Inhalt.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Deferred Initialiséierung:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Baut en neien `Arc` mat uninitialiséierten Inhalt, mat der Erënnerung mat `0` Bytes gefëllt.
    ///
    ///
    /// Kuckt [`MaybeUninit::zeroed`][zeroed] fir Beispiller fir korrekt a falsch Benotze vun dëser Method.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Baut en neien `Pin<Arc<T>>`.
    /// Wann `T` `Unpin` net implementéiert, da gëtt `data` an der Erënnerung festgehal a kann net geréckelt ginn.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Baut en neien `Arc<T>`, gëtt e Feeler zréck wann d'Allocatioun net geet.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Start de schwaache Zeigerziel als 1 dat ass dee schwaache Zeiger deen vun all de staarken Zeigefanger (kinda) gehal gëtt, kuckt std/rc.rs fir méi Info
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Baut en neien `Arc` mat oninitialiséierten Inhalt, bréngt e Feeler zréck wann d'Allocatioun net geet.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Deferred Initialiséierung:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Baut en neien `Arc` mat net-initialiséierter Inhalter, woubäi d'Erënnerung mat `0` Bytes gefëllt gëtt, an e Feeler zréckbréngt wann d'Allocatioun net geet.
    ///
    ///
    /// Kuckt [`MaybeUninit::zeroed`][zeroed] fir Beispiller fir korrekt a falsch Benotze vun dëser Method.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Nees de banneschte Wäert, wann den `Arc` genau eng staark Referenz huet.
    ///
    /// Soss gëtt en [`Err`] mat der selwechter `Arc` zréckginn, déi eraginn ass.
    ///
    ///
    /// Dëst wäert Erfolleg och wann et aussergewéinlech schwaach Referenze sinn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Maacht e schwaache Zeiger fir déi implizit staark-schwaach Referenz ze botzen
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Baut eng nei atomesch Referenz gezielt Scheif mat net initialiséiertem Inhalt.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Deferred Initialiséierung:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Baut eng nei atomesch Referenz gezielt Scheif mat oninitialiséierten Inhalt, mat der Erënnerung mat `0` Bytes gefëllt.
    ///
    ///
    /// Kuckt [`MaybeUninit::zeroed`][zeroed] fir Beispiller fir korrekt a falsch Benotze vun dëser Method.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Konvertéiert op `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Wéi mat [`MaybeUninit::assume_init`] ass et un den Uruffer ze garantéieren datt de banneschte Wäert wierklech an engem initialiséierte Staat ass.
    ///
    /// Dëst nennen wann den Inhalt nach net komplett initialiséiert ass verursaacht direkt ondefinéiert Verhalen.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Deferred Initialiséierung:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Konvertéiert op `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Wéi mat [`MaybeUninit::assume_init`] ass et un den Uruffer ze garantéieren datt de banneschte Wäert wierklech an engem initialiséierte Staat ass.
    ///
    /// Dëst nennen wann den Inhalt nach net komplett initialiséiert ass verursaacht direkt ondefinéiert Verhalen.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Deferred Initialiséierung:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Verbraucht den `Arc`, bréngt de gewéckelte Zeiger zréck.
    ///
    /// Fir e Gedächtnissleck ze vermeiden, muss de Zeiger zréck an en `Arc` mat [`Arc::from_raw`] ëmgewandelt ginn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Bitt e roude Zeiger fir d'Daten.
    ///
    /// D'Zuelen sinn op kee Fall beaflosst an den `Arc` gëtt net verbraucht.
    /// De Zeiger ass valabel soulaang et staark Zuelen am `Arc` sinn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // SAFETY: Dëst kann net duerch Deref::deref oder RcBoxPtr::inner goen well
        // dëst ass erfuerderlech fir d raw/mut Provenz ze halen sou datt z
        // `get_mut` kann duerch de Zeiger schreiwen nodeems de Rc duerch `from_raw` erholl ass.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Baut en `Arc<T>` aus engem réiem Zeigefanger.
    ///
    /// De roude Zeiger muss virdru vun engem Uruff op [`Arc<U>::into_raw`][into_raw] zréckkoum, wou `U` déiselwecht Gréisst an Ausriichtung wéi `T` muss hunn.
    /// Dëst ass trivial richteg wann `U` `T` ass.
    /// Bedenkt datt wann `U` net `T` ass awer déiselwecht Gréisst an Ausriichtung ass, ass dat am Fong wéi Transmissioun vu Referenzen vun verschiddenen Typen.
    /// Kuckt [`mem::transmute`][transmute] fir méi Informatiounen iwwer wéi eng Restriktiounen an dësem Fall gëllen.
    ///
    /// De Benotzer vun `from_raw` muss sécher sinn datt e spezifesche Wäert vun `T` nëmmen eemol fale gelooss gëtt.
    ///
    /// Dës Funktioun ass onsécher well falsch Notzung zu Erënnerung onsécherheet féiere kann, och wann de `Arc<T>` zréck ass ni zougänglech.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Konvertéiert zréck op en `Arc` fir Leck ze vermeiden.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Weider Uriff op `Arc::from_raw(x_ptr)` wieren Memory-onsécher.
    /// }
    ///
    /// // D'Erënnerung gouf befreit wann `x` ausserhalb vum Ëmfang erausgaang ass, sou datt den `x_ptr` elo hänkt!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Ëmgedréit den Offset fir den Original ArcInner ze fannen.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Erstellt en neien [`Weak`] Zeiger fir dës Bewëllegung.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Dëst Relax ass OK well mir de Wäert am CAS hei drënner kontrolléieren.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // préift ob de schwaache Compteur aktuell "locked" ass;wann also, spin.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: dëse Code ignoréiert aktuell d'Méiglechkeet vum Iwwerlaf
            // an usize::MAX;generell musse béid RC an Arc ugepasst ginn fir mam Iwwerlaf ëmzegoen.
            //

            // Am Géigesaz zu Clone(), brauche mir dëst fir e Liesliese ze sinn fir ze synchroniséieren mat dem Schreiwe vum `is_unique`, sou datt d'Evenementer virum Schreiwen ier dës Liesung passéieren.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Passt op datt mir keen hängende Schwächt kreéieren
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Kritt d'Zuel vun [`Weak`] Zeigefanger zu dëser Bewëllegung.
    ///
    /// # Safety
    ///
    /// Dës Method u sech ass sécher, awer korrekt benotze brauch extra Betreiung.
    /// En anere Fuedem kann de schwaache Grof zu all Moment änneren, och potenziell tëscht dëser Method ze ruffen an dem Resultat ze handelen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Dës Behaaptung ass deterministesch well mir den `Arc` oder `Weak` net tëscht Themen gedeelt hunn.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Wann de schwaache Grof de Moment gespaart ass, war de Wäert vum Grof 0 just ier Dir d'Spär geholl hutt.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Kritt d'Zuel vu staarke (`Arc`) Zeigefanger fir dës Bewëllegung.
    ///
    /// # Safety
    ///
    /// Dës Method u sech ass sécher, awer korrekt benotze brauch extra Betreiung.
    /// En anere Fuedem kann de staarke Grof zu all Moment änneren, och potenziell tëscht der Opruff vun dëser Method an dem Resultat handelen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Dës Behaaptung ass deterministesch well mir den `Arc` net tëscht de Fuedem gedeelt hunn.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Inkrementéiert de staarke Referenzzuel op der `Arc<T>` verbonne mat dem verschaffene Zeiger mat engem.
    ///
    /// # Safety
    ///
    /// De Zeiger muss duerch `Arc::into_raw` kritt ginn, an déi assoziéiert `Arc` Instanz muss valabel sinn (dh
    /// de staarke Grof muss op d'mannst 1) fir d'Dauer vun dëser Method sinn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Dës Behaaptung ass deterministesch well mir den `Arc` net tëscht de Fuedem gedeelt hunn.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Arc behalen, awer beréiert net de Refcount andeems Dir an ManuallyDrop wéckelt
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Elo erhéicht de Refcount, awer fällt och net nei Refcount of
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Reduzéiert de staarke Referenzzuel op der `Arc<T>` verbonne mat dem verschaffene Zeiger mat engem.
    ///
    /// # Safety
    ///
    /// De Zeiger muss duerch `Arc::into_raw` kritt ginn, an déi assoziéiert `Arc` Instanz muss valabel sinn (dh
    /// de staarke Grof muss op d'mannst 1 sinn) wann Dir dës Method oprufft.
    /// Dës Method kann benotzt ginn fir den endgültege `Arc` a Backing Storage ze verëffentlechen, awer **sollt net** genannt ginn nodeems de finalen `Arc` erauskomm ass.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Dës Behaaptunge si deterministesch well mir den `Arc` net tëscht de Fuedem gedeelt hunn.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Dës Onsécherheet ass ok, well wa dësen Arc lieweg ass, si mir garantéiert datt de banneschten Zeiger valabel ass.
        // Ausserdeem wësse mer datt d `ArcInner` Struktur selwer `Sync` ass well déi bannent Daten och `Sync` sinn, sou datt mir ok en onverännerbaren Zeiger fir dësen Inhalt ausléinen.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Net-inlineéierten Deel vun `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Zerstéiert d'Donnéeën zu dëser Zäit, och wa mir d'Boxzouweisung selwer net befreien (et kënne nach ëmmer schwaach Uweiser leien).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Drop de schwaache Ref kollektiv vun alle staarke Referenzen
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Retour `true` wann déi zwee `Arc`s op déi selwecht Bewëllegung weisen (an engem Sënn ähnlech wéi [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Allokéiert en `ArcInner<T>` mat genuch Plaz fir e méiglecherweis net-Gréisst bannent Wäert wou de Wäert de Layout huet.
    ///
    /// D'Funktioun `mem_to_arcinner` gëtt mam Datenzeiger geruff a muss e (potenziell fettegen) Punkt fir den `ArcInner<T>` zréckginn.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Berechent Layout mat dem gegebene Wäert Layout.
        // Virdru gouf de Layout op den Ausdrock `&*(ptr as* const ArcInner<T>)` berechent, awer dëst huet eng falsch ausgeriicht Referenz erstallt (kuck #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Allokéiert en `ArcInner<T>` mat genuch Plaz fir e méiglecherweis net-Gréisst bannent Wäert, wou de Wäert de Layout zur Verfügung gestallt huet, an e Feeler zréckbréngt wann d'Allocatioun net geet.
    ///
    ///
    /// D'Funktioun `mem_to_arcinner` gëtt mam Datenzeiger geruff a muss e (potenziell fettegen) Punkt fir den `ArcInner<T>` zréckginn.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Berechent Layout mat dem gegebene Wäert Layout.
        // Virdru gouf de Layout op den Ausdrock `&*(ptr as* const ArcInner<T>)` berechent, awer dëst huet eng falsch ausgeriicht Referenz erstallt (kuck #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Initialiséiert den ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Allokéiert en `ArcInner<T>` mat genuch Plaz fir en net-grousse banneschte Wäert.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Allocéiert fir den `ArcInner<T>` mat dem gegebene Wäert.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopéiert Wäert als Bytes
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Fräi d'Allocatioun ouni hiren Inhalt erofzesetzen
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Allokéiert en `ArcInner<[T]>` mat der bestëmmter Längt.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Kopéiert Elementer aus der Scheif an nei zougewisen Arc <\[T\]>
    ///
    /// Onsécher well de Ruffer muss entweder Besëtz huelen oder `T: Copy` bannen.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Baut en `Arc<[T]>` vun engem Iterator, deen als gewësse Gréisst bekannt ass.
    ///
    /// Verhalen ass ondefinéiert sollt d'Gréisst falsch sinn.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic Bewaacher beim Klonen vun T Elementer.
        // Am Fall vun engem panic ginn Elementer déi an den neien ArcInner geschriwwe goufen erofgelooss, da gëtt d'Erënnerung fräi.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Zeigefanger op dat éischt Element
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Alles kloer.Vergiess de Garde sou datt et den neien ArcInner net fräi mécht.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Spezialisatioun trait fir `From<&[T]>` benotzt.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Maacht e Klon vum `Arc` Zeiger.
    ///
    /// Dëst erstellt en anere Zeiger zu der selwechter Bewëllegung, erhéicht de staarken Referenzzuel.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Mat enger entspaanter Uerdnung ass hei an der Rei, well Wësse vun der ursprénglecher Referenz verhënnert datt aner Fiederen den Objet falsch läschen.
        //
        // Wéi an der [Boost documentation][1] erkläert, D'Erhéijung vum Referenzkonter kann ëmmer mat Memory_order_relaxed gemaach ginn: Nei Referenzen op en Objet kënnen nëmmen aus enger existéierter Referenz geformt ginn, an eng existent Referenz vun engem Fuedem an en aneren ze weiderginn, muss schonn all néideg Synchroniséierung ubidden.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Wéi och ëmmer, mir musse géint massiv Neeszäite schützen am Fall wou een "mem: : vergiesst" Béi.
        // Wa mir dat net maachen, kann de Grof iwwerschwemmen an d'Benotzer benotze gratis no.
        // Mir sättlech op `isize::MAX` mat der Virgab datt et net ~2 Milliarde Fäegkeete sinn, déi d'Referenzzuel gläichzäiteg erhéijen.
        //
        // Dësen branch gëtt ni an engem realistesche Programm geholl.
        //
        // Mir ofbriechen well sou e Programm onheemlech degeneréiert ass, a mir egal sinn et z'ënnerstëtzen.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Maacht eng mutéierbar Referenz an de gegebene `Arc`.
    ///
    /// Wann et aner `Arc` oder [`Weak`] Zeigefanger zu der selwechter Bewëllegung gëtt, da schaaft `make_mut` eng nei Bewëllegung an rufft den [`clone`][clone] op de banneschte Wäert op fir en eenzegaartegt Eegentum ze garantéieren.
    /// Dëst gëtt och als Klon-on-Write bezeechent.
    ///
    /// Bedenkt datt dëst sech vum Verhalen vun [`Rc::make_mut`] ënnerscheet, wat all verbleiwen `Weak` Zeigneur desassociéiert.
    ///
    /// Kuckt och [`get_mut`][get_mut], wat fällt anstatt ze klonen.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Wäert näischt klonéieren
    /// let mut other_data = Arc::clone(&data); // Wäert net bannen Daten klonéieren
    /// *Arc::make_mut(&mut data) += 1;         // Klon bannen Daten
    /// *Arc::make_mut(&mut data) += 1;         // Wäert näischt klonéieren
    /// *Arc::make_mut(&mut other_data) *= 2;   // Wäert näischt klonéieren
    ///
    /// // Elo `data` an `other_data` weisen op verschidden Allocatiounen.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Bedenkt datt mir eng staark Referenz an eng schwaach Referenz hunn.
        // Also, eis staark Referenz ze verëffentlechen wäert net vum selwen d'Ursaach veruersaachen.
        //
        // Benotzt Acquire fir sécherzestellen datt mir all Schreiwe fir `weak` gesinn déi passéieren ier d'Verëffentlechung schreift (dh Dekrementer) op `strong`.
        // Well mir e schwaache Grof hunn, ass et keng Chance datt den ArcInner selwer kéint verdeelt ginn.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // En anere staarken Zeiger existéiert, also musse mir klonen.
            // Pre-allocéiere Gedächtnis fir de klonéierte Wäert direkt ze schreiwen.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Relaxed geet duer an der ueweger, well dëst grondsätzlech eng Optimiséierung ass: mir rennen ëmmer mat schwaache Hinweiser fale gelooss.
            // Schlëmmste Fall, mir hunn en neien Arc onnéideg zougewisen.
            //

            // Mir hunn de leschte staarke Ref ewechgeholl, awer et sinn zousätzlech schwaach Refeuren iwwreg.
            // Mir plënneren den Inhalt an en neien Arc, an ongëlteg déi aner schwaach Refs.
            //

            // Bedenkt datt et net méiglech ass datt d'Liesen vun `weak` usize::MAX (dh gespaart) gëtt, well de schwaache Grof kann nëmmen duerch e Fuedem mat enger staarker Referenz gespaart ginn.
            //
            //

            // Materialiséiert eisen eegene impliziten schwaache Zeiger, sou datt et den ArcInner kann opraumen wéi néideg.
            //
            let _weak = Weak { ptr: this.ptr };

            // Kann just d'Donnéeë klauen, et bleift just nach Schwächen
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Mir waren déi eenzeg Referenz vun enger Zort;stierft de staarke Ref zielt zréck.
            //
            this.inner().strong.store(1, Release);
        }

        // Wéi mat `get_mut()`, ass d'Onsécherheet ok, well eis Referenz entweder eenzegaarteg war fir unzefänken, oder eng gouf beim Klonen vum Inhalt.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Gitt eng mutéierbar Referenz an de gegebene `Arc`, wann et keng aner `Arc` oder [`Weak`] Zeigefanger zu der selwechter Bewëllegung sinn.
    ///
    ///
    /// Retour [`None`] anescht, well et net sécher ass e gemeinsame Wäert ze mutéieren.
    ///
    /// Kuckt och [`make_mut`][make_mut], wat [`clone`][clone] de banneschte Wäert wäert wann et aner Zeigefanger sinn.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Dës Onsécherheet ass ok, well mir si garantéiert datt de Zeiger zréck den *eenzegen* Zeiger ass deen jeemools op T zréckgesat gëtt.
            // Eis Referenzzuel ass garantéiert 1 op dësem Punkt ze sinn, a mir hu gefrot datt den Arc selwer `mut` ass, sou datt mir déi eenzeg méiglech Referenz op déi bannenzeg Daten zréckginn.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Gitt eng mutéierbar Referenz an de gegebene `Arc` zréck, ouni Kontroll.
    ///
    /// Kuckt och [`get_mut`], dat ass sécher a passend Kontrollen.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// All aner `Arc`-oder [`Weak`]-Zeigefanger zu der selwechter Bewëllegung däerfen net fir d'Dauer vum zréckgeléinte Loun verfeiert ginn.
    ///
    /// Dëst ass trivial de Fall wa keng esou Hiweiser existéieren, zum Beispill direkt nom `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Mir si virsiichteg *net* eng Referenz ze kreéieren déi d "count" Felder deckt, well dëst alias mat gläichzäitegen Zougang zu de Referenzzuelen (z. B.
        // vun `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Bestëmmt ob dëst déi eenzegaarteg Referenz (abegraff schwaach Refs) zu de Basisdaten.
    ///
    ///
    /// Bedenkt datt dëst de schwaache Ref Zielt ze spären.
    fn is_unique(&mut self) -> bool {
        // Späert de schwaache Zeigerzuel wa mir als eenzege schwaache Pointerhalter schéngen.
        //
        // De Kafetikett hei garantéiert eng passéierend Bezéiung mat all Schreifweis op `strong` (besonnesch an `Weak::upgrade`) virum Verdeelunge vum `weak` Grof (iwwer `Weak::drop`, déi d'Verëffentlechung benotzt).
        // Wann den aktualiséierte schwaache Ref ni fale gelooss gouf, geet de CAS hei aus, sou datt mir egal sinn ze synchroniséieren.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Dëst muss en `Acquire` sinn fir mat der Verréngerung vum `strong` Konter am `drop` ze synchroniséieren-deen eenzegen Zougang dee geschitt wann iergendeen awer déi lescht Referenz fale gelooss gëtt.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // D'Verëffentlechungsschrëft hei synchroniséiert mat engem Liesen an `downgrade`, effektiv verhënnert datt déi uewe geliesene `strong` nom Schreiwen geschitt.
            //
            //
            self.inner().weak.store(1, Release); // loosst d'Spär fräi
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Drops den `Arc`.
    ///
    /// Dëst wäert de staarke Referenzzuel dekrementéieren.
    /// Wann de staarke Referenzzuel null erreecht, sinn déi eenzeg aner Referenzen (wann iwwerhaapt) [`Weak`], also `drop` de banneschte Wäert.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Dréckt näischt
    /// drop(foo2);   // Dréckt "dropped!" aus
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Well `fetch_sub` scho atomesch ass, brauche mir net mat anere Fächer ze synchroniséieren ausser mir ginn den Objet läschen.
        // Déiselwecht Logik gëlt fir den ënneschten `fetch_sub` fir den `weak` Grof.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Dëse Fence ass gebraucht fir nei Bestellung vum Gebrauch vun den Donnéeën ze vermeiden an d'Donnéeën ze läschen.
        // Well et `Release` markéiert ass, synchroniséiert d'Reduktioun vum Referenzzuel mat dësem `Acquire` Zait.
        // Dëst bedeit datt d'Benotzung vun den Daten passéiert ier de Referenzzuel erofgeet, wat geschitt virun dësem Zait, wat geschitt virum Läschen vun den Daten.
        //
        // Wéi an der [Boost documentation][1] erkläert,
        //
        // > Et ass wichteg all méiglechen Zougang zum Objet an engem duerchzesetzen
        // > Fuedem (duerch eng existent Referenz) fir *geschitt virum* Läschen
        // > den Objet an engem anere Fuedem.Dëst gëtt vun engem "release" erreecht
        // > Operatioun no enger Referenz falen (all Zougang zum Objet
        // > duerch dës Referenz muss offensichtlech virdru geschitt sinn), an eng
        // > "acquire" Operatioun ier Dir den Objet läscht.
        //
        // Besonnesch, wärend den Inhalt vun engem Arc normalerweis onverännerbar ass, ass et méiglech Interieur schreift zu eppes wéi e Mutex<T>.
        // Well eng Mutex net kaaft gëtt wann se geläscht gëtt, kënne mir net op seng Synchronisatiounslogik vertrauen fir schreift am Fuedem A siichtbar fir en Zerstéierer deen am Fuedem B leeft.
        //
        //
        // Bedenkt och datt d'Acquire Zait hei méiglecherweis duerch eng Acquire Belaaschtung ersat ka ginn, wat d'Performance an héich bekämpfte Situatiounen kéint verbesseren.Kuckt [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Versicht den `Arc<dyn Any + Send + Sync>` op e konkreten Typ erofzesetzen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Baut en neien `Weak<T>`, ouni Erënnerung ze verdeelen.
    /// [`upgrade`] um Retourwäert uruffen gëtt ëmmer [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Hëlleftyp fir Zougang zu de Referenzzuelen z'erméiglechen ouni Behaaptungen iwwer den Datefeld ze maachen.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Gitt e roude Zeigefanger op den Objet `T` zréckgezunn vun dësem `Weak<T>`.
    ///
    /// De Zeiger ass nëmme valabel wann et e puer staark Referenze gëtt.
    /// De Zeiger kann hängelen, net ausgeriicht sinn oder och [`null`] anescht.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Béid weisen op datselwecht Objet
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Dee staarken hei hält et lieweg, sou datt mir nach ëmmer Zougang zum Objet kréien.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Awer net méi.
    /// // Mir kënnen weak.as_ptr() maachen, awer Zougang zum Zeiger féiert zu ondefinéiert Verhalen.
    /// // assert_eq! ("hallo", onsécher {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Wann de Zeiger hänkt, gi mir de Sentinel direkt zréck.
            // Dëst kann net eng valabel Notzlaaschtadress sinn, well d'Notzlaascht op d'mannst esou ausgeriicht ass wéi den ArcInner (usize).
            ptr as *const T
        } else {
            // SIKKERHET: wann is_dangling falsch zréckkënnt, da kann de Zeiger déferencabel sinn.
            // D'Notzlaascht kann zu dësem Zäitpunkt fale gelooss ginn, a mir mussen d'Herzéiung behalen, also benotzt rau Zeiger Manipulatioun.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Verbraucht den `Weak<T>` a mécht en zu engem roude Pointer.
    ///
    /// Dëst konvertéiert de schwaache Zeiger an e roude Zeiger, wärend awer de Besëtz vun enger schwaacher Referenz konservéiert (de schwaache Grof gëtt net vun dëser Operatioun modifizéiert).
    /// Et kann zréck an den `Weak<T>` mat [`from_raw`] ëmgewandelt ginn.
    ///
    /// Déi selwecht Restriktioune fir Zougang zum Zil vum Zeiger wéi mat [`as_ptr`] z'erreechen gëllen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Konvertéiert e roude Zeigefanger, dee virdru vum [`into_raw`] erstallt gouf an `Weak<T>` zréck.
    ///
    /// Dëst kann benotzt ginn fir sécher eng staark Referenz ze kréien (andeems Dir [`upgrade`] méi spéit urufft) oder fir de schwaache Grof ze verhandelen andeems Dir den `Weak<T>` fällt.
    ///
    /// Et hëlt Eegentum vun enger schwaacher Referenz (mat Ausnam vun Zeigefanger erstallt vun [`new`], well dës näischt hunn; d'Method funktionnéiert ëmmer nach op hinnen).
    ///
    /// # Safety
    ///
    /// De Zeiger muss vum [`into_raw`] entstane sinn a muss ëmmer nach seng potenziell schwaach Referenz hunn.
    ///
    /// Et ass erlaabt datt de staarke Grof 0 ass beim Zäitpunkt fir dëst ze nennen.
    /// Trotzdem hëlt dëst Eegentum vun enger schwaacher Referenz déi aktuell als roude Zeiger duergestallt gëtt (de schwaache Grof gëtt net vun dëser Operatioun modifizéiert) an dofir muss et mat engem fréieren Uruff op [`into_raw`] gepaart ginn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Dekrementéiert de leschte schwaache Grof.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Kuckt Weak::as_ptr fir de Kontext wéi den Input Pointer ofgeleet gëtt.

        let ptr = if is_dangling(ptr as *mut T) {
            // Dëst ass en hängenden Schwach.
            ptr as *mut ArcInner<T>
        } else {
            // Soss si mir garantéiert datt de Zeigefanger aus engem net vernetzte Schwaach koum.
            // SAFETY: data_offset ass sécher ze ruffen, well ptr verweist op e reellen (potenziell erofgefall) T.
            let offset = unsafe { data_offset(ptr) };
            // Sou ëmsetze mir den Offset fir déi ganz RcBox ze kréien.
            // SIKKERHET: de Zeiger staamt aus engem Schwaachen, sou datt dësen Offset sécher ass.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SIKKERHET: mir hunn elo den originale Schwaachzeiger erëmfonnt, sou kënne mir de Schwaach erstellen.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Versicht den `Weak` Zeiger op en [`Arc`] ze aktualiséieren, de Verspéidung vum banneschten Wäert ze verzögeren wann et erfollegräich ass.
    ///
    ///
    /// Nees [`None`] wann de banneschte Wäert zënterhier erofgefall ass.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Zerstéiert all staark Hiweiser.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Mir benotzen eng CAS Loop fir de staarken Zuelen anzestellen amplaz vun engem fetch_add well dës Funktioun ni d'Referenzzuel vun Null op ee sollt huelen.
        //
        //
        let inner = self.inner()?;

        // Relax Belaaschtung well all Schreiwe vun 0 déi mir observéiere kënnen de Feld an engem permanenten Nullzoustand verloossen (sou datt eng "stale" Liesung vun 0 ass gutt), an all anere Wäert gëtt iwwer de CAS hei ënnendrënner bestätegt.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Gesinn Kommentaren an `Arc::clone` firwat mir dat maachen (fir `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Relaxéiert ass gutt fir de Feelerfall well mir keng Erwaardungen un den neie Staat hunn.
            // Acquire ass noutwendeg fir den Erfollegsfall mat `Arc::new_cyclic` ze synchroniséieren, wann de banneschte Wäert kann initialiséiert ginn nodeems `Weak` Referenze scho erstallt goufen.
            // An deem Fall erwaarden mir de voll initialiséierte Wäert ze beobachten.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null uewen iwwerpréift
                Err(old) => n = old,
            }
        }
    }

    /// Kritt d'Zuel vu staarke (`Arc`) Zeigefanger, déi op dës Bewëllegung weisen.
    ///
    /// Wann `self` mat [`Weak::new`] erstallt gouf, gëtt dëst 0 zréck.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Kritt eng Approximatioun vun der Zuel vun den `Weak` Zeigefanger, déi op dës Bewëllegung weisen.
    ///
    /// Wann `self` mat [`Weak::new`] erstallt gouf, oder wann et keng verbleifend staark Zeigefanger ginn, wäert dëst 0 zréckginn.
    ///
    /// # Accuracy
    ///
    /// Wéinst Ëmsetzungsdetailer kann de zréckgezunnene Wäert vun 1 a béide Richtungen ausgeschalt ginn wann aner Threads all `Arc`s oder`Schwaach` manipuléieren déi op déiselwecht Bewëllegung weisen.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Well mer observéiert hunn datt et op d'mannst ee staarken Zeiger war nodeems mer de schwaache Grof gelies hunn, wësse mer datt déi implizit schwaach Referenz (präsent wann all staark Referenze lieweg sinn) nach ëmmer ronderëm war wéi mer de schwaache Grof observéiert hunn, a kënnen se also sécher ofsetzen.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Retour `None` wann de Zeiger hänkt an et gëtt keen zougewisenen `ArcInner`, (dh wann dësen `Weak` vum `Weak::new` erstallt gouf).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Mir si virsiichteg *net* eng Referenz ze kreéieren déi den "data" Feld deckt, well d'Feld kann gläichzäiteg mutéiert ginn (zum Beispill, wann de leschten `Arc` fale gelooss gëtt, gëtt d'Datenfeld op der Plaz fale gelooss).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Retour `true` wann déi zwee "Schwaach" op déiselwecht Bewëllegung weisen (ähnlech wéi [`ptr::eq`]), oder wa béid net op eng Verdeelung hiweisen (well se mat `Weak::new()`) erstallt goufen.
    ///
    ///
    /// # Notes
    ///
    /// Well dëst Zeigner vergläicht, heescht et datt `Weak::new()` sech géigesäiteg gläiche wäerten, och wa se net op eng Allokatioun hiweisen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` vergläichen.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Maacht e Klon vum `Weak` Zeiger deen op déiselwecht Bewëllegung weist.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Kuckt d'Kommentaren an Arc::clone() firwat dat entspaant ass.
        // Dëst kann e fetch_add benotzen (ignoréiert d'Spär) well de schwaache Grof nëmme gespaart ass wou *keng aner* schwaach Zeigefanger existéieren.
        //
        // (Also mir kënnen dëse Code net an deem Fall lafen).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Gesinn Kommentaren an Arc::clone() firwat mir dat maachen (fir mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Baut en neien `Weak<T>`, ouni Erënnerung ze verdeelen.
    /// [`upgrade`] um Retourwäert uruffen gëtt ëmmer [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Fält den `Weak` Zeiger erof.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Dréckt näischt
    /// drop(foo);        // Dréckt "dropped!" aus
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Wa mir erausfannen datt mir de leschte schwaache Pointer waren, da ass et Zäit d'Daten ganz ze verhandelen.Kuckt d'Diskussioun am Arc::drop() iwwer d'Erënnerungsuerdnungen
        //
        // Et ass net néideg fir de gespaarten Zoustand hei ze kontrolléieren, well de schwaache Grof kann nëmme gespaart ginn wann et präzis ee schwaache Ref war, dat heescht datt drop nëmmen duerno kéint op dee Rescht schwaache Ref lafen, wat nëmme ka geschéien nodeems d'Sperre fräigelooss gëtt.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Mir maachen dës Spezialiséierung hei, an net als méi allgemeng Optimiséierung op `&T`, well et soss e Käschte fir all Gläichheetskontrollen op Refs bäifüügt.
/// Mir ginn dovun aus datt `Arc`s gi benotzt fir grouss Wäerter ze späicheren, déi lues ze klone sinn, awer och schwéier fir no Gläichheet ze kontrolléieren, wouduerch dës Käschte sech méi einfach bezuele kënnen.
///
/// Et ass och méi wahrscheinlech zwee `Arc` Klonen ze hunn, déi op dee selwechte Wäert hindeiten, wéi zwee `&T`en.
///
/// Mir kënnen dat nëmme maachen wann `T: Eq` als `PartialEq` bewosst irreflexiv ka sinn.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Gläichheet fir zwee `Arc`s.
    ///
    /// Zwee `Arc`s si gläich wann hir bannent Wäerter gläich sinn, och wa se a verschiddene Bewëllegunge gespäichert sinn.
    ///
    /// Wann `T` och `Eq` implementéiert (wat Reflexivitéit vu Gläichheet bedeit), sinn zwee `Arc`s déi op déiselwecht Bewëllegung weisen ëmmer gläich.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Ongläichheet fir zwee `Arc`s.
    ///
    /// Zwee `Arc`s sinn ongläich wann hir bannent Wäerter ongläich sinn.
    ///
    /// Wann `T` och `Eq` implementéiert (wat Reflexivitéit vu Gläichheet bedeit), sinn zwee `Arc`s déi op dee selwechte Wäert weisen ni ongläich.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Partielle Verglach fir zwee `Arc`s.
    ///
    /// Déi zwee gi verglach andeems se `partial_cmp()` op hir bannent Wäerter nennen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Manner wéi Verglach fir zwee `Arc`s.
    ///
    /// Déi zwee gi verglach andeems se `<` op hir bannent Wäerter nennen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'Manner wéi oder gläich wéi' Verglach fir zwee `Arc`s.
    ///
    /// Déi zwee gi verglach andeems se `<=` op hir bannent Wäerter nennen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Méi wéi Verglach fir zwee `Arc`s.
    ///
    /// Déi zwee gi verglach andeems se `>` op hir bannent Wäerter nennen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'Méi grouss wéi oder gläich wéi' Verglach fir zwee 'Arc'en.
    ///
    /// Déi zwee gi verglach andeems se `>=` op hir bannent Wäerter nennen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Verglach fir zwee `Arc`s.
    ///
    /// Déi zwee gi verglach andeems se `cmp()` op hir bannent Wäerter nennen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Erstellt en neien `Arc<T>`, mam `Default` Wäert fir `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Allocéiert eng mat Referenz gezielt Scheif a fëllt se duerch Klonung vun "v" Artikelen.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Allokéiert e Referenz gezielt `str` a kopéiert `v` dran.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Allokéiert e Referenz gezielt `str` a kopéiert `v` dran.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Beweegt e gekësst Objet op eng nei, mat Referenz gezielt Bewëllegung.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Allokéiert e Referenz gezielt Stéck a réckelt 'v' Artikelen dran.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Loosst de Vec säi Gedächtnis befreien, awer säin Inhalt net zerstéieren
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Huelt all Element am `Iterator` a sammelt et an en `Arc<[T]>`.
    ///
    /// # Leeschtung Charakteristiken
    ///
    /// ## Den allgemenge Fall
    ///
    /// Am allgemenge Fall gëtt Sammelen an `Arc<[T]>` gemaach andeems Dir als éischt an en `Vec<T>` gesammelt hutt.Dat ass, wann Dir folgend schreift:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// dëst verhält sech wéi wa mir geschriwwen hätten:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Den éischte Set vu Bewëllegunge passéiert hei.
    ///     .into(); // Eng zweet Bewëllegung fir `Arc<[T]>` geschitt hei.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Dëst verdeelt sou vill Mol wéi néideg fir den `Vec<T>` ze bauen an da verdeelt et eemol fir den `Vec<T>` an den `Arc<[T]>` ze dréinen.
    ///
    ///
    /// ## Iteratoren vu bekannter Längt
    ///
    /// Wann Äre `Iterator` `TrustedLen` implementéiert a vun enger exakter Gréisst ass, gëtt eng eenzeg Bewëllegung fir den `Arc<[T]>` gemaach.Zum Beispill:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Just eng eenzeg Bewëllegung geschitt hei.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Spezialiséierung trait benotzt fir an `Arc<[T]>` ze sammelen.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Dëst ass de Fall fir en `TrustedLen` Iterator.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SAFETY: Mir musse sécherstellen datt de Iterator eng exakt Längt huet a mir hunn.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Falen zréck op normal Ëmsetzung.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Kritt den Offset an engem `ArcInner` fir d'Notzlaascht hannert engem Zeiger.
///
/// # Safety
///
/// De Zeiger muss op eng virdru valabel Instanz vun T weisen (a gëlteg Metadate fir hunn), awer den T dierf fale gelooss ginn.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Alignéiert den onmaache Wäert op d'Enn vum ArcInner.
    // Well RcBox repr(C) ass, ass et ëmmer dat lescht Feld an der Erënnerung.
    // SIKKERHET: well déi eenzeg méiglech Gréissten Zorten si Scheiwen, trait Objeten,
    // an extern Typen, d'Input Sécherheetsfuerderung ass aktuell genuch fir d'Ufuerderunge vum align_of_val_raw z'erfëllen;dëst ass en Implementéierungsdetail vun der Sprooch déi net ausserhalb vun std kann ugewannt ginn.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}