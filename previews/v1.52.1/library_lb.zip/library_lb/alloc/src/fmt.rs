//! Utilities fir ze formatéieren an ze drécken `String`s.
//!
//! Dëst Modul enthält d'Runtime Support fir d [`format!`] Syntax Extensioun.
//! Dëse Makro gëtt am Compiler implementéiert fir Uriff zu dësem Modul auszeleeën fir Argumenter bei der Runtime a Strings ze formatéieren.
//!
//! # Usage
//!
//! Den [`format!`] Macro soll vertraut sinn fir déi aus C's `printf`/`fprintf` Funktiounen oder Python's `str.format` Funktioun.
//!
//! E puer Beispiller vun der [`format!`] Extensioun sinn:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" mat féierende Nullen
//! ```
//!
//! Vun dësen, kënnt Dir gesinn datt dat éischt Argument eng Formatstreng ass.Et ass vum Compiler erfuerdert datt dëst e String wuertwiertlech ass;et kann net eng verännerbar weiderginn (fir eng Validitéitskontroll auszeféieren).
//! De Compiler wäert dann d'Formatstrang analyséieren a feststellen ob d'Lëscht vun den Argumenter déi uginn ass passend ass fir dës Formatstreng ze weiderginn.
//!
//! Fir en eenzege Wäert an eng String ze konvertéieren, benotzt d [`to_string`] Method.Dëst wäert d [`Display`] Formatéierung trait benotzen.
//!
//! ## Positiounsparameteren
//!
//! All Formatéierungsargument ass erlaabt ze spezifizéieren wéi e Wärterargument et referéiert, a wann et ausgelooss gëtt ass ugeholl datt et "the next argument" ass.
//! Zum Beispill, d'Format String `{} {} {}` géif dräi Parameteren huelen, a si wäerten an der selwechter Uerdnung formatéiert ginn wéi se se ginn.
//! De Format String `{2} {1} {0}` géif awer d'Argumenter am Géigendeel formatéieren.
//!
//! D'Saache kënnen e bësse komplizéiert ginn, wann Dir déi zwou Aarte vu Positiounsspezifikatioune matenee mëscht.Den "next argument" Spezifizéierer kann als Iterator iwwer d'Argument geduecht ginn.
//! All Kéiers wann en "next argument" Spezifizéierer gesi gëtt, geet den Iterator weider.Dëst féiert zu Verhalen wéi dëst:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Den internen Iterator iwwer d'Argument ass net erweidert ginn wéi déi éischt `{}` gesinn ass, sou datt et dat éischt Argument dréckt.Dann beim Erreechen vun der zweeter `{}` ass den Iterator op dat zweet Argument fortgeschratt.
//! Wesentlech Parameteren, déi hir Argument explizit benennen, beaflossen net Parameteren déi keen Argument a Punkto Positiounsspezifizéierer benennen.
//!
//! E Format String ass erfuerderlech fir all seng Argumenter ze benotzen, soss ass et e Compile-Time Feeler.Dir kënnt op datselwecht Argument méi wéi eemol am Format String bezéien.
//!
//! ## Benannt Parameteren
//!
//! Rust selwer huet keen Python-Äquivalent vu benannte Parameteren zu enger Funktioun, awer den [`format!`] Macro ass eng Syntaxerweiterung déi et erméiglecht benannte Parameteren ze hiewen.
//! Benannt Parameter ginn am Ende vun der Argument Lëscht opgezielt an hunn d'Syntax:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Zum Beispill déi folgend [`format!`] Ausdréck benotzen all benannt Argument:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Et ass net valabel Positiounsparameteren (déi ouni Nimm) no Argumenter mat Nimm ze setzen.Wéi mat Positiounsparameteren ass et net valabel fir benannte Parameteren unzeginn déi net vum Format String benotzt ginn.
//!
//! # Parameteren formatéieren
//!
//! All Argument dat formatéiert gëtt kann duerch eng Rei Formatéierungsparameteren transforméiert ginn (entspriechend dem `format_spec` am [the syntax](#syntax)). Dës Parameteren beaflossen d'Schnouer Representatioun vun deem wat formatéiert gëtt.
//!
//! ## Width
//!
//! ```
//! // All dës drécken "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Dëst ass e Parameter fir den "minimum width" deen d'Format sollt ophuelen.
//! Wann de String vum Wäert dës vill Zeechen net ausfëllt, da gëtt de Padding spezifizéiert vun fill/alignment benotzt fir den néidege Raum opzehuelen (kuckt hei ënnendrënner).
//!
//! De Wäert fir d'Breet kann och als [`usize`] an der Lëscht vun de Parameteren zur Verfügung gestallt ginn andeems e Postfix `$` derbäigesat gëtt, wat beweist datt dat zweet Argument en [`usize`] ass wat d'Breet spezifizéiert.
//!
//! Referenz op en Argument mat der Dollar Syntax beaflosst net den "next argument" Konter, also ass et normalerweis eng gutt Iddi Argumenter no Positioun ze referenzéieren oder benannt Argumenter ze benotzen.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Den optional Fëllkarakter an d'Ausriichtung gëtt normalerweis a Verbindung mam [`width`](#width) Parameter zur Verfügung gestallt.Et muss virum `width` definéiert ginn, direkt nom `:`.
//! Dëst weist datt wann de Wäert deen formatéiert ass méi kleng ass wéi `width`, ginn extra Zeeche ronderëm gedréckt.
//! Füllung kënnt an de folgenden Varianten fir verschidden Ausriichtungen:
//!
//! * `[fill]<` - d'Argument ass lénks ausgeriicht an `width` Kolonnen
//! * `[fill]^` - d'Argument ass zentral ausgeriicht an `width` Kolonnen
//! * `[fill]>` - d'Argument ass richteg ausgeriicht an `width` Kolonnen
//!
//! De Standard [fill/alignment](#fillalignment) fir net numeresch ass e Raum a lénks ausgeriicht.De Standard fir numeresch Formateuren ass och e Raumcharakter awer mat der richteger Ausriichtung.
//! Wann den `0` Fändel (kuckt hei ënnendrënner) fir d'Numerik spezifizéiert ass, dann ass den impliziten Fill Charakter `0`.
//!
//! Bedenkt datt d'Ausrichtung net vu verschiddenen Typen ëmgesat ka ginn.Besonnesch et gëtt normalerweis net fir den `Debug` trait implementéiert.
//! E gudde Wee fir sécherzestellen datt d'Polsterung ugewannt gëtt ass Ären Input ze formatéieren, da pidd dës resultéierend String fir Är Output ze kréien:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Hallo Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Dëst sinn all Fändelen déi d'Behuele vum Formateur veränneren.
//!
//! * `+` - Dëst ass fir numeresch Aarte geduecht a weist datt d'Zeechen ëmmer gedréckt soll ginn.Positiv Schëlder ginn ni par défaut gedréckt, an dat negativt Schëld gëtt just als Standard fir den `Signed` trait gedréckt.
//! Dëse Fändel weist un datt dat richtegt Zeechen (`+` oder `-`) ëmmer soll gedréckt ginn.
//! * `-` - Moment net benotzt
//! * `#` - Dëse Fändel weist datt d "alternate" Form vum Drock benotzt soll ginn.Déi alternativ Forme sinn:
//!     * `#?` - zimmlech drécken d [`Debug`] Formatéierung
//!     * `#x` - geet virum Argument mat engem `0x` vir
//!     * `#X` - geet virum Argument mat engem `0x` vir
//!     * `#b` - geet virum Argument mat engem `0b` vir
//!     * `#o` - geet virum Argument mat engem `0o` vir
//! * `0` - Dëst gëtt benotzt fir fir ganz Zuelen Formater unzeginn datt de Padding op `width` soll mat engem `0` Charakter gemaach ginn wéi och Zeechenbewosst sinn.
//! E Format wéi `{:08}` géif `00000001` fir déi ganz `1` erginn, wärend datselwecht Format `-0000001` fir déi ganz `-1` géif erginn.
//! Bedenkt datt déi negativ Versioun eng manner Null huet wéi déi positiv Versioun.
//!         Bedenkt datt Padding Nullen ëmmer nom Schëld plazéiert sinn (wann iwwerhaapt) a virun den Zifferen.Wann zesumme mam `#` Fändel benotzt, gëlt eng ähnlech Regel: Padding Nullen ginn nom Präfix agefouert awer virun den Ziffere.
//!         De Präfix ass an der Gesamtbreet abegraff.
//!
//! ## Precision
//!
//! Fir net-numeresch Typen kann dëst als "maximum width" ugesi ginn.
//! Wann déi resultéierend String méi laang wéi dës Breet ass, da gëtt se op dës vill Zeechen ofgeschnidden an dee gekierzte Wäert gëtt mat engem richtegen `fill`, `alignment` an `width` ausgestouss wann dës Parameteren agestallt sinn.
//!
//! Fir integral Zorten gëtt dëst ignoréiert.
//!
//! Fir Flott Punktzorten weist dëst un wéivill Zifferen nom Dezimalpunkt gedréckt solle ginn.
//!
//! Et ginn dräi méiglech Weeër fir de gewënschten `precision` ze spezifizéieren:
//!
//! 1. Eng ganz `.N`:
//!
//!    déi ganz `N` selwer ass d'Präzisioun.
//!
//! 2. Eng ganz Zuel oder Numm gefollegt vun Dollarzeechen `.N$`:
//!
//!    benotz Format *Argument*`N` (dat muss en `usize` sinn) als Präzisioun.
//!
//! 3. En Stär `.*`:
//!
//!    `.*` heescht datt dësen `{...}` mat *zwee* Format Inputen assoziéiert ass anstatt mat engem: deen éischten Input hält d `usize` Präzisioun, an deen zweete hält de Wäert fir ze drécken.
//!    Bedenkt datt an dësem Fall, wann een de Format String `{<arg>:<spec>.*}` benotzt, da bezitt sech den `<arg>` Deel op de* Wäert * fir ze drécken, an den `precision` muss am Input kommen virum `<arg>`.
//!
//! Zum Beispill, déi folgend Uriff drécken all déiselwecht Saach `Hello x is 0.01000`:
//!
//! ```
//! // Moien {arg 0 ("x")} ass {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Moien {arg 1 ("x")} ass {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Moien {arg 0 ("x")} ass {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Moien {next arg ("x")} ass {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Moien {next arg ("x")} ass {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Moien {next arg ("x")} ass {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Wärend dës:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! dréckt dräi wesentlech verschidde Saachen:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! A verschiddene Programméierungssproochen hänkt d'Behuele vun de String-Formatéierungsfunktiounen of vun der lokaler Astellung vum Betribssystem.
//! D'Formatfunktiounen, déi vun der Standardbibliothéik vun Rust geliwwert ginn, hu kee Lokalkonzept a produzéieren déiselwecht Resultater op alle Systemer onofhängeg vun der Benotzerkonfiguratioun.
//!
//! Zum Beispill gëtt de folgende Code ëmmer `1.5` gedréckt, och wann d'Systemlokal en Dezimalseparator benotzt ausser engem Punkt.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Déi wuertwiertlech Personnagen `{` an `}` kënnen an engem String abegraff sinn, andeems se mam selwechte Charakter virginn.Zum Beispill ass den `{` Charakter mat `{{` entkomm an den `}` Charakter ass mat `}}` entkomm.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Fir ze resuméieren, hei fannt Dir déi voll Grammaire vu Formatstrings.
//! D'Syntax fir d'Formatéierungssprooch benotzt gëtt aus anere Sprooche gezeechent, also sollt et net ze friem sinn.Argumenter gi mat Python-ähnleche Syntax formatéiert, dat heescht datt Argumenter vun `{}` amplaz vun der C-ähnlecher `%` ëmginn sinn.
//! Déi aktuell Grammaire fir d'Formatéierungssyntax ass:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! An der uewendriwwer Grammatik kann `text` keng `'{'` oder `'}'` Charaktere enthalen.
//!
//! # Formatéiere vun traits
//!
//! Wann Dir freet datt en Argument mat engem bestëmmten Typ formatéiert gëtt, da frot Dir tatsächlech datt en Argument engem bestëmmten trait zouschreift.
//! Dëst erlaabt datt verschidde aktuell Typen iwwer `{:x}` formatéiert ginn (wéi [`i8`] souwéi [`isize`]).Déi aktuell Mapping vun Typen zu traits ass:
//!
//! * *näischt* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] mat kleng kleng Hexadecimalzuelen
//! * `X?` ⇒ [`Debug`] mat ieweschte Fall hexadecimal ganz
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Wat dat heescht ass datt all Typ vun Argument wat den [`fmt::Binary`][`Binary`] trait implementéiert da mat `{:b}` formatéiert ka ginn.Implementatioune gi fir dës traits fir eng Rei primitiv Zorten och vun der Standardbibliothéik zur Verfügung gestallt.
//!
//! Wa kee Format spezifizéiert gëtt (wéi an `{}` oder `{:6}`), da gëtt d'Format trait den [`Display`] trait benotzt.
//!
//! Wann Dir e Format trait fir Ären eegenen Typ implementéiert, musst Dir eng Method vun der Ënnerschrëft implementéieren:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // eise personaliséierten Typ
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Ären Typ gëtt als `self` duerch Referenz weiderginn, an da soll d'Funktioun Ausgang an den `f.buf` Stream emittéieren.Et ass bis zu all Format trait Ëmsetzung fir korrekt un déi gefrote Formatéierungsparameter ze halen.
//! D'Wäerter vun dëse Parameteren ginn an de Felder vum [`Formatter`] struct opgezielt.Fir mat dësem ze hëllefen, gëtt den [`Formatter`] struct och e puer Helfer Methoden.
//!
//! Zousätzlech ass de Retourwäert vun dëser Funktioun [`fmt::Result`] wat en Typalias vun [`Resultat`]`<(),`[`std: : fmt::Feeler`] `>` ass.
//! Implementéierungsformatéiere sollte suergen datt se Feeler aus der [`Formatter`] propagéieren (zB wann Dir [`write!`] rufft).
//! Allerdéngs sollten se ni Feeler falsch zréckginn.
//! Dat ass, eng Formatéierungsimplementéierung muss a kann nëmmen e Feeler zréckschécken wann de passéierten [`Formatter`] e Feeler zréckbréngt.
//! Dëst ass well, am Géigesaz zu deem wat d'Funktiounsënnerschrëft kéint virschloen, String Formatéierung eng onfehlbar Operatioun ass.
//! Dës Funktioun bréngt nëmmen e Resultat zréck well d'Schreiwe fir de Basisstroum ausfale kënnen an et muss e Wee ginn fir de Fakt ze propagéieren datt e Feeler zréck am Stack geschitt ass.
//!
//! E Beispill fir d'Ëmsetzung vun der Formatéierung traits géif ausgesinn:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Den `f` Wäert implementéiert den `Write` trait, wat ass wat et schreift!Macro erwaart.
//!         // Bedenkt datt dës Formatéierung déi verschidde Fändelen ignoréiert fir Strings ze formatéieren.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Verschidde traits erlaabt verschidde Formen vun Ausgab vun engem Typ.
//! // D'Bedeitung vun dësem Format ass d'Gréisst vun engem vector ze drécken.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Respektéiert d'Formatéierungsfändelen mat der Hëllefsmethod `pad_integral` op dem Formatter Objet.
//!         // Kuckt d'Methodendokumentatioun fir Detailer, an d'Funktioun `pad` kann benotzt ginn fir Strings ze padelen.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` géint `fmt::Debug`
//!
//! Dës zwee Formatéierung traits hunn ënnerschiddlech Zwecker:
//!
//! - [`fmt::Display`][`Display`] Implementéierunge behaapten datt den Typ zu all Moment trei als UTF-8 String duergestallt ka ginn.Et gëtt **net** erwaart datt all Typen den [`Display`] trait implementéieren.
//! - [`fmt::Debug`][`Debug`] Ëmsetzunge solle fir **all** ëffentlech Type implementéiert ginn.
//!   Ausgab representéiert typesch den interne Staat sou trei wéi méiglech.
//!   Den Zweck vum [`Debug`] trait ass d'Debuggen vum Rust Code erliichtert.In de meeschte Fäll ass d `#[derive(Debug)]` genug a recommandéiert.
//!
//! E puer Beispiller vum Output vu béide traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Zesummenhang Makroen
//!
//! Et ginn eng Rei vu verwandte Makroen an der [`format!`] Famill.Déi, déi aktuell implementéiert sinn, sinn:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Dëst an [`writeln!`] sinn zwee Makroen déi benotzt gi fir d'Formatstreng zu engem spezifizéierte Stroum z'emittéieren.Dëst gëtt benotzt fir Zwëschenallokatiounen vu Formatstrings ze vermeiden an amplaz direkt d'Ausgab ze schreiwen.
//! Ënnert der Kapuze fokusséiert dës Funktioun tatsächlech d [`write_fmt`] Funktioun definéiert op der [`std::io::Write`] trait.
//! Beispill Benotzung ass:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Dëst an [`println!`] emittéieren hir Ausgab op stdout.Ähnlech wéi den [`write!`] Makro ass d'Zil vun dëse Makroen Vermëttlungsallokatiounen beim Ausdrock ze vermeiden.Beispill Benotzung ass:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! D [`eprint!`] an [`eprintln!`] Makroen sinn identesch mat [`print!`] respektiv [`println!`], ausser se ginn hir Ausgab op stderr aus.
//!
//! ### `format_args!`
//!
//! Dëst ass e kuriéise Macro dee benotzt gëtt fir sécher en opaken Objet ze passéieren deen d'Format String beschreift.Dëst Objet erfuerdert keng Haapttildelen fir ze kreéieren, an et bezitt nëmmen Informatioun um Stack.
//! Ënnert dem Capot sinn all déi verbonne Makroen a Bezuch op dës implementéiert.
//! Als éischt ass e puer Beispiller benotzt:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! D'Resultat vum [`format_args!`] Macro ass e Wäert vum Typ [`fmt::Arguments`].
//! Dës Struktur kann dann an d [`write`] an [`format`] Funktiounen an dësem Modul weidergeleet ginn fir de Format String ze verarbeiten.
//! D'Zil vun dësem Makro ass et nach weider Zwëschenallokatiounen ze vermeiden wann Dir mat Formatéierungssträngen ëmgeet.
//!
//! Zum Beispill eng Logbicherbibliothéik kéint d'Standard Formatéierungssyntax benotzen, awer et géif intern ëm dës Struktur goen, bis et festgestallt gouf, wou d'Ausgab soll goen.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// D `format` Funktioun hëlt en [`Arguments`] Struct a bréngt déi resultéierend formatéiert String zréck.
///
///
/// D [`Arguments`] Instanz kann mam [`format_args!`] Macro erstallt ginn.
///
/// # Examples
///
/// Basis Benotzung:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Maacht weg datt d [`format!`] benotzt ka preferabel sinn.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}