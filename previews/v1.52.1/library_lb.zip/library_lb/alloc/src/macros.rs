/// Erstellt en [`Vec`] mat den Argumenter.
///
/// `vec!` erlaabt datt 'Vec' mat der selwechter Syntax wéi Arrayausdréck definéiert gëtt.
/// Et ginn zwou Forme vun dësem Makro:
///
/// - Erstellt en [`Vec`] mat enger bestëmmter Lëscht vun Elementer:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Erstellt en [`Vec`] aus engem bestëmmten Element a Gréisst:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Bedenkt datt am Géigesaz zu Arrayausdréck dës Syntax all Elementer ënnerstëtzt déi [`Clone`] implementéieren an d'Zuel vun Elementer muss net konstant sinn.
///
/// Dëst wäert `clone` benotze fir en Ausdrock ze duplizéieren, also sollt ee virsiichteg sinn dëst mat Typen ze benotzen déi eng net-Standard `Clone` Ëmsetzung hunn.
/// Zum Beispill, `vec![Rc::new(1);5] `erstellt en vector vu fënnef Referenzen op deeselwechte gekësst ganz Wäert, net fënnef Referenzen, déi op onofhängeg gekësst ganz Zuelen hiweisen.
///
///
/// Bedenkt och datt `vec![expr; 0]` erlaabt ass, a produzéiert en eidelen vector.
/// Dëst wäert awer ëmmer nach `expr` evaluéieren an direkt de resultéierende Wäert falen, also passt op Niewewierkungen.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): mat cfg(test) ass déi ugebaut `[T]::into_vec` Method, déi fir dës Makrodefinitioun erfuerderlech ass, net verfügbar.
// Amplaz d `slice::into_vec` Funktioun ze benotzen déi nëmme mat cfg(test) verfügbar ass Kuckt de slice::hack Modul am slice.rs fir méi Informatioun
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Erstellt en `String` mat Interpolatioun vu Runtime Ausdréck.
///
/// Dat éischt Argument dat `format!` kritt ass eng Formatstreng.Dëst muss e String wuertwiertlech sinn.D'Kraaft vum Formatéierungsstrang ass an den "{} enthale.
///
/// Zousätzlech Parameteren, déi op `format!` weiderginn, ersetzen déi "{} an der Formatéierungsstreng an der Uerdnung, ausser wann benannt oder positionell Parameter benotzt ginn;gesinn [`std::fmt`] fir méi Informatiounen.
///
///
/// E gemeinsame Gebrauch fir `format!` ass Zesummefaassung an Interpolatioun vu Stréckelen.
/// Déiselwecht Konventioun gëtt mat [`print!`] an [`write!`] Makroen benotzt, ofhängeg vun der bestëmmter Destinatioun vum String.
///
/// Fir en eenzege Wäert an eng String ze konvertéieren, benotzt d [`to_string`] Method.Dëst wäert d [`Display`] Formatéierung trait benotzen.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics wann eng Formatéierung trait Ëmsetzung e Feeler zréckbréngt.
/// Dëst weist op eng falsch Ëmsetzung well `fmt::Write for String` ni selwer e Feeler zréckbréngt.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Kraaft den AST-Knuet zu engem Ausdrock fir d'Diagnos an der Musterpositioun ze verbesseren.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}