//! Eng dynamesch Gréisst Vue an eng kontinuéierlech Sequenz, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Scheiwen sinn eng Vue op e Block vum Gedächtnis, deen als Zeiger an eng Längt duergestallt gëtt.
//!
//! ```
//! // e Vec schneiden
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // en Array zu engem Stéck zwéngen
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Scheiwen sinn entweder mutéierbar oder gedeelt.
//! De gemeinsame Scheifentyp ass `&[T]`, wärend de mutabelen Scheifentyp `&mut [T]` ass, wou `T` den Elementstyp duerstellt.
//! Zum Beispill kënnt Dir de Block vum Gedächtnis mutéieren op deen e mutabelen Deel weist op:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Hei sinn e puer vun de Saachen déi dëse Modul enthält:
//!
//! ## Structs
//!
//! Et gi verschidde Structs déi fir Scheiwen nëtzlech sinn, wéi [`Iter`], déi Iteratioun iwwer e Stéck duerstellt.
//!
//! ## Trait Implementatiounen
//!
//! Et gi verschidde Implementatioune vu gemeinsamen traits fir Scheiwen.E puer Beispiller enthalen:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], fir Scheiwen deenen hiren Elementtyp [`Eq`] oder [`Ord`] sinn.
//! * [`Hash`] - fir Scheiwen deenen hiren Elementtyp [`Hash`] ass.
//!
//! ## Iteration
//!
//! D'Scheiwen implementéieren `IntoIterator`.Den Iterator bréngt Referenzen zu de Scheiwenelementer.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Déi mutabel Scheif bréngt mutéierbar Referenzen zu den Elementer:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Dësen Iterator ergëtt mutéierbar Referenzen zu de Scheiwenelementer, sou datt d'Elementart vun der Scheif `i32` ass, ass d'Elementart vum Iterator `&mut i32`.
//!
//!
//! * [`.iter`] an [`.iter_mut`] sinn déi explizit Methoden fir d'Standard-Iteratore zréckzeginn.
//! * Weider Methoden déi Iteratoren zréckginn sinn [`.split`], [`.splitn`], [`.chunks`], [`.windows`] a méi.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Vill vun den Usings an dësem Modul ginn nëmmen an der Testkonfiguratioun benotzt.
// Et ass méi propper just d'Unused_Import Warnung auszeschalten wéi se ze fixéieren.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Basis Scheif Extensiounsmethoden
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) néideg fir d'Ëmsetzung vum `vec!` Makro beim Testen NB, kuckt de `hack` Modul an dëser Datei fir méi Detailer.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) néideg fir d'Ëmsetzung vun `Vec::clone` beim Testen NB, kuckt de `hack` Modul an dëser Datei fir méi Detailer.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Mat cfg(test) `impl [T]` ass net verfügbar, dës dräi Funktioune sinn tatsächlech Methoden déi an `impl [T]` sinn awer net an `core::slice::SliceExt`, mir mussen dës Funktioune fir den `test_permutations` Test liwweren
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Mir sollten net en Inline Attribut derbäisetzen, well dëst am `vec!` Macro meeschtens benotzt gëtt a verursaacht Perf Regressioun.
    // Gesinn #71204 fir Diskussioun a perfekt Resultater.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // Artikele goufen an der Loop ënnen initialiséiert
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) ass noutwendeg fir LLVM fir Grenzen ze läschen an huet besser Codegen wéi Zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // de Vec gouf uewen op d'mannst dës Längt zougewisen an initialiséiert.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // uewe mat der Kapazitéit vun `s` zougewisen, an initialiséiert op `s.len()` an ptr::copy_to_non_overlapping ënnen.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Sortéiert d'Scheiwen.
    ///
    /// Dës Zort ass stabil (dh, net nei Elementer nei bestellen) an *O*(*n*\*log(* n*)) am schlëmmste Fall.
    ///
    /// Wann et zoutrëfft, gëtt onbestänneg Zortéieren bevorzugt well et normalerweis méi séier ass wéi stabil Zortéieren an et hëlleft keen Erënnerung un.
    /// Kuckt [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Aktuell Ëmsetzung
    ///
    /// Den aktuellen Algorithmus ass eng adaptiv, iterativ Fusiounssort inspiréiert vun [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Et ass entwéckelt fir ganz séier ze sinn a Fäll wou d'Scheedung bal zortéiert ass, oder aus zwee oder méi sortéierte Sequenzen noeneen zesummegesat ass.
    ///
    ///
    /// Och allocéiert et temporär Späicherung hallef d'Gréisst vun `self`, awer fir kuerz Scheiwen gëtt eng net-allocéierend Insertion Sort benotzt amplaz.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Sorts de Slice mat enger Komparatorfunktioun.
    ///
    /// Dës Zort ass stabil (dh, net nei Elementer nei bestellen) an *O*(*n*\*log(* n*)) am schlëmmste Fall.
    ///
    /// D'Komparatorfunktioun muss eng total Bestellung fir d'Elementer an der Scheif definéieren.Wann d'Bestellung net total ass, ass d'Bestellung vun den Elementer net spezifizéiert.
    /// Eng Bestellung ass eng total Bestellung wann et ass (fir all `a`, `b` an `c`):
    ///
    /// * total an antisymmetresch: genau ee vun `a < b`, `a == b` oder `a > b` ass wouer, an
    /// * transitiv, `a < b` an `b < c` implizéiert `a < c`.Dat selwecht muss fir béid `==` an `>` halen.
    ///
    /// Zum Beispill, wärend [`f64`] [`Ord`] net implementéiert well `NaN != NaN`, kënne mir `partial_cmp` als Sortfunktioun benotzen wa mir wëssen datt de Slice keen `NaN` enthält.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Wann et zoutrëfft, gëtt onbestänneg Zortéieren bevorzugt well et normalerweis méi séier ass wéi stabil Zortéieren an et hëlleft keen Erënnerung un.
    /// Kuckt [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Aktuell Ëmsetzung
    ///
    /// Den aktuellen Algorithmus ass eng adaptiv, iterativ Fusiounssort inspiréiert vun [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Et ass entwéckelt fir ganz séier ze sinn a Fäll wou d'Scheedung bal zortéiert ass, oder aus zwee oder méi sortéierte Sequenzen noeneen zesummegesat ass.
    ///
    /// Och allocéiert et temporär Späicherung hallef d'Gréisst vun `self`, awer fir kuerz Scheiwen gëtt eng net-allocéierend Insertion Sort benotzt amplaz.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // ëmgedréint Zortéieren
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Sorts de Slice mat enger Schlëssel Extraktioun Funktioun.
    ///
    /// Dës Zort ass stabil (dh net nei Elementer nei bestellen) an *O*(*m*\* * n *\* log(*n*)) am schlëmmste Fall, wou d'Schlësselfunktioun *O*(*m*) ass.
    ///
    /// Fir deier Schlësselfunktiounen (z. B.
    /// Funktiounen déi net einfach Eegeschaftszougäng oder Basis Operatiounen sinn), [`sort_by_cached_key`](slice::sort_by_cached_key) ass méiglecherweis wesentlech méi séier, well et d'Element Tasten net berechent.
    ///
    ///
    /// Wann et zoutrëfft, gëtt onbestänneg Zortéieren bevorzugt well et normalerweis méi séier ass wéi stabil Zortéieren an et hëlleft keen Erënnerung un.
    /// Kuckt [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Aktuell Ëmsetzung
    ///
    /// Den aktuellen Algorithmus ass eng adaptiv, iterativ Fusiounssort inspiréiert vun [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Et ass entwéckelt fir ganz séier ze sinn a Fäll wou d'Scheedung bal zortéiert ass, oder aus zwee oder méi sortéierte Sequenzen noeneen zesummegesat ass.
    ///
    /// Och allocéiert et temporär Späicherung hallef d'Gréisst vun `self`, awer fir kuerz Scheiwen gëtt eng net-allocéierend Insertion Sort benotzt amplaz.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Sorts de Slice mat enger Schlëssel Extraktioun Funktioun.
    ///
    /// Während der Zortéierung gëtt d'Schlësselfunktioun nëmmen eemol pro Element genannt.
    ///
    /// Dës Zort ass stabil (dh, rechent net gläich Elementer) an *O*(*m*\* * n *+* n *\* log(*n*)) am schlëmmste Fall, wou d'Schlësselfunktioun *O*(*m*) ass .
    ///
    /// Fir einfach Schlësselfunktiounen (zB Funktiounen déi Zougank op Eegentum sinn oder Basis Operatiounen) ass [`sort_by_key`](slice::sort_by_key) méiglecherweis méi séier.
    ///
    /// # Aktuell Ëmsetzung
    ///
    /// Den aktuellen Algorithmus baséiert op [pattern-defeating quicksort][pdqsort] vum Orson Peters, deen de schnelle Duerchschnëttsfall vu randomiséierte Quicksort mat dem schnellste Schlëmmste Fall vun Heapsort kombinéiert, wärend et Linearzäit op Scheiwen mat gewësse Mustere erreecht.
    /// Et benotzt e puer Randomiséierung fir degeneréiert Fäll ze vermeiden, awer mat engem fixen seed fir ëmmer deterministescht Verhalen ze bidden.
    ///
    /// Am schlëmmste Fall allocéiert den Algorithmus temporär Späicheren an engem `Vec<(K, usize)>` d'Längt vun der Scheif.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Hëllefsmakro fir eis vector duerch dee klengsten méiglechen Index ze indexéieren, fir d'Allocatioun ze reduzéieren.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // D'Elementer vun `indices` sinn eenzegaarteg, well se indexéiert sinn, sou datt all Zort stabil ass par rapport zum originale Slice.
                // Mir benotzen `sort_unstable` hei well et manner Erënnerung Bewëllegung verlaangt.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Kopéiert `self` an en neien `Vec`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Hei kënnen `s` an `x` onofhängeg geännert ginn.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Kopéiert `self` an en neien `Vec` mat engem allocator.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Hei kënnen `s` an `x` onofhängeg geännert ginn.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, kuckt de `hack` Modul an dëser Datei fir méi Detailer.
        hack::to_vec(self, alloc)
    }

    /// Konvertéiert `self` an en vector ouni Klonen oder Allokatioun.
    ///
    /// Déi doraus resultéierend vector kann zréck an eng Këscht ëmgewandelt ginn iwwer `Vec<T>D `into_boxed_slice` Method.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` kann net méi benotzt ginn well en an `x` ëmgewandelt gouf.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, kuckt de `hack` Modul an dëser Datei fir méi Detailer.
        hack::into_vec(self)
    }

    /// Erstellt en vector andeems Dir e Stéck `n` Mol widderhëlt.
    ///
    /// # Panics
    ///
    /// Dës Funktioun wäert panic wann d'Kapazitéit iwwerschwemmt.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// A panic beim Iwwerlaf:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Wann `n` méi grouss wéi Null ass, kann et als `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)` gedeelt ginn.
        // `2^expn` ass d'Zuel déi lénksst '1' Bit vun `n` vertrueden ass, an `rem` ass de Rescht Deel vun `n`.
        //
        //

        // Mat `Vec` fir Zougang zu `set_len()` ze kréien.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` Widderhuelung gëtt gemaach andeems `buf` `expn`-Zäite verduebelt ginn.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Wann `m > 0`, da bleiwen nach Bits bis op déi lénksst '1'.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` huet Kapazitéit vun `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) Widderhuelung gëtt gemaach andeems éischt `rem` Widderhuelunge vun `buf` selwer kopéiert ginn.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Dëst ass net iwwerlappend zënter `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` ass gläich wéi `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Flaacht e Stéck `T` an een eenzege Wäert `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Flaacht e Stéck `T` an een eenzege Wäert `Self::Output`, a plazéiert e bestëmmten Trenner tëschteneen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Flaacht e Stéck `T` an een eenzege Wäert `Self::Output`, a plazéiert e bestëmmten Trenner tëschteneen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Nees en vector mat enger Kopie vun dëser Scheif wou all Byte u säin ASCII-Uewerfall entsprécht.
    ///
    ///
    /// ASCII Buschtawen 'a' op 'z' ginn op 'A' op 'Z', awer net ASCII Bréiwer sinn onverännert.
    ///
    /// Fir de Wäert op der Plaz ze schécken, benotzt [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Gitt e vector mat enger Kopie vun dësem Stéck wou all Byte u säin ASCII kleng Fall entsprécht.
    ///
    ///
    /// ASCII Buschtawen 'A' op 'Z' ginn op 'a' op 'z', awer net ASCII Bréiwer sinn onverännert.
    ///
    /// Fir de Wäert op der Plaz kleng ze maachen, benotzt [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Extensioun traits fir Scheiwen iwwer spezifesch Aarte vun Daten
////////////////////////////////////////////////////////////////////////////////

/// Helper trait fir [`[T]: : concat`](Slice::concat).
///
/// Note: den `Item` Typ Parameter gëtt net an dësem trait benotzt, awer et erlaabt Impls méi generesch ze sinn.
/// Ouni et kréie mir dëse Feeler:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Dëst ass well et `V` Typen mat méi `Borrow<[_]>` Implen existéiere kënnen, sou datt verschidde `T` Typen gëllen:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Déi doraus resultéierend Aart no Zesummefaassung
    type Output;

    /// Ëmsetzung vun [`[T]: : concat`](Slice::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Helper trait fir [`[T]: : join`](Slice::join)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Déi doraus resultéierend Aart no Zesummefaassung
    type Output;

    /// Ëmsetzung vun [`[T]: : join`](Slice::join)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Standard trait Implementatiounen fir Scheiwen
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // fällt alles am Zil dat net iwwerschriwwe gëtt
        target.truncate(self.len());

        // target.len <= self.len wéinst der Ofkierzung uewen, sou datt d'Scheiwen hei ëmmer a Grenzen sinn.
        //
        let (init, tail) = self.split_at(target.len());

        // reuse benotzte Wäerter allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Setzt `v[0]` an eng pre-sortéiert Sequenz `v[1..]`, sou datt de ganzen `v[..]` zortéiert gëtt.
///
/// Dëst ass déi integral Subrutin vun der Insertion Zort.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Et ginn dräi Weeër fir d'Enregistréiere hei ëmzesetzen:
            //
            // 1. Tauscht Nopeschelementer bis deen éischten op säi Schlussziel kënnt.
            //    Wéi och ëmmer, dës Manéier kopéiere mir Date ronderëm méi wéi néideg.
            //    Wann Elementer grouss Strukture sinn (deier ze kopéieren), wäert dës Method lues sinn.
            //
            // 2. Iteréiert bis déi richteg Plaz fir dat éischt Element fonnt gëtt.
            // Da verréckelen d'Elementer et erfollegräich fir et Plaz ze maachen a placéieren se endlech an de Rescht Lach.
            // Dëst ass eng gutt Method.
            //
            // 3. Kopéiert dat éischt Element an eng temporär Variabel.Iteréiert bis déi richteg Plaz fir et fonnt gëtt.
            // Wéi mir laanscht goen, kopéiert all duerchgestrachenem Element an de Slot virdrun.
            // Endlech kopéiert Daten aus der temporärer Variabel an de Rescht Lach.
            // Dës Method ass ganz gutt.
            // Benchmarks hunn e bësse besser Performance demonstréiert wéi mat der 2. Method.
            //
            // All Methode goufe benchmarkéiert, an déi 3. huet déi bescht Resultater gewisen.Also hu mir dee gewielt.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Zwëschenzoustand vum Insertionsprozess gëtt ëmmer vum `hole` verfollegt, wat zwee Zwecker déngt:
            // 1. Schützt Integritéit vun `v` vun panics an `is_less`.
            // 2. Fëllt dat rescht Lach am `v` um Enn aus.
            //
            // Panic Sécherheet:
            //
            // Wann `is_less` panics iergendwann am Prozess, `hole` fällt a fëllt d'Lach am `v` mat `tmp`, a garantéiert datt `v` ëmmer nach all Objet hält, deen et am Ufank genau eemol gehal huet.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` gëtt erofgefall a kopéiert domat `tmp` an de Rescht Lach am `v`.
        }
    }

    // Wann erofgefall, Kopie vun `src` op `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Fusionéiert net erofgoen leeft `v[..mid]` an `v[mid..]` mat `buf` als temporär Lagerung, a späichert d'Resultat an `v[..]`.
///
/// # Safety
///
/// Déi zwou Scheiwen mussen net eidel sinn an `mid` muss a Grenzen sinn.
/// Buffer `buf` muss laang genuch sinn fir eng Kopie vun der méi kuerzer Scheif ze halen.
/// Och `T` däerf keen Nullgréissten Typ sinn.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // De Fusiounsprozess kopéiert als éischt de méi kuerze Run an `buf`.
    // Duerno verfollegt et den nei kopéiert Run a méi laange Forward (oder no hannen), vergläicht hir nächst net konsuméiert Elementer a kopéiert de manner (oder méi groussen) an `v`.
    //
    // Soubal de méi kuerze Run voll verbraucht ass, gëtt de Prozess gemaach.Wann déi méi laang Course als éischt verbraucht gëtt, musse mir alles kopéiere wat vum kuerze Laf bleift an de Rescht Lach am `v`.
    //
    // Mëttelstand vum Prozess gëtt ëmmer vun `hole` verfollegt, wat zwee Zwecker déngt:
    // 1. Schützt Integritéit vun `v` vun panics an `is_less`.
    // 2. Fëllt de Rescht Lach am `v` aus wann de méi laange fir d'éischt verbraucht gëtt.
    //
    // Panic Sécherheet:
    //
    // Wann `is_less` panics iergendwann am Prozess, `hole` fällt a fëllt d'Lach am `v` mat dem onverbrauchte Range an `buf`, sou datt `v` ëmmer nach all Objet hält, wat et am Ufank genau eemol ofgehalen huet.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Déi lénks Course ass méi kuerz.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Ufanks weisen dës Zeigeféier op den Ufank vun hiren Arrays.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Verbrauch déi manner Säit.
            // Wann et gläich ass, léiwer de lénke Run fir d'Stabilitéit ze halen.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // De richtege Run ass méi kuerz.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Ufanks weisen dës Zeigefanger laanscht d'Enn vun hiren Arrays.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Verbrauch déi méi grouss Säit.
            // Wann et gläich ass, léiwer de richtege Run fir d'Stabilitéit ze halen.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Endlech gëtt `hole` erofgefall.
    // Wann dee méi kuerze Run net vollstänneg verbraucht gouf, gëtt ëmmer dat wat dovunner bleift elo an d'Lach am `v` kopéiert.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Wann erofgefall, kopéiert d'Band `start..end` op `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` ass keen Nullgréisstentyp, also ass et an der Rei ze deelen duerch seng Gréisst.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Dës Fusiounsaart léint e puer (awer net all) Iddien vum TimSort, déi am Detail [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt) beschriwwe ginn.
///
///
/// Den Algorithmus identifizéiert strikt ofsteigend an net ofsteigend Nofolger, déi natierlech Lafen genannt ginn.Et gëtt e Stack u waarden Lafen déi nach fusionéiert ginn.
/// All nei fonnt Run gëtt op de Stack gedréckt, an da ginn e puer Puer vun ugrenzende Runen fusionéiert bis dës zwee Invarariater zefridden sinn:
///
/// 1. fir all `i` an `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. fir all `i` an `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// D'Invariante suergen dofir datt d'Gesamtlaafzäit *O*(*n*\*log(* n*)) am schlëmmste Fall ass.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Scheiwen bis zu dëser Längt gi mat der Insertion Zort sortéiert.
    const MAX_INSERTION: usize = 20;
    // Ganz kuerz Lafen gi mat der Insertion Sort verlängert fir op d'mannst dës vill Elementer ze spannen.
    const MIN_RUN: usize = 10;

    // Sortéieren huet kee sënnvoll Verhalen op Nullgréissten Typen.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Kuerz Arrays ginn op der Plaz iwwer Insertion Sort sortéiert fir Allocatiounen ze vermeiden.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Allokéiert e Puffer fir als Scratch Memory ze benotzen.Mir behalen d'Längt 0 sou datt mir et flaach Kopie vum Inhalt vun `v` behale kënnen ouni datt d'Dtoren op Kopie lafen wann `is_less` panics.
    //
    // Wann Dir zwee sortéiert Runen fusionéiert, hält dëse Puffer eng Kopie vum méi kuerze Run, deen ëmmer d'Längt héchstens `len / 2` wäert hunn.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Fir natierlech Laafen an `v` z'identifizéieren, traverséiere mir et no hannen.
    // Dat kéint wéi eng komesch Entscheedung schéngen, awer betruecht de Fakt datt fusionnéiert méi dacks an déi entgéintgesate Richtung (forwards) goen.
    // Geméiss Benchmarks ass Fusioune viru liicht méi séier wéi no hannen ze fusionéieren.
    // Fir ofzeschléissen, d'Identifikatioun vu Rennen andeems se no hanne kräizen verbessert d'Performance.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Fannt déi nächst natierlech Course, a réckgängeg wann et strikt erofgeet.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Setzt e puer méi Elementer an de Run wann et ze kuerz ass.
        // Insertion Sort ass méi séier wéi d'Fusiounszort op kuerze Sequenzen, sou datt dëst d'Performance bedeitend verbessert.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Dréckt dëse Run op de Stack.
        runs.push(Run { start, len: end - start });
        end = start;

        // Fusionéiert e puer Pairen vun Nopeschlafen fir d'Invariater zefridden ze stellen.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Schlussendlech muss genau ee Run am Stack bleiwen.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Ënnersicht de Stack vu Runen an identifizéiert de nächste Pair vu Runen fir ze fusionéieren.
    // Méi spezifesch, wann `Some(r)` zréckkomm ass, heescht dat `runs[r]` an `runs[r + 1]` musse fusionéiert ginn.
    // Wann den Algorithmus amplaz en neie Run bauen sollt, gëtt `None` zréck.
    //
    // Den TimSort ass berühmt fir seng Buggy-Implementatiounen, wéi hei beschriwwen:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // De Kär vun der Geschicht ass: mir mussen d'Invarianten op déi véier éischt Runen um Stack duerchsetzen.
    // Duerchsetzen op just déi Top dräi ass net genuch fir ze garantéieren datt d'Invariater nach *all* leeft am Stack halen.
    //
    // Dës Funktioun kontrolléiert d'Invararianer korrekt fir déi véier éischt Runen.
    // Zousätzlech, wann den Top Run am Index 0 ufänkt, da fuerdert et ëmmer eng Fusiounsoperatioun bis de Stack komplett zesummegeklappt ass, fir d'Sort fäerdeg ze maachen.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}