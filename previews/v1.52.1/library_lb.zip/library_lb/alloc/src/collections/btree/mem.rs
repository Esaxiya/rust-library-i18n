use core::intrinsics;
use core::mem;
use core::ptr;

/// Dëst ersetzt de Wäert hannert der `v` eenzegaarteger Referenz andeems Dir déi relevant Funktioun nennt.
///
///
/// Wann en panic an der `change` Zoumaache geschitt, gëtt de ganze Prozess ofgebrach.
#[allow(dead_code)] // halen als Illustratioun a fir future benotzen
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Dëst ersetzt de Wäert hannert der `v` eenzegaarteger Referenz andeems Dir déi relevant Funktioun nennt, a bréngt e Resultat, dat Dir am Wee kritt kritt zréck.
///
///
/// Wann en panic an der `change` Zoumaache geschitt, gëtt de ganze Prozess ofgebrach.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}