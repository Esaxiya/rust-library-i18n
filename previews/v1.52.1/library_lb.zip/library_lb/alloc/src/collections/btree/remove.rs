use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef};

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    /// Entfernt e Schlësselwäertpaar vum Bam, a bréngt dat Paar zréck, souwéi d'Blat edge dat deem fréiere Puer entsprécht.
    /// Et ass méiglech datt e Rootknot eidel ass, deen intern ass, deen den Uruff aus der Kaart sprange soll, deen de Bam hält.
    /// Den Uruffer soll och d'Längt vun der Kaart erofsetzen.
    ///
    pub fn remove_kv_tracking<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        match self.force() {
            Leaf(node) => node.remove_leaf_kv(handle_emptied_internal_root),
            Internal(node) => node.remove_internal_kv(handle_emptied_internal_root),
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    fn remove_leaf_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let (old_kv, mut pos) = self.remove();
        let len = pos.reborrow().into_node().len();
        if len < MIN_LEN {
            let idx = pos.idx();
            // Mir mussen d'Kandertyp temporär vergiessen, well et gëtt keen ënnerschiddlechen Node-Typ fir déi direkt Elteren vun engem Blat.
            //
            let new_pos = match pos.into_node().forget_type().choose_parent_kv() {
                Ok(Left(left_parent_kv)) => {
                    debug_assert!(left_parent_kv.right_child_len() == MIN_LEN - 1);
                    if left_parent_kv.can_merge() {
                        left_parent_kv.merge_tracking_child_edge(Right(idx))
                    } else {
                        debug_assert!(left_parent_kv.left_child_len() > MIN_LEN);
                        left_parent_kv.steal_left(idx)
                    }
                }
                Ok(Right(right_parent_kv)) => {
                    debug_assert!(right_parent_kv.left_child_len() == MIN_LEN - 1);
                    if right_parent_kv.can_merge() {
                        right_parent_kv.merge_tracking_child_edge(Left(idx))
                    } else {
                        debug_assert!(right_parent_kv.right_child_len() > MIN_LEN);
                        right_parent_kv.steal_right(idx)
                    }
                }
                Err(pos) => unsafe { Handle::new_edge(pos, idx) },
            };
            // SAFETY: `new_pos` ass de Blat vun deem mir ugefaang hunn oder e Geschwëster.
            pos = unsafe { new_pos.cast_to_leaf_unchecked() };

            // Nëmme wa mir fusionéiert hunn, huet den Elterendeel (wann iwwerhaapt) verréngert, awer de folgende Schrëtt iwwerspréngt soss bezilt sech net an de Benchmarks.
            //
            // SAFETY: Mir wäerten d'Blat net zerstéieren oder nei arrangéieren wou `pos` ass
            // andeems hien säin Elterendeel rekursiv ëmgeet;am schlëmmste Fall wäerte mir den Elterendeel duerch d'Grousselteren zerstéieren oder nei arrangéieren, sou änneren de Link op den Elterendeel am Blat.
            //
            //
            //
            if let Ok(parent) = unsafe { pos.reborrow_mut() }.into_node().ascend() {
                if !parent.into_node().forget_type().fix_node_and_affected_ancestors() {
                    handle_emptied_internal_root();
                }
            }
        }
        (old_kv, pos)
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    fn remove_internal_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        // Ewechzehuelen engem bascht KV vu sengem Leaf an dann et zréck an Plaz vun der Element mir gefrot goufen ewechzehuelen.
        //
        // Léiwer de lénksen ugrenzenden KV, aus de Grënn déi am `choose_parent_kv` opgezielt sinn.
        let left_leaf_kv = self.left_edge().descend().last_leaf_edge().left_kv();
        let left_leaf_kv = unsafe { left_leaf_kv.ok().unwrap_unchecked() };
        let (left_kv, left_hole) = left_leaf_kv.remove_leaf_kv(handle_emptied_internal_root);

        // Den internen Node kann aus geklaut oder fusionéiert ginn.
        // Géi zréck riets fir ze fannen wou den originale KV endlech war.
        let mut internal = unsafe { left_hole.next_kv().ok().unwrap_unchecked() };
        let old_kv = internal.replace_kv(left_kv.0, left_kv.1);
        let pos = internal.next_leaf_edge();
        (old_kv, pos)
    }
}