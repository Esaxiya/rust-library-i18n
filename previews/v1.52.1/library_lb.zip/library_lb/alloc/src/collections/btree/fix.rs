use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef, Root};

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Lager en eventuell onvollstännegen Knuet op andeems se mat engem Geschwëster fusionéieren oder klauen.
    /// Wann erfollegräich awer op d'Käschte fir den Eltereknäppchen ze verréngeren, gëtt dee verréngerten Eltereknäppchen zréck
    /// Nees en `Err` wann de Knuet eng eidel Wuerzel ass.
    ///
    fn fix_node_through_parent(
        self,
    ) -> Result<Option<NodeRef<marker::Mut<'a>, K, V, marker::Internal>>, Self> {
        let len = self.len();
        if len >= MIN_LEN {
            Ok(None)
        } else {
            match self.choose_parent_kv() {
                Ok(Left(mut left_parent_kv)) => {
                    if left_parent_kv.can_merge() {
                        let parent = left_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        left_parent_kv.bulk_steal_left(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Ok(Right(mut right_parent_kv)) => {
                    if right_parent_kv.can_merge() {
                        let parent = right_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        right_parent_kv.bulk_steal_right(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Err(root) => {
                    if len > 0 {
                        Ok(None)
                    } else {
                        Err(root)
                    }
                }
            }
        }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Aktie vun engem méiglecherweis onvollstännegen Knuet, a wann dat säin Elterenknot verursaacht ze verréngeren, stockéiert den Elterendeel, rekursiv.
    /// Gitt `true` zréck wann et de Bam fixéiert huet, `false` wann et net konnt well de Rootknot eidel gouf.
    ///
    /// Dës Method erwaart net datt d'Virfahre scho wéineg beim Entrée sinn an panics wann et en eidele Virfahre begéint.
    ///
    ///
    ///
    pub fn fix_node_and_affected_ancestors(mut self) -> bool {
        loop {
            match self.fix_node_through_parent() {
                Ok(Some(parent)) => self = parent.forget_type(),
                Ok(None) => return true,
                Err(_) => return false,
            }
        }
    }
}

impl<K, V> Root<K, V> {
    /// Läscht eidel Niveauen uewen, awer hält en eidel Blat wann de ganze Bam eidel ass.
    pub fn fix_top(&mut self) {
        while self.height() > 0 && self.len() == 0 {
            self.pop_internal_level();
        }
    }

    /// Aktien op oder fusionéieren all Vollnoden op der rietser Grenz vum Bam.
    /// Déi aner Knäpp, déi net d'Wurzel sinn an och net déi riets edge, musse schonn op d'mannst MIN_LEN Elementer hunn.
    ///
    pub fn fix_right_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().last_kv().fix_right_border_of_right_edge();
            self.fix_top();
        }
    }

    /// De symmetresche Klon vun `fix_right_border`.
    pub fn fix_left_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().first_kv().fix_left_border_of_left_edge();
            self.fix_top();
        }
    }

    /// Lagerert all Vollknäppchen op der rietser Grenz vum Bam.
    /// Déi aner Kniet, déi net d'Wurzel sinn an och net déi riets edge, musse bereet sinn bis zu MIN_LEN Elementer geklaut ze hunn.
    ///
    pub fn fix_right_border_of_plentiful(&mut self) {
        let mut cur_node = self.borrow_mut();
        while let Internal(internal) = cur_node.force() {
            // Kontrolléiert ob dat rietsste Kand net voll ass.
            let mut last_kv = internal.last_kv().consider_for_balancing();
            debug_assert!(last_kv.left_child_len() >= MIN_LEN * 2);
            let right_child_len = last_kv.right_child_len();
            if right_child_len < MIN_LEN {
                // Mir musse klauen.
                last_kv.bulk_steal_left(MIN_LEN - right_child_len);
            }

            // Gitt méi wäit erof.
            cur_node = last_kv.into_right_child();
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    fn fix_left_border_of_left_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_left_child().first_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }

    fn fix_right_border_of_right_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_right_child().last_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Lagert dat lénkst Kand op, unzehuelen datt de richtege Kand net underfull ass, a bestëmmt en extra Element fir seng Kanner z'erreechen z'erreechen ouni ze underfull ze ginn.
    ///
    /// Retouréiert dat lénkst Kand.
    ///
    fn fix_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let left_len = internal_kv.left_child_len();
        debug_assert!(internal_kv.right_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` fir nei Upassung ze vermeiden wann Fusioun op den nächsten Niveau geschitt.
            let count = (MIN_LEN + 1).saturating_sub(left_len);
            if count > 0 {
                internal_kv.bulk_steal_right(count);
            }
            internal_kv.into_left_child()
        }
    }

    /// Lagert dat richtegt Kand op, unzehuelen datt dat lénkst Kand net ze voll ass, a bestëmmt en extra Element fir et méiglech seng Kanner noeneen ze fusionéieren ouni ze voll ze ginn.
    ///
    /// Retourne wou och ëmmer dat richtegt Kand.
    ///
    fn fix_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let right_len = internal_kv.right_child_len();
        debug_assert!(internal_kv.left_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` fir nei Upassung ze vermeiden wann Fusioun op den nächsten Niveau geschitt.
            let count = (MIN_LEN + 1).saturating_sub(right_len);
            if count > 0 {
                internal_kv.bulk_steal_left(count);
            }
            internal_kv.into_right_child()
        }
    }
}