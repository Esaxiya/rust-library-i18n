use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Füügt all Schlësselwäerterpuer vun der Unioun vun zwee opsteigend Iteratore bäi, a vergréissert eng `length` Variabel ënnerwee.Déi lescht mécht et méi einfach fir den Uruff e Leck ze vermeiden wann en Drop Handler panikéiert.
    ///
    /// Wa béid Iteratoren deeselwechte Schlëssel produzéieren, fällt dës Method de Pair vu lénksem Iterator an füügt de Pair vum richtegen Iterator un.
    ///
    /// Wann Dir wëllt datt de Bam an enger streng opsteigender Uerdnung kënnt, wéi fir en `BTreeMap`, solle béid Iteratoren Schlësselen a streng eropsteigend Uerdnung produzéieren, all méi grouss wéi all Schlësselen am Bam, inklusiv all Schlësselen, déi schonn am Bam beim Entrée sinn.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Mir préparéiere `left` an `right` an eng zortéiert Sequenz a linearer Zäit ze fusionéieren.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Mëttlerweil baue mir e Bam aus der zortéierter Sequenz a linearer Zäit.
        self.bulk_push(iter, length)
    }

    /// Dréckt all Schlësselwäerterpuer op d'Enn vum Bam, erhéicht eng `length` Variabel ënnerwee.
    /// Déi lescht mécht et méi einfach fir den Uruff e Leck ze vermeiden wann den Iterator panikéiert.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Iteréiert duerch all Schlësselwäertpuer, dréckt se a Knuet op de richtegen Niveau.
        for (key, value) in iter {
            // Probéiert Schlësselwäerterpuer an den aktuelle Blatknot ze drécken.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Keng Plaz méi, gitt erop an dréckt do.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Fonnt e Knuet mat lénksem Raum, dréckt hei.
                                open_node = parent;
                                break;
                            } else {
                                // Géi erëm erop.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Mir sinn uewen, kreéieren en neie Rootknot a drécken dohinner.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Dréckt Schlësselwäertpaar an neie richtege Subtree
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Géi nach eng Kéier op dat riets-meescht Blat erof.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Inkrementlängt all Iteratioun, fir sécher ze sinn, datt d'Kaart déi ugehaang Elementer fällt, och wann d'Iterator panikéiert.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// En Iterator fir zwee sortéiert Sequenzen an eng ze fusionéieren
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Wann zwee Schlësselen gläich sinn, gëtt de Schlësselwäertpaar vun der richteger Quell zréck.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}