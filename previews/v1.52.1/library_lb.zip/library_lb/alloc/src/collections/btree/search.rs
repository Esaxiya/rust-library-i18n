use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// Eng inklusiv Bindung fir nozekucken, sou wéi `Bound::Included(T)`.
    Included(T),
    /// Eng exklusiv Bindung fir nozekucken, sou wéi `Bound::Excluded(T)`.
    Excluded(T),
    /// Eng bedéngungslos inklusiv Bindung, sou wéi `Bound::Unbounded`.
    AllIncluded,
    /// Eng bedéngungslos exklusiv Grenz.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Kuckt e gegebene Schlëssel an engem (Ënner) Bam, deen duerch de Knuet geleet gëtt, rekursiv.
    /// Nees en `Found` mam Grëff vum passenden KV, wann iwwerhaapt.
    /// Soss gëtt en `GoDown` zréck mam Grëff vum Blat edge wou de Schlëssel gehéiert.
    ///
    /// D'Resultat ass nëmme sënnvoll wann de Bam mam Schlëssel bestallt gëtt, wéi de Bam an engem `BTreeMap` ass.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// Daucht erof op deen nooste Knuet wou den edge mat der ënneschter Grenz vum Beräich entsprécht anescht ass wéi den edge deen der ieweschter Grenz entsprécht, dh deen nooste Knuet deen op d'mannst ee Schlëssel enthält am Beräich.
    ///
    ///
    /// Wann et fonnt gëtt, gëtt en `Ok` mat deem Knuet zréck, de Pair vun edge Indizes dran, déi d'Gamme begrenzt, an de korrespondéierte Pair vu Grenze fir d'Sich an de Kannerknäpp weiderzemaachen, am Fall wou de Knuet intern ass.
    ///
    /// Wann net fonnt, gëtt en `Err` mam Blat edge mat der ganzer Palette zréck.
    ///
    /// D'Resultat ass nëmme sënnvoll wann de Bam mam Schlëssel bestallt gëtt.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Inlineéieren dës Variabelen sollten vermeit ginn.
        // Mir ginn dovun aus datt d'Grenzen, déi vum `range` gemellt goufen, déiselwecht bleiwen, awer eng géigneresch Implementatioun kéint tëscht den Uriff (#81138) änneren.
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// Fannt en edge am Knuet, deen déi ënnescht Grenz vun engem Beräich ofgrenzt.
    /// Gitt och déi ënnescht Grenz zréck fir ze benotzen fir d'Sich am passenden Kannerknot weiderzeféieren, wann `self` en internen Node ass.
    ///
    ///
    /// D'Resultat ass nëmme sënnvoll wann de Bam mam Schlëssel bestallt gëtt.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// Klon vun `find_lower_bound_edge` fir déi iewescht Grenz.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Kuckt e bestëmmte Schlëssel am Knuet, ouni Rekursioun.
    /// Nees en `Found` mam Grëff vum passenden KV, wann iwwerhaapt.
    /// Soss gëtt en `GoDown` mam Grëff vum edge zréck, wou de Schlëssel kéint fonnt ginn (wann den Node intern ass) oder wou de Schlëssel kann agefouert ginn.
    ///
    ///
    /// D'Resultat ass nëmme sënnvoll wann de Bam mam Schlëssel bestallt gëtt, wéi de Bam an engem `BTreeMap` ass.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// Gitt entweder de KV Index am Knuet op deem de Schlëssel (oder en Äquivalent) existéiert, oder den edge Index wou de Schlëssel gehéiert.
    ///
    ///
    /// D'Resultat ass nëmme sënnvoll wann de Bam mam Schlëssel bestallt gëtt, wéi de Bam an engem `BTreeMap` ass.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// Fannt en edge Index am Knuet, deen déi ënnescht Grenz vun engem Beräich ofgrenzt.
    /// Gitt och déi ënnescht Grenz zréck fir ze benotzen fir d'Sich am passenden Kannerknot weiderzeféieren, wann `self` en internen Node ass.
    ///
    ///
    /// D'Resultat ass nëmme sënnvoll wann de Bam mam Schlëssel bestallt gëtt.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// Klon vun `find_lower_bound_index` fir déi iewescht Grenz.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}