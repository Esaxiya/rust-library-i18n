use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// E Plang fir Crash Test Dummy Instanzen déi besonnesch Eventer iwwerwaachen.
/// E puer Fäll kënnen iergendwann op panic konfiguréiert sinn.
/// Eventer sinn `clone`, `drop` oder iergendeng anonym `query`.
///
/// Crash Test Dummies ginn identifizéiert a bestallt vun enger Id, sou datt se als Schlësselen an engem BTreeMap benotzt kënne ginn.
/// D'Ëmsetzung benotzt absichtlech net op eppes definéiert am crate, ofgesinn vum `Debug` trait.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// Erstellt e Crash Test Dummy Design.Den `id` bestëmmt Uerdnung a Gläichheet vun Instanzen.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// Erstellt eng Instanz vun enger Crash Test Dummy déi registréiert wéi eng Eventer et erlieft an eventuell panics.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// Zréckkomm wéi dacks Fäll vun der Dummy gekloont goufen.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// Gitt zréck wéi dacks Fäll vun der Dummy erofgefall sinn.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// Gitt zréck wéi vill Mol Fäll vun der Dummy hiren `query` Member opgeruff hunn.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// E puer anonym Ufroen, d'Resultat vun deem ass scho ginn.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}