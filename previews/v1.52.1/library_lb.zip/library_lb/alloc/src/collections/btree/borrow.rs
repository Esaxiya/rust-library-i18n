use core::marker::PhantomData;
use core::ptr::NonNull;

/// Modeller e Widderhuelung vun enger eenzegaarteger Referenz, wann Dir wësst datt de Widderhuelung an all seng Nokommen (dh all Zeigefanger a Referenzen dovun ofgeleet) net iergendwann méi benotzt ginn, duerno wëllt Dir déi originell eenzegaarteg Referenz erëm benotzen .
///
///
/// De Prêt Checker behandelt normalerweis dëse Stacking vu Prêten fir Iech, awer e puer Kontrollflëss déi dëse Stacking erreechen sinn ze komplizéiert fir de Compiler ze verfollegen.
/// A `DormantMutRef` erlaabt Iech selwer ze léinen ze kontrolléieren, wärend Dir ëmmer nach seng gestapelt Natur ausdréckt, an de roude Zeigekode encapsuléiert fir dat ze maachen ouni ondefinéiert Verhalen.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Fannt eng eenzegaarteg Prêt, a rembourséiert se direkt.
    /// Fir de Compiler ass d'Liewensdauer vun der neier Referenz d'selwecht wéi d'Liewensdauer vun der Original Referenz, awer Dir promise fir se fir eng méi kuerz Zäit ze benotzen.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // SAFETY: mir halen de Prêt uechter 'a iwwer `_marker`, a mir stellen aus
        // nëmmen dës Referenz, sou datt et eenzegaarteg ass.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Zréck op den eenzegaartege Prêt, deen am Ufank agefaang gouf.
    ///
    /// # Safety
    ///
    /// De Widderhuelung muss opgehalen hunn, dh d'Referenz zréckginn vun `new` an all Zeigefanger a Referenzen déi dovun ofgeleet sinn, däerfen net méi benotzt ginn.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // SAFETY: eis eege Sécherheetsbedingunge bedeit datt dës Referenz erëm eenzegaarteg ass.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;