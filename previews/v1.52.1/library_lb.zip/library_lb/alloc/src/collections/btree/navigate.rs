use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Huelt temporär en anert, onverännerlecht Äquivalent vum selwechte Beräich eraus.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Fannt déi ënnerschiddlech Blatkante, déi e spezifizéierte Beräich an engem Bam ofgrenzen.
    /// Gitt entweder e Paar verschidde Grëff an de selwechte Bam oder e puer eidel Optiounen zréck.
    ///
    /// # Safety
    ///
    /// Ausser `BorrowType` ass `Immut`, benotzt net déi duplizéiert Handle fir dee selwechte KV zweemol ze besichen.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Äquivalent mat `(root1.first_leaf_edge(), root2.last_leaf_edge())` awer méi effizient.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Fannt de Pair vu Blatkante, déi e spezifescht Sortiment an engem Bam ofgrenzen.
    ///
    /// D'Resultat ass nëmme sënnvoll wann de Bam mam Schlëssel bestallt gëtt, wéi de Bam an engem `BTreeMap` ass.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // SAFETY: eise Prêtentyp ass onverännerlech.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Fannt de Pair vu Blatkante, déi e ganze Bam ofgrenzen.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Deelt eng eenzegaarteg Referenz an e puer Blatkante, déi e spezifizéierter Beräich ofgrenzen.
    /// D'Resultat sinn net eenzegaarteg Referenzen déi d (some) Mutatioun erlaben, déi musse suergfälteg benotzt ginn.
    ///
    /// D'Resultat ass nëmme sënnvoll wann de Bam mam Schlëssel bestallt gëtt, wéi de Bam an engem `BTreeMap` ass.
    ///
    ///
    /// # Safety
    /// Benotzt net déi duplizéiert Handle fir deeselwechte KV zweemol ze besichen.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Splitt eng eenzegaarteg Referenz an e puer Blatkante, déi d'ganz Palette vum Bam begrenzen.
    /// D'Resultater sinn net eenzegaarteg Referenzen déi Mutatioun erlaben (nëmme vu Wäerter), also musse mat Suergfalt benotzt ginn.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Mir duplizéieren de Root NodeRef hei-mir wäerte ni dee selwechte KV zweemol besichen, an ni mat iwwerlappende Wäertreferenzen ophalen.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Splitt eng eenzegaarteg Referenz an e puer Blatkante, déi d'ganz Palette vum Bam begrenzen.
    /// D'Resultater sinn net eenzegaarteg Referenzen, déi massiv zerstéierend Mutatioun erlaben, also musse mat der gréisster Suergfalt benotzt ginn.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Mir duplizéieren de Root NodeRef hei-mir kréien ni Zougang dozou op eng Manéier déi Referenzen aus der Root kritt iwwerlappt.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Kritt e Blat edge Grëff, bréngt [`Result::Ok`] mat engem Grëff an den Nopesch KV op der rietser Säit zréck, deen entweder am selwechte Blatknot oder an engem Virfaartknot ass.
    ///
    /// Wann d'Blat edge de leschten am Bam ass, gëtt [`Result::Err`] mam Rootknot zréck.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Gitt e Blat edge Grëff, bréngt [`Result::Ok`] mat engem Grëff zréck op den Nopesch KV op der lénkser Säit, deen entweder am selwechte Blatknot oder an engem Vorfahrenknot ass.
    ///
    /// Wann de Blat edge deen éischten am Bam ass, gëtt [`Result::Err`] mam Rootknot zréck.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Kritt en internen edge Grëff, gëtt [`Result::Ok`] mat engem Grëff an den Nopesch KV op der rietser Säit zréck, deen entweder am selwechten interne Knuet oder an engem Virfaartknäpp ass.
    ///
    /// Wann den internen edge dee leschten am Bam ass, gëtt [`Result::Err`] mam Rootknot zréck.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Gitt e Blat edge Grëff an e stierwende Bam, bréngt de nächste Blat edge op der rietser Säit zréck, an de Schlësselwäerterpaart dertëscht, wat entweder am selwechte Blatknot ass, an engem Vorfahrenknot oder net existent.
    ///
    ///
    /// Dës Method deallocéiert och all node(s), wou et um Enn ass.
    /// Dëst implizéiert datt wa kee Schlësselwäertpaar méi existéiert, de ganze Rescht vum Bam Deallokaliséiert wier an et bleift näischt méi zréck.
    ///
    /// # Safety
    /// Dee gegebenen edge däerf net virdru vum Contrepartner `deallocating_next_back` zréck ginn.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Gitt e Blat edge Grëff an e stierwende Bam, bréngt d'nächst Blat edge op der lénkser Säit zréck, an de Schlësselwäertpaart dertëscht, wat entweder am selwechte Blatknot ass, an engem Vorfahrenknot oder net existent.
    ///
    ///
    /// Dës Method deallocéiert och all node(s), wou et um Enn ass.
    /// Dëst implizéiert datt wa kee Schlësselwäertpaar méi existéiert, de ganze Rescht vum Bam Deallokaliséiert wier an et bleift näischt méi zréck.
    ///
    /// # Safety
    /// Dee gegebenen edge däerf net virdru vum Contrepartner `deallocating_next` zréck ginn.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Deallocéiert e Koup Kniet vum Blat bis op d'Wurzel.
    /// Dëst ass deen eenzege Wee fir de Rescht vun engem Bam ze verhandelen nodeems `deallocating_next` an `deallocating_next_back` op béide Säite vum Bam geknabbelt hunn an déiselwecht edge getraff hunn.
    /// Wéi et nëmme geduecht ass ze ruffen wann all Schlësselen a Wäerter zréckkoum, gëtt keng Botz op engem vun de Schlësselen oder Wäerter gemaach.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Beweegt de Blat edge Grëff op dat nächst Blat edge a bréngt Referenzen zréck op de Schlëssel a Wäert dertëscht.
    ///
    ///
    /// # Safety
    /// Et muss e weidere KV a Richtung gefuer sinn.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Beweegt de Blat edge Grëff op dat viregt Blat edge a bréngt Referenzen zréck op de Schlëssel a Wäert dertëscht.
    ///
    ///
    /// # Safety
    /// Et muss e weidere KV a Richtung gefuer sinn.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Beweegt de Blat edge Grëff op dat nächst Blat edge a bréngt Referenzen zréck op de Schlëssel a Wäert dertëscht.
    ///
    ///
    /// # Safety
    /// Et muss e weidere KV a Richtung gefuer sinn.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Dës lescht ze maachen ass méi séier, no Benchmarks.
        kv.into_kv_valmut()
    }

    /// Beweegt de Blat edge Grëff op dat viregt Blat a bréngt Referenzen zréck op de Schlëssel a Wäert dertëscht.
    ///
    ///
    /// # Safety
    /// Et muss e weidere KV a Richtung gefuer sinn.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Dës lescht ze maachen ass méi séier, no Benchmarks.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Beweegt de Blat edge Grëff op dat nächst Blat edge a bréngt de Schlëssel a Wäert dertëschent zréck a verdeelt all Node, deen hannerléisst, andeems en den entspriechenden edge a sengem Eltereknäpp hannerléisst.
    ///
    /// # Safety
    /// - Et muss e weidere KV a Richtung gefuer sinn.
    /// - Dee KV gouf net virdru vum Pendant `next_back_unchecked` zréckginn op all Kopie vun de Grëffe fir de Bam ze duerchsichen.
    ///
    /// Deen eenzege séchere Wee fir mam aktualiséierte Grëff virzegoen ass et ze vergläichen, drop ze loossen, dës Method nach eng Kéier ënner seng Sécherheetsbedingungen ze ruffen, oder den Homolog `next_back_unchecked` ënner seng Sécherheetsbedingunge ruffen.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Beweegt de Blat edge Grëff op dat viregt Blat edge a bréngt de Schlëssel a Wäert dertëschent zréck, andeems hien all Node hannerléisst deen hannerléisst, wärend den entspriechenden edge a sengem Elterenknot hannerléisst.
    ///
    /// # Safety
    /// - Et muss e weidere KV a Richtung gefuer sinn.
    /// - Dat Blat edge gouf virdrun net vum Contrepartner `next_unchecked` zréckginn op all Kopie vun de Grëffe fir de Bam ze duerchsichen.
    ///
    /// Deen eenzege séchere Wee fir mam aktualiséierte Grëff virzegoen ass et ze vergläichen, drop ze loossen, dës Method nach eng Kéier ënner seng Sécherheetsbedingungen ze ruffen, oder den Homolog `next_unchecked` ënner seng Sécherheetsbedingunge ruffen.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Gitt d'lénks lénksst Blat edge an oder ënner engem Knuet, an anere Wierder, den edge deen Dir als éischt braucht wann Dir no vir navigéiert (oder lescht wann Dir no hannen navigéiert).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Returns de rietsste Blat edge an oder ënner engem Knuet, an anere Wierder, den edge Dir braucht lescht wann Dir no vir navigéiert (oder éischt wann Dir no hannen navigéiert).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Besicht Blatknoten an intern KVs an Uerdnung vun opsteigende Schlësselen, a besicht och intern Knieter als Ganzt an enger déifster éischter Uerdnung, dat heescht datt intern Kniet virun hiren individuellen KVs an hire Kandkniet.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Berechent d'Zuel vun Elementer an engem (Ënner) Bam.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Nees de Blat edge am nootste bei engem KV fir Forward Navigatioun.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Nees de Blat edge am nootste bei engem KV fir no hannen Navigatioun.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}