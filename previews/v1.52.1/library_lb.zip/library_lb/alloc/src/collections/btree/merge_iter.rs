use core::cmp::Ordering;
use core::fmt::{self, Debug};
use core::iter::FusedIterator;

/// Kär vun engem Iterator deen den Output vun zwee streng eropsteigend Iteratoren fusionéiert, zum Beispill eng Gewerkschaft oder e symmetreschen Ënnerscheed.
///
pub struct MergeIterInner<I: Iterator> {
    a: I,
    b: I,
    peeked: Option<Peeked<I>>,
}

/// Benchmarks méi séier wéi béid Iteratoren an engem Peekable wéckelen, wahrscheinlech well mir et eis leeschte kënnen e FusedIterator gebonnen ze imposéieren.
///
#[derive(Clone, Debug)]
enum Peeked<I: Iterator> {
    A(I::Item),
    B(I::Item),
}

impl<I: Iterator> Clone for MergeIterInner<I>
where
    I: Clone,
    I::Item: Clone,
{
    fn clone(&self) -> Self {
        Self { a: self.a.clone(), b: self.b.clone(), peeked: self.peeked.clone() }
    }
}

impl<I: Iterator> Debug for MergeIterInner<I>
where
    I: Debug,
    I::Item: Debug,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("MergeIterInner").field(&self.a).field(&self.b).field(&self.peeked).finish()
    }
}

impl<I: Iterator> MergeIterInner<I> {
    /// Erstellt en neie Kär fir en Iterator deen e puer Quelle fusionéiert.
    pub fn new(a: I, b: I) -> Self {
        MergeIterInner { a, b, peeked: None }
    }

    /// Gitt d'nächst Pair vun Elementer zréck, déi aus dem Puer Quellen, déi fusionéiert ginn, stamen.
    /// Wa béid zréckgezunn Optiounen e Wäert enthalen, ass dee Wäert gläich a kënnt a béide Quellen.
    /// Wann eng vun den zréckkommten Optiounen e Wäert enthält, da kënnt dëse Wäert net an der anerer Quell vir (oder d'Quellen klammen net streng erop).
    ///
    /// Wa keng zréckgezunn Optioun e Wäert enthält, ass d'Iteratioun fäerdeg a spéider Uriff ginn déiselwecht eidel Koppel zréck.
    ///
    ///
    pub fn nexts<Cmp: Fn(&I::Item, &I::Item) -> Ordering>(
        &mut self,
        cmp: Cmp,
    ) -> (Option<I::Item>, Option<I::Item>)
    where
        I: FusedIterator,
    {
        let mut a_next;
        let mut b_next;
        match self.peeked.take() {
            Some(Peeked::A(next)) => {
                a_next = Some(next);
                b_next = self.b.next();
            }
            Some(Peeked::B(next)) => {
                b_next = Some(next);
                a_next = self.a.next();
            }
            None => {
                a_next = self.a.next();
                b_next = self.b.next();
            }
        }
        if let (Some(ref a1), Some(ref b1)) = (&a_next, &b_next) {
            match cmp(a1, b1) {
                Ordering::Less => self.peeked = b_next.take().map(Peeked::B),
                Ordering::Greater => self.peeked = a_next.take().map(Peeked::A),
                Ordering::Equal => (),
            }
        }
        (a_next, b_next)
    }

    /// Nees e puer iewescht Grenze fir den `size_hint` vum leschten Iterator.
    pub fn lens(&self) -> (usize, usize)
    where
        I: ExactSizeIterator,
    {
        match self.peeked {
            Some(Peeked::A(_)) => (1 + self.a.len(), self.b.len()),
            Some(Peeked::B(_)) => (self.a.len(), 1 + self.b.len()),
            _ => (self.a.len(), self.b.len()),
        }
    }
}