//! Eng Prioritéit Schlaang implementéiert mat engem binäre Koup.
//!
//! Insertion a Popping vum gréissten Element hunn *O*(log(*n*)) Zäit Komplexitéit.
//! Kontrolléiert dat gréisst Element *O*(1).En vector zu engem binäre Koup ëmsetzen kann op der Plaz gemaach ginn an huet *O*(*n*) Komplexitéit.
//! E binäre Koup kann och an e sortéierten vector an der Plaz ëmgewandelt ginn, sou datt et fir en *O*(*n*\*log(* n*)) in-place Heapsort benotzt ka ginn.
//!
//! # Examples
//!
//! Dëst ass e méi grousst Beispill dat [Dijkstra's algorithm][dijkstra] implementéiert fir den [shortest path problem][sssp] op engem [directed graph][dir_graph] ze léisen.
//!
//! Et weist wéi Dir [`BinaryHeap`] mat personaliséierten Typen benotzt.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // D'Prioritéit Schlaang hänkt vun `Ord` of.
//! // Explizit den trait implementéieren sou datt d'Schlaang e Minishauf gëtt amplaz e Maxheap.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Bedenkt datt mir d'Bestellung op Käschte flippen.
//!         // Am Fall vun engem Tie vergläiche mir Positiounen, dëse Schrëtt ass noutwendeg fir Implementéierunge vun `PartialEq` an `Ord` konsequent ze maachen.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` muss och ëmgesat ginn.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // All Knuet gëtt als `usize` duergestallt, fir eng méi kuerz Ëmsetzung.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Dem Dijkstra säi kierzte Wee Algorithmus.
//!
//! // Start bei `start` a benotzt `dist` fir déi aktuell kierzlech Distanz zu all Knuet ze verfollegen.Dës Ëmsetzung ass net Memory-Effizient well et duplizéiert Knieter an der Schlaang léisst.
//! //
//! // Et benotzt och `usize::MAX` als Sentinel-Wäert, fir eng méi einfach Ëmsetzung.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [node]=aktuell kierzlech Distanz vun `start` op `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Mir sinn op `start`, mat Null Käschten
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Ënnersicht d'Grenz mat méi niddrege Käschteknäpp fir d'éischt (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Alternativ hätte mer weider kuerze Weeër kënne fannen
//!         if position == goal { return Some(cost); }
//!
//!         // Wichteg well mir vläicht schonn e bessere Wee fonnt hunn
//!         if cost > dist[position] { continue; }
//!
//!         // Fir all Knuet, dee mir erreeche kënnen, kuckt ob mir e Wee fannen mat méi niddrege Käschten duerch dësen Knued
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Wa jo, füügt et un d'Grenz bäi a fuert weider
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Entspanung, mir hunn elo e bessere Wee fonnt
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Zil net erreechbar
//!     None
//! }
//!
//! fn main() {
//!     // Dëst ass déi geriicht Grafik déi mir benotzen.
//!     // D'Nodenzuelen entspriechen de verschiddene Staaten, an d'edge Gewichte symboliséieren d'Käschte fir vun engem Node an en aneren ze réckelen.
//!     //
//!     // Bedenkt datt d'Kante sinn e Wee.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // D'Grafik gëtt als eng Nopeschlëscht duergestallt wou all Index, entspriechend engem Knuetwäert, eng Lëscht mat ausgaangene Kanten huet.
//!     // Gewielt fir seng Effizienz.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Node 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Node 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Node 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Node 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Node 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Eng Prioritéit Schlaang implementéiert mat engem binäre Koup.
///
/// Dëst wäert e Max-Koup sinn.
///
/// Et ass e Logikfehler fir en Artikel esou ze modifizéieren datt d'Bestellung vum Artikel relativ zu engem aneren Element, wéi vum `Ord` trait bestëmmt, ännert sech wärend et am Koup ass.
///
/// Dëst ass normalerweis nëmme méiglech duerch `Cell`, `RefCell`, globalen Zoustand, I/O oder onsécher Code.
/// D'Verhalen, déi aus esou engem Logikfeeler entstinn, gëtt net spezifizéiert, awer wäert net zu ondefinéiertem Verhalen resultéieren.
/// Dëst kéint panics enthalen, falsch Resultater, Ofbriechen, Gedächtnislecker, an Net-Kënnegung.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Typ Inferenz léisst eis eng explizit Typ Ënnerschrëft ewechloossen (wat `BinaryHeap<i32>` an dësem Beispill wier).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Mir kënne Peek benotze fir dat nächst Element am Koup ze kucken.
/// // An dësem Fall sinn nach keng Elementer dran, also kréie mir Keen.
/// assert_eq!(heap.peek(), None);
///
/// // Loosst eis e puer Partituren derbäi ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Elo kuckt kuckt dat wichtegst Element am Koup.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Mir kënnen d'Längt vun engem Koup kontrolléieren.
/// assert_eq!(heap.len(), 3);
///
/// // Mir kënnen iwwer d'Saachen am Koup iteréieren, obwuel se an enger zoufälleger Reiefolleg zréckginn.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Wa mir dës Partituren amplaz popen, da sollten se an d'Reiung kommen.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Mir kënnen de Koup vun all verbleiwen Elementer läschen.
/// heap.clear();
///
/// // De Koup soll elo eidel sinn.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Entweder `std::cmp::Reverse` oder eng personaliséiert `Ord`-Implementatioun ka benotzt ginn fir `BinaryHeap` zu engem Minheap ze maachen.
/// Dëst mécht `heap.pop()` de klengste Wäert zréck anstatt dee gréissten.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Wrap Wäerter an `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Wa mir dës Partituren elo popen, solle se am Géigendeel kommen zréck.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Zäit Komplexitéit
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// De Wäert fir `push` ass eng erwaart Käschte;d'Method Dokumentatioun gëtt eng méi detailléiert Analyse.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Struktur wéckelt eng mutéierbar Referenz zum gréissten Element op engem `BinaryHeap`.
///
///
/// Dësen `struct` gëtt vun der [`peek_mut`] Method op [`BinaryHeap`] erstallt.
/// Kuckt seng Dokumentatioun fir méi.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // SAFETY: PeekMut gëtt nëmmen instantiéiert fir net eidel Koup.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // SAFE: PeekMut gëtt nëmmen instantiéiert fir net eidel Koup
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // SAFE: PeekMut gëtt nëmmen instantiéiert fir net eidel Koup
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Läscht de gekuckte Wäert vum Koup a bréngt et zréck.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Erstellt en eidelen `BinaryHeap<T>`.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Erstellt en eidelen `BinaryHeap` als Max-Koup.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Erstellt en eidelen `BinaryHeap` mat enger spezifescher Kapazitéit.
    /// Dëst virlokaliséiert genuch Erënnerung fir `capacity` Elementer, sou datt den `BinaryHeap` net muss nei ëmgesat ginn, bis en op d'mannst esou vill Wäerter enthält.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Gitt eng mutéierbar Referenz op de gréissten Element am binäre Koup, oder `None` wann et eidel ass.
    ///
    /// Note: Wann den `PeekMut` Wäert leckt, kann de Koup an engem inkonsistente Staat sinn.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Zäit Komplexitéit
    ///
    /// Wann den Artikel geännert gëtt, ass déi schlëmmste Fall Zäitkomplexitéit *O*(log(*n*)), soss ass et *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Läscht de gréissten Artikel aus dem binäre Koup a gitt et zréck, oder `None` wann et eidel ass.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Zäit Komplexitéit
    ///
    /// De schlëmmste Fall Käschte vun `pop` op engem Koup mat *n* Elementer ass *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // SAFETY: !self.is_empty() heescht datt self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Dréckt en Element op de binäre Koup.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Zäit Komplexitéit
    ///
    /// Déi erwuessene Käschte vun `push`, am Duerchschnëtt iwwer all méiglech Bestellung vun den Elementer déi gedréckt ginn, an iwwer eng genuch grouss Unzuel vun Dréck, ass *O*(1).
    ///
    /// Dëst ass déi bedeitendst Käschte Metrik wann Dir Elementer dréckt déi *net* schonn an engem sortéierte Muster sinn.
    ///
    /// D'Zäitkomplexitéit degradéiert wann Elementer an haaptsächlech opsteigend Uerdnung gedréckt ginn.
    /// Am schlëmmste Fall ginn Elementer an opsteigend zortéierter Uerdnung gedréckt an déi amortiséiert Käschte pro Push sinn *O*(log(*n*)) géint e Koup mat *n* Elementer.
    ///
    /// De schlëmmste Fall Käschte vun engem *eenzegen* Uruff op `push` ass *O*(*n*).De schlëmmste Fall geschitt wann d'Kapazitéit erschöpft ass an eng Gréisst ännert.
    /// D'Gréisstekäschte goufen an de fréiere Figuren amortiséiert.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // SAFETY: Well mir en neit Element gedréckt hunn, heescht dat
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Verbraucht den `BinaryHeap` a bréngt en vector a sortéierter (ascending) Uerdnung zréck.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // SAFETY: `end` geet vun `self.len() - 1` op 1 (béid abegraff),
            //  also ass et ëmmer e gültegen Index fir Zougang ze kréien.
            //  Et ass sécher Zougang zum Index 0 (dh `ptr`), well
            //  1 <=Enn <self.len(), dat heescht self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // SAFETY: `end` geet vun `self.len() - 1` op 1 (béid abegraff) sou:
            //  0 <1 <=Enn <= self.len(), 1 <self.len() Dat heescht 0 <Enn an Enn <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // D'Ëmsetzung vu sift_up a sift_down benotzt onsécher Blocen fir en Element aus dem vector ze réckelen (e Lach hannerloossen), verréckelt laanscht déi aner a réckelt dat ewechgeholl Element zréck an d'vector op der leschter Plaz vum Lach.
    //
    // Den `Hole` Typ gëtt benotzt fir dëst duerzestellen, a gitt sécher datt d'Lach um Enn vu sengem Ëmfang zréckgefëllt ass, och op panic.
    // Mat engem Lach reduzéiert de konstante Faktor am Verglach mat Swaps, wat duebel sou vill Bewegunge involvéiert.
    //
    //
    //
    //

    /// # Safety
    ///
    /// De Ringer muss dee `pos < self.len()` garantéieren.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Huelt de Wäert bei `pos` eraus a schaaft e Lach.
        // SAFETY: Den Uruff garantéiert datt pos <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // SAFETY: hole.pos()> start>=0, dat heescht hole.pos()> 0
            //  an esou hole.pos(), 1 kann net ënnersträichen.
            //  Dëst garantéiert dat Elterendeel <hole.pos() also ass et e gültegen Index an och!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // SAFETY: Selwecht wéi uewen
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Huelt en Element bei `pos` a réckelt et de Koup erof, wärend seng Kanner méi grouss sinn.
    ///
    ///
    /// # Safety
    ///
    /// De Ringer muss dee `pos < end <= self.len()` garantéieren.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // SAFETY: Den Uruff garantéiert datt pos <end <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loop invariant: Kand==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // vergläiche mat der grousser vun den zwee Kanner SIKKERHET: Kand <Enn, 1 <self.len() a Kand + 1 <Enn <= self.len(), also si gëlteg Indexen.
            //
            //  Kand==2 *hole.pos() + 1!= hole.pos() a Kand + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 oder 2* hole.pos() + 2 kéint iwwerschwemmen wann T en ZST ass
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // wa mir schonn an der Rei sinn, stoppt.
            // SAFETY: Kand ass elo entweder dat aalt Kand oder dat aalt Kand + 1
            //  Mir hu scho bewisen datt béid <self.len() an!= hole.pos() sinn
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // SAFETY: d'selwecht wéi uewen.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // SAFETY: &&Kuerzzäit, dat heescht datt an der
        //  zweet Bedingung et ass scho wouer dat Kand==Enn, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // SAFETY: Kand ass scho bewisen e gültegen Index ze sinn an
            //  Kand==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// De Ringer muss dee `pos < self.len()` garantéieren.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // SAFETY: pos <len ass garantéiert vum Uruff an
        //  offensichtlech len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Huelt en Element bei `pos` a réckelt et de ganze Koup erof, sift et dann op seng Positioun.
    ///
    ///
    /// Note: Dëst ass méi séier wann d'Element bekannt ass grouss ze sinn/méi no um Buedem soll sinn.
    ///
    /// # Safety
    ///
    /// De Ringer muss dee `pos < self.len()` garantéieren.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // SAFETY: Den Uruff garantéiert datt pos <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loop invariant: Kand==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // SAFETY: Kand <Enn, 1 <self.len() an
            //  Kand + 1 <Enn <= self.len(), also si gëlteg Indexen.
            //  Kand==2 *hole.pos() + 1!= hole.pos() a Kand + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 oder 2* hole.pos() + 2 kéint iwwerschwemmen wann T en ZST ass
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // SAFETY: Selwecht wéi uewen
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // SAFETY: Kand==Enn, 1 <self.len(), also ass et e gültegen Index
            //  a Kand==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // SAFETY: pos ass d'Positioun am Lach a war scho bewisen
        //  e gültegen Index ze sinn.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // SAFETY: n fänkt vum self.len()/2 un a geet erof op 0.
            //  Deen eenzege Fall wann! (N <self.len()) ass wann self.len() ==0, awer et ass ausgeschloss vum Loop Zoustand.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Beweegt all d'Elementer vun `other` an `self`, léisst `other` eidel.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` hëlt O(len1 + len2) Operatiounen an ongeféier 2 *(len1 + len2) Vergläicher am schlëmmste Fall wärend `extend` O(len2* log(len1)) Operatiounen hëlt an ongeféier 1 *len2* log_2(len1) Vergläicher am schlëmmste Fall, unzehuelen len1>= len2.
        // Fir méi grouss Koup geet de Crossover Punkt net méi no dësem Raisonnement a gouf empiresch bestëmmt.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Nees en Iterator deen Elementer a Koup Reiefolleg erëmfënnt.
    /// Déi erëmfonnt Elementer ginn aus dem Original Koup erausgeholl.
    /// Déi reschtlech Elementer ginn op Drop an der Koupbestellung ofgeschaaft.
    ///
    /// Note:
    /// * `.drain_sorted()` ass *O*(*n*\*log(* n*)); vill méi lues wéi `.drain()`.
    ///   Dir sollt déi lescht fir déi meescht Fäll benotzen.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // läscht all Elementer a Koupbestellung
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Hält nëmmen d'Elementer déi vum Prädikat spezifizéiert sinn.
    ///
    /// An anere Wierder, ewechzehuelen all Elementer `e` sou datt `f(&e)` zréck `false`.
    /// D'Elementer ginn an onsortéierter (an net spezifizéierter) Uerdnung besicht.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // halen nëmmen och Zuelen
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Nees en Iterator deen all Wäerter an der Basis vector besicht, an arbiträrer Uerdnung.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Dréckt 1, 2, 3, 4 an arbiträrer Uerdnung
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Nees en Iterator deen Elementer a Koup Reiefolleg erëmfënnt.
    /// Dës Method verbraucht den originale Koup.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Gitt de gréissten Element am binäre Koup zréck, oder `None` wann et eidel ass.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Zäit Komplexitéit
    ///
    /// Käschte sinn *O*(1) am schlëmmste Fall.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Gitt d'Zuel vun Elementer zréck, déi de binäre Koup hale kann ouni nei z'allokaliséieren.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Reservéiert d'Mindestkapazitéit fir genau `additional` méi Elementer an de gegebene `BinaryHeap` ze setzen.
    /// Maacht näischt wann d'Kapazitéit scho genuch ass.
    ///
    /// Bedenkt datt d'Allocator der Sammlung méi Plaz ka ginn wéi se gefrot.
    /// Dofir kann d'Kapazitéit net drop verloossen datt se präzis minimal ass.
    /// Léiwer [`reserve`] wann future Insertions erwaart ginn.
    ///
    /// # Panics
    ///
    /// Panics wann déi nei Kapazitéit iwwer `usize` iwwerschwemmt.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Reservéiert Kapazitéit fir op d'mannst `additional` méi Elementer fir an den `BinaryHeap` anzesetzen.
    /// D'Kollektioun ka méi Plaz reservéieren fir heefeg Ëmverdeelungen ze vermeiden.
    ///
    /// # Panics
    ///
    /// Panics wann déi nei Kapazitéit iwwer `usize` iwwerschwemmt.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Verwerft sou vill zousätzlech Kapazitéit wéi méiglech.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Verwerft Kapazitéit mat enger ënneschter Grenz.
    ///
    /// D'Kapazitéit bleift op d'mannst sou grouss wéi d'Längt an de geliwwertene Wäert.
    ///
    ///
    /// Wann déi aktuell Kapazitéit manner wéi déi ënnescht Grenz ass, ass dat en No-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Verbraucht den `BinaryHeap` a bréngt de Basis vector an arbiträrer Uerdnung zréck.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Wäert an e puer Reiefolleg drécken
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Gitt d'Längt vum binäre Koup zréck.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Kontrolléiert ob de binäre Koup eidel ass.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Läscht de binäre Koup, bréngt en Iterator iwwer déi ewechgeholl Elementer zréck.
    ///
    /// D'Elementer ginn an arbiträrer Uerdnung ewechgeholl.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Drops all Elementer aus dem binäre Koup.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Lach stellt e Lach an engem Stéck duer, dh en Index ouni valabele Wäert (well e geplënnert ass oder duplizéiert).
///
/// Am Drop wäert d `Hole` d'Scheif restauréieren andeems se d'Lachpositioun mam Wäert fëllt deen ursprénglech ewechgeholl gouf.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Erstellt en neien `Hole` beim Index `pos`.
    ///
    /// Onsécher well Pos muss bannent der Dateschnitt sinn.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // SECHER: pos soll an der Scheif sinn
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Retourns eng Referenz zum Element ewechgeholl.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Nees eng Referenz zum Element bei `index`.
    ///
    /// Onsécher well den Index muss bannent der Dateschnitt sinn an net gläich wéi pos.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Réckelt Lach op nei Plaz
    ///
    /// Onsécher well den Index muss bannent der Dateschnitt sinn an net gläich wéi pos.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // fëllt d'Lach erëm
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// En Iterator iwwer d'Elementer vun engem `BinaryHeap`.
///
/// Dësen `struct` gëtt vum [`BinaryHeap::iter()`] erstallt.
/// Kuckt seng Dokumentatioun fir méi.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Ewechzehuelen zugonschte vun `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// E Besëtzer Iterator iwwer d'Elementer vun engem `BinaryHeap`.
///
/// Dësen `struct` gëtt vum [`BinaryHeap::into_iter()`] erstallt (geliwwert vum `IntoIterator` trait).
/// Kuckt seng Dokumentatioun fir méi.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// En draining Iterator iwwer d'Elementer vun engem `BinaryHeap`.
///
/// Dësen `struct` gëtt vum [`BinaryHeap::drain()`] erstallt.
/// Kuckt seng Dokumentatioun fir méi.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// En draining Iterator iwwer d'Elementer vun engem `BinaryHeap`.
///
/// Dësen `struct` gëtt vum [`BinaryHeap::drain_sorted()`] erstallt.
/// Kuckt seng Dokumentatioun fir méi.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Läscht Haapelementer a Koupuerdnung.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Konvertéiert en `Vec<T>` an en `BinaryHeap<T>`.
    ///
    /// Dës Konversioun geschitt op der Plaz an huet *O*(*n*) Zäitkomplexitéit.
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Konvertéiert en `BinaryHeap<T>` an en `Vec<T>`.
    ///
    /// Dës Konversioun erfuerdert keng Datenbewegung oder Allokatioun, an huet konstant Zäitkomplexitéit.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Erstellt e verbrauchenden Iterator, dat ass, deen all Wäert aus dem binäre Koup a arbiträrer Uerdnung réckelt.
    /// De binäre Koup kann net benotzt ginn nodeems hien dëst geruff huet.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Dréckt 1, 2, 3, 4 an arbiträrer Uerdnung
    /// for x in heap.into_iter() {
    ///     // x huet den Typ i32, net &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}