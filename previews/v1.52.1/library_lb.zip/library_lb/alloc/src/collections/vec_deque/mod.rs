//! Eng duebelstänneg Schlaang implementéiert mat engem wuessbaren Ringbuffer.
//!
//! Dës Schlaang huet *O*(1) amortiséiert Inserts an Entféierung vu béide Säite vum Container.
//! Et huet och *O*(1) indexéiert wéi en vector.
//! Déi enthale Elementer sinn net erfuerderlech kopéierbar ze sinn, an d'Schlaang gëtt verschéckt wann den enthale Typ sendbar ass.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // Gréissten méiglech Kraaft vun zwee

/// Eng duebelstänneg Schlaang implementéiert mat engem wuessbaren Ringbuffer.
///
/// D "default" Benotzung vun dësem Typ als Schlaang ass d [`push_back`] ze benotzen fir an d'Schlaang bäizefügen, an d [`pop_front`] fir aus der Schlaang ze läschen.
///
/// [`extend`] an [`append`] dréckt op d'Réck op dës Manéier, an iteréieren iwwer `VecDeque` geet vir.
///
/// Zënter `VecDeque` ass e Ruffpuffer, seng Elementer sinn net onbedéngt an der Erënnerung uneneegruff.
/// Wann Dir op d'Elementer als eenzeg Scheif zougräife wëllt, wéi zum Beispill fir effizient Zortéieren, kënnt Dir [`make_contiguous`] benotzen.
/// Et rotéiert den `VecDeque` sou datt seng Elementer net wéckelen, a bréngt e verännerbaart Stéck an déi elo zesummenhängend Elementssequenz zréck.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // Schwanz a Kapp sinn Uweiser an de Puffer.
    // Schwänz weist ëmmer op dat éischt Element dat gelies konnt ginn, Kapp weist ëmmer op wou Date geschriwwe solle ginn.
    //
    // Wann Schwänz==Kapp ass de Puffer eidel.D'Längt vum Ringbuffer gëtt definéiert wéi d'Distanz tëscht deenen zwee.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// Féiert den Destructor fir all Elementer an der Scheif wann et fällt (normalerweis oder beim Ofwéckelen).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // benotzen Drop fir [T]
            ptr::drop_in_place(front);
        }
        // RawVec behandelt Deallocation
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// Erstellt en eidelen `VecDeque<T>`.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// Marginal méi praktesch
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// Marginal méi praktesch
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // Fir Nullgréisst Zorten si mir ëmmer mat maximaler Kapazitéit
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// Maacht Ptr an e Stéck
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// Maacht Ptr an eng Mut Scheif
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// Beweegt en Element aus dem Puffer
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// Schreift en Element an de Puffer, réckelt et.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// Retour `true` wann de Puffer op voller Kapazitéit ass.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// Nees den Index am Basispuffer fir e bestëmmte logescht Element Index.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// Nees den Index am Basispuffer fir e bestëmmte logescht Element Index + Addend.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// Nees den Index am Basispuffer fir e bestëmmte logescht Element Index, subtrahend.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// Kopéiert e kontinuéierleche Block vum Gedächtnis Len laang vun src op dst
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Kopéiert e kontinuéierleche Block vum Gedächtnis Len laang vun src op dst
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Kopéiert e potenziell Wéckelblock vum Gedächtnis Len laang vun src op Dest.
    /// (abs(dst - src) + len) däerf net méi grouss si wéi cap() (Et muss héchstens eng kontinuéierlech iwwerlappend Regioun tëscht src an Dest sinn).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src wéckelt net, dst wéckelt net
                //
                //        S...
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] D.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // dst virum src, src wéckelt net, dst wéckelt
                //
                //
                //    S...
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. D.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // src virun dst, src wéckelt net, dst wéckelt
                //
                //
                //              S...
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. D.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // dst virum src, src wéckelt, dst wéckelt net
                //
                //
                //    .. S.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] D...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // src virun dst, src wéckelt, dst wéckelt net
                //
                //
                //    .. S.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] D...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // dst virum src, src wéckelt, dst wéckelt
                //
                //
                //    ... S.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. D..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // src virun dst, src wéckelt, dst wéckelt
                //
                //
                //    .. S..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... D.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// Frobs de Kapp a Schwanz Sektiounen ronderëm fir de Fakt ze handhaben datt mir eis just nei ëmgesat hunn.
    /// Onsécher well et alt_Kapazitéit vertraut.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // Beweegt de kürzeste kontinuéierlech Sektioun vum Réngbuffer TH
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [...ooooooo......
        //          ] HT
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // A Nop
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// Erstellt en eidelen `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// Erstellt en eidelen `VecDeque` mat Plaz fir op d'mannst `capacity` Elementer.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 well de Ringbuffer ëmmer e Raum eidel léisst
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// Gitt eng Referenz zum Element am gegebene Index.
    ///
    /// Element am Index 0 ass d'Front vun der Schlaang.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Bitt eng mutéierbar Referenz zum Element am gegebene Index.
    ///
    /// Element am Index 0 ass d'Front vun der Schlaang.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Tauscht Elementer op Indizes `i` an `j`.
    ///
    /// `i` an `j` kënne gläich sinn.
    ///
    /// Element am Index 0 ass d'Front vun der Schlaang.
    ///
    /// # Panics
    ///
    /// Panics wann entweder Index ausser Grenzen ass.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// Gitt d'Zuel vun den Elementer zréck, déi den `VecDeque` kann halen ouni nei ze verdeelen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// Reservéiert d'Mindestkapazitéit fir genau `additional` méi Elementer an de gegebene `VecDeque` anzesetzen.
    /// Maacht näischt wann d'Kapazitéit scho genuch ass.
    ///
    /// Bedenkt datt d'Allocator der Sammlung méi Plaz ka ginn wéi se gefrot.
    /// Dofir kann d'Kapazitéit net drop verloossen datt se präzis minimal ass.
    /// Léiwer [`reserve`] wann future Insertions erwaart ginn.
    ///
    /// # Panics
    ///
    /// Panics wann déi nei Kapazitéit iwwer `usize` iwwerschwemmt.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// Reservéiert Kapazitéit fir op d'mannst `additional` méi Elementer fir an de gegebene `VecDeque` anzesetzen.
    /// D'Kollektioun ka méi Plaz reservéieren fir heefeg Ëmverdeelungen ze vermeiden.
    ///
    /// # Panics
    ///
    /// Panics wann déi nei Kapazitéit iwwer `usize` iwwerschwemmt.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// Probéiert déi Mindestkapazitéit ze reservéieren fir genau `additional` méi Elementer an de gegebene `VecDeque<T>` ze setzen.
    ///
    /// Nodeems Dir `try_reserve_exact` ugeruff hutt, wäert d'Kapazitéit méi grouss wéi oder gläich wéi `self.len() + additional` sinn.
    /// Maacht näischt wann d'Kapazitéit scho genuch ass.
    ///
    /// Bedenkt datt d'Allocator der Sammlung méi Plaz ka ginn wéi se gefrot.
    /// Dofir kann d'Kapazitéit net drop verloossen datt se präzis minimal ass.
    /// Léiwer `reserve` wann future Insertions erwaart ginn.
    ///
    /// # Errors
    ///
    /// Wann d'Kapazitéit `usize` iwwerschwemmt, oder den Allocator e Feeler bericht, da gëtt e Feeler zréckginn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Reservéiert d'Erënnerung viraus, wann Dir net kënnt
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Elo wësse mer datt dëst net OOM(Out-Of-Memory) an der Mëtt vun eiser komplexer Aarbecht kann
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // ganz komplizéiert
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// Probéiert d'Kapazitéit ze reservéieren fir op d'mannst `additional` méi Elementer an de gegebene `VecDeque<T>` ze setzen.
    /// D'Kollektioun ka méi Plaz reservéieren fir heefeg Ëmverdeelungen ze vermeiden.
    /// Nodeems Dir `try_reserve` ugeruff hutt, wäert d'Kapazitéit méi grouss wéi oder gläich wéi `self.len() + additional` sinn.
    /// Maacht näischt wann d'Kapazitéit scho genuch ass.
    ///
    /// # Errors
    ///
    /// Wann d'Kapazitéit `usize` iwwerschwemmt, oder den Allocator e Feeler bericht, da gëtt e Feeler zréckginn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Reservéiert d'Erënnerung viraus, wann Dir net kënnt
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Elo wësse mer datt dëst net OOM kann an der Mëtt vun eiser komplexer Aarbecht
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // ganz komplizéiert
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// Schrëft d'Kapazitéit vum `VecDeque` sou vill wéi méiglech.
    ///
    /// Et fällt sou no wéi méiglech un d'Längt erof awer den Allocator kann den `VecDeque` nach matdeelen datt et Plaz fir e puer weider Elementer ass.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// Schrëft d'Kapazitéit vum `VecDeque` mat enger méi niddereger Grenz.
    ///
    /// D'Kapazitéit bleift op d'mannst sou grouss wéi d'Längt an de geliwwertene Wäert.
    ///
    ///
    /// Wann déi aktuell Kapazitéit manner wéi déi ënnescht Grenz ass, ass dat en No-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // Mir hu keng Suergen iwwer en Iwwerlaf well weder `self.len()` nach `self.capacity()` kann jeemools `usize::MAX` sinn.
        // +1 well de Ringbuffer ëmmer e Raum eidel léisst.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // Et ginn dräi Fäll vun Interesse:
            //   All Elementer sinn aus de gewënschte Grenzen Elementer sinn ugrenzend, an de Kapp ass aus de gewënschte Grenzen Elementer sinn onbedéngt, an de Schwanz ass aus de gewënschte Grenzen
            //
            //
            // Zu allen aneren Zäiten sinn Elementpositiounen net beaflosst.
            //
            // Weist datt Elementer um Kapp geréckelt solle ginn.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // Elementer aus de gewënschte Grenze réckelen (Positiounen nom target_cap)
            if self.tail >= target_cap && head_outside {
                // TH
                //   [. . . . . . . . o o o o o o o . ]
                //    TH
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // TH
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// Verkierzt den `VecDeque`, hält déi éischt `len` Elementer an de Rescht falen.
    ///
    ///
    /// Wann `len` méi grouss ass wéi déi aktuell VecDeque Längt, huet dat keen Effekt.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// Féiert den Destructor fir all Elementer an der Scheif wann et fällt (normalerweis oder beim Ofwéckelen).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // Sécher well:
        //
        // * All Slice déi op `drop_in_place` weiderginn ass gëlteg;den zweete Fall huet `len <= front.len()` an zréck op `len > self.len()` suergt `begin <= back.len()` am éischte Fall
        //
        // * De Kapp vun der VecDeque gëtt geréckelt ier en `drop_in_place` urufft, sou datt kee Wäert zweemol fale gelooss gëtt wann `drop_in_place` panics
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // Gitt sécher datt déi zweet Halschent fale gelooss gëtt och wann en Zerstéierer an der éischter panics.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// Nees e Front-to-Back Iterator.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// Gitt e Front-to-Back Iterator zréck, dee mutéierbar Referenzen zréckbréngt.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // SIKKERHET: Den internen `IterMut` Sécherheetsinvariant gëtt etabléiert well den
        // `ring` mir kreéieren ass eng dereferenzbar Scheif fir d'Liewen '_.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Gitt e puer Scheiwen zréck, déi, an Uerdnung, den Inhalt vum `VecDeque` enthalen.
    ///
    /// Wann [`make_contiguous`] virdru genannt gouf, sinn all Elementer vum `VecDeque` an der éischter Scheif an déi zweet Scheif ass eidel.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// Gitt e puer Scheiwen zréck, déi, an Uerdnung, den Inhalt vum `VecDeque` enthalen.
    ///
    /// Wann [`make_contiguous`] virdru genannt gouf, sinn all Elementer vum `VecDeque` an der éischter Scheif an déi zweet Scheif ass eidel.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// Gitt d'Zuel vun Elementer am `VecDeque` zréck.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// Retour `true` wann den `VecDeque` eidel ass.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// Erstellt en Iterator deen de spezifizéierte Beräich am `VecDeque` deckt.
    ///
    /// # Panics
    ///
    /// Panics wann de Startpunkt méi grouss ass wéi den Endpunkt oder wann den Endpunkt méi grouss ass wéi d'Längt vum vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // Eng ganz Palette deckt all Inhalter
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // Déi gemeinsam Referenz déi mir am &self hunn ass am '_ vun Iter gepflegt.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// Erstellt en Iterator deen de spezifizéierte mutabele Beräich am `VecDeque` deckt.
    ///
    /// # Panics
    ///
    /// Panics wann de Startpunkt méi grouss ass wéi den Endpunkt oder wann den Endpunkt méi grouss ass wéi d'Längt vum vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // Eng ganz Palette deckt all Inhalter
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // SIKKERHET: Den internen `IterMut` Sécherheetsinvariant gëtt etabléiert well den
        // `ring` mir kreéieren ass eng dereferenzbar Scheif fir d'Liewen '_.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Erstellt en drainaire Iterator deen de spezifizéierte Beräich am `VecDeque` läscht an déi ewechgeholl Artikele gëtt.
    ///
    /// Notiz 1: D'Elementberäich gëtt ofgeschaaft och wann den Iterator net bis zum Enn verbraucht gëtt.
    ///
    /// Notiz 2: Et ass net spezifizéiert wéi vill Elementer aus der Dekke erausgeholl ginn, wann de `Drain` Wäert net fale gelooss gëtt, awer de Prêt deen en hält ofleeft (zB wéinst `mem::forget`).
    ///
    ///
    /// # Panics
    ///
    /// Panics wann de Startpunkt méi grouss ass wéi den Endpunkt oder wann den Endpunkt méi grouss ass wéi d'Längt vum vector.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // Eng ganz Palette läscht all Inhalter
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // Erënnerung Sécherheet
        //
        // Wann den Drain als éischt erstallt gëtt, gëtt d'Source-Deque verkierzt fir sécher ze sinn datt keng net-initialiséiert oder geplënnert-vun Elementer iwwerhaapt zougänglech sinn wann den Drain Zerstéierer ni leeft.
        //
        //
        // Drain wäert d'Wäerter ptr::read eraushuelen fir ze läschen.
        // Wann Dir fäerdeg sidd, ginn déi verbleiwen Daten zréck kopéiert fir d'Lach ze decken, an d head/tail Wäerter ginn korrekt restauréiert.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // D'Elemente vun der Deque sinn an dräi Segmenter getrennt:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // T= self.tail;H= self.head;t=drain_tail;h=drain_head
        //
        // Mir späichere drain_tail als self.head, an drain_head an self.head als After_tail respektiv After_head op der Drain.
        // Dëst trunkéiert och den effektiven Array sou datt wann den Drain ausgeliwwert gëtt, hu mir iwwer déi potenziell geréckte Wäerter nom Ufank vum drain vergiess.
        //
        //
        //        T th H
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" iwwer d'Wäerter nom Ufank vum drain bis nom drain fäerdeg ass an den Drain Destructor leeft.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // Entscheedend kreéiere mir nëmmen gedeelt Referenzen vun `self` hei a liesen doraus.
                // Mir schreiwe weder op `self` nach nei op eng mutéierbar Referenz.
                // Dofir bleift de roude Zeiger, deen mir uewen erstallt hunn, fir `deque`, gëlteg.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// Läscht den `VecDeque`, ewechzehuelen all Wäerter.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// Retour `true` wann den `VecDeque` en Element enthält gläich dem gegebene Wäert.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// Gitt eng Referenz op dat viischt Element, oder `None` wann den `VecDeque` eidel ass.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// Bitt eng mutéierbar Referenz op dat viischt Element, oder `None` wann den `VecDeque` eidel ass.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// Bitt eng Referenz zum Réckelement, oder `None` wann den `VecDeque` eidel ass.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// Bitt eng mutéierbar Referenz zum Réckelement, oder `None` wann den `VecDeque` eidel ass.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// Läscht dat éischt Element zréck a gëtt et zréck, oder `None` wann den `VecDeque` eidel ass.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// Läscht dat lescht Element vum `VecDeque` zréck a gëtt et zréck, oder `None` wann et eidel ass.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// Bereet en Element op den `VecDeque` vir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// Füügt en Element op der Récksäit vum `VecDeque` bäi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: Solle mir `head == 0` als heeschen
        // datt den `self` ugestouss ass?
        self.tail <= self.head
    }

    /// Läscht en Element vun iwwerall an der `VecDeque` a bréngt et zréck, ersat duerch dat éischt Element.
    ///
    ///
    /// Dëst behält d'Bestellung net, awer ass *O*(1).
    ///
    /// Retour `None` wann `index` ausser Grenzen ass.
    ///
    /// Element am Index 0 ass d'Front vun der Schlaang.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// Läscht en Element vun iwwerall an der `VecDeque` a bréngt et zréck, ersetzt et mam leschten Element.
    ///
    ///
    /// Dëst behält d'Bestellung net, awer ass *O*(1).
    ///
    /// Retour `None` wann `index` ausser Grenzen ass.
    ///
    /// Element am Index 0 ass d'Front vun der Schlaang.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// Setzt en Element bei `index` am `VecDeque` an, verschéckt all Elementer mat Indizes méi wéi oder gläich wéi `index` no hannen.
    ///
    ///
    /// Element am Index 0 ass d'Front vun der Schlaang.
    ///
    /// # Panics
    ///
    /// Panics wann `index` méi grouss ass wéi "VecDeque" Längt
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // Beweegt déi mannst Unzuel vun Elementer am Réngbuffer a setzt dee gegebenen Objet an
        //
        // Héchstens len/2 ginn 1 Elementer geréckelt. O(min(n, n-i))
        //
        // Et ginn dräi Haaptfäll:
        //  Elementer sinn noeneen
        //      - speziellen Fall wann de Schwanz 0 ass Elementer sinn onbedéngt an de Insert ass an der Schwanzsektioun Elementer sinn diskontigu an den Insert ass am Kappdeel
        //
        //
        // Fir jiddereen dovun sinn et zwee weider Fäll:
        //  Insert ass méi no beim Schwanz Insert ass méi no beim Kapp
        //
        // Schlëssel: H, self.head
        //      T, self.tail o, Gülteg Element I, Insertion Element A, D'Element dat nom Insertionspunkt M sollt sinn, Indizéiert Element gouf geréckelt
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [A oooooo.......
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // ugrenzend, setzt méi no beim Schwanz an:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           TH
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // ugestouss, setzt méi no beim Schwanz an de Schwanz ass 0:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       MM

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // Scho de Schwanz geréckelt, sou datt mir nëmmen `index - 1` Elementer kopéieren.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // ugrenzend, setzt méi no beim Kapp:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o I A o o . . . . .]
                    //                       MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // onopfälleg, méi no beim Schwanz, Schwanzsektioun asetzen:
                    //
                    //                   HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // onopfälleg, méi no beim Kapp, Schwanzsektioun asetzen:
                    //
                    //           HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       MMMM

                    // kopéiert Elementer bis zum neie Kapp
                    self.copy(1, 0, self.head);

                    // kopéiert lescht Element op eidel Plaz um Enn vum Puffer
                    self.copy(0, self.cap() - 1, 1);

                    // réckelt Elementer vun idx bis Enn no vir net abegraff ^ Element
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // onopfälleg, Insert ass méi no beim Schwanz, Kappsektioun, an ass um Index Null am internen Puffer:
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               MMM

                    // kopéiert Elementer bis nei Schwänz
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // kopéiert lescht Element op eidel Plaz um Enn vum Puffer
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // onopfälleg, méi no un de Schwanz setzen, Kappdeel:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       MMMMMM

                    // kopéiert Elementer bis nei Schwänz
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // kopéiert lescht Element op eidel Plaz um Enn vum Puffer
                    self.copy(self.cap() - 1, 0, 1);

                    // réckelt Elementer vun idx-1 bis Enn vir net mat ^ Element
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // diskontigu, Insert méi no beim Kapp, Kapp Sektioun:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // Schwanz kéint gewiesselt ginn also musse mir nei rechnen
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// Ewechzehuelen an zréck Element op `index` aus `VecDeque`.
    /// Egal wéi en Enn méi no beim Entféierungspunkt ass, gëtt geréckelt fir Plaz ze maachen, an all déi betraff Elementer ginn op nei Positioune geréckelt.
    ///
    /// Retour `None` wann `index` ausser Grenzen ass.
    ///
    /// Element am Index 0 ass d'Front vun der Schlaang.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // Et ginn dräi Haaptfäll:
        //  Elementer sinn ugrenzend Elementer sinn onbedéngt an d'Entféierung ass an der Schwanzsektioun Elementer sinn onbedéngt an d'Entféierung ass am Kappdeel
        //
        //      - speziellen Fall wann Elementer technesch aneneegräifend sinn, awer self.head =0
        //
        // Fir jiddereen dovun sinn et zwee weider Fäll:
        //  Insert ass méi no beim Schwanz Insert ass méi no beim Kapp
        //
        // Schlëssel: H, self.head
        //      T, self.tail o, Gülteg Element x, Element markéiert fir d'Ewechhuele R, Weist Element wat ewechgeholl gëtt M, Weist Element gouf geréckelt
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // ugestouss, méi no beim Schwanz ewechhuelen:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               TH
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // ugestouss, méi no beim Kapp ewechhuelen:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // onopfälleg, méi no beim Schwanz ewechhuelen, Schwanzsektioun:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // onopfälleg, méi no beim Kapp ewechhuelen, Kappsektioun:
                    //
                    //               RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // onopfälleg, méi no beim Kapp ewechhuelen, Schwanzsektioun:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       MMMM
                    //
                    // oder quasi onbedéngt, nieft dem Kapp ewechhuelen, Schwanzsektioun:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         TH
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // zéien an Elementer an der Schwanzsektioun
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // Verhënnert Ënnerstroum.
                    if self.head != 0 {
                        // kopéiert éischt Element op eidel Plaz
                        self.copy(self.cap() - 1, 0, 1);

                        // bewegt Elementer am Kappdeel no hannen
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // onopfälleg, méi no beim Schwanz ewechhuelen, Kappdeel:
                    //
                    //           RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       MMMMM

                    // zitt an Elementer bis zu idx
                    self.copy(1, 0, idx);

                    // kopéiert lescht Element op eidel Plaz
                    self.copy(0, self.cap() - 1, 1);

                    // réckelt Elementer vum Schwanz zum Enn vir, ausser dee leschten
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// Deelt den `VecDeque` an zwee am gegebene Index.
    ///
    /// Nees eng nei zougewisen `VecDeque`.
    /// `self` enthält Elementer `[0, at)`, an déi zréckgesate `VecDeque` enthält Elementer `[at, len)`.
    ///
    /// Bedenkt datt d'Kapazitéit vum `self` net ännert.
    ///
    /// Element am Index 0 ass d'Front vun der Schlaang.
    ///
    /// # Panics
    ///
    /// Panics wann `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` läit an der éischter Halschent.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // huelt just all vun der zweeter Halschent.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` läit an der zweeter Halschent, muss d'Elementer faktoréieren, déi mir an der éischter Halschent iwwersprongen hunn.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // Botz wou d'Enn vun de Puffer sinn
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// Beweegt all d'Elementer vun `other` an `self`, léisst `other` eidel.
    ///
    /// # Panics
    ///
    /// Panics wann déi nei Unzuel vun Elementer a sech selwer en `usize` iwwerschwemmt.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // naiv impl
        self.extend(other.drain(..));
    }

    /// Hält nëmmen d'Elementer déi vum Prädikat spezifizéiert sinn.
    ///
    /// An anere Wierder, ewechzehuelen all Elementer `e` sou datt `f(&e)` falsch zréck.
    /// Dës Method funktionnéiert op der Plaz, besicht all Element genau eemol an der ursprénglecher Uerdnung, a behält d'Bestellung vun den erhalen Elementer.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// Déi exakt Uerdnung kann nëtzlech sinn fir den externen Zoustand ze verfollegen, wéi en Index.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // Dëst kann panic oder ofbriechen
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // Verduebelt d'Buffer Gréisst.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// Modifizéiert den `VecDeque` op der Plaz, sou datt den `len()` dem `new_len` gläich ass, entweder andeems iwwerflësseg Elementer vum Réck ewechgeholl ginn oder andeems Dir Elementer ergänzt andeems se `generator` op de Réck ruffen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// Arrangéiert d'intern Lagerung vun dëser Deque sou datt et eng kontinuéierlech Scheif ass, déi duerno zréck gëtt.
    ///
    /// Dës Method verdeelt net an ännert net den Optrag vun den agefouerten Elementer.Wéi et e mutéierbaart Stéck zréckbréngt, kann dëst benotzt ginn fir eng Deque ze sortéieren.
    ///
    /// Wann d'intern Speicherung noeneen ass, ginn d [`as_slices`] an d [`as_mut_slices`] Methoden de ganzen Inhalt vum `VecDeque` an engem eenzegen Slice zréck.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// Den Inhalt vun enger Deque ze sortéieren.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // sortéieren vun der deque
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // sortéiert se am Géigendeel
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// Onverännerlechen Zougank zur kontinuéierter Scheif kréien.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // mir kënnen elo sécher sinn datt `slice` all Elementer vun der Deck enthält, wärend ëmmer onverännerbar Zougang zu `buf`.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // et gëtt genuch fräie Raum fir de Schwanz op eemol ze kopéieren, dat heescht datt mir de Kapp fir d'éischt no hannen verréckelen, an dann de Schwanz op déi richteg Positioun kopéieren.
            //
            //
            // aus: DEFGH .... ABC
            // zu: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: Mir berécksiichtegen de Moment net .... ABCDEFGH
            // noeneen ze sinn, well `head` wier `0` an dësem Fall.
            // Wärend mir dëst wuel ännere wëllen ass et net trivial well e puer Plazen erwaart datt `is_contiguous` heescht datt mir just `buf[tail..head]` benotze kënnen.
            //
            //

            // et gëtt genuch fräie Raum fir de Kapp op eemol ze kopéieren, dat heescht datt mir als éischt de Schwanz no vir verréckelen, an dann de Kapp op déi richteg Positioun kopéieren.
            //
            //
            // vun: FGH .... ABCDE
            // zu: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // fräi ass méi kleng wéi de Kapp an de Schwanz, dat heescht mir mussen de Schwanz an de Kapp lues "swap".
            //
            //
            // aus: EFGHI ... ABCD oder HIJK.ABCDEFG
            // op: ABCDEFGHI ... oder ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // Den allgemenge Problem gesäit esou aus wéi dësen GHIJKLM ... ABCDEF, ier iergend eng Tausch ABCDEFM ... GHIJKL, no 1 Pass vun Tausch ABCDEFGHIJM ... KL, tauschen bis déi lénks edge an den Temp Store kommen
                //                  - da start den Algorithmus neu mat engem neien (smaller) Store Heiansdo gëtt den Temp Store erreecht wann de richtegen edge um Enn vum Puffer ass, dat heescht mir hunn déi richteg Uerdnung mat manner Swaps getraff!
                //
                // E.g
                // EF..ABCD ABCDEF .., no véier nëmmen Tauscher si mir fäerdeg
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// Rotéiert déi duebelstaark Schlaang `mid` Plazen no lénks.
    ///
    /// Equivalently,
    /// - Rotéiert Element `mid` an déi éischt Positioun.
    /// - Pops déi éischt `mid` Elementer an dréckt se bis zum Schluss.
    /// - Rotéiert `len() - mid` Plazen no riets.
    ///
    /// # Panics
    ///
    /// Wann `mid` méi grouss ass wéi `len()`.
    /// Bedenkt datt `mid == len()` _not_ panic mécht an eng No-op Rotatioun ass.
    ///
    /// # Complexity
    ///
    /// Huelt `*O*(min(mid, len() - mid))` Zäit a keng extra Plaz.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// Rotéiert déi duebelstaark Schlaang `k` Plazen no riets.
    ///
    /// Equivalently,
    /// - Rotéiert dat éischt Element op d'Positioun `k`.
    /// - Pops déi lescht `k` Elementer an dréckt se no vir.
    /// - Rotéiert `len() - k` Plazen no lénks.
    ///
    /// # Panics
    ///
    /// Wann `k` méi grouss ass wéi `len()`.
    /// Bedenkt datt `k == len()` _not_ panic mécht an eng No-op Rotatioun ass.
    ///
    /// # Complexity
    ///
    /// Huelt `*O*(min(k, len() - k))` Zäit a keng extra Plaz.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // SAFETY: déi folgend zwou Methoden erfuerderen datt d'Rotatiounsbetrag
    // manner wéi d'Halschent vun der Längt vun der Deque sinn.
    //
    // `wrap_copy` erfuerdert datt `min(x, cap() - x) + copy_len <= cap()`, awer wéi `min` ass ni méi wéi d'Halschent vun der Kapazitéit, egal vu x, also ass et kléngt hei ze ruffen, well mir ruffe mat eppes manner wéi d'Halschent vun der Längt, wat ni iwwer d'Halschent vun der Kapazitéit ass.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// Binär sicht dës sortéiert `VecDeque` no engem bestëmmten Element.
    ///
    /// Wann de Wäert fonnt gëtt da gëtt [`Result::Ok`] zréck, enthält den Index vum passenden Element.
    /// Wann et verschidde Matcher sinn, da kéint ee vun de Matcher zréck ginn.
    /// Wann de Wäert net fonnt gëtt, gëtt [`Result::Err`] zréckgezunn, enthält den Index wou e passende Element kéint agefouert ginn wärend der sortéierter Uerdnung behalen.
    ///
    ///
    /// # Examples
    ///
    /// Kuckt eng Serie vu véier Elementer op.
    /// Déi éischt gëtt fonnt, mat enger eenzegaarteg bestëmmter Positioun;déi zweet an drëtt sinn net fonnt;déi véiert kéint mat all Positioun am `[1, 4]` passen.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// Wann Dir en Element an e sortéierten `VecDeque` wëllt aginn, wärend Dir d'Sortefolleg behalen:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// Binär sicht dës sortéiert `VecDeque` mat enger Komparatorfunktioun.
    ///
    /// D'Komparatorfunktioun soll eng Bestellung ëmsetzen, déi konsequent mat der Sortéierungsuerdnung vun der Basis `VecDeque` ass, an e Bestellcode zréckbréngt deen uginn ob säin Argument `Less`, `Equal` oder `Greater` ass wéi dat gewënschten Zil.
    ///
    ///
    /// Wann de Wäert fonnt gëtt da gëtt [`Result::Ok`] zréck, enthält den Index vum passenden Element.Wann et verschidde Matcher sinn, da kéint ee vun de Matcher zréck ginn.
    /// Wann de Wäert net fonnt gëtt, gëtt [`Result::Err`] zréckgezunn, enthält den Index wou e passende Element kéint agefouert ginn wärend der sortéierter Uerdnung behalen.
    ///
    /// # Examples
    ///
    /// Kuckt eng Serie vu véier Elementer op.Déi éischt gëtt fonnt, mat enger eenzegaarteg bestëmmter Positioun;déi zweet an drëtt sinn net fonnt;déi véiert kéint mat all Positioun am `[1, 4]` passen.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// Binär sicht dës sortéiert `VecDeque` mat enger Schlëssel Extraktioun Funktioun.
    ///
    /// Ugeholl datt den `VecDeque` vum Schlëssel sortéiert ass, zum Beispill mat [`make_contiguous().sort_by_key()`](#method.make_contiguous) mat der selwechter Schlëssel Extraktioun Funktioun.
    ///
    ///
    /// Wann de Wäert fonnt gëtt da gëtt [`Result::Ok`] zréck, enthält den Index vum passenden Element.
    /// Wann et verschidde Matcher sinn, da kéint ee vun de Matcher zréck ginn.
    /// Wann de Wäert net fonnt gëtt, gëtt [`Result::Err`] zréckgezunn, enthält den Index wou e passende Element kéint agefouert ginn wärend der sortéierter Uerdnung behalen.
    ///
    /// # Examples
    ///
    /// Kuckt eng Serie vu véier Elementer an engem Stéck Puer zortéiert no hiren zweeten Elementer.
    /// Déi éischt gëtt fonnt, mat enger eenzegaarteg bestëmmter Positioun;déi zweet an drëtt sinn net fonnt;déi véiert kéint mat all Positioun am `[1, 4]` passen.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// Modifizéiert den `VecDeque` op der Plaz, sou datt den `len()` gläich wéi new_len ass, entweder andeems iwwerflësseg Elementer vum Réck ewechgeholl ginn oder andeems Dir Klone vun `value` op de Réck bäifüügt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// Nees den Index am Basispuffer fir e bestëmmte logescht Element Index.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // Gréisst ass ëmmer eng Kraaft vun 2
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// Berechent d'Zuel vun den Elementer, déi am Puffer gelies ginn
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // Gréisst ass ëmmer eng Kraaft vun 2
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // Ëmmer an dräi Sektiounen ze deelen, zum Beispill: selwer: [a b c|d e f] aner: [0 1 2 3|4 5] Front=3, Mëtt=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // Et ass net méiglech Hash::hash_slice op Scheiwen zréckkritt mat der as_slices Method zréckzeginn, well hir Längt kann anescht identeschen Deques variéieren.
        //
        //
        // Den Hasher garantéiert nëmme gläichwäerteg fir de exakte selwechte Satz Uriff u seng Methoden.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Verbraucht den `VecDeque` an e Front-to-Back Iterator, deen Elementer nom Wäert ergëtt.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // Dës Funktioun sollt de moraleschen Äquivalent sinn vun:
        //
        //      fir Element am iter.into_iter() {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// Maacht en [`Vec<T>`] an en [`VecDeque<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Dëst vermeit d'Wiederverdeelung wa méiglech, awer d'Konditioune fir dat si strikt a kënne geännert ginn, an dofir sollt net op vertrauen, ausser den `Vec<T>` koum vum `From<VecDeque<T>>` a gouf net nei ausgewiesselt.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // Et gëtt keng tatsächlech Bewëllegung fir ZSTs fir sech Gedanken iwwer Kapazitéit ze maachen, awer `VecDeque` kann net sou vill Längt wéi `Vec` packen.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // Mir mussen d'Gréisst änneren wann d'Kapazitéit net eng Kraaft vun zwee ass, ze kleng oder net op d'mannst ee fräie Raum huet.
            // Mir maachen dat wärend et nach ëmmer am `Vec` ass, sou datt d'Saachen op panic falen.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// Maacht en [`VecDeque<T>`] an en [`Vec<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Dëst brauch ni nei ze allocéieren, awer muss *O*(*n*) Datenbewegung maachen wann de kreesfërmege Puffer net am Ufank vun der Bewëllegung ass.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // Dëst ass *O*(1).
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // Dëse brauch Daten nei ëmzestellen.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}