use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Schreift en Test vun der Integratioun tëscht Drëtt-Partei Allocateuren an `RawVec` ass e bësse komplizéiert well d `RawVec` API keng falsch Allocatiounsmethoden aussetzt, also kënne mir net kontrolléieren wat geschitt wann den Allocator erschöpft ass (doriwwer eraus eng panic z'entdecken).
    //
    //
    // Amplaz datt dëst just kontrolléiert datt d `RawVec` Methoden op d'mannst duerch d'Allocator API goen wann se Späichere reservéiert.
    //
    //
    //
    //
    //

    // En dommen Allocateur deen e fixe Betrag u Brennstoff verbraucht ier d'Allocatiounsversich falen.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (verursaacht e Realloc, also benotzt 50 + 150=200 Eenheeten Brennstoff)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Als éischt allocéiert `reserve` wéi `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 ass méi wéi duebel vu 7, sou datt `reserve` wéi `reserve_exact` funktionéiere soll.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 ass manner wéi d'Halschent vun 12, also muss `reserve` exponentiell wuessen.
        // Zu der Zäit vum Schreiwe vun dësem Test wuesse Faktor ass 2, sou datt nei Kapazitéit 24 ass, awer wuesse Faktor vun 1.5 ass och OK.
        //
        // Dofir `>= 18` behaapten.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}