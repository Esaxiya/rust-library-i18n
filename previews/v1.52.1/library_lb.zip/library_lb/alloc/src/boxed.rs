//! Eng Zeigentyp fir Koup Bewëllegung.
//!
//! [`Box<T>`], gemittlech als 'box' bezeechent, bitt déi einfachst Form vu Koup Bewëllegung am Rust.Këschte bidden Eegentum fir dës Bewëllegung, a falen hiren Inhalt wann se ausserhalb vum Ëmfang ginn.Këschte suergen och datt se ni méi wéi `isize::MAX` Bytes allocéieren.
//!
//! # Examples
//!
//! Beweegt e Wäert vum Stack op de Koup andeems Dir en [`Box`] erstellt:
//!
//! ```
//! let val: u8 = 5;
//! let boxed: Box<u8> = Box::new(val);
//! ```
//!
//! Beweegt e Wäert vun engem [`Box`] zréck op de Stack vum [dereferencing]:
//!
//! ```
//! let boxed: Box<u8> = Box::new(5);
//! let val: u8 = *boxed;
//! ```
//!
//! Erstelle eng rekursiv Datestruktur:
//!
//! ```
//! #[derive(Debug)]
//! enum List<T> {
//!     Cons(T, Box<List<T>>),
//!     Nil,
//! }
//!
//! let list: List<i32> = List::Cons(1, Box::new(List::Cons(2, Box::new(List::Nil))));
//! println!("{:?}", list);
//! ```
//!
//! Dëst dréckt 'Cons (1, Cons(2, Nil))`.
//!
//! Rekursiv Strukture musse geboxt ginn, well wann d'Definitioun vun `Cons` esou ausgesäit:
//!
//! ```compile_fail,E0072
//! # enum List<T> {
//! Cons(T, List<T>),
//! # }
//! ```
//!
//! Et géif net funktionnéieren.Dëst ass well d'Gréisst vun engem `List` hänkt dovun of wéi vill Elementer an der Lëscht sinn, a mir wësse also net wéi vill Erënnerung fir en `Cons` ze allocéieren.Duerch d'Aféierung vun engem [`Box<T>`], deen eng definéiert Gréisst huet, wësse mer wéi grouss `Cons` muss sinn.
//!
//! # Erënnerung Layout
//!
//! Fir net-Nullgréisst Wäerter benotzt en [`Box`] den [`Global`] Allocator fir seng Allokatioun.Et ass valabel béid Weeër ze konvertéieren tëscht engem [`Box`] an engem roude Pointer, deen mam [`Global`] allocator zougewisen gëtt, well d [`Layout`], déi mam allocator benotzt gëtt, ass korrekt fir den Typ.
//!
//! Méi genau kann en `value:*mut T` dee mam [`Global`] allocator mam `Layout::for_value(&* value)` zougewisen gouf an eng Box mat [`Box::<T>::from_raw(value)`] ëmgewandelt ginn.
//! Ëmgedréit kann d'Erënnerung mat engem `value:*mut T`, dee vum [`Box::<T>::into_raw`] kritt ass, mat der [`Global`] allocator mat [`Layout::for_value(&* value)`] verhandelt ginn.
//!
//! Fir Nullgréisst Wäerter muss den `Box` Zeiger ëmmer [valid] sinn fir ze liesen a schreift a genuch ausgeriicht.
//! Besonnesch de Goss vun all ausgeriicht net-null ganz wuertwiertlech zu engem roen Zeiger produzéiert e gültege Zeiger, awer e Zeiger, deen an e fréier zougewisenen Erënnerung weist, deen zënter befreit ass net gëlteg.
//! De recommandéierte Wee fir eng Box zu engem ZST ze bauen wann `Box::new` net ka benotzt ginn ass [`ptr::NonNull::dangling`] ze benotzen.
//!
//! Soulaang wéi `T: Sized`, ass en `Box<T>` garantéiert als eenzelen Zeiger duergestallt ze ginn an ass och ABI-kompatibel mat C Zeigefanger (dh C Typ `T*`).
//! Dëst bedeit datt wann Dir extern "C" Rust Funktiounen hutt déi vu C genannt ginn, kënnt Dir dës Rust Funktioune mat `Box<T>` Typen definéieren an `T*` als entspriechenden Typ op der C Säit benotzen.
//! Als Beispill, betruecht dësen C Header dee Funktiounen deklaréiert déi eng Aart `Foo` Wäert erstellen an zerstéieren:
//!
//! ```c
//! /* C Kappball */
//!
//! /* Nees d'Besëtzer un den Uruff */
//! struct Foo* foo_new(void);
//!
//! /* Huelt Eegentum vum Uruff;no-op wa mat NULL opgeruff gëtt */
//! void foo_delete(struct Foo*);
//! ```
//!
//! Dës zwou Funktiounen kënnen an Rust wéi follegt implementéiert ginn.Hei gëtt den `struct Foo*` Typ vu C op `Box<Foo>` iwwersat, wat d'Besëtzer limitéiert.
//! Bedenkt och datt d'Nullable Argument zu `foo_delete` an Rust als `Option<Box<Foo>>` duergestallt ass, well `Box<Foo>` kann net null sinn.
//!
//! ```
//! #[repr(C)]
//! pub struct Foo;
//!
//! #[no_mangle]
//! pub extern "C" fn foo_new() -> Box<Foo> {
//!     Box::new(Foo)
//! }
//!
//! #[no_mangle]
//! pub extern "C" fn foo_delete(_: Option<Box<Foo>>) {}
//! ```
//!
//! Och wann `Box<T>` déiselwecht Representatioun an C ABI als C Zeiger huet, heescht dat net datt Dir en arbiträren `T*` an en `Box<T>` konvertéiere kënnt an datt d'Saache funktionéieren.
//! `Box<T>` Wäerter ginn ëmmer voll ausgeriicht, net null Zeigefanger.Ausserdeem wäert den Destructor fir `Box<T>` probéieren de Wäert mam globalen Allocateur ze befreien.Am Allgemengen ass déi bescht Praxis nëmmen `Box<T>` fir Zeigefanger ze benotzen déi aus dem globalen Allocateur stamen.
//!
//! **Wichteg.** Op d'mannst am Moment, sollt Dir vermeiden `Box<T>` Typen ze benotzen fir Funktiounen déi an C definéiert sinn awer vun Rust ugeruff ginn.An deene Fäll sollt Dir d'C-Typen esou no wéi méiglech direkt spigelen.
//! Benotzt Aarte wéi `Box<T>` wou d'C Definitioun just `T*` benotzt kann zu ondefinéiert Verhalen féieren, wéi an [rust-lang/unsafe-code-guidelines#198][ucg#198] beschriwwen.
//!
//! [ucg#198]: https://github.com/rust-lang/unsafe-code-guidelines/issues/198
//! [dereferencing]: core::ops::Deref
//! [`Box::<T>::from_raw(value)`]: Box::from_raw
//! [`Global`]: crate::alloc::Global
//! [`Layout`]: crate::alloc::Layout
//! [`Layout::for_value(&*value)`]: crate::alloc::Layout::for_value
//! [valid]: ptr#safety
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::future::Future;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator, Iterator};
use core::marker::{Unpin, Unsize};
use core::mem;
use core::ops::{
    CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Generator, GeneratorState, Receiver,
};
use core::pin::Pin;
use core::ptr::{self, Unique};
use core::stream::Stream;
use core::task::{Context, Poll};

use crate::alloc::{handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw};
use crate::borrow::Cow;
use crate::raw_vec::RawVec;
use crate::str::from_boxed_utf8_unchecked;
use crate::vec::Vec;

/// Eng Zeigentyp fir Koup Bewëllegung.
///
/// Kuckt de [module-level documentation](../../std/boxed/index.html) fir méi.
#[lang = "owned_box"]
#[fundamental]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Box<
    T: ?Sized,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
>(Unique<T>, A);

impl<T> Box<T> {
    /// Allokéiert Erënnerung op de Koup a plazéiert dann `x` an en.
    ///
    /// Dëst allocéiert net tatsächlech wann `T` null Gréisst ass.
    ///
    /// # Examples
    ///
    /// ```
    /// let five = Box::new(5);
    /// ```
    #[inline(always)]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(x: T) -> Self {
        box x
    }

    /// Baut eng nei Box mat uninitialiséierten Inhalt.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Deferred Initialiséierung:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn new_uninit() -> Box<mem::MaybeUninit<T>> {
        Self::new_uninit_in(Global)
    }

    /// Baut en neien `Box` mat uninitialiséierten Inhalt, mat der Erënnerung mat `0` Bytes gefëllt.
    ///
    ///
    /// Kuckt [`MaybeUninit::zeroed`][zeroed] fir Beispiller fir korrekt a falsch Benotze vun dëser Method.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let zero = Box::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[inline]
    #[doc(alias = "calloc")]
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Box<mem::MaybeUninit<T>> {
        Self::new_zeroed_in(Global)
    }

    /// Baut en neien `Pin<Box<T>>`.
    /// Wann `T` `Unpin` net implementéiert, da gëtt `x` an der Erënnerung festgehal a kann net geréckelt ginn.
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn pin(x: T) -> Pin<Box<T>> {
        (box x).into()
    }

    /// Allokéiert Gedächtnis op de Koup plazéiert dann `x` an en, a bréngt e Feeler zréck wann d'Allocatioun net geet
    ///
    ///
    /// Dëst allocéiert net tatsächlech wann `T` null Gréisst ass.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// let five = Box::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(x: T) -> Result<Self, AllocError> {
        Self::try_new_in(x, Global)
    }

    /// Baut eng nei Box mat oninitialiséierten Inhalt op de Koup, a bréngt e Feeler zréck wann d'Allocatioun net geet
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let mut five = Box::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Deferred Initialiséierung:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_uninit() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_uninit_in(Global)
    }

    /// Baut en neien `Box` mat net-initialiséierten Inhalt, mat der Erënnerung mat `0` Bytes um Koup gefëllt
    ///
    ///
    /// Kuckt [`MaybeUninit::zeroed`][zeroed] fir Beispiller fir korrekt a falsch Benotze vun dëser Method.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let zero = Box::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_zeroed() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_zeroed_in(Global)
    }
}

impl<T, A: Allocator> Box<T, A> {
    /// Allocates Erënnerung am uginn allocator Plazen dann `x` an et.
    ///
    /// Dëst allocéiert net tatsächlech wann `T` null Gréisst ass.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::new_in(5, System);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn new_in(x: T, alloc: A) -> Self {
        let mut boxed = Self::new_uninit_in(alloc);
        unsafe {
            boxed.as_mut_ptr().write(x);
            boxed.assume_init()
        }
    }

    /// Allokéiert Gedächtnis an de gegebene Verdreiwer plazéiert dann `x` dran, a bréngt e Feeler zréck wann d'Allocatioun net klappt
    ///
    ///
    /// Dëst allocéiert net tatsächlech wann `T` null Gréisst ass.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::try_new_in(5, System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new_in(x: T, alloc: A) -> Result<Self, AllocError> {
        let mut boxed = Self::try_new_uninit_in(alloc)?;
        unsafe {
            boxed.as_mut_ptr().write(x);
            Ok(boxed.assume_init())
        }
    }

    /// Baut eng nei Box mat uninitialiséierten Inhalt am geliwwerten allocator.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::new_uninit_in(System);
    ///
    /// let five = unsafe {
    ///     // Deferred Initialiséierung:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Léiwer Match iwwer unwrap_or_else zënter Zoumaache heiansdo net inlinéierbar.
        // Dat géif d'Codegréisst méi grouss maachen.
        match Box::try_new_uninit_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Baut eng nei Këscht mat oninitialiséierten Inhalt am geliwwerten allocator zréck, bréngt e Feeler zréck wann d'Allocatioun ausfält
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::try_new_uninit_in(System)?;
    ///
    /// let five = unsafe {
    ///     // Deferred Initialiséierung:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Baut en neien `Box` mat net-initialiséierter Inhalter, woubäi d'Erënnerung mat `0` Bytes am verschaffenen allocator gefëllt gëtt.
    ///
    ///
    /// Kuckt [`MaybeUninit::zeroed`][zeroed] fir Beispiller fir korrekt a falsch Benotze vun dëser Method.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::new_zeroed_in(System);
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Léiwer Match iwwer unwrap_or_else zënter Zoumaache heiansdo net inlinéierbar.
        // Dat géif d'Codegréisst méi grouss maachen.
        match Box::try_new_zeroed_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Baut en neien `Box` mat oninitialiséierten Inhalt, mat deem de Gedächtnis mat `0` Bytes an der geliwwert Allocator gefüllt gëtt, an e Feeler zréckkritt wann d'Allocatioun net ass,
    ///
    ///
    /// Kuckt [`MaybeUninit::zeroed`][zeroed] fir Beispiller fir korrekt a falsch Benotze vun dëser Method.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::try_new_zeroed_in(System)?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate_zeroed(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Baut en neien `Pin<Box<T, A>>`.
    /// Wann `T` `Unpin` net implementéiert, da gëtt `x` an der Erënnerung festgehal a kann net geréckelt ginn.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline(always)]
    pub fn pin_in(x: T, alloc: A) -> Pin<Self>
    where
        A: 'static,
    {
        Self::new_in(x, alloc).into()
    }

    /// Konvertéiert en `Box<T>` an en `Box<[T]>`
    ///
    /// Dës Konversioun allocéiert net op de Koup a geschitt op der Plaz.
    #[unstable(feature = "box_into_boxed_slice", issue = "71582")]
    pub fn into_boxed_slice(boxed: Self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(boxed);
        unsafe { Box::from_raw_in(raw as *mut [T; 1], alloc) }
    }

    /// Verbraucht den `Box`, bréngt de gewéckelte Wäert zréck.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(box_into_inner)]
    ///
    /// let c = Box::new(5);
    ///
    /// assert_eq!(Box::into_inner(c), 5);
    /// ```
    #[unstable(feature = "box_into_inner", issue = "80437")]
    #[inline]
    pub fn into_inner(boxed: Self) -> T {
        *boxed
    }
}

impl<T> Box<[T]> {
    /// Baut eng nei Box Box mat oninitialiséierten Inhalt.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Deferred Initialiséierung:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity(len).into_box(len) }
    }

    /// Baut eng nei gekëscht Scheif mat oninitialiséierten Inhalt, mat der Erënnerung mat `0` Bytes gefëllt.
    ///
    ///
    /// Kuckt [`MaybeUninit::zeroed`][zeroed] fir Beispiller fir korrekt a falsch Benotze vun dëser Method.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let values = Box::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity_zeroed(len).into_box(len) }
    }
}

impl<T, A: Allocator> Box<[T], A> {
    /// Baut eng nei gekëscht Scheif mat uninitialiséierten Inhalt an der ugeluechter Allocator.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::new_uninit_slice_in(3, System);
    ///
    /// let values = unsafe {
    ///     // Deferred Initialiséierung:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_in(len, alloc).into_box(len) }
    }

    /// Baut eng nei gekëscht Scheif mat oninitialiséierten Inhalt am geliwwerten allocator, mat der Erënnerung mat `0` Bytes gefëllt.
    ///
    ///
    /// Kuckt [`MaybeUninit::zeroed`][zeroed] fir Beispiller fir korrekt a falsch Benotze vun dëser Method.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::new_zeroed_slice_in(3, System);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_zeroed_in(len, alloc).into_box(len) }
    }
}

impl<T, A: Allocator> Box<mem::MaybeUninit<T>, A> {
    /// Konvertéiert op `Box<T, A>`.
    ///
    /// # Safety
    ///
    /// Wéi mat [`MaybeUninit::assume_init`] ass et un den Uruffer ze garantéieren datt de Wäert wierklech an engem initialiséierte Staat ass.
    ///
    /// Dëst nennen wann den Inhalt nach net komplett initialiséiert ass verursaacht direkt ondefinéiert Verhalen.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five: Box<u32> = unsafe {
    ///     // Deferred Initialiséierung:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<T, A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut T, alloc) }
    }
}

impl<T, A: Allocator> Box<[mem::MaybeUninit<T>], A> {
    /// Konvertéiert op `Box<[T], A>`.
    ///
    /// # Safety
    ///
    /// Wéi mat [`MaybeUninit::assume_init`] ass et un den Uruff ze garantéieren datt d'Wäerter wierklech an engem initialiséierte Staat sinn.
    ///
    /// Dëst nennen wann den Inhalt nach net komplett initialiséiert ass verursaacht direkt ondefinéiert Verhalen.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Deferred Initialiséierung:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut [T], alloc) }
    }
}

impl<T: ?Sized> Box<T> {
    /// Baut eng Këscht aus engem réiem Zeigefanger.
    ///
    /// Nodeems Dir dës Funktioun opgeruff huet, ass de roude Zeiger vum entstane `Box`.
    /// Spezifesch wäert den `Box` Destructor den Destruktor vum `T` nennen an d'allocéiert Erënnerung befreien.
    /// Fir dëst sécher ze sinn, muss d'Erënnerung am Aklang mat der [memory layout], déi vun `Box` benotzt gëtt, zougewise ginn.
    ///
    ///
    /// # Safety
    ///
    /// Dës Funktioun ass onsécher well falsch Notzung zu Gedächtnisprobleemer féiere kann.
    /// Zum Beispill kann en Duebelfräi optrieden wann d'Funktioun zweemol am selwechte roude Zeiger genannt gëtt.
    ///
    /// D'Sécherheetsbedingunge ginn an der [memory layout] Sektioun beschriwwen.
    ///
    /// # Examples
    ///
    /// Erstellt en `Box` erstallt dee virdrun an e rauen Zeiger mat [`Box::into_raw`] ëmgewandelt gouf:
    ///
    /// ```
    /// let x = Box::new(5);
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Manuell en `Box` vun Null erstellen mam globalen Allocator:
    ///
    /// ```
    /// use std::alloc::{alloc, Layout};
    ///
    /// unsafe {
    ///     let ptr = alloc(Layout::new::<i32>()) as *mut i32;
    ///     // Generell ass .write erfuerderlech fir ze vermeiden de (uninitialized) fréiere Inhalt vun `ptr` ze zerstéieren, awer och fir dëst einfacht Beispill hätt `*ptr = 5` och funktionnéiert.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw(ptr);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub unsafe fn from_raw(raw: *mut T) -> Self {
        unsafe { Self::from_raw_in(raw, Global) }
    }
}

impl<T: ?Sized, A: Allocator> Box<T, A> {
    /// Baut eng Këscht aus engem réiem Zeigefanger am gegebene Verdreiwer.
    ///
    /// Nodeems Dir dës Funktioun opgeruff huet, ass de roude Zeiger vum entstane `Box`.
    /// Spezifesch wäert den `Box` Destructor den Destruktor vum `T` nennen an d'allocéiert Erënnerung befreien.
    /// Fir dëst sécher ze sinn, muss d'Erënnerung am Aklang mat der [memory layout], déi vun `Box` benotzt gëtt, zougewise ginn.
    ///
    ///
    /// # Safety
    ///
    /// Dës Funktioun ass onsécher well falsch Notzung zu Gedächtnisprobleemer féiere kann.
    /// Zum Beispill kann en Duebelfräi optrieden wann d'Funktioun zweemol am selwechte roude Zeiger genannt gëtt.
    ///
    /// # Examples
    ///
    /// Erstellt en `Box` erstallt dee virdrun an e rauen Zeiger mat [`Box::into_raw_with_allocator`] ëmgewandelt gouf:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Manuell en `Box` vun Null erstellen andeems Dir de System allocator benotzt:
    ///
    /// ```
    /// #![feature(allocator_api, slice_ptr_get)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let ptr = System.allocate(Layout::new::<i32>())?.as_mut_ptr();
    ///     // Generell ass .write erfuerderlech fir ze vermeiden de (uninitialized) fréiere Inhalt vun `ptr` ze zerstéieren, awer och fir dëst einfacht Beispill hätt `*ptr = 5` och funktionnéiert.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw_in(ptr, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub unsafe fn from_raw_in(raw: *mut T, alloc: A) -> Self {
        Box(unsafe { Unique::new_unchecked(raw) }, alloc)
    }

    /// Verbraucht den `Box`, bréngt e gewéckelte rauen Zeechner zréck.
    ///
    /// De Zeiger gëtt richteg ausgeriicht an net null.
    ///
    /// Nodeems dës Funktioun ugeruff gouf, ass de Ruff verantwortlech fir d'Erënnerung, déi virdru vum `Box` geréiert gouf.
    /// Besonnesch de Ruffer soll `T` richteg zerstéieren an d'Erënnerung entloossen, andeems d [memory layout] vun `Box` benotzt gëtt.
    /// Deen einfachste Wee fir dëst ze maachen ass de roude Zeiger zréck an en `Box` mat der [`Box::from_raw`] Funktioun ze konvertéieren, sou datt den `Box` Zerstéierer den Opraum ausféiert.
    ///
    ///
    /// Note: dëst ass eng assoziéiert Funktioun, dat heescht datt Dir se als `Box::into_raw(b)` anstatt `b.into_raw()` nenne musst.
    /// Dëst ass sou datt et kee Konflikt mat enger Method am banneschten Typ ass.
    ///
    /// # Examples
    /// Konvertéiert de roude Zeiger zréck an en `Box` mat [`Box::from_raw`] fir automatesch Botzen:
    ///
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Manuell Botz duerch explizit de Destruktor auszeféieren an d'Erënnerung ze verhandelen:
    ///
    /// ```
    /// use std::alloc::{dealloc, Layout};
    /// use std::ptr;
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let p = Box::into_raw(x);
    /// unsafe {
    ///     ptr::drop_in_place(p);
    ///     dealloc(p as *mut u8, Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub fn into_raw(b: Self) -> *mut T {
        Self::into_raw_with_allocator(b).0
    }

    /// Verbraucht den `Box`, bréngt e gewéckelte roen Zeigefanger an den Allocateur zréck.
    ///
    /// De Zeiger gëtt richteg ausgeriicht an net null.
    ///
    /// Nodeems dës Funktioun ugeruff gouf, ass de Ruff verantwortlech fir d'Erënnerung, déi virdru vum `Box` geréiert gouf.
    /// Besonnesch de Ruffer soll `T` richteg zerstéieren an d'Erënnerung entloossen, andeems d [memory layout] vun `Box` benotzt gëtt.
    /// Deen einfachste Wee fir dëst ze maachen ass de roude Zeiger zréck an en `Box` mat der [`Box::from_raw_in`] Funktioun ze konvertéieren, sou datt den `Box` Zerstéierer den Opraum ausféiert.
    ///
    ///
    /// Note: dëst ass eng assoziéiert Funktioun, dat heescht datt Dir se als `Box::into_raw_with_allocator(b)` anstatt `b.into_raw_with_allocator()` nenne musst.
    /// Dëst ass sou datt et kee Konflikt mat enger Method am banneschten Typ ass.
    ///
    /// # Examples
    /// Konvertéiert de roude Zeiger zréck an en `Box` mat [`Box::from_raw_in`] fir automatesch Botzen:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Manuell Botz duerch explizit de Destruktor auszeféieren an d'Erënnerung ze verhandelen:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    /// use std::ptr::{self, NonNull};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     let non_null = NonNull::new_unchecked(ptr);
    ///     alloc.deallocate(non_null.cast(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn into_raw_with_allocator(b: Self) -> (*mut T, A) {
        let (leaked, alloc) = Box::into_unique(b);
        (leaked.as_ptr(), alloc)
    }

    #[unstable(
        feature = "ptr_internals",
        issue = "none",
        reason = "use `Box::leak(b).into()` or `Unique::from(Box::leak(b))` instead"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn into_unique(b: Self) -> (Unique<T>, A) {
        // Box gëtt als "unique pointer" vun Stacked Borrows unerkannt, awer intern ass et e roude Zeiger fir den Typ System.
        // Direkt an e roude Zeiger ze dréinen wier net als "releasing" unerkannt den eenzegaartege Zeiger fir aliéis Roh Zougang ze erlaben, sou datt all réi Zeechnermethoden duerch `Box::leak` musse goen.
        //
        // Maacht *datt* zu engem rauen Zeigefanger verhält sech korrekt.
        //
        let alloc = unsafe { ptr::read(&b.1) };
        (Unique::from(Box::leak(b)), alloc)
    }

    /// Retourns eng Referenz op de Basisdaten allocator.
    ///
    /// Note: dëst ass eng assoziéiert Funktioun, dat heescht datt Dir se als `Box::allocator(&b)` anstatt `b.allocator()` nenne musst.
    /// Dëst ass sou datt et kee Konflikt mat enger Method am banneschten Typ ass.
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(b: &Self) -> &A {
        &b.1
    }

    /// Verbraucht a leckt den `Box`, bréngt eng mutéierbar Referenz zréck, `&'a mut T`.
    /// Bedenkt datt den Typ `T` de gewielte Liewensdauer `'a` muss iwwerliewen.
    /// Wann den Typ nëmmen statesch Referenzen huet, oder guer keng, da kann dat gewielt ginn `'static` ze sinn.
    ///
    /// Dës Funktioun ass haaptsächlech nëtzlech fir Daten déi fir de Rescht vum Programmliewe liewen.
    /// Déi zréckgezunn Referenz ze falen verursaacht e Gedächtnisleck.
    /// Wann dëst net akzeptabel ass, sollt d'Referenz als éischt mat der [`Box::from_raw`] Funktioun gewéckelt ginn an en `Box` produzéiert.
    ///
    /// Dësen `Box` kann da fale gelooss ginn, déi `T` richteg zerstéiert an déi zougewisen Erënnerung fräisetzt.
    ///
    /// Note: dëst ass eng assoziéiert Funktioun, dat heescht datt Dir se als `Box::leak(b)` anstatt `b.leak()` nenne musst.
    /// Dëst ass sou datt et kee Konflikt mat enger Method am banneschten Typ ass.
    ///
    /// # Examples
    ///
    /// Einfach Benotzung:
    ///
    /// ```
    /// let x = Box::new(41);
    /// let static_ref: &'static mut usize = Box::leak(x);
    /// *static_ref += 1;
    /// assert_eq!(*static_ref, 42);
    /// ```
    ///
    /// Net grouss Daten:
    ///
    /// ```
    /// let x = vec![1, 2, 3].into_boxed_slice();
    /// let static_ref = Box::leak(x);
    /// static_ref[0] = 4;
    /// assert_eq!(*static_ref, [4, 2, 3]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "box_leak", since = "1.26.0")]
    #[inline]
    pub fn leak<'a>(b: Self) -> &'a mut T
    where
        A: 'a,
    {
        unsafe { &mut *mem::ManuallyDrop::new(b).0.as_ptr() }
    }

    /// Konvertéiert en `Box<T>` an en `Pin<Box<T>>`
    ///
    /// Dës Konversioun allocéiert net op de Koup a geschitt op der Plaz.
    ///
    /// Dëst ass och iwwer [`From`] verfügbar.
    #[unstable(feature = "box_into_pin", issue = "62370")]
    pub fn into_pin(boxed: Self) -> Pin<Self>
    where
        A: 'static,
    {
        // Et ass net méiglech d'Innere vun engem `Pin<Box<T>>` ze verréckelen oder ze ersetzen wann `T: !Unpin`, also ass et sécher et direkt ze knipsen ouni zousätzlech Ufuerderungen.
        //
        //
        unsafe { Pin::new_unchecked(boxed) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized, A: Allocator> Drop for Box<T, A> {
    fn drop(&mut self) {
        // FIXME: Maacht näischt, Drop gëtt aktuell vum Compiler gemaach.
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Box<T> {
    /// Erstellt en `Box<T>`, mam `Default` Wäert fir den T.
    fn default() -> Self {
        box T::default()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Box<[T]> {
    fn default() -> Self {
        Box::<[T; 0]>::new([])
    }
}

#[stable(feature = "default_box_extra", since = "1.17.0")]
impl Default for Box<str> {
    fn default() -> Self {
        unsafe { from_boxed_utf8_unchecked(Default::default()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<T, A> {
    /// Gitt eng nei Box mat engem `clone()` vum Inhalt vun dëser Box zréck.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let y = x.clone();
    ///
    /// // De Wäert ass dee selwechten
    /// assert_eq!(x, y);
    ///
    /// // Awer si sinn eenzegaarteg Objeten
    /// assert_ne!(&*x as *const i32, &*y as *const i32);
    /// ```
    #[inline]
    fn clone(&self) -> Self {
        // Pre-allocéiere Gedächtnis fir de klonéierte Wäert direkt ze schreiwen.
        let mut boxed = Self::new_uninit_in(self.1.clone());
        unsafe {
            (**self).write_clone_into_raw(boxed.as_mut_ptr());
            boxed.assume_init()
        }
    }

    /// Kopéiert d'Inhalter vun der "Quell" an `self` ouni eng nei Bewëllegung ze kreéieren.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let mut y = Box::new(10);
    /// let yp: *const i32 = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // De Wäert ass dee selwechten
    /// assert_eq!(x, y);
    ///
    /// // A keng Allokatioun ass geschitt
    /// assert_eq!(yp, &*y);
    /// ```
    #[inline]
    fn clone_from(&mut self, source: &Self) {
        (**self).clone_from(&(**source));
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl Clone for Box<str> {
    fn clone(&self) -> Self {
        // dëst mécht eng Kopie vun den Donnéeën
        let buf: Box<[u8]> = self.as_bytes().into();
        unsafe { from_boxed_utf8_unchecked(buf) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq, A: Allocator> PartialEq for Box<T, A> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        PartialEq::eq(&**self, &**other)
    }
    #[inline]
    fn ne(&self, other: &Self) -> bool {
        PartialEq::ne(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd, A: Allocator> PartialOrd for Box<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
    #[inline]
    fn lt(&self, other: &Self) -> bool {
        PartialOrd::lt(&**self, &**other)
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        PartialOrd::le(&**self, &**other)
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        PartialOrd::ge(&**self, &**other)
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        PartialOrd::gt(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord, A: Allocator> Ord for Box<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq, A: Allocator> Eq for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash, A: Allocator> Hash for Box<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<T: ?Sized + Hasher, A: Allocator> Hasher for Box<T, A> {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Box<T> {
    /// Konvertéiert e genereschen Typ `T` an en `Box<T>`
    ///
    /// D'Konversioun allocéiert op de Koup a réckelt den `t` vum Stack eran.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let x = 5;
    /// let boxed = Box::new(5);
    ///
    /// assert_eq!(Box::from(x), boxed);
    /// ```
    fn from(t: T) -> Self {
        Box::new(t)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> From<Box<T, A>> for Pin<Box<T, A>>
where
    A: 'static,
{
    /// Konvertéiert en `Box<T>` an en `Pin<Box<T>>`
    ///
    /// Dës Konversioun allocéiert net op de Koup a geschitt op der Plaz.
    fn from(boxed: Box<T, A>) -> Self {
        Box::into_pin(boxed)
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl<T: Copy> From<&[T]> for Box<[T]> {
    /// Konvertéiert en `&[T]` an en `Box<[T]>`
    ///
    /// Dës Konversioun allocéiert op de Koup a mécht eng Kopie vun `slice`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // erstellen eng&[u8] déi benotzt gi fir eng Box <[u8]> ze kreéieren
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice: Box<[u8]> = Box::from(slice);
    ///
    /// println!("{:?}", boxed_slice);
    /// ```
    fn from(slice: &[T]) -> Box<[T]> {
        let len = slice.len();
        let buf = RawVec::with_capacity(len);
        unsafe {
            ptr::copy_nonoverlapping(slice.as_ptr(), buf.ptr(), len);
            buf.into_box(slice.len()).assume_init()
        }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl<T: Copy> From<Cow<'_, [T]>> for Box<[T]> {
    #[inline]
    fn from(cow: Cow<'_, [T]>) -> Box<[T]> {
        match cow {
            Cow::Borrowed(slice) => Box::from(slice),
            Cow::Owned(slice) => Box::from(slice),
        }
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl From<&str> for Box<str> {
    /// Konvertéiert en `&str` an en `Box<str>`
    ///
    /// Dës Konversioun allocéiert um Koup a féiert eng Kopie vun `s` aus.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<str> = Box::from("hello");
    /// println!("{}", boxed);
    /// ```
    #[inline]
    fn from(s: &str) -> Box<str> {
        unsafe { from_boxed_utf8_unchecked(Box::from(s.as_bytes())) }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl From<Cow<'_, str>> for Box<str> {
    #[inline]
    fn from(cow: Cow<'_, str>) -> Box<str> {
        match cow {
            Cow::Borrowed(s) => Box::from(s),
            Cow::Owned(s) => Box::from(s),
        }
    }
}

#[stable(feature = "boxed_str_conv", since = "1.19.0")]
impl<A: Allocator> From<Box<str, A>> for Box<[u8], A> {
    /// Konvertéiert en `Box<str>` an en `Box<[u8]>`
    /// Dës Konversioun allocéiert net op de Koup a geschitt op der Plaz.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // eng Box erstellen<str>déi benotzt gi fir eng Box <[u8]> ze kreéieren
    /// let boxed: Box<str> = Box::from("hello");
    /// let boxed_str: Box<[u8]> = Box::from(boxed);
    ///
    /// // erstellen eng&[u8] déi benotzt gi fir eng Box <[u8]> ze kreéieren
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice = Box::from(slice);
    ///
    /// assert_eq!(boxed_slice, boxed_str);
    /// ```
    #[inline]
    fn from(s: Box<str, A>) -> Self {
        let (raw, alloc) = Box::into_raw_with_allocator(s);
        unsafe { Box::from_raw_in(raw as *mut [u8], alloc) }
    }
}

#[stable(feature = "box_from_array", since = "1.45.0")]
impl<T, const N: usize> From<[T; N]> for Box<[T]> {
    /// Konvertéiert en `[T; N]` an en `Box<[T]>`
    /// Dës Konversioun réckelt d'Array an nei Koup zougewisen Erënnerung.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<[u8]> = Box::from([4, 2]);
    /// println!("{:?}", boxed);
    /// ```
    fn from(array: [T; N]) -> Box<[T]> {
        box array
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Box<[T]>> for Box<[T; N]> {
    type Error = Box<[T]>;

    fn try_from(boxed_slice: Box<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Box::from_raw(Box::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

impl<A: Allocator> Box<dyn Any, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Versicht d'Këscht op e konkreten Typ erofzesetzen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut dyn Any, _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Versicht d'Këscht op e konkreten Typ erofzesetzen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send), _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send + Sync, A> {
    #[inline]
    #[stable(feature = "box_send_sync_any_downcast", since = "1.51.0")]
    /// Versicht d'Këscht op e konkreten Typ erofzesetzen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send + Sync), _) =
                    Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized, A: Allocator> fmt::Display for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug + ?Sized, A: Allocator> fmt::Debug for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> fmt::Pointer for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Et ass net méiglech déi bannenzeg Uniq direkt aus der Box extrahéieren, amplaz gi mir et op e * const deen den Unique alias
        //
        let ptr: *const T = &**self;
        fmt::Pointer::fmt(&ptr, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> Deref for Box<T, A> {
    type Target = T;

    fn deref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> DerefMut for Box<T, A> {
    fn deref_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized, A: Allocator> Receiver for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized, A: Allocator> Iterator for Box<I, A> {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth(n)
    }
    fn last(self) -> Option<I::Item> {
        BoxIter::last(self)
    }
}

trait BoxIter {
    type Item;
    fn last(self) -> Option<Self::Item>;
}

impl<I: Iterator + ?Sized, A: Allocator> BoxIter for Box<I, A> {
    type Item = I::Item;
    default fn last(self) -> Option<I::Item> {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }
}

/// Spezialiséierung fir Gréisst 'I' déi d'I Ëmsetzung vun `last()` benotzt amplaz vum Standard.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator, A: Allocator> BoxIter for Box<I, A> {
    fn last(self) -> Option<I::Item> {
        (*self).last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: DoubleEndedIterator + ?Sized, A: Allocator> DoubleEndedIterator for Box<I, A> {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized, A: Allocator> ExactSizeIterator for Box<I, A> {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized, A: Allocator> FusedIterator for Box<I, A> {}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnOnce<Args> + ?Sized, A: Allocator> FnOnce<Args> for Box<F, A> {
    type Output = <F as FnOnce<Args>>::Output;

    extern "rust-call" fn call_once(self, args: Args) -> Self::Output {
        <F as FnOnce<Args>>::call_once(*self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnMut<Args> + ?Sized, A: Allocator> FnMut<Args> for Box<F, A> {
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output {
        <F as FnMut<Args>>::call_mut(self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: Fn<Args> + ?Sized, A: Allocator> Fn<Args> for Box<F, A> {
    extern "rust-call" fn call(&self, args: Args) -> Self::Output {
        <F as Fn<Args>>::call(self, args)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized, A: Allocator> CoerceUnsized<Box<U, A>> for Box<T, A> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Box<U>> for Box<T, Global> {}

#[stable(feature = "boxed_slice_from_iter", since = "1.32.0")]
impl<I> FromIterator<I> for Box<[I]> {
    fn from_iter<T: IntoIterator<Item = I>>(iter: T) -> Self {
        iter.into_iter().collect::<Vec<_>>().into_boxed_slice()
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<[T], A> {
    fn clone(&self) -> Self {
        let alloc = Box::allocator(self).clone();
        self.to_vec_in(alloc).into_boxed_slice()
    }

    fn clone_from(&mut self, other: &Self) {
        if self.len() == other.len() {
            self.clone_from_slice(&other);
        } else {
            *self = other.clone();
        }
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::Borrow<T> for Box<T, A> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::BorrowMut<T> for Box<T, A> {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsRef<T> for Box<T, A> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsMut<T> for Box<T, A> {
    fn as_mut(&mut self) -> &mut T {
        &mut **self
    }
}

/* Nota bene
 *
 *  We could have chosen not to add this impl, and instead have written a
 *  function of Pin<Box<T>> to Pin<T>. Such a function would not be sound,
 *  because Box<T> implements Unpin even when T does not, as a result of
 *  this impl.
 *
 *  We chose this API instead of the alternative for a few reasons:
 *      - Logically, it is helpful to understand pinning in regard to the
 *        memory region being pointed to. For this reason none of the
 *        standard library pointer types support projecting through a pin
 *        (Box<T> is the only pointer type in std for which this would be
 *        safe.)
 *      - It is in practice very useful to have Box<T> be unconditionally
 *        Unpin because of trait objects, for which the structural auto
 *        trait functionality does not apply (e.g., Box<dyn Foo> would
 *        otherwise not be Unpin).
 *
 *  Another type with the same semantics as Box but only a conditional
 *  implementation of `Unpin` (where `T: Unpin`) would be valid/safe, and
 *  could have a method to project a Pin<T> from it.
 */
#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> Unpin for Box<T, A> where A: 'static {}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R, A: Allocator> Generator<R> for Box<G, A>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R, A: Allocator> Generator<R> for Pin<Box<G, A>>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin, A: Allocator> Future for Box<F, A>
where
    A: 'static,
{
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut *self), cx)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for Box<S> {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        Pin::new(&mut **self).poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}