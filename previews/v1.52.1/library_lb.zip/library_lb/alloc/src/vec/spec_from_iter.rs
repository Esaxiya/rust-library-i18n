use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Spezialisatioun trait fir Vec::from_iter benotzt
///
/// ## D'Delegatioun Grafik:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // E gemeinsame Fall ass en vector an eng Funktioun weiderginn déi direkt nei an en vector sammelt.
        // Mir kënnen dëst kuerz maachen wann den IntoIter guer net fortgeschratt ass.
        // Wann et fortgeschratt ass, kënne mir d'Erënnerung och weiderbenotzen an d'Donnéeën no vir réckelen.
        // Awer mir maachen et nëmmen wann de resultéierende Vec net méi onbenotzt Kapazitéit hätt wéi et duerch d'generesch FromIterator-Implementatioun ze kreéieren.
        //
        // Dës Begrenzung ass net streng noutwendeg well dem Vec säi Verdeelungsverhalen absichtlech net spezifizéiert ass.
        // Awer et ass eng konservativ Wiel.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // muss op spec_extend() delegéieren well extend() selwer delegéiert op spec_from fir eidel Vecs
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Dëst benotzt `iterator.as_slice().to_vec()` well spec_extend méi Schrëtt maache muss fir iwwer déi lescht Kapazitéit + Längt ze beroden an doduerch méi Aarbecht ze maachen.
// `to_vec()` verdeelt direkt de richtege Betrag a fëllt se genau aus.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): mat cfg(test) ass déi ugebuer `[T]::to_vec` Method, déi fir dës Method Definitioun erfuerderlech ass, net verfügbar.
    // Amplaz d `slice::to_vec` Funktioun ze benotzen déi nëmme mat cfg(test) verfügbar ass Kuckt de slice::hack Modul am slice.rs fir méi Informatioun
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}