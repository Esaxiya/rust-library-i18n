//! E kontinuéierbare wuessbaren Arraytyp mat Koup zougewisenen Inhalt, geschriwwen `Vec<T>`.
//!
//! Vectors hunn `O(1)` Indexéierung, amortiséiert `O(1)` Push (bis zum Enn) an `O(1)` Pop (vum Enn).
//!
//!
//! Vectors suergen datt se ni méi wéi `isize::MAX` Bytes allocéieren.
//!
//! # Examples
//!
//! Dir kënnt explizit en [`Vec`] mat [`Vec::new`] erstellen:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... oder mam [`vec!`] Macro:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // zéng Nullen
//! ```
//!
//! Dir kënnt [`push`] Wäerter um Enn vun enger vector (déi den vector wuesse wuesse wéi néideg):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Popping Wäerter funktionnéieren op déiselwecht Manéier:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors ënnerstëtzt och Indexéierung (duerch den [`Index`] an [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// E grenzwäerte wuessbaren Arraytyp, geschriwwen als `Vec<T>` an ausgeschwat 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// Den [`vec!`] Macro gëtt zur Verfügung gestallt fir d'Initialiséierung méi bequem ze maachen:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Et kann och all Element vun engem `Vec<T>` mat engem gegebene Wäert initialiséieren.
/// Dëst ka méi effizient sinn wéi d'Allocatioun an d'Initialiséierung a getrennte Schrëtt auszeféieren, besonnesch wann een vector vun Nullen initialiséiert:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Folgend ass gläichwäerteg, awer potenziell méi lues:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Fir méi Informatioun, kuckt [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Benotzt en `Vec<T>` als effizienten Stack:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Dréckt 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Den `Vec` Typ erlaabt Zougang zu Wäerter per Index, well en den [`Index`] trait implementéiert.E Beispill wäert méi explizit sinn:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // et wäert '2' affichéieren
/// ```
///
/// Maacht awer virsiichteg: wann Dir probéiert op en Index ze kommen deen net am `Vec` ass, wäert Är Software panic!Dir kënnt dat net maachen:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Benotzt [`get`] an [`get_mut`] wann Dir wëllt kontrolléieren ob den Index am `Vec` ass.
///
/// # Slicing
///
/// En `Vec` kann mutabel sinn.Op der anerer Säit, Scheiwen sinn nëmme gelies Objeten.
/// Fir en [slice][prim@slice] ze kréien, benotzt [`&`].Beispill:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... an dat ass alles!
/// // Dir kënnt et och esou maachen:
/// let u: &[usize] = &v;
/// // oder esou:
/// let u: &[_] = &v;
/// ```
///
/// An Rust ass et méi heefeg Scheiwen als Argumenter ze vermëttelen anstatt vectors wann Dir just Lieszougang wëllt ubidden.Dat selwecht gëlt fir [`String`] an [`&str`].
///
/// # Kapazitéit an Ëmverdeelung
///
/// D'Kapazitéit vun engem vector ass de Betrag vun der Plaz fir all future Elementer déi op den vector bäigefüügt ginn.Dëst ass net ze verwiessele mat der *Längt* vun engem vector, wat d'Zuel vun den aktuellen Elementer am vector spezifizéiert.
/// Wann eng vector Längt hir Kapazitéit iwwerschreift, gëtt hir Kapazitéit automatesch erhéicht, awer hir Elementer musse nei ausgewiesselt ginn.
///
/// Zum Beispill wier en vector mat Kapazitéit 10 a Längt 0 en eidelen vector mat Plaz fir 10 weider Elementer.10 oder manner Elementer op den vector drécken ännert seng Kapazitéit net oder veruersaacht Ëmverdeelung.
/// Wéi och ëmmer, wann d'Längt vun der vector op 11 eropgesat gëtt, da muss se nei ëmallocéieren, wat ka lues sinn.Aus dësem Grond ass et recommandéiert [`Vec::with_capacity`] ze benotzen wann et méiglech ass ze spezifizéieren wéi grouss den vector erwaart gëtt.
///
/// # Guarantees
///
/// Wéinst senger onheemlech fundamental Natur mécht `Vec` vill Garantien iwwer säin Design.Dëst garantéiert datt et am allgemenge Fall sou niddereg wéi méiglech ass, an op primitiv Weeër mat onséchere Code korrekt manipuléiert ka ginn.Bedenkt datt dës Garantien op en onqualifizéierten `Vec<T>` bezéien.
/// Wann zousätzlech Type Parameteren derbäikommen (z. B. fir personaliséiert Allocateuren z'ënnerstëtzen), kann hir Standardastellungen d'Verhalen änneren.
///
/// Am meeschte grondsätzlech ass a wäert `Vec` ëmmer en (Zeiger, Kapazitéit, Längt) Triplett sinn.Net méi, net manner.D'Uerdnung vun dëse Felder ass komplett net spezifizéiert, an Dir sollt déi entspriechend Methode benotze fir dës z'änneren.
/// De Zeiger wäert ni null sinn, sou datt dësen Typ Null-Zeiger-optimiséiert ass.
///
/// Wéi och ëmmer, de Zeiger kann net tatsächlech op zougewisen Erënnerung weisen.
/// Besonnesch wann Dir en `Vec` mat Kapazitéit 0 iwwer [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`] konstruéiert, oder andeems Dir [`shrink_to_fit`] op engem eidele Vec nennt, wäert et kee Gedächtnis verdeelen.Ähnlech wéi wann Dir Nullgréissten Typen an engem `Vec` speichert, gëtt et keng Plaz fir hinnen zou.
/// *Bedenkt datt an dësem Fall den `Vec` keen [`capacity`] vun 0* melle kann.
/// `Vec` verdeelt wann an nëmmen wann [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Am Allgemengen sinn d'Allocatiounsdetailer vu "Vec" ganz dezent-wann Dir wëllt Gedächtnis mat engem `Vec` allocéieren an se fir eppes anescht benotzen (entweder fir onsécher Code weiderzeginn, oder fir Är eege Memory-backed Sammlung ze bauen), gitt sécher fir dëst Gedächtnis ze verhandelen andeems Dir `from_raw_parts` benotzt fir den `Vec` ze recuperéieren an duerno ze falen.
///
/// Wann en `Vec` * Erënnerung zougewisen huet, ass d'Erënnerung op déi et weist op de Koup (wéi definéiert vum Allocator Rust ass konfiguréiert fir se standardméisseg ze benotzen), a säi Zeigefanger weist op [`len`] initialiséiert, ugestouss Elementer an Uerdnung (wat Dir géift maachen kuckt ob Dir et op e Stéck gezwongen hutt), gefollegt vun [`Kapazitéit`]`,`[`len`] logesch net initialiséiert, ugrenzend Elementer.
///
///
/// En vector mat den Elementer `'a'` an `'b'` mat Kapazitéit 4 kann wéi hei ënnendrënner visualiséiert ginn.Den Top Deel ass den `Vec` struct, en enthält en Zeiger zum Kapp vun der Allokatioun am Koup, Längt a Kapazitéit.
/// Den ënneschten Deel ass d'Allocatioun um Koup, e grenzende Gedächtnisblock.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** representéiert Erënnerung dat net initialiséiert ass, kuckt [`MaybeUninit`].
/// - Note: den ABI ass net stabil an `Vec` mécht keng Garantien iwwer säi Gedächtnis Layout (inklusiv d'Reiefolleg vu Felder).
///
/// `Vec` wäert ni en "small optimization" maachen, wou Elementer aus zwee Grënn tatsächlech um Stack gespäichert sinn:
///
/// * Et géif et méi schwéier maachen fir onséchere Code fir en `Vec` korrekt ze manipuléieren.Den Inhalt vun engem `Vec` hätt keng stabil Adress wa se just geréckelt gëtt, an et wier méi schwéier ze bestëmmen ob en `Vec` wierklech Erënnerung zougedeelt hätt.
///
/// * Et géif den allgemenge Fall bestrofen, en zousätzlechen branch bei all Zougang entstoen.
///
/// `Vec` wäert sech ni automatesch verréngeren, och wann et komplett eidel ass.Dëst garantéiert keng onnéideg Allocatiounen oder Deallocatiounen.E `Vec` eidel ze maachen an duerno erëm op déiselwecht [`len`] auszefëllen, soll keng Uriff un den Allocateur kréien.Wann Dir onbenotzt Erënnerung fräi maache wëllt, benotzt [`shrink_to_fit`] oder [`shrink_to`].
///
/// [`push`] an [`insert`] wäert ni (nei) allocéieren wann d'gemellt Kapazitéit genuch ass.[`push`] an [`insert`]*wäerten*(nei) allocéieren wann [`len`]`==`[`Kapazitéit`].Dat ass, d'gemellt Kapazitéit ass ganz korrekt, a kann op vertrauen.Et kann och benotzt ginn fir de Gedächtnis vun engem `Vec` zougewisen ze manuell ze befreien wa gewënscht.
/// Bulk-Insertionsmethoden *kënnen* nei omplacéieren, och wann net néideg.
///
/// `Vec` garantéiert keng speziell Wuesstumsstrategie beim Ëmverdeelung wa se voll ass, och net wann [`reserve`] genannt gëtt.Déi aktuell Strategie ass Basis an et kann wënschenswäert sinn en net konstante Wuesstumsfaktor ze benotzen.Egal wéi eng Strategie benotzt gëtt garantéiert natierlech *O*(1) amortiséiert [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]`, an [`Vec::with_capacity(n)`][`Vec::with_capacity`], produzéieren all en `Vec` mat genau der gefuerderter Kapazitéit.
/// Wann [`len`]`==`[`Kapazitéit`], (wéi de Fall fir den [`vec!`] Macro ass), da kann en `Vec<T>` an a vun engem [`Box<[T]>`][owned slice] ëmgewandelt ginn ouni d'Elementer nei ze verdeelen oder ze réckelen.
///
/// `Vec` wäert net spezifesch Daten iwwerschreiwe déi dovun ewechgeholl ginn, awer och net spezifesch konservéieren.Säin oninitialiséierte Gedächtnis ass e Kratzraum deen e benotze kann awer wéi et wëll.Et wäert normalerweis just maachen wat effizientst ass oder soss einfach ze implementéieren.Vertrau net op ewechgeholl Daten fir aus Sécherheetszwecker ze läschen.
/// Och wann Dir en `Vec` fällt, kann säi Puffer einfach vun engem aneren `Vec` weiderbenotzt ginn.
/// Och wann Dir als éischt e "Vec" Gedächtnis nulls, kann dat net wierklech geschéien, well den Optimizer dëst net als Nebenwirkung hält, dee muss erhale bleiwen.
/// Et ass e Fall dee mir net briechen, awer: `unsafe` Code benotze fir op d'iwwerschësseg Kapazitéit ze schreiwen, an dann d'Längt eropzesetzen fir ze passen, ass ëmmer gëlteg.
///
/// Momentan garantéiert `Vec` d'Bestellung net an deenen Elementer fale gelooss ginn.
/// D'Uerdnung huet an der Vergaangenheet geännert a kann erëm änneren.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Inherent Methoden
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Baut en neien, eidelen `Vec<T>`.
    ///
    /// Den vector allocéiert net bis Elementer drop gedréckt ginn.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Baut en neien, eidelen `Vec<T>` mat der spezifizéierter Kapazitéit.
    ///
    /// Den vector wäert fäeg sinn exakt `capacity` Elementer ze halen ouni nei ze verdeelen.
    /// Wann `capacity` 0 ass, wäert d'vector net allocéieren.
    ///
    /// Et ass wichteg ze bemierken datt och wann den zréckkommten vector déi *Kapazitéit* spezifizéiert huet, den vector eng Null *Längt* huet.
    ///
    /// Fir eng Erklärung iwwer den Ënnerscheed tëscht Längt a Kapazitéit, kuckt *[Kapazitéit an Ëmverdeelung]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // Den vector enthält keng Elementer, och wann et Kapazitéit fir méi huet
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Dës ginn all gemaach ouni nei ze verdeelen ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... awer dëst kann den vector nei realiséieren
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Erstellt en `Vec<T>` direkt vun de roude Komponente vun engem aneren vector.
    ///
    /// # Safety
    ///
    /// Dëst ass héich onsécher, wéinst der Unzuel vun Invararianen déi net kontrolléiert ginn:
    ///
    /// * `ptr` muss virdrun iwwer [`String`]/`Vec zougewisen ginn<T>"(op d'mannst ass et héchstwahrscheinlech falsch wann et net war).
    /// * `T` muss déiselwecht Gréisst an Ausriichtung hunn wéi mat deem `ptr` zougewise gouf.
    ///   (`T` mat enger manner strenger Ausriichtung ass net genuch, d'Ausriichtung muss wierklech gläich sinn fir dem [`dealloc`] Viraussetzung z'erfëllen datt d'Erënnerung muss mat deem selwechte Layout zougewisen a verdeelt ginn.)
    ///
    /// * `length` muss manner wéi oder gläich wéi `capacity` sinn.
    /// * `capacity` muss d'Kapazitéit sinn, mat där de Zeiger zougewise gouf.
    ///
    /// Verstouss géint dës ka Probleemer verursaache wéi Korruptioun vun den internen Datestrukturen vum allocator.Zum Beispill ass et **net** sécher en `Vec<u8>` vun engem Zeiger an en C `char` Array mat der Längt `size_t` ze bauen.
    /// Et ass och net sécher een aus engem `Vec<u16>` a senger Längt ze bauen, well den Allocator këmmert sech ëm d'Ausriichtung, an dës zwou Aarte hu verschidden Ausriichtungen.
    /// De Puffer gouf mat Ausriichtung 2 zougewisen (fir `u16`), awer nodeems en an en `Vec<u8>` verwandelt gouf, gëtt et mat der Ausriichtung 1 verdeelt.
    ///
    /// De Besëtz vun `ptr` gëtt effektiv op den `Vec<T>` transferéiert, deen dann den Inhalt vum Gedächtnis, deen de Zeigefanger op Wonsch weist, verhandelen, nei verdeelen oder änneren.
    /// Gitt sécher datt näischt anescht de Zeiger benotzt nodeems Dir dës Funktioun opgeruff hutt.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Update dëst wann vec_into_raw_parts stabiliséiert ass.
    ///     // Verhënnert datt Dir den "V" Destructor leeft, sou datt mir eng komplett Kontroll iwwer d'Allocatioun hunn.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Pull déi verschidde wichteg Informatiounsstécker iwwer `v` eraus
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Iwwerdribblen Erënnerung mat 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Setzt alles erëm zesummen an e Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Baut en neien, eidelen `Vec<T, A>`.
    ///
    /// Den vector allocéiert net bis Elementer drop gedréckt ginn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Baut en neien, eidelen `Vec<T, A>` mat der spezifizéierter Kapazitéit mat dem zougestellten allocator.
    ///
    /// Den vector wäert fäeg sinn exakt `capacity` Elementer ze halen ouni nei ze verdeelen.
    /// Wann `capacity` 0 ass, wäert d'vector net allocéieren.
    ///
    /// Et ass wichteg ze bemierken datt och wann den zréckkommten vector déi *Kapazitéit* spezifizéiert huet, den vector eng Null *Längt* huet.
    ///
    /// Fir eng Erklärung iwwer den Ënnerscheed tëscht Längt a Kapazitéit, kuckt *[Kapazitéit an Ëmverdeelung]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // Den vector enthält keng Elementer, och wann et Kapazitéit fir méi huet
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Dës ginn all gemaach ouni nei ze verdeelen ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... awer dëst kann den vector nei realiséieren
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Erstellt en `Vec<T, A>` direkt vun de roude Komponente vun engem aneren vector.
    ///
    /// # Safety
    ///
    /// Dëst ass héich onsécher, wéinst der Unzuel vun Invararianen déi net kontrolléiert ginn:
    ///
    /// * `ptr` muss virdrun iwwer [`String`]/`Vec zougewisen ginn<T>"(op d'mannst ass et héchstwahrscheinlech falsch wann et net war).
    /// * `T` muss déiselwecht Gréisst an Ausriichtung hunn wéi mat deem `ptr` zougewise gouf.
    ///   (`T` mat enger manner strenger Ausriichtung ass net genuch, d'Ausriichtung muss wierklech gläich sinn fir dem [`dealloc`] Viraussetzung z'erfëllen datt d'Erënnerung muss mat deem selwechte Layout zougewisen a verdeelt ginn.)
    ///
    /// * `length` muss manner wéi oder gläich wéi `capacity` sinn.
    /// * `capacity` muss d'Kapazitéit sinn, mat där de Zeiger zougewise gouf.
    ///
    /// Verstouss géint dës ka Probleemer verursaache wéi Korruptioun vun den internen Datestrukturen vum allocator.Zum Beispill ass et **net** sécher en `Vec<u8>` vun engem Zeiger an en C `char` Array mat der Längt `size_t` ze bauen.
    /// Et ass och net sécher een aus engem `Vec<u16>` a senger Längt ze bauen, well den Allocator këmmert sech ëm d'Ausriichtung, an dës zwou Aarte hu verschidden Ausriichtungen.
    /// De Puffer gouf mat Ausriichtung 2 zougewisen (fir `u16`), awer nodeems en an en `Vec<u8>` verwandelt gouf, gëtt et mat der Ausriichtung 1 verdeelt.
    ///
    /// De Besëtz vun `ptr` gëtt effektiv op den `Vec<T>` transferéiert, deen dann den Inhalt vum Gedächtnis, deen de Zeigefanger op Wonsch weist, verhandelen, nei verdeelen oder änneren.
    /// Gitt sécher datt näischt anescht de Zeiger benotzt nodeems Dir dës Funktioun opgeruff hutt.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Update dëst wann vec_into_raw_parts stabiliséiert ass.
    ///     // Verhënnert datt Dir den "V" Destructor leeft, sou datt mir eng komplett Kontroll iwwer d'Allocatioun hunn.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Pull déi verschidde wichteg Informatiounsstécker iwwer `v` eraus
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Iwwerdribblen Erënnerung mat 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Setzt alles erëm zesummen an e Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Zersetzt en `Vec<T>` a seng réi Komponenten.
    ///
    /// Gitt de roude Zeiger op d'Basisdaten zréck, d'Längt vum vector (an Elementer), an déi zougewisen Kapazitéit vun den Daten (an Elementer).
    /// Dëst sinn déiselwecht Argumenter an der selwechter Reiefolleg wéi d'Argumenter fir [`from_raw_parts`].
    ///
    /// Nodeems dës Funktioun urufft, ass de Ruff verantwortlech fir d'Erënnerung, déi virdru vum `Vec` geréiert gouf.
    /// Deen eenzege Wee fir dëst ze maachen ass de roude Zeiger, d'Längt an d'Kapazitéit zréck an en `Vec` mat der [`from_raw_parts`] Funktioun ze konvertéieren, sou datt den Destructor den Opraum ausféiert.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Mir kënnen elo Ännerunge fir d'Komponente maachen, sou wéi de roude Zeiger an e kompatiblen Typ ëmzesetzen.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Zersetzt en `Vec<T>` a seng réi Komponenten.
    ///
    /// Gitt de roude Zeiger op d'Basisdaten zréck, d'Längt vum vector (an Elementer), d'allocéiert Kapazitéit vun den Daten (an Elementer), an den Allocateur.
    /// Dëst sinn déiselwecht Argumenter an der selwechter Reiefolleg wéi d'Argumenter fir [`from_raw_parts_in`].
    ///
    /// Nodeems dës Funktioun urufft, ass de Ruff verantwortlech fir d'Erënnerung, déi virdru vum `Vec` geréiert gouf.
    /// Deen eenzege Wee fir dëst ze maachen ass de roude Zeiger, d'Längt an d'Kapazitéit zréck an en `Vec` mat der [`from_raw_parts_in`] Funktioun ze konvertéieren, sou datt den Destructor den Opraum ausféiert.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Mir kënnen elo Ännerunge fir d'Komponente maachen, sou wéi de roude Zeiger an e kompatiblen Typ ëmzesetzen.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Gitt d'Zuel vun den Elementer zréck déi den vector kann halen ouni nei ze verdeelen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Reservéiert Kapazitéit fir op d'mannst `additional` méi Elementer fir an de gegebene `Vec<T>` anzesetzen.
    /// D'Kollektioun ka méi Plaz reservéieren fir heefeg Ëmverdeelungen ze vermeiden.
    /// Nodeems Dir `reserve` ugeruff hutt, wäert d'Kapazitéit méi grouss wéi oder gläich wéi `self.len() + additional` sinn.
    /// Maacht näischt wann d'Kapazitéit scho genuch ass.
    ///
    /// # Panics
    ///
    /// Panics wann déi nei Kapazitéit méi wéi `isize::MAX` Bytes ass.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Reservéiert d'Mindestkapazitéit fir genau `additional` méi Elementer an de gegebene `Vec<T>` ze setzen.
    ///
    /// Nodeems Dir `reserve_exact` ugeruff hutt, wäert d'Kapazitéit méi grouss wéi oder gläich wéi `self.len() + additional` sinn.
    /// Maacht näischt wann d'Kapazitéit scho genuch ass.
    ///
    /// Bedenkt datt d'Allocator der Sammlung méi Plaz ka ginn wéi se gefrot.
    /// Dofir kann d'Kapazitéit net drop verloossen datt se präzis minimal ass.
    /// Léiwer `reserve` wann future Insertions erwaart ginn.
    ///
    /// # Panics
    ///
    /// Panics wann déi nei Kapazitéit iwwer `usize` iwwerschwemmt.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Probéiert d'Kapazitéit ze reservéieren fir op d'mannst `additional` méi Elementer an de gegebene `Vec<T>` ze setzen.
    /// D'Kollektioun ka méi Plaz reservéieren fir heefeg Ëmverdeelungen ze vermeiden.
    /// Nodeems Dir `try_reserve` ugeruff hutt, wäert d'Kapazitéit méi grouss wéi oder gläich wéi `self.len() + additional` sinn.
    /// Maacht näischt wann d'Kapazitéit scho genuch ass.
    ///
    /// # Errors
    ///
    /// Wann d'Kapazitéit iwwerschwemmt ass, oder de Verdeler e Feeler bericht, da gëtt e Feeler zréckginn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Reservéiert d'Erënnerung viraus, wann Dir net kënnt
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Elo wësse mer datt dëst net OOM kann an der Mëtt vun eiser komplexer Aarbecht
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // ganz komplizéiert
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Probéiert déi Mindestkapazitéit ze reservéieren fir exakt `additional` Elementer an de gegebene `Vec<T>` anzesetzen.
    /// Nodeems Dir `try_reserve_exact` ugeruff hutt, wäert d'Kapazitéit méi grouss wéi oder gläich wéi `self.len() + additional` sinn, wann et `Ok(())` zréckbréngt.
    ///
    /// Maacht näischt wann d'Kapazitéit scho genuch ass.
    ///
    /// Bedenkt datt d'Allocator der Sammlung méi Plaz ka ginn wéi se gefrot.
    /// Dofir kann d'Kapazitéit net drop verloossen datt se präzis minimal ass.
    /// Léiwer `reserve` wann future Insertions erwaart ginn.
    ///
    /// # Errors
    ///
    /// Wann d'Kapazitéit iwwerschwemmt ass, oder de Verdeler e Feeler bericht, da gëtt e Feeler zréckginn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Reservéiert d'Erënnerung viraus, wann Dir net kënnt
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Elo wësse mer datt dëst net OOM kann an der Mëtt vun eiser komplexer Aarbecht
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // ganz komplizéiert
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Schrëft d'Kapazitéit vum vector sou vill wéi méiglech.
    ///
    /// Et fällt sou no wéi méiglech op d'Längt erof, awer de Verdeeler kann ëmmer nach d'vector informéieren datt et Plaz fir e puer méi Elementer ass.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // D'Kapazitéit ass ni manner wéi d'Längt, an et ass näischt ze maachen wann se gläich sinn, sou datt mir den panic Fall am `RawVec::shrink_to_fit` vermeiden andeems se et nëmme mat méi grousser Kapazitéit nennen.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Schrëft d'Kapazitéit vum vector mat enger ënneschter Grenz.
    ///
    /// D'Kapazitéit bleift op d'mannst sou grouss wéi d'Längt an de geliwwertene Wäert.
    ///
    ///
    /// Wann déi aktuell Kapazitéit manner wéi déi ënnescht Grenz ass, ass dat en No-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Konvertéiert den vector an [`Box<[T]>`][owned slice].
    ///
    /// Bedenkt datt dëst all iwwerschësseg Kapazitéit fällt.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// All Iwwerschosskapazitéit gëtt ofgeschaaft:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Verkierzt den vector, hält déi éischt `len` Elementer an de Rescht fällt.
    ///
    /// Wann `len` méi grouss ass wéi déi aktuell Längt vun der vector, huet dat keen Effekt.
    ///
    /// D [`drain`] Method kann `truncate` emuléieren, awer bewierkt datt d'iwwerschësseg Elementer zréckkommen anstatt ofgefall sinn.
    ///
    ///
    /// Bedenkt datt dës Method keen Effekt op d'allocéiert Kapazitéit vum vector huet.
    ///
    /// # Examples
    ///
    /// Truncating a five element vector to two elements:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Keng Ofkierzung geschitt wann `len` méi grouss ass wéi déi aktuell Längt vun der vector:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Ofkierzen wann `len == 0` entsprécht der [`clear`] Method ze ruffen.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Dëst ass sécher well:
        //
        // * de Slice deen op `drop_in_place` weiderginn ass gëlteg;den `len > self.len` Fall evitéiert eng ongëlteg Scheif ze schafen, an
        // * den `len` vun der vector gëtt verréngert ier en `drop_in_place` genannt gëtt, sou datt kee Wäert zweemol fale gelooss gëtt wann `drop_in_place` eemol panic wier (wann et zweemol panics, de Programm ofgebrach).
        //
        //
        //
        unsafe {
            // Note: Et ass bewosst datt dëst `>` an net `>=` ass.
            //       Änneren op `>=` huet negativ Performance Implikatiounen an e puer Fäll.
            //       Kuckt #78884 fir méi.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Extraitéiert e Stéck dat ganz vector enthält.
    ///
    /// Gläichwäerteg zu `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Extraitéiert eng mutéierbar Scheif vum ganzen vector.
    ///
    /// Gläichwäerteg zu `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Nees e roude Zeigefanger op de Puffer vum vector.
    ///
    /// De Ruffer muss sécher sinn datt den vector de Zeigefanger iwwerliewt dës Funktioun zréckkënnt, oder soss weist et op Müll.
    /// D'vector z'änneren kann dozou féieren datt säi Puffer nei ëmgeleet gëtt, wat och all Hiweiser drop ongëlteg mécht.
    ///
    /// De Ruffer muss och sécher sinn datt d'Erënnerung op déi de Zeiger (non-transitively) weist op ni geschriwwe gëtt (ausser an engem `UnsafeCell`) mat dësem Zeiger oder all Zeiger dervun ofgeleet.
    /// Wann Dir den Inhalt vun der Scheif mutéiere musst, benotzt [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Mir schatten d'Scheiwenmethod mam selwechten Numm fir ze vermeiden duerch `deref` ze goen, wat eng Zwëscher Referenz erstellt.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Nees en onséchere mutabelen Zeiger zum Puffer vum vector.
    ///
    /// De Ruffer muss sécher sinn datt den vector de Zeigefanger iwwerliewt dës Funktioun zréckkënnt, oder soss weist et op Müll.
    ///
    /// D'vector z'änneren kann dozou féieren datt säi Puffer nei ëmgeleet gëtt, wat och all Hiweiser drop ongëlteg mécht.
    ///
    /// # Examples
    ///
    /// ```
    /// // Allokéiert vector grouss genuch fir 4 Elementer.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Initialiséiert Elementer iwwer réi Zeechner schreift, da setzt d'Längt.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Mir schatten d'Scheiwenmethod mam selwechten Numm fir ze vermeiden duerch `deref_mut` ze goen, wat eng Zwëscher Referenz erstellt.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Retourns eng Referenz op de Basisdaten allocator.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Kräft d'Längt vum vector bis `new_len`.
    ///
    /// Dëst ass eng niddereg Operatioun déi keng vun den normalen Invararianer vum Typ ënnerhält.
    /// Normalerweis ännert d'Längt vun engem vector mat enger vun de séchere Operatiounen amplaz wéi [`truncate`], [`resize`], [`extend`] oder [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` muss manner wéi oder gläich wéi [`capacity()`] sinn.
    /// - D'Elementer bei `old_len..new_len` mussen initialiséiert ginn.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Dës Method kann nëtzlech sinn fir Situatiounen an deenen den vector als Puffer fir anere Code déngt, besonnesch iwwer FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Dëst ass just e minimale Skelett fir den Dokter Beispill;
    /// # // benotzt dëst net als Ausgangspunkt fir eng richteg Bibliothéik.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Per Dokumenter vun der FFI Method, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // SAFETY: Wann `deflateGetDictionary` `Z_OK` zréckbréngt, hält se dat:
    ///     // 1. `dict_length` Elementer goufen initialiséiert.
    ///     // 2.
    ///     // `dict_length` <=d'Kapazitéit (32_768) déi `set_len` sécher mécht fir ze ruffen.
    ///     unsafe {
    ///         // Maacht den FFI Uriff ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... an aktualiséiert d'Längt op wat initialiséiert gouf.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Wärend de folgenden Beispill klang ass, ass et e Gedächtnissleck well déi bannent vectors net virum `set_len` Uruff befreit goufen:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` ass eidel, dofir musse keng Elementer initialiséiert ginn.
    /// // 2. `0 <= capacity` hält ëmmer wat och ëmmer `capacity` ass.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Normalerweis, hei, géif een [`clear`] amplaz benotze fir den Inhalt korrekt ze falen an doduerch kee Gedächtnis ze lecken.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Läscht en Element aus der vector an zréck.
    ///
    /// Dat ewechgeholl Element gëtt duerch dat lescht Element vun der vector ersat.
    ///
    /// Dëst behält d'Bestellung net, awer ass O(1).
    ///
    /// # Panics
    ///
    /// Panics wann `index` ausser Grenzen ass.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Mir ersetzen den Self [Index] duerch dat lescht Element.
            // Bedenkt datt wann d'Grenzcheck uewen erfollegräich ass, muss e lescht Element sinn (dat ka selwer [Index] selwer sinn).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Setzt en Element op der Positioun `index` am vector an, verschéckt all Elementer duerno no riets.
    ///
    ///
    /// # Panics
    ///
    /// Panics wann `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // Plaz fir dat neit Element
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // onfehlbar De Fleck fir de neie Wäert ze setzen
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Verréckelt alles fir Plaz ze maachen.
                // (Duplizéieren vum "Index" Element op zwou hannereneen Uertschaften.)
                ptr::copy(p, p.offset(1), len - index);
                // Schreift et an, iwwerschreift déi éischt Kopie vum `index`th Element.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Entfernt an zréckgitt d'Element op der Positioun `index` am vector, verréckelt all Elementer duerno no lénks.
    ///
    ///
    /// # Panics
    ///
    /// Panics wann `index` ausser Grenzen ass.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // déi Plaz wou mir huelen.
                let ptr = self.as_mut_ptr().add(index);
                // kopéiert et aus, onsécher eng Kopie vum Wäert um Stack an an der vector zur selwechter Zäit.
                //
                ret = ptr::read(ptr);

                // Verréckelt alles erof fir dës Plaz auszefëllen.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Hält nëmmen d'Elementer déi vum Prädikat spezifizéiert sinn.
    ///
    /// An anere Wierder, ewechzehuelen all Elementer `e` sou datt `f(&e)` zréck `false`.
    /// Dës Method funktionnéiert op der Plaz, besicht all Element genau eemol an der ursprénglecher Uerdnung, a behält d'Bestellung vun den erhalen Elementer.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Well d'Elementer genau eemol an der ursprénglecher Uerdnung besicht ginn, kann externen Zoustand benotzt ginn fir ze entscheeden wéi eng Elementer ze halen.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Vermeit Duebelfall wann d'Dropschutz net ausgefouert gëtt, well mir kënnen e puer Lächer am Prozess maachen.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-veraarbecht len-> |^-niewend dem Check
        //                  | <-geläscht cnt-> |
        //      | <-original_len-> |Kept: Elementer déi predikat ginn zréck op.
        //
        // Lach: Geplënnert oder gefall Element Slot.
        // Onkontrolléiert: Onkontrolléiert valabel Elementer.
        //
        // Dëse Drop Guard gëtt opgeruff wann Prädikat oder `drop` vun Element panikéiert ass.
        // Et verréckelt onkontrolléiert Elementer fir Lächer an `set_len` op déi richteg Längt ze decken.
        // A Fäll wou Predikat an `drop` ni panikéieren, gëtt se optimiséiert.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // SIKKERHET: Unkontrolléiert Saache musse valabel sinn, well mir se ni beréieren.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // SÉCHERHEET: Nodeems Lächer gefëllt sinn, sinn all Elementer an enger noeneen Erënnerung.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // SAFETY: Onkontrolléiert Element muss valabel sinn.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Gitt fréi vir, fir duebel drop ze vermeiden wann `drop_in_place` panikéiert ass.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // SAFETY: Mir beréieren dëst Element ni méi nodeems et erofgefall ass.
                unsafe { ptr::drop_in_place(cur) };
                // Mir hunn de Comptoir scho fortgeschratt.
                continue;
            }
            if g.deleted_cnt > 0 {
                // SAFETY: `deleted_cnt`> 0, sou datt d'Lachplaz net mam aktuellen Element iwwerlappt.
                // Mir benotze Kopie fir ze bewegen, an beréieren dëst Element ni méi.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // All Element gëtt veraarbecht.Dëst kann op `set_len` vu LLVM optiméiert ginn.
        drop(g);
    }

    /// Läscht alles ausser déi éischt vun hannereneen Elementer am vector déi sech op dee selwechte Schlëssel léisen.
    ///
    ///
    /// Wann den vector sortéiert ass, läscht dat all Duplikaten.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Läscht all ausser déi éischt vun hannereneen Elementer am vector déi eng gegebene Gläichheetsbezéiung zefridden stellen.
    ///
    /// D `same_bucket` Funktioun gëtt Referenzen op zwee Elementer aus der vector weiderginn a muss bestëmmen ob d'Elementer d'selwecht vergläichen.
    /// D'Elementer ginn am Géigendeel vun hirer Bestellung an der Scheif weiderginn, also wann `same_bucket(a, b)` `true` zréckkënnt, gëtt `a` ewechgeholl.
    ///
    ///
    /// Wann den vector sortéiert ass, läscht dat all Duplikaten.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Füügt en Element um Réck vun enger Sammlung bäi.
    ///
    /// # Panics
    ///
    /// Panics wann déi nei Kapazitéit méi wéi `isize::MAX` Bytes ass.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Dëst wäert panic oder ofbriechen wa mir> isize::MAX Bytes zougedeelt hunn oder wann d'Längtzuel fir Nullgréissten Typen iwwerschwemmt.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Läscht dat lescht Element vun engem vector zréck a gëtt et zréck, oder [`None`] wann et eidel ass.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Beweegt all d'Elementer vun `other` an `Self`, léisst `other` eidel.
    ///
    /// # Panics
    ///
    /// Panics wann d'Zuel vun Elementer am vector en `usize` iwwerschwemmt.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Füügt Elementer op `Self` aus anere Puffer.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Erstellt en draining Iterator deen de spezifizéierte Beräich am vector läscht an déi ewechgeholl Artikele gëtt.
    ///
    /// Wann iterator ** fale gelooss gëtt, ginn all Elementer am Beräich vum vector erofgeholl, och wann den Iterator net voll verbraucht gouf.
    /// Wann den Iterator **net** fale gelooss gëtt (mat [`mem::forget`] zum Beispill), ass net spezifizéiert wéivill Elementer ewechgeholl ginn.
    ///
    /// # Panics
    ///
    /// Panics wann de Startpunkt méi grouss ass wéi den Endpunkt oder wann den Endpunkt méi grouss ass wéi d'Längt vum vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Eng ganz Palette läscht den vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Erënnerung Sécherheet
        //
        // Wann den Drain als éischt erstallt gëtt, verkierzt d'Längt vun der Quell vector fir sécher ze sinn datt keng oninitialiséiert oder geplënnert Elementer iwwerhaapt zougänglech sinn wann den Destructor vum Drain ni leeft.
        //
        //
        // Drain wäert d'Wäerter ptr::read eraushuelen fir ze läschen.
        // Wann Dir fäerdeg ass, gëtt de Rescht Schwanz vum Vec zréck kopéiert fir d'Lach ze decken, an d'vector Längt gëtt an déi nei Längt restauréiert.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // self.vec Längt festleeën fir unzefänken, fir sécher ze sinn am Fall wou Drain leeft
            self.set_len(start);
            // Benotzt de Prêt am IterMut fir e Prêtverhalen vum ganzen Drain Iterator unzeginn (wéi &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Läscht den vector, ewechzehuelen all Wäerter.
    ///
    /// Bedenkt datt dës Method keen Effekt op d'allocéiert Kapazitéit vum vector huet.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Gitt d'Zuel vun Elementer am vector zréck, och als säin 'length' bezeechent.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Retour `true` wann den vector keng Elementer enthält.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Deelt d'Sammlung an zwee am gegebene Index.
    ///
    /// Retourneiert en nei zougewisen vector mat den Elementer am Beräich `[at, len)`.
    /// Nom Uruff bleift den Original vector mat den Elementer `[0, at)` mat senger fréierer Kapazitéit onverännert.
    ///
    ///
    /// # Panics
    ///
    /// Panics wann `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // den neien vector kann den originale Puffer iwwerhuelen an d'Kopie vermeiden
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Onsécher `set_len` a kopéiert Elementer op `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// D'Gréisst vum `Vec` op der Plaz ännert sou datt de `len` dem `new_len` gläich ass.
    ///
    /// Wann `new_len` méi grouss ass wéi `len`, gëtt den `Vec` duerch den Ënnerscheed verlängert, mat all zousätzlech Slot gefëllt mam Resultat fir den Zoumaache `f` ze nennen.
    ///
    /// D'Retourwäerter vun `f` landen am `Vec` an der Reiefolleg wéi se generéiert goufen.
    ///
    /// Wann `new_len` manner wéi `len` ass, gëtt den `Vec` einfach ofgeschnidden.
    ///
    /// Dës Method benotzt eng Zoumaache fir nei Wäerter op all Dréck ze kreéieren.Wann Dir [`Clone`] e bestëmmte Wäert léiwer benotzt, benotzt [`Vec::resize`].
    /// Wann Dir den [`Default`] trait benotze wëllt fir Wäerter ze generéieren, kënnt Dir [`Default::default`] als zweet Argument weiderginn.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Verbraucht a leckert den `Vec`, bréngt eng mutéierbar Referenz zum Inhalt zréck, `&'a mut [T]`.
    /// Bedenkt datt den Typ `T` de gewielte Liewensdauer `'a` muss iwwerliewen.
    /// Wann den Typ nëmmen statesch Referenzen huet, oder guer keng, da kann dat gewielt ginn `'static` ze sinn.
    ///
    /// Dës Funktioun ass ähnlech wéi d [`leak`][Box::leak] Funktioun op [`Box`], ausser datt et kee Wee ass fir de gepaffte Gedächtnis erëmzefannen.
    ///
    ///
    /// Dës Funktioun ass haaptsächlech nëtzlech fir Daten déi fir de Rescht vum Programmliewe liewen.
    /// Déi zréckgezunn Referenz ze falen verursaacht e Gedächtnisleck.
    ///
    /// # Examples
    ///
    /// Einfach Benotzung:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Nees déi verbleiwen Ersatzkapazitéit vum vector als e Stéck vun `MaybeUninit<T>`.
    ///
    /// Déi zréckgezunn Scheif kann benotzt ginn fir den vector mat Daten ze fëllen (z. B.
    /// andeems Dir aus enger Datei liest) ier Dir d'Donnéeë markéiert wéi initialiséiert mat der [`set_len`] Method.
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Allokéiert vector grouss genuch fir 10 Elementer.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Fëllt déi éischt 3 Elementer aus.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Markéiert déi éischt 3 Elementer vum vector als initialiséiert.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Dës Method gëtt net am Sënn vun `split_at_spare_mut` implementéiert, fir Invalidatioun vun Zeigefanger an de Puffer ze vermeiden.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Retour vector Inhalt als Slice of `T`, zesumme mat der verbleibender Ersatzkapazitéit vum vector als Slice of `MaybeUninit<T>`.
    ///
    /// Déi zréckkommt Ersatzkapazitéitsschnitt kann benotzt ginn fir den vector mat Daten ze fëllen (z. B. andeems Dir aus enger Datei liest) ier Dir d'Daten als initialiséiert mat der [`set_len`] Method markéiert.
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Bedenkt datt dëst eng niddereg API ass, déi mat Suergfalt fir Optimiséierungszwecker benotzt soll ginn.
    /// Wann Dir Daten op en `Vec` füügt musst Dir [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] oder [`resize_with`] benotzen, ofhängeg vun Äre genauen Bedierfnesser.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Reservéiert zousätzlech Plaz grouss genuch fir 10 Elementer.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Fëllt déi nächst 4 Elementer aus.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Markéiert déi 4 Elementer vum vector als initialiséiert.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len gëtt ignoréiert an sou ni geännert
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Sécherheet: Ännere geännert .2 (&mut usize) gëllt als déiselwecht wéi `.set_len(_)` ze ruffen.
    ///
    /// Dës Method gëtt benotzt fir eenzegaarteg Zougang zu all Vec Deeler gläichzäiteg am `extend_from_within` ze hunn.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` ass garantéiert gëlteg fir `len` Elementer
        // - `spare_ptr` weist een Element laanscht de Puffer, sou datt et net mat `initialized` iwwerlappt
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// D'Gréisst vum `Vec` op der Plaz ännert sou datt de `len` dem `new_len` gläich ass.
    ///
    /// Wann `new_len` méi grouss ass wéi `len`, gëtt den `Vec` duerch den Ënnerscheed verlängert, mat all zousätzlech Slot mat `value` gefëllt.
    ///
    /// Wann `new_len` manner wéi `len` ass, gëtt den `Vec` einfach ofgeschnidden.
    ///
    /// Dës Method erfuerdert `T` fir [`Clone`] ëmzesetzen, fir de passéierte Wäert ze klonéieren.
    /// Wann Dir méi Flexibilitéit braucht (oder wëllt op [`Default`] amplaz [`Clone`] vertrauen), benotzt [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Klonéiert an all Elementer an engem Stéck op den `Vec` bäifügt.
    ///
    /// Iteréiert iwwer d'Scheibe `other`, klonéiert all Element, an füügt se dann op dësen `Vec` an.
    /// Den `other` vector gëtt an der Uerdnung duerchgestrachen.
    ///
    /// Bedenkt datt dës Funktioun d'selwecht ass wéi [`extend`] ausser datt se spezialiséiert ass mat Stécker amplaz ze schaffen.
    ///
    /// Wann a wéini Rust Spezialiséierung kritt, gëtt dës Funktioun wahrscheinlech ofgeleent (awer nach verfügbar).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Kopéiert Elementer aus dem `src` Beräich bis zum Enn vum vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` garantéiert datt de gegebene Beräich valabel ass fir selwer ze indexéieren
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Dëse Code generaliséiert `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Verlängert den vector mat `n` Wäerter, mat dem gegebene Generator.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Benotzt SetLenOnDrop fir e Feeler ze schaffen, wou de Compiler de Buttek net duerch `ptr` duerch self.set_len() realiséiere kann net alias.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Schreift all Elementer ausser déi lescht
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Inkrementéiert d'Längt an all Schrëtt am Fall next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Mir kënnen dat lescht Element direkt schreiwen ouni onnéideg ze klonen
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len gesat vum Scope Guard
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Läscht noeneen widderholl Elementer am vector no der [`PartialEq`] trait Ëmsetzung.
    ///
    ///
    /// Wann den vector sortéiert ass, läscht dat all Duplikaten.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Intern Methoden a Funktiounen
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` muss gëlteg Index sinn
    /// - `self.capacity() - self.len()` muss `>= src.len()` sinn
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len gëtt eréischt erhéicht nodeems Elementer initialiséiert goufen
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - Uruff garantéiert datt src e gültegen Index ass
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Element gouf just mat `MaybeUninit::write` initialiséiert, also ass et ok Len ze erhéijen
            // - Len gëtt no all Element erhéicht fir Leckeren ze vermeiden (kuckt Thema #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - Uruff garantéiert datt `src` e gültegen Index ass
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Béid Zeechner ginn aus eenzegaartege Scheifreferenzen erstallt (`&mut [_]`) sou datt se valabel sinn an net iwwerlappend sinn.
            //
            // - Elementer sinn: Kopéiert also ass et OK se ze kopéieren, ouni eppes mat den originelle Wäerter ze maachen
            // - `count` ass gläich wéi d'Len vun `source`, also ass d'Quell gëlteg fir `count` ze liesen
            // - `.reserve(count)` garantéiert datt `spare.len() >= count` sou Ersatz valabel ass fir `count` schreift
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - D'Elementer goufe just vun `copy_nonoverlapping` initialiséiert
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Gemeinsam trait Implementatiounen fir Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): mat cfg(test) ass déi ugebuer `[T]::to_vec` Method, déi fir dës Method Definitioun erfuerderlech ass, net verfügbar.
    // Amplaz d `slice::to_vec` Funktioun ze benotzen déi nëmme mat cfg(test) verfügbar ass Kuckt de slice::hack Modul am slice.rs fir méi Informatioun
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // alles fale loossen wat net iwwerschriwwe gëtt
        self.truncate(other.len());

        // self.len <= other.len wéinst der Ofkierzung uewen, sou datt d'Scheiwen hei ëmmer a Grenzen sinn.
        //
        let (init, tail) = other.split_at(self.len());

        // reuse benotzte Wäerter allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Erstellt e verbrauchenden Iterator, dat heescht een deen all Wäert aus dem vector réckelt (vun Ufank bis Enn).
    /// Den vector kann net benotzt ginn nodeems Dir dëst opgeruff huet.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s huet Typ String, net &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // Blatmethod op déi verschidde SpecFrom/SpecExtend Implementéierungen delegéieren wa se keng weider Optimiséierungen hunn fir ze gëllen
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Dëst ass de Fall fir en allgemengen Iterator.
        //
        // Dës Funktioun sollt de moraleschen Äquivalent sinn vun:
        //
        //      fir Element am Iterator {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB kann net iwwerschwemmen well mir hätten den Adressraum musse verdeelen
                self.set_len(len + 1);
            }
        }
    }

    /// Erstellt e Splizéierteriterator deen de spezifizéierte Beräich am vector duerch de gegebene `replace_with`-Iterator ersetzt an déi ewechgeholl Artikele gëtt.
    ///
    /// `replace_with` brauch net déiselwecht Längt wéi `range` ze sinn.
    ///
    /// `range` gëtt geläscht och wann den Iterator net bis zum Enn verbraucht gëtt.
    ///
    /// Et ass net spezifizéiert wéi vill Elementer aus dem vector erausgeholl ginn wann de `Splice` Wäert ausgelooss gëtt.
    ///
    /// Den Input Iterator `replace_with` gëtt nëmme verbraucht wann den `Splice` Wäert fale gelooss gëtt.
    ///
    /// Dëst ass optimal wann:
    ///
    /// * De Schwanz (Elementer am vector nom `range`) ass eidel,
    /// * oder `replace_with` bréngt manner oder gläich Elementer wéi d'Längt vun der "Gamme"
    /// * oder déi ënnescht Grenz vu sengem `size_hint()` ass exakt.
    ///
    /// Soss gëtt en temporäre vector zougewisen an de Schwanz gëtt zweemol geréckelt.
    ///
    /// # Panics
    ///
    /// Panics wann de Startpunkt méi grouss ass wéi den Endpunkt oder wann den Endpunkt méi grouss ass wéi d'Längt vum vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Erstellt en Iterator deen eng Zoumaache benotzt fir festzestellen ob en Element soll ewechgeholl ginn.
    ///
    /// Wann d'Zoumaache richteg ass, da gëtt d'Element ewechgeholl an erginn.
    /// Wann d'Zoumaache falsch zréckgeet, bleift d'Element am vector a gëtt net vum Iterator erginn.
    ///
    /// Mat dëser Method ass gläichwäerteg dem folgende Code:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // Äre Code hei
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Awer `drain_filter` ass méi einfach ze benotzen.
    /// `drain_filter` ass och méi effizient, well et kann d'Elementer vum Array am Grousse backshift.
    ///
    /// Bedenkt datt `drain_filter` och léisst Dir all Element an der Filterverschlësselung mutéieren, egal ob Dir wielt se ze halen oder ze läschen.
    ///
    ///
    /// # Examples
    ///
    /// En Array an Gläicher a Quoten opzedeelen, d'Original Bewëllegung weiderbenotzen:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Schützt géint eis ze lecken (Leckverstäerkung)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Verlängert d'Implementatioun déi Elementer aus Referenzen kopéiert ier se op de Vec gedréckt ginn.
///
/// Dës Ëmsetzung ass spezialiséiert fir Slice-Iteratoren, wou se [`copy_from_slice`] benotzt fir de ganze Slice gläichzäiteg anzebezéien.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Implementéiert de Verglach vun vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Implementéiert Bestellung vun vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // Benotzt Drop fir [T] benotzt e roude Scheif fir d'Elementer vum vector als schwaachst noutwendeg Aart ze bezeechnen;
            //
            // kéint a bestëmmte Fäll Froen iwwer Validitéit vermeiden
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec behandelt Deallocation
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Erstellt en eidelen `Vec<T>`.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: Test zitt an libstd, wat hei Feeler verursaacht
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: Test zitt an libstd, wat hei Feeler verursaacht
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Kritt de ganzen Inhalt vun der `Vec<T>` als en Array, wann d'Gréisst exakt mat där vum gefrote Array entsprécht.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Wann d'Längt net passt, kënnt den Input zréck an `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Wann Dir gutt sidd mat just e Präfix vum `Vec<T>` ze kréien, kënnt Dir d [`.truncate(N)`](Vec::truncate) als éischt uruffen.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // SAFETY: `.set_len(0)` ass ëmmer gesond.
        unsafe { vec.set_len(0) };

        // SIKKERHET: De Zeiger vun engem "Vec" ass ëmmer richteg ausgeriicht, an
        // d'Ausriichtung déi d'Array brauch ass d'selwecht wéi d'Elementer.
        // Mir hu virdru kontrolléiert datt mir genuch Saachen hunn.
        // D'Elementer ginn net duebel erof well d `set_len` seet dem `Vec` se och net fale loossen.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}