use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Spezialiséierungsmarker fir eng Iterator-Pipeline an e Vec ze sammelen beim Quellentildung erëmbenotzung, d
/// d'Pipeline op der Plaz auszeféieren.
///
/// De SourceIter Elterendeel trait ass noutwendeg fir d'Spezialiséierungsfunktioun fir Zougang zu der Bewëllegung ze kréien déi nei benotzt gëtt.
/// Awer et geet net duer datt d'Spezialiséierung gëlteg ass.
/// Kuckt zousätzlech Grenzen op der Impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// D'std-intern SourceIter/InPlaceIterable traits ginn nëmme vu Adapterketten implementéiert <Adapter<Adapter<IntoIter>>> (alles am Besëtz vun core/std).
// Zousätzlech Grenzen op den Adapterimplementéierungen (ausser `impl<I: Trait> Trait for Adapter<I>`) hänken nëmmen vun aneren traits of, déi scho als Spezialiséierung traits (Copy, TrustedRandomAccess, FusedIterator) markéiert sinn.
//
// I.e. de Marker hänkt net vu Liewensdauer vu Benotzerversuergten Typen of.Modulo the Copy Loch, op dat e puer aner Spezialiséierungen schonn ofhängeg sinn.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Zousätzlech Ufuerderungen déi net iwwer trait bounds ausgedréckt kënne ginn.Mir vertrauen op const eval amplaz:
        // a) keng ZSTs well et wier keng Bewëllegung fir weiderbenotzen an Zeechner Arithmetik géif panic b) Gréisst passt wéi erfuerderlech vum Alloc Kontrakt c) Ausrichtunge passen wéi gefuerdert vum Alloc Kontrakt
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // Réckfall op méi generesch Implementatiounen
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // benotz Try-Fold zënter
        // - et vectoriséiert besser fir verschidde Iterator-Adapteren
        // - am Géigesaz zu de meeschten internen Iteratiounsmethoden, brauch et nëmmen e &mut Selbst
        // - et léisst eis de Schreifweiger duerch seng Innere verdrängen an um Enn erëmkritt
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // Iteratioun gelongen, net Kapp falen
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // préift ob de SourceIter Kontrakt opgehale gouf: wa se net wieren, da komme mir et mol net zu dësem Punkt
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // kontrolléieren InPlaceIterable Kontrakt.Dëst ass nëmme méiglech wann den Iterator de Quellzeiger iwwerhaapt fortgeschratt huet.
        // Wann et onkontrolléiert Zougang iwwer TrustedRandomAccess benotzt, da bleift de Quellzeiger op der éischter Positioun a mir kënnen et net als Referenz benotzen
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // fällt all verbleiwen Wäerter um Schwanz vun der Quell awer verhënnert Drëps vun der Bewëllegung selwer eemol IntoIter geet aus dem Ëmfang wann d'Drop panics da fuere mir och all Elementer gesammelt an dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // den InPlaceIterable Kontrakt kann net präzis hei verifizéiert ginn zënter try_fold huet eng exklusiv Referenz zum Quellzeiger alles wat mir maache kënnen ass ze kontrolléieren ob et nach ëmmer am Beräich ass
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}