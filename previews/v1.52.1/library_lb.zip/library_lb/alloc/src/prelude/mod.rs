//! D'Allocatioun Prelude
//!
//! Den Zweck vun dësem Modul ass d'Importer vun allgemeng benotzten Elementer vun der `alloc` crate ze linderen andeems en Globimport uewen op Moduler bäisetzt:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;