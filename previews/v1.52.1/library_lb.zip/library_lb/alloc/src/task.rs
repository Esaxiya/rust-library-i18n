#![stable(feature = "wake_trait", since = "1.51.0")]
//! Typen an Traits fir mat asynchronen Aufgaben ze schaffen.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// D'Ëmsetzung vun enger Aufgab op engem Exekutor erwächen.
///
/// Dësen trait kann benotzt ginn fir en [`Waker`] ze kreéieren.
/// En Exekutor kann eng Implementatioun vun dësem trait definéieren, a benotze fir e Waker ze konstruéiere fir un d'Aufgaben ze ginn, déi op deen Exekutor ausgefouert ginn.
///
/// Dësen trait ass eng Gedächtnis-sécher an ergonomesch Alternativ zum Bau vun engem [`RawWaker`].
/// Et ënnerstëtzt de gemeinsamen Exekutor Design, an deem d'Donnéeë benotzt fir eng Aufgab ze erwächen an engem [`Arc`] gelagert sinn.
/// E puer Exekutoren (besonnesch déi fir agebett Systemer) kënnen dës API net benotzen, dofir existéiert [`RawWaker`] als Alternativ fir dës Systemer.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Eng Basis `block_on` Funktioun déi eng future hëlt a se bis zum Ofschloss am aktuellen Thread leeft.
///
/// **Note:** Dëst Beispill verhandelt Richtegkeet fir Einfachheet.
/// Fir Deadlocks ze vermeiden, mussen d'Produktiounsgrad Implementatiounen och mëttler Uriff op `thread::unpark` wéi och veruersaacht Invokatiounen handhaben.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// E Waker deen den aktuelle Fuedem waakreg mécht wann en urufft.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Féiert en future bis zum Ofschloss am aktuellen Fuedem.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Pin den future fir datt et kann gepolléiert ginn.
///     let mut fut = Box::pin(fut);
///
///     // Erstellt en neie Kontext fir un d'future weidergeleet ze ginn.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Féiert den future bis zum Ofschloss.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Erwächt dës Aufgab.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Waacht dës Aufgab ouni de Waker ze konsuméieren.
    ///
    /// Wann en Exekutor e méi bëllege Wee ënnerstëtzt fir ze erwächen ouni de Waker ze konsuméieren, sollt et dës Method iwwerschreiden.
    /// Par défaut klon et den [`Arc`] a rifft [`wake`] op de Klon.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // SAFETY: Dëst ass sécher well raw_waker sécher konstruéiert
        // e RawWaker vun Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Dës privat Funktioun fir e RawWaker ze bauen gëtt benotzt, anstatt
// dëst an den `From<Arc<W>> for RawWaker` Implement inlining, fir sécher ze sinn, datt d'Sécherheet vum `From<Arc<W>> for Waker` net vun der richteger trait Versand hänkt, amplaz béid impls dës Funktioun direkt an explizit ze nennen.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Inkrementéiert de Referenzzuel vum Bogen fir et ze klonen.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Waak mam Wäert, réckelt den Arc an d Wake::wake Funktioun
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Erwächt mat Referenz, packt de Waker an ManuallyDrop fir ze vermeiden
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Redukt de Referenzzuel vum Arc on Drop
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}