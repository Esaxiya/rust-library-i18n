//! Single-threaded Referenz-Zielen Indikatiounen.'Rc' steet fir 'Referenz
//! Counted'.
//!
//! Den Typ [`Rc<T>`][`Rc`] bitt e gemeinsame Besëtz vun engem Wäert vum Typ `T`, deen am Koup zougewisen ass.
//! [`clone`][clone] op [`Rc`] opruffen produzéiert en neie Zeiger zu der selwechter Bewëllegung am Koup.
//! Wann de leschten [`Rc`] Zeiger zu enger bestëmmter Bewëllegung zerstéiert gëtt, gëtt de Wäert an där Bewëllegung (dacks als "inner value" bezeechent) och fale gelooss.
//!
//! Gedeelt Referenzen an Rust verbidden d'Mutatioun als Standard, an [`Rc`] ass keng Ausnahm: Dir kënnt normalerweis net eng mutéierbar Referenz op eppes an engem [`Rc`] kréien.
//! Wann Dir Verännerlechkeet braucht, setzt en [`Cell`] oder [`RefCell`] an den [`Rc`];gesinn [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] benotzt net-atomesch Referenzzählung.
//! Dëst bedeit datt Overhead ganz niddereg ass, awer en [`Rc`] kann net tëscht Fiedem geschéckt ginn, an deementspriechend implementéiert [`Rc`] net [`Send`][send].
//! Als Resultat kontrolléiert den Rust Compiler *bei der Zäit kompiléieren* datt Dir keng [`Rc`] tëscht de Fiedere schéckt.
//! Wann Dir Multi-threaded, atomarer Referenzzählung braucht, benotzt [`sync::Arc`][arc].
//!
//! D [`downgrade`][downgrade] Method kann benotzt ginn fir en net Besëtzende [`Weak`] Zeiger ze kreéieren.
//! En [`Weak`] Zeiger kann [`upgrade`][upgrade] d op en [`Rc`] sinn, awer dëst wäert [`None`] zréckkommen wann de Wäert deen an der Bewëllegung gespäichert gouf scho fale gelooss gouf.
//! An anere Wierder, `Weak` Zeigefanger halen de Wäert net an der Bewëllegung lieweg;awer,*se* halen d'Allocatioun (de Backing Store fir den banneschte Wäert) lieweg.
//!
//! En Zyklus tëscht [`Rc`] Zeigefanger gëtt ni Deallokaliséiert.
//! Aus dësem Grond gëtt [`Weak`] benotzt fir Zyklen ze briechen.
//! Zum Beispill kéint e Bam staark [`Rc`] Zeigefanger vun Elterenknäpp fir Kanner hunn, an [`Weak`] Zeigefanger vu Kanner zréck bei hir Elteren.
//!
//! `Rc<T>` automatesch Dereferenzen op `T` (iwwer den [`Deref`] trait), sou datt Dir 'T' Methoden op e Wäert vum Typ [`Rc<T>`][`Rc`] nennen.
//! Fir Nummkonflikter mat "T" Methoden ze vermeiden, sinn d'Methode vum [`Rc<T>`][`Rc`] selwer assoziéiert Funktiounen, genannt [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>D'Ëmsetzung vun traits wéi `Clone` kann och mat vollqualifizéierter Syntax genannt ginn.
//! E puer Leit benotze léiwer vollqualifizéiert Syntax, anerer benotze léiwer Method-Call Syntax.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Method-Call Syntax
//! let rc2 = rc.clone();
//! // Vollqualifizéiert Syntax
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] mécht keen Auto-Dereferenz zu `T`, well de banneschte Wäert scho fale gelooss ass.
//!
//! # Klonen Referenzen
//!
//! Erstelle vun enger neier Referenz zu der selwechter Bewëllegung wéi e existent Referenz gezielt Zeiger gëtt mat der `Clone` trait gemaach fir [`Rc<T>`][`Rc`] an [`Weak<T>`][`Weak`] implementéiert.
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Déi zwou Syntaxen hei ënnendrënner sinn gläichwäerteg.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a an b weisen all op déi selwecht Erënnerungsplaz wéi foo.
//! ```
//!
//! D `Rc::clone(&from)` Syntax ass déi idiomatesch, well se méi explizit d'Bedeitung vum Code vermëttelt.
//! Am Beispill hei uewen mécht dës Syntax et méi einfach ze gesinn datt dëse Code eng nei Referenz erstellt anstatt de ganzen Inhalt vu foo ze kopéieren.
//!
//! # Examples
//!
//! Betruecht e Szenario wou e Set vu `Gadget`s vun engem gegebene `Owner` gehéiert.
//! Mir wëllen eise "Gadget" op hiren `Owner` weisen.Mir kënnen dat net mam eenzegaartege Besëtz maachen, well méi wéi ee Gadget kann zum selwechte `Owner` gehéieren.
//! [`Rc`] erlaabt eis en `Owner` tëscht méi "Gadget`s ze deelen, an den `Owner` soulaang wéi all `Gadget` Punkten drop zougewisen ze bleiwen.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... aner Felder
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... aner Felder
//! }
//!
//! fn main() {
//!     // Erstellt e Referenz gezielt `Owner`.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Erstellt `Gadget`s déi zu `gadget_owner` gehéieren.
//!     // D'Cloning vum `Rc<Owner>` gëtt eis en neie Zeiger zu der selwechter `Owner` Bewëllegung, andeems d'Referenzzuel am Prozess eropgeet.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Entsuergt eis lokal Variabel `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Trotz dem `gadget_owner` erofsetzen, kënne mir nach ëmmer den Numm vum `Owner` vun der "Gadget" drécken.
//!     // Dëst ass well mir nëmmen een eenzegen `Rc<Owner>` erofgelooss hunn, net den `Owner` op deen et weist.
//!     // Soulaang et aner `Rc<Owner>` op déiselwecht `Owner` Bewëllegung ginn, bleift et live.
//!     // D'Feldprojektioun `gadget1.owner.name` funktionnéiert well `Rc<Owner>` automatesch Dereferenzen op `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Um Enn vun der Funktioun ginn `gadget1` an `gadget2` zerstéiert, a mat hinnen déi lescht gezielt Referenzen zu eisem `Owner`.
//!     // Gadget Man gëtt elo och zerstéiert.
//!     //
//! }
//! ```
//!
//! Wann eis Ufuerderunge geännert ginn, a mir mussen och fäeg sinn vun `Owner` op `Gadget` duerchzekommen, wäerte mir a Problemer lafen.
//! En [`Rc`] Zeiger vun `Owner` op `Gadget` stellt en Zyklus vir.
//! Dëst bedeit datt hir Referenzzuelen ni 0 erreeche kënnen, an d'Allocatioun ni zerstéiert gëtt:
//! eng Erënnerung Leck.Fir dëst ëmzegoen, kënne mir [`Weak`] Zeigefanger benotzen.
//!
//! Rust mécht et tatsächlech schwéier fir dës Loop iwwerhaapt ze produzéieren.Fir mat zwou Wäerter op en Enn ze kommen, muss ee vun hinnen mutabel sinn.
//! Dëst ass schwéier well [`Rc`] d'Gedächtnessécherheet duerchsetzt andeems se nëmme gedeelt Referenze fir de Wäert gëtt deen et ëmfaasst, an dës erlaben net direkt Mutatioun.
//! Mir mussen deen Deel vum Wäert wéckelen, dee mir mutéiere wëllen an engem [`RefCell`], deen *Interieur Mutabilitéit* bitt: eng Method fir d'Mutabilitéit duerch eng gemeinsam Referenz z'erreechen.
//! [`RefCell`] Duerchsetzt d'Rust Prêtregele bei der Runtime.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... aner Felder
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... aner Felder
//! }
//!
//! fn main() {
//!     // Erstellt e Referenz gezielt `Owner`.
//!     // Bedenkt datt mir den "Besëtzer" vector vu "Gadget" an engem `RefCell` gesat hunn, sou datt mir et duerch eng gemeinsam Referenz mutéiere kënnen.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Erstellt `Gadget`s déi zu `gadget_owner` gehéieren, wéi virdrun.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Füügt de `Gadget`s op hiren `Owner` bäi.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` dynamesch léinen hält hei op.
//!     }
//!
//!     // Iteréiert iwwer eise `Gadget`s, dréckt hir Detailer aus.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` ass en `Weak<Gadget>`.
//!         // Well `Weak` Zeigefanger net garantéieren datt d'Allocation nach existéiert, musse mir `upgrade` uruffen, wat en `Option<Rc<Gadget>>` zréckbréngt.
//!         //
//!         //
//!         // An dësem Fall wësse mer datt d'Allocatioun nach ëmmer existéiert, also `unwrap` den `Option` einfach.
//!         // An engem méi komplizéierte Programm brauch Dir vläicht gnädeg Feelerbehandlung fir e `None` Resultat.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Um Enn vun der Funktioun sinn `gadget_owner`, `gadget1` an `gadget2` zerstéiert.
//!     // Et ginn elo keng staark (`Rc`) Zeigefanger op de Gadgeten, sou datt se zerstéiert ginn.
//!     // Dëst nullt d'Referenzzuel op Gadget Man, sou datt hien och zerstéiert gëtt.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Dëst ass repr(C) bis future-Beweis géint méiglech Felduerdnung, wat anescht sécher [into|from]_raw() vu transmutierbaren bannent Typen stéieren.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// En eenzege Fuedem Referenzzuel Zeiger.'Rc' steet fir 'Referenz
/// Counted'.
///
/// Kuckt d [module-level documentation](./index.html) fir méi Detailer.
///
/// Déi ugebuerene Methode vun `Rc` sinn all assoziéiert Funktiounen, dat heescht datt Dir se nennt wéi zB [`Rc::get_mut(&mut value)`][get_mut] amplaz `value.get_mut()`.
/// Dëst vermeit Konflikter mat Methode vum banneschten Typ `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Dës Onsécherheet ass ok, well wa dësen RC lieweg ass, si mir garantéiert datt de banneschten Zeiger valabel ass.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Baut en neien `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Et ass en implizitte schwaache Zeiger vun all de staarken Zeechner, déi garantéiert datt de schwaachen Zerstéierer d'Allocatioun ni befreit wann de staarken Zerstéierer leeft, och wann de schwaache Weiger an deem staarke gespäichert ass.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Baut en neien `Rc<T>` mat enger schwaacher Referenz op sech selwer.
    /// Probéiert déi schwaach Referenz ze aktualiséieren ier dës Funktioun zréckkomm ass, gëtt zu engem `None` Wäert.
    ///
    /// Wéi och ëmmer, déi schwaach Referenz ka fräi gekloont ginn a spéider gespäichert ginn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... méi Felder
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Konstruéiert den Innen am "uninitialized" Staat mat enger eenzeger schwaacher Referenz.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Et ass wichteg datt mir de Besëtz vum schwaache Zeiger net opginn, soss kéint d'Erënnerung fräi gi wéi d `data_fn` zréck ass.
        // Wa mir wierklech d'Besëtzer weidergoe wollten, kéinte mir en zousätzleche schwaache Zeiger fir eis selwer kreéieren, awer dëst géif zu zousätzlechen Aktualiséierunge vum schwaache Referenzzuel resultéieren, wat soss net néideg wier.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Staark Referenze solle kollektiv eng gemeinsam schwaach Referenz besëtzen, also féiert den Destruktor net fir eis al schwaach Referenz.
        //
        mem::forget(weak);
        strong
    }

    /// Baut en neien `Rc` mat uninitialiséierten Inhalt.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Deferred Initialiséierung:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Baut en neien `Rc` mat uninitialiséierten Inhalt, mat der Erënnerung mat `0` Bytes gefëllt.
    ///
    ///
    /// Kuckt [`MaybeUninit::zeroed`][zeroed] fir Beispiller fir korrekt a falsch Benotze vun dëser Method.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Baut en neien `Rc<T>`, gëtt e Feeler zréck wann d'Allocatioun ausfält
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Et ass en implizitte schwaache Zeiger vun all de staarken Zeechner, déi garantéiert datt de schwaachen Zerstéierer d'Allocatioun ni befreit wann de staarken Zerstéierer leeft, och wann de schwaache Weiger an deem staarke gespäichert ass.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Baut en neien `Rc` mat oninitialiséierten Inhalt, zréck e Feeler wann d'Allocatioun ausfält
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Deferred Initialiséierung:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Baut en neien `Rc` mat net-initialiséierten Inhalt, mat der Erënnerung mat `0` Bytes gefëllt, an e Feeler zréck wann d'Allocatioun net geet
    ///
    ///
    /// Kuckt [`MaybeUninit::zeroed`][zeroed] fir Beispiller fir korrekt a falsch Benotze vun dëser Method.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Baut en neien `Pin<Rc<T>>`.
    /// Wann `T` `Unpin` net implementéiert, da gëtt `value` an der Erënnerung festgehal a kann net geréckelt ginn.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Nees de banneschte Wäert, wann den `Rc` genau eng staark Referenz huet.
    ///
    /// Soss gëtt en [`Err`] mat der selwechter `Rc` zréckginn, déi eraginn ass.
    ///
    ///
    /// Dëst wäert Erfolleg och wann et aussergewéinlech schwaach Referenze sinn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // kopéiert den enthale Objet

                // Weist fir Schwächen datt se net kënne gefördert ginn andeems de staarke Grof ofgeholl gëtt, an dann den impliziten "strong weak" Zeiger ewechhuelen andeems Dir och Drop-Logik behandelt andeems Dir just e falsch Schwächt bastelt.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Baut eng nei Referenz gezielt Scheif mat oninitialiséierten Inhalt.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Deferred Initialiséierung:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Baut eng nei Referenz gezielt Scheif mat oninitialiséierten Inhalt, mat der Erënnerung mat `0` Bytes gefëllt.
    ///
    ///
    /// Kuckt [`MaybeUninit::zeroed`][zeroed] fir Beispiller fir korrekt a falsch Benotze vun dëser Method.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Konvertéiert op `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Wéi mat [`MaybeUninit::assume_init`] ass et un den Uruffer ze garantéieren datt de banneschte Wäert wierklech an engem initialiséierte Staat ass.
    ///
    /// Dëst nennen wann den Inhalt nach net komplett initialiséiert ass verursaacht direkt ondefinéiert Verhalen.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Deferred Initialiséierung:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Konvertéiert op `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Wéi mat [`MaybeUninit::assume_init`] ass et un den Uruffer ze garantéieren datt de banneschte Wäert wierklech an engem initialiséierte Staat ass.
    ///
    /// Dëst nennen wann den Inhalt nach net komplett initialiséiert ass verursaacht direkt ondefinéiert Verhalen.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Deferred Initialiséierung:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Verbraucht den `Rc`, bréngt de gewéckelte Zeiger zréck.
    ///
    /// Fir e Gedächtnissleck ze vermeiden, muss de Zeiger zréck an en `Rc` mat [`Rc::from_raw`][from_raw] ëmgewandelt ginn.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Bitt e roude Zeiger fir d'Daten.
    ///
    /// D'Zuelen sinn op kee Fall beaflosst an den `Rc` gëtt net verbraucht.
    /// De Zeiger ass valabel soulaang et staark Zuelen am `Rc` sinn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // SAFETY: Dëst kann net duerch Deref::deref oder Rc::inner goen well
        // dëst ass erfuerderlech fir d raw/mut Provenz ze halen sou datt z
        // `get_mut` kann duerch de Zeiger schreiwen nodeems de Rc duerch `from_raw` erholl ass.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Baut en `Rc<T>` aus engem réiem Zeigefanger.
    ///
    /// De roude Zeiger muss virdru vun engem Uruff op [`Rc<U>::into_raw`][into_raw] zréckkoum, wou `U` déiselwecht Gréisst an Ausriichtung wéi `T` muss hunn.
    /// Dëst ass trivial richteg wann `U` `T` ass.
    /// Bedenkt datt wann `U` net `T` ass awer déiselwecht Gréisst an Ausriichtung ass, ass dat am Fong wéi Transmissioun vu Referenzen vun verschiddenen Typen.
    /// Kuckt [`mem::transmute`][transmute] fir méi Informatiounen iwwer wéi eng Restriktiounen an dësem Fall gëllen.
    ///
    /// De Benotzer vun `from_raw` muss sécher sinn datt e spezifesche Wäert vun `T` nëmmen eemol fale gelooss gëtt.
    ///
    /// Dës Funktioun ass onsécher well falsch Notzung zu Erënnerung onsécherheet féiere kann, och wann de `Rc<T>` zréck ass ni zougänglech.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Konvertéiert zréck op en `Rc` fir Leck ze vermeiden.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Weider Uriff op `Rc::from_raw(x_ptr)` wieren Memory-onsécher.
    /// }
    ///
    /// // D'Erënnerung gouf befreit wann `x` ausserhalb vum Ëmfang erausgaang ass, sou datt den `x_ptr` elo hänkt!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Ëmgedréit den Offset fir d'Original RcBox ze fannen.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Erstellt en neien [`Weak`] Zeiger fir dës Bewëllegung.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Passt op datt mir keen hängende Schwächt kreéieren
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Kritt d'Zuel vun [`Weak`] Zeigefanger zu dëser Bewëllegung.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Kritt d'Zuel vu staarke (`Rc`) Zeigefanger fir dës Bewëllegung.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Retour `true` wann et keng aner `Rc` oder [`Weak`] Zeigefanger zu dëser Bewëllegung sinn.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Gitt eng mutéierbar Referenz an de gegebene `Rc`, wann et keng aner `Rc` oder [`Weak`] Zeigefanger zu der selwechter Bewëllegung sinn.
    ///
    ///
    /// Retour [`None`] anescht, well et net sécher ass e gemeinsame Wäert ze mutéieren.
    ///
    /// Kuckt och [`make_mut`][make_mut], wat [`clone`][clone] de banneschte Wäert wäert wann et aner Zeigefanger sinn.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Gitt eng mutéierbar Referenz an de gegebene `Rc` zréck, ouni Kontroll.
    ///
    /// Kuckt och [`get_mut`], dat ass sécher a passend Kontrollen.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// All aner `Rc`-oder [`Weak`]-Zeigefanger zu der selwechter Bewëllegung däerfen net fir d'Dauer vum zréckgeléinte Loun verfeiert ginn.
    ///
    /// Dëst ass trivial de Fall wa keng esou Hiweiser existéieren, zum Beispill direkt nom `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Mir si virsiichteg *net* eng Referenz ze kreéieren déi d "count" Felder deckt, well dëst mat den Zougang zu de Referenzzuelen (z. B.
        // vun `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Retour `true` wann déi zwee `Rc`s op déiselwecht Verdeelung weisen (an engem Sënn ähnlech wéi [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Maacht eng mutéierbar Referenz an de gegebene `Rc`.
    ///
    /// Wann et aner `Rc` Zeigefanger zu der selwechter Bewëllegung ginn, da wäert `make_mut` den banneschten Wäert vun enger neier Bewëllegung [`clone`] fir en eenzegaartegt Eegentum ze garantéieren.
    /// Dëst gëtt och als Klon-on-Write bezeechent.
    ///
    /// Wann et keng aner `Rc` Zeigefanger zu dëser Bewëllegung sinn, da ginn [`Weak`] Zeigefanger zu dëser Bewëllegung ofgebaut.
    ///
    /// Kuckt och [`get_mut`], wat fällt anstatt ze klonen.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Wäert näischt klonéieren
    /// let mut other_data = Rc::clone(&data);    // Wäert net bannen Daten klonéieren
    /// *Rc::make_mut(&mut data) += 1;        // Klon bannen Daten
    /// *Rc::make_mut(&mut data) += 1;        // Wäert näischt klonéieren
    /// *Rc::make_mut(&mut other_data) *= 2;  // Wäert näischt klonéieren
    ///
    /// // Elo `data` an `other_data` weisen op verschidden Allocatiounen.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] Uweiser ginn ofgebaut:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Muss d'Donnéeë klonéieren, et ginn aner RCen.
            // Pre-allocéiere Gedächtnis fir de klonéierte Wäert direkt ze schreiwen.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Kann just d'Donnéeë klauen, et bleift just nach Schwächen
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Ewechhuele implizit staark-schwaach Ref (keng Notwendegkeet e falsche Schwächen hei ze bastelen-mir wëssen datt aner Schwäche fir eis kënnen opraumen)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Dës Onsécherheet ass ok, well mir si garantéiert datt de Zeiger zréck den *eenzegen* Zeiger ass deen jeemools op T zréckgesat gëtt.
        // Eist Referenzzuel ass garantéiert 1 op dësem Punkt ze sinn, a mir hunn den `Rc<T>` selwer `mut` missen sinn, sou datt mir déi eenzeg méiglech Referenz op d'Allocatioun zréckginn.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Versicht den `Rc<dyn Any>` op e konkreten Typ erofzesetzen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Allokéiert en `RcBox<T>` mat genuch Plaz fir e méiglecherweis net-Gréisst bannent Wäert wou de Wäert de Layout huet.
    ///
    /// D'Funktioun `mem_to_rcbox` gëtt mam Datenzeiger geruff a muss e (potenziell fettegen) Punkt fir den `RcBox<T>` zréckginn.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Berechent Layout mat dem gegebene Wäert Layout.
        // Virdru gouf de Layout op den Ausdrock `&*(ptr as* const RcBox<T>)` berechent, awer dëst huet eng falsch ausgeriicht Referenz erstallt (kuck #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Allokéiert en `RcBox<T>` mat genuch Plaz fir e méiglecherweis net-Gréisst bannent Wäert, wou de Wäert de Layout zur Verfügung gestallt huet, an e Feeler zréckbréngt wann d'Allocatioun net geet.
    ///
    ///
    /// D'Funktioun `mem_to_rcbox` gëtt mam Datenzeiger geruff a muss e (potenziell fettegen) Punkt fir den `RcBox<T>` zréckginn.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Berechent Layout mat dem gegebene Wäert Layout.
        // Virdru gouf de Layout op den Ausdrock `&*(ptr as* const RcBox<T>)` berechent, awer dëst huet eng falsch ausgeriicht Referenz erstallt (kuck #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Allocéiert fir de Layout.
        let ptr = allocate(layout)?;

        // Initialiséiert d'RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Allokéiert en `RcBox<T>` mat genuch Plaz fir en net-grousse banneschte Wäert
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Allocéiert fir den `RcBox<T>` mat dem gegebene Wäert.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopéiert Wäert als Bytes
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Fräi d'Allocatioun ouni hiren Inhalt erofzesetzen
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Allokéiert en `RcBox<[T]>` mat der bestëmmter Längt.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Kopéiert Elementer aus der Scheif an nei zougewisen Rc <\[T\]>
    ///
    /// Onsécher well de Ruffer muss entweder Besëtz huelen oder `T: Copy` bannen
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Baut en `Rc<[T]>` vun engem Iterator, deen als gewësse Gréisst bekannt ass.
    ///
    /// Verhalen ass ondefinéiert sollt d'Gréisst falsch sinn.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic Bewaacher beim Klonen vun T Elementer.
        // Am Fall vun engem panic ginn Elementer déi an déi nei RcBox geschriwwe goufen erofgelooss, da gëtt d'Erënnerung fräi.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Zeigefanger op dat éischt Element
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Alles kloer.Vergiess de Wuecht, sou datt et net déi nei RcBox freet.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Spezialisatioun trait fir `From<&[T]>` benotzt.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Drops den `Rc`.
    ///
    /// Dëst wäert de staarke Referenzzuel dekrementéieren.
    /// Wann de staarke Referenzzuel null erreecht, sinn déi eenzeg aner Referenzen (wann iwwerhaapt) [`Weak`], also `drop` de banneschte Wäert.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Dréckt näischt
    /// drop(foo2);   // Dréckt "dropped!" aus
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // den enthalen Objet zerstéieren
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // den impliziten "strong weak" Zeiger ewechzehuelen elo datt mir den Inhalt zerstéiert hunn.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Maacht e Klon vum `Rc` Zeiger.
    ///
    /// Dëst erstellt en anere Zeiger zu der selwechter Bewëllegung, erhéicht de staarken Referenzzuel.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Erstellt en neien `Rc<T>`, mam `Default` Wäert fir `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack fir Spezialiséierungen op `Eq` ze erlaben och wann `Eq` eng Method huet.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Mir maachen dës Spezialiséierung hei, an net als méi allgemeng Optimiséierung op `&T`, well et soss e Käschte fir all Gläichheetskontrollen op Refs bäifüügt.
/// Mir ginn dovun aus datt `Rc`s gi benotzt fir grouss Wäerter ze späicheren, déi lues ze klone sinn, awer och schwéier fir no Gläichheet ze kontrolléieren, wouduerch dës Käschte sech méi einfach bezuele kënnen.
///
/// Et ass och méi wahrscheinlech zwee `Rc` Klonen ze hunn, déi op dee selwechte Wäert hindeiten, wéi zwee `&T`en.
///
/// Mir kënnen dat nëmme maachen wann `T: Eq` als `PartialEq` bewosst irreflexiv ka sinn.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Gläichheet fir zwee `Rc`en.
    ///
    /// Zwee `Rc`s si gläich wann hir bannent Wäerter gläich sinn, och wa se a verschiddene Bewëllegunge gespäichert sinn.
    ///
    /// Wann `T` och `Eq` implementéiert (Reflexivitéit vun der Gläichheet implizéiert), sinn zwee 'RC's déi op déiselwecht Verdeelung weisen ëmmer gläich.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Ongläichheet fir zwee `Rc`en.
    ///
    /// Zwee `Rc`s sinn ongläich wann hir bannent Wäerter ongläich sinn.
    ///
    /// Wann `T` och `Eq` implementéiert (wat Reflexivitéit vu Gläichheet bedeit), sinn zwee 'RC's déi op déiselwecht Bewëllegung weisen ni ongläich.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Deelweis Verglach fir zwee `Rc`en.
    ///
    /// Déi zwee gi verglach andeems se `partial_cmp()` op hir bannent Wäerter nennen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Manner wéi Verglach fir zwee `Rc`en.
    ///
    /// Déi zwee gi verglach andeems se `<` op hir bannent Wäerter nennen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// 'Manner wéi oder gläich wéi' Verglach fir zwee 'RC's.
    ///
    /// Déi zwee gi verglach andeems se `<=` op hir bannent Wäerter nennen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Gréissere wéi Verglach fir zwee `Rc`en.
    ///
    /// Déi zwee gi verglach andeems se `>` op hir bannent Wäerter nennen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 'Méi grouss wéi oder gläich wéi' Verglach fir zwee 'RC's.
    ///
    /// Déi zwee gi verglach andeems se `>=` op hir bannent Wäerter nennen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Verglach fir zwee `Rc`en.
    ///
    /// Déi zwee gi verglach andeems se `cmp()` op hir bannent Wäerter nennen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Allocéiert eng mat Referenz gezielt Scheif a fëllt se duerch Klonung vun "v" Artikelen.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Allokéiert e Referenz gezielt Stringschnitt a kopéiert `v` dran.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Allokéiert e Referenz gezielt Stringschnitt a kopéiert `v` dran.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Réckelt e gekësst Objet op eng nei, Referenz gezielt, Bewëllegung.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Allokéiert e Referenz gezielt Stéck a réckelt 'v' Artikelen dran.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Loosst de Vec säi Gedächtnis befreien, awer säin Inhalt net zerstéieren
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Huelt all Element am `Iterator` a sammelt et an en `Rc<[T]>`.
    ///
    /// # Leeschtung Charakteristiken
    ///
    /// ## Den allgemenge Fall
    ///
    /// Am allgemengen Fall gëtt Sammelen an `Rc<[T]>` gemaach andeems Dir als éischt an en `Vec<T>` gesammelt.Dat ass, wann Dir folgend schreift:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// dëst verhält sech wéi wa mir geschriwwen hätten:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Den éischte Set vu Bewëllegunge passéiert hei.
    ///     .into(); // Eng zweet Bewëllegung fir `Rc<[T]>` geschitt hei.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Dëst verdeelt sou vill Mol wéi néideg fir den `Vec<T>` ze bauen an da verdeelt et eemol fir den `Vec<T>` an den `Rc<[T]>` ze dréinen.
    ///
    ///
    /// ## Iteratoren vu bekannter Längt
    ///
    /// Wann Äre `Iterator` `TrustedLen` implementéiert a vun enger exakter Gréisst ass, gëtt eng eenzeg Bewëllegung fir den `Rc<[T]>` gemaach.Zum Beispill:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Just eng eenzeg Bewëllegung geschitt hei.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Spezialiséierung trait benotzt fir an `Rc<[T]>` ze sammelen.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Dëst ass de Fall fir en `TrustedLen` Iterator.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SAFETY: Mir musse sécherstellen datt de Iterator eng exakt Längt huet a mir hunn.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Falen zréck op normal Ëmsetzung.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` ass eng Versioun vun [`Rc`] déi eng net bezittend Referenz zu der verwaltter Allocatioun hält.D'Allocatioun ass zougänglech andeems Dir [`upgrade`] um `Weak` Zeiger urufft, deen eng ["Option"] <"[" Rc "]"<T>> `.
///
/// Zënter enger `Weak` Referenz zielt net zum Eegentum, et wäert net verhënneren datt de Wäert, deen an der Bewëllegung gespäichert ass, fale gelooss gëtt, an `Weak` selwer mécht keng Garantien iwwer de Wäert, deen nach ëmmer do ass.
/// Sou kann et [`None`] zréckginn wann [`upgrade`] d.
/// Bedenkt awer datt eng `Weak` Referenz * verhënnert datt d'Allocatioun selwer (de Backing Store) ausgedeelt gëtt.
///
/// En `Weak` Zeiger ass nëtzlech fir eng temporär Referenz zu der Bewëllegung ze halen, déi vum [`Rc`] verwalt gëtt, ouni datt säi banneschte Wäert fällt.
/// Et gëtt och benotzt fir kreesfërmeg Referenzen tëscht [`Rc`] Zeigefanger ze vermeiden, well géigesäiteg Besëtzer Referenzen ni erlaben datt entweder [`Rc`] fale gelooss gëtt.
/// Zum Beispill kéint e Bam staark [`Rc`] Zeigefanger vun Elterenknäpp fir Kanner hunn, an `Weak` Zeigefanger vu Kanner zréck bei hir Elteren.
///
/// Den typesche Wee fir en `Weak` Zeiger ze kréien ass den [`Rc::downgrade`] ze ruffen.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Dëst ass en `NonNull` fir d'Gréisst vun dësem Typ an Enums ze optimiséieren, awer et ass net onbedéngt e gëltege Zeiger.
    //
    // `Weak::new` setzt dëst op `usize::MAX` sou datt et kee Raum um Koup brauch ze verdeelen.
    // Dat ass net e Wäert deen e richtege Zeiger je wäert hunn well RcBox Ausriichtung op d'mannst 2 huet.
    // Dëst ass nëmme méiglech wann `T: Sized`;unsized `T` ni bengelen.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Baut en neien `Weak<T>`, ouni Erënnerung ze verdeelen.
    /// [`upgrade`] um Retourwäert uruffen gëtt ëmmer [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Hëlleftyp fir Zougang zu de Referenzzuelen z'erméiglechen ouni Behaaptungen iwwer den Datefeld ze maachen.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Gitt e roude Zeigefanger op den Objet `T` zréckgezunn vun dësem `Weak<T>`.
    ///
    /// De Zeiger ass nëmme valabel wann et e puer staark Referenze gëtt.
    /// De Zeiger kann hängelen, net ausgeriicht sinn oder och [`null`] anescht.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Béid weisen op datselwecht Objet
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Dee staarken hei hält et lieweg, sou datt mir nach ëmmer Zougang zum Objet kréien.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Awer net méi.
    /// // Mir kënnen weak.as_ptr() maachen, awer Zougang zum Zeiger féiert zu ondefinéiert Verhalen.
    /// // assert_eq! ("hallo", onsécher {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Wann de Zeiger hänkt, gi mir de Sentinel direkt zréck.
            // Dëst kann net eng valabel Notzlaaschtadress sinn, well d'Notzlaascht op d'mannst esou ausgeriicht ass wéi RcBox (usize).
            ptr as *const T
        } else {
            // SIKKERHET: wann is_dangling falsch zréckkënnt, da kann de Zeiger déferencabel sinn.
            // D'Notzlaascht kann zu dësem Zäitpunkt fale gelooss ginn, a mir mussen d'Herzéiung behalen, also benotzt rau Zeiger Manipulatioun.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Verbraucht den `Weak<T>` a mécht en zu engem roude Pointer.
    ///
    /// Dëst konvertéiert de schwaache Zeiger an e roude Zeiger, wärend awer de Besëtz vun enger schwaacher Referenz konservéiert (de schwaache Grof gëtt net vun dëser Operatioun modifizéiert).
    /// Et kann zréck an den `Weak<T>` mat [`from_raw`] ëmgewandelt ginn.
    ///
    /// Déi selwecht Restriktioune fir Zougang zum Zil vum Zeiger wéi mat [`as_ptr`] z'erreechen gëllen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Konvertéiert e roude Zeigefanger, dee virdru vum [`into_raw`] erstallt gouf an `Weak<T>` zréck.
    ///
    /// Dëst kann benotzt ginn fir sécher eng staark Referenz ze kréien (andeems Dir [`upgrade`] méi spéit urufft) oder fir de schwaache Grof ze verhandelen andeems Dir den `Weak<T>` fällt.
    ///
    /// Et hëlt Eegentum vun enger schwaacher Referenz (mat Ausnam vun Zeigefanger erstallt vun [`new`], well dës näischt hunn; d'Method funktionnéiert ëmmer nach op hinnen).
    ///
    /// # Safety
    ///
    /// De Zeiger muss vum [`into_raw`] entstane sinn a muss ëmmer nach seng potenziell schwaach Referenz hunn.
    ///
    /// Et ass erlaabt datt de staarke Grof 0 ass beim Zäitpunkt fir dëst ze nennen.
    /// Trotzdem hëlt dëst Eegentum vun enger schwaacher Referenz déi aktuell als roude Zeiger duergestallt gëtt (de schwaache Grof gëtt net vun dëser Operatioun modifizéiert) an dofir muss et mat engem fréieren Uruff op [`into_raw`] gepaart ginn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Dekrementéiert de leschte schwaache Grof.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Kuckt Weak::as_ptr fir de Kontext wéi den Input Pointer ofgeleet gëtt.

        let ptr = if is_dangling(ptr as *mut T) {
            // Dëst ass en hängenden Schwach.
            ptr as *mut RcBox<T>
        } else {
            // Soss si mir garantéiert datt de Zeigefanger aus engem net vernetzte Schwaach koum.
            // SAFETY: data_offset ass sécher ze ruffen, well ptr verweist op e reellen (potenziell erofgefall) T.
            let offset = unsafe { data_offset(ptr) };
            // Sou ëmsetze mir den Offset fir déi ganz RcBox ze kréien.
            // SIKKERHET: de Zeiger staamt aus engem Schwaachen, sou datt dësen Offset sécher ass.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SIKKERHET: mir hunn elo den originale Schwaachzeiger erëmfonnt, sou kënne mir de Schwaach erstellen.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Versicht den `Weak` Zeiger op en [`Rc`] ze aktualiséieren, de Verspéidung vum banneschten Wäert ze verzögeren wann et erfollegräich ass.
    ///
    ///
    /// Nees [`None`] wann de banneschte Wäert zënterhier erofgefall ass.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Zerstéiert all staark Hiweiser.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Kritt d'Zuel vu staarke (`Rc`) Zeigefanger, déi op dës Bewëllegung weisen.
    ///
    /// Wann `self` mat [`Weak::new`] erstallt gouf, gëtt dëst 0 zréck.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Kritt d'Zuel vun `Weak` Zeigefanger déi op dës Bewëllegung weisen.
    ///
    /// Wa keng staark Hiweiser bleiwen, wäert dëst null zréckginn.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // subtrahéiert déi implizit schwaach ptr
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Retour `None` wann de Zeiger hänkt an et gëtt keen zougewisenen `RcBox`, (dh wann dësen `Weak` vum `Weak::new` erstallt gouf).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Mir si virsiichteg *net* eng Referenz ze kreéieren déi den "data" Feld deckt, well d'Feld kann gläichzäiteg mutéiert ginn (zum Beispill, wann de leschten `Rc` fale gelooss gëtt, gëtt d'Datenfeld op der Plaz fale gelooss).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Retour `true` wann déi zwee "Schwaach" op déiselwecht Bewëllegung weisen (ähnlech wéi [`ptr::eq`]), oder wa béid net op eng Verdeelung hiweisen (well se mat `Weak::new()`) erstallt goufen.
    ///
    ///
    /// # Notes
    ///
    /// Well dëst Zeigner vergläicht, heescht et datt `Weak::new()` sech géigesäiteg gläiche wäerten, och wa se net op eng Allokatioun hiweisen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` vergläichen.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Fält den `Weak` Zeiger erof.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Dréckt näischt
    /// drop(foo);        // Dréckt "dropped!" aus
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // de schwaache Grof fänkt bei 1 un, a geet nëmmen op Null wann all déi staark Hiweiser verschwonne sinn.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Maacht e Klon vum `Weak` Zeiger deen op déiselwecht Bewëllegung weist.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Baut en neien `Weak<T>`, verdeelt Erënnerung fir `T` ouni et ze initialiséieren.
    /// [`upgrade`] um Retourwäert uruffen gëtt ëmmer [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Mir hunn hei gekuckt_add fir sécher mat mem::forget ëmzegoen.Besonnesch
// wann Dir mem::forget RCs (oder Schwächen), kann de Ref-Count iwwerschwemmt ginn, an da kënnt Dir d'Allocatioun befreien, während aussergewéinlech Rcs (oder Weaks) existéieren.
//
// Mir ofbriechen, well dëst sou degeneréiert Szenario ass, datt et eis egal ass wat geschitt-kee richtege Programm sollt dat jee erliewen.
//
// Dëst sollt vernoléissegbar Overhead hunn, well Dir net tatsächlech dës vill an Rust klonéiere musst dank Eegentum a Bewegungssemantik.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Mir wëllen d'Ofdreiwung ofbriechen amplaz de Wäert erofzesetzen.
        // D'Referenzzuel wäert ni null sinn wann dëst genannt gëtt;
        // trotzdem setze mir en Ofbriechen hei an fir de LLVM op eng anescht verpasst Optimiséierung hinzeweisen.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Mir wëllen d'Ofdreiwung ofbriechen amplaz de Wäert erofzesetzen.
        // D'Referenzzuel wäert ni null sinn wann dëst genannt gëtt;
        // trotzdem setze mir en Ofbriechen hei an fir de LLVM op eng anescht verpasst Optimiséierung hinzeweisen.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Kritt den Offset an engem `RcBox` fir d'Notzlaascht hannert engem Zeiger.
///
/// # Safety
///
/// De Zeiger muss op eng virdru valabel Instanz vun T weisen (a gëlteg Metadate fir hunn), awer den T dierf fale gelooss ginn.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Alignéiert den onmaache Wäert op d'Enn vun der RcBox.
    // Well RcBox repr(C) ass, ass et ëmmer dat lescht Feld an der Erënnerung.
    // SIKKERHET: well déi eenzeg méiglech Gréissten Zorten si Scheiwen, trait Objeten,
    // an extern Typen, d'Input Sécherheetsfuerderung ass aktuell genuch fir d'Ufuerderunge vum align_of_val_raw z'erfëllen;dëst ass en Implementéierungsdetail vun der Sprooch déi net ausserhalb vun std kann ugewannt ginn.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}