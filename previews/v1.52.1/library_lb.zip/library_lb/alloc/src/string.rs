//! Eng UTF-8-kodéiert, wuessbar String.
//!
//! Dëst Modul enthält den [`String`] Typ, den [`ToString`] trait fir Konvertéieren op Strings, a verschidde Feelertypen, déi aus der Aarbecht mat [`String`] kënnen entstoen.
//!
//!
//! # Examples
//!
//! Et gi verschidde Weeër fir en neien [`String`] aus engem String wuertwiertlech ze kreéieren:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Dir kënnt en neie [`String`] aus engem existente erstellen andeems Dir mat verknëppelt
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Wann Dir en vector vu gëltege UTF-8 Bytes hutt, kënnt Dir en [`String`] draus maachen.Dir kënnt och de Géigendeel maachen.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Mir wëssen datt dës Bytes gëlteg sinn, also benotze mir `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// Eng UTF-8-kodéiert, wuessbar String.
///
/// Den `String` Typ ass deen heefegste Stringtyp deen Eegentum iwwer den Inhalt vun der String huet.Et huet eng enk Relatioun mat sengem geléinte Kolleg, dem primitiven [`str`].
///
/// # Examples
///
/// Dir kënnt en `String` vun [a literal string][`str`] mat [`String::from`] erstellen:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Dir kënnt en [`char`] op en `String` mat der [`push`] Method bäifügen, an en [`&str`] mat der [`push_str`] Method bäifügen:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Wann Dir en vector vun UTF-8 Bytes hutt, kënnt Dir en `String` dovun erstellen mat der [`from_utf8`] Method:
///
/// ```
/// // e puer Bytes, an engem vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Mir wëssen datt dës Bytes gëlteg sinn, also benotze mir `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `String`s sinn ëmmer gëlteg UTF-8.Dëst huet e puer Implikatiounen, déi éischt dovun ass datt wann Dir en Net-UTF-8 String braucht, betruecht [`OsString`].Et ass ähnlech, awer ouni d UTF-8 Beschränkung.Déi zweet Implikatioun ass datt Dir net an en `String` indexéiere kënnt:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Indexéiere soll eng konstant Zäitoperatioun sinn, awer UTF-8 Kodéierung erlaabt eis et net ze maachen.Ausserdeem ass et net kloer wéi eng Saach den Index sollt zréckginn: e Byte, e Codepoint oder e Grafeme-Cluster.
/// D [`bytes`] an d [`chars`] Methode ginn d'Iteratoren iwwer déi éischt zwee zréck.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `String`s implementéieren [`Deref`] `<Target=str>`, an ierft also all [[str`] Methoden.Zousätzlech heescht dat datt Dir en `String` op eng Funktioun weiderginn déi en [`&str`] mat engem Ampersand (`&`) hëlt:
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Dëst erstellt en [`&str`] aus dem `String` a weiderginn. Dës Konversioun ass ganz deier, an sou allgemeng akzeptéiere Funktiounen [`&str`] als Argumenter, ausser se brauchen e `String` aus irgend engem spezifesche Grond.
///
/// A gewësse Fäll huet Rust net genuch Informatioun fir dës Konversioun ze maachen, bekannt als [`Deref`] Zwang.Am folgenden Beispill implementéiert e Stringschnitt [`&'a str`][`&str`] den trait `TraitExample`, an d'Funktioun `example_func` hëlt alles wat d'trait implementéiert.
/// An dësem Fall muss Rust zwee implizit Conversiounen maachen, déi Rust net d'Moyenen huet ze maachen.
/// Aus deem Grond wäert dat folgend Beispill net kompiléieren.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Et ginn zwou Optiounen, déi amplaz funktionnéieren.Déi éischt wier d'Linn `example_func(&example_string);` op `example_func(example_string.as_str());` z'änneren, mat der Method [`as_str()`] fir explizit d'Schnouer Slice mat der String extrahéieren.
/// Den zweete Wee ännert `example_func(&example_string);` op `example_func(&*example_string);`.
/// An dësem Fall verweise mer en `String` op en [`str`][`&str`], da referenzéieren mir den [`str`][`&str`] zréck op [`&str`].
/// Den zweete Wee ass méi idiomatesch, awer zwee schaffen d'Konversioun explizit ze maachen anstatt op déi implizit Konversioun ze vertrauen.
///
/// # Representation
///
/// En `String` besteet aus dräi Komponenten: e Zeiger zu e puer Bytes, eng Längt an eng Kapazitéit.De Zeiger weist op en internen Puffer `String` benotzt fir seng Daten ze späicheren.D'Längt ass d'Zuel vu Bytes déi aktuell am Puffer gespäichert sinn, an d'Kapazitéit ass d'Gréisst vum Puffer an de Bytes.
///
/// Als sou wäert d'Längt ëmmer manner wéi oder gläich wéi d'Kapazitéit sinn.
///
/// Dëse Puffer gëtt ëmmer op de Koup gelagert.
///
/// Dir kënnt dës mat de Methoden [`as_ptr`], [`len`] an [`capacity`] kucken:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Update dëst wann vec_into_raw_parts stabiliséiert ass.
/// // Verhënnert datt automatesch d'Daten vun der String falen
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // Geschicht huet nonzéng Bytes
/// assert_eq!(19, len);
///
/// // Mir kënnen e String nei bauen aus ptr, len a Kapazitéit.
/// // Dëst ass alles onsécher well mir si verantwortlech fir sécher ze sinn datt d'Komponente valabel sinn:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Wann en `String` genuch Kapazitéit huet, ginn Elementer derbäi net nei zougewisen.Zum Beispill, betruecht dëse Programm:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Dëst wäert déi folgend Ausgab:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Fir d'éischt hu mir guer kee Gediechtnes zougewisen, awer wa mir un de String bäifügen, erhéicht se hir Kapazitéit ubruecht.Wa mir amplaz d [`with_capacity`] Method benotze fir déi richteg Kapazitéit ufanks ze verdeelen:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Mir kommen mat enger anerer Ausgab:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Hei ass et net néideg méi Erënnerung am Loop ze verdeelen.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// E méigleche Feelerwäert beim Ëmwandele vun engem `String` aus engem UTF-8 Byte vector.
///
/// Dësen Typ ass de Feelertyp fir d [`from_utf8`] Method op [`String`].
/// Et ass sou entwéckelt fir suergfälteg Reallokatiounen ze vermeiden: d [`into_bytes`] Method gëtt de Byte vector zréck, deen am Ëmbauversuch benotzt gouf.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Den [`Utf8Error`] Typ, deen vun [`std::str`] geliwwert gëtt, stellt e Feeler vir, dee ka optriede wann Dir e Stéck vun [`u8`] an en [`&str`] konvertéiert.
/// An dësem Sënn ass et en Analog zu `FromUtf8Error`, an Dir kënnt ee vun engem `FromUtf8Error` duerch d [`utf8_error`] Method kréien.
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Basis Benotzung:
///
/// ```
/// // e puer ongëlteg Bytes, an engem vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// E méigleche Feelerwäert beim Ëmwandele vun engem `String` aus engem UTF-16 Byte Slice.
///
/// Dësen Typ ass de Feelertyp fir d [`from_utf16`] Method op [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Basis Benotzung:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Erstellt en neien eidelen `String`.
    ///
    /// Entscheet datt den `String` eidel ass, verdeelt dëst keen initialen Puffer.Och wann dat heescht datt dës éischt Operatioun ganz deier ass, kann et exzessiv Bewëllegung méi spéit verursaachen wann Dir Daten bäifügt.
    ///
    /// Wann Dir eng Iddi hutt wéi vill Daten den `String` hält, betruecht d [`with_capacity`] Method fir exzessiv Re-allocatioun ze vermeiden.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Erstellt en neien eidelen `String` mat enger spezieller Kapazitéit.
    ///
    /// `String`s hunn en interne Puffer fir hir Daten ze halen.
    /// D'Kapazitéit ass d'Längt vun deem Puffer, a ka mat der [`capacity`] Method nogefrot ginn.
    /// Dës Method kreéiert en eidelen `String`, awer ee mat engem éischte Puffer deen `capacity` Bytes kann halen.
    /// Dëst ass nëtzlech wann Dir e Koup Daten op den `String` kënnt bäifügen, d'Zuel vun den Ëmlokalisatiounen ze reduzéieren déi et maache muss.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Wann déi gegebene Kapazitéit `0` ass, fällt keng Bewëllegung op, an dës Method ass identesch mat der [`new`] Method.
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // De String enthält keng Zeechen, och wann et Kapazitéit fir méi huet
    /// assert_eq!(s.len(), 0);
    ///
    /// // Dës ginn all gemaach ouni nei ze verdeelen ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... awer dëst kann d'Schnouer nei realiséieren
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): mat cfg(test) ass déi ugebuer `[T]::to_vec` Method, déi fir dës Method Definitioun erfuerderlech ass, net verfügbar.
    // Well mir dës Method net fir Testzwecker erfuerderen, stäipen ech se einfach NB kuckt den slice::hack Modul am slice.rs fir méi Informatioun
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Konvertéiert en vector vu Bytes op en `String`.
    ///
    /// E String ([`String`]) ass aus Bytes ([`u8`]) gemaach, an en vector vu Bytes ([`Vec<u8>`]) ass aus Bytes gemaach, sou datt dës Funktioun tëscht deenen zwee konvertéiert.
    /// Net all Byte Scheiwen si valabel `String`s, awer: `String` erfuerdert datt et gëlteg UTF-8 ass.
    /// `from_utf8()` kontrolléiert fir sécherzestellen datt d'Bytes gëlteg UTF-8 sinn, an dann d'Konversioun mécht.
    ///
    /// Wann Dir sécher sidd datt de Byte Slice gëlteg ass UTF-8, an Dir wëllt net d'Iwwerleeung vun der Validitéitskontroll maachen, et gëtt eng onsécher Versioun vun dëser Funktioun, [`from_utf8_unchecked`], déi déiselwecht Verhalen huet awer iwwerpréift de Scheck.
    ///
    ///
    /// Dës Method këmmert sech ëm d'vector net ze kopéieren, fir Effizienz.
    ///
    /// Wann Dir en [`&str`] amplaz en `String` braucht, da kuckt [`str::from_utf8`].
    ///
    /// D'Invers vun dëser Method ass [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Retour [`Err`] wann d'Scheedung net UTF-8 ass mat enger Beschreiwung firwat déi geliwwert Bytes net UTF-8 sinn.Den vector deen Dir ageplënnert hutt ass och mat abegraff.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// // e puer Bytes, an engem vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Mir wëssen datt dës Bytes gëlteg sinn, also benotze mir `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Falsch Bytes:
    ///
    /// ```
    /// // e puer ongëlteg Bytes, an engem vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Kuckt d'Dokumenter fir [`FromUtf8Error`] fir méi Detailer iwwer wat Dir mat dësem Feeler maache kënnt.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Konvertéiert e Stéck Bytes an e String, inklusiv ongëlteg Zeechen.
    ///
    /// Strings ginn aus Bytes ([`u8`]) gemaach, an e Stéck Bytes ([`&[u8]`][byteslice]) ass aus Bytes gemaach, sou datt dës Funktioun tëscht deenen zwee konvertéiert.Net all Byte Scheiwen si valabel Seilen, awer: Seeler mussen als gëlteg UTF-8 sinn.
    /// Wärend dëser Konversioun wäert `from_utf8_lossy()` all ongëlteg UTF-8-Sequenzen duerch [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] ersetzen, déi sou ausgesinn:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Wann Dir sécher sidd datt de Byte Slice gëlteg ass UTF-8, an Dir wëllt d'Iwwerleeung vun der Konversioun net maachen, et gëtt eng onsécher Versioun vun dëser Funktioun, [`from_utf8_unchecked`], déi datselwecht Verhalen huet awer d'Schecken iwwerspréngt.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Dës Funktioun bréngt en [`Cow<'a, str>`] zréck.Wann eis Byte Slice ongülteg UTF-8 ass, da musse mir Ersatzzeechen anhuelen, wat d'Gréisst vun der String ännert, an dofir en `String` erfuerderen.
    /// Awer wann et scho gëlteg UTF-8 ass, brauche mir keng nei Bewëllegung.
    /// Dëse Retourtyp erlaabt eis béid Fäll ze behandelen.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// // e puer Bytes, an engem vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Falsch Bytes:
    ///
    /// ```
    /// // e puer ongëlteg Bytes
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// En UTF-16-kodéiert vector `v` an en `String` dekodéiert, zréck [`Err`] wann `v` keng ongëlteg Daten enthält.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Dëst gëtt net iwwer Sammele gemaach: : <Result<_, _>> () aus Performance Grënn.
        // FIXME: d'Funktioun kann erëm vereinfacht ginn wann #48994 zou ass.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Decodéiert en UTF-16-kodéiert Slice `v` an en `String`, ersetzt ongëlteg Date mat [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// Am Géigesaz zu [`from_utf8_lossy`] deen e [`Cow<'a, str>`] zréckkommt, `from_utf16_lossy` zréckkommt en `String` well d UTF-16 op UTF-8 Konversioun eng Gedächtniszouweisung brauch.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Zersetzt en `String` a seng réi Komponenten.
    ///
    /// Gitt de roude Zeiger op d'Basisdaten, d'Längt vum String (a Bytes) an déi zougewisen Kapazitéit vun den Donnéeën (a Bytes) zréck.
    /// Dëst sinn déiselwecht Argumenter an der selwechter Reiefolleg wéi d'Argumenter fir [`from_raw_parts`].
    ///
    /// Nodeems dës Funktioun ugeruff gouf, ass de Ruff verantwortlech fir d'Erënnerung, déi virdru vum `String` geréiert gouf.
    /// Deen eenzege Wee fir dëst ze maachen ass de roude Zeiger, d'Längt an d'Kapazitéit zréck an en `String` mat der [`from_raw_parts`] Funktioun ze konvertéieren, sou datt den Destructor den Opraum ausféiert.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Erstellt en neien `String` aus enger Längt, Kapazitéit a Pointer.
    ///
    /// # Safety
    ///
    /// Dëst ass héich onsécher, wéinst der Unzuel vun Invararianen déi net kontrolléiert ginn:
    ///
    /// * D'Erënnerung bei `buf` muss virdru vum selwechten allocator zougedeelt ginn, deen d'Standardbibliothéik benotzt, mat enger erfuerderter Ausriichtung vu genau 1.
    /// * `length` muss manner wéi oder gläich wéi `capacity` sinn.
    /// * `capacity` muss de richtege Wäert sinn.
    /// * Déi éischt `length` Bytes bei `buf` musse gëlteg UTF-8 sinn.
    ///
    /// Verstouss géint dës ka Probleemer verursaache wéi Korruptioun vun den interne Datestrukturen vum allocator.
    ///
    /// De Besëtz vun `buf` gëtt effektiv op den `String` transferéiert, deen dann den Inhalt vum Gedächtnis, deen de Zeigefanger op Wonsch weist, verhandelen, nei verdeelen oder änneren.
    /// Gitt sécher datt näischt anescht de Zeiger benotzt nodeems Dir dës Funktioun opgeruff hutt.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Update dëst wann vec_into_raw_parts stabiliséiert ass.
    ///     // Verhënnert datt automatesch d'Daten vun der String falen
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Konvertéiert en vector vu Bytes op en `String` ouni ze kontrolléieren datt de String gëlteg UTF-8 enthält.
    ///
    /// Kuckt déi sécher Versioun, [`from_utf8`], fir méi Detailer.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Dës Funktioun ass onsécher well se net kontrolléiert datt d'Bytes, déi u si weiderginn, valabel UTF-8 sinn.
    /// Wann dës Beschränkung verletzt gëtt, kann et Gedächtnissécherheetsprobleemer mat future Benotzer vum `String` verursaachen, well de Rescht vun der Standardbibliothéik geet dovun aus datt 'String's valabel UTF-8 sinn.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// // e puer Bytes, an engem vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Konvertéiert en `String` an e Byte vector.
    ///
    /// Dëst verbraucht den `String`, dofir brauche mir d'Inhalter net ze kopéieren.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Extraitéiert e Stringschnitt mat der ganzer `String`.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Konvertéiert en `String` an eng mutabel String Scheif.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Füügt e gegebene Stringschnitt op d'Enn vun dësem `String` bäi.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Nees dës "String" Kapazitéit, a Bytes.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Assuréiert datt d'Kapazitéit vun dëser "String" op d'mannst `additional` Bytes méi grouss ass wéi hir Längt.
    ///
    /// D'Kapazitéit ka méi wéi `additional` Bytes erhéicht ginn, wa se et wielt, fir heefeg Ëmverdeelungen ze vermeiden.
    ///
    ///
    /// Wann Dir dëst "at least" Verhalen net wëllt, kuckt d [`reserve_exact`] Method.
    ///
    /// # Panics
    ///
    /// Panics wann déi nei Kapazitéit iwwer [`usize`] iwwerschwemmt.
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Dëst kann d'Kapazitéit net tatsächlech erhéijen:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s huet elo eng Längt vun 2 an eng Kapazitéit vun 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Well mir schonn eng zousätzlech 8 Kapazitéit hunn, nennen dëst ...
    /// s.reserve(8);
    ///
    /// // ... geet net tatsächlech erop.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Assuréiert datt dës "String" Kapazitéit `additional` Bytes méi grouss ass wéi hir Längt.
    ///
    /// Bedenkt d [`reserve`] Method ze benotzen ausser Dir wësst absolut besser wéi den Allocator.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics wann déi nei Kapazitéit iwwer `usize` iwwerschwemmt.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Dëst kann d'Kapazitéit net tatsächlech erhéijen:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s huet elo eng Längt vun 2 an eng Kapazitéit vun 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Well mir schonn eng zousätzlech 8 Kapazitéit hunn, nennen dëst ...
    /// s.reserve_exact(8);
    ///
    /// // ... geet net tatsächlech erop.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Probéiert d'Kapazitéit ze reservéieren fir op d'mannst `additional` méi Elementer an de gegebene `String` ze setzen.
    /// D'Kollektioun ka méi Plaz reservéieren fir heefeg Ëmverdeelungen ze vermeiden.
    /// Nodeems Dir `reserve` ugeruff hutt, wäert d'Kapazitéit méi grouss wéi oder gläich wéi `self.len() + additional` sinn.
    /// Maacht näischt wann d'Kapazitéit scho genuch ass.
    ///
    /// # Errors
    ///
    /// Wann d'Kapazitéit iwwerschwemmt ass, oder de Verdeler e Feeler bericht, da gëtt e Feeler zréckginn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Reservéiert d'Erënnerung viraus, wann Dir net kënnt
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Elo wësse mer datt dëst net OOM kann an der Mëtt vun eiser komplexer Aarbecht
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Probéiert déi Mindestkapazitéit ze reservéieren fir genau `additional` méi Elementer an de gegebene `String` ze setzen.
    ///
    /// Nodeems Dir `reserve_exact` ugeruff hutt, wäert d'Kapazitéit méi grouss wéi oder gläich wéi `self.len() + additional` sinn.
    /// Maacht näischt wann d'Kapazitéit scho genuch ass.
    ///
    /// Bedenkt datt d'Allocator der Sammlung méi Plaz ka ginn wéi se gefrot.
    /// Dofir kann d'Kapazitéit net drop verloossen datt se präzis minimal ass.
    /// Léiwer `reserve` wann future Insertions erwaart ginn.
    ///
    /// # Errors
    ///
    /// Wann d'Kapazitéit iwwerschwemmt ass, oder de Verdeler e Feeler bericht, da gëtt e Feeler zréckginn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Reservéiert d'Erënnerung viraus, wann Dir net kënnt
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Elo wësse mer datt dëst net OOM kann an der Mëtt vun eiser komplexer Aarbecht
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Schrëft d'Kapazitéit vun dësem `String` fir seng Längt ze passen.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Schrëft d'Kapazitéit vun dësem `String` mat enger méi niddereger Grenz.
    ///
    /// D'Kapazitéit bleift op d'mannst sou grouss wéi d'Längt an de geliwwertene Wäert.
    ///
    ///
    /// Wann déi aktuell Kapazitéit manner wéi déi ënnescht Grenz ass, ass dat en No-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Füügt de gegebene [`char`] um Enn vun dësem `String` un.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Gitt e Byte Stéck vun dësem Inhalt "String".
    ///
    /// D'Invers vun dëser Method ass [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Verkierzt dësen `String` zu der spezifizéierter Längt.
    ///
    /// Wann `new_len` méi grouss ass wéi déi aktuell Längt vum String, huet dat keen Effekt.
    ///
    ///
    /// Bedenkt datt dës Method keen Effekt op d'allocéiert Kapazitéit vum String huet
    ///
    /// # Panics
    ///
    /// Panics wann `new_len` net op enger [`char`] Grenz läit.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Läscht de leschte Charakter aus dem Stringpuffer an zréck.
    ///
    /// Retour [`None`] wann dësen `String` eidel ass.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Läscht en [`char`] vun dësem `String` op enger Byte-Positioun an zréck.
    ///
    /// Dëst ass eng *O*(*n*) Operatioun, well et all Element am Puffer kopéiert.
    ///
    /// # Panics
    ///
    /// Panics wann `idx` méi grouss wéi oder gläich wéi d'Längt "String" ass, oder wann et net op enger [`char`] Grenz läit.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Ewechzehuelen all Matcher vum Muster `pat` an der `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Matcher ginn detektéiert detektéiert an ewechgeholl, also a Fäll wou Mustere sech iwwerschneiden, gëtt nëmmen dat éischt Muster ewechgeholl:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // SAFETY: Start an Enn sinn op utf8 Byte Grenzen pro
        // de Searcher docs
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Hält nëmmen d'Charaktere vum Prädikat uginn.
    ///
    /// An anere Wierder, ewechzehuelen all Zeeche `c` sou datt `f(c)` nees `false`.
    /// Dës Methode funktionnéiert op der Plaz, besicht all Charakter genau eemol an der ursprénglecher Uerdnung, a behält d'Bestellung vun den erhale Personnagen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Déi exakt Uerdnung kann nëtzlech sinn fir den externen Zoustand ze verfollegen, wéi en Index.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Weist idx op den nächsten Char
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Setzt e Charakter an dësen `String` op eng Byte Positioun an.
    ///
    /// Dëst ass eng *O*(*n*) Operatioun well se all Element am Puffer kopéiert.
    ///
    /// # Panics
    ///
    /// Panics wann `idx` méi grouss wéi d'Längt "String" ass, oder wann et net op enger [`char`] Grenz läit.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Setzt e Stringschnitt an dësen `String` op eng Byte Positioun.
    ///
    /// Dëst ass eng *O*(*n*) Operatioun well se all Element am Puffer kopéiert.
    ///
    /// # Panics
    ///
    /// Panics wann `idx` méi grouss wéi d'Längt "String" ass, oder wann et net op enger [`char`] Grenz läit.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Gitt eng mutabel Referenz op den Inhalt vun dësem `String`.
    ///
    /// # Safety
    ///
    /// Dës Funktioun ass onsécher well se net kontrolléiert datt d'Bytes, déi u si weiderginn, valabel UTF-8 sinn.
    /// Wann dës Beschränkung verletzt gëtt, kann et Gedächtnissécherheetsprobleemer mat future Benotzer vum `String` verursaachen, well de Rescht vun der Standardbibliothéik geet dovun aus datt 'String's valabel UTF-8 sinn.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Gitt d'Längt vun dësem `String` zréck, a Bytes, net [`char`] s oder Graphemen.
    /// An anere Wierder, et kann net sinn, wat e Mënsch d'Längt vun der Schnouer hält.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Retour `true` wann dësen `String` eng Längt vun Null huet, an `false` soss.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Deelt de String an zwee beim gegebene Byte Index.
    ///
    /// Nees eng nei zougewisen `String`.
    /// `self` enthält Bytes `[0, at)`, an déi zréckgesate `String` enthält Bytes `[at, len)`.
    /// `at` muss op der Grenz vun engem UTF-8 Code Punkt sinn.
    ///
    /// Bedenkt datt d'Kapazitéit vum `self` net ännert.
    ///
    /// # Panics
    ///
    /// Panics wann `at` net op enger `UTF-8` Code Punkt Grenz ass, oder wann et iwwer de leschte Code Punkt vum String ass.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Truncates this `String`, remove all Inhalt.
    ///
    /// Och wann dëst bedeit datt den `String` eng Längt vun Null huet, beréiert et net seng Kapazitéit.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Erstellt en draining Iterator deen de spezifizéierte Beräich am `String` läscht an den ewechgehollene `chars` ergëtt.
    ///
    ///
    /// Note: D'Elementberäich gëtt ofgeschaaft och wann den Iterator net bis zum Enn verbraucht gëtt.
    ///
    /// # Panics
    ///
    /// Panics wann de Startpunkt oder Ennpunkt net op enger [`char`] Grenz leien, oder wann se ausser Grenzen sinn.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Ewechzehuelen de Beräich bis de β aus dem String
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Eng ganz Palette kläert d'Sträich
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Erënnerung Sécherheet
        //
        // D'Strings Versioun vun Drain huet keng Gedächtnis Sécherheetsprobleemer vun der vector Versioun.
        // D'Donnéeë si just Bytes.
        // Well d'Bandentfernung am Drop passéiert, wann den Drain-Iterator ausgelaf ass, wäert d'Entféierung net geschéien.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Huelt zwee gläichzäiteg Prêten aus.
        // D &mut String gëtt net zougänglech bis d'Iteratioun eriwwer ass, am Drop.
        let self_ptr = self as *mut _;
        // SAFETY: `slice::range` an `is_char_boundary` maachen déi entspriechend Grenzen Kontrollen.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Läscht de spezifizéierte Beräich am String, an ersetzt et mat der bestëmmter String.
    /// Dee gegebene String muss net déiselwecht Längt wéi d'Band sinn.
    ///
    /// # Panics
    ///
    /// Panics wann de Startpunkt oder Ennpunkt net op enger [`char`] Grenz leien, oder wann se ausser Grenzen sinn.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Ersetzt d'Band bis de β aus der Schnouer
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Erënnerung Sécherheet
        //
        // Replace_range huet net d'Erënnerungssécherheetsprobleemer vun engem vector Splice.
        // vun der vector Versioun.D'Donnéeë si just Bytes.

        // OPGEPASST: Inlining dës Variabel wier net gesond (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // OPGEPASST: Inlining dës Variabel wier net gesond (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // `range` erëm ze benotzen wier net gesond (#81138) Mir ginn dovun aus datt d'Grenze vun `range` déi selwecht bleiwen, awer eng géigneresch Ëmsetzung kéint tëscht Uriff änneren
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Konvertéiert dësen `String` an eng [`Box`]`<`[`str`] `>`.
    ///
    /// Dëst fällt all iwwerschësseg Kapazitéit.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Retourns e Stéck vun [`u8`] s Bytes déi versicht goufen an en `String` ze konvertéieren.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// // e puer ongëlteg Bytes, an engem vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Gitt d'Bytes zréck, déi probéiert goufen an en `String` ze konvertéieren.
    ///
    /// Dës Method ass suergfälteg gebaut fir d'Allocatioun ze vermeiden.
    /// Et wäert de Feeler verbrauchen, d'Bytes réckelen, sou datt eng Kopie vun de Bytes net muss gemaach ginn.
    ///
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// // e puer ongëlteg Bytes, an engem vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Gitt en `Utf8Error` fir méi Detailer iwwer de Konversiounsausfall ze kréien.
    ///
    /// Den [`Utf8Error`] Typ, deen vun [`std::str`] geliwwert gëtt, stellt e Feeler vir, dee ka optriede wann Dir e Stéck vun [`u8`] an en [`&str`] konvertéiert.
    /// An dësem Sënn ass et en Analog zu `FromUtf8Error`.
    /// Kuckt seng Dokumentatioun fir méi Detailer iwwer d'Benotzung.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// // e puer ongëlteg Bytes, an engem vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // den éischte Byte ass hei ongëlteg
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Well mir iwwer "String`s iteréieren, kënne mir op d'mannst eng Allocatioun vermeiden andeems mir den éischte String vum Iterator kréien an all déi uschléissend Strings derbäi bäifügen.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Well mir iwwer CoWs iteréieren, kënne mir (potentially) op d'mannst eng Allocatioun vermeiden andeems mir dat éischt Element kréien an all déi uschléissend Artikelen derbäi bäifügen.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// E Komfortimpl deen op d'impl fir `&str` delegéiert.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Erstellt en eidelen `String`.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Implementéiert den `+` Bedreiwer fir zwee Saiten ze verknëppelen.
///
/// Dëst verbraucht den `String` op der lénkser Säit a benotzt säi Puffer (wuesse se wann néideg).
/// Dëst gëtt gemaach fir ze vermeiden datt en neien `String` zougedeelt gëtt an de ganzen Inhalt op all Operatioun kopéiert, wat zu *O*(*n*^ 2) Laafzäit féiert wann Dir en *n*-Byte String duerch widderhuelend Zesummefaassung baut.
///
///
/// De String op der rietser Säit gëtt nëmmen ausgeléint;säin Inhalt gëtt an den zréckgekéierte `String` kopéiert.
///
/// # Examples
///
/// Zesummeschneiden vun zwee 'String`s hëlt déi éischt no Wäert a léint déi zweet:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` gëtt geréckelt a kann net méi hei benotzt ginn.
/// ```
///
/// Wann Dir den éischte `String` weider benotze wëllt, kënnt Dir et klonen an anstatt op de Klon bäifügen:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` gëllt nach ëmmer hei.
/// ```
///
/// Concatenating `&str` Scheiwen kënnen gemaach ginn andeems Dir déi éischt an en `String` konvertéiert:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Implementéiert den `+=` Betreiber fir en `String` unzeschléissen.
///
/// Dëst huet déiselwecht Verhalen wéi d [`push_str`][String::push_str] Method.
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// En Typ Alias fir [`Infallible`].
///
/// Dësen Alias existéiert fir no hannen Kompatibilitéit, a ka schliisslech entfouert ginn.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// En trait fir e Wäert op en `String` ze konvertéieren.
///
/// Dësen trait gëtt automatesch implementéiert fir all Typ deen den [`Display`] trait implementéiert.
/// Als sou soll `ToString` net direkt implementéiert ginn:
/// [`Display`] sollt amplaz implementéiert ginn, an Dir kritt d `ToString`-Implementatioun gratis.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Konvertéiert de gegebene Wäert op en `String`.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// An dëser Ëmsetzung ass d `to_string` Method panics wann d `Display` Ëmsetzung e Feeler zréckbréngt.
/// Dëst weist op eng falsch `Display` Ëmsetzung well `fmt::Write for String` ni selwer e Feeler zréckbréngt.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Eng gemeinsam Richtlinn ass net generesch Funktiounen ze integréieren.
    // Wéi och ëmmer, d `#[inline]` vun dëser Method ewechzehuelen verursaacht net vernoléissbar Regressiounen.
    // Kuckt <https://github.com/rust-lang/rust/pull/74852>, de leschte Versuch et ze läschen.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Konvertéiert en `&mut str` an en `String`.
    ///
    /// D'Resultat gëtt op de Koup zougewisen.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: Test zitt an libstd, wat hei Feeler verursaacht
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Konvertéiert déi gegebene Këscht `str` Slice zu engem `String`.
    /// Et ass bemierkenswäert datt d `str` Slice gehéiert.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Konvertéiert de gegebene `String` zu enger Këscht `str` Scheif déi gehéiert.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Konvertéiert e Stringschnitt an eng Geléinte Variant.
    /// Kee Koup Bewëllegung gëtt ausgefouert, an de String gëtt net kopéiert.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Konvertéiert e String an eng Besëtz Variant.
    /// Kee Koup Bewëllegung gëtt ausgefouert, an de String gëtt net kopéiert.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Konvertéiert eng String Referenz an eng Geléinte Variant.
    /// Kee Koup Bewëllegung gëtt ausgefouert, an de String gëtt net kopéiert.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Konvertéiert de gegebene `String` zu engem vector `Vec` dee Wäerter vum Typ `u8` hält.
    ///
    /// # Examples
    ///
    /// Basis Benotzung:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// En draining Iterator fir `String`.
///
/// Dëse Struktur gëtt vun der [`drain`] Method op [`String`] erstallt.
/// Kuckt seng Dokumentatioun fir méi.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Gëtt als&'mut String am Destructor benotzt
    string: *mut String,
    /// Start vun Deel ze läschen
    start: usize,
    /// Enn vum Deel ze läschen
    end: usize,
    /// Aktuellen Reschtberäich ze läschen
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Benotzt Vec::drain.
            // "Reaffirm" d'Grenzkontrolle fir ze vermeiden datt den panic Code erëm agefouert gëtt.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Nees de verbleiwen (Ënner) String vun dësem Iterator als Stéck.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: Kommentar AsRef impls ënnen beim Stabiliséieren.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Onkommentéiert beim `string_drain_as_str` stabiliséieren.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>fir Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> fir Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}