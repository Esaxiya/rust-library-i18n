# Den `rustc-std-workspace-core` crate

Dësen crate ass e Shim an eidel crate deen einfach vun `libcore` ofhänkt an all säin Inhalt nei exportéiert.
Den crate ass de Kärel fir d'Standardbibliothéik z'erméiglechen ofhängeg vun crates vun crates.io

Crates op crates.io datt d'Standardbibliothéik ofhängeg ass, muss ofhängeg sinn vum `rustc-std-workspace-core` crate vun crates.io, déi eidel ass.

Mir benotzen `[patch]` fir et op dësen crate an dësem Repository z'iwwerschreiden.
Als Resultat zitt crates op crates.io eng Ofhängegkeet edge op `libcore`, déi Versioun an dësem Repository definéiert.
Dat soll all Ofhängegkeetskante molen fir datt Cargo crates erfollegräich baut!

Bedenkt datt crates op crates.io vun dësem crate mam Numm `core` ofhängeg sinn fir datt alles richteg funktionnéiert.Fir dat ze maachen, kënne se benotzen:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Duerch d'Benotzung vum `package` Schlëssel gëtt den crate op `core` ëmbenannt, dat heescht et wäert ausgesinn

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

wann Cargo de Compiler aberuff, zefriddestellend déi implizit `extern crate core` Direktiv injizéiert vum Compiler.




