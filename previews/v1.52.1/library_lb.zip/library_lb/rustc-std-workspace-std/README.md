# Den `rustc-std-workspace-std` crate

Kuckt Dokumentatioun fir den `rustc-std-workspace-core` crate.