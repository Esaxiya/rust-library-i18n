//! Внедряване на panics чрез отвиване на стека
//!
//! Този crate е изпълнение на panics в Rust, използвайки механизъм за размотаване на стека "most native" на платформата, за която се компилира.
//! Това по същество се категоризира в три групи понастоящем:
//!
//! 1. Целите на MSVC използват SEH във файла `seh.rs`.
//! 2. Emscripten използва C++ изключения във файла `emcc.rs`.
//! 3. Всички останали цели използват libunwind/libgcc във файла `gcc.rs`.
//!
//! Повече документация за всяко внедряване може да бъде намерена в съответния модул.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` не се използва с Мири, така че предупреждения за мълчание.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Стартовите обекти на изпълнението на Rust зависят от тези символи, така че ги направете обществено достояние.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Цели, които не поддържат размотаване.
        // - arch=wasm32
        // - os=няма ("bare metal" цели)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Използвайте изпълнението на Miri.
        // Все още трябва да заредим нормалното изпълнение по-горе, тъй като rustc очаква определени елементи от lang да бъдат дефинирани от там.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Използвайте реалното време на изпълнение.
        use real_imp as imp;
    }
}

extern "C" {
    /// Манипулатор в libstd, извикан, когато обект panic е изпуснат извън `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Манипулаторът в libstd се извиква, когато се хване чуждо изключение.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Входна точка за създаване на изключение, само делегати на специфичното за платформата изпълнение.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}