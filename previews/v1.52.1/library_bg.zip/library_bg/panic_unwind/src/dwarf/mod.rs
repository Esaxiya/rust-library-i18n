//! Помощни програми за анализиране на кодирани от DWARF потоци от данни.
//! Вижте стандарт <http://www.dwarfstd.org>, DWARF-4, раздел 7, "Data Representation"
//!

// Засега този модул се използва само от x86_64-pc-windows-gnu, но ние го компилираме навсякъде, за да избегнем регресии.
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // DWARF потоците са опаковани, така че например u32 не е задължително да бъде подравнен на 4-байтова граница.
    // Това може да причини проблеми на платформи със строги изисквания за подравняване.
    // Като обгръщаме данни в "packed" структура, ние казваме на бекенда да генерира "misalignment-safe" код.
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // Кодирането на ULEB128 и SLEB128 са дефинирани в раздел 7.6, "Variable Length Data".
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}