//! Развиване на panics за Miri.
use alloc::boxed::Box;
use core::any::Any;

// Типът полезен товар, който двигателят на Miri разпространява чрез размотаване за нас.
// Трябва да е с размер на указателя.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Предоставената от Miri външна функция за започване на размотаване.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Полезният товар, който предаваме на `miri_start_panic`, ще бъде точно аргументът, който получаваме в `cleanup` по-долу.
    // Така че ние просто го боксираме веднъж, за да получим нещо с размер на показалеца.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Възстановете основния `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}