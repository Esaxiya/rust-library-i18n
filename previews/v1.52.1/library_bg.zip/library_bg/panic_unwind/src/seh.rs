//! Windows SEH
//!
//! На Windows (понастоящем само на MSVC) механизмът за обработка на изключения по подразбиране е Structured Exception Handling (SEH).
//! Това е съвсем различно от базираното на джуджета обработка на изключения (напр. Това, което използват други платформи unix) по отношение на вътрешните компоненти на компилатора, така че LLVM се изисква да има доста допълнителна поддръжка за SEH.
//!
//! Накратко, това, което се случва тук, е:
//!
//! 1. Функцията `panic` извиква стандартната функция Windows `_CxxThrowException`, за да изведе подобно на C++ изключение, задействащо процеса на размотаване.
//! 2.
//! Всички площадки за кацане, генерирани от компилатора, използват функцията за личност `__CxxFrameHandler3`, функция в CRT, а кодът за размотаване в Windows ще използва тази функция за личност, за да изпълни целия код за почистване в стека.
//!
//! 3. Всички генерирани от компилатора повиквания към `invoke` имат подложка за кацане, зададена като инструкция за LLVM на `cleanuppad`, която показва началото на рутинната процедура за почистване.
//! Личността (в стъпка 2, дефинирана в CRT) е отговорна за изпълнението на процедурите за почистване.
//! 4. В крайна сметка кодът "catch" във вътрешния `try` (генериран от компилатора) се изпълнява и показва, че контролът трябва да се върне към Rust.
//! Това се прави чрез `catchswitch` плюс инструкция `catchpad` в LLVM IR термини, като накрая връща нормалния контрол на програмата с инструкция `catchret`.
//!
//! Някои специфични разлики от обработката на изключения, базирана на gcc, са:
//!
//! * Rust няма персонализирана функция на личността, а вместо това *винаги*`__CxxFrameHandler3`.Освен това не се извършва допълнително филтриране, така че в крайна сметка улавяме всички изключения на C++ , които изглеждат като вида, който хвърляме.
//! Имайте предвид, че хвърлянето на изключение в Rust така или иначе е недефинирано поведение, така че това трябва да се оправи.
//! * Имаме някои данни, които да предаваме през разгъващата се граница, по-специално `Box<dyn Any + Send>`.Както при изключенията на Джуджи, тези два указателя се съхраняват като полезен товар в самото изключение.
//! На MSVC обаче няма нужда от допълнително разпределение на купчина, защото стекът повиквания се запазва, докато се изпълняват функциите на филтъра.
//! Това означава, че указателите се предават директно на `_CxxThrowException`, които след това се възстановяват във филтърната функция, за да се запишат във фреймовата стека на присъщата `try`.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Това трябва да е опция, защото улавяме изключението чрез препратка и неговият деструктор се изпълнява от времето за изпълнение на C++ .
    // Когато извадим Box от изключението, трябва да оставим изключението в валидно състояние, за да може неговият деструктор да работи, без да пуска двойно Box.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Първо, цял куп определения на типа.Тук има няколко странности, специфични за платформата, и много, които просто са откровено копирани от LLVM.Целта на всичко това е да се приложи функцията `panic` по-долу чрез повикване към `_CxxThrowException`.
//
// Тази функция взема два аргумента.Първият е указател към данните, които предаваме, което в този случай е нашият обект Portrait.Доста лесно за намиране!Следващото обаче е по-сложно.
// Това е указател към структура `_ThrowInfo` и обикновено е предназначен просто да опише хвърленото изключение.
//
// В момента определението за този тип [1] е малко космат и основната странност (и разликата от онлайн статията) е, че на 32-битовите указателите са указатели, но на 64-битовите указателите се изразяват като 32-битови отмествания от `__ImageBase` символ.
//
// За изразяване на това се използват макросите `ptr_t` и `ptr!` в модулите по-долу.
//
// Лабиринтът от дефиниции на типа също следи отблизо какво излъчва LLVM за този вид операция.Например, ако компилирате този C++ код на MSVC и излъчите LLVM IR:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      празнота foo() { rust_panic a = {0, 1};
//          хвърли a;}
//
// По същество това се опитваме да подражаваме.Повечето от стойностите по-долу са просто копирани от LLVM,
//
// Във всеки случай, всички тези структури са изградени по подобен начин и това е малко многословно за нас.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Имайте предвид, че умишлено игнорираме правилата за манипулиране на имена тук: не искаме C++ да може да улавя Rust panics, като просто декларира `struct rust_panic`.
//
//
// Когато модифицирате, уверете се, че низът на името на типа съвпада точно с този, използван в `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Водещият `\x01` байт тук всъщност е магически сигнал към LLVM, за да *не* прилага никакви други манипулации като префикс с знак `_`.
    //
    //
    // Този символ е vtable, използван от `std::type_info` на C++ .
    // Обектите от тип `std::type_info`, дескриптори на типа, имат указател към тази таблица.
    // Дескрипторите на типове са посочени от C++ EH структурите, дефинирани по-горе и които ние конструираме по-долу.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Този дескриптор на типа се използва само при хвърляне на изключение.
// Частта за улов се обработва от intrinsic try, която генерира собствен TypeDescriptor.
//
// Това е добре, тъй като изпълнението на MSVC използва сравнение на низове на името на типа, за да съответства на TypeDescriptors, вместо на равенството на указателя.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Деструктор, използван, ако кодът на C++ реши да заснеме изключението и да го пусне, без да го разпространява.
// Частта за улавяне на try intrinsic ще зададе първата дума на обекта за изключение на 0, така че да бъде пропусната от деструктора.
//
// Обърнете внимание, че x86 Windows използва конвенцията за извикване "thiscall" за функциите на член C++ вместо стандартната конвенция за извикване на "C".
//
// Функцията изключение_копия е малко специална тук: тя се извиква от изпълнението на MSVC под блок try/catch и panic, който генерираме тук, ще бъде използван като резултат от копието на изключение.
//
// Това се използва от средата на изпълнение C++ за поддържане на улавяне на изключения с std::exception_ptr, които не можем да поддържаме, защото Box<dyn Any>не може да се клонира.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException се изпълнява изцяло върху тази рамка на стека, така че няма нужда да прехвърляте `data` в купчината.
    // Просто подаваме указател на стека към тази функция.
    //
    // Тук е необходим ManuallyDrop, тъй като не искаме изключение да отпадне при отвиване.
    // Вместо това той ще бъде отхвърлен от exception_cleanup, който се извиква от времето за изпълнение на C++ .
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Това ... може да изглежда изненадващо и с основание.На 32-битовия MSVC указателите между тези структури са точно това, указатели.
    // На 64-битовия MSVC обаче указателите между структурите са по-скоро изразени като 32-битови отмествания от `__ImageBase`.
    //
    // Следователно, на 32-битов MSVC можем да декларираме всички тези указатели в "статичните" по-горе.
    // На 64-битовия MSVC ще трябва да изразим изваждане на указатели в статиката, което Rust в момента не позволява, така че всъщност не можем да го направим.
    //
    // Следващото най-добро нещо, тогава е да попълните тези структури по време на изпълнение (паниката и без това вече е "slow path").
    // Така че тук преинтерпретираме всички тези полета на показалеца като 32-битови цели числа и след това съхраняваме съответната стойност в него (атомално, тъй като може да се случва едновременно panics).
    //
    // Технически средата на изпълнение вероятно ще направи неатомно четене на тези полета, но на теория те никога не четат стойността *грешна*, така че не би трябвало да е лошо ...
    //
    // Във всеки случай по принцип трябва да направим нещо подобно, докато успеем да изразим повече операции в статиката (и може би никога няма да можем).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // NULL полезен товар тук означава, че стигнахме тук от улова (...) на __rust_try.
    // Това се случва, когато се хване чуждо изключение извън Rust.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Това се изисква от компилатора, за да съществува (напр. Това е елемент от езика), но всъщност никога не се извиква от компилатора, защото __C_specific_handler или _except_handler3 е личната функция, която винаги се използва.
//
// Следователно това е просто неуспешно мъниче.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}