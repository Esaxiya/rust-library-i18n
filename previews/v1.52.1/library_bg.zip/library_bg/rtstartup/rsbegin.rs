// rsbegin.o и rsend.o са така наречените "compiler runtime startup objects".
// Те съдържат код, необходим за правилна инициализация на изпълнението на компилатора.
//
// Когато е свързано изпълнимо или дилиб изображение, целият потребителски код и библиотеки са "sandwiched" между тези два обектни файла, така че кодът или данните от rsbegin.o стават първи в съответните секции на изображението, докато кодът и данните от rsend.o стават последните.
// Този ефект може да се използва за поставяне на символи в началото или в края на раздел, както и за вмъкване на всички необходими горни или долни колонтитули.
//
// Имайте предвид, че действителната точка за влизане на модула се намира в стартовия обект на изпълнението C (обикновено се нарича `crtX.o`), който след това извиква обратни извиквания на инициализация на други компоненти по време на изпълнение (регистрирани чрез още една специална секция с изображения).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Маркира началото на рамката на стека, разгънете информационната секция
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Драскане за вътрешно водене на книги за размотаване.
    // Това се дефинира като `struct object` в $ GCC/unsind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Отпуснете информационните рутинги registration/deregistration.
    // Вижте документите на libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // регистрирайте информация за отвиване при стартиране на модула
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // отписване при изключване
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Специфична за MinGW init/uninit рутинна регистрация
    pub mod mingw_init {
        // Стартиращите обекти на MinGW (crt0.o/dllcrt0.o) ще извикат глобални конструктори в секциите .ctors и .dtors при стартиране и излизане.
        // В случай на DLL, това се прави, когато DLL се зарежда и разтоварва.
        //
        // Линкерът ще сортира секциите, което гарантира, че обратните ни обаждания се намират в края на списъка.
        // Тъй като конструкторите се изпълняват в обратен ред, това гарантира, че нашите обратни извиквания са първите и последните изпълнени.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: Обратни извиквания за инициализация на C
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: Обратни обаждания за прекратяване на C
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}