`core::arch` - Основните специфични за архитектурата на Rust архитектури на библиотеката
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Модулът `core::arch` изпълнява зависими от архитектурата присъщи елементи (например SIMD).

# Usage 

`core::arch` се предлага като част от `libcore` и се реекспортира от `libstd`.Предпочитайте да го използвате чрез `core::arch` или `std::arch`, отколкото чрез този crate.
Нестабилните функции често са достъпни в нощния Rust чрез `feature(stdsimd)`.

Използването на `core::arch` чрез този crate изисква нощно Rust и може (и го прави) често да се счупи.Единствените случаи, в които трябва да обмислите използването му чрез този crate, са:

* ако трябва да прекомпилирате сами `core::arch`, например с активирани определени целеви функции, които не са активирани за `libcore`/`libstd`.
Note: ако трябва да го прекомпилирате за нестандартна цел, моля, предпочитайте да използвате `xargo` и да прекомпилирате `libcore`/`libstd` според случая, вместо да използвате този crate.
  
* използване на някои функции, които може да не са налични дори зад нестабилните функции на Rust.Опитваме се да ги сведем до минимум.
Ако трябва да използвате някои от тези функции, моля, отворете проблем, за да можем да ги изложим в нощно Rust и вие да можете да ги използвате от там.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` се разпространява предимно при условията на лиценза MIT и лиценза Apache (Версия 2.0), като частите са обхванати от различни BSD-подобни лицензи.

Вижте LICENSE-APACHE и LICENSE-MIT за подробности.

# Contribution

Освен ако изрично не посочите друго, всеки принос, умишлено изпратен за включване в `core_arch` от вас, както е дефинирано в лиценза Apache-2.0, ще бъде двойно лицензиран, както по-горе, без никакви допълнителни условия или условия.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












