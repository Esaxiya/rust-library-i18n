use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Използва се, за да каже на нашите `#[assert_instr]` анотации, че всички вътрешни характеристики на simd са на разположение за тестване на техния кодеген, тъй като някои са затворени зад допълнителен `-Ctarget-feature=+unimplemented-simd128`, който в момента няма никакъв еквивалент в `#[target_feature]`.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}