//! Внедряване на Rust panics чрез прекъсване на процеса
//!
//! В сравнение с изпълнението чрез размотаване, този crate е *много* по-опростен!Като се има предвид това, не е чак толкова гъвкав, но ето!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" полезния товар и подложката към съответния аборт на въпросната платформа.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // обадете се на std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // На Windows използвайте специфичния за процесора механизъм __fastfail.В Windows 8 и по-късно това ще прекрати незабавно процеса, без да се изпълняват обработващи изключения в процеса.
            // В по-ранните версии на Windows тази последователност от инструкции ще се третира като нарушение на достъпа, прекратявайки процеса, но без непременно да заобикаля всички манипулатори на изключения.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: това е същото изпълнение като в `abort_internal` на libstd
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Това ... е малко странно.Tl; dr;е, че това е необходимо за правилна връзка, по-дългото обяснение е по-долу.
//
// В момента двоичните файлове на libcore/libstd, които доставяме, са компилирани с `-C panic=unwind`.Това се прави, за да се гарантира, че двоичните файлове са максимално съвместими с възможно най-много ситуации.
// Компилаторът обаче изисква "personality function" за всички функции, компилирани с `-C panic=unwind`.Тази функция на личността е кодирана твърдо в символа `rust_eh_personality` и е дефинирана от елемента `eh_personality` lang.
//
// So...
// защо просто да не дефинираме този елемент тук?Добър въпрос!Начинът, по който се свързват изпълненията на panic, всъщност е малко фин, тъй като те са "sort of" в магазина на crate на компилатора, но всъщност са свързани само ако друг не е свързан всъщност.
//
// Това в крайна сметка означава, че както този crate, така и panic_unwind crate могат да се появят в хранилището на crate на компилатора и ако и двете дефинират елемента `eh_personality` lang, това ще удари грешка.
//
// За да се справи с това, компилаторът изисква само `eh_personality` да е дефиниран, ако времето за изпълнение на panic, в което е свързано, е времето за размотаване и в противен случай не се изисква да бъде дефинирано (с основание).
// В този случай обаче тази библиотека просто дефинира този символ, така че някъде има поне някаква личност.
//
// По същество този символ е точно дефиниран, за да се свърже към двоични файлове на libcore/libstd, но никога не бива да се извиква, тъй като изобщо не свързваме в размотаващо се изпълнение.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // На x86_64-pc-windows-gnu използваме нашата собствена функция на личността, която трябва да върне `ExceptionContinueSearch`, докато предаваме всички наши рамки.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Подобно на горното, това съответства на елемента `eh_catch_typeinfo` lang, който в момента се използва само в Emscripten.
    //
    // Тъй като panics не генерира изключения, а чуждестранните изключения понастоящем са UB с -C panic=прекъсване (въпреки че това може да се промени), всички обаждания catch_unwind никога няма да използват тази информация.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Тези две се извикват от нашите стартиращи обекти на i686-pc-windows-gnu, но не е нужно да правят нищо, така че телата са nops.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}