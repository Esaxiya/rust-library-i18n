use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Това не е стабилна повърхност, но помага да се поддържа `?` евтино помежду им, дори ако LLVM не винаги може да се възползва от него в момента.
    //
    // (За съжаление резултатът и опцията са несъвместими, така че ControlFlow не може да съответства и на двете.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}