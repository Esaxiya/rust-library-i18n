//! `Clone` Portrait за типове, които не могат да бъдат " имплицитно копирани`.
//!
//! В Rust някои прости типове са "implicitly copyable" и когато ги присвоите или ги предадете като аргументи, получателят ще получи копие, оставяйки оригиналната стойност на място.
//! Тези типове не изискват разпределение за копиране и нямат финализатори (т.е. те не съдържат притежавани кутии или внедряват [`Drop`]), така че компилаторът ги смята за евтини и безопасни за копиране.
//!
//! За други типове копията трябва да се правят изрично, като се прилага [`Clone`] Portrait и се извиква методът [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Пример за основно използване:
//!
//! ```
//! let s = String::new(); // Типът низ изпълнява Clone
//! let copy = s.clone(); // за да го клонираме
//! ```
//!
//! За да приложите лесно Clone Portrait, можете да използвате и `#[derive(Clone)]`.Пример:
//!
//! ```
//! #[derive(Clone)] // добавяме Clone Portrait към структурата на Morpheus
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // и сега можем да го клонираме!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Често срещан Portrait за възможността за изрично дублиране на обект.
///
/// Различава се от [`Copy`] с това, че [`Copy`] е неявно и изключително евтино, докато `Clone` винаги е изрично и може или не може да бъде скъпо.
/// За да се приложат тези характеристики, Rust не ви позволява да въведете отново [`Copy`], но можете да въведете отново `Clone` и да изпълните произволен код.
///
/// Тъй като `Clone` е по-общ от [`Copy`], можете автоматично да направите всичко [`Copy`] също `Clone`.
///
/// ## Derivable
///
/// Този Portrait може да се използва с `#[derive]`, ако всички полета са `Clone`.Прилагането на " извличане` на [`Clone`] извиква [`clone`] във всяко поле.
///
/// [`clone`]: Clone::clone
///
/// За обща структура `#[derive]` внедрява `Clone` условно чрез добавяне на обвързан `Clone` върху родови параметри.
///
/// ```
/// // `derive` изпълнява Clone for Reading<T>когато T е Clone.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Как мога да внедря `Clone`?
///
/// Типовете, които са [`Copy`], трябва да имат тривиална реализация на `Clone`.По-официално:
/// ако `T: Copy`, `x: T` и `y: &T`, тогава `let x = y.clone();` е еквивалентно на `let x = *y;`.
/// Ръчните внедрения трябва да бъдат внимателни, за да поддържат този инвариант;несигурният код обаче не трябва да разчита на него, за да гарантира безопасността на паметта.
///
/// Пример за това е обща структура, съдържаща указател на функция.В този случай изпълнението на `Clone` не може да бъде " получено`, но може да бъде приложено като:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Допълнителни изпълнители
///
/// В допълнение към [implementors listed below][impls], следните типове също изпълняват `Clone`:
///
/// * Типове елементи на функции (т.е. отделните типове, дефинирани за всяка функция)
/// * Типове указатели на функции (напр. `fn() -> i32`)
/// * Типове масиви за всички размери, ако типът артикул също така изпълнява `Clone` (напр. `[i32; 123456]`)
/// * Типове типове, ако всеки компонент също така изпълнява `Clone` (например `()`, `(i32, bool)`)
/// * Типове затваряне, ако те не улавят никаква стойност от околната среда или ако всички такива уловени стойности сами реализират `Clone`.
///   Обърнете внимание, че променливите, заснети от споделена препратка, винаги изпълняват `Clone` (дори ако референтът не го прави), докато променливите, заснети от променлива препратка, никога не изпълняват `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Връща копие на стойността.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str изпълнява Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Извършва възлагане на копиране от `source`.
    ///
    /// `a.clone_from(&b)` е еквивалентен на `a = b.clone()` по функционалност, но може да бъде заменен, за да се използват повторно ресурсите на `a`, за да се избегнат ненужни разпределения.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Извлечете макрос, генериращ impl на Portrait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): тези структури се използват единствено от#[derive], за да се твърди, че всеки компонент на даден тип изпълнява Clone или Copy.
//
//
// Тези структури никога не трябва да се появяват в потребителския код.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Реализации на `Clone` за примитивни типове.
///
/// Реализации, които не могат да бъдат описани в Rust, са внедрени в `traits::SelectionContext::copy_clone_conditions()` в `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Споделените препратки могат да бъдат клонирани, но променливите препратки *не могат*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Споделените препратки могат да бъдат клонирани, но променливите препратки *не могат*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}