#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker` позволява на изпълнителя на изпълнител на задача да създаде [`Waker`], който осигурява персонализирано поведение при събуждане.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Състои се от указател за данни и [virtual function pointer table (vtable)][vtable], който персонализира поведението на `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Указател на данни, който може да се използва за съхраняване на произволни данни, както се изисква от изпълнителя.
    /// Това може да е напр
    /// изтрит тип указател към `Arc`, който е свързан със задачата.
    /// Стойността на това поле се предава на всички функции, които са част от vtable като първи параметър.
    ///
    data: *const (),
    /// Таблица на виртуални функции, която персонализира поведението на този waker.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Създава нов `RawWaker` от предоставения указател `data` и `vtable`.
    ///
    /// Указателят `data` може да се използва за съхраняване на произволни данни, както се изисква от изпълнителя.Това може да е напр
    /// изтрит тип указател към `Arc`, който е свързан със задачата.
    /// Стойността на този указател ще бъде предадена на всички функции, които са част от `vtable` като първи параметър.
    ///
    /// `vtable` персонализира поведението на `Waker`, който се създава от `RawWaker`.
    /// За всяка операция на `Waker` ще бъде извикана свързаната функция в `vtable` на базовия `RawWaker`.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Таблица на виртуална функция (vtable), която определя поведението на [`RawWaker`].
///
/// Указателят, предаден на всички функции в vtable, е указателят `data` от заграждащия обект [`RawWaker`].
///
/// Функциите вътре в тази структура са предназначени да бъдат извикани само на указателя `data` на правилно конструиран обект [`RawWaker`] от вътрешността на изпълнението на [`RawWaker`].
/// Извикването на една от съдържащите се функции с помощта на друг показалец `data` ще доведе до недефинирано поведение.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Тази функция ще бъде извикана, когато [`RawWaker`] бъде клониран, например когато [`Waker`], в който се съхранява [`RawWaker`], бъде клониран.
    ///
    /// Внедряването на тази функция трябва да запази всички ресурси, необходими за този допълнителен екземпляр на [`RawWaker`] и свързаната задача.
    /// Извикването на `wake` на получения [`RawWaker`] трябва да доведе до събуждане на същата задача, която би била събудена от оригиналния [`RawWaker`].
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Тази функция ще бъде извикана, когато `wake` бъде извикан на [`Waker`].
    /// Той трябва да събуди задачата, свързана с този [`RawWaker`].
    ///
    /// Внедряването на тази функция трябва да гарантира, че освобождава всички ресурси, свързани с този екземпляр на [`RawWaker`] и свързана задача.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Тази функция ще бъде извикана, когато `wake_by_ref` бъде извикан на [`Waker`].
    /// Той трябва да събуди задачата, свързана с този [`RawWaker`].
    ///
    /// Тази функция е подобна на `wake`, но не трябва да консумира предоставения указател за данни.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Тази функция се извиква, когато [`RawWaker`] падне.
    ///
    /// Внедряването на тази функция трябва да гарантира, че освобождава всички ресурси, свързани с този екземпляр на [`RawWaker`] и свързана задача.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Създава нов `RawWakerVTable` от предоставените функции `clone`, `wake`, `wake_by_ref` и `drop`.
    ///
    /// # `clone`
    ///
    /// Тази функция ще бъде извикана, когато [`RawWaker`] бъде клониран, например когато [`Waker`], в който се съхранява [`RawWaker`], бъде клониран.
    ///
    /// Внедряването на тази функция трябва да запази всички ресурси, необходими за този допълнителен екземпляр на [`RawWaker`] и свързаната задача.
    /// Извикването на `wake` на получения [`RawWaker`] трябва да доведе до събуждане на същата задача, която би била събудена от оригиналния [`RawWaker`].
    ///
    /// # `wake`
    ///
    /// Тази функция ще бъде извикана, когато `wake` бъде извикан на [`Waker`].
    /// Той трябва да събуди задачата, свързана с този [`RawWaker`].
    ///
    /// Внедряването на тази функция трябва да гарантира, че освобождава всички ресурси, свързани с този екземпляр на [`RawWaker`] и свързана задача.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Тази функция ще бъде извикана, когато `wake_by_ref` бъде извикан на [`Waker`].
    /// Той трябва да събуди задачата, свързана с този [`RawWaker`].
    ///
    /// Тази функция е подобна на `wake`, но не трябва да консумира предоставения указател за данни.
    ///
    /// # `drop`
    ///
    /// Тази функция се извиква, когато [`RawWaker`] падне.
    ///
    /// Внедряването на тази функция трябва да гарантира, че освобождава всички ресурси, свързани с този екземпляр на [`RawWaker`] и свързана задача.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// `Context` на асинхронна задача.
///
/// В момента `Context` служи само за предоставяне на достъп до `&Waker`, който може да се използва за събуждане на текущата задача.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Уверете се, че имаме future-доказателство срещу измененията на дисперсията, като принудим времето на живот да бъде инвариантно (времето на живот на аргумента е противоположно, докато времето на връщане на позицията е ковариантно).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Създайте нов `Context` от `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Връща препратка към `Waker` за текущата задача.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker` е дръжка за събуждане на задача чрез уведомяване на изпълнителя, че е готова за изпълнение.
///
/// Тази манипулация капсулира екземпляр [`RawWaker`], който дефинира поведението на събуждане, специфично за изпълнителя.
///
///
/// Прилага [`Clone`], [`Send`] и [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Събудете задачата, свързана с този `Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Действителното повикване за събуждане се делегира чрез виртуално извикване на функция към изпълнението, което се дефинира от изпълнителя.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Не се обаждайте на `drop`-waker ще бъде погълнат от `wake`.
        crate::mem::forget(self);

        // БЕЗОПАСНОСТ: Това е безопасно, защото `Waker::from_raw` е единственият начин
        // за инициализиране на `wake` и `data`, изискващи от потребителя да потвърди, че договорът на `RawWaker` е спазен.
        //
        unsafe { (wake)(data) };
    }

    /// Събудете задачата, свързана с този `Waker`, без да консумирате `Waker`.
    ///
    /// Това е подобно на `wake`, но може да е малко по-малко ефективно в случая, когато е наличен притежаван `Waker`.
    /// Този метод трябва да се предпочита пред извикването на `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Действителното повикване за събуждане се делегира чрез виртуално извикване на функция към изпълнението, което се дефинира от изпълнителя.
        //

        // БЕЗОПАСНОСТ: вижте `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Връща `true`, ако този `Waker` и друг `Waker` са събудили същата задача.
    ///
    /// Тази функция работи с най-добри усилия и може да върне false, дори когато `Waker`s ще събуди същата задача.
    /// Ако обаче тази функция върне `true`, гарантирано е, че `Waker`s ще събудят същата задача.
    ///
    /// Тази функция се използва предимно за целите на оптимизацията.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Създава нов `Waker` от [`RawWaker`].
    ///
    /// Поведението на върнатия `Waker` е недефинирано, ако договорът, дефиниран в документацията на [" RawWaker`] и [" RawWakerVTable`], не се поддържа.
    ///
    /// Следователно този метод е опасен.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // БЕЗОПАСНОСТ: Това е безопасно, защото `Waker::from_raw` е единственият начин
            // за инициализиране на `clone` и `data`, изискващи от потребителя да потвърди, че договорът на [`RawWaker`] е спазен.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // БЕЗОПАСНОСТ: Това е безопасно, защото `Waker::from_raw` е единственият начин
        // за инициализиране на `drop` и `data`, изискващи от потребителя да потвърди, че договорът на `RawWaker` е спазен.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}