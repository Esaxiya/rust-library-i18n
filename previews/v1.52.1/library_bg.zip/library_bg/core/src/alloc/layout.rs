use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Въпреки че тази функция се използва на едно място и нейното изпълнение може да бъде очертано, предишните опити за това направиха rustc по-бавен:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Оформление на блок памет.
///
/// Екземпляр на `Layout` описва конкретно оформление на паметта.
/// Изграждате `Layout` като вход, който да дадете на разпределител.
///
/// Всички оформления имат асоцииран размер и подравняване на мощността на две.
///
/// (Обърнете внимание, че оформленията *не* се изискват да имат ненулев размер, въпреки че `GlobalAlloc` изисква всички заявки за памет да са с ненулев размер.
/// Повикващият трябва или да гарантира, че са изпълнени условия като това, да използва специфични разпределители с по-разхлабени изисквания или да използва по-мекия интерфейс `Allocator`.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // размер на заявения блок памет, измерен в байтове.
    size_: usize,

    // подравняване на заявения блок памет, измерено в байтове.
    // ние гарантираме, че това винаги е сила на две, тъй като API като `posix_memalign` го изискват и е разумно ограничение за налагане на конструктори на оформление.
    //
    //
    // (Въпреки това, ние не аналогично изискваме `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Конструира `Layout` от дадени `size` и `align` или връща `LayoutError`, ако някое от следните условия не е изпълнено:
    ///
    /// * `align` не трябва да е нула,
    ///
    /// * `align` трябва да е степен на две,
    ///
    /// * `size`, когато се закръгля до най-близкото кратно на `align`, не трябва да прелива (т.е. закръглената стойност трябва да бъде по-малка или равна на `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (power-of-two предполага подравняване!=0.)

        // Закръгленият размер е:
        //   size_rounded_up=(размер + подравняване, 1)&! (подравняване, 1);
        //
        // Отгоре знаем, че е подравнено!=0.
        // Ако добавянето (подравняване, 1) не препълни, закръгляването нагоре ще бъде добре.
        //
        // Обратно,&-masking с! (Align, 1) ще извади само битове от нисък ред.
        // По този начин, ако настъпи препълване със сумата,&-mask не може да извади достатъчно, за да отмени това препълване.
        //
        //
        // Горе означава, че проверката за препълване на сумирането е едновременно необходима и достатъчна.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // БЕЗОПАСНОСТ: условията за `from_size_align_unchecked` са били
        // отметната по-горе.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Създава оформление, заобикаляйки всички проверки.
    ///
    /// # Safety
    ///
    /// Тази функция е опасна, тъй като не проверява предварителните условия от [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // БЕЗОПАСНОСТ: повикващият трябва да гарантира, че `align` е по-голям от нула.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Минималният размер в байтове за блок памет от това оформление.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Минималното подреждане на байта за блок памет от това оформление.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Конструира `Layout`, подходящ за задържане на стойност от тип `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // БЕЗОПАСНОСТ: подравняването се гарантира от Rust да бъде степен на две и
        // комбинацията size + align гарантирано се побира в нашето адресно пространство.
        // В резултат използвайте непроверения конструктор тук, за да избегнете вмъкването на код, който panics, ако не е оптимизиран достатъчно добре.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Произвежда оформление, описващо запис, който може да се използва за разпределяне на структурата на поддръжката за `T` (която може да бъде Portrait или друг неразмерен тип като отрязък).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // БЕЗОПАСНОСТ: вижте обосновката в `new` защо това се използва небезопасният вариант
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Произвежда оформление, описващо запис, който може да се използва за разпределяне на структурата на поддръжката за `T` (която може да бъде Portrait или друг неразмерен тип като отрязък).
    ///
    /// # Safety
    ///
    /// Тази функция е безопасна за извикване само ако са налице следните условия:
    ///
    /// - Ако `T` е `Sized`, тази функция винаги е безопасна за извикване.
    /// - Ако неоразмерената опашка на `T` е:
    ///     - [slice], тогава дължината на опашката на среза трябва да бъде инициализирано цяло число, а размерът на *цялата стойност*(динамична дължина на опашката + префикс със статичен размер) трябва да се побере в `isize`.
    ///     - [trait object], тогава vtable частта на показалеца трябва да сочи към валидна vtable за типа `T`, придобити чрез принудително оразмеряване, а размерът на *цялата стойност*(динамична дължина на опашката + префикс със статичен размер) трябва да се побере в `isize`.
    ///
    ///     - (unstable) [extern type], тогава тази функция винаги е безопасна за извикване, но може да panic или по друг начин да върне грешна стойност, тъй като оформлението на външния тип не е известно.
    ///     Това е същото поведение като [`Layout::for_value`] при препратка към опашка от външен тип.
    ///     - в противен случай консервативно не е позволено да извиквате тази функция.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // БЕЗОПАСНОСТ: предаваме предпоставките за тези функции на повикващия
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // БЕЗОПАСНОСТ: вижте обосновката в `new` защо това се използва небезопасният вариант
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Създава `NonNull`, който е висящ, но добре подравнен за това оформление.
    ///
    /// Обърнете внимание, че стойността на показалеца може потенциално да представлява валиден указател, което означава, че това не трябва да се използва като "not yet initialized" sentinel стойност.
    /// Типовете, които лениво разпределят, трябва да проследяват инициализацията по някакъв друг начин.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // БЕЗОПАСНОСТ: гарантира се, че подравняването е ненулево
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Създава оформление, описващо записа, който може да съдържа стойност от същото оформление като `self`, но което също е подравнено с подравняване `align` (измерено в байтове).
    ///
    ///
    /// Ако `self` вече отговаря на предписаното подравняване, връща `self`.
    ///
    /// Имайте предвид, че този метод не добавя никакви подплънки към общия размер, независимо дали върнатото оформление има различно подравняване.
    /// С други думи, ако `K` има размер 16, `K.align_to(32)` ще *все още* ще има размер 16.
    ///
    /// Връща грешка, ако комбинацията от `self.size()` и дадения `align` нарушава условията, изброени в [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Връща количеството запълване, което трябва да вмъкнем след `self`, за да гарантираме, че следният адрес ще отговаря на `align` (измерено в байтове).
    ///
    /// например, ако `self.size()` е 9, тогава `self.padding_needed_for(4)` връща 3, защото това е минималният брой байтове за подложка, необходим за получаване на 4-изравнен адрес (ако приемем, че съответният блок памет започва от 4-подравнен адрес).
    ///
    ///
    /// Връщаната стойност на тази функция няма значение, ако `align` не е сила на две.
    ///
    /// Имайте предвид, че полезността на върнатата стойност изисква `align` да бъде по-малко или равно на подравняването на началния адрес за целия разпределен блок памет.Един от начините да се задоволи това ограничение е да се осигури `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Закръглената стойност е:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // и след това връщаме разликата в подплънките: `len_rounded_up - len`.
        //
        // Използваме модулна аритметика в:
        //
        // 1. align е гарантирано, че е> 0, така че align, 1 винаги е валиден.
        //
        // 2.
        // `len + align - 1` може да препълни най-много с `align - 1`, така че&-mask с `!(align - 1)` ще гарантира, че в случай на преливане, `len_rounded_up` сам ще бъде 0.
        //
        //    По този начин върнатата подложка, когато се добави към `len`, дава 0, което тривиално удовлетворява подравняването `align`.
        //
        // (Разбира се, опитите за разпределяне на блокове памет, чийто размер и препълване по горния начин трябва да накарат разпределителя да доведе до грешка така или иначе.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Създава оформление чрез закръгляване на размера на това оформление до кратно на подравняването на оформлението.
    ///
    ///
    /// Това е еквивалентно на добавяне на резултата от `padding_needed_for` към текущия размер на оформлението.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Това не може да прелее.Цитирайки инварианта на Layout:
        // > `size`, когато се закръгли до най-близкото кратно на `align`,
        // > не трябва да прелива (т.е. закръглената стойност трябва да бъде по-малка от
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Създава оформление, описващо записа за `n` екземпляри на `self`, с подходящо количество подложка между всеки, за да се гарантира, че на всеки екземпляр е даден заявения размер и подравняване.
    /// При успех връща `(k, offs)`, където `k` е оформлението на масива, а `offs` е разстоянието между началото на всеки елемент в масива.
    ///
    /// При аритметично преливане връща `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Това не може да прелее.Цитирайки инварианта на Layout:
        // > `size`, когато се закръгли до най-близкото кратно на `align`,
        // > не трябва да прелива (т.е. закръглената стойност трябва да бъде по-малка от
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // БЕЗОПАСНОСТ: self.align вече е известно, че е валиден и alloc_size е бил
        // подплатени вече.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Създава оформление, описващо записа за `self`, последван от `next`, включително всички необходими подложки, за да се гарантира, че `next` ще бъде правилно подравнен, но *няма последващо подплащане*.
    ///
    /// За да съвпаднете с оформлението на представяне C `repr(C)`, трябва да извикате `pad_to_align`, след като разширите оформлението с всички полета.
    /// (Няма начин да съответства на оформлението на представяне по подразбиране Rust `repr(Rust)`, as it is unspecified.)
    ///
    /// Имайте предвид, че подравняването на полученото оформление ще бъде максимално на тези на `self` и `next`, за да се осигури подравняване на двете части.
    ///
    /// Връща `Ok((k, offset))`, където `k` е оформление на конкатенирания запис, а `offset` е относителното местоположение в байтове на началото на `next`, вградено в конкатенирания запис (ако приемем, че самият запис започва с отместване 0).
    ///
    ///
    /// При аритметично преливане връща `LayoutError`.
    ///
    /// # Examples
    ///
    /// За да изчислите оформлението на `#[repr(C)]` структура и отместванията на полетата от оформлението на полетата:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Не забравяйте да финализирате с `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // проверете дали работи
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Създава оформление, описващо записа за `n` екземпляри на `self`, без подложка между всеки екземпляр.
    ///
    /// Имайте предвид, че за разлика от `repeat`, `repeat_packed` не гарантира, че повтарящите се екземпляри на `self` ще бъдат правилно подравнени, дори ако даден екземпляр на `self` е правилно подравнен.
    /// С други думи, ако оформлението, върнато от `repeat_packed`, се използва за разпределяне на масив, не е гарантирано, че всички елементи в масива ще бъдат правилно подравнени.
    ///
    /// При аритметично преливане връща `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Създава оформление, описващо записа за `self`, последвано от `next`, без допълнителни подплънки между двете.
    /// Тъй като не е вмъкната подложка, подравняването на `next` е без значение и изобщо не е включено * в полученото оформление.
    ///
    ///
    /// При аритметично преливане връща `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Създава оформление, описващо записа за `[T; n]`.
    ///
    /// При аритметично преливане връща `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Параметрите, дадени на `Layout::from_size_align` или друг конструктор `Layout`, не отговарят на документираните му ограничения.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (имаме нужда от това за импулса надолу по веригата на грешка Portrait)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}