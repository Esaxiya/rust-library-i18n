#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Съдържа дефиниции на структури за оформлението на вградените типове компилатор.
//!
//! Те могат да се използват като цели на трансмути в небезопасен код за директно манипулиране на суровите представителства.
//!
//!
//! Дефиницията им винаги трябва да съответства на ABI, дефиниран в `rustc_middle::ty::layout`.
//!

/// Представянето на обект Portrait като `&dyn SomeTrait`.
///
/// Тази структура има същото оформление като типове като `&dyn SomeTrait` и `Box<dyn AnotherTrait>`.
///
/// `TraitObject` гарантирано съответства на оформленията, но това не е типът на Portrait обекти (напр. полетата не са пряко достъпни на `&dyn SomeTrait`), нито контролира това оформление (промяната на дефиницията няма да промени оформлението на `&dyn SomeTrait`).
///
/// Той е проектиран да се използва само от небезопасен код, който трябва да манипулира детайлите на ниско ниво.
///
/// Няма начин да се препраща към всички Portrait обекти като цяло, така че единственият начин за създаване на стойности от този тип е с функции като [`std::mem::transmute`][transmute].
/// По същия начин единственият начин да се създаде истински обект Portrait от стойност `TraitObject` е с `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Синтезирането на обект Portrait с несъответстващи типове-такъв, при който vtable не съответства на типа на стойността, към която сочи указателят на данните-е много вероятно да доведе до недефинирано поведение.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // пример Portrait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // нека компилаторът направи обект Portrait
/// let object: &dyn Foo = &value;
///
/// // погледнете суровото представяне
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // указателят за данни е адресът на `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // конструирайте нов обект, сочейки към различен `i32`, като внимавате да използвате `i32` vtable от `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // би трябвало да работи така, сякаш директно сме конструирали обект Portrait от `other_value`
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}