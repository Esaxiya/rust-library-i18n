#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Предоставя типа на метаданните на указателя за всеки тип, посочен към.
///
/// # Метаданни на указателя
///
/// Типовете необработени указатели и референтните типове в Rust могат да се разглеждат като направени от две части:
/// указател на данни, който съдържа адреса на паметта на стойността и някои метаданни.
///
/// За типовете с статичен размер (които прилагат `Sized` traits), както и за типовете `extern`, се казва, че указателите са " тънки`: метаданните са с нулев размер и техният тип е `()`.
///
///
/// Казват, че указателите към [dynamically-sized types][dst] са " широки`или " дебели`, те имат метаданни с не нулев размер:
///
/// * За структури, чието последно поле е DST, метаданните са метаданните за последното поле
/// * За типа `str` метаданните са дължината в байтове като `usize`
/// * За типове срезове като `[T]` метаданните са дължината в елементите като `usize`
/// * За обекти Portrait като `dyn SomeTrait` метаданните са [`DynMetadata<Self>`][DynMetadata] (напр. `DynMetadata<dyn SomeTrait>`)
///
/// В future езикът Rust може да придобие нови видове типове, които имат различни метаданни на указателя.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` Portrait
///
/// Смисълът на този Portrait е свързаният с него `Metadata` тип, който е `()` или `usize` или `DynMetadata<_>`, както е описано по-горе.
/// Той се прилага автоматично за всеки тип.
/// Може да се приеме, че се изпълнява в общ контекст, дори без съответна граница.
///
/// # Usage
///
/// Суровите указатели могат да бъдат декомпозирани в адреса на данните и компонентите на метаданни с техния метод [`to_raw_parts`].
///
/// Като алтернатива само метаданните могат да бъдат извлечени с функцията [`metadata`].
/// Препратка може да бъде предадена на [`metadata`] и имплицитно принудена.
///
/// Показалецът (possibly-wide) може да бъде върнат заедно от неговия адрес и метаданни с [`from_raw_parts`] или [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Типът за метаданни в указатели и препратки към `Self`.
    #[lang = "metadata_type"]
    // NOTE: Запазете Portrait bounds в `static_assert_expected_bounds_for_metadata`
    //
    // в `library/core/src/ptr/metadata.rs` в синхрон с тези тук:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Указателите към типовете, изпълняващи този псевдоним Portrait, са " тънки`.
///
/// Това включва типово статични типове и `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: не стабилизирайте това, преди псевдонимите на Portrait да са стабилни в езика?
pub trait Thin = Pointee<Metadata = ()>;

/// Извличане на компонента за метаданни на указател.
///
/// Стойности от тип `*mut T`, `&T` или `&mut T` могат да бъдат предадени директно към тази функция, тъй като те имплицитно принуждават към `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // БЕЗОПАСНОСТ: Достъпът до стойността от обединението `PtrRepr` е безопасен, тъй като * const T
    // и PtrComponents<T>имат еднакви оформления на паметта.
    // Само std може да направи тази гаранция.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Формира (possibly-wide) суров указател от адрес на данни и метаданни.
///
/// Тази функция е безопасна, но върнатият указател не е непременно безопасен за пренасочване.
/// За филийки вижте документацията на [`slice::from_raw_parts`] за изисквания за безопасност.
/// За обектите Portrait метаданните трябва да идват от указател към същия основен изтрит тип.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // БЕЗОПАСНОСТ: Достъпът до стойността от обединението `PtrRepr` е безопасен, тъй като * const T
    // и PtrComponents<T>имат еднакви оформления на паметта.
    // Само std може да направи тази гаранция.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Изпълнява същата функционалност като [`from_raw_parts`], с изключение на това, че се връща суров указател `*mut`, за разлика от суров указател `* const`.
///
///
/// Вижте документацията на [`from_raw_parts`] за повече подробности.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // БЕЗОПАСНОСТ: Достъпът до стойността от обединението `PtrRepr` е безопасен, тъй като * const T
    // и PtrComponents<T>имат еднакви оформления на паметта.
    // Само std може да направи тази гаранция.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Необходим е ръчен impl, за да се избегне обвързването с `T: Copy`.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Необходим е ръчен impl, за да се избегне обвързването с `T: Clone`.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Метаданните за тип обект `Dyn = dyn SomeTrait` Portrait.
///
/// Това е указател към vtable (виртуална таблица на повикванията), която представлява цялата необходима информация за манипулиране на конкретния тип, съхраняван в обект Portrait.
/// Vtable, особено той съдържа:
///
/// * размер на типа
/// * подравняване на типа
/// * указател към `drop_in_place` impl на типа (може да не е опция за обикновени-стари данни)
/// * насочва към всички методи за изпълнение на типа на Portrait
///
/// Обърнете внимание, че първите три са специални, защото са необходими за разпределяне, пускане и освобождаване на всеки обект Portrait.
///
/// Възможно е тази структура да се наименува с параметър тип, който не е обект `dyn` Portrait (например `DynMetadata<u64>`), но не и да се получи смислена стойност на тази структура.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Общият префикс на всички vtables.Следват се указатели на функции за методите Portrait.
///
/// Частни подробности за изпълнението на `DynMetadata::size_of` и др.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Връща размера на типа, свързан с тази vtable.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Връща подравняването на типа, свързан с тази vtable.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Връща размера и подравняването заедно като `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // БЕЗОПАСНОСТ: компилаторът е излъчил тази vtable за конкретен тип Rust, който
        // е известно, че има валидно оформление.Обосновка като при `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Необходими са ръчни импулси, за да се избегнат границите на `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}