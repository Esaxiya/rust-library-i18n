use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` но ненулеви и ковариантни.
///
/// Това често е правилното нещо, което трябва да се използва при изграждане на структури от данни с помощта на сурови указатели, но в крайна сметка е по-опасно за използване поради допълнителните му свойства.Ако не сте сигурни дали трябва да използвате `NonNull<T>`, просто използвайте `*mut T`!
///
/// За разлика от `*mut T`, показалецът винаги трябва да е ненулен, дори ако указателят никога не е дереферендиран.Това е така, че преброяванията могат да използват тази забранена стойност като дискриминант-`Option<NonNull<T>>` има същия размер като `* mut T`.
/// Въпреки това показалецът все още може да се мотае, ако не е дереферендиран.
///
/// За разлика от `*mut T`, `NonNull<T>` е избран да бъде ковариант над `T`.Това прави възможно използването на `NonNull<T>` при изграждане на ковариантни типове, но въвежда риска от несъстоятелност, ако се използва в тип, който всъщност не трябва да бъде ковариант.
/// (За `*mut T` е направен обратният избор, въпреки че технически несъстоятелността може да бъде причинена само от извикване на опасни функции.)
///
/// Ковариацията е правилна за повечето безопасни абстракции, като `Box`, `Rc`, `Arc`, `Vec` и `LinkedList`.Това е така, защото те предоставят публичен API, който следва нормалните споделени XOR изменяеми правила на Rust.
///
/// Ако вашият тип не може безопасно да бъде ковариант, трябва да се уверите, че съдържа някакво допълнително поле, за да осигури инвариантност.Често това поле ще бъде от тип [`PhantomData`] като `PhantomData<Cell<T>>` или `PhantomData<&'a mut T>`.
///
/// Забележете, че `NonNull<T>` има екземпляр `From` за `&T`.Това обаче не променя факта, че мутирането чрез (указател, получен от a) споделена препратка е недефинирано поведение, освен ако мутацията не се случи в [`UnsafeCell<T>`].Същото важи и за създаването на променлива препратка от споделена препратка.
///
/// Когато използвате този екземпляр `From` без `UnsafeCell<T>`, вие носите отговорност да гарантирате, че `as_mut` никога не се извиква и `as_ptr` никога не се използва за мутация.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` указателите не са `Send`, тъй като данните, към които се позовават, могат да бъдат псевдоними.
// NB, този impl е ненужен, но трябва да предоставя по-добри съобщения за грешки.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` указателите не са `Sync`, тъй като данните, към които се позовават, могат да бъдат псевдоними.
// NB, този impl е ненужен, но трябва да предоставя по-добри съобщения за грешки.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Създава нов `NonNull`, който е висящ, но добре подравнен.
    ///
    /// Това е полезно за инициализиране на типове, които лениво разпределят, както прави `Vec::new`.
    ///
    /// Имайте предвид, че стойността на показалеца може потенциално да представлява валиден указател към `T`, което означава, че това не трябва да се използва като контролна стойност "not yet initialized".
    /// Типовете, които лениво разпределят, трябва да проследяват инициализацията по някакъв друг начин.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // БЕЗОПАСНОСТ: mem::align_of() връща ненулево оразмеряване, което след това се излива
        // към * мут Т.
        // Следователно `ptr` не е нула и условията за извикване на new_unchecked() са спазени.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Връща споделени препратки към стойността.За разлика от [`as_ref`], това не изисква стойността да се инициализира.
    ///
    /// За променящия се аналог вижте [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Когато извиквате този метод, трябва да се уверите, че всички от следните са верни:
    ///
    /// * Показалецът трябва да бъде правилно подравнен.
    ///
    /// * Трябва да е "dereferencable" в смисъла, дефиниран в [the module documentation].
    ///
    /// * Трябва да приложите правилата за псевдоними на Rust, тъй като върнатият живот `'a` е произволно избран и не отразява непременно действителния живот на данните.
    ///
    ///   По-специално, по време на този живот паметта, към която сочи указателят, не трябва да мутира (освен в `UnsafeCell`).
    ///
    /// Това важи дори ако резултатът от този метод е неизползван!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // БЕЗОПАСНОСТ: повикващият трябва да гарантира, че `self` отговаря на всички
        // изисквания за справка.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Връща уникални препратки към стойността.За разлика от [`as_mut`], това не изисква стойността да се инициализира.
    ///
    /// За споделения аналог вижте [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Когато извиквате този метод, трябва да се уверите, че всички от следните са верни:
    ///
    /// * Показалецът трябва да бъде правилно подравнен.
    ///
    /// * Трябва да е "dereferencable" в смисъла, дефиниран в [the module documentation].
    ///
    /// * Трябва да приложите правилата за псевдоними на Rust, тъй като върнатият живот `'a` е произволно избран и не отразява непременно действителния живот на данните.
    ///
    ///   По-специално, за продължителността на този живот паметта, към която сочи указателят, не трябва да бъде достъпвана (четена или записвана) чрез друг указател.
    ///
    /// Това важи дори ако резултатът от този метод е неизползван!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // БЕЗОПАСНОСТ: повикващият трябва да гарантира, че `self` отговаря на всички
        // изисквания за справка.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Създава нов `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` трябва да е не-null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // БЕЗОПАСНОСТ: повикващият трябва да гарантира, че `ptr` не е нулев.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Създава нов `NonNull`, ако `ptr` не е нулев.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // БЕЗОПАСНОСТ: Указателят вече е проверен и не е нулев
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Изпълнява същата функционалност като [`std::ptr::from_raw_parts`], с изключение на това, че се връща указател `NonNull`, за разлика от суров указател `*const`.
    ///
    ///
    /// Вижте документацията на [`std::ptr::from_raw_parts`] за повече подробности.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // БЕЗОПАСНОСТ: Резултатът от `ptr::from::raw_parts_mut` не е нулев, защото `data_address` е.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Декомпозирайте (евентуално широк) указател в е адрес и компоненти на метаданни.
    ///
    /// Указателят може по-късно да бъде реконструиран с [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Придобива основния указател `*mut`.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Връща споделена препратка към стойността.Ако стойността може да бъде неинициализирана, вместо това трябва да се използва [`as_uninit_ref`].
    ///
    /// За променящия се аналог вижте [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Когато извиквате този метод, трябва да се уверите, че всички от следните са верни:
    ///
    /// * Показалецът трябва да бъде правилно подравнен.
    ///
    /// * Трябва да е "dereferencable" в смисъла, дефиниран в [the module documentation].
    ///
    /// * Указателят трябва да сочи към инициализиран екземпляр на `T`.
    ///
    /// * Трябва да приложите правилата за псевдоними на Rust, тъй като върнатият живот `'a` е произволно избран и не отразява непременно действителния живот на данните.
    ///
    ///   По-специално, по време на този живот паметта, към която сочи указателят, не трябва да мутира (освен в `UnsafeCell`).
    ///
    /// Това важи дори ако резултатът от този метод е неизползван!
    /// (Частта за инициализацията все още не е напълно решена, но докато не бъде, единственият безопасен подход е да се гарантира, че те наистина са инициализирани.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // БЕЗОПАСНОСТ: повикващият трябва да гарантира, че `self` отговаря на всички
        // изисквания за справка.
        unsafe { &*self.as_ptr() }
    }

    /// Връща уникална препратка към стойността.Ако стойността може да бъде неинициализирана, вместо това трябва да се използва [`as_uninit_mut`].
    ///
    /// За споделения аналог вижте [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Когато извиквате този метод, трябва да се уверите, че всички от следните са верни:
    ///
    /// * Показалецът трябва да бъде правилно подравнен.
    ///
    /// * Трябва да е "dereferencable" в смисъла, дефиниран в [the module documentation].
    ///
    /// * Указателят трябва да сочи към инициализиран екземпляр на `T`.
    ///
    /// * Трябва да приложите правилата за псевдоними на Rust, тъй като върнатият живот `'a` е произволно избран и не отразява непременно действителния живот на данните.
    ///
    ///   По-специално, за продължителността на този живот паметта, към която сочи указателят, не трябва да бъде достъпвана (четена или записвана) чрез друг указател.
    ///
    /// Това важи дори ако резултатът от този метод е неизползван!
    /// (Частта за инициализацията все още не е напълно решена, но докато не бъде, единственият безопасен подход е да се гарантира, че те наистина са инициализирани.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // БЕЗОПАСНОСТ: повикващият трябва да гарантира, че `self` отговаря на всички
        // изисквания за променлива референция.
        unsafe { &mut *self.as_ptr() }
    }

    /// Предава към указател от друг тип.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // БЕЗОПАСНОСТ: `self` е указател `NonNull`, който непременно не е нулев
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Създава ненулев суров фрагмент от тънък указател и дължина.
    ///
    /// Аргументът `len` е броят на **елементите**, а не броят на байтовете.
    ///
    /// Тази функция е безопасна, но пренасочването на връщаната стойност е опасно.
    /// Вижте документацията на [`slice::from_raw_parts`] за изискванията за безопасност на нарязване.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // създайте указател на среза, когато започвате с указател към първия елемент
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Обърнете внимание, че този пример изкуствено демонстрира използване на този метод, но `let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // БЕЗОПАСНОСТ: `data` е указател `NonNull`, който непременно не е нулев
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Връща дължината на ненулево сурово парче.
    ///
    /// Върнатата стойност е броят на **елементите**, а не броят на байтовете.
    ///
    /// Тази функция е безопасна, дори когато ненулевият суров фрагмент не може да бъде пренасочен към фрагмент, тъй като указателят няма валиден адрес.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Връща ненулеви указател към буфера на среза.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // БЕЗОПАСНОСТ: Знаем, че `self` не е нулев.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Връща суров указател към буфера на среза.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Връща споделена препратка към парче от евентуално неинициализирани стойности.За разлика от [`as_ref`], това не изисква стойността да се инициализира.
    ///
    /// За променящия се аналог вижте [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Когато извиквате този метод, трябва да се уверите, че всички от следните са верни:
    ///
    /// * Указателят трябва да е [valid] за четене за много байтове `ptr.len() * mem::size_of::<T>()` и трябва да бъде правилно подравнен.Това означава по-специално:
    ///
    ///     * Целият обхват на паметта на този отрязък трябва да се съдържа в един разпределен обект!
    ///       Резените никога не могат да обхващат множество разпределени обекти.
    ///
    ///     * Показалецът трябва да бъде подравнен дори за срезове с нулева дължина.
    ///     Една от причините за това е, че оптимизацията на изброяване на оформлението може да разчита на препратки (включително срезове с всякаква дължина), които са подравнени и не са нулеви, за да ги различи от другите данни.
    ///
    ///     Можете да получите указател, който може да се използва като `data` за срезове с нулева дължина, като използвате [`NonNull::dangling()`].
    ///
    /// * Общият размер `ptr.len() * mem::size_of::<T>()` на среза не трябва да бъде по-голям от `isize::MAX`.
    ///   Вижте документацията за безопасност на [`pointer::offset`].
    ///
    /// * Трябва да приложите правилата за псевдоними на Rust, тъй като върнатият живот `'a` е произволно избран и не отразява непременно действителния живот на данните.
    ///   По-специално, по време на този живот паметта, към която сочи указателят, не трябва да мутира (освен в `UnsafeCell`).
    ///
    /// Това важи дори ако резултатът от този метод е неизползван!
    ///
    /// Вижте също [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // БЕЗОПАСНОСТ: повикващият трябва да спазва договора за безопасност за `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Връща уникална препратка към фрагмент от евентуално неинициализирани стойности.За разлика от [`as_mut`], това не изисква стойността да се инициализира.
    ///
    /// За споделения аналог вижте [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Когато извиквате този метод, трябва да се уверите, че всички от следните са верни:
    ///
    /// * Показалецът трябва да е [valid] за четене и запис за `ptr.len() * mem::size_of::<T>()` много байтове и трябва да бъде правилно подравнен.Това означава по-специално:
    ///
    ///     * Целият обхват на паметта на този отрязък трябва да се съдържа в един разпределен обект!
    ///       Резените никога не могат да обхващат множество разпределени обекти.
    ///
    ///     * Показалецът трябва да бъде подравнен дори за срезове с нулева дължина.
    ///     Една от причините за това е, че оптимизацията на изброяване на оформлението може да разчита на препратки (включително срезове с всякаква дължина), които са подравнени и не са нулеви, за да ги различи от другите данни.
    ///
    ///     Можете да получите указател, който може да се използва като `data` за срезове с нулева дължина, като използвате [`NonNull::dangling()`].
    ///
    /// * Общият размер `ptr.len() * mem::size_of::<T>()` на среза не трябва да бъде по-голям от `isize::MAX`.
    ///   Вижте документацията за безопасност на [`pointer::offset`].
    ///
    /// * Трябва да приложите правилата за псевдоними на Rust, тъй като върнатият живот `'a` е произволно избран и не отразява непременно действителния живот на данните.
    ///   По-специално, за продължителността на този живот паметта, към която сочи указателят, не трябва да бъде достъпвана (четена или записвана) чрез друг указател.
    ///
    /// Това важи дори ако резултатът от този метод е неизползван!
    ///
    /// Вижте също [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Това е безопасно, тъй като `memory` е валиден за четене и запис за `memory.len()` много байтове.
    /// // Имайте предвид, че извикването на `memory.as_mut()` тук не е разрешено, тъй като съдържанието може да е неинициализирано.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // БЕЗОПАСНОСТ: повикващият трябва да спазва договора за безопасност за `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Връща суров указател към елемент или подрезан, без да прави проверка на границите.
    ///
    /// Извикването на този метод с индекс извън границите или когато `self` не може да се дереферентира е *[неопределено поведение]*, дори полученият указател да не се използва.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // БЕЗОПАСНОСТ: повикващият гарантира, че `self` е нереференцируем и `index` в границите.
        // В резултат на това полученият указател не може да бъде NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // БЕЗОПАСНОСТ: Уникалният указател не може да бъде нулев, така че условията за
        // new_unchecked() са уважавани.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // БЕЗОПАСНОСТ: Изменяемата препратка не може да бъде нула.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // БЕЗОПАСНОСТ: Препратката не може да бъде нула, така че условията за
        // new_unchecked() са уважавани.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}