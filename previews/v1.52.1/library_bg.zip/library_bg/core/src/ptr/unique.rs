use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Опаковка около суров ненулеви `*mut T`, който показва, че притежателят на тази обвивка притежава референта.
/// Полезно за изграждане на абстракции като `Box<T>`, `Vec<T>`, `String` и `HashMap<K, V>`.
///
/// За разлика от `*mut T`, `Unique<T>` се държи "as if", това е екземпляр на `T`.
/// Той изпълнява `Send`/`Sync`, ако `T` е `Send`/`Sync`.
/// Това също така предполага вида на силни псевдоними, които един екземпляр на `T` може да очаква:
/// референтът на указателя не трябва да бъде модифициран без уникален път към притежаващия го Unique.
///
/// Ако не сте сигурни дали е правилно да използвате `Unique` за вашите цели, помислете дали да не използвате `NonNull`, който има по-слаба семантика.
///
///
/// За разлика от `*mut T`, показалецът винаги трябва да е ненулен, дори ако указателят никога не е дереферендиран.
/// Това е така, че преброяванията могат да използват тази забранена стойност като дискриминант-`Option<Unique<T>>` има същия размер като `Unique<T>`.
/// Въпреки това показалецът все още може да се мотае, ако не е дереферендиран.
///
/// За разлика от `*mut T`, `Unique<T>` е ковариантна спрямо `T`.
/// Това винаги трябва да е правилно за всеки тип, който спазва псевдонимите на Unique.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: този маркер няма последици за отклонението, но е необходим
    // за dropck да разбере, че логично притежаваме `T`.
    //
    // За подробности вижте:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` указателите са `Send`, ако `T` е `Send`, тъй като данните, към които се позовават, са без псевдоним.
/// Обърнете внимание, че този псевдоним инвариант не се налага от системата на типа;абстракцията, използваща `Unique`, трябва да я наложи.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` указателите са `Sync`, ако `T` е `Sync`, тъй като данните, към които се позовават, са неподписани.
/// Обърнете внимание, че този псевдоним инвариант не се налага от системата на типа;абстракцията, използваща `Unique`, трябва да я наложи.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Създава нов `Unique`, който е висящ, но добре подравнен.
    ///
    /// Това е полезно за инициализиране на типове, които лениво разпределят, както прави `Vec::new`.
    ///
    /// Имайте предвид, че стойността на показалеца може потенциално да представлява валиден указател към `T`, което означава, че това не трябва да се използва като контролна стойност "not yet initialized".
    /// Типовете, които лениво разпределят, трябва да проследяват инициализацията по някакъв друг начин.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // БЕЗОПАСНОСТ: mem::align_of() връща валиден, ненулеви указател.The
        // По този начин се спазват условията за извикване на new_unchecked().
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Създава нов `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` трябва да е не-null.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // БЕЗОПАСНОСТ: повикващият трябва да гарантира, че `ptr` не е нулев.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Създава нов `Unique`, ако `ptr` не е нулев.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // БЕЗОПАСНОСТ: Указателят вече е проверен и не е нулев.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Придобива основния указател `*mut`.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Dereferences съдържанието.
    ///
    /// Полученият живот е обвързан със себе си, така че това се държи "as if", всъщност е екземпляр от T, който се заема.
    /// Ако е необходим по-дълъг живот на (unbound), използвайте `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // БЕЗОПАСНОСТ: повикващият трябва да гарантира, че `self` отговаря на всички
        // изисквания за справка.
        unsafe { &*self.as_ptr() }
    }

    /// Пренасочва съдържанието със заменяне.
    ///
    /// Полученият живот е обвързан със себе си, така че това се държи "as if", всъщност е екземпляр от T, който се заема.
    /// Ако е необходим по-дълъг живот на (unbound), използвайте `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // БЕЗОПАСНОСТ: повикващият трябва да гарантира, че `self` отговаря на всички
        // изисквания за променлива референция.
        unsafe { &mut *self.as_ptr() }
    }

    /// Предава към указател от друг тип.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // БЕЗОПАСНОСТ: Unique::new_unchecked() създава нов уникал и нужди
        // даден указател да не е нула.
        // Тъй като предаваме self като указател, той не може да бъде нулев.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // БЕЗОПАСНОСТ: Изменяемата препратка не може да бъде нула
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}