#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Разширява се до `$crate::panic::panic_2015` или `$crate::panic::panic_2021` в зависимост от изданието на повикващия.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Твърди, че два израза са равни помежду си (използвайки [`PartialEq`]).
///
/// На panic този макрос ще отпечата стойностите на изразите с техните представяния за отстраняване на грешки.
///
///
/// Подобно на [`assert!`], този макрос има втора форма, където може да се предостави персонализирано съобщение panic.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Презаредите отдолу са умишлени.
                    // Без тях слотът за стека за заема се инициализира дори преди сравнението на стойностите, което води до забележимо забавяне.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Презаредите отдолу са умишлени.
                    // Без тях слотът за стека за заема се инициализира дори преди сравнението на стойностите, което води до забележимо забавяне.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Твърди, че два израза не са равни помежду си (използвайки [`PartialEq`]).
///
/// На panic този макрос ще отпечата стойностите на изразите с техните представяния за отстраняване на грешки.
///
///
/// Подобно на [`assert!`], този макрос има втора форма, където може да се предостави персонализирано съобщение panic.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Презаредите отдолу са умишлени.
                    // Без тях слотът за стека за заема се инициализира дори преди сравнението на стойностите, което води до забележимо забавяне.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Презаредите отдолу са умишлени.
                    // Без тях слотът за стека за заема се инициализира дори преди сравнението на стойностите, което води до забележимо забавяне.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Твърди, че булев израз е `true` по време на изпълнение.
///
/// Това ще извика макроса [`panic!`], ако предоставеният израз не може да бъде оценен на `true` по време на изпълнение.
///
/// Подобно на [`assert!`], този макрос има и втора версия, където може да се предостави персонализирано съобщение panic.
///
/// # Uses
///
/// За разлика от [`assert!`], операторите `debug_assert!` са разрешени само в неоптимизирани компилации по подразбиране.
/// Оптимизираната компилация няма да изпълнява оператори `debug_assert!`, освен ако `-C debug-assertions` не бъде предаден на компилатора.
/// Това прави `debug_assert!` полезен за проверки, които са твърде скъпи, за да присъстват в компилация на издание, но може да са полезни по време на разработката.
/// Резултатът от разширяването на `debug_assert!` винаги е проверен тип.
///
/// Непровереното твърдение позволява на програма в непоследователно състояние да продължи да работи, което може да има неочаквани последици, но не създава несигурност, стига това да се случва само в безопасен код.
///
/// Цената на ефективността на твърденията обаче не е измерима като цяло.
/// По този начин замяната на [`assert!`] с `debug_assert!` се насърчава само след задълбочено профилиране и по-важното само в безопасен код!
///
/// # Examples
///
/// ```
/// // съобщението panic за тези твърдения е стрифифицираната стойност на дадения израз.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // много проста функция
/// debug_assert!(some_expensive_computation());
///
/// // твърди с персонализирано съобщение
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Твърди, че два израза са равни помежду си.
///
/// На panic този макрос ще отпечата стойностите на изразите с техните представяния за отстраняване на грешки.
///
/// За разлика от [`assert_eq!`], операторите `debug_assert_eq!` са разрешени само в неоптимизирани компилации по подразбиране.
/// Оптимизираната компилация няма да изпълнява оператори `debug_assert_eq!`, освен ако `-C debug-assertions` не бъде предаден на компилатора.
/// Това прави `debug_assert_eq!` полезен за проверки, които са твърде скъпи, за да присъстват в компилация на издание, но може да са полезни по време на разработката.
///
/// Резултатът от разширяването на `debug_assert_eq!` винаги е проверен тип.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Твърди, че два израза не са равни помежду си.
///
/// На panic този макрос ще отпечата стойностите на изразите с техните представяния за отстраняване на грешки.
///
/// За разлика от [`assert_ne!`], операторите `debug_assert_ne!` са разрешени само в неоптимизирани компилации по подразбиране.
/// Оптимизираната компилация няма да изпълнява оператори `debug_assert_ne!`, освен ако `-C debug-assertions` не бъде предаден на компилатора.
/// Това прави `debug_assert_ne!` полезен за проверки, които са твърде скъпи, за да присъстват в компилация на издание, но може да са полезни по време на разработката.
///
/// Резултатът от разширяването на `debug_assert_ne!` винаги е проверен тип.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Връща дали даденият израз съвпада с някой от дадените модели.
///
/// Подобно на израз в `match`, по избор шаблонът може да бъде последван от `if` и израз на защита, който има достъп до имена, обвързани от шаблона.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Разгъва резултат или разпространява неговата грешка.
///
/// Операторът `?` е добавен да замени `try!` и трябва да се използва вместо него.
/// Освен това `try` е запазена дума в Rust 2018, така че ако трябва да я използвате, ще трябва да използвате [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` съответства на дадения [`Result`].В случая с варианта `Ok`, изразът има стойността на опакованата стойност.
///
/// В случай на вариант `Err`, той извлича вътрешната грешка.След това `try!` извършва преобразуване с помощта на `From`.
/// Това осигурява автоматично преобразуване между специализирани грешки и по-общи.
/// След това получената грешка веднага се връща.
///
/// Поради ранното връщане, `try!` може да се използва само във функции, които връщат [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Предпочитаният метод за бързо връщане на грешки
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Предишният метод за бързо връщане на грешки
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Това е еквивалентно на:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Записва форматирани данни в буфер.
///
/// Този макрос приема 'writer', низ за формат и списък с аргументи.
/// Аргументите ще бъдат форматирани според указания низ за форматиране и резултатът ще бъде предаден на писателя.
/// Записващото устройство може да има всякаква стойност с метод `write_fmt`;обикновено това идва от изпълнение на [`fmt::Write`] или [`io::Write`] Portrait.
/// Макросът връща каквото връща методът `write_fmt`;обикновено [`fmt::Result`] или [`io::Result`].
///
/// Вижте [`std::fmt`] за повече информация относно синтаксиса на форматиращия низ.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Модулът може да импортира както `std::fmt::Write`, така и `std::io::Write` и да извиква `write!` за обекти, изпълняващи и двете, тъй като обектите обикновено не изпълняват и двете.
///
/// Модулът обаче трябва да импортира квалифицирания traits, така че имената им да не противоречат:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // използва fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // използва io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Този макрос може да се използва и в `no_std` настройки.
/// При настройка на `no_std` вие отговаряте за подробностите за изпълнението на компонентите.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Запишете форматирани данни в буфер с добавен нов ред.
///
/// На всички платформи новата линия е само символът LINE FEED (`\n`/`U+000A`) (без допълнително ВРЪЩАНЕ НА КАРИГА (`\r`/`U+000D`).
///
/// За повече информация вижте [`write!`].За информация относно синтаксиса на форматиращия низ вижте [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Модулът може да импортира както `std::fmt::Write`, така и `std::io::Write` и да извиква `write!` за обекти, изпълняващи и двете, тъй като обектите обикновено не изпълняват и двете.
/// Модулът обаче трябва да импортира квалифицирания traits, така че имената им да не противоречат:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // използва fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // използва io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Показва недостижим код.
///
/// Това е полезно всеки път, когато компилаторът не може да определи, че някакъв код е недостъпен.Например:
///
/// * Съчетайте ръцете с условията на пазача.
/// * Цикли, които се прекратяват динамично.
/// * Итератори, които се прекратяват динамично.
///
/// Ако определението, че кодът е недостъпен, се окаже неправилно, програмата незабавно прекратява с [`panic!`].
///
/// Несигурният аналог на този макрос е функцията [`unreachable_unchecked`], която ще причини недефинирано поведение, ако кодът бъде достигнат.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Това винаги ще е [`panic!`].
///
/// # Examples
///
/// Мач ръце:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // грешка при компилиране, ако се коментира
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // една от най-бедните реализации на x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Показва неизпълнен код чрез паника със съобщение на "not implemented".
///
/// Това позволява на вашия код да проверява типа, което е полезно, ако прототипирате или внедрявате Portrait, който изисква множество методи, които не планирате да използвате всички.
///
/// Разликата между `unimplemented!` и [`todo!`] е, че докато `todo!` предава намерение за внедряване на функционалността по-късно и съобщението е "not yet implemented", `unimplemented!` не прави такива твърдения.
/// Съобщението му е "not implemented".
/// Също така някои IDE ще маркират `todo!` S.
///
/// # Panics
///
/// Това винаги ще бъде [`panic!`], защото `unimplemented!` е просто стенография за `panic!` с фиксирано, конкретно съобщение.
///
/// Подобно на `panic!`, този макрос има втора форма за показване на персонализирани стойности.
///
/// # Examples
///
/// Да речем, че имаме Portrait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Искаме да внедрим `Foo` за 'MyStruct', но по някаква причина има смисъл само да внедрим функцията `bar()`.
/// `baz()` и `qux()` все още ще трябва да бъде дефиниран в нашата реализация на `Foo`, но можем да използваме `unimplemented!` в техните дефиниции, за да позволим на нашия код да се компилира.
///
/// Все още искаме нашата програма да спре да работи, ако се достигнат неприложени методи.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Няма смисъл `baz` да е `MyStruct`, така че изобщо нямаме логика.
/////
///         // Това ще покаже "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Тук имаме някаква логика, можем да добавим съобщение към нереализираното!за да покажем нашия пропуск.
///         // Това ще покаже: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Показва незавършен код.
///
/// Това може да бъде полезно, ако правите прототипи и просто искате да проверите типа на кода си.
///
/// Разликата между [`unimplemented!`] и `todo!` е, че докато `todo!` предава намерение за внедряване на функционалността по-късно и съобщението е "not yet implemented", `unimplemented!` не прави такива твърдения.
/// Съобщението му е "not implemented".
/// Също така някои IDE ще маркират `todo!` S.
///
/// # Panics
///
/// Това винаги ще е [`panic!`].
///
/// # Examples
///
/// Ето пример за някои текущи кодове.Имаме Portrait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Искаме да внедрим `Foo` върху един от нашите типове, но също така искаме първо да работим само с `bar()`.За да може нашият код да се компилира, трябва да внедрим `baz()`, за да можем да използваме `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // изпълнението върви тук
///     }
///
///     fn baz(&self) {
///         // нека не се притесняваме за внедряването на baz() засега
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // дори не използваме baz(), така че това е добре.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Дефиниции на вградени макроси.
///
/// Повечето от свойствата на макросите (стабилност, видимост и т.н.) са взети от изходния код тук, с изключение на функциите за разширение, които трансформират макро входовете в изходи, тези функции се предоставят от компилатора.
///
///
pub(crate) mod builtin {

    /// Причинява компилация да се провали с даденото съобщение за грешка при среща.
    ///
    /// Този макрос трябва да се използва, когато crate използва условна стратегия за компилация, за да предостави по-добри съобщения за грешки при грешни условия.
    ///
    /// Това е формата на ниво компилатор на [`panic!`], но издава грешка по време на *компилация*, а не по време на изпълнение *.
    ///
    /// # Examples
    ///
    /// Два такива примера са макроси и `#[cfg]` среди.
    ///
    /// Излъчва по-добра грешка на компилатора, ако на макрос се предават невалидни стойности
    /// Без окончателния branch компилаторът пак ще издава грешка, но в съобщението за грешка няма да се споменават двете валидни стойности.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Изпуснете грешка на компилатора, ако една от редица функции не е налична.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Конструира параметри за другите макроси за форматиране на низове.
    ///
    /// Този макрос функционира, като приема форматиращ низ литерал, съдържащ `{}` за всеки допълнителен подаден аргумент.
    /// `format_args!` подготвя допълнителните параметри, за да гарантира, че изходът може да бъде интерпретиран като низ и канонизира аргументите в един тип.
    /// Всяка стойност, която реализира [`Display`] Portrait, може да бъде предадена на `format_args!`, както и всяка реализация на [`Debug`] да бъде предадена на `{:?}` в рамките на форматиращия низ.
    ///
    ///
    /// Този макрос генерира стойност от тип [`fmt::Arguments`].Тази стойност може да бъде предадена на макросите в [`std::fmt`] за извършване на полезно пренасочване.
    /// Всички други макроси за форматиране ([" формат!`], [`write!`], [`println!`] и т.н.) се проксират чрез този.
    /// `format_args!`, за разлика от получените макроси, избягва разпределянето на купчина.
    ///
    /// Можете да използвате стойността [`fmt::Arguments`], която `format_args!` връща в контексти `Debug` и `Display`, както е показано по-долу.
    /// Примерът също така показва, че `Debug` и `Display` форматират едно и също нещо: интерполираният низ в `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// За повече информация вижте документацията в [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Същото като `format_args`, но накрая добавя нов ред.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Проверява променлива на средата по време на компилиране.
    ///
    /// Този макрос ще се разшири до стойността на посочената променлива на средата по време на компилиране, като ще даде израз от тип `&'static str`.
    ///
    ///
    /// Ако променливата на средата не е дефинирана, ще се изведе грешка при компилацията.
    /// За да не издавате грешка при компилиране, вместо това използвайте макроса [`option_env!`].
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Можете да персонализирате съобщението за грешка, като предадете низ като втори параметър:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Ако променливата на средата `documentation` не е дефинирана, ще получите следната грешка:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// По желание проверява променлива на средата по време на компилиране.
    ///
    /// Ако посочената променлива на средата присъства по време на компилация, това ще се разшири в израз от тип `Option<&'static str>`, чиято стойност е `Some` на стойността на променливата на средата.
    /// Ако променливата на средата не присъства, това ще се разшири до `None`.
    /// Вижте [`Option<T>`][Option] за повече информация за този тип.
    ///
    /// Грешка във времето на компилация никога не се излъчва при използване на този макрос, независимо дали променливата на средата присъства или не.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Обединява идентификаторите в един идентификатор.
    ///
    /// Този макрос взема произволен брой идентификатори, разделени със запетая, и ги обединява в един, като дава израз, който е нов идентификатор.
    /// Имайте предвид, че хигиената го прави такъв, че този макрос да не може да улови локални променливи.
    /// Освен това, като общо правило, макросите са разрешени само в позиция, израз или позиция на израз.
    /// Това означава, че докато можете да използвате този макрос за препращане към съществуващи променливи, функции или модули и т.н., не можете да дефинирате нов с него.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (ново, забавно, име) { }//не се използва по този начин!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Обединява литералите в статичен низ.
    ///
    /// Този макрос приема произволен брой литерали, разделени със запетая, като дава израз от тип `&'static str`, който представлява всички литерали, обединени отляво надясно.
    ///
    ///
    /// Целочислените и плаващите запетаи са литерални, за да бъдат обединени.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Разширява се до номера на реда, на който е бил извикан.
    ///
    /// С [`column!`] и [`file!`] тези макроси предоставят информация за отстраняване на грешки на разработчиците относно местоположението в източника.
    ///
    /// Разширеният израз има тип `u32` и е базиран на 1, така че първият ред във всеки файл се оценява на 1, вторият на 2 и т.н.
    /// Това е в съответствие със съобщенията за грешки от обичайните компилатори или популярни редактори.
    /// Върнатият ред *не е задължително* редът на самото извикване на `line!`, а по-скоро първото извикване на макрос, водещо до извикването на макроса `line!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Разширява се до номера на колоната, при който е била извикана.
    ///
    /// С [`line!`] и [`file!`] тези макроси предоставят информация за отстраняване на грешки на разработчиците относно местоположението в източника.
    ///
    /// Разширеният израз има тип `u32` и е базиран на 1, така че първата колона във всеки ред се оценява на 1, втората на 2 и т.н.
    /// Това е в съответствие със съобщенията за грешки от обичайните компилатори или популярни редактори.
    /// Върнатата колона е *не е задължително* редът на самото извикване на `column!`, а по-скоро първото извикване на макрос, водещо до извикването на макроса `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Разширява се до името на файла, в който е бил извикан.
    ///
    /// С [`line!`] и [`column!`] тези макроси предоставят информация за отстраняване на грешки на разработчиците относно местоположението в източника.
    ///
    /// Разширеният израз има тип `&'static str` и върнатият файл не е извикването на самия макрос `file!`, а по-скоро първото извикване на макрос, водещо до извикването на макроса `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Стрингира своите аргументи.
    ///
    /// Този макрос ще даде израз от тип `&'static str`, който е стринификацията на всички tokens, предадени на макроса.
    /// Не са поставени ограничения върху синтаксиса на самото извикване на макрос.
    ///
    /// Имайте предвид, че разширените резултати на входните tokens могат да се променят в future.Трябва да внимавате, ако разчитате на резултата.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Включва кодиран файл UTF-8 като низ.
    ///
    /// Файлът се намира спрямо текущия файл (подобно на начина, по който се намират модулите).
    /// Предоставеният път се интерпретира по специфичен за платформата начин по време на компилиране.
    /// Така например, извикване с път Windows, съдържащ обратни наклонени черти `\`, няма да се компилира правилно на Unix.
    ///
    ///
    /// Този макрос ще даде израз от тип `&'static str`, който е съдържанието на файла.
    ///
    /// # Examples
    ///
    /// Да приемем, че в една и съща директория има два файла със следното съдържание:
    ///
    /// Файл 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Файл 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Компилирането на 'main.rs' и стартирането на получения двоичен файл ще отпечата "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Включва файл като препратка към байтов масив.
    ///
    /// Файлът се намира спрямо текущия файл (подобно на начина, по който се намират модулите).
    /// Предоставеният път се интерпретира по специфичен за платформата начин по време на компилиране.
    /// Така например, извикване с път Windows, съдържащ обратни наклонени черти `\`, няма да се компилира правилно на Unix.
    ///
    ///
    /// Този макрос ще даде израз от тип `&'static [u8; N]`, който е съдържанието на файла.
    ///
    /// # Examples
    ///
    /// Да приемем, че в една и съща директория има два файла със следното съдържание:
    ///
    /// Файл 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Файл 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Компилирането на 'main.rs' и стартирането на получения двоичен файл ще отпечата "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Разширява се до низ, който представлява текущия път на модула.
    ///
    /// Текущият път на модула може да се разглежда като йерархията на модулите, водещи обратно до crate root.
    /// Първият компонент на върнатия път е името на crate, който се компилира в момента.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Оценява булеви комбинации от конфигурационни знамена по време на компилация.
    ///
    /// В допълнение към атрибута `#[cfg]`, този макрос се предоставя, за да позволи булево оценяване на изрази на конфигурационни знамена.
    /// Това често води до по-малко дублиран код.
    ///
    /// Синтаксисът, даден на този макрос, е същият синтаксис като атрибута [`cfg`].
    ///
    /// `cfg!`, за разлика от `#[cfg]`, не премахва никакъв код и оценява само на true или false.
    /// Например всички блокове в if/else израз трябва да са валидни, когато `cfg!` се използва за условието, независимо от това, което `cfg!` оценява.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Анализира файл като израз или елемент според контекста.
    ///
    /// Файлът се намира спрямо текущия файл (подобно на начина, по който се намират модулите).Предоставеният път се интерпретира по специфичен за платформата начин по време на компилиране.
    /// Така например, извикване с път Windows, съдържащ обратни наклонени черти `\`, няма да се компилира правилно на Unix.
    ///
    /// Използването на този макрос често е лоша идея, защото ако файлът се анализира като израз, той ще бъде поставен в околния код нехигиенично.
    /// Това може да доведе до променливи или функции, различни от това, което файлът очаква, ако има променливи или функции, които имат същото име в текущия файл.
    ///
    ///
    /// # Examples
    ///
    /// Да приемем, че в една и съща директория има два файла със следното съдържание:
    ///
    /// Файл 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Файл 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Компилирането на 'main.rs' и стартирането на получения двоичен файл ще отпечата "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Твърди, че булев израз е `true` по време на изпълнение.
    ///
    /// Това ще извика макроса [`panic!`], ако предоставеният израз не може да бъде оценен на `true` по време на изпълнение.
    ///
    /// # Uses
    ///
    /// Твърденията винаги се проверяват както при компилации за отстраняване на грешки, така и при издаване и не могат да бъдат деактивирани.
    /// Вижте [`debug_assert!`] за твърдения, които по подразбиране не са активирани в компилации на издания.
    ///
    /// Небезопасният код може да разчита на `assert!` за налагане на инварианти по време на изпълнение, които, ако бъдат нарушени, могат да доведат до несигурност.
    ///
    /// Други случаи на използване на `assert!` включват тестване и налагане на инварианти на времето за изпълнение в безопасен код (чието нарушение не може да доведе до несигурност).
    ///
    ///
    /// # Персонализирани съобщения
    ///
    /// Този макрос има втора форма, където персонализирано съобщение panic може да бъде предоставено със или без аргументи за форматиране.
    /// Вижте [`std::fmt`] за синтаксис на тази форма.
    /// Изразите, използвани като аргументи във формат, ще бъдат оценени само ако твърдението е неуспешно.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // съобщението panic за тези твърдения е стрифифицираната стойност на дадения израз.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // много проста функция
    ///
    /// assert!(some_computation());
    ///
    /// // твърди с персонализирано съобщение
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Вграден монтаж.
    ///
    /// Прочетете [unstable book] за употребата.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Вграден монтаж в стил LLVM.
    ///
    /// Прочетете [unstable book] за употребата.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Вграден модул на ниво модул.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Отпечатъците предадоха tokens в стандартния изход.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Активира или деактивира функционалността за проследяване, използвана за отстраняване на грешки на други макроси.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Атрибут макрос, използван за прилагане на производни макроси.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Атрибут макрос, приложен към функция, за да я превърне в единичен тест.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Атрибут макрос, приложен към функция, за да я превърне в бенчмарк тест.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Подробности за изпълнението на макросите `#[test]` и `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Атрибут макрос, приложен към статичен, за да го регистрира като глобален разпределител.
    ///
    /// Вижте също [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Запазва елемента, към който е приложен, ако преминатият път е достъпен, и го премахва в противен случай.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Разширява всички атрибути `#[cfg]` и `#[cfg_attr]` във фрагмента на кода, към който е приложен.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Нестабилни подробности за изпълнението на компилатора `rustc`, не използвайте.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Нестабилни подробности за изпълнението на компилатора `rustc`, не използвайте.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}