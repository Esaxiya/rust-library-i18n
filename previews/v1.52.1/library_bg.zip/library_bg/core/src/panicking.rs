//! Panic поддръжка за libcore
//!
//! Основната библиотека не може да дефинира паника, но *декларира* паника.
//! Това означава, че функциите вътре в libcore са разрешени на panic, но за да бъде полезно, нагоре по веригата crate трябва да дефинира паника за използване на libcore.
//! Текущият интерфейс за паника е:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Тази дефиниция позволява да се паникьосва с всяко общо съобщение, но не позволява да се провали със стойност `Box<Any>`.
//! (`PanicInfo` просто съдържа `&(dyn Any + Send)`, за който попълваме фиктивна стойност в `PanicInfo: : internal_constructor`.) Причината за това е, че libcore няма право да разпределя.
//!
//!
//! Този модул съдържа няколко други панически функции, но това са само необходимите езикови елементи за компилатора.Всички panics се пренасят през тази една функция.
//! Действителният символ се декларира чрез атрибута `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Основната реализация на макроса `panic!` на libcore, когато не се използва форматиране.
#[cold]
// никога вградени, освен ако panic_immediate_abort, за да се избегне подуване на кода на сайтовете за повикване, доколкото е възможно
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // необходим на codegen за panic при преливане и други `Assert` MIR терминатори
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Използвайте Arguments::new_v1 вместо format_args! ("{}", Expr), за да намалите потенциално режийните разходи.
    // Форматът_арг!macro използва дисплея на Portrait на str, за да напише израз, който извиква Formatter::pad, който трябва да побере съкращаване на низове и запълване (въпреки че тук не се използва нито едно).
    //
    // Използването на Arguments::new_v1 може да позволи на компилатора да пропусне Formatter::pad от изходния двоичен файл, спестявайки до няколко килобайта.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // необходим за оценена по const panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // необходим на codegen за panic при OOB array/slice достъп
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Основното изпълнение на макроса `panic!` на libcore при форматиране се използва.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // ЗАБЕЛЕЖКА Тази функция никога не преминава границата на FFI;това е повикване Rust-to-Rust, което се разрешава до функцията `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // БЕЗОПАСНОСТ: `panic_impl` е дефиниран в безопасен код Rust и по този начин е безопасно да се обадите.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Вътрешна функция за макроси `assert_eq!` и `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}