//! Това е вътрешен модул, използван от ifmt!време на изпълнение.Тези структури се излъчват в статични масиви за предварително компилиране на форматирани низове преди време.
//!
//! Тези дефиниции са подобни на техните еквиваленти `ct`, но се различават по това, че могат да бъдат разпределени статично и леко оптимизирани за времето на изпълнение
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Възможни подравнения, които могат да бъдат поискани като част от директива за форматиране.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Указание, че съдържанието трябва да бъде подравнено вляво.
    Left,
    /// Указание, че съдържанието трябва да бъде подравнено вдясно.
    Right,
    /// Указание, че съдържанието трябва да бъде подравнено по центъра.
    Center,
    /// Не е поискано подравняване.
    Unknown,
}

/// Използва се от спецификаторите [width](https://doc.rust-lang.org/std/fmt/#width) и [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// Посочено с буквален номер, съхранява стойността
    Is(usize),
    /// Специфициран със синтаксиси `$` и `*`, съхранява индекса в `args`
    Param(usize),
    /// Неопределено
    Implied,
}