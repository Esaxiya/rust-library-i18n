//! Начини за създаване на `str` от байтов фрагмент.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Преобразува парче байтове в низ отрязък.
///
/// Срез от низове ([`&str`]) е направен от байтове ([`u8`]), а отрязък от байтове ([`&[u8]`][byteslice]) е от байтове, така че тази функция преобразува между двете.
/// Не всички байтови срезове са валидни низови срезове, обаче: [`&str`] изисква да е валиден UTF-8.
/// `from_utf8()` проверява дали байтовете са валидни UTF-8 и след това извършва преобразуването.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Ако сте сигурни, че байтовият фрагмент е валиден UTF-8 и не искате да поемате допълнителни разходи за проверката на валидността, има опасна версия на тази функция, [`from_utf8_unchecked`], която има същото поведение, но пропуска проверката.
///
///
/// Ако имате нужда от `String` вместо `&str`, помислете за [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Тъй като можете да разпределите стека `[u8; N]` и можете да вземете [`&[u8]`][byteslice] от него, тази функция е един от начините да има низ, разпределен в стека.Има пример за това в раздела за примери по-долу.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Връща `Err`, ако фрагментът не е UTF-8, с описание защо предоставеният фрагмент не е UTF-8.
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// use std::str;
///
/// // някои байтове, в vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Знаем, че тези байтове са валидни, затова просто използвайте `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Неправилни байтове:
///
/// ```
/// use std::str;
///
/// // някои невалидни байтове в vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Вижте документите за [`Utf8Error`] за повече подробности относно видовете грешки, които могат да бъдат върнати.
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // някои байтове в масив, разпределен в стек
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Знаем, че тези байтове са валидни, затова просто използвайте `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // БЕЗОПАСНОСТ: Току-що проверих проверка.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Преобразува изменяем отрязък от байтове в променлив отрязък от низ.
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" като променлив vector
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Тъй като знаем, че тези байтове са валидни, можем да използваме `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Неправилни байтове:
///
/// ```
/// use std::str;
///
/// // Някои невалидни байтове в променлив vector
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Вижте документите за [`Utf8Error`] за повече подробности относно видовете грешки, които могат да бъдат върнати.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // БЕЗОПАСНОСТ: Току-що проверих проверка.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Преобразува парче байтове в фрагмент от низ, без да проверява дали низът съдържа валиден UTF-8.
///
/// Вижте безопасната версия, [`from_utf8`], за повече информация.
///
/// # Safety
///
/// Тази функция е опасна, тъй като не проверява дали байтовете, подадени към нея, са валидни UTF-8.
/// Ако това ограничение е нарушено, се получава неопределено поведение, тъй като останалата част от Rust приема, че [`&str`] s са валидни UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// use std::str;
///
/// // някои байтове, в vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // БЕЗОПАСНОСТ: повикващият трябва да гарантира, че байтовете `v` са валидни UTF-8.
    // Също така разчита на `&str` и `&[u8]` с еднакво оформление.
    unsafe { mem::transmute(v) }
}

/// Преобразува парче байтове в фрагмент от низ, без да проверява дали низът съдържа валиден UTF-8;променлива версия.
///
///
/// Вижте неизменяемата версия, [`from_utf8_unchecked()`] за повече информация.
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // БЕЗОПАСНОСТ: повикващият трябва да гарантира, че байтовете `v`
    // са валидни UTF-8, така че прехвърлянето към `*mut str` е безопасно.
    // Също така, пренасочването на указателя е безопасно, защото този указател идва от препратка, която е гарантирано валидна за записи.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}