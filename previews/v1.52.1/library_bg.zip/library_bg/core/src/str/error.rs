//! Определя типа грешка utf8.

use crate::fmt;

/// Грешки, които могат да възникнат при опит за интерпретиране на последователност от [`u8`] като низ.
///
/// Като такива, семейството функции и методи на `from_utf8` както за [`String`], така и за [`&str`] използват тази грешка, например.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Методите от този тип грешка могат да се използват за създаване на функционалност, подобна на `String::from_utf8_lossy`, без да се разпределя куп памет:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Връща индекса в дадения низ, до който е проверен валидният UTF-8.
    ///
    /// Това е максималният индекс, който `from_utf8(&input[..index])` би върнал `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::str;
    ///
    /// // някои невалидни байтове в vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 връща Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // вторият байт е невалиден тук
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Предоставя повече информация за повредата:
    ///
    /// * `None`: краят на входа беше достигнат неочаквано.
    ///   `self.valid_up_to()` е 1 до 3 байта от края на входа.
    ///   Ако байтов поток (като файл или мрежов сокет) се декодира постепенно, това може да е валиден `char`, чиято последователност от байтове UTF-8 обхваща множество парчета.
    ///
    ///
    /// * `Some(len)`: бе открит неочакван байт.
    ///   Предоставената дължина е тази на невалидната байтова последователност, която започва от индекса, даден от `valid_up_to()`.
    ///   Декодирането трябва да се възобнови след тази последователност (след вмъкване на [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) в случай на декодиране със загуби.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Грешка, върната при анализ на `bool` с помощта на [`from_str`] не е успешен
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}