//! API на низа Pattern.
//!
//! API Pattern осигурява общ механизъм за използване на различни типове шаблони при търсене през низ.
//!
//! За повече подробности вижте traits [`Pattern`], [`Searcher`], [`ReverseSearcher`] и [`DoubleEndedSearcher`].
//!
//! Въпреки че този API е нестабилен, той се излага чрез стабилни API на типа [`str`].
//!
//! # Examples
//!
//! [`Pattern`] е [implemented][pattern-impls] в стабилния API за [`&str`][`str`], [`char`], резени от [`char`] и функции и затваряния, изпълняващи `FnMut(char) -> bool`.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // шарка модел
//! assert_eq!(s.find('n'), Some(2));
//! // парче шарка модел
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // модел на затваряне
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Низов модел.
///
/// `Pattern<'a>` изразява, че внедряващият тип може да се използва като низ модел за търсене в [`&'a str`][str].
///
/// Например и `'a'`, и `"aa"` са модели, които биха съвпаднали при индекс `1` в низа `"baaaab"`.
///
/// Самият Portrait действа като конструктор за асоцииран тип [`Searcher`], който извършва действителната работа по намиране на появявания на шаблона в низ.
///
///
/// В зависимост от типа на модела, поведението на методи като [`str::find`] и [`str::contains`] може да се промени.
/// Таблицата по-долу описва някои от тези поведения.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Свързан търсач за този модел
    type Searcher: Searcher<'a>;

    /// Конструира свързания търсач от `self` и `haystack` за търсене.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Проверява дали моделът съвпада някъде в купата сено
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Проверява дали моделът съвпада в предната част на купата сено
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Проверява дали моделът съвпада в задната част на купата сено
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Премахва шаблона от предната страна на купа сено, ако съвпада.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // БЕЗОПАСНОСТ: Известно е, че `Searcher` връща валидни индекси.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Премахва шаблона от гърба на купа сено, ако съвпада.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // БЕЗОПАСНОСТ: Известно е, че `Searcher` връща валидни индекси.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// Резултат от извикване на [`Searcher::next()`] или [`ReverseSearcher::next_back()`].
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Изразява, че при `haystack[a..b]` е намерено съвпадение на шаблона.
    ///
    Match(usize, usize),
    /// Изразява, че `haystack[a..b]` е отхвърлен като възможно съвпадение на шаблона.
    ///
    /// Имайте предвид, че може да има повече от един `Reject` между две " Match`es, няма изискване те да бъдат комбинирани в едно.
    ///
    ///
    Reject(usize, usize),
    /// Изразява, че всеки байт от купа сено е бил посетен, като приключва итерацията.
    ///
    Done,
}

/// Търсещ модел на низ.
///
/// Този Portrait предоставя методи за търсене на неприпокриващи се съвпадения на шаблон, започвайки от предната (left) на низ.
///
/// Той ще бъде реализиран от асоциирани `Searcher` типове на [`Pattern`] Portrait.
///
/// Portrait е маркиран като несигурен, тъй като индексите, върнати от методите [`next()`][Searcher::next], трябва да лежат на валидни граници на utf8 в купата сено.
/// Това позволява на потребителите на този Portrait да нарязват купата сено без допълнителни проверки по време на работа.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter за основния низ, в който ще се търси
    ///
    /// Винаги ще връща същия [`&str`][str].
    fn haystack(&self) -> &'a str;

    /// Извършва следващата стъпка на търсене, започвайки отпред.
    ///
    /// - Връща [`Match(a, b)`][SearchStep::Match], ако `haystack[a..b]` съвпада с модела.
    /// - Връща [`Reject(a, b)`][SearchStep::Reject], ако `haystack[a..b]` не може да съответства на модела, дори частично.
    /// - Връща [`Done`][SearchStep::Done], ако е бил посетен всеки байт от купа сено.
    ///
    /// Потокът от стойности на [`Match`][SearchStep::Match] и [`Reject`][SearchStep::Reject] до [`Done`][SearchStep::Done] ще съдържа диапазони на индекси, които са в съседство, не се припокриват, обхващат целия купа сено и полагат на границите на utf8.
    ///
    ///
    /// Резултатът от [`Match`][SearchStep::Match] трябва да съдържа целия съвпадащ модел, но резултатите от [`Reject`][SearchStep::Reject] може да бъдат разделени на произволни много съседни фрагменти.И двата диапазона могат да имат нулева дължина.
    ///
    /// Като пример, моделът `"aaa"` и купата сено `"cbaaaaab"` може да генерират потока
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Намира следващия резултат [`Match`][SearchStep::Match].Вижте [`next()`][Searcher::next].
    ///
    /// За разлика от [`next()`][Searcher::next], няма гаранция, че върнатите диапазони на това и [`next_reject`][Searcher::next_reject] ще се припокриват.
    /// Това ще върне `(start_match, end_match)`, където start_match е индексът на мястото, където започва съвпадението, а end_match е индексът след края на мача.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Намира следващия резултат [`Reject`][SearchStep::Reject].Вижте [`next()`][Searcher::next] и [`next_match()`][Searcher::next_match].
    ///
    /// За разлика от [`next()`][Searcher::next], няма гаранция, че върнатите диапазони на това и [`next_match`][Searcher::next_match] ще се припокриват.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Обратно търсене на низ модел.
///
/// Този Portrait предоставя методи за търсене на неприпокриващи се съвпадения на шаблон, започвайки от задния (right) на низ.
///
/// Той ще бъде реализиран от асоциирани [`Searcher`] типове на [`Pattern`] Portrait, ако моделът поддържа търсене отзад.
///
///
/// Диапазоните на индексите, върнати от този Portrait, не се изискват да съвпадат точно с тези на търсенето напред в обратен ред.
///
/// Поради причината, поради която този Portrait е означен като опасен, вижте ги родителски Portrait [`Searcher`].
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Извършва следващата стъпка на търсене, започвайки отзад.
    ///
    /// - Връща [`Match(a, b)`][SearchStep::Match], ако `haystack[a..b]` съвпада с модела.
    /// - Връща [`Reject(a, b)`][SearchStep::Reject], ако `haystack[a..b]` не може да съответства на модела, дори частично.
    /// - Връща [`Done`][SearchStep::Done], ако е бил посетен всеки байт от купа сено
    ///
    /// Потокът от стойности на [`Match`][SearchStep::Match] и [`Reject`][SearchStep::Reject] до [`Done`][SearchStep::Done] ще съдържа диапазони на индекси, които са в съседство, не се припокриват, обхващат целия купа сено и полагат на границите на utf8.
    ///
    ///
    /// Резултатът от [`Match`][SearchStep::Match] трябва да съдържа целия съвпадащ модел, но резултатите от [`Reject`][SearchStep::Reject] може да бъдат разделени на произволни много съседни фрагменти.И двата диапазона могат да имат нулева дължина.
    ///
    /// Като пример, моделът `"aaa"` и купата сено `"cbaaaaab"` може да генерират потока `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Намира следващия резултат на [`Match`][SearchStep::Match].
    /// Вижте [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Намира следващия резултат на [`Reject`][SearchStep::Reject].
    /// Вижте [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Маркер Portrait, за да изрази, че [`ReverseSearcher`] може да се използва за изпълнение на [`DoubleEndedIterator`].
///
/// За това impl на [`Searcher`] и [`ReverseSearcher`] трябва да спазват следните условия:
///
/// - Всички резултати от `next()` трябва да бъдат идентични с резултатите от `next_back()` в обратен ред.
/// - `next()` и `next_back()` трябва да се държат като двата края на диапазон от стойности, тоест те не могат да "walk past each other".
///
/// # Examples
///
/// `char::Searcher` е `DoubleEndedSearcher`, тъй като търсенето на [`char`] изисква само гледане един по един, който се държи еднакво от двата края.
///
/// `(&str)::Searcher` не е `DoubleEndedSearcher`, защото моделът `"aa"` в купата сено `"aaa"` съвпада или като `"[aa]a"`, или като `"a[aa]"`, в зависимост от коя страна се търси.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Impl за char
/////////////////////////////////////////////////////////////////////////////

/// Свързан тип за `<char as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // инвариант на безопасността: `finger`/`finger_back` трябва да е валиден индекс на байта на utf8 на `haystack`. Този инвариант може да бъде счупен *в рамките на* next_match и next_match_back, но те трябва да излязат с пръсти на валидни граници на кодовата точка.
    //
    //
    /// `finger` е текущият индекс на байта на търсенето напред.
    /// Представете си, че той съществува преди байта по своя индекс, т.е.
    /// `haystack[finger]` е първият байт от среза, който трябва да проверим по време на търсене напред
    ///
    finger: usize,
    /// `finger_back` е текущият индекс на байта на обратното търсене.
    /// Представете си, че той съществува след байта в неговия индекс, т.е.
    /// haystack [finger_back, 1] е последният байт от среза, който трябва да проверим по време на търсене напред (и по този начин първият байт, който трябва да бъде проверен при извикване на next_back()).
    ///
    finger_back: usize,
    /// Търсеният герой
    needle: char,

    // инвариант на безопасността: `utf8_size` трябва да бъде по-малко от 5
    /// Броят на байтовете `needle` заема, когато са кодирани в utf8.
    utf8_size: usize,
    /// Кодирано utf8 копие на `needle`
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // БЕЗОПАСНОСТ: 1-4 гарантират безопасността на `get_unchecked`
        // 1. `self.finger` и `self.finger_back` се държат на Unicode граници (това е инвариант)
        // 2. `self.finger >= 0` тъй като започва от 0 и само се увеличава
        // 3. `self.finger < self.finger_back` защото в противен случай char `iter` би върнал `SearchStep::Done`
        // 4.
        // `self.finger` идва преди края на купата сено, защото `self.finger_back` започва в края и само намалява
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // добавяне на байтово отместване на текущия символ без прекодиране като utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // вземете купа сено след последния намерен знак
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // последният байт на кодираната игла utf8 БЕЗОПАСНОСТ: имаме инвариант, че `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Новият пръст е индексът на байта, който намерихме, плюс един, тъй като запомнихме за последния байт на символа.
                //
                // Имайте предвид, че това не винаги ни дава пръст върху граница на UTF8.
                // Ако *не* намерим характера си, може да сме индексирали до не последния байт от 3-байтов или 4-байтов символ.
                // Не можем просто да преминем към следващия валиден начален байт, защото знак като ꁁ (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` ще ни накара винаги да намираме втория байт, когато търсим третия.
                //
                //
                // Това обаче е напълно наред.
                // Въпреки че имаме инварианта, че self.finger е на граница на UTF8, на този инвариант не се разчита в рамките на този метод (на него се разчита в CharSearcher::next()).
                //
                // Излизаме от този метод само когато достигнем края на низа или ако намерим нещо.Когато намерим нещо, `finger` ще бъде зададен на граница UTF8.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // не намери нищо, излез
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // нека next_reject използва изпълнението по подразбиране от Searcher Portrait
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // БЕЗОПАСНОСТ: вижте коментара за next() по-горе
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // изваждане на байтово отместване на текущия символ без прекодиране като utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // вземете купа сено до, но не включително последния търсен знак
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // последният байт на кодираната игла utf8 БЕЗОПАСНОСТ: имаме инвариант, че `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // търсихме парче, което беше компенсирано от self.finger, добавихме self.finger, за да възстановим оригиналния индекс
                //
                let index = self.finger + index;
                // memrchr ще върне индекса на байта, който искаме да намерим.
                // В случай на ASCII символ, това наистина е, ако желаем новият ни пръст да бъде ("after" намереният знак в парадигмата на обратната итерация).
                //
                // За многобайтовите символи трябва да пропуснем надолу по броя на повече байтове, които имат от ASCII
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // преместете пръста до преди намерения знак (т.е. в началния му индекс)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Тук не можем да използваме finger_back=index, size + 1.
                // Ако намерихме последния знак на символ с различен размер (или средния байт на различен символ), трябва да преместим finger_back до `index`.
                // Това прави по подобен начин `finger_back` потенциалът вече да не е на граница, но това е ОК, тъй като излизаме от тази функция само на граница или когато купата сено е била търсена напълно.
                //
                //
                // За разлика от next_match, тук няма проблем с повтарящи се байтове в utf-8, защото търсим последния байт и можем да намерим последния байт само при търсене в обратен ред.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // не намери нищо, излез
                return None;
            }
        }
    }

    // нека next_reject_back използва изпълнението по подразбиране от Searcher Portrait
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Търси символи, които са равни на даден [`char`].
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Impl за обвивка MultiCharEq
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Сравнете дължините на вътрешния итератор на байтов разрез, за да намерите дължината на текущия char
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Сравнете дължините на вътрешния итератор на байтов разрез, за да намерите дължината на текущия char
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Impl за&[char]
/////////////////////////////////////////////////////////////////////////////

// Todo: Промяна/премахване поради неяснота в значението.

/// Свързан тип за `<&[char] as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Търси символи, които са равни на всеки от [`char`] в среза.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl за F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// Свързан тип за `<F as Pattern<'a>>::Searcher`.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Търси за [`char`], които съответстват на дадения предикат.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl за&&str
/////////////////////////////////////////////////////////////////////////////

/// Делегати на `&str` имп.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Impl за &str
/////////////////////////////////////////////////////////////////////////////

/// Неразпределящо търсене на поднизове.
///
/// Ще обработва модела `""` като връщане на празни съвпадения на всяка граница на знака.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Проверява дали моделът съвпада в предната част на купата сено.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Премахва шаблона от предната страна на купа сено, ако съвпада.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // БЕЗОПАСНОСТ: Префиксът току-що бе потвърден, че съществува.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Проверява дали моделът съвпада в задната част на купата сено.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Премахва шаблона от гърба на купа сено, ако съвпада.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // БЕЗОПАСНОСТ: току-що беше потвърдено, че суфиксът съществува.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// Двупосочен търсач на поднизове
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Свързан тип за `<&str as Pattern<'a>>::Searcher`.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // празната игла отхвърля всеки знак и съответства на всеки празен низ между тях
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher произвежда валидни *Match* индекси, които се разделят на граници на символи, стига да прави правилното съвпадение и че сено и игла са валидни UTF-8 *Отхвърлянията* от алгоритъма могат да попаднат върху всякакви индекси, но ние ще ги преведем ръчно до следващата граница на знака, така че да са безопасни за utf-8.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // преминете към следващата граница на знака
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // изписвайте случаи `true` и `false`, за да насърчите компилатора да специализира двата случая поотделно.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // преминете към следващата граница на знака
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // изписвайте `true` и `false`, като `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// Вътрешното състояние на двупосочния алгоритъм за търсене на поднизове.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// индекс на критично факторизиране
    crit_pos: usize,
    /// критичен коефициент на факторизация за обърната игла
    crit_pos_back: usize,
    period: usize,
    /// `byteset` е разширение (не е част от двупосочния алгоритъм);
    /// това е 64-битов "fingerprint", където всеки зададен бит `j` съответства на (байт&63)==j, присъстващ в иглата.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// индекс в иглата, преди която вече сме съвпаднали
    memory: usize,
    /// индекс в иглата, след което вече имаме съвпадение
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Особено четимо обяснение на случващото се тук може да се намери в книгата на Crochemore и Rytter "Text Algorithms", гл. 13.
        // По-конкретно вижте кода за "Algorithm CP" на стр.
        // 323.
        //
        // Това, което се случва, е, че имаме критично факторизиране (u, v) на иглата и искаме да определим дали u е суфикс на&v [.. период].
        // Ако е, използваме "Algorithm CP1".
        // В противен случай използваме "Algorithm CP2", който е оптимизиран, когато периодът на иглата е голям.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // кратък период от време-периодът е точен изчислява отделно критично факторизиране за обърнатата игла x=u 'v' където | v '|<period(x).
            //
            // Това се ускорява от известния вече период.
            // Обърнете внимание, че случай като x= "acba" може да бъде разложен точно напред (крит_пос=1, период=3), като същевременно се разчита с приблизителен период в обратна посока (крит_пос=2, период=2).
            // Използваме дадената обратна факторизация, но запазваме точния период.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // случай с дълъг период-имаме приблизително до действителния период и не използваме запаметяване.
            //
            //
            // Приближете периода с долна граница max(|u|, |v|) + 1.
            // Критичната факторизация е ефикасна за използване както за търсене напред, така и за обратно.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Фиктивна стойност, която означава, че периодът е дълъг
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Една от основните идеи на Two-Way е, че разлагаме иглата на две половини (u, v) и започваме да се опитваме да намерим v в купата сено, като сканираме отляво надясно.
    // Ако v съвпада, ние се опитваме да съпоставим u, като сканираме отдясно наляво.
    // Доколко можем да скочим, когато срещнем несъответствие, всичко се основава на факта, че (u, v) е критично факторизиране за иглата.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` използва `self.position` като свой курсор
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Проверете дали имаме място за търсене в позиция + игла_ласт не може да препълни, ако приемем, че резените са ограничени от обхвата на isize.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Бързо прескачайте с големи порции, несвързани с нашия подниз
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Вижте дали дясната част на иглата съвпада
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Вижте дали лявата част на иглата съвпада
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Намерихме съвпадение!
            let match_pos = self.position;

            // Note: добавете self.period вместо needle.len(), за да има припокриващи се съвпадения
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // зададени на needle.len(), self.period за припокриващи се съвпадения
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Следва идеите в `next()`.
    //
    // Дефинициите са симетрични, с period(x) = period(reverse(x)) и local_period(u, v) = local_period(reverse(v), reverse(u)), така че ако (u, v) е критична факторизация, така е и (reverse(v), reverse(u)).
    //
    //
    // За обратния случай сме изчислили критична факторизация x=u 'v' (поле `crit_pos_back`).Нуждаем се от | u |<period(x) за предния случай и по този начин | v '|<period(x) за обратното.
    //
    // За да търсим наобратно през купа сено, ние търсим напред през обърната купа сено с обърната игла, съвпадаща първо u 'и след това v'.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` използва `self.end` като свой курсор-така че `next()` и `next_back()` са независими.
        //
        let old_end = self.end;
        'search: loop {
            // Проверете дали в крайна сметка имаме място за търсене, needle.len() ще се увие, когато вече няма място, но поради ограниченията на дължината на среза, той никога не може да се увие обратно в дължината на купа сено.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Бързо прескачайте с големи порции, несвързани с нашия подниз
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Вижте дали лявата част на иглата съвпада
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Вижте дали дясната част на иглата съвпада
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Намерихме съвпадение!
            let match_pos = self.end - needle.len();
            // Note: под self.period вместо needle.len(), за да има припокриващи се съвпадения
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Изчислете максималния суфикс на `arr`.
    //
    // Максималният суфикс е възможна критична факторизация (u, v) на `arr`.
    //
    // Връща (`i`, `p`), където `i` е началният индекс на v, а `p` е периодът на v.
    //
    // `order_greater` определя дали лексикалният ред е `<` или `>`.
    // И двете поръчки трябва да бъдат изчислени-поръчката с най-големия `i` дава критично факторизиране.
    //
    //
    // За случаи с дълъг период полученият период не е точен (той е твърде кратък).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Съответства на i в статията
        let mut right = 1; // Съответства на j в статията
        let mut offset = 0; // Съответства на k в статията, но започва от 0
        // за да съответства на индексирането въз основа на 0.
        let mut period = 1; // Съответства на p в статията

        while let Some(&a) = arr.get(right + offset) {
            // `left` ще бъдат входящи, когато `right` е.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Суфиксът е по-малък, периодът е цял префикс досега.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Напредване чрез повторение на текущия период.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Суфиксът е по-голям, започнете отначало от текущото местоположение.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Изчислете максималната суфикс на обратната страна на `arr`.
    //
    // Максималната суфикс е възможна критична факторизация (u ', v') на `arr`.
    //
    // Връща `i`, където `i` е началният индекс на v ', отзад;
    // връща се незабавно, когато е достигнат период от `known_period`.
    //
    // `order_greater` определя дали лексикалният ред е `<` или `>`.
    // И двете поръчки трябва да бъдат изчислени-поръчката с най-големия `i` дава критично факторизиране.
    //
    //
    // За случаи с дълъг период полученият период не е точен (той е твърде кратък).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Съответства на i в статията
        let mut right = 1; // Съответства на j в статията
        let mut offset = 0; // Съответства на k в статията, но започва от 0
        // за да съответства на индексирането въз основа на 0.
        let mut period = 1; // Съответства на p в статията
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Суфиксът е по-малък, периодът е цял префикс досега.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Напредване чрез повторение на текущия период.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Суфиксът е по-голям, започнете отначало от текущото местоположение.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy позволява на алгоритъма да пропуска несъвпадения възможно най-бързо, или да работи в режим, при който излъчва отхвърляния относително бързо.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Прескочете, за да съответствате на интервали възможно най-бързо
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Излъчвайте отхвърляния редовно
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}