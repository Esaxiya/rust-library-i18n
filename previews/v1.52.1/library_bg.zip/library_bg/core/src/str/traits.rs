//! Реализации на Trait за `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Прилага подреждане на низове.
///
/// Низовете са подредени [lexicographically](Ord#lexicographical-comparison) по техните байтови стойности.
/// Това нарежда Unicode кодови точки въз основа на техните позиции в кодовите диаграми.
/// Това не е задължително същото като поръчката на "alphabetical", която варира в зависимост от езика и локала.
/// Сортирането на низове според културно приетите стандарти изисква специфични за локала данни, които са извън обхвата на типа `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Прилага операции за сравнение на низове.
///
/// Низовете се сравняват [lexicographically](Ord#lexicographical-comparison) по техните байтови стойности.
/// Това сравнява Unicode кодови точки въз основа на техните позиции в кодовите диаграми.
/// Това не е задължително същото като поръчката на "alphabetical", която варира в зависимост от езика и локала.
/// Сравняването на низовете според културно приетите стандарти изисква специфични за локала данни, които са извън обхвата на типа `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Прилага нарязване на поднизове със синтаксис `&self[..]` или `&mut self[..]`.
///
/// Връща фрагмент от целия низ, т.е. връща `&self` или `&mut self`.Еквивалентно на `&self [0 ..
/// len] `или`&mut self [0 ..
/// len]`.
/// За разлика от други операции за индексиране, това никога не може да бъде panic.
///
/// Тази операция е *O*(1).
///
/// Преди 1.20.0 тези операции по индексиране все още се поддържаха чрез директно внедряване на `Index` и `IndexMut`.
///
/// Еквивалентно на `&self[0 .. len]` или `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Прилага нарязване на поднизове със синтаксис `&self[begin .. end]` или `&mut self[begin .. end]`.
///
/// Връща фрагмент от дадения низ от байтовия диапазон [`begin`, `end`).
///
/// Тази операция е *O*(1).
///
/// Преди 1.20.0 тези операции по индексиране все още се поддържаха чрез директно внедряване на `Index` и `IndexMut`.
///
/// # Panics
///
/// Panics, ако `begin` или `end` не сочи към началното изместване на байта на символ (както е дефинирано от `is_char_boundary`), ако `begin > end` или ако `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // те ще panic:
/// // байт 2 се намира в `ö`:
/// // &s [2 ..3];
///
/// // байт 8 се намира в `老`&s [1 ..
/// // 8];
///
/// // байт 100 е извън низа&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // БЕЗОПАСНОСТ: току-що проверих дали `start` и `end` са на граница на знака,
            // и предаваме безопасна препратка, така че връщаната стойност също ще бъде една.
            // Също така проверихме границите на знака, така че това е валидно UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // БЕЗОПАСНОСТ: току-що проверих дали `start` и `end` са на граница на знака.
            // Знаем, че показалецът е уникален, защото го получихме от `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // БЕЗОПАСНОСТ: повикващият гарантира, че `self` е в границите на `slice`
        // който отговаря на всички условия за `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // БЕЗОПАСНОСТ: вижте коментарите за `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary проверява дали индексът е в [0, .len()] не може да използва повторно `get` както по-горе, поради проблем с NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // БЕЗОПАСНОСТ: току-що проверих дали `start` и `end` са на граница на знака,
            // и предаваме безопасна препратка, така че връщаната стойност също ще бъде една.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Прилага нарязване на поднизове със синтаксис `&self[.. end]` или `&mut self[.. end]`.
///
/// Връща фрагмент от дадения низ от байтовия диапазон [`0`, `end`).
/// Еквивалентно на `&self[0 .. end]` или `&mut self[0 .. end]`.
///
/// Тази операция е *O*(1).
///
/// Преди 1.20.0 тези операции по индексиране все още се поддържаха чрез директно внедряване на `Index` и `IndexMut`.
///
/// # Panics
///
/// Panics, ако `end` не сочи към началното изместване на байта на символ (както е дефинирано от `is_char_boundary`), или ако `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // БЕЗОПАСНОСТ: току-що проверих дали `end` е на граница на знака,
            // и предаваме безопасна препратка, така че връщаната стойност също ще бъде една.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // БЕЗОПАСНОСТ: току-що проверих дали `end` е на граница на знака,
            // и предаваме безопасна препратка, така че връщаната стойност също ще бъде една.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // БЕЗОПАСНОСТ: току-що проверих дали `end` е на граница на знака,
            // и предаваме безопасна препратка, така че връщаната стойност също ще бъде една.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Прилага нарязване на поднизове със синтаксис `&self[begin ..]` или `&mut self[begin ..]`.
///
/// Връща фрагмент от дадения низ от байтовия диапазон [`begin`, `len`).Еквивалентно на `&self [начало ..
/// len] `или`&mut self [начало ..
/// len]`.
///
/// Тази операция е *O*(1).
///
/// Преди 1.20.0 тези операции по индексиране все още се поддържаха чрез директно внедряване на `Index` и `IndexMut`.
///
/// # Panics
///
/// Panics, ако `begin` не сочи към началното изместване на байта на символ (както е дефинирано от `is_char_boundary`), или ако `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // БЕЗОПАСНОСТ: току-що проверих дали `start` е на граница на знака,
            // и предаваме безопасна препратка, така че връщаната стойност също ще бъде една.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // БЕЗОПАСНОСТ: току-що проверих дали `start` е на граница на знака,
            // и предаваме безопасна препратка, така че връщаната стойност също ще бъде една.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // БЕЗОПАСНОСТ: повикващият гарантира, че `self` е в границите на `slice`
        // който отговаря на всички условия за `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // БЕЗОПАСНОСТ: идентичен с `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // БЕЗОПАСНОСТ: току-що проверих дали `start` е на граница на знака,
            // и предаваме безопасна препратка, така че връщаната стойност също ще бъде една.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Прилага нарязване на поднизове със синтаксис `&self[begin ..= end]` или `&mut self[begin ..= end]`.
///
/// Връща фрагмент от дадения низ от байтовия диапазон [`begin`, `end`].Еквивалентно на `&self [begin .. end + 1]` или `&mut self[begin .. end + 1]`, освен ако `end` има максималната стойност за `usize`.
///
/// Тази операция е *O*(1).
///
/// # Panics
///
/// Panics, ако `begin` не сочи към началното байтово отместване на символ (както е дефинирано от `is_char_boundary`), ако `end` не сочи към крайното байтово отместване на символ (`end + 1` е или начално байтово отместване, или равно на `len`), ако `begin > end`, или ако `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // БЕЗОПАСНОСТ: повикващият трябва да спазва договора за безопасност за `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // БЕЗОПАСНОСТ: повикващият трябва да спазва договора за безопасност за `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Прилага нарязване на поднизове със синтаксис `&self[..= end]` или `&mut self[..= end]`.
///
/// Връща фрагмент от дадения низ от байтовия диапазон [0, `end`].
/// Еквивалентно на `&self [0 .. end + 1]`, освен ако `end` има максималната стойност за `usize`.
///
/// Тази операция е *O*(1).
///
/// # Panics
///
/// Panics, ако `end` не сочи към крайно байтово отместване на символ (`end + 1` е или начално байтово отместване, както е дефинирано от `is_char_boundary`, или равно на `len`), или ако `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // БЕЗОПАСНОСТ: повикващият трябва да спазва договора за безопасност за `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // БЕЗОПАСНОСТ: повикващият трябва да спазва договора за безопасност за `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Анализирайте стойност от низ
///
/// Методът на " FromStr [`from_str`] често се използва имплицитно, чрез метода [`parse`] на [" str`].
/// Вижте документацията на [`parse`] за примери.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` няма параметър за цял живот и затова можете да анализирате само типове, които сами не съдържат параметър за цял живот.
///
/// С други думи, можете да анализирате `i32` с `FromStr`, но не и `&i32`.
/// Можете да анализирате структура, която съдържа `i32`, но не и такава, която съдържа `&i32`.
///
/// # Examples
///
/// Основна реализация на `FromStr` на примерен тип `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Свързаната грешка, която може да бъде върната от синтактичния анализ.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Анализира низ `s`, за да върне стойност от този тип.
    ///
    /// Ако анализирането е успешно, върнете стойността вътре в [`Ok`], в противен случай, когато низът е неправилно форматиран, върнете грешка, специфична за вътрешната [`Err`].
    /// Типът грешка е специфичен за изпълнението на Portrait.
    ///
    /// # Examples
    ///
    /// Основна употреба с [`i32`], тип, който прилага `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Анализирайте `bool` от низ.
    ///
    /// Дава `Result<bool, ParseBoolError>`, защото `s` може или не може да бъде анализируем.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Имайте предвид, че в много случаи методът `.parse()` на `str` е по-правилен.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}