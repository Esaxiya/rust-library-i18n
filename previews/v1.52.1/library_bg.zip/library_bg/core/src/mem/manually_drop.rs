use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Опаковка, която пречи на компилатора автоматично да извиква деструктора на T.
/// Тази обвивка е 0-цена.
///
/// `ManuallyDrop<T>` е обект на същите оптимизации на оформлението като `T`.
/// В резултат на това той няма *ефект* върху предположенията, които компилаторът прави относно съдържанието му.
/// Например инициализирането на `ManuallyDrop<&mut T>` с [`mem::zeroed`] е недефинирано поведение.
/// Ако трябва да обработвате неинициализирани данни, използвайте [`MaybeUninit<T>`] вместо това.
///
/// Имайте предвид, че достъпът до стойността в `ManuallyDrop<T>` е безопасен.
/// Това означава, че `ManuallyDrop<T>`, чието съдържание е изпуснато, не трябва да бъде излагано чрез обществено безопасен API.
/// Съответно `ManuallyDrop::drop` е опасен.
///
/// # `ManuallyDrop` и пуснете поръчка.
///
/// Rust има добре дефинирани стойности [drop order].
/// За да сте сигурни, че полетата или локалите са изпуснати в определен ред, пренаредете декларациите така, че подразбиращият се ред на отпадане да е правилен.
///
/// Възможно е да се използва `ManuallyDrop` за контрол на реда на пускане, но това изисква опасен код и е трудно да се направи правилно при наличие на отвиване.
///
///
/// Например, ако искате да сте сигурни, че конкретно поле е отпаднало след останалите, направете го последното поле на структура:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` ще отпадне след `children`.
///     // Rust гарантира, че полетата ще бъдат изпуснати в реда на деклариране.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Опаковайте стойност, която да бъде ръчно пусната.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Все още можете безопасно да управлявате стойността
    /// assert_eq!(*x, "Hello");
    /// // Но `Drop` няма да работи тук
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Извлича стойността от контейнера `ManuallyDrop`.
    ///
    /// Това позволява стойността да бъде изпусната отново.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Това отпада `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Изважда стойността от контейнера `ManuallyDrop<T>`.
    ///
    /// Този метод е предназначен предимно за изваждане на стойности в спад.
    /// Вместо да използвате [`ManuallyDrop::drop`] за ръчно изпускане на стойността, можете да използвате този метод, за да вземете стойността и да я използвате, както желаете.
    ///
    /// Когато е възможно, за предпочитане е вместо това да се използва [`into_inner`][`ManuallyDrop::into_inner`], което предотвратява дублирането на съдържанието на `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Тази функция семантично измества съдържащата се стойност, без да предотвратява по-нататъшно използване, оставяйки състоянието на този контейнер непроменено.
    /// Ваша отговорност е да се уверите, че този `ManuallyDrop` не се използва отново.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // БЕЗОПАСНОСТ: четем от справка, която е гарантирана
        // да е валиден за четения
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Ръчно изпуска съдържащата се стойност.Това е точно еквивалентно на извикване на [`ptr::drop_in_place`] с указател на съдържащата се стойност.
    /// Като такъв, освен ако съдържащата стойност не е опакована структура, деструкторът ще бъде извикан на място, без да се премества стойността и по този начин може да се използва за безопасно изпускане на [pinned] данни.
    ///
    /// Ако притежавате стойността на стойността, вместо това можете да използвате [`ManuallyDrop::into_inner`].
    ///
    /// # Safety
    ///
    /// Тази функция изпълнява деструктора на съдържащата се стойност.
    /// Освен промените, направени от самия деструктор, паметта остава непроменена и по отношение на компилатора все още има битов модел, който е валиден за типа `T`.
    ///
    ///
    /// Тази стойност на "zombie" обаче не трябва да се излага на безопасен код и тази функция не трябва да се извиква повече от веднъж.
    /// Използването на стойност, след като е била изпусната или пускането на стойност няколко пъти, може да доведе до недефинирано поведение (в зависимост от това, което `drop` прави).
    /// Това обикновено се предотвратява от типовата система, но потребителите на `ManuallyDrop` трябва да поддържат тези гаранции без съдействие от компилатора.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // БЕЗОПАСНОСТ: изпускаме стойността, посочена от променяща се препратка
        // което е гарантирано валидно за записи.
        // От повикващия зависи да се увери, че `slot` не е отпаднал отново.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}