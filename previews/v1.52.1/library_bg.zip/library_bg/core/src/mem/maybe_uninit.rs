use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Тип обвивка за конструиране на неинициализирани екземпляри на `T`.
///
/// # Инициализация инвариант
///
/// Като цяло компилаторът приема, че променливата е правилно инициализирана в съответствие с изискванията на типа на променливата.Например променлива от референтен тип трябва да бъде подравнена и да не е NULL.
/// Това е инвариант, който трябва винаги да се поддържа * дори в небезопасен код.
/// В резултат на това нулевата инициализация на променлива от референтен тип причинява мигновено [undefined behavior][ub], без значение дали тази референция някога ще се използва за достъп до паметта:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // недефинирано поведение!⚠️
/// // Еквивалентният код с `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // недефинирано поведение!⚠️
/// ```
///
/// Това се използва от компилатора за различни оптимизации, като изтриване на проверки за изпълнение и оптимизиране на оформлението на `enum`.
///
/// По същия начин изцяло неинициализираната памет може да има някакво съдържание, докато `bool` винаги трябва да бъде `true` или `false`.Следователно създаването на неинициализиран `bool` е недефинирано поведение:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // недефинирано поведение!⚠️
/// // Еквивалентният код с `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // недефинирано поведение!⚠️
/// ```
///
/// Освен това неинициализираната памет е специална с това, че няма фиксирана стойност ("fixed", което означава "it won't change without being written to").Четенето на един и същ неинициализиран байт няколко пъти може да даде различни резултати.
/// Това прави недефинираното поведение да има неинициализирани данни в променлива, дори ако тази променлива има цяло число, което иначе може да съдържа всеки *фиксиран* битов модел:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // недефинирано поведение!⚠️
/// // Еквивалентният код с `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // недефинирано поведение!⚠️
/// ```
/// (Забележете, че правилата около неинициализираните цели числа все още не са финализирани, но докато не бъдат препоръчително да се избягват.)
///
/// Освен това не забравяйте, че повечето типове имат допълнителни инварианти, освен че се считат за инициализирани на ниво тип.
/// Например, инициализиран с " 1` [`Vec<T>`] се счита за инициализиран (при текущата реализация; това не представлява стабилна гаранция), тъй като единственото изискване, което компилаторът знае за него, е, че указателят за данни трябва да е ненулев.
/// Създаването на такъв `Vec<T>` не причинява *незабавно* недефинирано поведение, но ще причини недефинирано поведение при повечето безопасни операции (включително отпадането му).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` служи за активиране на небезопасен код за работа с неинициализирани данни.
/// Това е сигнал към компилатора, указващ, че данните тук може да не се * инициализират:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Създайте изрично неинициализирана препратка.
/// // Компилаторът знае, че данните в `MaybeUninit<T>` може да са невалидни и следователно това не е UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Задайте го на валидна стойност.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Извличане на инициализираните данни-това е разрешено *само след* правилно инициализиране на `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Тогава компилаторът знае, че не прави неправилни предположения или оптимизации на този код.
///
/// Можете да мислите за `MaybeUninit<T>` като за нещо като `Option<T>`, но без проследяване на времето за изпълнение и без проверки за безопасност.
///
/// ## out-pointers
///
/// Можете да използвате `MaybeUninit<T>`, за да внедрите "out-pointers": вместо да връщате данни от функция, предавайте я указател на някаква памет (uninitialized), за да поставите резултата.
/// Това може да бъде полезно, когато е важно повикващият да контролира как паметта, в която се съхранява резултатът, се разпределя и искате да избегнете ненужни ходове.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` не изпуска старото съдържание, което е важно.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Сега знаем, че `v` е инициализиран!Това също гарантира, че vector ще бъде изпуснат правилно.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Инициализиране на масив елемент по елемент
///
/// `MaybeUninit<T>` може да се използва за инициализиране на голям масив елемент по елемент:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Създайте неинициализиран масив от `MaybeUninit`.
///     // `assume_init` е безопасен, тъй като типът, за който твърдим, че е инициализиран тук, е куп `MaybeUninit`s, които не изискват инициализация.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Изпускането на `MaybeUninit` не прави нищо.
///     // По този начин използването на присвояване на суров указател вместо `ptr::write` не води до отпадане на старата неинициализирана стойност.
/////
///     // Също така, ако има panic по време на този цикъл, имаме изтичане на памет, но няма проблем със сигурността на паметта.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Всичко е инициализирано.
///     // Трансмутирайте масива в инициализирания тип.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Можете също така да работите с частично инициализирани масиви, които могат да бъдат намерени в структурите на данни от ниско ниво.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Създайте неинициализиран масив от `MaybeUninit`.
/// // `assume_init` е безопасен, тъй като типът, за който твърдим, че е инициализиран тук, е куп `MaybeUninit`s, които не изискват инициализация.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Пребройте броя на елементите, които сме задали.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // За всеки елемент в масива пуснете, ако сме го разпределили.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Инициализиране на структура поле по поле
///
/// Можете да използвате `MaybeUninit<T>` и макроса [`std::ptr::addr_of_mut`], за да инициализирате структурите поле по поле:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Инициализиране на полето `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Инициализиране на полето `list` Ако тук има panic, тогава `String` в полето `name` изтича.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Всички полета са инициализирани, затова извикваме `assume_init`, за да получим инициализиран Foo.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` гарантирано има същия размер, подравняване и ABI като `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Не забравяйте обаче, че тип *, съдържащ*`MaybeUninit<T>`, не е задължително едно и също оформление;Rust като цяло не гарантира, че полетата на `Foo<T>` имат същия ред като `Foo<U>`, дори ако `T` и `U` имат еднакъв размер и подравняване.
///
/// Освен това, тъй като която и да е битова стойност е валидна за `MaybeUninit<T>`, компилаторът не може да приложи оптимизации на non-zero/niche-filling, което може да доведе до по-голям размер:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Ако `T` е безопасен за FFI, тогава е и `MaybeUninit<T>`.
///
/// Докато `MaybeUninit` е `#[repr(transparent)]` (което означава, че гарантира същия размер, подравняване и ABI като `T`), това *не* променя нито едно от предишните предупреждения.
/// `Option<T>` и `Option<MaybeUninit<T>>` все още могат да имат различни размери и типовете, съдържащи поле от тип `T`, могат да бъдат разположени (и оразмерени) по различен начин, отколкото ако това поле е `MaybeUninit<T>`.
/// `MaybeUninit` е тип обединение, а `#[repr(transparent)]` за обединения е нестабилен (вижте [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// С течение на времето точните гаранции за `#[repr(transparent)]` за обединенията могат да се развият и `MaybeUninit` може или не да остане `#[repr(transparent)]`.
/// Въпреки това, `MaybeUninit<T>`*винаги* ще гарантира, че има същия размер, подравняване и ABI като `T`;просто начинът, по който `MaybeUninit` прилага тази гаранция, може да се развие.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Езиков елемент, за да можем да увием други видове в него.Това е полезно за генераторите.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Не се обаждаме на `T::clone()`, не можем да разберем дали сме достатъчно инициализирани за това.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Създава нов `MaybeUninit<T>`, инициализиран с дадената стойност.
    /// Безопасно е да се обадите на [`assume_init`] за връщаната стойност на тази функция.
    ///
    /// Имайте предвид, че пускането на `MaybeUninit<T>` никога няма да извика кода за спад на " T`.
    /// Вашата отговорност е да се уверите, че `T` ще бъде изпуснат, ако е инициализиран.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Създава нов `MaybeUninit<T>` в неинициализирано състояние.
    ///
    /// Имайте предвид, че пускането на `MaybeUninit<T>` никога няма да извика кода за спад на " T`.
    /// Вашата отговорност е да се уверите, че `T` ще бъде изпуснат, ако е инициализиран.
    ///
    /// Вижте [type-level documentation][MaybeUninit] за някои примери.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Създайте нов масив от `MaybeUninit<T>` елементи в неинициализирано състояние.
    ///
    /// Note: във версия future Rust този метод може да стане ненужен, когато синтаксисът на литералния масив позволява [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Примерът по-долу може да използва `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Връща (евентуално по-малък) фрагмент от данни, който всъщност е бил прочетен
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // БЕЗОПАСНОСТ: Неинициализиран `[MaybeUninit<_>; LEN]` е валиден.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Създава нов `MaybeUninit<T>` в неинициализирано състояние, като паметта се запълва с байтове `0`.Зависи от `T` дали това вече прави правилната инициализация.
    ///
    /// Например `MaybeUninit<usize>::zeroed()` е инициализиран, но `MaybeUninit<&'static i32>::zeroed()` не е, защото препратките не трябва да са нула.
    ///
    /// Имайте предвид, че пускането на `MaybeUninit<T>` никога няма да извика кода за спад на " T`.
    /// Вашата отговорност е да се уверите, че `T` ще бъде изпуснат, ако е инициализиран.
    ///
    /// # Example
    ///
    /// Правилно използване на тази функция: инициализиране на структура с нула, където всички полета на структурата могат да съдържат битовия модел 0 като валидна стойност.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Неправилно* използване на тази функция: извикване на `x.zeroed().assume_init()`, когато `0` не е валиден битов модел за типа:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Вътре в двойка създаваме `NotZero`, който няма валиден дискриминант.
    /// // Това е недефинирано поведение.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // БЕЗОПАСНОСТ: `u.as_mut_ptr()` сочи към разпределена памет.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Задава стойността на `MaybeUninit<T>`.
    /// Това заменя всяка предишна стойност, без да я изпуска, така че внимавайте да не я използвате два пъти, освен ако не искате да пропуснете стартирането на деструктора.
    ///
    /// За ваше улеснение това също връща променлива препратка към (вече безопасно инициализираното) съдържание на `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // БЕЗОПАСНОСТ: Току-що инициализирахме тази стойност.
        unsafe { self.assume_init_mut() }
    }

    /// Получава указател към съдържащата се стойност.
    /// Четенето от този указател или превръщането му в препратка е недефинирано поведение, освен ако `MaybeUninit<T>` не е инициализиран.
    /// Записването в паметта, към което сочи този указател (non-transitively), е недефинирано поведение (освен в `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Правилно използване на този метод:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Създайте препратка към `MaybeUninit<T>`.Това е добре, защото го инициализирахме.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Неправилно* използване на този метод:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Създадохме препратка към неинициализиран vector!Това е недефинирано поведение.⚠️
    /// ```
    ///
    /// (Забележете, че правилата за препратки към неинициализирани данни все още не са финализирани, но докато не бъдат препоръчително да се избягват.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` и `ManuallyDrop` са `repr(transparent)`, за да можем да хвърлим показалеца.
        self as *const _ as *const T
    }

    /// Получава променлив указател към съдържащата се стойност.
    /// Четенето от този указател или превръщането му в препратка е недефинирано поведение, освен ако `MaybeUninit<T>` не е инициализиран.
    ///
    /// # Examples
    ///
    /// Правилно използване на този метод:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Създайте препратка към `MaybeUninit<Vec<u32>>`.
    /// // Това е добре, защото го инициализирахме.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Неправилно* използване на този метод:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Създадохме препратка към неинициализиран vector!Това е недефинирано поведение.⚠️
    /// ```
    ///
    /// (Забележете, че правилата за препратки към неинициализирани данни все още не са финализирани, но докато не бъдат препоръчително да се избягват.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` и `ManuallyDrop` са `repr(transparent)`, за да можем да хвърлим показалеца.
        self as *mut _ as *mut T
    }

    /// Извлича стойността от контейнера `MaybeUninit<T>`.Това е чудесен начин да се гарантира, че данните ще бъдат изпуснати, тъй като полученият `T` е обект на обичайното обработване на капки.
    ///
    /// # Safety
    ///
    /// От повикващия зависи да гарантира, че `MaybeUninit<T>` наистина е в инициализирано състояние.Извикването на това, когато съдържанието все още не е напълно инициализирано, причинява незабавно недефинирано поведение.
    /// [type-level documentation][inv] съдържа повече информация за този инвариант на инициализацията.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Освен това не забравяйте, че повечето типове имат допълнителни инварианти, освен че се считат за инициализирани на ниво тип.
    /// Например, инициализиран с " 1` [`Vec<T>`] се счита за инициализиран (при текущата реализация; това не представлява стабилна гаранция), тъй като единственото изискване, което компилаторът знае за него, е, че указателят за данни трябва да е ненулев.
    ///
    /// Създаването на такъв `Vec<T>` не причинява *незабавно* недефинирано поведение, но ще причини недефинирано поведение при повечето безопасни операции (включително отпадането му).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Правилно използване на този метод:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Неправилно* използване на този метод:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` все още не е инициализиран, така че този последен ред е причинил недефинирано поведение.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // БЕЗОПАСНОСТ: повикващият трябва да гарантира, че `self` е инициализиран.
        // Това също означава, че `self` трябва да бъде вариант `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Отчита стойността от контейнера `MaybeUninit<T>`.Полученият `T` е обект на обичайното обработване на капки.
    ///
    /// Когато е възможно, за предпочитане е вместо това да се използва [`assume_init`], което предотвратява дублирането на съдържанието на `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// От повикващия зависи да гарантира, че `MaybeUninit<T>` наистина е в инициализирано състояние.Извикването на това, когато съдържанието все още не е напълно инициализирано, причинява недефинирано поведение.
    /// [type-level documentation][inv] съдържа повече информация за този инвариант на инициализацията.
    ///
    /// Нещо повече, това оставя копие на същите данни зад `MaybeUninit<T>`.
    /// Когато използвате множество копия на данните (чрез многократно извикване на `assume_init_read` или първо извикване на `assume_init_read` и след това на [`assume_init`]), вашата отговорност е да се уверите, че тези данни наистина могат да бъдат дублирани.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Правилно използване на този метод:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` е `Copy`, така че можем да четем няколко пъти.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Дублирането на стойност `None` е добре, така че можем да четем няколко пъти.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Неправилно* използване на този метод:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Сега създадохме две копия на един и същ vector, водещи до двойно безплатно ⚠️, когато и двамата отпаднат!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // БЕЗОПАСНОСТ: повикващият трябва да гарантира, че `self` е инициализиран.
        // Четенето от `self.as_ptr()` е безопасно, тъй като `self` трябва да бъде инициализиран.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Изпуска съдържащата се стойност на място.
    ///
    /// Ако притежавате `MaybeUninit`, вместо това можете да използвате [`assume_init`].
    ///
    /// # Safety
    ///
    /// От повикващия зависи да гарантира, че `MaybeUninit<T>` наистина е в инициализирано състояние.Извикването на това, когато съдържанието все още не е напълно инициализирано, причинява недефинирано поведение.
    ///
    /// На всичкото отгоре трябва да бъдат изпълнени всички допълнителни инварианти от типа `T`, тъй като изпълнението на `Drop` на `T` (или неговите членове) може да разчита на това.
    /// Например, инициализиран с " 1` [`Vec<T>`] се счита за инициализиран (при текущата реализация; това не представлява стабилна гаранция), тъй като единственото изискване, което компилаторът знае за него, е, че указателят за данни трябва да е ненулев.
    ///
    /// Изпускането на такъв `Vec<T>` обаче ще доведе до недефинирано поведение.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // БЕЗОПАСНОСТ: повикващият трябва да гарантира, че `self` е инициализиран и
        // удовлетворява всички инварианти на `T`.
        // Отпадането на стойността на място е безопасно, ако случаят е такъв.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Получава споделена препратка към съдържащата се стойност.
    ///
    /// Това може да бъде полезно, когато искаме да осъществим достъп до `MaybeUninit`, който е инициализиран, но не притежава собствеността върху `MaybeUninit` (предотвратявайки използването на `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Извикването на това, когато съдържанието все още не е напълно инициализирано, причинява недефинирано поведение: повикващият трябва да гарантира, че `MaybeUninit<T>` наистина е в инициализирано състояние.
    ///
    ///
    /// # Examples
    ///
    /// ### Правилно използване на този метод:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Инициализирайте `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Сега, когато е известно, че нашият `MaybeUninit<_>` е инициализиран, е добре да създадете споделена препратка към него:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // БЕЗОПАСНОСТ: `x` е инициализиран.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Неправилни* употреби на този метод:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Създадохме препратка към неинициализиран vector!Това е недефинирано поведение.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Инициализирайте `MaybeUninit` с помощта на `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Позоваване на неинициализиран `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // БЕЗОПАСНОСТ: повикващият трябва да гарантира, че `self` е инициализиран.
        // Това също означава, че `self` трябва да бъде вариант `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Получава променлива препратка (unique) към съдържащата се стойност.
    ///
    /// Това може да бъде полезно, когато искаме да осъществим достъп до `MaybeUninit`, който е инициализиран, но не притежава собствеността върху `MaybeUninit` (предотвратявайки използването на `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Извикването на това, когато съдържанието все още не е напълно инициализирано, причинява недефинирано поведение: повикващият трябва да гарантира, че `MaybeUninit<T>` наистина е в инициализирано състояние.
    /// Например `.assume_init_mut()` не може да се използва за инициализиране на `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Правилно използване на този метод:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Инициализира *всички* байта на входния буфер.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Инициализирайте `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Сега знаем, че `buf` е инициализиран, така че можем да го `.assume_init()`.
    /// // Използването на `.assume_init()` обаче може да задейства `memcpy` от 2048 байта.
    /// // За да твърдим, че нашият буфер е инициализиран, без да го копираме, надграждаме `&mut MaybeUninit<[u8; 2048]>` до `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // БЕЗОПАСНОСТ: `buf` е инициализиран.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Сега можем да използваме `buf` като нормален слайс:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Неправилни* употреби на този метод:
    ///
    /// Не можете да използвате `.assume_init_mut()` за инициализиране на стойност:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Създадохме (mutable) препратка към неинициализиран `bool`!
    ///     // Това е недефинирано поведение.⚠️
    /// }
    /// ```
    ///
    /// Например не можете да [`Read`] в неинициализиран буфер:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) препратка към неинициализирана памет!
    ///                             // Това е недефинирано поведение.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Нито можете да използвате директен достъп до поле, за да извършвате постепенно инициализиране на полето:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) препратка към неинициализирана памет!
    ///                  // Това е недефинирано поведение.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) препратка към неинициализирана памет!
    ///                  // Това е недефинирано поведение.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Понастоящем разчитаме на горното да е неправилно, т.е. имаме препратки към неинициализирани данни (например в `libcore/fmt/float.rs`).
    // Трябва да вземем окончателно решение за правилата преди стабилизацията.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // БЕЗОПАСНОСТ: повикващият трябва да гарантира, че `self` е инициализиран.
        // Това също означава, че `self` трябва да бъде вариант `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Извлича стойностите от масив от `MaybeUninit` контейнери.
    ///
    /// # Safety
    ///
    /// От повикващия зависи да гарантира, че всички елементи на масива са в инициализирано състояние.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // БЕЗОПАСНОСТ: Сега в безопасност, тъй като инициализирахме всички елементи
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Повикващият гарантира, че всички елементи на масива са инициализирани
        // * `MaybeUninit<T>` и T са гарантирани да имат еднакво оформление
        // * MaybeUnint не пада, така че няма двойни освобождавания и по този начин преобразуването е безопасно
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Ако приемем, че всички елементи са инициализирани, вземете парче към тях.
    ///
    /// # Safety
    ///
    /// От повикващия зависи да гарантира, че елементите `MaybeUninit<T>` наистина са в инициализирано състояние.
    ///
    /// Извикването на това, когато съдържанието все още не е напълно инициализирано, причинява недефинирано поведение.
    ///
    /// Вижте [`assume_init_ref`] за повече подробности и примери.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // БЕЗОПАСНОСТ: прехвърлянето на парче на `*const [T]` е безопасно, тъй като повикващият гарантира това
        // `slice` е инициализиран и`MaybeUninit` гарантирано има същото оформление като `T`.
        // Полученият указател е валиден, тъй като се отнася до памет, собственост на `slice`, която е референция и по този начин гарантира, че е валидна за четения.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Ако приемем, че всички елементи са инициализирани, вземете променлив парче към тях.
    ///
    /// # Safety
    ///
    /// От повикващия зависи да гарантира, че елементите `MaybeUninit<T>` наистина са в инициализирано състояние.
    ///
    /// Извикването на това, когато съдържанието все още не е напълно инициализирано, причинява недефинирано поведение.
    ///
    /// Вижте [`assume_init_mut`] за повече подробности и примери.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // БЕЗОПАСНОСТ: подобно на бележките за безопасност за `slice_get_ref`, но ние имаме
        // променлива препратка, която също е гарантирано валидна за записи.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Получава указател към първия елемент от масива.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Получава изменяем указател към първия елемент на масива.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Копира елементите от `src` в `this`, връщайки изменяема препратка към сега инициализираното съдържание на `this`.
    ///
    /// Ако `T` не прилага `Copy`, използвайте [`write_slice_cloned`]
    ///
    /// Това е подобно на [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Тази функция ще panic, ако двата среза имат различна дължина.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // БЕЗОПАСНОСТ: току-що копирахме всички елементи на len в свободния капацитет
    /// // първите src.len() елементи на vec са валидни сега.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // БЕЗОПАСНОСТ: &[T] и&[MaybeUninit<T>] имат същото оформление
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // БЕЗОПАСНОСТ: Валидните елементи току-що са копирани в `this`, така че той е инициализиран
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Клонира елементите от `src` до `this`, връщайки изменяема препратка към сега инициализираното съдържание на `this`.
    /// Всички вече инициализирани елементи няма да бъдат изпуснати.
    ///
    /// Ако `T` изпълнява `Copy`, използвайте [`write_slice`]
    ///
    /// Това е подобно на [`slice::clone_from_slice`], но не изпуска съществуващите елементи.
    ///
    /// # Panics
    ///
    /// Тази функция ще panic, ако двата среза имат различна дължина, или ако изпълнението на `Clone` panics.
    ///
    /// Ако има panic, вече клонираните елементи ще бъдат изпуснати.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // БЕЗОПАСНОСТ: току-що клонирахме всички елементи на len в свободния капацитет
    /// // първите src.len() елементи на vec са валидни сега.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // за разлика от copy_from_slice, това не извиква clone_from_slice на среза, това е така, защото `MaybeUninit<T: Clone>` не прилага Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // БЕЗОПАСНОСТ: този суров фрагмент ще съдържа само инициализирани обекти
                // ето защо е позволено да го пуснете.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Трябва изрично да ги нарежем на еднаква дължина
        // за проверка на граници, които трябва да бъдат изтрити, и оптимизаторът ще генерира memcpy за прости случаи (например T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // необходима е охрана b/c panic може да се случи по време на клонинг
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // БЕЗОПАСНОСТ: Валидните елементи току-що са записани в `this`, така че той е инициализиран
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}