/// Версията на оператора за повикване, която приема неизменяем приемник.
///
/// Екземплярите на `Fn` могат да бъдат извиквани многократно, без да мутира състояние.
///
/// *Този Portrait (`Fn`) не трябва да се бърка с [function pointers] (`fn`).*
///
/// `Fn` се изпълнява автоматично чрез затваряния, които вземат само неизменяеми препратки към заснетите променливи или изобщо не улавят нищо, както и (safe) [function pointers] (с някои предупреждения вижте документацията им за повече подробности).
///
/// Освен това, за всеки тип `F`, който прилага `Fn`, `&F` също прилага `Fn`.
///
/// Тъй като и [`FnMut`], и [`FnOnce`] са супергресиви на `Fn`, всеки екземпляр на `Fn` може да се използва като параметър, където се очаква [`FnMut`] или [`FnOnce`].
///
/// Използвайте `Fn` като обвързан, когато искате да приемете параметър от тип, подобен на функция и трябва да го извиквате многократно и без да мутира състояние (например, когато го извиквате едновременно).
/// Ако не се нуждаете от толкова строги изисквания, използвайте [`FnMut`] или [`FnOnce`] като граници.
///
/// Вижте [chapter on closures in *The Rust Programming Language*][book] за повече информация по тази тема.
///
/// Също така трябва да се отбележи специалният синтаксис за `Fn` traits (напр
/// `Fn(usize, bool) -> usize`).Тези, които се интересуват от техническите подробности за това, могат да се обърнат към [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Обаждане на затваряне
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Използване на параметър `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // така че regex да може да разчита на този `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Извършва операцията за повикване.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Версията на оператора за повикване, която приема променлив приемник.
///
/// Екземплярите на `FnMut` могат да се извикват многократно и могат да мутират състоянието.
///
/// `FnMut` се изпълнява автоматично чрез затваряния, които вземат променливи препратки към уловени променливи, както и всички типове, които прилагат [`Fn`], например (safe) [function pointers] (тъй като `FnMut` е супертрейт на [`Fn`]).
/// Освен това, за всеки тип `F`, който прилага `FnMut`, `&mut F` също прилага `FnMut`.
///
/// Тъй като [`FnOnce`] е супертрейт на `FnMut`, всеки екземпляр на `FnMut` може да се използва там, където се очаква [`FnOnce`], а тъй като [`Fn`] е подпорт на `FnMut`, всеки екземпляр на [`Fn`] може да се използва там, където се очаква `FnMut`.
///
/// Използвайте `FnMut` като обвързан, когато искате да приемете параметър от тип, подобен на функция и трябва да го извиквате многократно, като същевременно му позволявате да мутира състояние.
/// Ако не искате параметърът да мутира състояние, използвайте [`Fn`] като обвързан;ако не е необходимо да го извиквате многократно, използвайте [`FnOnce`].
///
/// Вижте [chapter on closures in *The Rust Programming Language*][book] за повече информация по тази тема.
///
/// Също така трябва да се отбележи специалният синтаксис за `Fn` traits (напр
/// `Fn(usize, bool) -> usize`).Тези, които се интересуват от техническите подробности за това, могат да се обърнат към [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Извикване на затваряне за затваряне с мутация
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Използване на параметър `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // така че regex да може да разчита на този `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Извършва операцията за повикване.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Версията на оператора на повикване, която приема приемник по стойност.
///
/// Екземпляри на `FnOnce` могат да бъдат извикани, но може да не се извикват многократно.Поради това, ако единственото нещо, което се знае за даден тип е, че той изпълнява `FnOnce`, той може да бъде извикан само веднъж.
///
/// `FnOnce` се изпълнява автоматично чрез затваряния, които могат да консумират уловени променливи, както и всички типове, които прилагат [`FnMut`], например (safe) [function pointers] (тъй като `FnOnce` е супертрейт на [`FnMut`]).
///
///
/// Тъй като и [`Fn`], и [`FnMut`] са подгрупи на `FnOnce`, всеки екземпляр на [`Fn`] или [`FnMut`] може да се използва там, където се очаква `FnOnce`.
///
/// Използвайте `FnOnce` като обвързан, когато искате да приемете параметър от тип, подобен на функция и трябва да го извикате само веднъж.
/// Ако трябва да извикате параметъра многократно, използвайте [`FnMut`] като обвързан;ако имате нужда и от него, за да не мутирате състояние, използвайте [`Fn`].
///
/// Вижте [chapter on closures in *The Rust Programming Language*][book] за повече информация по тази тема.
///
/// Също така трябва да се отбележи специалният синтаксис за `Fn` traits (напр
/// `Fn(usize, bool) -> usize`).Тези, които се интересуват от техническите подробности за това, могат да се обърнат към [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Използване на параметър `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` консумира своите уловени променливи, така че не може да се изпълнява повече от веднъж.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Опитът да се извика `func()` отново ще доведе до грешка `use of moved value` за `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` вече не може да бъде извикан
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // така че regex да може да разчита на този `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Върнатият тип след използвания оператор на повикване.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Извършва операцията за повикване.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}