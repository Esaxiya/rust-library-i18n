/// Portrait за персонализиране на поведението на оператора `?`.
///
/// Тип, изпълняващ `Try`, е този, който има каноничен начин да го разглежда от гледна точка на дихотомия success/failure.
/// Този Portrait позволява както извличане на тези стойности за успех или неуспех от съществуващ екземпляр, така и създаване на нов екземпляр от стойност на успех или неуспех.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Типът на тази стойност, когато се счита за успешна.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Типът на тази стойност, когато се разглежда като неуспешен.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Прилага оператора "?".Връщането на `Ok(t)` означава, че изпълнението трябва да продължи нормално, а резултатът от `?` е стойността `t`.
    /// Връщането на `Err(e)` означава, че изпълнението трябва да branch към най-вътрешната заграждаща `catch`, или да се върне от функцията.
    ///
    /// Ако се върне резултат `Err(e)`, стойността `e` ще бъде "wrapped" в типа на връщане на обхващащия обхват (който сам трябва да реализира `Try`).
    ///
    /// По-точно се връща стойността `X::from_error(From::from(e))`, където `X` е типът на връщане на заграждащата функция.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Опаковайте стойност на грешка, за да изградите съставния резултат.
    /// Например `Result::Err(x)` и `Result::from_error(x)` са еквивалентни.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Опаковайте OK стойност, за да изградите съставния резултат.
    /// Например `Result::Ok(x)` и `Result::from_ok(x)` са еквивалентни.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}