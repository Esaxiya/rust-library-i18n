//! Оператори за прехвърляне.
//!
//! Внедряването на тези traits ви позволява да претоварвате определени оператори.
//!
//! Някои от тези traits са импортирани от prelude, така че те са достъпни във всяка програма Rust.Само оператори, подкрепени от traits, могат да бъдат претоварени.
//! Например, операторът на добавяне (`+`) може да бъде претоварен чрез [`Add`] Portrait, но тъй като операторът за присвояване (`=`) няма поддръжка на Portrait, няма начин да се претовари неговата семантика.
//! Освен това този модул не предоставя никакъв механизъм за създаване на нови оператори.
//! Ако се изискват безстепенно претоварване или персонализирани оператори, трябва да погледнете към макроси или плъгини на компилатора, за да разширите синтаксиса на Rust.
//!
//! Внедряванията на оператор traits не трябва да са изненадващи в съответните им контексти, като се имат предвид обичайните им значения и [operator precedence].
//! Например, когато внедрявате [`Mul`], операцията трябва да има известна прилика с умножението (и да споделя очаквани свойства като асоциативност).
//!
//! Имайте предвид, че операторите `&&` и `||` късо съединение, т.е. те оценяват втория си операнд само ако той допринася за резултата.Тъй като това поведение не може да се приложи от traits, `&&` и `||` не се поддържат като оператори за прехвърляне.
//!
//! Много от операторите вземат своите операнди по стойност.В негенерични контексти, включващи вградени типове, това обикновено не е проблем.
//! Използването на тези оператори в общ код обаче изисква известно внимание, ако стойностите трябва да бъдат използвани повторно, вместо да се позволява на операторите да ги консумират.Единият вариант е от време на време да използвате [`clone`].
//! Друг вариант е да разчитате на включените типове, предоставящи допълнителни операторски реализации за препратки.
//! Например, за потребителски дефиниран тип `T`, който трябва да поддържа добавяне, вероятно е добра идея `T` и `&T` да внедрят traits [`Add<T>`][`Add`] и [`Add<&T>`][`Add`], така че родовият код да може да бъде написан без ненужно клониране.
//!
//!
//! # Examples
//!
//! Този пример създава структура `Point`, която реализира [`Add`] и [`Sub`] и след това демонстрира добавяне и изваждане на две `Point`s.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Вижте документацията за всеки Portrait за пример за изпълнение.
//!
//! [`Fn`], [`FnMut`] и [`FnOnce`] traits се изпълняват от типове, които могат да бъдат извикани като функции.Имайте предвид, че [`Fn`] отнема `&self`, [`FnMut`] отнема `&mut self` и [`FnOnce`] отнема `self`.
//! Те съответстват на трите вида методи, които могат да бъдат извикани в даден екземпляр: обаждане по препратка, обаждане по променлива препратка и обаждане по стойност.
//! Най-честото използване на тези traits е да действат като граници на функции от по-високо ниво, които приемат функции или затваряния като аргументи.
//!
//! Вземане на [`Fn`] като параметър:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Вземане на [`FnMut`] като параметър:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Вземане на [`FnOnce`] като параметър:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` консумира своите уловени променливи, така че не може да се изпълнява повече от веднъж
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Опитът да се извика `func()` отново ще доведе до грешка `use of moved value` за `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` вече не може да бъде извикан
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;