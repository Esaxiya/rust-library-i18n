/// Използва се за неизменни операции за пренасочване, като `*v`.
///
/// Освен че се използва за изрични операции за пренасочване с оператор (unary) `*` в неизменни контексти, `Deref` се използва и имплицитно от компилатора при много обстоятелства.
/// Този механизъм се нарича ['`Deref` coercion'][more].
/// В изменяем контекст се използва [`DerefMut`].
///
/// Внедряването на `Deref` за интелигентни указатели прави достъпа до данните зад тях удобен, поради което те прилагат `Deref`.
/// От друга страна, правилата по отношение на `Deref` и [`DerefMut`] са създадени специално за настаняване на интелигентни указатели.
/// Поради това **" Deref` трябва да се прилага само за интелигентни указатели**, за да се избегне объркване.
///
/// По подобни причини **този Portrait никога не трябва да се проваля**.Неизправността по време на пренасочване може да бъде изключително объркваща, когато `Deref` се извика имплицитно.
///
/// # Повече за принудата `Deref`
///
/// Ако `T` реализира `Deref<Target = U>` и `x` е стойност от тип `T`, тогава:
///
/// * В неизменни контексти `*x` (където `T` не е нито референтен, нито суров указател) е еквивалентен на `* Deref::deref(&x)`.
/// * Стойностите от тип `&T` се принуждават към стойности от тип `&U`
/// * `T` имплицитно реализира всички методи (immutable) от типа `U`.
///
/// За повече подробности посетете [the chapter in *The Rust Programming Language*][book], както и справочните раздели за [the dereference operator][ref-deref-op], [method resolution] и [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Структура с едно поле, което е достъпно чрез пренасочване на структурата.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Полученият тип след пренасочване.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Преориентира стойността.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Използва се за променливи операции за пренасочване, като в `*v = 1;`.
///
/// Освен че се използва за изрични операции за пренасочване с оператор (unary) `*` в променлив контекст, `DerefMut` се използва и имплицитно от компилатора при много обстоятелства.
/// Този механизъм се нарича ['`Deref` coercion'][more].
/// В неизменни контексти се използва [`Deref`].
///
/// Внедряването на `DerefMut` за интелигентни указатели прави мутирането на данните зад тях удобно, поради което те прилагат `DerefMut`.
/// От друга страна, правилата по отношение на [`Deref`] и `DerefMut` са създадени специално за настаняване на интелигентни указатели.
/// Поради това **`DerefMut` трябва да се прилага само за интелигентни указатели**, за да се избегне объркване.
///
/// По подобни причини **този Portrait никога не трябва да се проваля**.Неизправността по време на пренасочване може да бъде изключително объркваща, когато `DerefMut` се извика имплицитно.
///
/// # Повече за принудата `Deref`
///
/// Ако `T` реализира `DerefMut<Target = U>` и `x` е стойност от тип `T`, тогава:
///
/// * В изменяеми контексти `*x` (където `T` не е нито референтен, нито суров указател) е еквивалентен на `* DerefMut::deref_mut(&mut x)`.
/// * Стойностите от тип `&mut T` се принуждават към стойности от тип `&mut U`
/// * `T` имплицитно реализира всички методи (mutable) от типа `U`.
///
/// За повече подробности посетете [the chapter in *The Rust Programming Language*][book], както и справочните раздели за [the dereference operator][ref-deref-op], [method resolution] и [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Структура с едно поле, което може да се модифицира чрез пренасочване на структурата.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Променя се пренасочването на стойността.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Показва, че структура може да се използва като приемник на метод, без функцията `arbitrary_self_types`.
///
/// Това се реализира от типове указатели stdlib като `Box<T>`, `Rc<T>`, `&T` и `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}