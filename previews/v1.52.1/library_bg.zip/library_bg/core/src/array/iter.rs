//! Определя притежавания от `IntoIter` итератор за масиви.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Итератор по стойност [array].
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Това е масивът, над който се итерираме.
    ///
    /// Елементи с индекс `i`, където `alive.start <= i < alive.end` все още не са получени и са валидни записи в масива.
    /// Елементи с индекси `i < alive.start` или `i >= alive.end` вече са предоставени и вече не трябва да бъдат достъпни!Тези мъртви елементи може дори да са в напълно неинициализирано състояние!
    ///
    ///
    /// И така, инвариантите са:
    /// - `data[alive]` е жив (т.е. съдържа валидни елементи)
    /// - `data[..alive.start]` и `data[alive.end..]` са мъртви (т.е. елементите вече са прочетени и не трябва да се пипат повече!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Елементите в `data`, които все още не са получени.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Създава нов итератор за дадения `array`.
    ///
    /// *Забележка*: този метод може да бъде остарял в future, след [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Типът `value` тук е `i32`, вместо `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // БЕЗОПАСНОСТ: Трансмутацията тук всъщност е безопасна.Документите на `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` гарантирано има еднакъв размер и подравняване
        // > като `T`.
        //
        // Документите дори показват трансмутация от масив `MaybeUninit<T>` в масив `T`.
        //
        //
        // С това тази инициализация удовлетворява инвариантите.

        // FIXME(LukasKalbertodt): всъщност използвайте `mem::transmute` тук, след като работи с const generics:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Дотогава можем да използваме `mem::transmute_copy`, за да създадем побитово копие като различен тип, след което да забравим `array`, за да не бъде изпуснато.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Връща неизменяем фрагмент от всички елементи, които все още не са получени.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // БЕЗОПАСНОСТ: Знаем, че всички елементи в `alive` са правилно инициализирани.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Връща изменяем фрагмент от всички елементи, които все още не са получени.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // БЕЗОПАСНОСТ: Знаем, че всички елементи в `alive` са правилно инициализирани.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Вземете следващия индекс отпред.
        //
        // Увеличаването на `alive.start` с 1 поддържа инварианта по отношение на `alive`.
        // Поради тази промяна обаче за кратко време живата зона вече не е `data[alive]`, а `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Прочетете елемента от масива.
            // БЕЗОПАСНОСТ: `idx` е индекс на бившия регион "alive" на
            // масив.Четенето на този елемент означава, че `data[idx]` сега се счита за мъртъв (т.е. не пипайте).
            // Тъй като `idx` беше началото на живата зона, сега живата зона отново е `data[alive]`, възстановявайки всички инварианти.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Вземете следващия индекс отзад.
        //
        // Намаляването на `alive.end` с 1 поддържа инварианта по отношение на `alive`.
        // Поради тази промяна обаче за кратко време живата зона вече не е `data[alive]`, а `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Прочетете елемента от масива.
            // БЕЗОПАСНОСТ: `idx` е индекс на бившия регион "alive" на
            // масив.Четенето на този елемент означава, че `data[idx]` сега се счита за мъртъв (т.е. не пипайте).
            // Тъй като `idx` беше края на живата зона, сега живата зона отново е `data[alive]`, възстановявайки всички инварианти.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // БЕЗОПАСНОСТ: Това е безопасно: `as_mut_slice` връща точно подреза
        // на елементи, които все още не са преместени и които остават за отпадане.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Никога няма да се разтопи поради инварианта `alive.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Итераторът наистина отчита правилната дължина.
// Броят на елементите "alive" (които все още ще бъдат получени) е дължината на диапазона `alive`.
// Този диапазон е намален по дължина или в `next`, или в `next_back`.
// Той винаги се намалява с 1 в тези методи, но само ако `Some(_)` бъде върнат.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Имайте предвид, че всъщност не е нужно да съвпадаме с точно същия обхват на живо, така че можем просто да клонираме в отместване 0, независимо къде е `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Клонирайте всички живи елементи.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Напишете клонинг в новия масив, след което актуализирайте неговия жив диапазон.
            // Ако клонирате panics, правилно ще изпуснем предишните елементи.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Отпечатвайте само елементите, които все още не са получени: вече не можем да осъществим достъп до получените елементи.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}