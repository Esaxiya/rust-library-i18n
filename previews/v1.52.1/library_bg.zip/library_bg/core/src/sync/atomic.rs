//! Атомни типове
//!
//! Атомните типове осигуряват примитивна комуникация със споделена памет между нишките и са градивните елементи на други едновременни типове.
//!
//! Този модул определя атомни версии на избран брой примитивни типове, включително [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`] и др.
//! Атомните типове представят операции, които, когато се използват правилно, синхронизират актуализациите между нишките.
//!
//! Всеки метод взема [`Ordering`], който представлява силата на бариерата на паметта за тази операция.Тези поръчки са същите като [C++20 atomic orderings][1].За повече информация вижте [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Атомните променливи са безопасни за споделяне между нишки (те изпълняват [`Sync`]), но те самите не осигуряват механизма за споделяне и следват [threading model](../../../std/thread/index.html#the-threading-model) на Rust.
//!
//! Най-често срещаният начин за споделяне на атомна променлива е поставянето й в [`Arc`][arc] (споделен указател с атомно преброяване).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Атомните типове могат да се съхраняват в статични променливи, инициализирани с помощта на константните инициализатори като [`AtomicBool::new`].Атомната статика често се използва за мързелива глобална инициализация.
//!
//! # Portability
//!
//! Всички атомни типове в този модул са гарантирано [lock-free], ако са налични.Това означава, че вътрешно не придобиват глобален мютекс.Не се гарантира, че атомните видове и операции са без изчакване.
//! Това означава, че операции като `fetch_or` могат да бъдат изпълнени с цикъл за сравнение и размяна.
//!
//! Атомни операции могат да бъдат реализирани в слоя инструкции с по-големи атоми.Например някои платформи използват 4-байтови атомни инструкции за внедряване на `AtomicI8`.
//! Имайте предвид, че тази емулация не трябва да оказва влияние върху коректността на кода, това е просто нещо, което трябва да знаете.
//!
//! Атомните типове в този модул може да не са налични на всички платформи.Атомните типове тук обаче са широко достъпни и обикновено могат да се разчитат на съществуващи.Някои забележителни изключения са:
//!
//! * PowerPC и платформите MIPS с 32-битови указатели нямат типове `AtomicU64` или `AtomicI64`.
//! * ARM платформи като `armv5te`, които не са за Linux, осигуряват само операции `load` и `store` и не поддържат операции за сравнение и размяна на (CAS), като `swap`, `fetch_add` и т.н.
//! Освен това на Linux, тези CAS операции се реализират чрез [operating system support], което може да дойде с наказание за изпълнение.
//! * ARM цели с `thumbv6m` осигуряват само операции `load` и `store` и не поддържат операции за сравнение и размяна на (CAS), като `swap`, `fetch_add` и др.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Имайте предвид, че могат да се добавят платформи future, които също нямат поддръжка за някои атомни операции.Максимално преносим код ще иска да внимава кои атомни типове се използват.
//! `AtomicUsize` и `AtomicIsize` обикновено са най-преносимите, но дори и тогава те не са налични навсякъде.
//! За справка, библиотеката `std` изисква атоми с размер на указател, въпреки че `core` не.
//!
//! В момента ще трябва да използвате `#[cfg(target_arch)]` предимно за условно компилиране в код с атоми.Има и нестабилен `#[cfg(target_has_atomic)]`, който може да бъде стабилизиран в future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Прост спинлок:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Изчакайте другата нишка да освободи ключалката
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Съхранявайте глобален брой живи нишки:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Булев тип, който може безопасно да се споделя между нишки.
///
/// Този тип има същото представяне в паметта като [`bool`].
///
/// **Забележка**: Този тип е достъпен само на платформи, които поддържат атомни товари и хранилища на `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Създава `AtomicBool`, инициализиран в `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Изпращането е имплицитно реализирано за AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Суров тип указател, който може безопасно да се споделя между нишки.
///
/// Този тип има същото представяне в паметта като `*mut T`.
///
/// **Забележка**: Този тип е достъпен само на платформи, които поддържат атомни товари и магазини на указатели.
/// Размерът му зависи от размера на целевия указател.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Създава нула `AtomicPtr<T>`.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Подреждане на атомна памет
///
/// Подреждането на паметта указва начина, по който атомните операции синхронизират паметта.
/// В най-слабия си [`Ordering::Relaxed`] се синхронизира само паметта, пряко докосната от операцията.
/// От друга страна, двойка от заредени хранилища операции [`Ordering::SeqCst`] синхронизират друга памет, като същевременно запазват общия ред на такива операции във всички нишки.
///
///
/// Поръчките на паметта на Rust са [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// За повече информация вижте [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Няма ограничения за подреждане, а само атомни операции.
    ///
    /// Съответства на [`memory_order_relaxed`] в C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Когато се свържат със запаметяване, всички предишни операции стават подредени преди всяко натоварване на тази стойност с [`Acquire`] (или по-силно) поръчване.
    ///
    /// По-специално, всички предишни записи стават видими за всички нишки, които изпълняват [`Acquire`] (или по-силно) натоварване на тази стойност.
    ///
    /// Забележете, че използването на тази поръчка за операция, която комбинира товари и съхранение, води до операция за зареждане [`Relaxed`]!
    ///
    /// Тази поръчка е приложима само за операции, които могат да изпълняват магазин.
    ///
    /// Съответства на [`memory_order_release`] в C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Когато е свързан с товар, ако заредената стойност е написана от операция на съхранение с [`Release`] (или по-силна) поръчка, тогава всички последващи операции стават подредени след това съхранение.
    /// По-специално, всички следващи зареждания ще виждат данни, записани преди съхранението.
    ///
    /// Забележете, че използването на тази поръчка за операция, която комбинира товари и съхранение, води до операция за съхранение [`Relaxed`]!
    ///
    /// Тази поръчка е приложима само за операции, които могат да изпълнят товар.
    ///
    /// Съответства на [`memory_order_acquire`] в C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Има ефектите както на [`Acquire`], така и на [`Release`] заедно:
    /// За товари използва [`Acquire`] поръчка.За магазини използва поръчката [`Release`].
    ///
    /// Забележете, че в случай на `compare_and_swap` е възможно операцията в крайна сметка да не извърши никакво съхранение и следователно тя има само [`Acquire`] поръчка.
    ///
    /// `AcqRel` обаче никога няма да извършва достъп до [`Relaxed`].
    ///
    /// Тази поръчка е приложима само за операции, които комбинират както товари, така и складове.
    ///
    /// Съответства на [`memory_order_acq_rel`] в C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Подобно на [`Acquire`]/[`Release`]/[`AcqRel`](съответно за зареждане, съхранение и зареждане със съхранение) с допълнителната гаранция, че всички нишки виждат всички последователно последователни операции в същия ред .
    ///
    ///
    /// Съответства на [`memory_order_seq_cst`] в C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// [`AtomicBool`], инициализиран в `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Създава нов `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Връща променлива препратка към основния [`bool`].
    ///
    /// Това е безопасно, тъй като изменяемата препратка гарантира, че никоя друга нишка не осъществява едновременен достъп до атомните данни.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // БЕЗОПАСНОСТ: изменяемата референция гарантира уникална собственост.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Получете атомен достъп до `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // БЕЗОПАСНОСТ: изменяемата референция гарантира уникална собственост и
        // подравняването на `bool` и `Self` е 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Консумира атома и връща съдържащата се стойност.
    ///
    /// Това е безопасно, защото предаването на `self` по стойност гарантира, че никоя друга нишка няма едновременен достъп до атомните данни.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Зарежда стойност от bool.
    ///
    /// `load` взема аргумент [`Ordering`], който описва подреждането на паметта на тази операция.
    /// Възможните стойности са [`SeqCst`], [`Acquire`] и [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, ако `order` е [`Release`] или [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // БЕЗОПАСНОСТ: всякакви състезания с данни се предотвратяват от атомни присъщи и сурови
        // указателят, предаден, е валиден, защото го получихме от препратка.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Съхранява стойност в bool.
    ///
    /// `store` взема аргумент [`Ordering`], който описва подреждането на паметта на тази операция.
    /// Възможните стойности са [`SeqCst`], [`Release`] и [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, ако `order` е [`Acquire`] или [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // БЕЗОПАСНОСТ: всякакви състезания с данни се предотвратяват от атомни присъщи и сурови
        // указателят, предаден, е валиден, защото го получихме от препратка.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Съхранява стойност в bool, връщайки предишната стойност.
    ///
    /// `swap` взема аргумент [`Ordering`], който описва подреждането на паметта на тази операция.Възможни са всички режими за поръчка.
    /// Имайте предвид, че използването на [`Acquire`] прави запаметяването част от тази операция [`Relaxed`], а използването на [`Release`] прави товара на [`Relaxed`].
    ///
    ///
    /// **Note:** Този метод е достъпен само на платформи, които поддържат атомни операции на `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // БЕЗОПАСНОСТ: състезанията с данни се предотвратяват от атомни присъщи.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Съхранява стойност в [`bool`], ако текущата стойност е същата като стойността на `current`.
    ///
    /// Връщаната стойност винаги е предишната стойност.Ако е равно на `current`, тогава стойността е актуализирана.
    ///
    /// `compare_and_swap` също взема аргумент [`Ordering`], който описва подреждането на паметта на тази операция.
    /// Забележете, че дори когато използвате [`AcqRel`], операцията може да се провали и следователно просто да изпълни `Acquire` натоварване, но да няма `Release` семантика.
    /// Използването на [`Acquire`] прави запаметяването част от тази операция [`Relaxed`], ако това се случи, а използването на [`Release`] прави зареждащата част [`Relaxed`].
    ///
    /// **Note:** Този метод е достъпен само на платформи, които поддържат атомни операции на `u8`.
    ///
    /// # Мигриране към `compare_exchange` и `compare_exchange_weak`
    ///
    /// `compare_and_swap` е еквивалентно на `compare_exchange` със следното картографиране за поръчки в паметта:
    ///
    /// Оригинал |Успех |Неуспех
    /// -------- | ------- | -------
    /// Спокойно |Спокойно |Спокойно придобиване |Придобиване |Придобиване на освобождаване |Освобождаване |Спокоен AcqRel |AcqRel |Придобиване на SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` е разрешено да се проваля фалшиво, дори когато сравнението успее, което позволява на компилатора да генерира по-добър код на сглобяване, когато сравнението и суапът се използват в цикъл.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Съхранява стойност в [`bool`], ако текущата стойност е същата като стойността на `current`.
    ///
    /// Връщаната стойност е резултат, показващ дали новата стойност е написана и съдържа ли предишната стойност.
    /// При успех тази стойност е гарантирано равна на `current`.
    ///
    /// `compare_exchange` отнема два аргумента [`Ordering`], за да опише подреждането на паметта на тази операция.
    /// `success` описва необходимата поръчка за операцията за четене-промяна-запис, която се извършва, ако сравнението с `current` успее.
    /// `failure` описва необходимата поръчка за операцията по зареждане, която се извършва, когато сравнението не успее.
    /// Използването на [`Acquire`] като успешна поръчка прави магазина част от тази операция [`Relaxed`], а използването на [`Release`] прави успешното зареждане [`Relaxed`].
    ///
    /// Подреждането на неизправността може да бъде само [`SeqCst`], [`Acquire`] или [`Relaxed`] и трябва да бъде равностойно или по-слабо от поръчката за успех.
    ///
    /// **Note:** Този метод е достъпен само на платформи, които поддържат атомни операции на `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // БЕЗОПАСНОСТ: състезанията с данни се предотвратяват от атомни присъщи.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Съхранява стойност в [`bool`], ако текущата стойност е същата като стойността на `current`.
    ///
    /// За разлика от [`AtomicBool::compare_exchange`], на тази функция е позволено да се проваля фалшиво, дори когато сравнението успее, което може да доведе до по-ефективен код на някои платформи.
    ///
    /// Връщаната стойност е резултат, показващ дали новата стойност е написана и съдържа ли предишната стойност.
    ///
    /// `compare_exchange_weak` отнема два аргумента [`Ordering`], за да опише подреждането на паметта на тази операция.
    /// `success` описва необходимата поръчка за операцията за четене-промяна-запис, която се извършва, ако сравнението с `current` успее.
    /// `failure` описва необходимата поръчка за операцията по зареждане, която се извършва, когато сравнението не успее.
    /// Използването на [`Acquire`] като успешна поръчка прави магазина част от тази операция [`Relaxed`], а използването на [`Release`] прави успешното зареждане [`Relaxed`].
    /// Подреждането на неизправността може да бъде само [`SeqCst`], [`Acquire`] или [`Relaxed`] и трябва да бъде равностойно или по-слабо от поръчката за успех.
    ///
    /// **Note:** Този метод е достъпен само на платформи, които поддържат атомни операции на `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // БЕЗОПАСНОСТ: състезанията с данни се предотвратяват от атомни присъщи.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Логически "and" с булева стойност.
    ///
    /// Извършва логическа операция "and" върху текущата стойност и аргумента `val` и задава новата стойност на резултата.
    ///
    /// Връща предишната стойност.
    ///
    /// `fetch_and` взема аргумент [`Ordering`], който описва подреждането на паметта на тази операция.Възможни са всички режими за поръчка.
    /// Имайте предвид, че използването на [`Acquire`] прави запаметяването част от тази операция [`Relaxed`], а използването на [`Release`] прави товара на [`Relaxed`].
    ///
    ///
    /// **Note:** Този метод е достъпен само на платформи, които поддържат атомни операции на `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // БЕЗОПАСНОСТ: състезанията с данни се предотвратяват от атомни присъщи.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Логически "nand" с булева стойност.
    ///
    /// Извършва логическа операция "nand" върху текущата стойност и аргумента `val` и задава новата стойност на резултата.
    ///
    /// Връща предишната стойност.
    ///
    /// `fetch_nand` взема аргумент [`Ordering`], който описва подреждането на паметта на тази операция.Възможни са всички режими за поръчка.
    /// Имайте предвид, че използването на [`Acquire`] прави запаметяването част от тази операция [`Relaxed`], а използването на [`Release`] прави товара на [`Relaxed`].
    ///
    ///
    /// **Note:** Този метод е достъпен само на платформи, които поддържат атомни операции на `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Тук не можем да използваме atomic_nand, защото това може да доведе до bool с невалидна стойност.
        // Това се случва, защото атомната операция се извършва с 8-битово цяло число вътре, което би задало горните 7 бита.
        //
        // Затова вместо това просто използваме fetch_xor или swap.
        if val {
            // ! (x&true)== !x Трябва да обърнем bool.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true Трябва да зададем bool на true.
            //
            self.swap(true, order)
        }
    }

    /// Логически "or" с булева стойност.
    ///
    /// Извършва логическа операция "or" върху текущата стойност и аргумента `val` и задава новата стойност на резултата.
    ///
    /// Връща предишната стойност.
    ///
    /// `fetch_or` взема аргумент [`Ordering`], който описва подреждането на паметта на тази операция.Възможни са всички режими за поръчка.
    /// Имайте предвид, че използването на [`Acquire`] прави запаметяването част от тази операция [`Relaxed`], а използването на [`Release`] прави товара на [`Relaxed`].
    ///
    ///
    /// **Note:** Този метод е достъпен само на платформи, които поддържат атомни операции на `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // БЕЗОПАСНОСТ: състезанията с данни се предотвратяват от атомни присъщи.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Логически "xor" с булева стойност.
    ///
    /// Извършва логическа операция "xor" върху текущата стойност и аргумента `val` и задава новата стойност на резултата.
    ///
    /// Връща предишната стойност.
    ///
    /// `fetch_xor` взема аргумент [`Ordering`], който описва подреждането на паметта на тази операция.Възможни са всички режими за поръчка.
    /// Имайте предвид, че използването на [`Acquire`] прави запаметяването част от тази операция [`Relaxed`], а използването на [`Release`] прави товара на [`Relaxed`].
    ///
    ///
    /// **Note:** Този метод е достъпен само на платформи, които поддържат атомни операции на `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // БЕЗОПАСНОСТ: състезанията с данни се предотвратяват от атомни присъщи.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Връща променлив указател към основния [`bool`].
    ///
    /// Извършването на неатомно четене и запис на полученото цяло число може да бъде състезание за данни.
    /// Този метод е най-полезен за FFI, където подписът на функцията може да използва `*mut bool` вместо `&AtomicBool`.
    ///
    /// Връщането на `*mut` указател от споделена препратка към този атом е безопасно, тъй като атомните типове работят с вътрешна променливост.
    /// Всички модификации на атома променят стойността чрез споделена препратка и могат да го направят безопасно, стига да използват атомни операции.
    /// Всяко използване на върнатия суров указател изисква блок `unsafe` и все още трябва да спазва същото ограничение: операциите върху него трябва да са атомни.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Извлича стойността и прилага функция към нея, която връща по избор нова стойност.Връща `Result` от `Ok(previous_value)`, ако функцията е върнала `Some(_)`, иначе `Err(previous_value)`.
    ///
    /// Note: Това може да извика функцията няколко пъти, ако междувременно стойността е била променена от други нишки, стига функцията да връща `Some(_)`, но функцията ще бъде приложена само веднъж към съхранената стойност.
    ///
    ///
    /// `fetch_update` отнема два аргумента [`Ordering`], за да опише подреждането на паметта на тази операция.
    /// Първият описва необходимата поръчка за това кога операцията най-накрая е успешна, докато втората описва необходимата поръчка за товари.
    /// Те съответстват на поръчките за успех и неуспех на [`AtomicBool::compare_exchange`] съответно.
    ///
    /// Използването на [`Acquire`] като успешна поръчка прави магазина част от тази операция [`Relaxed`], а използването на [`Release`] прави окончателното успешно зареждане [`Relaxed`].
    /// Поръчването на натоварване (failed) може да бъде само [`SeqCst`], [`Acquire`] или [`Relaxed`] и трябва да бъде равностойно или по-слабо от поръчката за успех.
    ///
    /// **Note:** Този метод е достъпен само на платформи, които поддържат атомни операции на `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Създава нов `AtomicPtr`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Връща променлива препратка към основния указател.
    ///
    /// Това е безопасно, тъй като изменяемата препратка гарантира, че никоя друга нишка не осъществява едновременен достъп до атомните данни.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Получете атомен достъп до указател.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - изменяемата референция гарантира уникална собственост.
        //  - подравняването на `*mut T` и `Self` е еднакво на всички платформи, поддържани от rust, както е потвърдено по-горе.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Консумира атома и връща съдържащата се стойност.
    ///
    /// Това е безопасно, защото предаването на `self` по стойност гарантира, че никоя друга нишка няма едновременен достъп до атомните данни.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Зарежда стойност от показалеца.
    ///
    /// `load` взема аргумент [`Ordering`], който описва подреждането на паметта на тази операция.
    /// Възможните стойности са [`SeqCst`], [`Acquire`] и [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, ако `order` е [`Release`] или [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // БЕЗОПАСНОСТ: състезанията с данни се предотвратяват от атомни присъщи.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Съхранява стойност в указателя.
    ///
    /// `store` взема аргумент [`Ordering`], който описва подреждането на паметта на тази операция.
    /// Възможните стойности са [`SeqCst`], [`Release`] и [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, ако `order` е [`Acquire`] или [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // БЕЗОПАСНОСТ: състезанията с данни се предотвратяват от атомни присъщи.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Съхранява стойност в указателя, връщайки предишната стойност.
    ///
    /// `swap` взема аргумент [`Ordering`], който описва подреждането на паметта на тази операция.Възможни са всички режими за поръчка.
    /// Имайте предвид, че използването на [`Acquire`] прави запаметяването част от тази операция [`Relaxed`], а използването на [`Release`] прави товара на [`Relaxed`].
    ///
    ///
    /// **Note:** Този метод е достъпен само на платформи, които поддържат атомни операции върху указатели.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // БЕЗОПАСНОСТ: състезанията с данни се предотвратяват от атомни присъщи.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Съхранява стойност в указателя, ако текущата стойност е същата като стойността на `current`.
    ///
    /// Връщаната стойност винаги е предишната стойност.Ако е равно на `current`, тогава стойността е актуализирана.
    ///
    /// `compare_and_swap` също взема аргумент [`Ordering`], който описва подреждането на паметта на тази операция.
    /// Забележете, че дори когато използвате [`AcqRel`], операцията може да се провали и следователно просто да изпълни `Acquire` натоварване, но да няма `Release` семантика.
    /// Използването на [`Acquire`] прави запаметяването част от тази операция [`Relaxed`], ако това се случи, а използването на [`Release`] прави зареждащата част [`Relaxed`].
    ///
    /// **Note:** Този метод е достъпен само на платформи, които поддържат атомни операции върху указатели.
    ///
    /// # Мигриране към `compare_exchange` и `compare_exchange_weak`
    ///
    /// `compare_and_swap` е еквивалентно на `compare_exchange` със следното картографиране за поръчки в паметта:
    ///
    /// Оригинал |Успех |Неуспех
    /// -------- | ------- | -------
    /// Спокойно |Спокойно |Спокойно придобиване |Придобиване |Придобиване на освобождаване |Освобождаване |Спокоен AcqRel |AcqRel |Придобиване на SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` е разрешено да се проваля фалшиво, дори когато сравнението успее, което позволява на компилатора да генерира по-добър код на сглобяване, когато сравнението и суапът се използват в цикъл.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Съхранява стойност в указателя, ако текущата стойност е същата като стойността на `current`.
    ///
    /// Връщаната стойност е резултат, показващ дали новата стойност е написана и съдържа ли предишната стойност.
    /// При успех тази стойност е гарантирано равна на `current`.
    ///
    /// `compare_exchange` отнема два аргумента [`Ordering`], за да опише подреждането на паметта на тази операция.
    /// `success` описва необходимата поръчка за операцията за четене-промяна-запис, която се извършва, ако сравнението с `current` успее.
    /// `failure` описва необходимата поръчка за операцията по зареждане, която се извършва, когато сравнението не успее.
    /// Използването на [`Acquire`] като успешна поръчка прави магазина част от тази операция [`Relaxed`], а използването на [`Release`] прави успешното зареждане [`Relaxed`].
    ///
    /// Подреждането на неизправността може да бъде само [`SeqCst`], [`Acquire`] или [`Relaxed`] и трябва да бъде равностойно или по-слабо от поръчката за успех.
    ///
    /// **Note:** Този метод е достъпен само на платформи, които поддържат атомни операции върху указатели.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // БЕЗОПАСНОСТ: състезанията с данни се предотвратяват от атомни присъщи.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Съхранява стойност в указателя, ако текущата стойност е същата като стойността на `current`.
    ///
    /// За разлика от [`AtomicPtr::compare_exchange`], на тази функция е позволено да се проваля фалшиво, дори когато сравнението успее, което може да доведе до по-ефективен код на някои платформи.
    ///
    /// Връщаната стойност е резултат, показващ дали новата стойност е написана и съдържа ли предишната стойност.
    ///
    /// `compare_exchange_weak` отнема два аргумента [`Ordering`], за да опише подреждането на паметта на тази операция.
    /// `success` описва необходимата поръчка за операцията за четене-промяна-запис, която се извършва, ако сравнението с `current` успее.
    /// `failure` описва необходимата поръчка за операцията по зареждане, която се извършва, когато сравнението не успее.
    /// Използването на [`Acquire`] като успешна поръчка прави магазина част от тази операция [`Relaxed`], а използването на [`Release`] прави успешното зареждане [`Relaxed`].
    /// Подреждането на неизправността може да бъде само [`SeqCst`], [`Acquire`] или [`Relaxed`] и трябва да бъде равностойно или по-слабо от поръчката за успех.
    ///
    /// **Note:** Този метод е достъпен само на платформи, които поддържат атомни операции върху указатели.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // БЕЗОПАСНОСТ: Това присъщо е опасно, защото работи върху суров указател
        // но със сигурност знаем, че указателят е валиден (току-що го получихме от `UnsafeCell`, който имаме чрез препратка) и самата атомна операция ни позволява безопасно да мутираме съдържанието на `UnsafeCell`.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Извлича стойността и прилага функция към нея, която връща по избор нова стойност.Връща `Result` от `Ok(previous_value)`, ако функцията е върнала `Some(_)`, иначе `Err(previous_value)`.
    ///
    /// Note: Това може да извика функцията няколко пъти, ако междувременно стойността е била променена от други нишки, стига функцията да връща `Some(_)`, но функцията ще бъде приложена само веднъж към съхранената стойност.
    ///
    ///
    /// `fetch_update` отнема два аргумента [`Ordering`], за да опише подреждането на паметта на тази операция.
    /// Първият описва необходимата поръчка за това кога операцията най-накрая е успешна, докато втората описва необходимата поръчка за товари.
    /// Те съответстват на поръчките за успех и неуспех на [`AtomicPtr::compare_exchange`] съответно.
    ///
    /// Използването на [`Acquire`] като успешна поръчка прави магазина част от тази операция [`Relaxed`], а използването на [`Release`] прави окончателното успешно зареждане [`Relaxed`].
    /// Поръчването на натоварване (failed) може да бъде само [`SeqCst`], [`Acquire`] или [`Relaxed`] и трябва да бъде равностойно или по-слабо от поръчката за успех.
    ///
    /// **Note:** Този метод е достъпен само на платформи, които поддържат атомни операции върху указатели.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Преобразува `bool` в `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Този макрос се оказва неизползван в някои архитектури.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Целочислен тип, който може безопасно да се споделя между нишки.
        ///
        /// Този тип има същото представяне в паметта като основния целочислен тип, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// За повече информация относно разликите между атомни типове и неатомни типове, както и информация за преносимостта на този тип, моля, вижте [module-level documentation].
        ///
        ///
        /// **Note:** Този тип е достъпен само на платформи, които поддържат атомни товари и магазини на [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Атомно цяло число, инициализирано в `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Изпращането е имплицитно реализирано.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Създава ново атомно цяло число.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Връща изменяема препратка към основното цяло число.
            ///
            /// Това е безопасно, тъй като изменяемата препратка гарантира, че никоя друга нишка не осъществява едновременен достъп до атомните данни.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// нека mut някои_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - изменяемата референция гарантира уникална собственост.
                //  - подравняването на `$int_type` и `Self` е същото, както беше обещано от $cfg_align и проверено по-горе.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Консумира атома и връща съдържащата се стойност.
            ///
            /// Това е безопасно, защото предаването на `self` по стойност гарантира, че никоя друга нишка няма едновременен достъп до атомните данни.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Зарежда стойност от атомното цяло число.
            ///
            /// `load` взема аргумент [`Ordering`], който описва подреждането на паметта на тази операция.
            /// Възможните стойности са [`SeqCst`], [`Acquire`] и [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics, ако `order` е [`Release`] или [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // БЕЗОПАСНОСТ: състезанията с данни се предотвратяват от атомни присъщи.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Съхранява стойност в атомното цяло число.
            ///
            /// `store` взема аргумент [`Ordering`], който описва подреждането на паметта на тази операция.
            ///  Възможните стойности са [`SeqCst`], [`Release`] и [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics, ако `order` е [`Acquire`] или [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // БЕЗОПАСНОСТ: състезанията с данни се предотвратяват от атомни присъщи.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Съхранява стойност в атомно цяло число, връщайки предишната стойност.
            ///
            /// `swap` взема аргумент [`Ordering`], който описва подреждането на паметта на тази операция.Възможни са всички режими за поръчка.
            /// Имайте предвид, че използването на [`Acquire`] прави запаметяването част от тази операция [`Relaxed`], а използването на [`Release`] прави товара на [`Relaxed`].
            ///
            ///
            /// **Забележка**: Този метод е достъпен само на платформи, които поддържат атомни операции на
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕЗОПАСНОСТ: състезанията с данни се предотвратяват от атомни присъщи.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Съхранява стойност в атомно цяло число, ако текущата стойност е същата като стойността `current`.
            ///
            /// Връщаната стойност винаги е предишната стойност.Ако е равно на `current`, тогава стойността е актуализирана.
            ///
            /// `compare_and_swap` също взема аргумент [`Ordering`], който описва подреждането на паметта на тази операция.
            /// Забележете, че дори когато използвате [`AcqRel`], операцията може да се провали и следователно просто да изпълни `Acquire` натоварване, но да няма `Release` семантика.
            ///
            /// Използването на [`Acquire`] прави запаметяването част от тази операция [`Relaxed`], ако това се случи, а използването на [`Release`] прави зареждащата част [`Relaxed`].
            ///
            /// **Забележка**: Този метод е достъпен само на платформи, които поддържат атомни операции на
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Мигриране към `compare_exchange` и `compare_exchange_weak`
            ///
            /// `compare_and_swap` е еквивалентно на `compare_exchange` със следното картографиране за поръчки в паметта:
            ///
            /// Оригинал |Успех |Неуспех
            /// -------- | ------- | -------
            /// Спокойно |Спокойно |Спокойно придобиване |Придобиване |Придобиване на освобождаване |Освобождаване |Спокоен AcqRel |AcqRel |Придобиване на SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` е разрешено да се проваля фалшиво, дори когато сравнението успее, което позволява на компилатора да генерира по-добър код на сглобяване, когато сравнението и суапът се използват в цикъл.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Съхранява стойност в атомно цяло число, ако текущата стойност е същата като стойността `current`.
            ///
            /// Връщаната стойност е резултат, показващ дали новата стойност е написана и съдържа ли предишната стойност.
            /// При успех тази стойност е гарантирано равна на `current`.
            ///
            /// `compare_exchange` отнема два аргумента [`Ordering`], за да опише подреждането на паметта на тази операция.
            /// `success` описва необходимата поръчка за операцията за четене-промяна-запис, която се извършва, ако сравнението с `current` успее.
            /// `failure` описва необходимата поръчка за операцията по зареждане, която се извършва, когато сравнението не успее.
            /// Използването на [`Acquire`] като успешна поръчка прави магазина част от тази операция [`Relaxed`], а използването на [`Release`] прави успешното зареждане [`Relaxed`].
            ///
            /// Подреждането на неизправността може да бъде само [`SeqCst`], [`Acquire`] или [`Relaxed`] и трябва да бъде равностойно или по-слабо от поръчката за успех.
            ///
            /// **Забележка**: Този метод е достъпен само на платформи, които поддържат атомни операции на
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // БЕЗОПАСНОСТ: състезанията с данни се предотвратяват от атомни присъщи.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Съхранява стойност в атомно цяло число, ако текущата стойност е същата като стойността `current`.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// тази функция може да се проваля фалшиво, дори когато сравнението успее, което може да доведе до по-ефективен код на някои платформи.
            /// Връщаната стойност е резултат, показващ дали новата стойност е написана и съдържа ли предишната стойност.
            ///
            /// `compare_exchange_weak` отнема два аргумента [`Ordering`], за да опише подреждането на паметта на тази операция.
            /// `success` описва необходимата поръчка за операцията за четене-промяна-запис, която се извършва, ако сравнението с `current` успее.
            /// `failure` описва необходимата поръчка за операцията по зареждане, която се извършва, когато сравнението не успее.
            /// Използването на [`Acquire`] като успешна поръчка прави магазина част от тази операция [`Relaxed`], а използването на [`Release`] прави успешното зареждане [`Relaxed`].
            ///
            /// Подреждането на неизправността може да бъде само [`SeqCst`], [`Acquire`] или [`Relaxed`] и трябва да бъде равностойно или по-слабо от поръчката за успех.
            ///
            /// **Забележка**: Този метод е достъпен само на платформи, които поддържат атомни операции на
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// нека mut old= val.load(Ordering::Relaxed);
            /// цикъл {нека нов=стар * 2;
            ///     съвпадение val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // БЕЗОПАСНОСТ: състезанията с данни се предотвратяват от атомни присъщи.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Добавя към текущата стойност, връщайки предишната стойност.
            ///
            /// Тази операция се увива при преливане.
            ///
            /// `fetch_add` взема аргумент [`Ordering`], който описва подреждането на паметта на тази операция.Възможни са всички режими за поръчка.
            /// Имайте предвид, че използването на [`Acquire`] прави запаметяването част от тази операция [`Relaxed`], а използването на [`Release`] прави товара на [`Relaxed`].
            ///
            ///
            /// **Забележка**: Този метод е достъпен само на платформи, които поддържат атомни операции на
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕЗОПАСНОСТ: състезанията с данни се предотвратяват от атомни присъщи.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Изважда се от текущата стойност, връщайки предишната стойност.
            ///
            /// Тази операция се увива при преливане.
            ///
            /// `fetch_sub` взема аргумент [`Ordering`], който описва подреждането на паметта на тази операция.Възможни са всички режими за поръчка.
            /// Имайте предвид, че използването на [`Acquire`] прави запаметяването част от тази операция [`Relaxed`], а използването на [`Release`] прави товара на [`Relaxed`].
            ///
            ///
            /// **Забележка**: Този метод е достъпен само на платформи, които поддържат атомни операции на
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕЗОПАСНОСТ: състезанията с данни се предотвратяват от атомни присъщи.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Побитово "and" с текущата стойност.
            ///
            /// Извършва битова операция "and" върху текущата стойност и аргумента `val` и задава новата стойност на резултата.
            ///
            /// Връща предишната стойност.
            ///
            /// `fetch_and` взема аргумент [`Ordering`], който описва подреждането на паметта на тази операция.Възможни са всички режими за поръчка.
            /// Имайте предвид, че използването на [`Acquire`] прави запаметяването част от тази операция [`Relaxed`], а използването на [`Release`] прави товара на [`Relaxed`].
            ///
            ///
            /// **Забележка**: Този метод е достъпен само на платформи, които поддържат атомни операции на
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕЗОПАСНОСТ: състезанията с данни се предотвратяват от атомни присъщи.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Побитово "nand" с текущата стойност.
            ///
            /// Извършва битова операция "nand" върху текущата стойност и аргумента `val` и задава новата стойност на резултата.
            ///
            /// Връща предишната стойност.
            ///
            /// `fetch_nand` взема аргумент [`Ordering`], който описва подреждането на паметта на тази операция.Възможни са всички режими за поръчка.
            /// Имайте предвид, че използването на [`Acquire`] прави запаметяването част от тази операция [`Relaxed`], а използването на [`Release`] прави товара на [`Relaxed`].
            ///
            ///
            /// **Забележка**: Този метод е достъпен само на платформи, които поддържат атомни операции на
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕЗОПАСНОСТ: състезанията с данни се предотвратяват от атомни присъщи.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Побитово "or" с текущата стойност.
            ///
            /// Извършва битова операция "or" върху текущата стойност и аргумента `val` и задава новата стойност на резултата.
            ///
            /// Връща предишната стойност.
            ///
            /// `fetch_or` взема аргумент [`Ordering`], който описва подреждането на паметта на тази операция.Възможни са всички режими за поръчка.
            /// Имайте предвид, че използването на [`Acquire`] прави запаметяването част от тази операция [`Relaxed`], а използването на [`Release`] прави товара на [`Relaxed`].
            ///
            ///
            /// **Забележка**: Този метод е достъпен само на платформи, които поддържат атомни операции на
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕЗОПАСНОСТ: състезанията с данни се предотвратяват от атомни присъщи.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Побитово "xor" с текущата стойност.
            ///
            /// Извършва битова операция "xor" върху текущата стойност и аргумента `val` и задава новата стойност на резултата.
            ///
            /// Връща предишната стойност.
            ///
            /// `fetch_xor` взема аргумент [`Ordering`], който описва подреждането на паметта на тази операция.Възможни са всички режими за поръчка.
            /// Имайте предвид, че използването на [`Acquire`] прави запаметяването част от тази операция [`Relaxed`], а използването на [`Release`] прави товара на [`Relaxed`].
            ///
            ///
            /// **Забележка**: Този метод е достъпен само на платформи, които поддържат атомни операции на
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕЗОПАСНОСТ: състезанията с данни се предотвратяват от атомни присъщи.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Извлича стойността и прилага функция към нея, която връща по избор нова стойност.Връща `Result` от `Ok(previous_value)`, ако функцията е върнала `Some(_)`, иначе `Err(previous_value)`.
            ///
            /// Note: Това може да извика функцията няколко пъти, ако междувременно стойността е била променена от други нишки, стига функцията да връща `Some(_)`, но функцията ще бъде приложена само веднъж към съхранената стойност.
            ///
            ///
            /// `fetch_update` отнема два аргумента [`Ordering`], за да опише подреждането на паметта на тази операция.
            /// Първият описва необходимата поръчка за това кога операцията най-накрая е успешна, докато втората описва необходимата поръчка за товари.Те съответстват на поръчките за успех и неуспех на
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Използването на [`Acquire`] като успешна поръчка прави магазина част от тази операция [`Relaxed`], а използването на [`Release`] прави окончателното успешно зареждане [`Relaxed`].
            /// Поръчването на натоварване (failed) може да бъде само [`SeqCst`], [`Acquire`] или [`Relaxed`] и трябва да бъде равностойно или по-слабо от поръчката за успех.
            ///
            /// **Забележка**: Този метод е достъпен само на платформи, които поддържат атомни операции на
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Подреждане: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Подреждане: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Максимум с текущата стойност.
            ///
            /// Намира максимума на текущата стойност и аргумента `val` и задава новата стойност на резултата.
            ///
            /// Връща предишната стойност.
            ///
            /// `fetch_max` взема аргумент [`Ordering`], който описва подреждането на паметта на тази операция.Възможни са всички режими за поръчка.
            /// Имайте предвид, че използването на [`Acquire`] прави запаметяването част от тази операция [`Relaxed`], а използването на [`Release`] прави товара на [`Relaxed`].
            ///
            ///
            /// **Забележка**: Този метод е достъпен само на платформи, които поддържат атомни операции на
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// нека бар=42;
            /// нека max_foo=foo.fetch_max (бар, Ordering::SeqCst).max(bar);
            /// твърди! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕЗОПАСНОСТ: състезанията с данни се предотвратяват от атомни присъщи.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Минимум с текущата стойност.
            ///
            /// Намира минимума на текущата стойност и аргумента `val` и задава новата стойност на резултата.
            ///
            /// Връща предишната стойност.
            ///
            /// `fetch_min` взема аргумент [`Ordering`], който описва подреждането на паметта на тази операция.Възможни са всички режими за поръчка.
            /// Имайте предвид, че използването на [`Acquire`] прави запаметяването част от тази операция [`Relaxed`], а използването на [`Release`] прави товара на [`Relaxed`].
            ///
            ///
            /// **Забележка**: Този метод е достъпен само на платформи, които поддържат атомни операции на
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// нека лента=12;
            /// нека min_foo=foo.fetch_min (бар, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕЗОПАСНОСТ: състезанията с данни се предотвратяват от атомни присъщи.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Връща изменяем указател към основното цяло число.
            ///
            /// Извършването на неатомно четене и запис на полученото цяло число може да бъде състезание за данни.
            /// Този метод е най-полезен за FFI, където подписът на функцията може да използва
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Връщането на `*mut` указател от споделена препратка към този атом е безопасно, тъй като атомните типове работят с вътрешна променливост.
            /// Всички модификации на атома променят стойността чрез споделена препратка и могат да го направят безопасно, стига да използват атомни операции.
            /// Всяко използване на върнатия суров указател изисква блок `unsafe` и все още трябва да спазва същото ограничение: операциите върху него трябва да са атомни.
            ///
            ///
            /// # Examples
            ///
            /// " игнорирайте (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// външен "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // БЕЗОПАСНОСТ: Безопасен, докато `my_atomic_op` е атомен.
            /// небезопасно {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // БЕЗОПАСНОСТ: повикващият трябва да спазва договора за безопасност за `atomic_store`.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // БЕЗОПАСНОСТ: повикващият трябва да спазва договора за безопасност за `atomic_load`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗОПАСНОСТ: повикващият трябва да спазва договора за безопасност за `atomic_swap`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Връща предишната стойност (като __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗОПАСНОСТ: повикващият трябва да спазва договора за безопасност за `atomic_add`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Връща предишната стойност (като __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗОПАСНОСТ: повикващият трябва да спазва договора за безопасност за `atomic_sub`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // БЕЗОПАСНОСТ: повикващият трябва да спазва договора за безопасност за `atomic_compare_exchange`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // БЕЗОПАСНОСТ: повикващият трябва да спазва договора за безопасност за `atomic_compare_exchange_weak`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗОПАСНОСТ: повикващият трябва да спазва договора за безопасност за `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗОПАСНОСТ: повикващият трябва да спазва договора за безопасност за `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗОПАСНОСТ: повикващият трябва да спазва договора за безопасност за `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗОПАСНОСТ: повикващият трябва да спазва договора за безопасност за `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// връща максималната стойност (подписано сравнение)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗОПАСНОСТ: повикващият трябва да спазва договора за безопасност за `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// връща минималната стойност (подписано сравнение)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗОПАСНОСТ: повикващият трябва да спазва договора за безопасност за `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// връща максималната стойност (неподписано сравнение)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗОПАСНОСТ: повикващият трябва да спазва договора за безопасност за `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// връща минималната стойност (неподписано сравнение)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕЗОПАСНОСТ: повикващият трябва да спазва договора за безопасност за `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Атомна ограда.
///
/// В зависимост от посочения ред, оградата не позволява на компилатора и процесора да пренареждат определени видове операции с памет около него.
/// Това създава синхронизиране-с връзките между него и атомни операции или огради в други нишки.
///
/// Ограда 'A', която има (поне) [`Release`], подреждаща семантика, се синхронизира с ограда 'B' с (поне) [`Acquire`] семантика, ако и само ако съществуват операции X и Y, и двете действащи върху някакъв атомен обект 'M', така че A е секвенирана преди X, Y се синхронизира преди B и Y наблюдава промяната в M.
/// Това осигурява зависимост между A и B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Атомните операции със семантиката [`Release`] или [`Acquire`] също могат да се синхронизират с ограда.
///
/// Ограда, която има [`SeqCst`] подреждане, освен че има семантика [`Acquire`] и [`Release`], участва в глобалната програмна поръчка на другите операции [`SeqCst`] и/или огради.
///
/// Приема поръчки [`Acquire`], [`Release`], [`AcqRel`] и [`SeqCst`].
///
/// # Panics
///
/// Panics, ако `order` е [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Примитив за взаимно изключване, основан на спинлок.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Изчакайте, докато старата стойност е `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Тази ограда се синхронизира-с магазин в `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // БЕЗОПАСНОСТ: използването на атомна ограда е безопасно.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Ограда на паметта на компилатора.
///
/// `compiler_fence` не излъчва машинен код, но ограничава видовете памет, които пренареждат на компилатора.По-конкретно, в зависимост от дадената семантика [`Ordering`], на компилатора може да бъде забранено да премества четене или запис от преди или след обаждането към другата страна на повикването към `compiler_fence`.Имайте предвид, че **не** пречи на *хардуера* да прави такова пренареждане.
///
/// Това не е проблем в еднонишковия контекст на изпълнение, но когато други нишки могат да модифицират паметта едновременно, се изискват по-силни примитиви за синхронизация като [`fence`].
///
/// Пренареждането, предотвратено от различните семантики за подреждане, е:
///
///  - с [`SeqCst`] не е разрешено пренареждане на четене и запис в тази точка.
///  - с [`Release`], предходните четения и записи не могат да бъдат премествани от последващи записи.
///  - с [`Acquire`] последващите четения и записи не могат да бъдат премествани преди предходните четения.
///  - с [`AcqRel`] се прилагат и двете горепосочени правила.
///
/// `compiler_fence` обикновено е полезен само за предотвратяване на нишка да се състезава *със себе си*.Тоест, ако дадена нишка изпълнява една част от кода и след това се прекъсва и започва да изпълнява код другаде (докато все още е в същата нишка и концептуално все още е в същото ядро).В традиционните програми това може да се случи само когато е регистриран манипулатор на сигнали.
/// В по-ниско ниво код такива ситуации могат да възникнат и при обработка на прекъсвания, при внедряване на зелени нишки с изпреварване и т.н.
/// Любопитните читатели се насърчават да прочетат дискусията на ядрото Linux за [memory barriers].
///
/// # Panics
///
/// Panics, ако `order` е [`Relaxed`].
///
/// # Examples
///
/// Без `compiler_fence`, `assert_eq!` в следващия код *не* гарантирано ще успее, въпреки всичко, което се случва в една нишка.
/// За да разберете защо, не забравяйте, че компилаторът може да сменя магазините на `IMPORTANT_VARIABLE` и `IS_READ`, тъй като и двете са `Ordering::Relaxed`.Ако го направи и манипулаторът на сигнал се извиква веднага след актуализирането на `IS_READY`, тогава манипулаторът на сигнала ще види `IS_READY=1`, но `IMPORTANT_VARIABLE=0`.
/// Използването на `compiler_fence` отстранява тази ситуация.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // предотвратява преместването на по-ранни записи отвъд тази точка
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // БЕЗОПАСНОСТ: използването на атомна ограда е безопасно.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Сигнализира на процесора, че се намира във въртящ се цикъл на забързано изчакване (" завъртане на спина`).
///
/// Тази функция е оттеглена в полза на [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}