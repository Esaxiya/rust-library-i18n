//! Споделяеми подвижни контейнери.
//!
//! Безопасността на паметта Rust се основава на това правило: Като се има предвид обект `T`, е възможно да има само едно от следните:
//!
//! - Наличието на няколко неизменни препратки (`&T`) към обекта (известен също като **псевдоним**).
//! - Наличие на една променлива препратка (`&mut T`) към обекта (известна също като **изменчивост**).
//!
//! Това се налага от компилатора Rust.Има обаче ситуации, при които това правило не е достатъчно гъвкаво.Понякога се изисква да има множество препратки към обект и въпреки това да го мутира.
//!
//! Съществуват съвместими подвижни контейнери, които позволяват контролирана променливост, дори при наличие на псевдоним.Както [`Cell<T>`], така и [`RefCell<T>`] позволяват да се направи това по един конец.
//! Нито `Cell<T>`, нито `RefCell<T>` обаче са безопасни за нишки (те не прилагат [`Sync`]).
//! Ако трябва да направите псевдоним и мутация между множество нишки, е възможно да използвате типове [`Mutex<T>`], [`RwLock<T>`] или [`atomic`].
//!
//! Стойностите на типовете `Cell<T>` и `RefCell<T>` могат да бъдат мутирани чрез споделени препратки (т.е.
//! често срещания тип `&T`), докато повечето типове Rust могат да бъдат мутирани само чрез уникални (`&mut T`) препратки.
//! Казваме, че `Cell<T>` и `RefCell<T>` осигуряват " вътрешна променливост`, за разлика от типичните типове Rust, които проявяват " наследена изменчивост`.
//!
//! Типовете клетки се предлагат в два вкуса: `Cell<T>` и `RefCell<T>`.`Cell<T>` реализира вътрешна променливост чрез преместване на стойности в и извън `Cell<T>`.
//! За да се използват референции вместо стойности, трябва да се използва тип `RefCell<T>`, като се придобие заключване за запис, преди да се мутира.`Cell<T>` предоставя методи за извличане и промяна на текущата вътрешна стойност:
//!
//!  - За типове, които прилагат [`Copy`], методът [`get`](Cell::get) извлича текущата вътрешна стойност.
//!  - За типове, които прилагат [`Default`], методът [`take`](Cell::take) заменя текущата вътрешна стойност с [`Default::default()`] и връща заменената стойност.
//!  - За всички типове методът [`replace`](Cell::replace) замества текущата вътрешна стойност и връща заменената стойност, а методът [`into_inner`](Cell::into_inner) консумира `Cell<T>` и връща вътрешната стойност.
//!  Освен това методът [`set`](Cell::set) замества вътрешната стойност, като отменя заменената стойност.
//!
//! `RefCell<T>` използва живота на Rust, за да приложи " динамично заемане`, процес, при който човек може да поиска временен, изключителен, променлив достъп до вътрешната стойност.
//! Взема назаем за `RefCell<T>`s се проследяват"по време на изпълнение", за разлика от родните референтни типове на Rust, които се проследяват изцяло статично, по време на компилация.
//! Тъй като заемите `RefCell<T>` са динамични, възможно е да се направи опит за заемане на стойност, която вече е заимствана с промени;когато това се случи, това води до нишка panic.
//!
//! # Кога да изберете интериорна променливост
//!
//! По-често срещаната наследствена изменчивост, при която човек трябва да има уникален достъп за мутиране на стойност, е един от ключовите езикови елементи, който позволява на Rust да разсъждава категорично относно псевдонима на показалеца, статично предотвратявайки грешки при срив.
//! Поради това се предпочита наследствената изменчивост, а вътрешната изменчивост е нещо като последна инстанция.
//! Тъй като типовете клетки позволяват мутация там, където в противен случай тя би била забранена, има случаи, когато вътрешната променливост може да е подходяща или дори * трябва да се използва, напр.
//!
//! * Представяме мутабилност 'inside' на нещо неизменяемо
//! * Подробности за изпълнението на логически неизменяеми методи.
//! * Мутиращи реализации на [`Clone`].
//!
//! ## Представяме мутабилност 'inside' на нещо неизменяемо
//!
//! Много споделени типове интелигентни указатели, включително [`Rc<T>`] и [`Arc<T>`], предоставят контейнери, които могат да бъдат клонирани и споделени между множество страни.
//! Тъй като съдържащите се стойности могат да бъдат многократно псевдоними, те могат да бъдат заети само с `&`, но не и с `&mut`.
//! Без клетки изобщо би било невъзможно да мутирате данни вътре в тези интелигентни указатели.
//!
//! Тогава е много често да се поставя `RefCell<T>` вътре в споделени типове указатели, за да се въведе отново изменчивост:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Създайте нов блок, за да ограничите обхвата на динамичното заемане
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Имайте предвид, че ако не бяхме позволили на предишното заемане на кеша да излезе извън обхвата, тогава последващото заемане ще предизвика динамична нишка panic.
//!     //
//!     // Това е основната опасност от използването на `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Имайте предвид, че този пример използва `Rc<T>`, а не `Arc<T>`.`RefCell<T>`s са за сценарии с една нишка.Помислете дали да не използвате [`RwLock<T>`] или [`Mutex<T>`], ако имате нужда от споделена променливост в ситуация с много нишки.
//!
//! ## Подробности за изпълнението на логически неизменяеми методи
//!
//! Понякога може да е желателно да не се излага в API, че има мутация "under the hood".
//! Това може да се дължи на факта, че логично операцията е неизменна, но например кеширането принуждава изпълнението да извърши мутация;или защото трябва да използвате мутация, за да приложите метод Portrait, който първоначално е дефиниран да приема `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Тук върви скъпо изчисление
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Мутиращи реализации на `Clone`
//!
//! Това е просто специален, но често срещан случай на предишния: скриване на изменчивост за операции, които изглеждат неизменни.
//! Очаква се методът [`clone`](Clone::clone) да не променя стойността на източника и е деклариран да приема `&self`, а не `&mut self`.
//! Следователно, всяка мутация, която се случва в метода `clone`, трябва да използва типове клетки.
//! Например [`Rc<T>`] поддържа броя на референтите си в рамките на `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Променящо се място в паметта.
///
/// # Examples
///
/// В този пример можете да видите, че `Cell<T>` позволява мутация в неизменяема структура.
/// С други думи, той позволява "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // ГРЕШКА: `my_struct` е неизменим
/// // my_struct.regular_field =нова_стойност;
///
/// // РАБОТИ: въпреки че `my_struct` е неизменим, `special_field` е `Cell`,
/// // които винаги могат да бъдат мутирани
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Вижте [module-level documentation](self) за повече.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Създава `Cell<T>`, със стойността `Default` за T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Създава нов `Cell`, съдържащ дадената стойност.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Задава съдържащата се стойност.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Разменя стойностите на две клетки.
    /// Разликата с `std::mem::swap` е, че тази функция не изисква справка за `&mut`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // БЕЗОПАСНОСТ: Това може да бъде рисковано, ако се извика от отделни нишки, но `Cell`
        // е `!Sync`, така че това няма да се случи.
        // Това също няма да обезсили никой указател, тъй като `Cell` гарантира, че нищо друго няма да сочи към нито един от тези `Cell`s.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Заменя съдържащата се стойност с `val` и връща старата съдържаща се стойност.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // БЕЗОПАСНОСТ: Това може да причини състезания с данни, ако се извика от отделна нишка,
        // но `Cell` е `!Sync`, така че това няма да се случи.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Разгъва стойността.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Връща копие на съдържаната стойност.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // БЕЗОПАСНОСТ: Това може да причини състезания с данни, ако се извика от отделна нишка,
        // но `Cell` е `!Sync`, така че това няма да се случи.
        unsafe { *self.value.get() }
    }

    /// Актуализира съдържащата се стойност с помощта на функция и връща новата стойност.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Връща суров указател към основните данни в тази клетка.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Връща променлива препратка към основните данни.
    ///
    /// Това обаждане заема `Cell` мутативно (по време на компилация), което гарантира, че притежаваме единствената референция.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Връща `&Cell<T>` от `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // БЕЗОПАСНОСТ: `&mut` осигурява уникален достъп.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Приема стойността на клетката, оставяйки `Default::default()` на нейно място.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Връща `&[Cell<T>]` от `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // БЕЗОПАСНОСТ: `Cell<T>` има същото оформление на паметта като `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Изменяемо място в паметта с динамично проверявани правила за заем
///
/// Вижте [module-level documentation](self) за повече.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Грешка, върната от [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Грешка, върната от [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Положителните стойности представляват броя на активните `Ref`.Отрицателните стойности представляват броя на активните `RefMut`.
// Множество `RefMut` могат да бъдат активни в даден момент само ако се отнасят до отделни, неприпокриващи се компоненти на `RefCell` (например различни диапазони на парче).
//
// `Ref` и `RefMut` са с две думи по размер, така че вероятно никога няма да има достатъчно " Ref`s или" RefMut`s, които да преливат половината от диапазона `usize`.
// По този начин `BorrowFlag` вероятно никога няма да прелее или да прелее.
// Това обаче не е гаранция, тъй като патологична програма може многократно да създава и след това mem::forget `Ref`s или`RefMut`s.
// По този начин целият код трябва изрично да проверява за преливане и преливане, за да се избегне несигурност или поне да се държи правилно в случай, че се случи преливане или преливане (напр. Вижте BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Създава нов `RefCell`, съдържащ `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Консумира `RefCell`, връщайки опакованата стойност.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Тъй като тази функция приема `self` (`RefCell`) по стойност, компилаторът статично проверява, че в момента не е заимстван.
        //
        self.value.into_inner()
    }

    /// Заменя опакованата стойност с нова, връщайки старата стойност, без да инициализира нито една.
    ///
    ///
    /// Тази функция съответства на [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics, ако стойността в момента е заета.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Заменя опакованата стойност с нова, изчислена от `f`, връщайки старата стойност, без да деинициализира нито една.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ако стойността в момента е заета.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Разменя заместената стойност на `self` с опакованата стойност на `other`, без да деинициализира нито една.
    ///
    ///
    /// Тази функция съответства на [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics, ако стойността в който и да е от `RefCell` е заета в момента.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Неизменяемо заема опакованата стойност.
    ///
    /// Заемът продължава, докато върнатият `Ref` не излезе от обхвата.
    /// Могат да се изтеглят няколко неизменяеми заеми едновременно.
    ///
    /// # Panics
    ///
    /// Panics, ако стойността понастоящем е заимствана с промени.
    /// За вариант без паника използвайте [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Пример за panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Неизменяемо заема опакованата стойност, връщайки грешка, ако стойността понастоящем е заимствана с промени.
    ///
    ///
    /// Заемът продължава, докато върнатият `Ref` не излезе от обхвата.
    /// Могат да се изтеглят няколко неизменяеми заеми едновременно.
    ///
    /// Това е паническият вариант на [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // БЕЗОПАСНОСТ: `BorrowRef` гарантира, че има само неизменим достъп
            // до стойността при заем.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Mutably заема опакованата стойност.
    ///
    /// Заемът продължава, докато върнатият `RefMut` или всички `RefMut`, получени от него, излязат от обхвата.
    ///
    /// Стойността не може да бъде взета назаем, докато този заем е активен.
    ///
    /// # Panics
    ///
    /// Panics, ако стойността в момента е заета.
    /// За вариант без паника използвайте [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Пример за panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Mutably заема опакованата стойност, връщайки грешка, ако стойността в момента е заета.
    ///
    ///
    /// Заемът продължава, докато върнатият `RefMut` или всички `RefMut`, получени от него, излязат от обхвата.
    /// Стойността не може да бъде взета назаем, докато този заем е активен.
    ///
    /// Това е паническият вариант на [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // БЕЗОПАСНОСТ: `BorrowRef` гарантира уникален достъп.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Връща суров указател към основните данни в тази клетка.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Връща променлива препратка към основните данни.
    ///
    /// Това обаждане заема `RefCell` мутативно (по време на компилация), така че няма нужда от динамични проверки.
    ///
    /// Внимавайте обаче: този метод очаква `self` да бъде променлив, което обикновено не е така при използването на `RefCell`.
    ///
    /// Вместо това разгледайте метода [`borrow_mut`], ако `self` не е променлив.
    ///
    /// Също така, моля, имайте предвид, че този метод е само за специални обстоятелства и обикновено не е това, което искате.
    /// В случай на съмнение използвайте [`borrow_mut`] вместо това.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Отменете ефекта на изтекли предпазители върху състоянието на заема на `RefCell`.
    ///
    /// Този разговор е подобен на [`get_mut`], но е по-специализиран.
    /// Той взема назаем `RefCell` мутативно, за да гарантира, че не съществуват заеми и след това нулира споделените заеми за проследяване на състоянието.
    /// Това е от значение, ако някои `Ref` или `RefMut` заеми са изтекли.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Неизменяемо заема опакованата стойност, връщайки грешка, ако стойността понастоящем е заимствана с промени.
    ///
    /// # Safety
    ///
    /// За разлика от `RefCell::borrow`, този метод не е безопасен, тъй като не връща `Ref`, като по този начин оставя флага за заем незасегнат.
    /// Заемът на `RefCell` по същество, докато референцията, върната от този метод е жива, е недефинирано поведение.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // БЕЗОПАСНОСТ: Проверяваме дали сега никой не пише активно, но е така
            // отговорността на повикващия да гарантира, че никой не пише, докато върнатата препратка вече не се използва.
            // Също така, `self.value.get()` се отнася до стойността, притежавана от `self`, и по този начин се гарантира, че е валидна за целия живот на `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Взима опакованата стойност, оставяйки `Default::default()` на мястото си.
    ///
    /// # Panics
    ///
    /// Panics, ако стойността в момента е заета.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics, ако стойността понастоящем е заимствана с промени.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Създава `RefCell<T>`, със стойността `Default` за T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics, ако стойността в който и да е от `RefCell` е заета в момента.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics, ако стойността в който и да е от `RefCell` е заета в момента.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics, ако стойността в който и да е от `RefCell` е заета в момента.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, ако стойността в който и да е от `RefCell` е заета в момента.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, ако стойността в който и да е от `RefCell` е заета в момента.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, ако стойността в който и да е от `RefCell` е заета в момента.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics, ако стойността в който и да е от `RefCell` е заета в момента.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Увеличаването на заема може да доведе до непрочетена стойност (<=0) в тези случаи:
            // 1. Беше <0, т.е. има заемни средства за писане, така че не можем да позволим четене на заем поради правилата за псевдоним на референтен Rust
            // 2.
            // Това беше isize::MAX (максималното количество заеми за четене) и се препълни в isize::MIN (максималното количество заеми за писане), така че не можем да позволим допълнително четене, тъй като isize не може да представлява толкова много чети заеми (това може да се случи само ако вие mem::forget повече от малко постоянно количество `Ref`s, което не е добра практика)
            //
            //
            //
            //
            None
        } else {
            // Увеличаването на заема може да доведе до стойност на четене (> 0) в тези случаи:
            // 1. Беше=0, т.е. не беше взето назаем и вземаме първото четене
            // 2. Беше> 0 и <isize::MAX, т.е.
            // имаше прочетени заемки, а isize е достатъчно голям, за да представлява още един прочетен заем
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Тъй като този Ref съществува, знаем, че заемният флаг е заем за четене.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Предотвратете преливането на брояча на заеми в писмено вземане.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Опакова заемна препратка към стойност в поле `RefCell`.
/// Тип обвивка за неизменно заимствана стойност от `RefCell<T>`.
///
/// Вижте [module-level documentation](self) за повече.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Копира `Ref`.
    ///
    /// `RefCell` вече е неизменно заимстван, така че това не може да се провали.
    ///
    /// Това е свързана функция, която трябва да се използва като `Ref::clone(...)`.
    /// Прилагането на `Clone` или метод би попречило на широкото използване на `r.borrow().clone()` за клониране на съдържанието на `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Прави нов `Ref` за компонент от заетите данни.
    ///
    /// `RefCell` вече е неизменно заимстван, така че това не може да се провали.
    ///
    /// Това е свързана функция, която трябва да се използва като `Ref::map(...)`.
    /// Методът би повлиял на методите със същото име върху съдържанието на `RefCell`, използван през `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Прави нов `Ref` за незадължителен компонент на заетите данни.
    /// Оригиналният предпазител се връща като `Err(..)`, ако затварянето връща `None`.
    ///
    /// `RefCell` вече е неизменно заимстван, така че това не може да се провали.
    ///
    /// Това е свързана функция, която трябва да се използва като `Ref::filter_map(...)`.
    /// Методът би повлиял на методите със същото име върху съдържанието на `RefCell`, използван през `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Разделя `Ref` на множество `Ref`s за различни компоненти на заетите данни.
    ///
    /// `RefCell` вече е неизменно заимстван, така че това не може да се провали.
    ///
    /// Това е свързана функция, която трябва да се използва като `Ref::map_split(...)`.
    /// Методът би повлиял на методите със същото име върху съдържанието на `RefCell`, използван през `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Преобразувайте в препратка към основните данни.
    ///
    /// Основният `RefCell` никога повече не може да бъде заимстван изменяемо и винаги ще изглежда вече неизменен заем.
    ///
    /// Не е добра идея да изтече повече от постоянен брой препратки.
    /// `RefCell` може да бъде заимстван неизменно отново, ако общо са настъпили само по-малък брой течове.
    ///
    /// Това е свързана функция, която трябва да се използва като `Ref::leak(...)`.
    /// Методът би повлиял на методите със същото име върху съдържанието на `RefCell`, използван през `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Като забравяме този Ref, ние гарантираме, че броячът на заеми в RefCell не може да се върне към UNUSED в рамките на целия `'b`.
        // Нулирането на състоянието на проследяване на референцията би изисквало уникална препратка към заетата RefCell.
        // От оригиналната клетка не могат да се създават други изменяеми препратки.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Прави нов `RefMut` за компонент от заетите данни, напр. Вариант с изброяване.
    ///
    /// `RefCell` вече е заимстван с промени, така че това не може да се провали.
    ///
    /// Това е свързана функция, която трябва да се използва като `RefMut::map(...)`.
    /// Методът би повлиял на методите със същото име върху съдържанието на `RefCell`, използван през `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): коригиране на заем-проверка
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Прави нов `RefMut` за незадължителен компонент на заетите данни.
    /// Оригиналният предпазител се връща като `Err(..)`, ако затварянето връща `None`.
    ///
    /// `RefCell` вече е заимстван с промени, така че това не може да се провали.
    ///
    /// Това е свързана функция, която трябва да се използва като `RefMut::filter_map(...)`.
    /// Методът би повлиял на методите със същото име върху съдържанието на `RefCell`, използван през `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): коригиране на заем-проверка
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // БЕЗОПАСНОСТ: функцията задържа изключителна препратка за продължителността
        // на своето повикване през `orig`, а указателят е само дефектиран във вътрешността на извикването на функция, като никога не позволява на изключителната препратка да избяга.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // БЕЗОПАСНОСТ: същото като по-горе.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Разделя `RefMut` на множество `RefMut` за различни компоненти на заетите данни.
    ///
    /// Подлежащият `RefCell` ще остане заимстван с изменяем характер, докато и двете върнати `RefMut` излязат извън обхвата.
    ///
    /// `RefCell` вече е заимстван с промени, така че това не може да се провали.
    ///
    /// Това е свързана функция, която трябва да се използва като `RefMut::map_split(...)`.
    /// Методът би повлиял на методите със същото име върху съдържанието на `RefCell`, използван през `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Преобразувайте в променлива препратка към основните данни.
    ///
    /// Основният `RefCell` не може да бъде взаимстван отново и винаги ще изглежда вече заимстван с промени, което прави връщаната препратка единствена към интериора.
    ///
    ///
    /// Това е свързана функция, която трябва да се използва като `RefMut::leak(...)`.
    /// Методът би повлиял на методите със същото име върху съдържанието на `RefCell`, използван през `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Като забравяме този BorrowRefMut, ние гарантираме, че броячът на заеми в RefCell не може да се върне към НЕИЗПОЛЗВАН в рамките на `'b`.
        // Нулирането на състоянието на проследяване на референцията би изисквало уникална препратка към заетата RefCell.
        // Не могат да се създават допълнителни препратки от оригиналната клетка в рамките на този живот, което прави текущото заемане единствената препратка за оставащия живот.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: За разлика от BorrowRefMut::clone, new се извиква, за да създаде началната
        // променлива препратка и затова в момента не трябва да има съществуващи препратки.
        // По този начин, докато клонингът увеличава изменяемото преброяване, тук изрично разрешаваме само преминаване от UNUSED към UNUSED, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Клонира `BorrowRefMut`.
    //
    // Това е валидно само ако всеки `BorrowRefMut` се използва за проследяване на променлива препратка към отделен, неприпокриващ се диапазон на оригиналния обект.
    //
    // Това не е в Clone impl, така че кодът да не извиква това имплицитно.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Предотвратете изтичането на брояча на заеми.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Тип обвивка за заемно стойност, заимствана от `RefCell<T>`.
///
/// Вижте [module-level documentation](self) за повече.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Основният примитив за вътрешна променливост в Rust.
///
/// Ако имате референтен `&T`, тогава обикновено в Rust компилаторът извършва оптимизации въз основа на знанието, че `&T` сочи към неизменяеми данни.Мутирането на тези данни, например чрез псевдоним или чрез преобразуване на `&T` в `&mut T`, се счита за недефинирано поведение.
/// `UnsafeCell<T>` отказ от гаранцията за неизменност за `&T`: споделена референция `&UnsafeCell<T>` може да сочи към данни, които се мутират.Това се нарича "interior mutability".
///
/// Всички останали типове, които позволяват вътрешна променливост, като `Cell<T>` и `RefCell<T>`, използват вътрешно `UnsafeCell`, за да обгръщат данните си.
///
/// Имайте предвид, че само гаранцията за неизменност за споделени референции е засегната от `UnsafeCell`.Гаранцията за уникалност за изменяеми референции не е засегната.Няма *никакъв* легален начин за получаване на псевдоним `&mut`, дори и с `UnsafeCell<T>`.
///
/// Самият API на `UnsafeCell` е технически много прост: [`.get()`] ви дава суров указател `*mut T` към съдържанието му._you_ зависи от дизайнера на абстракция, за да използва правилно този суров указател.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Прецизните правила за псевдоними на Rust донякъде се променят, но основните моменти не са спорни:
///
/// - Ако създадете безопасна препратка с доживотна `'a` (или `&T` или `&mut T` препратка), която е достъпна чрез безопасен код (например, защото сте я върнали), тогава не трябва да имате достъп до данните по никакъв начин, който противоречи на тази препратка за останалата част на `'a`.
/// Например, това означава, че ако вземете `*mut T` от `UnsafeCell<T>` и го хвърлите на `&T`, тогава данните в `T` трябва да останат неизменни (по модул всички данни на `UnsafeCell`, намерени в `T`, разбира се), докато изтича животът на тази референция.
/// По същия начин, ако създадете референция `&mut T`, която е освободена за безопасен код, тогава не трябва да имате достъп до данните в `UnsafeCell`, докато тази референция изтече.
///
/// - По всяко време трябва да избягвате състезания с данни.Ако множество нишки имат достъп до един и същ `UnsafeCell`, тогава всички записи трябва да имат правилна връзка преди всички други достъпи (или да използват атоми).
///
/// За да подпомогнат правилния дизайн, следните сценарии са изрично обявени за законни за еднонишковия код:
///
/// 1. Референцията за `&T` може да бъде пусната в безопасен код и там може да съществува съвместно с други референции на `&T`, но не и с `&mut T`
///
/// 2. Препратка към `&mut T` може да бъде пусната за безопасен код, при условие че нито други `&mut T`, нито `&T` съществуват заедно с него.`&mut T` винаги трябва да е уникален.
///
/// Имайте предвид, че докато мутирането на съдържанието на `&UnsafeCell<T>` (дори докато други `&UnsafeCell<T>` се позовават на псевдонима на клетката) е добре (при условие, че налагате горните инварианти по друг начин), все още е неопределено поведение да има множество псевдоними на `&mut UnsafeCell<T>`.
/// Тоест, `UnsafeCell` е обвивка, проектирана да има специално взаимодействие с _shared_ accesses (_i.e._, чрез референция `&UnsafeCell<_>`);няма никаква магия, когато се работи с _exclusive_ accesses (_e.g._, чрез `&mut UnsafeCell<_>`): нито клетката, нито обвитата стойност могат да бъдат псевдоними по време на този заем `&mut`.
///
/// Това е демонстрирано от аксесоара [`.get_mut()`], който е _safe_ getter, който дава `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Ето пример, показващ как да мутирате добре съдържанието на `UnsafeCell<_>`, въпреки че има множество препратки, псевдоними на клетката:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Вземете множество/едновременни/споделени препратки към един и същ `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // БЕЗОПАСНОСТ: в този обхват няма други препратки към съдържанието на `x`,
///     // така че нашата е ефективно уникална.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- заем-+
///     *p1_exclusive += 27; // |
/// } // <---------- не може да надхвърли тази точка -------------------+
///
/// unsafe {
///     // БЕЗОПАСНОСТ: в този обхват никой не очаква да има изключителен достъп до съдържанието на `x`,
///     // така че можем да имаме няколко споделени достъпа едновременно.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Следващият пример показва факта, че изключителният достъп до `UnsafeCell<T>` предполага изключителен достъп до неговия `T`:
///
/// ```rust
/// #![forbid(unsafe_code)] // с изключителен достъп,
///                         // `UnsafeCell` е прозрачна обвивка без опция, така че тук няма нужда от `unsafe`.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Вземете проверена по време на компилация уникална препратка към `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // С изключителна справка можем да мутираме съдържанието безплатно.
/// *p_unique.get_mut() = 0;
/// // Или, еквивалентно:
/// x = UnsafeCell::new(0);
///
/// // Когато притежаваме стойността, можем да извлечем съдържанието безплатно.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Конструира нов екземпляр на `UnsafeCell`, който ще обгърне посочената стойност.
    ///
    ///
    /// Целият достъп до вътрешната стойност чрез методи е `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Разгъва стойността.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Получава променлив указател към обгърнатата стойност.
    ///
    /// Това може да бъде хвърлено към указател от всякакъв вид.
    /// Уверете се, че достъпът е уникален (няма активни препратки, променящи се или не), когато се предава към `&mut T`, и се уверете, че няма никакви мутации или променящи се псевдоними, когато се предава към `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Можем просто да хвърлим показалеца от `UnsafeCell<T>` към `T` поради #[repr(transparent)].
        // Това използва специалния статус на libstd, няма гаранция за потребителския код, че това ще работи във версиите на future на компилатора!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Връща променлива препратка към основните данни.
    ///
    /// Това обаждане заема `UnsafeCell` мутативно (по време на компилация), което гарантира, че притежаваме единствената референция.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Получава променлив указател към обгърнатата стойност.
    /// Разликата с [`get`] е, че тази функция приема суров указател, което е полезно, за да се избегне създаването на временни препратки.
    ///
    /// Резултатът може да бъде хвърлен към указател от всякакъв вид.
    /// Уверете се, че достъпът е уникален (няма активни препратки, променящи се или не), когато се предава към `&mut T`, и се уверете, че няма никакви мутации или променящи се псевдоними, когато се предава към `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Постепенната инициализация на `UnsafeCell` изисква `raw_get`, тъй като извикването на `get` ще изисква създаване на препратка към неинициализирани данни:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Можем просто да хвърлим показалеца от `UnsafeCell<T>` към `T` поради #[repr(transparent)].
        // Това използва специалния статус на libstd, няма гаранция за потребителския код, че това ще работи във версиите на future на компилатора!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Създава `UnsafeCell`, със стойността `Default` за T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}