#![stable(feature = "futures_api", since = "1.36.0")]

//! Асинхронни стойности.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Този тип е необходим, защото:
///
/// а) Генераторите не могат да внедрят `for<'a, 'b> Generator<&'a mut Context<'b>>`, така че трябва да предадем суров указател (вижте <https://github.com/rust-lang/rust/issues/68923>).
///
/// б) Суровите указатели и `NonNull` не са `Send` или `Sync`, така че това би направило всеки отделен future non-Send/Sync, а ние не искаме това.
///
/// Той също така опростява понижаването на HIR на `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Увийте генератор в future.
///
/// Тази функция връща `GenFuture` отдолу, но го скрива в `impl Trait`, за да дава по-добри съобщения за грешка (`impl Future`, а не `GenFuture<[closure.....]>`).
///
// Това е `const`, за да се избегнат допълнителни грешки, след като се възстановим от `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Разчитаме на факта, че async/await futures са неподвижни, за да се създадат самореферентни заеми в основния генератор.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // БЕЗОПАСНОСТ: Безопасно, защото сме !Unpin + !Drop, а това е само проекция на поле.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Възобновете генератора, превръщайки `&mut Context` в `NonNull` суров указател.
            // Спускането на `.await` безопасно ще го върне към `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // БЕЗОПАСНОСТ: повикващият трябва да гарантира, че `cx.0` е валиден указател
    // който отговаря на всички изисквания за променлива референция.
    unsafe { &mut *cx.0.as_ptr().cast() }
}