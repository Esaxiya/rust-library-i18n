//! Малко търкаляне на положителни плувки IEEE 754.Отрицателните числа не са и не трябва да се обработват.
//! Нормалните числа с плаваща запетая имат канонично представяне като (frac, exp), така че стойността е 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)), където N е броят на битовете.
//!
//! Поднормалните са малко по-различни и странни, но се прилага същият принцип.
//!
//! Тук обаче ги представяме като (sig, k) с f положително, така че стойността е f *
//! 2 <sup>д</sup> .Освен че прави "hidden bit" явен, това променя степента чрез така наречената мантисова смяна.
//!
//! Казано по друг начин, обикновено плувките се пишат като (1), но тук те се пишат като (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Ние наричаме (1)**дробното представяне**, а (2)**интегрално представяне**.
//!
//! Много функции в този модул обработват само нормални числа.Процедурите dec2flt консервативно поемат универсално правилния бавен път (алгоритъм М) за много малки и много големи числа.
//! Този алгоритъм се нуждае само от next_float(), който обработва поднормали и нули.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Помощник Portrait за избягване на дублиране основно на целия код за преобразуване за `f32` и `f64`.
///
/// Вижте коментара на документа на родителския модул за това защо е необходимо.
///
/// Трябва ли **никога никога** да се внедрява за други типове или да се използва извън модула dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Тип, използван от `to_bits` и `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Извършва сурова трансмутация в цяло число.
    fn to_bits(self) -> Self::Bits;

    /// Извършва сурова трансмутация от цяло число.
    fn from_bits(v: Self::Bits) -> Self;

    /// Връща категорията, в която попада това число.
    fn classify(self) -> FpCategory;

    /// Връща мантисата, експонента и знак като цели числа.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Декодира поплавъка.
    fn unpack(self) -> Unpacked;

    /// Изпълнения от малко цяло число, което може да бъде представено точно.
    /// Panic, ако цялото число не може да бъде представено, другият код в този модул гарантира, че никога няма да позволи това да се случи.
    fn from_int(x: u64) -> Self;

    /// Получава стойността 10 <sup>e</sup> от предварително изчислена таблица.
    /// Panics за `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Какво казва името.
    /// По-лесно е да кодирате твърдо, отколкото да жонглирате с присъщи елементи и да се надявате, че константата на LLVM го сгъва.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Консервативна граница на десетичните цифри на входовете, които не могат да предизвикат преливане или нула или
    /// поднормални.Вероятно десетичната степен на максималната нормална стойност, откъдето идва и името.
    const MAX_NORMAL_DIGITS: usize;

    /// Когато най-значимата десетична цифра има място, по-голямо от това, числото със сигурност се закръглява до безкрайност.
    ///
    const INF_CUTOFF: i64;

    /// Когато най-значимата десетична цифра има място, по-малко от това, числото със сигурност се закръглява до нула.
    ///
    const ZERO_CUTOFF: i64;

    /// Броят на битовете в експонентата.
    const EXP_BITS: u8;

    /// Броят на битовете в значението,*включително* скрития бит.
    const SIG_BITS: u8;

    /// Броят на битовете в значението,*с изключение на* скрития бит.
    const EXPLICIT_SIG_BITS: u8;

    /// Максималният правен показател при частично представяне.
    const MAX_EXP: i16;

    /// Минималният правен показател при частично представяне, с изключение на поднормалните.
    const MIN_EXP: i16;

    /// `MAX_EXP` за интегрално представяне, т.е. с приложената смяна.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` кодирани (т.е. с компенсирано пристрастие)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` за интегрално представяне, т.е. с приложената смяна.
    const MIN_EXP_INT: i16;

    /// Максималното нормализирано значениеи в интегрално представяне.
    const MAX_SIG: u64;

    /// Минималното нормализирано значениеи в интегрално представяне.
    const MIN_SIG: u64;
}

// Предимно решение за #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Връща мантисата, експонента и знак като цели числа.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Експонентално пристрастие + мантисова промяна
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe не е сигурен дали `as` закръглява правилно на всички платформи.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Връща мантисата, експонента и знак като цели числа.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Експонентално пристрастие + мантисова промяна
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe не е сигурен дали `as` закръглява правилно на всички платформи.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Преобразува `Fp` в най-близкия тип машинен поплавък.
/// Не се справя с необичайни резултати.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f е 64 бита, така че xe има мантисово изместване от 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Закръглете 64-битовото значение до битове T::SIG_BITS с половин до четен.
/// Не се справя с препълване на експонента.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Регулирайте смяната на мантиса
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Обратно на `RawFloat::unpack()` за нормализирани числа.
/// Panics, ако значението или степента не са валидни за нормализирани числа.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Премахнете скрития бит
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Регулирайте експонентата за експозиционно пристрастие и изместване на мантиса
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Оставете знаков бит при 0 ("+"), всичките ни числа са положителни
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Постройте субнормално.Мантиса от 0 е разрешена и конструира нула.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Кодираният експонент е 0, знаковият бит е 0, така че просто трябва да преинтерпретираме битовете.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Приблизително bignum с Fp.Закръглява в рамките на 0.5 ULP с половин до равномерно.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Ние отрязваме всички битове преди индекса `start`, т.е. ефективно преместваме надясно с количество `start`, така че това е и степента, от която се нуждаем.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Кръгъл (half-to-even) в зависимост от пресечените битове.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Намира най-голямото число с плаваща запетая, строго по-малко от аргумента.
/// Не се справя с поднормални, нулеви или експонентен недостатък.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Намерете най-малкото число с плаваща запетая, строго по-голямо от аргумента.
// Тази операция е насищаща, т.е. next_float(inf) ==инф.
// За разлика от повечето кодове в този модул, тази функция се справя с нула, субнормални и безкрайности.
// Въпреки това, както и всички останали кодове тук, той не се занимава с NaN и отрицателни числа.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Това изглежда твърде добре, за да е истина, но работи.
        // 0.0 се кодира като абсолютно нулева дума.Субнормалните са 0x000m ... m, където m е мантисата.
        // По-специално, най-малката субнормална е 0x0 ... 01, а най-голямата е 0x000F ... F.
        // Най-малкото нормално число е 0x0010 ... 0, така че и този ъглов калъф работи.
        // Ако инкрементът препълва мантисата, битът за носене увеличава степента, както искаме, и битовете на мантисата стават нула.
        // Поради скритата конвенция за битове, това също е точно това, което искаме!
        // И накрая, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}