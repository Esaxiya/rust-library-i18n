//! Помощни функции за bignums, които нямат твърде много смисъл да се превръщат в методи.

// FIXME Името на този модул е малко жалко, тъй като други модули също импортират `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Тествайте дали отрязването на всички битове, по-малко значими от `ones_place`, въвежда относителна грешка, по-малка, равна или по-голяма от 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Ако всички останали битове са нула, това е= 0.5 ULP, в противен случай> 0.5 Ако няма повече битове (half_bit==0), по-долу също правилно връща Equal.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Преобразува ASCII низ, съдържащ само десетични цифри, в `u64`.
///
/// Не извършва проверки за препълване или невалидни символи, така че ако повикващият не е внимателен, резултатът е фалшив и може да panic (макар че няма да бъде `unsafe`).
/// Освен това празните низове се третират като нула.
/// Тази функция съществува, защото
///
/// 1. използването на `FromStr` на `&[u8]` изисква `from_utf8_unchecked`, което е лошо, и
/// 2. обединяването на резултатите от `integral.parse()` и `fractional.parse()` е по-сложно от цялата тази функция.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Преобразува низ от ASCII цифри в bignum.
///
/// Подобно на `from_str_unchecked`, тази функция разчита на синтактичния анализатор за премахване на нецифрени цифри.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Разгъва bignum в 64-битово цяло число.Panics, ако броят е твърде голям.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Извлича редица битове.

/// Индекс 0 е най-малко значимият бит и диапазонът е полуотворен, както обикновено.
/// Panics, ако бъде поискано да извлече повече битове, отколкото се побира във типа на връщане.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}