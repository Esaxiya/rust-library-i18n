//! Декодира стойност с плаваща запетая на отделни части и диапазони на грешки.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Декодирана неподписана крайна стойност, такава че:
///
/// - Оригиналната стойност е равна на `mant * 2^exp`.
///
/// - Всяко число от `(mant - minus)*2^exp` до `(mant + plus)* 2^exp` ще се закръгли до първоначалната стойност.
/// Обхватът е включен само когато `inclusive` е `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Мащабираната мантиса.
    pub mant: u64,
    /// Долният диапазон на грешки.
    pub minus: u64,
    /// Горният диапазон на грешки.
    pub plus: u64,
    /// Споделеният експонент в база 2.
    pub exp: i16,
    /// Вярно, когато обхватът на грешките е включен.
    ///
    /// В IEEE 754 това е вярно, когато първоначалната мантиса е била четна.
    pub inclusive: bool,
}

/// Декодирана неподписана стойност.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Безкрайности, било то положителни или отрицателни.
    Infinite,
    /// Нула, или положителна, или отрицателна.
    Zero,
    /// Крайни числа с допълнително декодирани полета.
    Finite(Decoded),
}

/// Тип с плаваща запетая, който може да бъде "декодиран".
pub trait DecodableFloat: RawFloat + Copy {
    /// Минималната положителна нормализирана стойност.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Връща знак (вярно, когато е отрицателно) и стойност `FullDecoded` от дадено число с плаваща запетая.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // съседи: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode винаги запазва експонентата, така че мантисата се мащабира за поднормални.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // съседи: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // където maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // съседи: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}