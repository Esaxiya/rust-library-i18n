//! Почти директен (но леко оптимизиран) превод на Rust на Фигура 3 от " Печат на числа с плаваща запетая бързо и точно` [^ 1].
//!
//!
//! [^1]: Burger, RG и Dybvig, RK 1996. Отпечатване на числа с плаваща запетая
//!   бързо и точно.SIGPLAN Не.31, 5 (май 1996 г.), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// предварително изчислени масиви от `Digit`s за 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// използваем само когато `x < 16 * scale`;`scaleN` трябва да бъде `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Най-краткият режим на изпълнение за Dragon.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // числото `v` за форматиране е известно:
    // - равен на `mant * 2^exp`;
    // - предшествано от `(mant - 2 *minus)* 2^exp` в оригиналния тип;и
    // - последвано от `(mant + 2 *plus)* 2^exp` в оригиналния тип.
    //
    // очевидно `minus` и `plus` не могат да бъдат нула.(за безкрайности използваме стойности извън обхвата.) също така приемаме, че се генерира поне една цифра, т.е. `mant` също не може да бъде нула.
    //
    // това също означава, че всяко число между `low = (mant - minus)*2^exp` и `high = (mant + plus)* 2^exp` ще се преобразува в точно това число с плаваща запетая, с граници, включени, когато оригиналната мантиса е четна (т.е. `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` е `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // изчислете `k_0` от оригинални входове, удовлетворяващи `10^(k_0-1) < high <= 10^(k_0+1)`.
    // плътно обвързаният `k`, удовлетворяващ `10^(k-1) < high <= 10^k`, се изчислява по-късно.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // конвертирате `{mant, plus, minus} * 2^exp` във дробна форма, така че:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // разделете `mant` на `10^k`.сега `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // поправяне, когато `mant + plus > scale` (или `>=`).
    // всъщност не модифицираме `scale`, тъй като вместо това можем да пропуснем първоначалното умножение.
    // сега `scale < mant + plus <= scale * 10` и сме готови да генерираме цифри.
    //
    // имайте предвид, че `d[0]`*може* да бъде нула, когато `scale - plus < mant < scale`.
    // в този случай условието за закръгляване (`up` по-долу) ще се задейства незабавно.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // еквивалентно на мащабиране на `scale` с 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // кеш `(2, 4, 8) * scale` за генериране на цифри.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // инварианти, където `d[0..n-1]` са цифри, генерирани досега:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (по този начин `mant / scale < 10`), където `d[i..j]` е стенография за `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // генериране на една цифра: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // това е опростено описание на модифицирания алгоритъм Dragon.
        // много междинни изводи и аргументи за пълнота са пропуснати за удобство.
        //
        // започнете с модифицирани инварианти, тъй като обновихме `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // да приемем, че `d[0..n-1]` е най-краткото представяне между `low` и `high`, т.е. `d[0..n-1]` удовлетворява и двете от следните, но `d[0..n-2]` не:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (биективност: цифри закръглени до `v`);и
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (последната цифра е правилна).
        //
        // второто условие се опростява до `2 * mant <= scale`.
        // решаването на инварианти по отношение на `mant`, `low` и `high` дава по-опростена версия на първото условие: `-plus < mant < minus`.
        // от `-plus < 0 <= mant`, имаме правилното най-кратко представяне, когато `mant < minus` и `2 * mant <= scale`.
        // (първият става `mant <= minus`, когато оригиналната мантиса е четна.)
        //
        // когато втората не държи (`2 * mant> scale`), трябва да увеличим последната цифра.
        // това е достатъчно за възстановяване на това състояние: вече знаем, че генерирането на цифри гарантира `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // в този случай първото условие става `-plus < mant - scale < minus`.
        // тъй като `mant < scale` след поколението, имаме `scale < mant + plus`.
        // (отново това става `scale <= mant + plus`, когато оригиналната мантиса е четна.)
        //
        // накратко:
        // - спрете и закръглете `down` (запазете цифрите, както е), когато `mant < minus` (или `<=`).
        // - спрете и закръглете `up` (увеличете последната цифра), когато `scale < mant + plus` (или `<=`).
        // - продължете да генерирате по друг начин.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // имаме най-краткото представяне, преминете към закръгляването

        // възстанови инвариантите.
        // това прави алгоритъма винаги завършващ: `minus` и `plus` винаги се увеличават, но `mant` се отрязва по модул `scale` и `scale` е фиксиран.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // закръгляването се случва, когато i) само условието за закръгляване е задействано, или ii) и двете условия са задействани и разчупването на вратовръз предпочита закръгляването.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // ако закръгляването променя дължината, степента също трябва да се промени.
        // изглежда, че това условие е много трудно да бъде изпълнено (възможно невъзможно), но ние просто сме в безопасност и последователност тук.
        //
        // БЕЗОПАСНОСТ: инициализирахме тази памет по-горе.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // БЕЗОПАСНОСТ: инициализирахме тази памет по-горе.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Точното и фиксирано внедряване на режим за Dragon.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // изчислете `k_0` от оригинални входове, удовлетворяващи `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // разделете `mant` на `10^k`.сега `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // поправяне, когато `mant + plus >= scale`, където `plus / scale = 10^-buf.len() / 2`.
    // за да запазим фиг. размер bignum, всъщност използваме `mant + floor(plus) >= scale`.
    // всъщност не модифицираме `scale`, тъй като вместо това можем да пропуснем първоначалното умножение.
    // отново с най-краткия алгоритъм, `d[0]` може да бъде нула, но в крайна сметка ще бъде закръглена нагоре.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // еквивалентно на мащабиране на `scale` с 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // ако работим с ограничението от последната цифра, трябва да съкратим буфера преди реалното изобразяване, за да избегнем двойно закръгляване.
    //
    // имайте предвид, че трябва да увеличим буфера отново, когато се получи закръгляване!
    let mut len = if k < limit {
        // ами, не можем дори да изведем *една* цифра.
        // това е възможно, когато, да речем, имаме нещо като 9.5 и то е закръглено до 10.
        // връщаме празен буфер, с изключение на по-късното закръгляване, което се случва при `k == limit` и трябва да даде точно една цифра.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // кеш `(2, 4, 8) * scale` за генериране на цифри.
        // (това може да е скъпо, така че не ги изчислявайте, когато буферът е празен.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // следващите цифри са нули, спираме до тук не *не* се опитвайте да извършите закръгляване!по-скоро попълнете останалите цифри.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // БЕЗОПАСНОСТ: инициализирахме тази памет по-горе.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // закръгляване нагоре, ако спрем в средата на цифрите, ако следващите цифри са точно 5000 ..., проверете предходната цифра и се опитайте да закръглите до четна (т.е. избягвайте закръгляването нагоре, когато предходната цифра е четна).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // БЕЗОПАСНОСТ: `buf[len-1]` се инициализира.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // ако закръгляването променя дължината, степента също трябва да се промени.
        // но ни беше поискан фиксиран брой цифри, така че не променяйте буфера ...
        // БЕЗОПАСНОСТ: инициализирахме тази памет по-горе.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... освен ако вместо това не ни е поискана фиксираната точност.
            // ние също трябва да проверим, че ако оригиналният буфер е празен, допълнителната цифра може да бъде добавена само когато `k == limit` (случай edge).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // БЕЗОПАСНОСТ: инициализирахме тази памет по-горе.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}