/*!

Floating-point number to decimal conversion routines.

# Problem statement

We are given the floating-point number `v = f * 2^e` with an integer `f`,
and its bounds `minus` and `plus` such that any number between `v - minus` and
`v + plus` will be rounded to `v`. For the simplicity we assume that
this range is exclusive. Then we would like to get the unique decimal
representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero.

- It's correctly rounded when parsed back: `v - minus < V < v + plus`.
  Furthermore it is shortest such one, i.e., there is no representation
  with less than `n` digits that is correctly rounded.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Note that
  there might be two representations satisfying this uniqueness requirement,
  in which case some tie-breaking mechanism is used.

We will call this mode of operation as to the *shortest* mode. This mode is used
when there is no additional constraint, and can be thought as a "natural" mode
as it matches the ordinary intuition (it at least prints `0.1f32` as "0.1").

We have two more modes of operation closely related to each other. In these modes
we are given either the number of significant digits `n` or the last-digit
limitation `limit` (which determines the actual `n`), and we would like to get
the representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero, unless `n` was zero in which case only `k` is returned.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Again,
  there might be some tie-breaking mechanism.

When `limit` is given but not `n`, we set `n` such that `k - n = limit`
so that the last digit `d[n-1]` is scaled by `10^(k-n) = 10^limit`.
If such `n` is negative, we clip it to zero so that we will only get `k`.
We are also limited by the supplied buffer. This limitation is used to print
the number up to given number of fractional digits without knowing
the correct `k` beforehand.

We will call the mode of operation requiring `n` as to the *exact* mode,
and one requiring `limit` as to the *fixed* mode. The exact mode is a subset of
the fixed mode: the sufficiently large last-digit limitation will eventually fill
the supplied buffer and let the algorithm to return.

# Implementation overview

It is easy to get the floating point printing correct but slow (Russ Cox has
[demonstrated](http://research.swtch.com/ftoa) how it's easy), or incorrect but
fast (naïve division and modulo). But it is surprisingly hard to print
floating point numbers correctly *and* efficiently.

There are two classes of algorithms widely known to be correct.

- The "Dragon" family of algorithm is first described by Guy L. Steele Jr. and
  Jon L. White. They rely on the fixed-size big integer for their correctness.
  A slight improvement was found later, which is posthumously described by
  Robert G. Burger and R. Kent Dybvig. David Gay's `dtoa.c` routine is
  a popular implementation of this strategy.

- The "Grisu" family of algorithm is first described by Florian Loitsch.
  They use very cheap integer-only procedure to determine the close-to-correct
  representation which is at least guaranteed to be shortest. The variant,
  Grisu3, actively detects if the resulting representation is incorrect.

We implement both algorithms with necessary tweaks to suit our requirements.
In particular, published literatures are short of the actual implementation
difficulties like how to avoid arithmetic overflows. Each implementation,
available in `strategy::dragon` and `strategy::grisu` respectively,
extensively describes all necessary justifications and many proofs for them.
(It is still difficult to follow though. You have been warned.)

Both implementations expose two public functions:

- `format_shortest(decoded, buf)`, which always needs at least
  `MAX_SIG_DIGITS` digits of buffer. Implements the shortest mode.

- `format_exact(decoded, buf, limit)`, which accepts as small as
  one digit of buffer. Implements exact and fixed modes.

They try to fill the `u8` buffer with digits and returns the number of digits
written and the exponent `k`. They are total for all finite `f32` and `f64`
inputs (Grisu internally falls back to Dragon if necessary).

The rendered digits are formatted into the actual string form with
four functions:

- `to_shortest_str` prints the shortest representation, which can be padded by
  zeroes to make *at least* given number of fractional digits.

- `to_shortest_exp_str` prints the shortest representation, which can be
  padded by zeroes when its exponent is in the specified ranges,
  or can be printed in the exponential form such as `1.23e45`.

- `to_exact_exp_str` prints the exact representation with given number of
  digits in the exponential form.

- `to_exact_fixed_str` prints the fixed representation with *exactly*
  given number of fractional digits.

They all return a slice of preallocated `Part` array, which corresponds to
the individual part of strings: a fixed string, a part of rendered digits,
a number of zeroes or a small (`u16`) number. The caller is expected to
provide a large enough buffer and `Part` array, and to assemble the final
string from resulting `Part`s itself.

All algorithms and formatting functions are accompanied by extensive tests
in `coretests::num::flt2dec` module. It also shows how to use individual
functions.

*/

// макар това да е подробно документирано, то по принцип е частно, което се публикува само за тестване.
// не ни излагайте.
#![doc(hidden)]
#![unstable(
    feature = "flt2dec",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

pub use self::decoder::{decode, DecodableFloat, Decoded, FullDecoded};

use crate::mem::MaybeUninit;

pub mod decoder;
pub mod estimator;

/// Алгоритми за генериране на цифри.
pub mod strategy {
    pub mod dragon;
    pub mod grisu;
}

/// Минималният размер на буфера, необходим за най-краткия режим.
///
/// Извличането е малко нетривиално, но това е едно плюс максималния брой значими десетични цифри от алгоритмите за форматиране с най-кратък резултат.
///
/// Точната формула е `ceil(# bits in mantissa * log_10 2 + 1)`.
pub const MAX_SIG_DIGITS: usize = 17;

/// Когато `d` съдържа десетични цифри, увеличете последната цифра и разпространете пренасянето.
/// Връща следваща цифра, когато причинява промяна на дължината.
#[doc(hidden)]
pub fn round_up(d: &mut [u8]) -> Option<u8> {
    match d.iter().rposition(|&c| c != b'9') {
        Some(i) => {
            // d [i + 1..n] е всички деветки
            d[i] += 1;
            for j in i + 1..d.len() {
                d[j] = b'0';
            }
            None
        }
        None if d.len() > 0 => {
            // 999..999 закръглява до 1000..000 с увеличена степен
            d[0] = b'1';
            for j in 1..d.len() {
                d[j] = b'0';
            }
            Some(b'0')
        }
        None => {
            // празен буфер се закръгля (малко странно, но разумно)
            Some(b'1')
        }
    }
}

/// Форматирани части.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Part<'a> {
    /// Даден брой нулеви цифри.
    Zero(usize),
    /// Буквално число до 5 цифри.
    Num(u16),
    /// Дословно копие на дадени байтове.
    Copy(&'a [u8]),
}

impl<'a> Part<'a> {
    /// Връща точната дължина на байта на дадена част.
    pub fn len(&self) -> usize {
        match *self {
            Part::Zero(nzeroes) => nzeroes,
            Part::Num(v) => {
                if v < 1_000 {
                    if v < 10 {
                        1
                    } else if v < 100 {
                        2
                    } else {
                        3
                    }
                } else {
                    if v < 10_000 { 4 } else { 5 }
                }
            }
            Part::Copy(buf) => buf.len(),
        }
    }

    /// Записва част в предоставения буфер.
    /// Връща броя на записаните байтове или `None`, ако буферът не е достатъчен.
    /// (Все още може да остави частично написани байтове в буфера; не разчитайте на това.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        let len = self.len();
        if out.len() >= len {
            match *self {
                Part::Zero(nzeroes) => {
                    for c in &mut out[..nzeroes] {
                        *c = b'0';
                    }
                }
                Part::Num(mut v) => {
                    for c in out[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                }
                Part::Copy(buf) => {
                    out[..buf.len()].copy_from_slice(buf);
                }
            }
            Some(len)
        } else {
            None
        }
    }
}

/// Форматиран резултат, съдържащ една или повече части.
/// Това може да бъде записано в байтовия буфер или преобразувано в разпределения низ.
#[allow(missing_debug_implementations)]
#[derive(Clone)]
pub struct Formatted<'a> {
    /// Байтов фрагмент, представляващ знак, или `""`, `"-"` или `"+"`.
    pub sign: &'static str,
    /// Форматирани части, които трябва да бъдат изобразени след знак и допълнително нулево подпълване.
    pub parts: &'a [Part<'a>],
}

impl<'a> Formatted<'a> {
    /// Връща точната дължина на байта на комбиниран форматиран резултат.
    pub fn len(&self) -> usize {
        let mut len = self.sign.len();
        for part in self.parts {
            len += part.len();
        }
        len
    }

    /// Записва всички форматирани части в предоставения буфер.
    /// Връща броя на записаните байтове или `None`, ако буферът не е достатъчен.
    /// (Все още може да остави частично написани байтове в буфера; не разчитайте на това.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        if out.len() < self.sign.len() {
            return None;
        }
        out[..self.sign.len()].copy_from_slice(self.sign.as_bytes());

        let mut written = self.sign.len();
        for part in self.parts {
            let len = part.write(&mut out[written..])?;
            written += len;
        }
        Some(written)
    }
}

/// Формати, дадени десетични цифри `0.<...buf...> * 10^exp` в десетична форма с поне зададен брой дробни цифри.
///
/// Резултатът се съхранява в предоставения масив от части и се връща парче от записани части.
///
/// `frac_digits` може да бъде по-малък от броя на действителните дробни цифри в `buf`;
/// тя ще бъде игнорирана и ще бъдат отпечатани цели цифри.Използва се само за отпечатване на допълнителни нули след изобразени цифри.
/// По този начин `frac_digits` от 0 означава, че ще отпечатва само дадени цифри и нищо друго.
///
fn digits_to_dec_str<'a>(
    buf: &'a [u8],
    exp: i16,
    frac_digits: usize,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 4);

    // ако има ограничение за последната цифрова позиция, се приема, че `buf` е подплатен с виртуални нули.
    // броят на виртуалните нули, `nzeroes`, е равен на `max(0, exp + frac_digits - buf.len())`, така че позицията на последната цифра `exp - buf.len() - nzeroes` е не повече от `-frac_digits`:
    //
    //
    //                       |<-virtual->|
    //       | <----buf----> |нули |опит
    //    0. 1 2 3 4 5 6 7 8 9 _ _ _ _ _ _ x 10
    //    |                  |           |
    // 10 ^ опит 10^(exp-buf.len()) 10^(exp-buf.len()-nzeroes)
    //
    // `nzeroes` се изчислява индивидуално за всеки случай, за да се избегне преливане.
    //

    if exp <= 0 {
        // десетичната точка е преди изобразени цифри: [0.][000...000][1234][____]
        let minus_exp = -(exp as i32) as usize;
        parts[0] = MaybeUninit::new(Part::Copy(b"0."));
        parts[1] = MaybeUninit::new(Part::Zero(minus_exp));
        parts[2] = MaybeUninit::new(Part::Copy(buf));
        if frac_digits > buf.len() && frac_digits - buf.len() > minus_exp {
            parts[3] = MaybeUninit::new(Part::Zero((frac_digits - buf.len()) - minus_exp));
            // БЕЗОПАСНОСТ: току-що инициализирахме елементите `..4`.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
        } else {
            // БЕЗОПАСНОСТ: току-що инициализирахме елементите `..3`.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
        }
    } else {
        let exp = exp as usize;
        if exp < buf.len() {
            // десетичната точка е вътре в изобразени цифри: [12][.][34][____]
            parts[0] = MaybeUninit::new(Part::Copy(&buf[..exp]));
            parts[1] = MaybeUninit::new(Part::Copy(b"."));
            parts[2] = MaybeUninit::new(Part::Copy(&buf[exp..]));
            if frac_digits > buf.len() - exp {
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits - (buf.len() - exp)));
                // БЕЗОПАСНОСТ: току-що инициализирахме елементите `..4`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // БЕЗОПАСНОСТ: току-що инициализирахме елементите `..3`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
            }
        } else {
            // десетичната точка е след изобразени цифри: [1234][____0000] или [1234][__][.][__].
            parts[0] = MaybeUninit::new(Part::Copy(buf));
            parts[1] = MaybeUninit::new(Part::Zero(exp - buf.len()));
            if frac_digits > 0 {
                parts[2] = MaybeUninit::new(Part::Copy(b"."));
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits));
                // БЕЗОПАСНОСТ: току-що инициализирахме елементите `..4`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // БЕЗОПАСНОСТ: току-що инициализирахме елементите `..2`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) }
            }
        }
    }
}

/// Форматира дадените десетични цифри `0.<...buf...> * 10^exp` в експоненциална форма с поне дадения брой значими цифри.
///
/// Когато `upper` е `true`, експонентата ще има префикс от `E`;иначе това е `e`.
/// Резултатът се съхранява в предоставения масив от части и се връща парче от записани части.
///
/// `min_digits` може да бъде по-малък от броя на действителните значими цифри в `buf`;
/// тя ще бъде игнорирана и ще бъдат отпечатани цели цифри.Използва се само за отпечатване на допълнителни нули след изобразени цифри.
/// По този начин `min_digits == 0` означава, че ще отпечата само дадените цифри и нищо друго.
///
fn digits_to_exp_str<'a>(
    buf: &'a [u8],
    exp: i16,
    min_ndigits: usize,
    upper: bool,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 6);

    let mut n = 0;

    parts[n] = MaybeUninit::new(Part::Copy(&buf[..1]));
    n += 1;

    if buf.len() > 1 || min_ndigits > 1 {
        parts[n] = MaybeUninit::new(Part::Copy(b"."));
        parts[n + 1] = MaybeUninit::new(Part::Copy(&buf[1..]));
        n += 2;
        if min_ndigits > buf.len() {
            parts[n] = MaybeUninit::new(Part::Zero(min_ndigits - buf.len()));
            n += 1;
        }
    }

    // 0.1234 x 10 ^ опит= 1.234 x 10 ^ (опит-1)
    let exp = exp as i32 - 1; // избягвайте преливането, когато exp е i16::MIN
    if exp < 0 {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E-" } else { b"e-" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(-exp as u16));
    } else {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E" } else { b"e" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(exp as u16));
    }
    // БЕЗОПАСНОСТ: току-що инициализирахме елементите `..n + 2`.
    unsafe { MaybeUninit::slice_assume_init_ref(&parts[..n + 2]) }
}

/// Опции за форматиране на подпис.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Sign {
    /// Отпечатва `-` само за отрицателните ненулеви стойности.
    Minus, // -inf -1 0 0 1 инф. Нан
    /// Отпечатва `-` само за всякакви отрицателни стойности (включително отрицателната нула).
    MinusRaw, // -inf -1 -0 0 1 инф. Нан
    /// Отпечатва `-` за отрицателните ненулеви стойности или `+` в противен случай.
    MinusPlus, // -inf -1 +0 +0 +1 + инф. Нан
    /// Отпечатва `-` за всякакви отрицателни стойности (включително отрицателната нула) или `+` в противен случай.
    MinusPlusRaw, // -inf -1 -0 +0 +1 + инф. Нан
}

/// Връща статичния байт низ, съответстващ на знака за форматиране.
/// Може да бъде `""`, `"+"` или `"-"`.
fn determine_sign(sign: Sign, decoded: &FullDecoded, negative: bool) -> &'static str {
    match (*decoded, sign) {
        (FullDecoded::Nan, _) => "",
        (FullDecoded::Zero, Sign::Minus) => "",
        (FullDecoded::Zero, Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (FullDecoded::Zero, Sign::MinusPlus) => "+",
        (FullDecoded::Zero, Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
        (_, Sign::Minus | Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (_, Sign::MinusPlus | Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
    }
}

/// Форматира даденото число с плаваща запетая в десетична форма с поне зададен брой дробни цифри.
/// Резултатът се съхранява в предоставения масив от части, докато се използва даден байтов буфер като надраскване.
/// `upper` понастоящем не се използва, но е оставено за решението на future да промени случая на неограничени стойности, т.е. `inf` и `nan`.
///
/// Първата част, която трябва да бъде изобразена, винаги е `Part::Sign` (която може да бъде празен низ, ако не е изобразен знак).
///
/// `format_shortest` трябва да е основната функция за генериране на цифри.
/// Той трябва да върне частта от буфера, която той инициализира.
/// Вероятно бихте искали `strategy::grisu::format_shortest` за това.
///
/// `frac_digits` може да бъде по-малък от броя на действителните дробни цифри в `v`;
/// тя ще бъде игнорирана и ще бъдат отпечатани цели цифри.Използва се само за отпечатване на допълнителни нули след изобразени цифри.
/// По този начин `frac_digits` от 0 означава, че ще отпечатва само дадени цифри и нищо друго.
///
/// Байтовият буфер трябва да бъде с дължина поне `MAX_SIG_DIGITS` байта.
/// Трябва да има поне 4 налични части, поради най-лошия случай като `[+][0.][0000][2][0000]` с `frac_digits = 10`.
///
///
///
pub fn to_shortest_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);
    assert!(buf.len() >= MAX_SIG_DIGITS);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // БЕЗОПАСНОСТ: току-що инициализирахме елементите `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // БЕЗОПАСНОСТ: току-що инициализирахме елементите `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // БЕЗОПАСНОСТ: току-що инициализирахме елементите `..2`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // БЕЗОПАСНОСТ: току-що инициализирахме елементите `..1`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
        }
    }
}

/// Форматира даденото число с плаваща запетая в десетична форма или експоненциална форма, в зависимост от получения експонентен показател.
/// Резултатът се съхранява в предоставения масив от части, докато се използва даден байтов буфер като надраскване.
/// `upper` се използва за определяне на случая на неограничени стойности (`inf` и `nan`) или случая на експонентен префикс (`e` или `E`).
/// Първата част, която трябва да бъде изобразена, винаги е `Part::Sign` (която може да бъде празен низ, ако не е изобразен знак).
///
/// `format_shortest` трябва да е основната функция за генериране на цифри.
/// Той трябва да върне частта от буфера, която той инициализира.
/// Вероятно бихте искали `strategy::grisu::format_shortest` за това.
///
/// `dec_bounds` е кортеж `(lo, hi)`, така че номерът е форматиран като десетичен само когато `10^lo <= V < 10^hi`.
/// Имайте предвид, че това е *привидният*`V` вместо действителния `v`!По този начин всеки отпечатан експонент в експоненциална форма не може да бъде в този диапазон, като се избягва объркване.
///
///
/// Байтовият буфер трябва да бъде с дължина поне `MAX_SIG_DIGITS` байта.
/// Трябва да има поне 6 налични части, поради най-лошия случай като `[+][1][.][2345][e][-][6]`.
///
///
///
///
///
pub fn to_shortest_exp_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    dec_bounds: (i16, i16),
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(dec_bounds.0 <= dec_bounds.1);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // БЕЗОПАСНОСТ: току-що инициализирахме елементите `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // БЕЗОПАСНОСТ: току-що инициализирахме елементите `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            parts[0] = if dec_bounds.0 <= 0 && 0 < dec_bounds.1 {
                MaybeUninit::new(Part::Copy(b"0"))
            } else {
                MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }))
            };
            // БЕЗОПАСНОСТ: току-що инициализирахме елементите `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            let vis_exp = exp as i32 - 1;
            let parts = if dec_bounds.0 as i32 <= vis_exp && vis_exp < dec_bounds.1 as i32 {
                digits_to_dec_str(buf, exp, 0, parts)
            } else {
                digits_to_exp_str(buf, exp, 0, upper, parts)
            };
            Formatted { sign, parts }
        }
    }
}

/// Връща доста грубо приближение (горна граница) за максималния размер на буфера, изчислен от дадената декодирана степен.
///
/// Точният лимит е:
///
/// - когато `exp < 0`, максималната дължина е `ceil(log_10 (5^-exp * (2^64 - 1)))`.
/// - когато `exp >= 0`, максималната дължина е `ceil(log_10 (2^exp * (2^64 - 1)))`.
///
/// `ceil(log_10 (x^exp * (2^64 - 1)))` е по-малко от `ceil(log_10 (2^64 - 1)) + ceil(exp *log_10 x)`, което от своя страна е по-малко от `20 + (1 + exp* log_10 x)`.
/// Ние използваме фактите `log_10 2 < 5/16` и `log_10 5 < 12/16`, което е достатъчно за нашите цели.
///
/// Защо се нуждаем от това?Функциите `format_exact` ще запълнят целия буфер, освен ако не са ограничени от ограничението от последната цифра, но е възможно броят на поисканите цифри да е нелепо голям (да речем, 30 000 цифри).
///
/// По-голямата част от буфера ще бъде запълнена с нули, така че не искаме да разпределяме целия буфер предварително.
/// Следователно, за дадени аргументи,
/// 826 байта буфер трябва да са достатъчни за `f64`.Сравнете това с действителното число за най-лошия случай: 770 байта (когато `exp = -1074`).
///
///
///
///
///
fn estimate_max_buf_len(exp: i16) -> usize {
    21 + ((if exp < 0 { -12 } else { 5 } * exp as i32) as usize >> 4)
}

/// Формати, дадени с число с плаваща запетая в експоненциална форма с точно зададен брой значими цифри.
/// Резултатът се съхранява в предоставения масив от части, докато се използва даден байтов буфер като надраскване.
/// `upper` се използва за определяне на регистъра на експонентен префикс (`e` или `E`).
/// Първата част, която трябва да бъде изобразена, винаги е `Part::Sign` (която може да бъде празен низ, ако не е изобразен знак).
///
/// `format_exact` трябва да е основната функция за генериране на цифри.
/// Той трябва да върне частта от буфера, която той инициализира.
/// Вероятно бихте искали `strategy::grisu::format_exact` за това.
///
/// Байтовият буфер трябва да бъде дълъг поне `ndigits` байта, освен ако `ndigits` не е толкова голям, че някога ще бъде записан само фиксираният брой цифри.
/// (Точката на преобръщане за `f64` е около 800, така че 1000 байта трябва да са достатъчни.) Трябва да има поне 6 части на разположение, поради най-лошия случай като `[+][1][.][2345][e][-][6]`.
///
///
///
///
///
pub fn to_exact_exp_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    ndigits: usize,
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(ndigits > 0);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // БЕЗОПАСНОСТ: току-що инициализирахме елементите `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // БЕЗОПАСНОСТ: току-що инициализирахме елементите `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if ndigits > 1 {
                // [0.][0000][e0]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(ndigits - 1));
                parts[2] = MaybeUninit::new(Part::Copy(if upper { b"E0" } else { b"e0" }));
                Formatted {
                    sign,
                    // БЕЗОПАСНОСТ: току-що инициализирахме елементите `..3`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }));
                Formatted {
                    sign,
                    // БЕЗОПАСНОСТ: току-що инициализирахме елементите `..1`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= ndigits || buf.len() >= maxlen);

            let trunc = if ndigits < maxlen { ndigits } else { maxlen };
            let (buf, exp) = format_exact(decoded, &mut buf[..trunc], i16::MIN);
            Formatted { sign, parts: digits_to_exp_str(buf, exp, ndigits, upper, parts) }
        }
    }
}

/// Формати, дадени с число с плаваща запетая в десетична форма с точно зададен брой дробни цифри.
/// Резултатът се съхранява в предоставения масив от части, докато се използва даден байтов буфер като надраскване.
/// `upper` понастоящем не се използва, но е оставено за решението на future да промени случая на неограничени стойности, т.е. `inf` и `nan`.
/// Първата част, която трябва да бъде изобразена, винаги е `Part::Sign` (която може да бъде празен низ, ако не е изобразен знак).
///
/// `format_exact` трябва да е основната функция за генериране на цифри.
/// Той трябва да върне частта от буфера, която той инициализира.
/// Вероятно бихте искали `strategy::grisu::format_exact` за това.
///
/// Байтовият буфер трябва да е достатъчен за изхода, освен ако `frac_digits` не е толкова голям, че някога ще бъде записан само фиксираният брой цифри.
/// (Точката на преобръщане за `f64` е около 800 и трябва да са достатъчни 1000 байта.) Трябва да са налични поне 4 части, поради най-лошия случай като `[+][0.][0000][2][0000]` с `frac_digits = 10`.
///
///
///
///
///
pub fn to_exact_fixed_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // БЕЗОПАСНОСТ: току-що инициализирахме елементите `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // БЕЗОПАСНОСТ: току-що инициализирахме елементите `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // БЕЗОПАСНОСТ: току-що инициализирахме елементите `..2`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // БЕЗОПАСНОСТ: току-що инициализирахме елементите `..1`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= maxlen);

            // *възможно е*`frac_digits` да е абсурдно голям.
            // `format_exact` ще приключи с изобразяването на цифри много по-рано в този случай, защото сме строго ограничени от `maxlen`.
            //
            let limit = if frac_digits < 0x8000 { -(frac_digits as i16) } else { i16::MIN };
            let (buf, exp) = format_exact(decoded, &mut buf[..maxlen], limit);
            if exp <= limit {
                // ограничението не може да бъде спазено, така че това трябва да се окаже като нула, независимо от `exp`.
                // това не включва случая, че ограничението е спазено само след окончателното закръгляване;това е обикновен случай с `exp = limit + 1`.
                //
                debug_assert_eq!(buf.len(), 0);
                if frac_digits > 0 {
                    // [0.][0000]
                    parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                    parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                    Formatted {
                        sign,
                        // БЕЗОПАСНОСТ: току-що инициализирахме елементите `..2`.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                    }
                } else {
                    parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                    Formatted {
                        sign,
                        // БЕЗОПАСНОСТ: току-що инициализирахме елементите `..1`.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                    }
                }
            } else {
                Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
            }
        }
    }
}