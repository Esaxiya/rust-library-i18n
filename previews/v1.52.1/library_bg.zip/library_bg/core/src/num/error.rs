//! Типове грешки за преобразуване в интегрални типове.

use crate::convert::Infallible;
use crate::fmt;

/// Типът грешка се връща, когато проверено преобразуване на интегрален тип се провали.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Съвпадение, а не принуда, за да сте сигурни, че код като `From<Infallible> for TryFromIntError` по-горе ще продължи да работи, когато `Infallible` стане псевдоним на `!`.
        //
        //
        match never {}
    }
}

/// Грешка, която може да бъде върната при анализиране на цяло число.
///
/// Тази грешка се използва като тип грешка за функциите `from_str_radix()` на примитивните цели числа, като [`i8::from_str_radix`].
///
/// # Потенциални причини
///
/// Наред с други причини, `ParseIntError` може да бъде хвърлен поради водещо или последващо празно пространство в низа, например, когато е получено от стандартния вход.
///
/// Използването на метода [`str::trim()`] гарантира, че не остава празно пространство преди анализирането.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum за съхраняване на различните видове грешки, които могат да доведат до неуспех при анализирането на цяло число.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Стойността, която се анализира, е празна.
    ///
    /// Наред с други причини, този вариант ще бъде конструиран при синтактичен анализ на празен низ.
    Empty,
    /// Съдържа невалидна цифра в своя контекст.
    ///
    /// Наред с други причини, този вариант ще бъде конструиран при синтактичен анализ на низ, който съдържа не-ASCII знак.
    ///
    /// Този вариант също се конструира, когато `+` или `-` е поставен погрешно в низ или самостоятелно, или в средата на число.
    ///
    ///
    InvalidDigit,
    /// Цялото число е твърде голямо, за да се съхранява в целевия целочислен тип.
    PosOverflow,
    /// Цялото число е твърде малко, за да се съхранява в целевия целочислен тип.
    NegOverflow,
    /// Стойността беше нула
    ///
    /// Този вариант ще се излъчи, когато синтактичният анализ има стойност нула, което би било незаконно за ненулеви типове.
    ///
    Zero,
}

impl ParseIntError {
    /// Извежда подробната причина за разбор на цяло число неуспешно.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}