macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Най-малката стойност, която може да бъде представена от този цял тип.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// Най-голямата стойност, която може да бъде представена от този цял тип.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// Размерът на този цял тип в битове.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Преобразува срезов низ в дадена основа в цяло число.
        ///
        /// Очаква се низът да е незадължителен знак `+`, последван от цифри.
        ///
        /// Водещият и последващият интервал представляват грешка.
        /// Цифрите са подмножество от тези знаци, в зависимост от `radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Тази функция panics, ако `radix` не е в диапазона от 2 до 36.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Връща броя на единиците в двоичното представяне на `self`.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// Връща броя на нулите в двоичното представяне на `self`.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Връща броя на водещите нули в двоичното представяне на `self`.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// Връща броя на последващите нули в двоичното представяне на `self`.
        ///
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// Връща броя на водещите в двоичното представяне на `self`.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// Връща броя на последващите в двоичното представяне на `self`.
        ///
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Премества битовете наляво с определено количество, `n`, като увива пресечените битове до края на полученото цяло число.
        ///
        ///
        /// Моля, обърнете внимание, че това не е същата операция като преместващия оператор `<<`!
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Премества битовете надясно с определено количество, `n`, като увива пресечените битове в началото на полученото цяло число.
        ///
        ///
        /// Моля, обърнете внимание, че това не е същата операция като преместващия оператор `>>`!
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// Обръща реда на байтовете на цялото число.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// нека m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// Обръща реда на битовете в цялото число.
        /// Най-малко значимият бит става най-значимият бит, вторият най-малко значим бит става вторият най-значим бит и т.н.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// нека m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Преобразува цяло число от голям endian в endianness на целта.
        ///
        /// На големия ендиан това е не-операция.
        /// На малкия ендиан байтовете се разменят.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ако cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } друго {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Преобразува цяло число от малко endian в endianness на целта.
        ///
        /// На малкия ендиан това е не-операция.
        /// На голям ендиан байтовете се разменят.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ако cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } друго {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Преобразува `self` в голям ендиан от крайния край на целта.
        ///
        /// На големия ендиан това е не-операция.
        /// На малкия ендиан байтовете се разменят.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ако cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } иначе { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // или да не бъде?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Преобразува `self` в малък ендиан от крайния край на целта.
        ///
        /// На малкия ендиан това е не-операция.
        /// На голям ендиан байтовете се разменят.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ако cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } иначе { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Проверено добавяне на цяло число.
        /// Изчислява `self + rhs`, връщайки `None`, ако е възникнало препълване.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Непроверено добавяне на цяло число.Изчислява `self + rhs`, като приеме, че не може да възникне преливане.
        /// Това води до недефинирано поведение, когато
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // БЕЗОПАСНОСТ: повикващият трябва да спазва договора за безопасност за `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Проверено изваждане на цяло число.
        /// Изчислява `self - rhs`, връщайки `None`, ако е възникнало препълване.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Непроверено изваждане на цяло число.Изчислява `self - rhs`, като приеме, че не може да възникне преливане.
        /// Това води до недефинирано поведение, когато
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // БЕЗОПАСНОСТ: повикващият трябва да спазва договора за безопасност за `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Проверено целочислено умножение.
        /// Изчислява `self * rhs`, връщайки `None`, ако е възникнало препълване.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Непроверено умножение на цяло число.Изчислява `self * rhs`, като приеме, че не може да възникне преливане.
        /// Това води до недефинирано поведение, когато
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // БЕЗОПАСНОСТ: повикващият трябва да спазва договора за безопасност за `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Проверено целочислено деление.
        /// Изчислява `self / rhs`, връщайки `None`, ако `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // БЕЗОПАСНОСТ: div by zero е проверен по-горе и неподписаните типове нямат други
                // режими на отказ за разделяне
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Проверено евклидово деление.
        /// Изчислява `self.div_euclid(rhs)`, връщайки `None`, ако `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// Проверен остатък от цяло число.
        /// Изчислява `self % rhs`, връщайки `None`, ако `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // БЕЗОПАСНОСТ: div by zero е проверен по-горе и неподписаните типове нямат други
                // режими на отказ за разделяне
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Проверен евклидов модул.
        /// Изчислява `self.rem_euclid(rhs)`, връщайки `None`, ако `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Проверено отрицание.Изчислява `-self`, връща `None`, освен ако `self==
        /// 0`.
        ///
        /// Имайте предвид, че отричането на всяко положително цяло число ще прелее.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Проверена смяна наляво.
        /// Изчислява `self << rhs`, връщайки `None`, ако `rhs` е по-голям или равен на броя на битовете в `self`.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Проверена смяна надясно.
        /// Изчислява `self >> rhs`, връщайки `None`, ако `rhs` е по-голям или равен на броя на битовете в `self`.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Проверена степенуване.
        /// Изчислява `self.pow(exp)`, връщайки `None`, ако е възникнало препълване.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // тъй като exp!=0, накрая exp трябва да бъде 1.
            // Справете се с последния бит на експонентата отделно, тъй като квадратирането на основата след това не е необходимо и може да доведе до ненужно преливане.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Насищащо добавяне на цяло число.
        /// Изчислява `self + rhs`, насищайки в числовите граници, вместо да прелива.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Насищащо изваждане на цяло число.
        /// Изчислява `self - rhs`, насищайки в числовите граници, вместо да прелива.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Насищащо цяло умножение.
        /// Изчислява `self * rhs`, насищайки в числовите граници, вместо да прелива.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Насищащо цяло число степенуване.
        /// Изчислява `self.pow(exp)`, насищайки в числовите граници, вместо да прелива.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Опаковане (modular) добавка.
        /// Изчислява `self + rhs`, увивайки се на границата на типа.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Опаковане на изваждане на (modular).
        /// Изчислява `self - rhs`, увивайки се на границата на типа.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Опаковане на (modular) умножение.
        /// Изчислява `self * rhs`, увивайки се на границата на типа.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// Моля, обърнете внимание, че този пример се споделя между целочислени типове.
        /// Което обяснява защо `u8` се използва тук.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Опаковане на (modular) разделение.Изчислява `self / rhs`.
        /// Увитото разделяне на неподписани типове е просто нормално разделяне.
        /// Няма начин някога да се случи опаковане.
        /// Тази функция съществува, така че всички операции се отчитат в операциите за опаковане.
        ///
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Опаковане на евклидово разделение.Изчислява `self.div_euclid(rhs)`.
        /// Увитото разделяне на неподписани типове е просто нормално разделяне.
        /// Няма начин някога да се случи опаковане.
        /// Тази функция съществува, така че всички операции се отчитат в операциите за опаковане.
        /// Тъй като за положителните цели числа всички общи дефиниции на деление са равни, това е точно равно на `self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Опаковане на (modular) остатък.Изчислява `self % rhs`.
        /// Изчисляването на остатъка в опаковка за неподписани типове е просто редовното изчисление на остатъка.
        ///
        /// Няма начин някога да се случи опаковане.
        /// Тази функция съществува, така че всички операции се отчитат в операциите за опаковане.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Опаковане на Евклидов модул.Изчислява `self.rem_euclid(rhs)`.
        /// Увитото изчисляване по модул за неподписани типове е само редовното изчисление на остатъка.
        /// Няма начин някога да се случи опаковане.
        /// Тази функция съществува, така че всички операции се отчитат в операциите за опаковане.
        /// Тъй като за положителните цели числа всички общи дефиниции на деление са равни, това е точно равно на `self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Опаковане на отрицание (modular).
        /// Изчислява `-self`, увивайки се на границата на типа.
        ///
        /// Тъй като неподписаните типове нямат отрицателни еквиваленти, всички приложения на тази функция ще се увиват (с изключение на `-0`).
        /// За стойности, по-малки от съответния максимум на съответния тип, резултатът е същият като излъчване на съответната подписана стойност.
        ///
        /// Всички по-големи стойности са еквивалентни на `MAX + 1 - (val - MAX - 1)`, където `MAX` е максимумът на съответния подписан тип.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// Моля, обърнете внимание, че този пример се споделя между целочислени типове.
        /// Което обяснява защо `i8` се използва тук.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic без битово изместване наляво;
        /// дава `self << mask(rhs)`, където `mask` премахва всички битове от висок порядък на `rhs`, които биха накарали смяната да надвишава битовата ширина на типа.
        ///
        /// Имайте предвид, че това *не* е същото като завъртане наляво;RHS на превключващата смяна наляво е ограничена до обхвата на типа, вместо битовете, изместени извън LHS, да бъдат върнати в другия край.
        /// Всички примитивни цели числа изпълняват функция [`rotate_left`](Self::rotate_left), която вместо това може да е това, което искате.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // БЕЗОПАСНОСТ: маскирането от битовия размер на типа гарантира, че няма да се изместваме
            // извън границите
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic без битово отместване надясно;
        /// дава `self >> mask(rhs)`, където `mask` премахва всички битове от висок порядък на `rhs`, които биха накарали смяната да надвишава битовата ширина на типа.
        ///
        /// Имайте предвид, че това *не* е същото като завъртане надясно;RHS на увиващата смяна надясно е ограничен до обхвата на типа, а не битовете, изместени извън LHS, се връщат в другия край.
        /// Всички примитивни цели числа изпълняват функция [`rotate_right`](Self::rotate_right), която вместо това може да е това, което искате.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // БЕЗОПАСНОСТ: маскирането от битовия размер на типа гарантира, че няма да се изместваме
            // извън границите
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Опаковане на степенуване на (modular).
        /// Изчислява `self.pow(exp)`, увивайки се на границата на типа.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // тъй като exp!=0, накрая exp трябва да бъде 1.
            // Справете се с последния бит на експонентата отделно, тъй като квадратирането на основата след това не е необходимо и може да доведе до ненужно преливане.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Изчислява `self` + `rhs`
        ///
        /// Връща кортеж от добавянето заедно с булева стойност, указваща дали ще възникне аритметично препълване.
        /// Ако би имало преливане, тогава се връща увитата стойност.
        ///
        /// # Examples
        ///
        /// Основна употреба
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Изчислява `self`, `rhs`
        ///
        /// Връща кортеж от изваждането заедно с булева стойност, указваща дали ще възникне аритметично препълване.
        /// Ако би имало преливане, тогава се връща увитата стойност.
        ///
        /// # Examples
        ///
        /// Основна употреба
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Изчислява умножението на `self` и `rhs`.
        ///
        /// Връща кортеж от умножението заедно с булева стойност, указваща дали ще възникне аритметично препълване.
        /// Ако би имало преливане, тогава се връща увитата стойност.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// Моля, обърнете внимание, че този пример се споделя между целочислени типове.
        /// Което обяснява защо `u32` се използва тук.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Изчислява делителя, когато `self` се дели на `rhs`.
        ///
        /// Връща кортеж на делителя заедно с булева стойност, указваща дали ще възникне аритметично препълване.
        /// Имайте предвид, че за неподписани цели числа никога не се получава препълване, така че втората стойност винаги е `false`.
        ///
        /// # Panics
        ///
        /// Тази функция ще panic, ако `rhs` е 0.
        ///
        /// # Examples
        ///
        /// Основна употреба
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Изчислява коефициента на евклидово деление `self.div_euclid(rhs)`.
        ///
        /// Връща кортеж на делителя заедно с булева стойност, указваща дали ще възникне аритметично препълване.
        /// Имайте предвид, че за неподписани цели числа никога не се получава препълване, така че втората стойност винаги е `false`.
        /// Тъй като за положителните цели числа всички общи дефиниции на деление са равни, това е точно равно на `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Тази функция ще panic, ако `rhs` е 0.
        ///
        /// # Examples
        ///
        /// Основна употреба
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Изчислява остатъка, когато `self` се дели на `rhs`.
        ///
        /// Връща кортеж от остатъка след разделяне заедно с булева стойност, указваща дали ще възникне аритметично препълване.
        /// Имайте предвид, че за неподписани цели числа никога не се получава препълване, така че втората стойност винаги е `false`.
        ///
        /// # Panics
        ///
        /// Тази функция ще panic, ако `rhs` е 0.
        ///
        /// # Examples
        ///
        /// Основна употреба
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Изчислява остатъка `self.rem_euclid(rhs)` сякаш чрез евклидово деление.
        ///
        /// Връща кортеж от модула след разделяне заедно с булева стойност, указваща дали ще възникне аритметично преливане.
        /// Имайте предвид, че за неподписани цели числа никога не се получава препълване, така че втората стойност винаги е `false`.
        /// Тъй като за положителните цели числа всички общи дефиниции на деление са равни, тази операция е точно равна на `self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Тази функция ще panic, ако `rhs` е 0.
        ///
        /// # Examples
        ///
        /// Основна употреба
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Негатира себе си по преливащ начин.
        ///
        /// Връща `!self + 1`, като използва операции за опаковане, за да върне стойността, която представлява отрицанието на тази неподписана стойност.
        /// Имайте предвид, че при положителни неподписани стойности винаги се получава препълване, но отрицанието на 0 не прелива.
        ///
        /// # Examples
        ///
        /// Основна употреба
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// Премества самостоятелно наляво от битове `rhs`.
        ///
        /// Връща кортеж от изместената версия на self заедно с булева стойност, указваща дали стойността на смяната е била по-голяма или равна на броя на битовете.
        /// Ако стойността на смяната е твърде голяма, тогава стойността е маскирана (N-1), където N е броят на битовете и тази стойност след това се използва за извършване на смяната.
        ///
        /// # Examples
        ///
        /// Основна употреба
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Премества се надясно с битове `rhs`.
        ///
        /// Връща кортеж от изместената версия на self заедно с булева стойност, указваща дали стойността на смяната е била по-голяма или равна на броя на битовете.
        /// Ако стойността на смяната е твърде голяма, тогава стойността е маскирана (N-1), където N е броят на битовете и тази стойност след това се използва за извършване на смяната.
        ///
        /// # Examples
        ///
        /// Основна употреба
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Издига себе си до мощността на `exp`, като използва степенуване чрез квадратура.
        ///
        /// Връща кортеж от степенуването заедно със bool, указващ дали е възникнало преливане.
        ///
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, вярно));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Драскане място за съхраняване на резултатите от overflowing_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // тъй като exp!=0, накрая exp трябва да бъде 1.
            // Справете се с последния бит на експонентата отделно, тъй като квадратирането на основата след това не е необходимо и може да доведе до ненужно преливане.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// Издига себе си до мощността на `exp`, като използва степенуване чрез квадратура.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // тъй като exp!=0, накрая exp трябва да бъде 1.
            // Справете се с последния бит на експонентата отделно, тъй като квадратирането на основата след това не е необходимо и може да доведе до ненужно преливане.
            //
            //
            acc * base
        }

        /// Извършва евклидово деление.
        ///
        /// Тъй като за положителните цели числа всички общи дефиниции на деление са равни, това е точно равно на `self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Тази функция ще panic, ако `rhs` е 0.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// Изчислява най-малкия остатък от `self (mod rhs)`.
        ///
        /// Тъй като за положителните цели числа всички общи дефиниции на деление са равни, това е точно равно на `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Тази функция ще panic, ако `rhs` е 0.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Връща `true`, ако и само ако `self == 2^k` за някои `k`.
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // Връща една по-малка от следващата степен на две.
        // (За 8u8 следващата степен на два е 8u8, а за 6u8 е 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // Този метод не може да препълни, тъй като в случаите на препълване `next_power_of_two` вместо това завършва връщането на максималната стойност на типа и може да върне 0 за 0.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // БЕЗОПАСНОСТ: Тъй като `p > 0`, той не може да се състои изцяло от водещи нули.
            // Това означава, че промяната винаги е в границите и някои процесори (като например Intel pre-haswell) имат по-ефективни ctlz вътрешни характеристики, когато аргументът е ненулев.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// Връща най-малката мощност от две, по-голяма или равна на `self`.
        ///
        /// Когато връщаната стойност прелива (т.е. `self > (1 << (N-1))` за тип `uN`), тя panics в режим за отстраняване на грешки и връщаната стойност се увива на 0 в режим на освобождаване (единствената ситуация, в която методът може да върне 0).
        ///
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// Връща най-малката мощност от две, по-голяма или равна на `n`.
        /// Ако следващата мощност на две е по-голяма от максималната стойност на типа, се връща `None`, в противен случай мощността на две се увива в `Some`.
        ///
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// Връща най-малката мощност от две, по-голяма или равна на `n`.
        /// Ако следващата мощност от две е по-голяма от максималната стойност на типа, връщаната стойност се увива в `0`.
        ///
        ///
        /// # Examples
        ///
        /// Основна употреба:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Върнете представянето на паметта на това цяло число като байтов масив в байтов ред на big-endian (network).
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Върнете представянето на паметта на това цяло число като байтов масив в малък байтов ред.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Върнете представянето на паметта на това цяло число като байтов масив в естествен байт ред.
        ///
        /// Тъй като се използва родният край на целевата платформа, преносимият код вместо това трябва да използва [`to_be_bytes`] или [`to_le_bytes`], както е подходящо.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     байта, ако cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } друго {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // БЕЗОПАСНОСТ: const звук, защото целите числа са обикновени стари типове данни, така че винаги можем
        // ги преобразуват в масиви от байтове
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // БЕЗОПАСНОСТ: целите числа са обикновени стари типове данни, така че винаги можем да ги трансмутираме
            // масиви от байтове
            unsafe { mem::transmute(self) }
        }

        /// Върнете представянето на паметта на това цяло число като байтов масив в естествен байт ред.
        ///
        ///
        /// [`to_ne_bytes`] трябва да се предпочита пред това, когато е възможно.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// нека байтове= num.as_ne_bytes();
        /// assert_eq!(
        ///     байта, ако cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } друго {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // БЕЗОПАСНОСТ: целите числа са обикновени стари типове данни, така че винаги можем да ги трансмутираме
            // масиви от байтове
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Създайте естествена цялостна стойност на endian от нейното представяне като байтов масив в big endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// използвайте std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * вход=почивка;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Създайте естествена цялостна стойност на endian от нейното представяне като байтов масив в малко endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// използвайте std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * вход=почивка;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Създайте естествена цялостна цялостна стойност от нейното представяне в паметта като байтов масив в естествената крайност.
        ///
        /// Тъй като се използва родният край на целевата платформа, преносимият код вероятно иска да използва [`from_be_bytes`] или [`from_le_bytes`], както е подходящо вместо това.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } друго {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// използвайте std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * вход=почивка;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // БЕЗОПАСНОСТ: const звук, защото целите числа са обикновени стари типове данни, така че винаги можем
        // трансмутирайте им
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // БЕЗОПАСНОСТ: целите числа са обикновени стари типове данни, така че винаги можем да ги преобразуваме
            unsafe { mem::transmute(bytes) }
        }

        /// Новият код трябва да предпочита да се използва
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Връща най-малката стойност, която може да бъде представена от този цял тип.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// Новият код трябва да предпочита да се използва
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Връща най-голямата стойност, която може да бъде представена от този цял тип.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}