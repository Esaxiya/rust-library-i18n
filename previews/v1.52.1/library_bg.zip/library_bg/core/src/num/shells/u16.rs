//! Константи за 16-битовия неподписан цяло число.
//!
//! *[See also the `u16` primitive type][u16].*
//!
//! Новият код трябва да използва свързаните константи директно върху примитивния тип.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u16`"
)]

int_module! { u16 }