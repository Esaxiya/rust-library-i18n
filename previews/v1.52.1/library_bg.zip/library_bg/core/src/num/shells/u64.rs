//! Константи за 64-битовия неподписан цяло число.
//!
//! *[See also the `u64` primitive type][u64].*
//!
//! Новият код трябва да използва свързаните константи директно върху примитивния тип.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u64`"
)]

int_module! { u64 }