//! Константи за типа с подписване на цяло число с размер на указателя.
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! Новият код трябва да използва свързаните константи директно върху примитивния тип.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }