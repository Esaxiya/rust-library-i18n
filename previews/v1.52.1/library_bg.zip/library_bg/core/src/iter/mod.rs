//! Композираема външна итерация.
//!
//! Ако сте се озовали с някаква колекция и имате нужда да извършите операция върху елементите на споменатата колекция, бързо ще се сблъскате с 'iterators'.
//! Итераторите са широко използвани в идиоматичния Rust код, така че си струва да се запознаете с тях.
//!
//! Преди да обясним повече, нека поговорим за това как е структуриран този модул:
//!
//! # Organization
//!
//! Този модул е до голяма степен организиран по тип:
//!
//! * [Traits] са основната част: тези traits определят какъв вид итератори съществуват и какво можете да правите с тях.Методите на тези traits си струва да отделите допълнително време за изучаване.
//! * [Functions] предоставят някои полезни начини за създаване на някои основни итератори.
//! * [Structs] често са типовете връщане на различните методи в traits на този модул.Обикновено ще искате да разгледате метода, който създава `struct`, а не самия `struct`.
//! За повече подробности защо, вижте '[Implementing Iterator](#Implementation-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Това е!Нека да разровим в итератори.
//!
//! # Iterator
//!
//! Сърцето и душата на този модул е [`Iterator`] Portrait.Ядрото на [`Iterator`] изглежда така:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Итераторът има метод [`next`], който при извикване връща [`Опция`]`<Item>`.
//! [`next`] ще върне [`Some(Item)`], докато има елементи и след като всички те са изчерпани, ще върне `None`, за да покаже, че итерацията е завършена.
//! Отделни итератори могат да изберат да възобновят итерацията и така извикването на [`next`] отново може или не може да започне да връща [`Some(Item)`] отново в някакъв момент (например вижте [`TryIter`]).
//!
//!
//! Пълната дефиниция на ["Iterator`] включва и редица други методи, но те са методи по подразбиране, изградени върху [`next`], и затова ги получавате безплатно.
//!
//! Итераторите също могат да се съставят и е обичайно те да бъдат свързани заедно, за да се направят по-сложни форми на обработка.Вижте раздела [Adapters](#adapters) по-долу за повече подробности.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Трите форми на итерация
//!
//! Има три често срещани метода, които могат да създават итератори от колекция:
//!
//! * `iter()`, който итерира през `&T`.
//! * `iter_mut()`, който итерира през `&mut T`.
//! * `into_iter()`, който итерира през `T`.
//!
//! Различните неща в стандартната библиотека могат да внедрят едно или повече от трите, където е подходящо.
//!
//! # Внедряване на Итератор
//!
//! Създаването на собствен итератор включва две стъпки: създаване на `struct`, за да държи състоянието на итератора, и след това внедряване на [`Iterator`] за този `struct`.
//! Ето защо в този модул има толкова много `структури`: има по един за всеки итератор и адаптер за итератор.
//!
//! Нека направим итератор на име `Counter`, който брои от `1` до `5`:
//!
//! ```
//! // Първо, структурата:
//!
//! /// Итератор, който брои от един до пет
//! struct Counter {
//!     count: usize,
//! }
//!
//! // искаме броят ни да започне от един, така че нека добавим метод new() за помощ.
//! // Това не е строго необходимо, но е удобно.
//! // Имайте предвид, че стартираме `count` от нула, ще видим защо в изпълнението на `next()`'s по-долу.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // След това внедряваме `Iterator` за нашия `Counter`:
//!
//! impl Iterator for Counter {
//!     // ние ще броим с usize
//!     type Item = usize;
//!
//!     // next() е единственият необходим метод
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Увеличете броя ни.Ето защо започнахме от нула.
//!         self.count += 1;
//!
//!         // Проверете дали сме приключили с броенето или не.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // И сега можем да го използваме!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Извикването на [`next`] по този начин се повтаря.Rust има конструкция, която може да извиква [`next`] във вашия итератор, докато достигне `None`.Нека да преминем към това по-нататък.
//!
//! Също така имайте предвид, че `Iterator` осигурява изпълнение по подразбиране на методи като `nth` и `fold`, които извикват `next` вътрешно.
//! Възможно е обаче да се напише и персонализирана реализация на методи като `nth` и `fold`, ако итератор може да ги изчисли по-ефективно, без да извиква `next`.
//!
//! # `for` цикли и `IntoIterator`
//!
//! Синтаксисът на цикъла `for` на Rust всъщност е захар за итератори.Ето един основен пример за `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Това ще отпечата числата от едно до пет, всяко на свой ред.Но тук ще забележите нещо: никога не сме извикали нищо на нашия vector, за да създадем итератор.Какво дава?
//!
//! В стандартната библиотека има Portrait за конвертиране на нещо в итератор: [`IntoIterator`].
//! Този Portrait има един метод, [`into_iter`], който преобразува нещото, внедряващо [`IntoIterator`], в итератор.
//! Нека отново да разгледаме този цикъл `for` и в какво го преобразува компилаторът:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust отслабва това в:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Първо, извикваме `into_iter()` за стойността.След това съвпадаме с итератора, който се връща, извиквайки [`next`] отново и отново, докато не видим `None`.
//! В този момент излязохме от `break` и приключихме с итерацията.
//!
//! Тук има още един фин бит: стандартната библиотека съдържа интересна реализация на [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! С други думи, всички [`Iterator`] изпълняват [`IntoIterator`], като просто се връщат.Това означава две неща:
//!
//! 1. Ако пишете [`Iterator`], можете да го използвате с контур `for`.
//! 2. Ако създавате колекция, внедряването на [`IntoIterator`] за нея ще позволи вашата колекция да се използва с контура `for`.
//!
//! # Итерация чрез препратка
//!
//! Тъй като [`into_iter()`] взема `self` по стойност, използването на цикъл `for` за итерация над колекция консумира тази колекция.Често може да искате да прегледате колекция, без да я консумирате.
//! Много колекции предлагат методи, които предоставят итератори над референции, наречени съответно `iter()` и `iter_mut()`:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` все още е собственост на тази функция.
//! ```
//!
//! Ако тип колекция `C` предоставя `iter()`, той обикновено също така изпълнява `IntoIterator` за `&C`, с изпълнение, което просто извиква `iter()`.
//! По същия начин колекция `C`, която предоставя `iter_mut()`, обикновено прилага `IntoIterator` за `&mut C`, като делегира на `iter_mut()`.Това дава възможност за удобна стенография:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // същото като `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // същото като `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Докато много колекции предлагат `iter()`, не всички предлагат `iter_mut()`.
//! Например, мутирането на ключовете на [`HashSet<T>`] или [`HashMap<K, V>`] може да постави колекцията в несъответстващо състояние, ако хеш-ключовете се променят, така че тези колекции предлагат само `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Функциите, които приемат [`Iterator`] и връщат друг [`Iterator`], често се наричат " адаптери за итератор`, тъй като те са форма на " адаптер`
//! pattern'.
//!
//! Общите итераторни адаптери включват [`map`], [`take`] и [`filter`].
//! За повече информация вижте документацията им.
//!
//! Ако адаптер за итератор panics, итераторът ще бъде в неуточнено (но безопасно за паметта) състояние.
//! Това състояние също не е гарантирано да остане същото във версиите на Rust, така че трябва да избягвате да разчитате на точните стойности, върнати от итератор, който се паникьосва.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Итераторите (и итераторът [adapters](#adapters)) са *мързеливи*. Това означава, че само създаването на итератор не прави _do_ много. Всъщност нищо не се случва, докато не се обадите на [`next`].
//! Това понякога е източник на объркване, когато създавате итератор единствено за неговите странични ефекти.
//! Например методът [`map`] извиква затваряне на всеки елемент, през който се итерира:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Това няма да отпечата никакви стойности, тъй като ние само създадохме итератор, вместо да го използваме.Компилаторът ще ни предупреди за този вид поведение:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Идиоматичният начин да напишете [`map`] за неговите странични ефекти е да използвате цикъл `for` или да извикате метода [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Друг често срещан начин за оценка на итератор е използването на метода [`collect`] за създаване на нова колекция.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Итераторите не трябва да бъдат ограничени.Като пример, отворен диапазон е безкраен итератор:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Често се използва адаптер за итератор [`take`], за да се превърне безкраен итератор в краен:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Това ще отпечата числата `0` до `4`, всеки на свой ред.
//!
//! Имайте предвид, че методите за безкрайни итератори, дори тези, за които резултатът може да бъде математически определен за краен период от време, може да не приключат.
//! По-конкретно, методи като [`min`], които в общия случай изискват обхождане на всеки елемент в итератора, вероятно няма да се върнат успешно за безкрайни итератори.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // О, не!Безкраен цикъл!
//! // `ones.min()` причинява безкраен цикъл, така че няма да стигнем до този момент!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;