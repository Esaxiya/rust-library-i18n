use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// Обекти, които имат понятие за *наследник* и *предшественик* операции.
///
/// Операцията *наследник* се придвижва към стойности, които се сравняват по-големи.
/// Операцията *предшественик* се придвижва към стойности, които сравняват по-малко.
///
/// # Safety
///
/// Този Portrait е `unsafe`, тъй като неговото изпълнение трябва да бъде правилно за безопасността на изпълнението на `unsafe trait TrustedLen`, а иначе резултатите от използването на този Portrait могат да се доверят от кода `unsafe`, за да бъдат правилни и да изпълняват изброените задължения.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// Връща броя на стъпките *наследник*, необходими за преминаване от `start` до `end`.
    ///
    /// Връща `None`, ако броят на стъпките ще препълни `usize` (или е безкраен, или ако `end` никога няма да бъде достигнат).
    ///
    ///
    /// # Invariants
    ///
    /// За всеки `a`, `b` и `n`:
    ///
    /// * `steps_between(&a, &b) == Some(n)` ако и само ако `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` ако и само ако `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` само ако `a <= b`
    ///   * Следствие: `steps_between(&a, &b) == Some(0)` тогава и само ако `a == b`
    ///   * Имайте предвид, че `a <= b` наистина _not_ предполага `steps_between(&a, &b) != None`;
    ///     това е случаят, когато ще са необходими повече от `usize::MAX` стъпки, за да стигнете до `b`
    /// * `steps_between(&a, &b) == None` ако `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// Връща стойността, която би била получена чрез вземане на *наследник* на `self` `count` пъти.
    ///
    /// Ако това би препълнило диапазона от стойности, поддържани от `Self`, връща `None`.
    ///
    /// # Invariants
    ///
    /// За всеки `a`, `n` и `m`:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// За всеки `a`, `n` и `m`, където `n + m` не прелива:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// За всеки `a` и `n`:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// Връща стойността, която би била получена чрез вземане на *наследник* на `self` `count` пъти.
    ///
    /// Ако това би препълнило диапазона от стойности, поддържани от `Self`, тази функция е разрешена до panic, обвиване или насищане.
    ///
    /// Предлаганото поведение е към panic, когато са разрешени твърдения за отстраняване на грешки, и за увиване или насищане по друг начин.
    ///
    /// Небезопасният код не трябва да разчита на коректността на поведението след преливане.
    ///
    /// # Invariants
    ///
    /// За всеки `a`, `n` и `m`, където не възниква преливане:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// За всеки `a` и `n`, където не възниква преливане:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// Връща стойността, която би била получена чрез вземане на *наследник* на `self` `count` пъти.
    ///
    /// # Safety
    ///
    /// Неопределено поведение за тази операция е препълването на диапазона от стойности, поддържани от `Self`.
    /// Ако не можете да гарантирате, че това няма да прелее, вместо това използвайте `forward` или `forward_checked`.
    ///
    /// # Invariants
    ///
    /// За всеки `a`:
    ///
    /// * ако съществува `b`, такъв като `b > a`, е безопасно да се обадите на `Step::forward_unchecked(a, 1)`
    /// * ако има `b`, `n` такива, че `steps_between(&a, &b) == Some(n)`, е безопасно да се обадите на `Step::forward_unchecked(a, m)` за всеки `m <= n`.
    ///
    ///
    /// За всеки `a` и `n`, където не възниква преливане:
    ///
    /// * `Step::forward_unchecked(a, n)` е еквивалентно на `Step::forward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// Връща стойността, която би била получена чрез вземане на *предшественика* на `self` `count` пъти.
    ///
    /// Ако това би препълнило диапазона от стойности, поддържани от `Self`, връща `None`.
    ///
    /// # Invariants
    ///
    /// За всеки `a`, `n` и `m`:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// За всеки `a` и `n`:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// Връща стойността, която би била получена чрез вземане на *предшественика* на `self` `count` пъти.
    ///
    /// Ако това би препълнило диапазона от стойности, поддържани от `Self`, тази функция е разрешена до panic, обвиване или насищане.
    ///
    /// Предлаганото поведение е към panic, когато са разрешени твърдения за отстраняване на грешки, и за увиване или насищане по друг начин.
    ///
    /// Небезопасният код не трябва да разчита на коректността на поведението след преливане.
    ///
    /// # Invariants
    ///
    /// За всеки `a`, `n` и `m`, където не възниква преливане:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// За всеки `a` и `n`, където не възниква преливане:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// Връща стойността, която би била получена чрез вземане на *предшественика* на `self` `count` пъти.
    ///
    /// # Safety
    ///
    /// Неопределено поведение за тази операция е препълването на диапазона от стойности, поддържани от `Self`.
    /// Ако не можете да гарантирате, че това няма да прелее, вместо това използвайте `backward` или `backward_checked`.
    ///
    /// # Invariants
    ///
    /// За всеки `a`:
    ///
    /// * ако съществува `b`, такъв като `b < a`, е безопасно да се обадите на `Step::backward_unchecked(a, 1)`
    /// * ако има `b`, `n` такива, че `steps_between(&b, &a) == Some(n)`, е безопасно да се обадите на `Step::backward_unchecked(a, m)` за всеки `m <= n`.
    ///
    ///
    /// За всеки `a` и `n`, където не възниква преливане:
    ///
    /// * `Step::backward_unchecked(a, n)` е еквивалентно на `Step::backward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// Те все още се генерират макроси, тъй като целочислените литерали се разрешават на различни типове.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // БЕЗОПАСНОСТ: повикващият трябва да гарантира, че `start + n` няма да прелее.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // БЕЗОПАСНОСТ: повикващият трябва да гарантира, че `start - n` няма да прелее.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // При компилации за отстраняване на грешки задействайте panic при преливане.
            // Това трябва да оптимизира напълно в компилациите на изданията.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // Правете математическа опаковка, за да позволите напр `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // При компилации за отстраняване на грешки задействайте panic при преливане.
            // Това трябва да оптимизира напълно в компилациите на изданията.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // Правете математическа опаковка, за да позволите напр `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Това разчита на $u_narrower <=usize
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // ако n е извън обхвата, `unsigned_start + n` също
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // ако n е извън обхвата, `unsigned_start - n` също
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Това разчита на $i_narrower <=usize
                        //
                        // Кастингът за измерване разширява ширината, но запазва знака.
                        // Използвайте wrapping_sub в пространството на isize и преместете, за да използвате размера, за да изчислите разликата, която може да не се побере в диапазона на isize.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Опаковането обработва случаи като `Step::forward(-120_i8, 200) == Some(80_i8)`, въпреки че 200 е извън обхвата за i8.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // Добавянето е препълнено
                            }
                        }
                        // Ако n е извън обхвата на напр
                        // u8, тогава той е по-голям от целия диапазон за i8 е широк, така че `any_i8 + n` задължително прелива i8.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Опаковането обработва случаи като `Step::forward(-120_i8, 200) == Some(80_i8)`, въпреки че 200 е извън обхвата за i8.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // Изваждането е препълнено
                            }
                        }
                        // Ако n е извън обхвата на напр
                        // u8, тогава той е по-голям от целия диапазон за i8 е широк, така че `any_i8 - n` задължително прелива i8.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // Ако разликата е твърде голяма за напр
                            // i128, той също ще бъде твърде голям за използване с по-малко битове.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // БЕЗОПАСНОСТ: res е валиден скаляр на Unicode
            // (под 0x110000 и не в 0xD800..0xE000)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // БЕЗОПАСНОСТ: res е валиден скаляр на Unicode
        // (под 0x110000 и не в 0xD800..0xE000)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // БЕЗОПАСНОСТ: повикващият трябва да гарантира, че това няма да прелее
        // диапазонът от стойности за знак.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // БЕЗОПАСНОСТ: повикващият трябва да гарантира, че това няма да прелее
            // диапазонът от стойности за знак.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // БЕЗОПАСНОСТ: поради предишния договор това е гарантирано
        // от повикващия да бъде валиден знак.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // БЕЗОПАСНОСТ: повикващият трябва да гарантира, че това няма да прелее
        // диапазонът от стойности за знак.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // БЕЗОПАСНОСТ: повикващият трябва да гарантира, че това няма да прелее
            // диапазонът от стойности за знак.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // БЕЗОПАСНОСТ: поради предишния договор това е гарантирано
        // от повикващия да бъде валиден знак.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // БЕЗОПАСНОСТ: току-що проверена предпоставка
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // БЕЗОПАСНОСТ: току-що проверена предпоставка
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// Тези макроси генерират `ExactSizeIterator` импулси за различни типове диапазони.
//
// * `ExactSizeIterator::len` се изисква винаги да връща точен `usize`, така че обхватът не може да бъде по-дълъг от `usize::MAX`.
//
// * За целочислените типове в `Range<_>` това важи за типовете, по-тесни или по-широки от `usize`.
//   За целочислените типове в `RangeInclusive<_>` това важи за типовете *строго по-тесни* от `usize`, тъй като напр
//   `(0..=u64::MAX).len()` ще бъде `u64::MAX + 1`.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // Те са несъвместими според горните разсъждения, но премахването им би било сериозна промяна, тъй като бяха стабилизирани в Rust 1.0.0.
    // Така например
    // `(0..66_000_u32).len()` например ще се компилира без грешки или предупреждения на 16-битови платформи, но ще продължи да дава грешен резултат.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // Те са несъвместими според горните разсъждения, но премахването им би било сериозна промяна, тъй като бяха стабилизирани в Rust 1.26.0.
    // Така например
    // `(0..=u16::MAX).len()` например ще се компилира без грешки или предупреждения на 16-битови платформи, но ще продължи да дава грешен резултат.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // БЕЗОПАСНОСТ: току-що проверена предпоставка
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // БЕЗОПАСНОСТ: току-що проверена предпоставка
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // БЕЗОПАСНОСТ: току-що проверена предпоставка
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // БЕЗОПАСНОСТ: току-що проверена предпоставка
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // БЕЗОПАСНОСТ: току-що проверена предпоставка
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // БЕЗОПАСНОСТ: току-що проверена предпоставка
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}