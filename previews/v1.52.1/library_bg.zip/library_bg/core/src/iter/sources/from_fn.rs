use crate::fmt;

/// Създава нов итератор, където всяка итерация извиква предоставеното затваряне `F: FnMut() -> Option<T>`.
///
/// Това позволява да се създаде персонализиран итератор с каквото и да е поведение, без да се използва по-подробният синтаксис на създаване на специален тип и внедряване на [`Iterator`] Portrait за него.
///
/// Имайте предвид, че итераторът `FromFn` не прави предположения за поведението на затварянето и следователно консервативно не прилага [`FusedIterator`] или отменя [`Iterator::size_hint()`] от стандартния `(0, None)`.
///
///
/// Затварянето може да използва улавяния и неговата среда за проследяване на състоянието през итерации.В зависимост от начина на използване на итератора, това може да изисква да се посочи ключовата дума [`move`] в затварянето.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Нека повторно внедрим брояча итератор от [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Увеличете броя ни.Ето защо започнахме от нула.
///     count += 1;
///
///     // Проверете дали сме приключили с броенето или не.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Итератор, при който всяка итерация извиква предоставеното затваряне `F: FnMut() -> Option<T>`.
///
/// Този `struct` е създаден от функцията [`iter::from_fn()`].
/// Вижте документацията му за повече.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}