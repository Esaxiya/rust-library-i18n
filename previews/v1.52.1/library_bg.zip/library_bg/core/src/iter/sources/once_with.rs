use crate::iter::{FusedIterator, TrustedLen};

/// Създава итератор, който лениво генерира стойност точно веднъж, като извика предоставеното затваряне.
///
/// Това обикновено се използва за адаптиране на единичен генератор на стойност в [`chain()`] от други видове итерации.
/// Може би имате итератор, който покрива почти всичко, но имате нужда от допълнителен специален случай.
/// Може би имате функция, която работи върху итератори, но трябва да обработите само една стойност.
///
/// За разлика от [`once()`], тази функция ще генерира мързеливо стойността при поискване.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// use std::iter;
///
/// // едно е най-самотното число
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // само едно, това е всичко, което получаваме
/// assert_eq!(None, one.next());
/// ```
///
/// Верига заедно с друг итератор.
/// Да кажем, че искаме да повторим всеки файл от директорията `.foo`, но също и конфигурационен файл,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // трябва да конвертираме от итератор на DirEntry-s в итератор на PathBufs, затова използваме map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // сега, нашият итератор само за нашия конфигурационен файл
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // свържете двата итератора заедно в един голям итератор
/// let files = dirs.chain(config);
///
/// // това ще ни даде всички файлове в .foo, както и .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Итератор, който дава единичен елемент от тип `A` чрез прилагане на предоставеното затваряне `F: FnOnce() -> A`.
///
///
/// Този `struct` е създаден от функцията [`once_with()`].
/// Вижте документацията му за повече.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}