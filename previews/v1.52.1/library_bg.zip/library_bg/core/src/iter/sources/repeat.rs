use crate::iter::{FusedIterator, TrustedLen};

/// Създава нов итератор, който безкрайно повтаря отделен елемент.
///
/// Функцията `repeat()` повтаря една и съща стойност отново и отново.
///
/// Безкрайните итератори като `repeat()` често се използват с адаптери като [`Iterator::take()`], за да ги направят крайни.
///
/// Ако типът елемент на итератора, от който се нуждаете, не реализира `Clone` или ако не искате да запазите повтарящия се елемент в паметта, можете вместо това да използвате функцията [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// use std::iter;
///
/// // числото четири 4евър:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // да, все още четири
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Отивате крайно с [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // последният пример беше твърде много четворки.Нека имаме само четири четворки.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... и сега приключихме
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Итератор, който повтаря елемент безкрайно.
///
/// Този `struct` е създаден от функцията [`repeat()`].Вижте документацията му за повече.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}