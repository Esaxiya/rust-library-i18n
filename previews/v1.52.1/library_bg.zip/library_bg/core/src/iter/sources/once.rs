use crate::iter::{FusedIterator, TrustedLen};

/// Създава итератор, който дава елемент точно веднъж.
///
/// Това обикновено се използва за адаптиране на единична стойност в [`chain()`] от други видове итерации.
/// Може би имате итератор, който покрива почти всичко, но имате нужда от допълнителен специален случай.
/// Може би имате функция, която работи върху итератори, но трябва да обработите само една стойност.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// use std::iter;
///
/// // едно е най-самотното число
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // само едно, това е всичко, което получаваме
/// assert_eq!(None, one.next());
/// ```
///
/// Верига заедно с друг итератор.
/// Да кажем, че искаме да повторим всеки файл от директорията `.foo`, но също и конфигурационен файл,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // трябва да конвертираме от итератор на DirEntry-s в итератор на PathBufs, затова използваме map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // сега, нашият итератор само за нашия конфигурационен файл
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // свържете двата итератора заедно в един голям итератор
/// let files = dirs.chain(config);
///
/// // това ще ни даде всички файлове в .foo, както и .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Итератор, който дава елемент точно веднъж.
///
/// Този `struct` е създаден от функцията [`once()`].Вижте документацията му за повече.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}