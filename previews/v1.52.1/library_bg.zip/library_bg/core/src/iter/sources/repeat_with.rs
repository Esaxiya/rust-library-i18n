use crate::iter::{FusedIterator, TrustedLen};

/// Създава нов итератор, който повтаря безкрайно елементи от тип `A` чрез прилагане на предвиденото затваряне, повторителя, `F: FnMut() -> A`.
///
/// Функцията `repeat_with()` извиква повторителя отново и отново.
///
/// Безкрайните итератори като `repeat_with()` често се използват с адаптери като [`Iterator::take()`], за да ги направят крайни.
///
/// Ако типът елемент на итератора, от който се нуждаете, изпълнява [`Clone`] и е добре да запазите изходния елемент в паметта, вместо това трябва да използвате функцията [`repeat()`].
///
///
/// Итератор, произведен от `repeat_with()`, не е [`DoubleEndedIterator`].
/// Ако имате нужда от `repeat_with()`, за да върнете [`DoubleEndedIterator`], моля, отворете проблем с GitHub, обясняващ вашия случай на използване.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// use std::iter;
///
/// // нека приемем, че имаме някаква стойност от тип, който не е `Clone` или който все още не иска да има в паметта, защото е скъп:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // определена стойност завинаги:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Използване на мутация и завършване:
///
/// ```rust
/// use std::iter;
///
/// // От нула до трета степен на две:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... и сега приключихме
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Итератор, който повтаря безкрайно елементи от тип `A` чрез прилагане на предоставеното затваряне `F: FnMut() -> A`.
///
///
/// Този `struct` е създаден от функцията [`repeat_with()`].
/// Вижте документацията му за повече.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}