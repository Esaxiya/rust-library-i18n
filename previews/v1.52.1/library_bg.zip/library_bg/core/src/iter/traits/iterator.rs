// ignore-tidy-filelength Този файл се състои почти изключително от дефиницията на `Iterator`.
// Не можем да го разделим на множество файлове.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Интерфейс за работа с итератори.
///
/// Това е основният итератор Portrait.
/// За повече информация относно концепцията за итератори като цяло, моля, вижте [module-level documentation].
/// По-специално, може да искате да знаете как да [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Типът на итерираните елементи.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Напредва итератора и връща следващата стойност.
    ///
    /// Връща [`None`], когато итерацията приключи.
    /// Отделните внедрения на итератори могат да решат да възобновят итерацията и така извикването на `next()` отново може или не може да започне да връща [`Some(Item)`] отново в някакъв момент.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Обаждането до next() връща следващата стойност ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... и след това None, след като свърши.
    /// assert_eq!(None, iter.next());
    ///
    /// // Повече обаждания могат или не могат да върнат `None`.Тук те винаги ще го направят.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Връща границите на оставащата дължина на итератора.
    ///
    /// По-конкретно, `size_hint()` връща кортеж, където първият елемент е долната граница, а вторият елемент е горната граница.
    ///
    /// Втората половина на върната, която се връща, е [`Option`]`<`[`usize`] `>`.
    /// [`None`] тук означава, че или не е известна горна граница, или горната граница е по-голяма от [`usize`].
    ///
    /// # Бележки за изпълнение
    ///
    /// Не се налага прилагането на итератор да дава декларирания брой елементи.Бъги итератор може да даде по-малко от долната граница или повече от горната граница на елементите.
    ///
    /// `size_hint()` е предназначен предимно да се използва за оптимизации като резервиране на пространство за елементите на итератора, но не трябва да се вярва, напр. да пропусне проверките за граници в небезопасен код.
    /// Неправилното внедряване на `size_hint()` не трябва да води до нарушения на безопасността на паметта.
    ///
    /// Въпреки това, изпълнението трябва да осигури правилна оценка, защото в противен случай би било нарушение на протокола на Portrait.
    ///
    /// Реализацията по подразбиране връща `(0,` [`None`]`), което е правилно за всеки итератор.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// По-сложен пример:
    ///
    /// ```
    /// // Четните числа от нула до десет.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Може да повторим от нула до десет пъти.
    /// // Знанието, че това са точно пет, не би било възможно без изпълнение на filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Нека добавим още пет числа с chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // сега и двете граници се увеличават с пет
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Връща се `None` за горна граница:
    ///
    /// ```
    /// // безкраен итератор няма горна граница и максимално възможната долна граница
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Консумира итератора, като брои броя на итерациите и го връща.
    ///
    /// Този метод ще извиква [`next`] многократно, докато не се срещне [`None`], връщайки броя пъти, когато е видял [`Some`].
    /// Имайте предвид, че [`next`] трябва да бъде извикан поне веднъж, дори ако итераторът няма никакви елементи.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Поведение на преливане
    ///
    /// Методът не предпазва от препълване, така че броенето на елементи на итератор с повече от [`usize::MAX`] елементи или дава грешен резултат, или panics.
    ///
    /// Ако твърденията за отстраняване на грешки са активирани, panic е гарантиран.
    ///
    /// # Panics
    ///
    /// Тази функция може да panic, ако итераторът има повече от [`usize::MAX`] елементи.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Консумира итератора, връщайки последния елемент.
    ///
    /// Този метод ще оценява итератора, докато не върне [`None`].
    /// Докато го прави, той проследява текущия елемент.
    /// След връщането на [`None`], `last()` ще върне последния видян елемент.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Напредва итератора чрез `n` елементи.
    ///
    /// Този метод с нетърпение ще пропусне `n` елементи, като извика [`next`] до `n` пъти, докато се срещне [`None`].
    ///
    /// `advance_by(n)` ще върне [`Ok(())`][Ok], ако итераторът успешно премине по `n` елементи, или [`Err(k)`][Err], ако се срещне [`None`], където `k` е броят на елементите, с които итераторът е усъвършенстван преди да изтече елементите (т.е.
    /// дължината на итератора).
    /// Имайте предвид, че `k` винаги е по-малко от `n`.
    ///
    /// Извикването на `advance_by(0)` не консумира никакви елементи и винаги връща [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // само `&4` е пропуснат
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Връща n-ия елемент на итератора.
    ///
    /// Както повечето операции по индексиране, броят започва от нула, така че `nth(0)` връща първата стойност, `nth(1)` втората и т.н.
    ///
    /// Имайте предвид, че всички предходни елементи, както и върнатият елемент, ще бъдат консумирани от итератора.
    /// Това означава, че предходните елементи ще бъдат отхвърлени, както и че извикването на `nth(0)` няколко пъти в един и същ итератор ще върне различни елементи.
    ///
    ///
    /// `nth()` ще върне [`None`], ако `n` е по-голяма или равна на дължината на итератора.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Извикването на `nth()` няколко пъти не пренавива итератора:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Връща се `None`, ако има по-малко от `n + 1` елементи:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Създава итератор, започвайки от една и съща точка, но стъпки от дадената сума при всяка итерация.
    ///
    /// Забележка 1: Първият елемент на итератора винаги ще бъде върнат, независимо от дадената стъпка.
    ///
    /// Забележка 2: Времето, в което се изтеглят игнорирани елементи, не е фиксирано.
    /// `StepBy` се държи като последователността `next(), nth(step-1), nth(step-1),…`, но също така е свободен да се държи като последователността
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Който начин се използва може да се промени за някои итератори от съображения за производителност.
    /// Вторият начин ще подобри итератора по-рано и може да консумира повече елементи.
    ///
    /// `advance_n_and_return_first` е еквивалент на:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Методът ще panic, ако дадената стъпка е `0`.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Взима два итератора и създава нов итератор и за двата последователно.
    ///
    /// `chain()` ще върне нов итератор, който първо ще итерира над стойности от първия итератор и след това над стойности от втория итератор.
    ///
    /// С други думи, той свързва два итератора заедно във верига.🔗
    ///
    /// [`once`] обикновено се използва за адаптиране на единична стойност във верига от други видове итерации.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Тъй като аргументът за `chain()` използва [`IntoIterator`], можем да предадем всичко, което може да бъде преобразувано в [`Iterator`], а не само в самия [`Iterator`].
    /// Например, срезовете (`&[T]`) изпълняват [`IntoIterator`] и така могат да бъдат предадени директно на `chain()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ако работите с Windows API, може да пожелаете да конвертирате [`OsStr`] в `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Zips up' два итератора в един итератор от двойки.
    ///
    /// `zip()` връща нов итератор, който ще се повтори над два други итератора, връщайки кортеж, където първият елемент идва от първия итератор, а вторият елемент идва от втория итератор.
    ///
    ///
    /// С други думи, той компресира два итератора заедно, в един.
    ///
    /// Ако някой от итераторите върне [`None`], [`next`] от компресирания итератор ще върне [`None`].
    /// Ако първият итератор върне [`None`], `zip` ще късо съединение и `next` няма да бъде извикан на втория итератор.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Тъй като аргументът за `zip()` използва [`IntoIterator`], можем да предадем всичко, което може да бъде преобразувано в [`Iterator`], а не само в самия [`Iterator`].
    /// Например, срезовете (`&[T]`) изпълняват [`IntoIterator`] и така могат да бъдат предадени директно на `zip()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` често се използва за цип на безкраен итератор до краен.
    /// Това работи, защото крайният итератор в крайна сметка ще върне [`None`], завършвайки ципа.Ципирането с `(0..)` може много да прилича на [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Създава нов итератор, който поставя копие на `separator` между съседни елементи на оригиналния итератор.
    ///
    /// В случай, че `separator` не прилага [`Clone`] или трябва да се изчислява всеки път, използвайте [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Първият елемент от `a`.
    /// assert_eq!(a.next(), Some(&100)); // Сепараторът.
    /// assert_eq!(a.next(), Some(&1));   // Следващият елемент от `a`.
    /// assert_eq!(a.next(), Some(&100)); // Сепараторът.
    /// assert_eq!(a.next(), Some(&2));   // Последният елемент от `a`.
    /// assert_eq!(a.next(), None);       // Итераторът е завършен.
    /// ```
    ///
    /// `intersperse` може да бъде много полезно да се присъедините към елементи на итератор, използвайки общ елемент:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Създава нов итератор, който поставя елемент, генериран от `separator`, между съседни елементи на оригиналния итератор.
    ///
    /// Затварянето ще се извиква точно веднъж всеки път, когато елемент се постави между два съседни елемента от основния итератор;
    /// по-конкретно, затварянето не се извиква, ако основният итератор дава по-малко от два елемента и след даването на последния елемент.
    ///
    ///
    /// Ако елементът на итератора изпълнява [`Clone`], може да е по-лесно да използвате [`intersperse`].
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Първият елемент от `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Сепараторът.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Следващият елемент от `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Сепараторът.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Последният елемент от `v`.
    /// assert_eq!(it.next(), None);               // Итераторът е завършен.
    /// ```
    ///
    /// `intersperse_with` може да се използва в ситуации, когато трябва да се изчисли разделителят:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Затварянето изменя взаимно контекста си, за да генерира елемент.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Взима затваряне и създава итератор, който извиква това затваряне на всеки елемент.
    ///
    /// `map()` преобразува един итератор в друг, чрез неговия аргумент:
    /// нещо, което прилага [`FnMut`].Той създава нов итератор, който извиква това затваряне на всеки елемент от оригиналния итератор.
    ///
    /// Ако се справяте добре с типовете, можете да мислите за `map()` така:
    /// Ако имате итератор, който ви дава елементи от някакъв тип `A` и искате итератор от някакъв друг тип `B`, можете да използвате `map()`, преминавайки през затваряне, което взема `A` и връща `B`.
    ///
    ///
    /// `map()` е концептуално подобен на контур [`for`].Тъй като обаче `map()` е мързелив, най-добре се използва, когато вече работите с други итератори.
    /// Ако правите някакъв цикъл за страничен ефект, счита се за по-идиоматично да използвате [`for`], отколкото `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ако правите някакъв страничен ефект, предпочитайте [`for`] пред `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // не прави това:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // дори няма да се изпълни, тъй като е мързелив.Rust ще ви предупреди за това.
    ///
    /// // Вместо това използвайте за:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Призовава затваряне на всеки елемент на итератор.
    ///
    /// Това е еквивалентно на използването на цикъл [`for`] на итератора, въпреки че `break` и `continue` не са възможни от затваряне.
    /// По принцип е по-идиоматично да се използва цикъл `for`, но `for_each` може да бъде по-четлив при обработка на елементи в края на по-дълги вериги итератори.
    ///
    /// В някои случаи `for_each` може да бъде и по-бърз от цикъл, защото ще използва вътрешна итерация на адаптери като `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// За такъв малък пример, цикъл `for` може да е по-чист, но `for_each` може да е за предпочитане да се запази функционален стил с по-дълги итератори:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Създава итератор, който използва затваряне, за да определи дали даден елемент трябва да бъде получен.
    ///
    /// При даден елемент затварянето трябва да върне `true` или `false`.Върнатият итератор ще даде само елементите, за които затварянето връща true.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Тъй като затварянето, предадено на `filter()`, взема препратка и много итератори се прелистват над препратки, това води до евентуално объркваща ситуация, при която типът на затварянето е двойна препратка:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // трябват две * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Обикновено вместо това се използва деструктуриране на аргумента, за да се премахне един:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // и&и *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// или и двете:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // два &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// от тези слоеве.
    ///
    /// Имайте предвид, че `iter.filter(f).next()` е еквивалентен на `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Създава итератор, който едновременно филтрира и картографира.
    ///
    /// Върнатият итератор дава само стойностите, за които предоставеното затваряне връща `Some(value)`.
    ///
    /// `filter_map` може да се използва, за да направи веригите от [`filter`] и [`map`] по-кратки.
    /// Примерът по-долу показва как `map().filter().map()` може да бъде съкратен до едно обаждане до `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ето същия пример, но с [`filter`] и [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Създава итератор, който дава текущия брой итерации, както и следващата стойност.
    ///
    /// Върнатият итератор дава двойки `(i, val)`, където `i` е текущият индекс на итерация, а `val` е стойността, върната от итератора.
    ///
    ///
    /// `enumerate()` запазва броя си като [`usize`].
    /// Ако искате да броите с различно по големина цяло число, функцията [`zip`] предоставя подобна функционалност.
    ///
    /// # Поведение на преливане
    ///
    /// Методът не предпазва от препълване, така че изброяването на повече от [`usize::MAX`] елементи или дава грешен резултат, или panics.
    /// Ако твърденията за отстраняване на грешки са активирани, panic е гарантиран.
    ///
    /// # Panics
    ///
    /// Върнатият итератор може да panic, ако индексът, който трябва да бъде върнат, препълва [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Създава итератор, който може да използва [`peek`], за да гледа следващия елемент на итератора, без да го консумира.
    ///
    /// Добавя метод [`peek`] към итератор.Вижте документацията му за повече информация.
    ///
    /// Имайте предвид, че основният итератор все още е напреднал, когато [`peek`] е извикан за първи път: За да се извлече следващият елемент, [`next`] се извиква на базовия итератор, следователно всякакви странични ефекти (т.е.
    ///
    /// ще се случи нещо различно от извличането на следващата стойност) на метода [`next`].
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() ни позволява да видим в future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // можем да peek() няколко пъти, итераторът няма да напредне
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // след като итераторът приключи, peek() също
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Създава итератор, който [`пропуска '] елементи на базата на предикат.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` приема закриване като аргумент.Той ще извика това затваряне на всеки елемент от итератора и ще игнорира елементи, докато върне `false`.
    ///
    /// След връщането на `false`, заданието `skip_while()`'s приключва, а останалите елементи се получават.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Тъй като затварянето, предадено на `skip_while()`, взема препратка и много итератори прелитат над препратки, това води до евентуално объркваща ситуация, при която типът на аргумента за затваряне е двойна препратка:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // трябват две * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Спиране след първоначален `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // макар че това би било фалшиво, тъй като вече имаме фалшиво, skip_while() вече не се използва
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Създава итератор, който дава елементи въз основа на предикат.
    ///
    /// `take_while()` приема закриване като аргумент.Той ще извика това затваряне на всеки елемент от итератора и ще даде елементи, докато връща `true`.
    ///
    /// След връщането на `false`, заданието `take_while()`'s приключва, а останалите елементи се игнорират.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Тъй като затварянето, предадено на `take_while()`, взема препратка и много итератори се прелистват над препратки, това води до евентуално объркваща ситуация, при която типът на затварянето е двойна препратка:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // трябват две * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Спиране след първоначален `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Имаме повече елементи, които са по-малко от нула, но тъй като вече имаме false, take_while() вече не се използва
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Тъй като `take_while()` трябва да погледне стойността, за да види дали трябва да бъде включена или не, консумиращите итератори ще видят, че тя е премахната:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` вече не е там, защото е бил консумиран, за да се види дали итерацията трябва да спре, но не е бил поставен обратно в итератора.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Създава итератор, който и двете дава елементи въз основа на предикат и карти.
    ///
    /// `map_while()` приема закриване като аргумент.
    /// Той ще извика това затваряне на всеки елемент от итератора и ще даде елементи, докато връща [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ето същия пример, но с [`take_while`] и [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Спиране след първоначален [`None`]:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Имаме повече елементи, които биха могли да се поберат в u32 (4, 5), но `map_while` върна `None` за `-3` (тъй като `predicate` върна `None`) и `collect` спира при първия срещнат `None`.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Тъй като `map_while()` трябва да погледне стойността, за да види дали трябва да бъде включена или не, консумиращите итератори ще видят, че тя е премахната:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` вече не е там, защото е бил консумиран, за да се види дали итерацията трябва да спре, но не е бил поставен обратно в итератора.
    ///
    /// Имайте предвид, че за разлика от [`take_while`] този итератор **не е** разтопен.
    /// Също така не е посочено какво връща този итератор след връщането на първия [`None`].
    /// Ако имате нужда от разтопен итератор, използвайте [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Създава итератор, който пропуска първите `n` елементи.
    ///
    /// След като бъдат консумирани, останалите елементи се получават.
    /// Вместо да замените директно този метод, вместо да замените метода `nth`.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Създава итератор, който дава първите си `n` елементи.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` често се използва с безкраен итератор, за да го направи краен:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ако са налични по-малко от `n` елементи, `take` ще се ограничи до размера на основния итератор:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Итераторен адаптер, подобен на [`fold`], който поддържа вътрешно състояние и създава нов итератор.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` взема два аргумента: начална стойност, която засява вътрешното състояние, и затваряне с два аргумента, като първият е изменяема препратка към вътрешното състояние, а вторият е елемент на итератор.
    ///
    /// Затварянето може да присвои на вътрешното състояние да споделя състояние между итерации.
    ///
    /// При итерация затварянето ще се приложи към всеки елемент от итератора и връщаната стойност от затварянето, [`Option`], се дава от итератора.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // всяка итерация ще умножим състоянието по елемента
    ///     *state = *state * x;
    ///
    ///     // тогава ще дадем отрицанието на държавата
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Създава итератор, който работи като map, но изравнява вложената структура.
    ///
    /// Адаптерът [`map`] е много полезен, но само когато аргументът за затваряне създава стойности.
    /// Ако вместо това създаде итератор, има допълнителен слой на непрякост.
    /// `flat_map()` ще премахне този допълнителен слой сам.
    ///
    /// Можете да мислите за `flat_map(f)` като семантичен еквивалент на ['map`] ping и след това [`flatten`] ing както в `map(f).flatten()`.
    ///
    /// Друг начин на мислене за `flat_map()`: затварянето на [`map`] връща по един елемент за всеки елемент, а затварянето `flat_map()`'s връща итератор за всеки елемент.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() връща итератор
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Създава итератор, който изравнява вложената структура.
    ///
    /// Това е полезно, когато имате итератор на итератори или итератор на неща, които могат да бъдат превърнати в итератори и искате да премахнете едно ниво на непрякост.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Картографиране и след това изравняване:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() връща итератор
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Можете също да пренапишете това по отношение на [`flat_map()`], което е за предпочитане в този случай, тъй като предава намерението по-ясно:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() връща итератор
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Изравняването премахва само едно ниво на гнездене наведнъж:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Тук виждаме, че `flatten()` не изпълнява изравняване на "deep".
    /// Вместо това се премахва само едно ниво на гнездене.Тоест, ако `flatten()` имате триизмерен масив, резултатът ще бъде двуизмерен, а не едномерен.
    /// За да получите едномерна структура, трябва отново да `flatten()`.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Създава итератор, който завършва след първия [`None`].
    ///
    /// След като итераторът върне [`None`], повикванията future могат или не могат да дадат [`Some(T)`] отново.
    /// `fuse()` адаптира итератор, като гарантира, че след даване на [`None`], той винаги ще връща [`None`] завинаги.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// // итератор, който се редува между Някои и Никой
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // ако е четно, Some(i32), друго Няма
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // можем да видим нашия итератор да върви напред-назад
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // обаче, след като го разтопим ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // винаги ще връща `None` след първия път.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Прави нещо с всеки елемент от итератор, предавайки стойността.
    ///
    /// Когато използвате итератори, често ще свързвате няколко от тях заедно.
    /// Докато работите по такъв код, може да искате да проверите какво се случва в различни части на конвейера.За да направите това, поставете повикване към `inspect()`.
    ///
    /// По-често е `inspect()` да се използва като инструмент за отстраняване на грешки, отколкото да съществува във вашия окончателен код, но приложенията могат да го намерят за полезен в определени ситуации, когато трябва да се регистрират грешки, преди да бъдат изхвърлени.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // тази итераторна последователност е сложна.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // нека добавим няколко повиквания inspect(), за да разследваме какво се случва
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Това ще отпечата:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Грешки при регистриране преди да ги изхвърлите:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Това ще отпечата:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Взема назаем итератор, вместо да го консумира.
    ///
    /// Това е полезно, за да се позволи прилагането на адаптери за итератори, като същевременно се запазва собствеността върху оригиналния итератор.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // ако се опитаме да използваме iter отново, няма да работи.
    /// // Следващият ред дава "грешка: използване на преместена стойност: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // нека опитаме това отново
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // вместо това добавяме .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // сега това е добре:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Преобразува итератор в колекция.
    ///
    /// `collect()` може да вземе всичко, което може да се повтори, и да го превърне в подходяща колекция.
    /// Това е един от най-мощните методи в стандартната библиотека, използван в различни контексти.
    ///
    /// Най-основният модел, при който се използва `collect()`, е превръщането на една колекция в друга.
    /// Вземете колекция, обадете се на [`iter`], направете куп трансформации и след това `collect()` в края.
    ///
    /// `collect()` може също така да създава екземпляри от типове, които не са типични колекции.
    /// Например, [`String`] може да се изгради от [`char`] s, а итератор на [`Result<T, E>`][`Result`] елементи може да се събере в `Result<Collection<T>, E>`.
    ///
    /// Вижте примерите по-долу за повече.
    ///
    /// Тъй като `collect()` е толкова общ, той може да причини проблеми с извода за типа.
    /// Като такъв, `collect()` е един от малкото пъти, когато ще видите синтаксиса, известен като галено като 'turbofish': `::<>`.
    /// Това помага на алгоритъма за извод да разбере конкретно в коя колекция се опитвате да съберете.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Имайте предвид, че се нуждаехме от `: Vec<i32>` от лявата страна.Това е така, защото вместо това бихме могли да съберем например [`VecDeque<T>`]:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Използване на 'turbofish' вместо анотиране на `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Тъй като `collect()` се интересува само от това, което събирате, все още можете да използвате частичен тип подсказка, `_`, с turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Използване на `collect()` за създаване на [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Ако имате списък с [`Резултат<T, E>`][`Резултат`] s, можете да използвате `collect()`, за да видите дали някой от тях е неуспешен:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // ни дава първата грешка
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // ни дава списъка с отговори
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Консумира итератор, създавайки две колекции от него.
    ///
    /// Предикатът, предаден на `partition()`, може да върне `true` или `false`.
    /// `partition()` връща чифт, всички елементи, за които е върнал `true`, и всички елементи, за които е върнал `false`.
    ///
    ///
    /// Вижте също [`is_partitioned()`] и [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Пренарежда елементите на този итератор *на място* според дадения предикат, така че всички, които връщат `true`, предшестват всички, които връщат `false`.
    ///
    /// Връща броя на намерените елементи `true`.
    ///
    /// Относителният ред на разделени елементи не се поддържа.
    ///
    /// Вижте също [`is_partitioned()`] и [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Разделяне на място между нива и коефициенти
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: трябва ли да се притесняваме, че броят препълва?Единственият начин да имате повече от
        // `usize::MAX` променливите препратки са със ZST, които не са полезни за разделяне ...

        // Тези функции за затваряне "factory" съществуват, за да се избегне генеричност в `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Намирайте многократно първия `false` и го сменяйте с последния `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Проверява дали елементите на този итератор са разделени според дадения предикат, така че всички, които връщат `true`, предшестват всички, които връщат `false`.
    ///
    ///
    /// Вижте също [`partition()`] и [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Или всички елементи тестват `true`, или първата клауза спира на `false` и ние проверяваме дали няма повече `true` елементи след това.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Метод на итератор, който прилага функция, стига да се върне успешно, създавайки единична, крайна стойност.
    ///
    /// `try_fold()` взема два аргумента: начална стойност и затваряне с два аргумента: 'accumulator' и елемент.
    /// Затварянето или се връща успешно, със стойността, която акумулаторът трябва да има за следващата итерация, или връща неуспех, със стойност на грешка, която се предава обратно на повикващия веднага (short-circuiting).
    ///
    ///
    /// Първоначалната стойност е стойността, която акумулаторът ще има при първото повикване.Ако прилагането на затварянето е било успешно за всеки елемент на итератора, `try_fold()` връща крайния акумулатор като успех.
    ///
    /// Сгъването е полезно винаги, когато имате колекция от нещо и искате да създадете единична стойност от нея.
    ///
    /// # Забележка към изпълнителите
    ///
    /// Няколко от другите методи (forward) имат внедрения по подразбиране по отношение на този, така че опитайте да го приложите изрично, ако може да направи нещо по-добро от изпълнението на контура `for` по подразбиране.
    ///
    /// По-специално, опитайте се да имате това повикване `try_fold()` във вътрешните части, от които е съставен този итератор.
    /// Ако са необходими множество повиквания, операторът `?` може да е удобен за веригиране на стойността на акумулатора, но внимавайте за всички инварианти, които трябва да бъдат поддържани преди тези ранни връщания.
    /// Това е метод `&mut self`, така че итерацията трябва да бъде възобновена, след като се появи грешка тук.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // проверената сума на всички елементи на масива
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Тази сума прелива при добавяне на елемента 100
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Тъй като е късо съединение, останалите елементи все още са достъпни чрез итератора.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Метод на итератор, който прилага безпогрешна функция към всеки елемент в итератора, спирайки при първата грешка и връщайки тази грешка.
    ///
    ///
    /// Това също може да се разглежда като непогрешима форма на [`for_each()`] или като версия на [`try_fold()`] без гражданство.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Той е на късо съединение, така че останалите елементи все още са в итератора:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Сгъва всеки елемент в акумулатор чрез прилагане на операция, връщайки крайния резултат.
    ///
    /// `fold()` взема два аргумента: начална стойност и затваряне с два аргумента: 'accumulator' и елемент.
    /// Затварянето връща стойността, която акумулаторът трябва да има за следващата итерация.
    ///
    /// Първоначалната стойност е стойността, която акумулаторът ще има при първото повикване.
    ///
    /// След прилагане на това затваряне към всеки елемент на итератора, `fold()` връща акумулатора.
    ///
    /// Тази операция понякога се нарича 'reduce' или 'inject'.
    ///
    /// Сгъването е полезно винаги, когато имате колекция от нещо и искате да създадете единична стойност от нея.
    ///
    /// Note: `fold()` и подобни методи, които пресичат целия итератор, може да не се прекратяват за безкрайни итератори, дори на traits, за които резултатът може да бъде определен за ограничено време.
    ///
    /// Note: [`reduce()`] може да се използва, за да се използва първият елемент като начална стойност, ако типът на акумулатора и типът на артикулите са еднакви.
    ///
    /// # Забележка към изпълнителите
    ///
    /// Няколко от другите методи (forward) имат внедрения по подразбиране по отношение на този, така че опитайте да го приложите изрично, ако може да направи нещо по-добро от изпълнението на контура `for` по подразбиране.
    ///
    ///
    /// По-специално, опитайте се да имате това повикване `fold()` във вътрешните части, от които е съставен този итератор.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // сумата от всички елементи на масива
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Нека преминем през всяка стъпка от итерацията тук:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// И така, нашият краен резултат, `6`.
    ///
    /// Обичайно е хората, които не са използвали много итератори, да използват цикъл `for` със списък от неща, за да изградят резултат.Те могат да бъдат превърнати в `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // за цикъл:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // те са едни и същи
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Намалява елементите до един, като многократно прилага редуцираща операция.
    ///
    /// Ако итераторът е празен, връща [`None`];в противен случай връща резултата от намалението.
    ///
    /// За итератори с поне един елемент това е същото като [`fold()`] с първия елемент на итератора като начална стойност, сгъвайки всеки следващ елемент в него.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Намерете максималната стойност:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Тества дали всеки елемент от итератора съвпада с предикат.
    ///
    /// `all()` взема затваряне, което връща `true` или `false`.Той прилага това затваряне към всеки елемент на итератора и ако всички те връщат `true`, тогава и `all()`.
    /// Ако някой от тях върне `false`, той връща `false`.
    ///
    /// `all()` е късо съединение;с други думи, ще спре да обработва веднага щом намери `false`, като се има предвид, че независимо какво друго се случва, резултатът също ще бъде `false`.
    ///
    ///
    /// Празен итератор връща `true`.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Спиране на първия `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // все още можем да използваме `iter`, тъй като има повече елементи.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Тества дали някой елемент от итератора съвпада с предикат.
    ///
    /// `any()` взема затваряне, което връща `true` или `false`.Той прилага това затваряне към всеки елемент от итератора и ако някой от тях върне `true`, тогава го прави и `any()`.
    /// Ако всички те върнат `false`, той връща `false`.
    ///
    /// `any()` е късо съединение;с други думи, ще спре да обработва веднага щом намери `true`, като се има предвид, че независимо какво друго се случва, резултатът също ще бъде `true`.
    ///
    ///
    /// Празен итератор връща `false`.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Спиране на първия `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // все още можем да използваме `iter`, тъй като има повече елементи.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Търси елемент от итератор, който удовлетворява предикат.
    ///
    /// `find()` взема затваряне, което връща `true` или `false`.
    /// Той прилага това затваряне към всеки елемент на итератора и ако някой от тях върне `true`, тогава `find()` връща [`Some(element)`].
    /// Ако всички те върнат `false`, той връща [`None`].
    ///
    /// `find()` е късо съединение;с други думи, ще спре да обработва веднага щом затварянето върне `true`.
    ///
    /// Тъй като `find()` взема препратка и много итератори прелистват препратки, това води до евентуално объркваща ситуация, когато аргументът е двойна препратка.
    ///
    /// Можете да видите този ефект в примерите по-долу, с `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Спиране на първия `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // все още можем да използваме `iter`, тъй като има повече елементи.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Имайте предвид, че `iter.find(f)` е еквивалентен на `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Прилага функция към елементите на итератор и връща първия резултат, който не е никакъв.
    ///
    ///
    /// `iter.find_map(f)` е еквивалентно на `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Прилага функция към елементите на итератора и връща първия истински резултат или първата грешка.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Търси елемент в итератор, връщайки индекса му.
    ///
    /// `position()` взема затваряне, което връща `true` или `false`.
    /// Той прилага това затваряне към всеки елемент на итератора и ако един от тях върне `true`, тогава `position()` връща [`Some(index)`].
    /// Ако всички те върнат `false`, той връща [`None`].
    ///
    /// `position()` е късо съединение;с други думи, той ще спре да обработва веднага щом намери `true`.
    ///
    /// # Поведение на преливане
    ///
    /// Методът не предпазва от препълване, така че ако има повече от [`usize::MAX`] несъвпадащи елементи, той или дава грешен резултат, или panics.
    ///
    /// Ако твърденията за отстраняване на грешки са активирани, panic е гарантиран.
    ///
    /// # Panics
    ///
    /// Тази функция може да panic, ако итераторът има повече от `usize::MAX` несъвпадащи елементи.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Спиране на първия `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // все още можем да използваме `iter`, тъй като има повече елементи.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Върнатият индекс зависи от състоянието на итератора
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Търси елемент в итератор отдясно, връщайки индекса му.
    ///
    /// `rposition()` взема затваряне, което връща `true` или `false`.
    /// Той прилага това затваряне към всеки елемент на итератора, започвайки от края и ако един от тях връща `true`, тогава `rposition()` връща [`Some(index)`].
    ///
    /// Ако всички те върнат `false`, той връща [`None`].
    ///
    /// `rposition()` е късо съединение;с други думи, той ще спре да обработва веднага щом намери `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Спиране на първия `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // все още можем да използваме `iter`, тъй като има повече елементи.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Тук няма нужда от проверка за препълване, защото `ExactSizeIterator` предполага, че броят на елементите се побира в `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Връща максималния елемент на итератор.
    ///
    /// Ако няколко елемента са еднакво максимални, се връща последният елемент.
    /// Ако итераторът е празен, [`None`] се връща.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Връща минималния елемент на итератор.
    ///
    /// Ако няколко елемента са еднакво минимални, първият елемент се връща.
    /// Ако итераторът е празен, [`None`] се връща.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Връща елемента, който дава максималната стойност от посочената функция.
    ///
    ///
    /// Ако няколко елемента са еднакво максимални, се връща последният елемент.
    /// Ако итераторът е празен, [`None`] се връща.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Връща елемента, който дава максималната стойност по отношение на посочената функция за сравнение.
    ///
    ///
    /// Ако няколко елемента са еднакво максимални, се връща последният елемент.
    /// Ако итераторът е празен, [`None`] се връща.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Връща елемента, който дава минималната стойност от посочената функция.
    ///
    ///
    /// Ако няколко елемента са еднакво минимални, първият елемент се връща.
    /// Ако итераторът е празен, [`None`] се връща.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Връща елемента, който дава минималната стойност по отношение на посочената функция за сравнение.
    ///
    ///
    /// Ако няколко елемента са еднакво минимални, първият елемент се връща.
    /// Ако итераторът е празен, [`None`] се връща.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Обръща посоката на итератора.
    ///
    /// Обикновено итераторите се повтарят отляво надясно.
    /// След използване на `rev()`, итератор вместо това ще повтори отдясно наляво.
    ///
    /// Това е възможно само ако итераторът има край, така че `rev()` работи само на [`DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Преобразува итератор на двойки в двойка контейнери.
    ///
    /// `unzip()` консумира цял итератор на двойки, като създава две колекции: една от левите елементи на двойките и една от десните елементи.
    ///
    ///
    /// Тази функция в известен смисъл е противоположна на [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Създава итератор, който копира всички негови елементи.
    ///
    /// Това е полезно, когато имате итератор над `&T`, но имате нужда от итератор над `T`.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // копираното е същото като .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Създава итератор, който [`clone`] е всичките му елементи.
    ///
    /// Това е полезно, когато имате итератор над `&T`, но имате нужда от итератор над `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // cloned е същото като .map(|&x| x), за цели числа
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Повтаря итератор безкрайно.
    ///
    /// Вместо да спре на [`None`], итераторът вместо това ще започне отново, от самото начало.След повторно повторение ще започне отново в началото.И отново.
    /// И отново.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Сумира елементите на итератор.
    ///
    /// Взема всеки елемент, добавя ги заедно и връща резултата.
    ///
    /// Празен итератор връща нулевата стойност на типа.
    ///
    /// # Panics
    ///
    /// Когато се извиква `sum()` и се връща примитивен цяло число, този метод ще panic, ако изчислението препълва и твърдения за отстраняване на грешки са активирани.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Взаимодейства с целия итератор, умножавайки всички елементи
    ///
    /// Празен итератор връща едната стойност на типа.
    ///
    /// # Panics
    ///
    /// При извикване на `product()` и се връща примитивен цяло число, методът ще panic, ако изчислението препълва и твърдения за отстраняване на грешки са активирани.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) сравнява елементите на този [`Iterator`] с тези на друг.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) сравнява елементите на този [`Iterator`] с тези на друг по отношение на посочената функция за сравнение.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) сравнява елементите на този [`Iterator`] с тези на друг.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) сравнява елементите на този [`Iterator`] с тези на друг по отношение на посочената функция за сравнение.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Определя дали елементите на този [`Iterator`] са равни на тези на друг.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Определя дали елементите на този [`Iterator`] са равни на тези на друг по отношение на посочената функция за равенство.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Определя дали елементите на този [`Iterator`] са неравни с тези на друг.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Определя дали елементите на този [`Iterator`] са с [lexicographically](Ord#lexicographical-comparison) по-малко от тези на друг.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Определя дали елементите на този [`Iterator`] са [lexicographically](Ord#lexicographical-comparison) по-малко или равни на тези на друг.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Определя дали елементите на този [`Iterator`] са [lexicographically](Ord#lexicographical-comparison) по-големи от тези на друг.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Определя дали елементите на този [`Iterator`] са [lexicographically](Ord#lexicographical-comparison) по-големи или равни на тези на друг.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Проверява дали елементите на този итератор са сортирани.
    ///
    /// Тоест, за всеки елемент `a` и следващия му елемент `b`, `a <= b` трябва да има.Ако итераторът даде точно нула или един елемент, се връща `true`.
    ///
    /// Обърнете внимание, че ако `Self::Item` е само `PartialOrd`, но не и `Ord`, горната дефиниция предполага, че тази функция връща `false`, ако всеки два последователни елемента не са сравними.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Проверява дали елементите на този итератор са сортирани с помощта на дадената функция за сравнение.
    ///
    /// Вместо да използва `PartialOrd::partial_cmp`, тази функция използва дадената функция `compare`, за да определи подреждането на два елемента.
    /// Отделно от това, той е еквивалентен на [`is_sorted`];вижте документацията му за повече информация.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Проверява дали елементите на този итератор са сортирани с помощта на дадената функция за извличане на ключ.
    ///
    /// Вместо да сравнява директно елементите на итератора, тази функция сравнява ключовете на елементите, както е определено от `f`.
    /// Отделно от това, той е еквивалентен на [`is_sorted`];вижте документацията му за повече информация.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Вижте [TrustedRandomAccess]
    // Необичайното име е да се избегнат сблъсъци на имена в разделителната способност на метода, вижте #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}