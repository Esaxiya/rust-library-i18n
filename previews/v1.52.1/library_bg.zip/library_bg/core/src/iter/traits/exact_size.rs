/// Итератор, който знае точната му дължина.
///
/// Много [`Итератор`] не знаят колко пъти ще повторят, но някои го правят.
/// Ако итераторът знае колко пъти може да повтори, предоставянето на достъп до тази информация може да бъде полезно.
/// Например, ако искате да повторите назад, добро начало е да знаете къде е краят.
///
/// Когато внедрявате `ExactSizeIterator`, трябва да внедрите и [`Iterator`].
/// При това изпълнението на [`Iterator::size_hint`]*трябва* да върне точния размер на итератора.
///
/// Методът [`len`] има изпълнение по подразбиране, така че обикновено не трябва да го прилагате.
/// Възможно е обаче да можете да предоставите по-ефективна реализация от стандартната, така че да я замените в този случай има смисъл.
///
///
/// Имайте предвид, че този Portrait е безопасен Portrait и като такъв *не* и *не може* да гарантира, че върнатата дължина е правилна.
/// Това означава, че кодът `unsafe`**не трябва** да разчита на коректността на [`Iterator::size_hint`].
/// Нестабилната и несигурна [`TrustedLen`](super::marker::TrustedLen) Portrait дава тази допълнителна гаранция.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// // краен диапазон знае точно колко пъти ще се повтори
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// В [module-level docs] внедрихме [`Iterator`], `Counter`.
/// Нека внедрим `ExactSizeIterator` и за него:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Можем лесно да изчислим оставащия брой итерации.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // И сега можем да го използваме!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Връща точната дължина на итератора.
    ///
    /// Внедряването гарантира, че итераторът ще върне точно `len()` повече пъти по стойност [`Some(T)`], преди да върне [`None`].
    ///
    /// Този метод има изпълнение по подразбиране, така че обикновено не трябва да го прилагате директно.
    /// Ако обаче можете да осигурите по-ефективно изпълнение, можете да го направите.
    /// Вижте документите за [trait-level] за пример.
    ///
    /// Тази функция има същите гаранции за безопасност като функцията [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// // краен диапазон знае точно колко пъти ще се повтори
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Това твърдение е твърде защитно, но проверява инварианта
        // гарантирано от Portrait.
        // Ако този Portrait беше rust-вътрешен, бихме могли да използваме debug_assert !;assert_eq!ще провери и всички потребителски реализации на Rust.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Връща `true`, ако итераторът е празен.
    ///
    /// Този метод има изпълнение по подразбиране, използващо [`ExactSizeIterator::len()`], така че не е нужно да го прилагате сами.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}