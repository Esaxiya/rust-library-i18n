use crate::ops::{ControlFlow, Try};

/// Итератор, способен да дава елементи от двата края.
///
/// Нещо, което реализира `DoubleEndedIterator`, има една допълнителна способност спрямо нещо, което реализира [`Iterator`]: способността да се вземат и "Предмети" отзад, както и отпред.
///
///
/// Важно е да се отбележи, че както напред, така и напред работят върху един и същи диапазон и не се пресичат: итерацията приключва, когато се срещнат в средата.
///
/// По подобен начин на протокола [`Iterator`], след като `DoubleEndedIterator` върне [`None`] от [`next_back()`], извикването му отново може или не може да върне [`Some`] отново.
/// [`next()`] и [`next_back()`] са взаимозаменяеми за тази цел.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Премахва и връща елемент от края на итератора.
    ///
    /// Връща `None`, когато няма повече елементи.
    ///
    /// Документите [trait-level] съдържат повече подробности.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Елементите, получени от методите на "DoubleEndedIterator", могат да се различават от елементите, получени от методите на ["Iterator`]:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Авансира итератора отзад с елементи `n`.
    ///
    /// `advance_back_by` е обратната версия на [`advance_by`].Този метод ще пропуска с нетърпение елементите на `n`, започвайки отзад, като извиква [`next_back`] до `n` пъти, докато се срещне [`None`].
    ///
    /// `advance_back_by(n)` ще върне [`Ok(())`], ако итераторът успешно премине по `n` елементи, или [`Err(k)`], ако се срещне [`None`], където `k` е броят на елементите, с които итераторът е усъвършенстван, преди да изтече елементите (т.е.
    /// дължината на итератора).
    /// Имайте предвид, че `k` винаги е по-малко от `n`.
    ///
    /// Извикването на `advance_back_by(0)` не консумира никакви елементи и винаги връща [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // само `&3` е пропуснат
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Връща `n`-ия елемент от края на итератора.
    ///
    /// Това по същество е обърната версия на [`Iterator::nth()`].
    /// Въпреки че, както повечето операции за индексиране, броят започва от нула, така че `nth_back(0)` връща първата стойност от края, `nth_back(1)` втората и т.н.
    ///
    ///
    /// Имайте предвид, че всички елементи между края и върнатия елемент ще бъдат консумирани, включително върнатия елемент.
    /// Това също означава, че извикването на `nth_back(0)` няколко пъти в един и същ итератор ще върне различни елементи.
    ///
    /// `nth_back()` ще върне [`None`], ако `n` е по-голяма или равна на дължината на итератора.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Извикването на `nth_back()` няколко пъти не пренавива итератора:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Връща се `None`, ако има по-малко от `n + 1` елементи:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Това е обратната версия на [`Iterator::try_fold()`]: отнема елементи, започващи от задната страна на итератора.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Тъй като е късо съединение, останалите елементи все още са достъпни чрез итератора.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Метод на итератор, който намалява елементите на итератора до една, крайна стойност, започвайки отзад.
    ///
    /// Това е обратната версия на [`Iterator::fold()`]: отнема елементи, започващи от задната страна на итератора.
    ///
    /// `rfold()` взема два аргумента: начална стойност и затваряне с два аргумента: 'accumulator' и елемент.
    /// Затварянето връща стойността, която акумулаторът трябва да има за следващата итерация.
    ///
    /// Първоначалната стойност е стойността, която акумулаторът ще има при първото повикване.
    ///
    /// След прилагане на това затваряне към всеки елемент на итератора, `rfold()` връща акумулатора.
    ///
    /// Тази операция понякога се нарича 'reduce' или 'inject'.
    ///
    /// Сгъването е полезно винаги, когато имате колекция от нещо и искате да създадете единична стойност от нея.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // сумата от всички елементи на a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Този пример изгражда низ, започвайки с начална стойност и продължавайки с всеки елемент отзад до предната част:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Търси елемент от итератор отзад, който удовлетворява предикат.
    ///
    /// `rfind()` взема затваряне, което връща `true` или `false`.
    /// Той прилага това затваряне към всеки елемент от итератора, започвайки от края и ако някой от тях върне `true`, тогава `rfind()` връща [`Some(element)`].
    /// Ако всички те върнат `false`, той връща [`None`].
    ///
    /// `rfind()` е късо съединение;с други думи, ще спре да обработва веднага щом затварянето върне `true`.
    ///
    /// Тъй като `rfind()` взема препратка и много итератори прелистват препратки, това води до евентуално объркваща ситуация, когато аргументът е двойна препратка.
    ///
    /// Можете да видите този ефект в примерите по-долу, с `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Спиране на първия `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // все още можем да използваме `iter`, тъй като има повече елементи.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}