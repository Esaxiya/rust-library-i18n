/// Преобразуване от [`Iterator`].
///
/// Чрез внедряване на `FromIterator` за тип, вие дефинирате как ще бъде създаден от итератор.
/// Това е често срещано за типове, които описват някаква колекция.
///
/// [`FromIterator::from_iter()`] рядко се извиква изрично и вместо това се използва чрез метода [`Iterator::collect()`].
///
/// Вижте документацията за [`Iterator::collect()`]'s за повече примери.
///
/// Вижте също: [`IntoIterator`].
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Използване на [`Iterator::collect()`] за имплицитно използване на `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Внедряване на `FromIterator` за вашия тип:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Примерна колекция, това е просто обвивка над Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Нека му дадем няколко метода, за да можем да го създадем и да добавим неща към него.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // и ще приложим FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Сега можем да направим нов итератор ...
/// let iter = (0..5).into_iter();
///
/// // ... и направете MyCollection от него
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // събирайте и творби!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Създава стойност от итератор.
    ///
    /// Вижте [module-level documentation] за повече.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Преобразуване в [`Iterator`].
///
/// Чрез внедряване на `IntoIterator` за тип, вие дефинирате как той ще бъде преобразуван в итератор.
/// Това е често срещано за типове, които описват някаква колекция.
///
/// Едно предимство от внедряването на `IntoIterator` е, че вашият тип ще бъде [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Вижте също: [`FromIterator`].
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Внедряване на `IntoIterator` за вашия тип:
///
/// ```
/// // Примерна колекция, това е просто обвивка над Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Нека му дадем няколко метода, за да можем да го създадем и да добавим неща към него.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // и ще внедрим IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Сега можем да направим нова колекция ...
/// let mut c = MyCollection::new();
///
/// // ... добавете малко неща към него ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... и след това го превърнете в итератор:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Често се използва `IntoIterator` като Portrait bound.Това позволява промяна на типа на входящата колекция, стига да е все още итератор.
/// Допълнителни граници могат да бъдат определени чрез ограничаване на
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Типът на итерираните елементи.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// В какъв вид итератор превръщаме това?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Създава итератор от стойност.
    ///
    /// Вижте [module-level documentation] за повече.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Разширете колекция със съдържанието на итератор.
///
/// Итераторите създават поредица от стойности, а колекциите също могат да се разглеждат като поредица от стойности.
/// `Extend` Portrait преодолява тази празнина, позволявайки ви да разширите колекция, като включите съдържанието на този итератор.
/// При разширяване на колекция с вече съществуващ ключ, този запис се актуализира или, в случай на колекции, които позволяват множество записи с еднакви ключове, този запис се вмъква.
///
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// // Можете да удължите String с някои символи:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Внедряване на `Extend`:
///
/// ```
/// // Примерна колекция, това е просто обвивка над Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Нека му дадем няколко метода, за да можем да го създадем и да добавим неща към него.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // тъй като MyCollection има списък с i32, ние прилагаме Extend за i32
/// impl Extend<i32> for MyCollection {
///
///     // Това е малко по-просто с конкретния тип подпис: можем да извикаме разширяване на всичко, което може да се превърне в итератор, който ни дава i32s.
///     // Тъй като се нуждаем от i32s, които да поставим в MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Внедряването е много лесно: цикъл през итератора и add() всеки елемент към нас самите.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // нека разширим колекцията си с още три числа
/// c.extend(vec![1, 2, 3]);
///
/// // добавихме тези елементи в края
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Разширява колекция със съдържанието на итератор.
    ///
    /// Тъй като това е единственият задължителен метод за този Portrait, документите [trait-level] съдържат повече подробности.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// // Можете да удължите String с някои символи:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Разширява колекция с точно един елемент.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Запазва капацитет в колекция за дадения брой допълнителни елементи.
    ///
    /// Изпълнението по подразбиране не прави нищо.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}