use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Този Portrait осигурява преходен достъп до етап-източник в тръбопровод за интегратор-адаптер при условията, че
/// * източникът на итератор `S` сам реализира `SourceIter<Source = S>`
/// * има делегираща реализация на този Portrait за всеки адаптер в тръбопровода между източника и потребителя на тръбопровода.
///
/// Когато източникът е собствена структура на итератор (обикновено се нарича `IntoIter`), това може да бъде полезно за специализиране на внедряването на [`FromIterator`] или за възстановяване на останалите елементи, след като итераторът е частично изчерпан.
///
///
/// Имайте предвид, че реализациите не трябва непременно да осигуряват достъп до най-вътрешния източник на тръбопровод.Междинен адаптер с възможност за състояние може с нетърпение да оцени част от тръбопровода и да изложи вътрешното му хранилище като източник.
///
/// Portrait не е безопасен, тъй като изпълнителите трябва да поддържат допълнителни защитни свойства.
/// Вижте [`as_inner`] за подробности.
///
/// # Examples
///
/// Извличане на частично консумиран източник:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Етап на източника в итератор.
    type Source: Iterator;

    /// Извличане на източника на итераторски конвейер.
    ///
    /// # Safety
    ///
    /// Реализациите на трябва да връщат една и съща променяща се референция за целия им живот, освен ако не са заменени от повикващ.
    /// Повикващите могат да заменят референцията само когато са спрели итерацията и са изпуснали конвейера на итератора след извличане на източника.
    ///
    /// Това означава, че адаптерите на итератори могат да разчитат на източника, който не се променя по време на итерация, но те не могат да разчитат на него в своите реализации на Drop.
    ///
    /// Прилагането на този метод означава, че адаптерите се отказват само от частен достъп до своя източник и могат да разчитат само на гаранции, направени въз основа на типове приемници на методи.
    /// Липсата на ограничен достъп също така изисква адаптерите да поддържат публичния API на източника, дори когато имат достъп до вътрешните му елементи.
    ///
    /// Повикващите от своя страна трябва да очакват източникът да е във всяко състояние, което е в съответствие с неговия публичен API, тъй като адаптерите, разположени между него и източника, имат един и същ достъп.
    /// По-специално адаптерът може да е консумирал повече елементи, отколкото е строго необходимо.
    ///
    /// Общата цел на тези изисквания е да се позволи на потребителя на тръбопровод да използва
    /// * всичко, което остава в източника след спиране на итерацията
    /// * паметта, която е станала неизползвана от напредването на консумиращ итератор
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Итераторен адаптер, който произвежда изход, докато основният итератор произвежда стойности `Result::Ok`.
///
///
/// Ако се срещне грешка, итераторът спира и грешката се съхранява.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Обработете дадения итератор така, сякаш той дава `T` вместо `Result<T, _>`.
/// Всички грешки ще спрат вътрешния итератор и общият резултат ще бъде грешка.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}