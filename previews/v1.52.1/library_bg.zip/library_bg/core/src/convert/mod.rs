//! Traits за преобразуване между типове.
//!
//! traits в този модул предоставя начин за конвертиране от един тип в друг тип.
//! Всеки Portrait служи за различна цел:
//!
//! - Внедрете [`AsRef`] Portrait за евтини преобразувания от референтни към референтни
//! - Внедрете [`AsMut`] Portrait за евтини преобразувания, които могат да се променят
//! - Внедрете [`From`] Portrait за консумация на конверсии от стойност към стойност
//! - Внедрете [`Into`] Portrait за консумация на преобразувания от стойност в стойност към типове извън текущия crate
//! - [`TryFrom`] и [`TryInto`] traits се държат като [`From`] и [`Into`], но трябва да бъдат приложени, когато преобразуването може да се провали.
//!
//! traits в този модул често се използват като Portrait bounds за общи функции, така че да се поддържат аргументи от множество типове.Вижте документацията на всеки Portrait за примери.
//!
//! Като автор на библиотека, винаги трябва да предпочитате да внедрявате [`From<T>`][`From`] или [`TryFrom<T>`][`TryFrom`], а не [`Into<U>`][`Into`] или [`TryInto<U>`][`TryInto`], тъй като [`From`] и [`TryFrom`] осигуряват по-голяма гъвкавост и предлагат еквивалентни внедрения на [`Into`] или [`TryInto`] безплатно, благодарение на общо изпълнение в стандартната библиотека.
//! Когато насочвате към версия преди Rust 1.41, може да се наложи да внедрите [`Into`] или [`TryInto`] директно при преобразуване в тип извън текущия crate.
//!
//! # Общи приложения
//!
//! - [`AsRef`] и [`AsMut`] автоматично пренасочване, ако вътрешният тип е референтен
//! - [" От`] " <U>за T` означава [" В`] " </u><T><U>за U`</u>
//! - [`TryFrom`]`<U>за T` означава [`TryInto`]`</u><T><U>за U`</u>
//! - [`From`] и [`Into`] са рефлексивни, което означава, че всички типове могат да `into` себе си и `from` себе си
//!
//! Вижте всеки Portrait за примери за използване.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Функцията за идентичност.
///
/// Две неща са важни за тази функция:
///
/// - Не винаги е еквивалентно на затваряне като `|x| x`, тъй като затварянето може да принуди `x` към различен тип.
///
/// - Той премества входа `x`, предаден на функцията.
///
/// Въпреки че може да изглежда странно да има функция, която просто връща обратно входа, има някои интересни приложения.
///
///
/// # Examples
///
/// Използването на `identity`, за да не се прави нищо в поредица от други, интересни функции:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Нека се преструваме, че добавянето на една е интересна функция.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Използване на `identity` като основен случай "do nothing" в условно:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Правете още интересни неща ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Използване на `identity` за запазване на вариантите на `Some` на итератор на `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Използва се за извършване на евтино преобразуване от препратка към препратка.
///
/// Този Portrait е подобен на [`AsMut`], който се използва за преобразуване между изменяеми референции.
/// Ако трябва да направите скъпо преобразуване, по-добре е да внедрите [`From`] с тип `&T` или да напишете персонализирана функция.
///
/// `AsRef` има същия подпис като [`Borrow`], но [`Borrow`] е различен в няколко аспекта:
///
/// - За разлика от `AsRef`, [`Borrow`] има обща impl за всеки `T` и може да се използва за приемане на референция или стойност.
/// - [`Borrow`] също така изисква [`Hash`], [`Eq`] и [`Ord`] за заемна стойност да са еквивалентни на тези на притежаваната стойност.
/// Поради тази причина, ако искате да заемете само едно поле на структура, можете да внедрите `AsRef`, но не и [`Borrow`].
///
/// **Note: Този Portrait не трябва да се проваля **.Ако преобразуването може да се провали, използвайте специален метод, който връща [`Option<T>`] или [`Result<T, E>`].
///
/// # Общи приложения
///
/// - `AsRef` автоматично пренасочване, ако вътрешният тип е препратка или променяща се препратка (например: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Чрез използването на Portrait bounds можем да приемаме аргументи от различни типове, стига те да могат да бъдат преобразувани в посочения тип `T`.
///
/// Например: Чрез създаването на обща функция, която приема `AsRef<str>`, ние изразяваме, че искаме да приемем всички аргументи, които могат да бъдат преобразувани в [`&str`] като аргумент.
/// Тъй като и [`String`], и [`&str`] изпълняват `AsRef<str>`, можем да приемем и двете като входен аргумент.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Извършва преобразуването.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Използва се за извършване на евтино преобразуване на променлив към изменяем еталон.
///
/// Този Portrait е подобен на [`AsRef`], но се използва за преобразуване между изменяеми референции.
/// Ако трябва да направите скъпо преобразуване, по-добре е да внедрите [`From`] с тип `&mut T` или да напишете персонализирана функция.
///
/// **Note: Този Portrait не трябва да се проваля **.Ако преобразуването може да се провали, използвайте специален метод, който връща [`Option<T>`] или [`Result<T, E>`].
///
/// # Общи приложения
///
/// - `AsMut` автоматично пренасочване, ако вътрешният тип е променлива референция (например: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Използвайки `AsMut` като Portrait bound за обща функция, ние можем да приемем всички изменяеми препратки, които могат да бъдат преобразувани в тип `&mut T`.
/// Тъй като [`Box<T>`] реализира `AsMut<T>`, можем да напишем функция `add_one`, която приема всички аргументи, които могат да бъдат преобразувани в `&mut u64`.
/// Тъй като [`Box<T>`] реализира `AsMut<T>`, `add_one` приема и аргументи от тип `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Извършва преобразуването.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Преобразуване на стойност в стойност, което консумира входната стойност.Обратното на [`From`].
///
/// Човек трябва да избягва внедряването на [`Into`] и вместо това да прилага [`From`].
/// Внедряването на [`From`] автоматично предоставя такъв с изпълнение на [`Into`] благодарение на общото внедряване в стандартната библиотека.
///
/// Предпочитайте да използвате [`Into`] пред [`From`], когато указвате Portrait bounds за обща функция, за да сте сигурни, че могат да се използват и типове, които реализират само [`Into`].
///
/// **Note: Този Portrait не трябва да се проваля **.Ако преобразуването може да се провали, използвайте [`TryInto`].
///
/// # Общи приложения
///
/// - [`От`]`<T>за U` предполага `Into<U> for T`
/// - [`Into`] е рефлексивен, което означава, че `Into<T> for T` е внедрен
///
/// # Внедряване на [`Into`] за преобразуване към външни типове в стари версии на Rust
///
/// Преди Rust 1.41, ако типът дестинация не е бил част от текущия crate, тогава не можете да внедрите [`From`] директно.
/// Например, вземете този код:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Това няма да успее да се компилира в по-старите версии на езика, защото правилата за осиротяване на Rust бяха малко по-строги.
/// За да заобиколите това, можете директно да внедрите [`Into`]:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Важно е да се разбере, че [`Into`] не осигурява изпълнение на [`From`] (както [`From`] прави с [`Into`]).
/// Следователно, винаги трябва да се опитвате да внедрите [`From`] и след това да се върнете към [`Into`], ако [`From`] не може да бъде внедрен.
///
/// # Examples
///
/// [`String`] изпълнява [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// За да изразим, че искаме обща функция да приема всички аргументи, които могат да бъдат преобразувани в определен тип `T`, можем да използваме Portrait bound от [`Into`]`<T>`.
///
/// Например: Функцията `is_hello` взема всички аргументи, които могат да бъдат преобразувани в [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Извършва преобразуването.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Използва се за превръщане на стойност в стойност, докато се консумира входната стойност.Това е реципрочното на [`Into`].
///
/// Винаги трябва да се предпочита внедряването на `From` пред [`Into`], защото внедряването на `From` автоматично му осигурява изпълнение на [`Into`] благодарение на общото изпълнение в стандартната библиотека.
///
///
/// Прилагайте [`Into`] само когато насочвате към версия преди Rust 1.41 и конвертирате в тип извън текущия crate.
/// `From` не беше в състояние да направи тези видове преобразувания в по-ранни версии поради правилата за осиротяване на Rust.
/// Вижте [`Into`] за повече подробности.
///
/// Предпочитайте да използвате [`Into`] пред `From`, когато указвате Portrait bounds за обща функция.
/// По този начин типовете, които директно реализират [`Into`], могат да се използват и като аргументи.
///
/// `From` е много полезен и при обработка на грешки.Когато се конструира функция, която може да се провали, типът на връщане обикновено ще бъде от формата `Result<T, E>`.
/// `From` Portrait опростява обработката на грешки, като позволява на функцията да върне единичен тип грешка, който капсулира множество типове грешки.Вижте раздела "Examples" и [the book][book] за повече подробности.
///
/// **Note: Този Portrait не трябва да се проваля **.Ако преобразуването може да се провали, използвайте [`TryFrom`].
///
/// # Общи приложения
///
/// - `From<T> for U` предполага ["В"] "<U>за T"</u>
/// - `From` е рефлексивен, което означава, че `From<T> for T` е внедрен
///
/// # Examples
///
/// [`String`] прилага `From<&str>`:
///
/// Изрично преобразуване от `&str` в низ се извършва, както следва:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Докато извършвате обработка на грешки, често е полезно да внедрите `From` за вашия собствен тип грешка.
/// Чрез преобразуване на основните типове грешки в наш собствен потребителски тип грешка, който капсулира основния тип грешка, можем да върнем единичен тип грешка, без да губим информация за основната причина.
/// Операторът '?' автоматично преобразува основния тип грешка в нашия персонализиран тип грешка, като извиква `Into<CliError>::into`, който се предоставя автоматично при внедряване на `From`.
/// След това компилаторът установява коя реализация на `Into` трябва да се използва.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Извършва преобразуването.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Опит за преобразуване, който консумира `self`, което може или не може да бъде скъпо.
///
/// Авторите на библиотеките обикновено не трябва да прилагат директно този Portrait, но трябва да предпочитат да внедрят [`TryFrom`] Portrait, който предлага по-голяма гъвкавост и осигурява еквивалентна реализация на `TryInto` безплатно, благодарение на обща реализация в стандартната библиотека.
/// За повече информация относно това вижте документацията за [`Into`].
///
/// # Внедряване на `TryInto`
///
/// Това страда от същите ограничения и разсъждения като внедряването на [`Into`], вижте там за подробности.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Типът, върнат в случай на грешка при преобразуване.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Извършва преобразуването.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Прости и безопасни преобразувания от тип, които при определени обстоятелства могат да се провалят контролирано.Това е реципрочното на [`TryInto`].
///
/// Това е полезно, когато правите преобразуване на тип, което може тривиално да успее, но може да се нуждае и от специално боравене.
/// Например няма начин да конвертирате [`i64`] в [`i32`], като използвате [`From`] Portrait, тъй като [`i64`] може да съдържа стойност, която [`i32`] не може да представи и така преобразуването ще загуби данни.
///
/// Това може да се обработи чрез съкращаване на [`i64`] до [`i32`] (по същество даване на стойността на [`i64`] по модул [`i32::MAX`]) или чрез просто връщане на [`i32::MAX`] или по някакъв друг метод.
/// [`From`] Portrait е предназначен за перфектни преобразувания, така че `TryFrom` Portrait информира програмиста кога преобразуването на тип може да се обърка и им позволява да решат как да се справят.
///
/// # Общи приложения
///
/// - `TryFrom<T> for U` предполага [`TryInto`]`<U>за T`</u>
/// - [`try_from`] е рефлексивен, което означава, че `TryFrom<T> for T` е внедрен и не може да се провали-свързаният тип `Error` за извикване на `T::try_from()` за стойност от тип `T` е [`Infallible`].
/// Когато типът [`!`] е стабилизиран, [`Infallible`] и [`!`] ще бъдат еквивалентни.
///
/// `TryFrom<T>` може да се приложи както следва:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Както е описано, [`i32`] реализира " TryFrom <`[`i64`]`> `:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Безшумно съкращава `big_number`, изисква откриване и обработка на съкращаването след факта.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Връща грешка, защото `big_number` е твърде голям, за да се побере в `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Връща `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Типът, върнат в случай на грешка при преобразуване.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Извършва преобразуването.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// ОБЩИ ИМПЛ
////////////////////////////////////////////////////////////////////////////////

// Като асансьори над&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Като асансьори над &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): заменете горните импулси за&/&mut със следния по-общ:
// // Като лифтове над Дереф
// импл <D: ?Sized + Deref<Target: AsRef<U>>, U:? Размери> AsRef <U>за D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut се вдига над &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): заменете горния impl за &mut със следния по-общ:
// // AsMut се издига над DerefMut
// импл <D: ?Sized + Deref<Target: AsMut<U>>, U:? Размери> AsMut <U>за D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// От внушава Into
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// From (и по този начин Into) е рефлексивен
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Бележка за стабилността:** Този impl все още не съществува, но ние сме "reserving space", за да го добавим в future.
/// Вижте [rust-lang/rust#64715][#64715] за подробности.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): вместо това направете принципна корекция.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom предполага TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Непогрешимите преобразувания са семантично еквивалентни на непогрешимите преобразувания с необитаем тип грешка.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// БЕТОННИ ИМПЛИ
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// ТИП БЕЗ ГРЕШКИ
////////////////////////////////////////////////////////////////////////////////

/// Типът грешка за грешки, които никога не могат да се случат.
///
/// Тъй като това изброяване няма вариант, стойност от този тип всъщност никога не може да съществува.
/// Това може да бъде полезно за общи API, които използват [`Result`] и параметризират типа грешка, за да покажат, че резултатът винаги е [`Ok`].
///
/// Например [`TryFrom`] Portrait (преобразуване, което връща [`Result`]) има обща реализация за всички типове, където съществува обратна реализация [`Into`].
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future съвместимост
///
/// Това изброяване има същата роля като [the `!`“never”type][never], която е нестабилна в тази версия на Rust.
/// Когато `!` се стабилизира, планираме да направим `Infallible` типичен псевдоним на него:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... и в крайна сметка оттегля `Infallible`.
///
/// Има обаче един случай, в който синтаксисът `!` може да бъде използван преди `!` да бъде стабилизиран като пълноправен тип: в позицията на тип връщане на функция.
/// По-конкретно, възможни са реализации за два различни типа указатели на функции:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Тъй като `Infallible` е изброяване, този код е валиден.
/// Когато обаче `Infallible` се превърне в псевдоним на never type, двата `impl` ще започнат да се припокриват и следователно ще бъдат забранени от правилата за кохерентност на Portrait на езика.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}