//! Libcore prelude
//!
//! Този модул е предназначен за потребители на libcore, които също не се свързват с libstd.
//! Този модул се импортира по подразбиране, когато `#![no_std]` се използва по същия начин като стандартната библиотека prelude.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Версията от 2015 г. на ядрото prelude.
///
/// Вижте [module-level documentation](self) за повече.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Версията от 2018 г. на ядрото prelude.
///
/// Вижте [module-level documentation](self) за повече.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Версията на ядрото prelude от 2021 г.
///
/// Вижте [module-level documentation](self) за повече.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Добавете още неща.
}