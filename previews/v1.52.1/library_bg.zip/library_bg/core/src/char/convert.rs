//! Преобразувания на знаци.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Преобразува `u32` в `char`.
///
/// Обърнете внимание, че всички [`char`] s са валидни [`u32`] s и могат да бъдат предадени на един с
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Обратното обаче не е вярно: не всички валидни [`u32`] s са валидни [`char`] s.
/// `from_u32()` ще върне `None`, ако входът не е валидна стойност за [`char`].
///
/// За опасна версия на тази функция, която игнорира тези проверки, вижте [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Връща се `None`, когато входът не е валиден [`char`]:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Преобразува `u32` в `char`, пренебрегвайки валидността.
///
/// Обърнете внимание, че всички [`char`] s са валидни [`u32`] s и могат да бъдат предадени на един с
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Обратното обаче не е вярно: не всички валидни [`u32`] s са валидни [`char`] s.
/// `from_u32_unchecked()` ще игнорира това и ще хвърли сляпо на [`char`], вероятно създавайки невалиден.
///
///
/// # Safety
///
/// Тази функция е опасна, тъй като може да създаде невалидни стойности на `char`.
///
/// За безопасна версия на тази функция вижте функцията [`from_u32`].
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // БЕЗОПАСНОСТ: повикващият трябва да гарантира, че `i` е валидна стойност на символа.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Преобразува [`char`] в [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Преобразува [`char`] в [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Char се излива в стойността на кодовата точка, след което се удължава до нула до 64 бита.
        // Вижте [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Преобразува [`char`] в [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Char се излива в стойността на кодовата точка, след което се удължава до нула до 128 бита.
        // Вижте [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Картира байт в 0x00 ..=0xFF в `char`, чиято кодова точка има същата стойност, в U + 0000 ..=U + 00FF.
///
/// Unicode е проектиран така, че това ефективно декодира байтове с кодиране на знаци, което IANA нарича ISO-8859-1.
/// Това кодиране е съвместимо с ASCII.
///
/// Имайте предвид, че това е различно от ISO/IEC 8859-1 aka
/// ISO 8859-1 (с един по-малко тире), който оставя някои "blanks", байтови стойности, които не са присвоени на никакъв символ.
/// ISO-8859-1 (IANA) ги присвоява на контролните кодове C0 и C1.
///
/// Имайте предвид, че това *също* се различава от Windows-1252 известен още
/// кодова страница 1252, което е супермножество ISO/IEC 8859-1, което присвоява някои (не всички!) празни места на пунктуацията и различни латински символи.
///
/// За да объркате нещата допълнително, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` и `windows-1252` са псевдоними за супермножество Windows-1252, което запълва останалите празни места със съответните контролни кодове C0 и C1.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Преобразува [`u8`] в [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Грешка, която може да бъде върната при синтактичен анализ на char.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // БЕЗОПАСНОСТ: проверено дали това е законна стойност на Unicode
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Типът грешка се връща, когато преобразуването от u32 в char не успее.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Преобразува цифра в дадения радикс в `char`.
///
/// 'radix' тук понякога се нарича още 'base'.
/// Радикс от две показва двоично число, радиус от десет, десетичен и радиус от шестнадесет, шестнадесетичен, за да даде някои общи стойности.
///
/// Поддържат се произволни радикали.
///
/// `from_digit()` ще върне `None`, ако входът не е цифра в дадения радикс.
///
/// # Panics
///
/// Panics, ако има радиус, по-голям от 36.
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Десетичното число 11 е едноцифрено в база 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Връща се `None`, когато входът не е цифра:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Преминавайки голям радикс, причинявайки panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}