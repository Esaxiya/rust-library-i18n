//! Примитивни traits и типове, представляващи основни свойства на типовете.
//!
//! Типовете Rust могат да бъдат класифицирани по различни полезни начини според техните присъщи свойства.
//! Тези класификации са представени като traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Типове, които могат да се прехвърлят през границите на нишките.
///
/// Този Portrait се прилага автоматично, когато компилаторът определи, че е подходящ.
///
/// Пример за тип, който не е " Изпрати`, е указателят за преброяване на референции [`rc::Rc`][`Rc`].
/// Ако две нишки се опитат да клонират [`Rc`], които сочат към една и съща преброена стойност, те могат да се опитат да актуализират броя на препратките едновременно, което е [undefined behavior][ub], тъй като [`Rc`] не използва атомни операции.
///
/// Неговият братовчед [`sync::Arc`][arc] използва атомни операции (което води до някои режийни разходи) и по този начин е `Send`.
///
/// Вижте [the Nomicon](../../nomicon/send-and-sync.html) за повече подробности.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Типове с постоянен размер, известни по време на компилиране.
///
/// Всички параметри на типа имат имплицитна граница на `Sized`.Специалният синтаксис `?Sized` може да се използва за премахване на тази граница, ако не е подходящо.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//грешка: Размерът не е приложен за [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Единственото изключение е неявният тип `Self` на Portrait.
/// Portrait няма неявен `Sized`, обвързан, тъй като това е несъвместимо с [Portrait обект], където по дефиниция Portrait трябва да работи с всички възможни внедряващи и по този начин може да бъде с всякакъв размер.
///
///
/// Въпреки че Rust ще ви позволи да свържете `Sized` със Portrait, няма да можете да го използвате за формиране на обект Portrait по-късно:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // нека y: &dyn Бар= &Impl;//грешка: Portrait `Bar` не може да бъде превърнат в обект
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // например по подразбиране, което изисква `[T]: !Default` да бъде оценим
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Типове, които могат да бъдат "unsized" към динамично оразмерен тип.
///
/// Например оразмереният тип масив `[i8; 2]` изпълнява `Unsize<[i8]>` и `Unsize<dyn fmt::Debug>`.
///
/// Всички внедрения на `Unsize` се предоставят автоматично от компилатора.
///
/// `Unsize` се прилага за:
///
/// - `[T; N]` е `Unsize<[T]>`
/// - `T` е `Unsize<dyn Trait>`, когато `T: Trait`
/// - `Foo<..., T, ...>` е `Unsize<Foo<..., U, ...>>`, ако:
///   - `T: Unsize<U>`
///   - Foo е структура
///   - Само последното поле на `Foo` има тип, включващ `T`
///   - `T` не е част от типа на други полета
///   - `Bar<T>: Unsize<Bar<U>>`, ако последното поле на `Foo` има тип `Bar<T>`
///
/// `Unsize` се използва заедно с [`ops::CoerceUnsized`], за да позволи на контейнери "user-defined" като [`Rc`] да съдържат типове с динамичен размер.
/// Вижте [DST coercion RFC][RFC982] и [the nomicon entry on coercion][nomicon-coerce] за повече подробности.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Необходим Portrait за константи, използвани в съвпадения на шаблони.
///
/// Всеки тип, който произвежда `PartialEq`, автоматично изпълнява този Portrait,*независимо* дали неговите параметри на типа изпълняват `Eq`.
///
/// Ако елемент `const` съдържа някакъв тип, който не изпълнява този Portrait, тогава този тип или (1.) не реализира `PartialEq` (което означава, че константата няма да осигури този метод за сравнение, който генерирането на код приема, че е наличен), или (2.) той реализира *свой собствен* версия на `PartialEq` (която предполагаме, че не съответства на сравнение на структурно равенство).
///
///
/// Във всеки от двата сценария по-горе отхвърляме използването на такава константа в съвпадение на шаблон.
///
/// Вижте също [structural match RFC][RFC1445] и [issue 63438], които са мотивирали мигрирането от базиран на атрибути дизайн към този Portrait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Необходим Portrait за константи, използвани в съвпадения на шаблони.
///
/// Всеки тип, който произвежда `Eq`, автоматично прилага този Portrait,*независимо* дали параметрите на неговия тип реализират `Eq`.
///
/// Това е хак за заобикаляне на ограничение в нашата система за тип.
///
/// # Background
///
/// Искаме да изискваме типовете consts, използвани в съвпадения на шаблони, да имат атрибут `#[derive(PartialEq, Eq)]`.
///
/// В един по-идеален свят бихме могли да проверим това изискване, като просто проверим дали дадения тип изпълнява както `StructuralPartialEq` Portrait *, така и*`Eq` Portrait.
/// Можете обаче да имате ADT, които *правят*`derive(PartialEq, Eq)`, и да бъдем случай, който искаме компилаторът да приеме, и въпреки това типът на константата не успява да внедри `Eq`.
///
/// А именно случай като този:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Проблемът в горния код е, че `Wrap<fn(&())>` не изпълнява `PartialEq`, нито `Eq`, защото `за <'a> fn(&'a _)` does not implement those traits.)
///
/// Следователно не можем да разчитаме на наивна проверка за `StructuralPartialEq` и само `Eq`.
///
/// Като хак за заобикаляне на това използваме две отделни traits, инжектирани от всеки от двата производни (`#[derive(PartialEq)]` и `#[derive(Eq)]`) и проверяваме дали и двамата присъстват като част от проверката на структурно съвпадение.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Типове, чиито стойности могат да се дублират просто чрез копиране на битове.
///
/// По подразбиране променливите обвързвания имат " семантика на преместване`.С други думи:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` се е преместил в `y` и затова не може да се използва
///
/// // println! ("{: ?}", x);//грешка: използване на преместена стойност
/// ```
///
/// Ако обаче даден тип реализира `Copy`, той вместо това има " копиране на семантика`:
///
/// ```
/// // Можем да извлечем изпълнение на `Copy`.
/// // `Clone` също се изисква, тъй като това е супертрейт на `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` е копие на `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Важно е да се отбележи, че в тези два примера единствената разлика е дали ви е разрешен достъп до `x` след заданието.
/// Под капака както копирането, така и преместването могат да доведат до копиране на битове в паметта, въпреки че понякога това се оптимизира.
///
/// ## Как мога да внедря `Copy`?
///
/// Има два начина да внедрите `Copy` за вашия тип.Най-простото е да се използва `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Можете също така да внедрите `Copy` и `Clone` ръчно:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Има малка разлика между двете: стратегията `derive` също ще постави `Copy`, обвързан с параметри на типа, което не винаги е желано.
///
/// ## Каква е разликата между `Copy` и `Clone`?
///
/// Копията се случват неявно, например като част от задание `y = x`.Поведението на `Copy` не може да се прехвърли;това винаги е просто копие по малко.
///
/// Клонирането е явно действие, `x.clone()`.Внедряването на [`Clone`] може да осигури всякакво специфично поведение, необходимо за безопасно дублиране на стойности.
/// Например, внедряването на [`Clone`] за [`String`] трябва да копира посочения към буфер низ в купчината.
/// Едно просто битово копиране на стойности на [`String`] просто ще копира показалеца, което води до двойно освобождаване по линията.
/// Поради тази причина [`String`] е [`Clone`], но не и `Copy`.
///
/// [`Clone`] е супертрейт на `Copy`, така че всичко, което е `Copy`, също трябва да внедри [`Clone`].
/// Ако типът е `Copy`, тогава неговата реализация [`Clone`] трябва само да върне `*self` (вижте примера по-горе).
///
/// ## Кога моят тип може да бъде `Copy`?
///
/// Един тип може да реализира `Copy`, ако всички негови компоненти изпълняват `Copy`.Например, тази структура може да бъде `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Структурата може да бъде `Copy` и [`i32`] е `Copy`, следователно `Point` може да бъде `Copy`.
/// За разлика от това, помислете
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Структурата `PointList` не може да внедри `Copy`, защото [`Vec<T>`] не е `Copy`.Ако се опитаме да извлечем изпълнение на `Copy`, ще получим грешка:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Споделените референции (`&T`) също са `Copy`, така че даден тип може да бъде `Copy`, дори когато съдържа споделени референции от типове `T`, които са *не*`Copy`.
/// Помислете за следната структура, която може да внедри `Copy`, тъй като тя съдържа само *споделена препратка* към нашия не-Копиращ тип `PointList` отгоре:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Кога *не може* моят тип да е `Copy`?
///
/// Някои типове не могат да бъдат копирани безопасно.Например, копирането на `&mut T` би създало псевдоним променлива препратка.
/// Копирането на [`String`] би дублирало отговорността за управление на буфера [" String`], което ще доведе до двойно безплатно.
///
/// Генерализирайки последния случай, всеки тип, изпълняващ [`Drop`], не може да бъде `Copy`, защото той управлява някакъв ресурс освен собствените си байтове [`size_of::<T>`].
///
/// Ако се опитате да внедрите `Copy` в структура или изброяване, съдържащи данни, които не са " Копия`, ще получите грешката [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Кога *трябва* моят тип да е `Copy`?
///
/// Най-общо казано, ако вашият тип _can_ внедри `Copy`, трябва.
/// Имайте предвид обаче, че внедряването на `Copy` е част от публичния API на вашия тип.
/// Ако типът може да стане " Копиране` в future, би било разумно да пропуснете внедряването на `Copy` сега, за да избегнете нарушаване на промяната на API.
///
/// ## Допълнителни изпълнители
///
/// В допълнение към [implementors listed below][impls], следните типове също изпълняват `Copy`:
///
/// * Типове елементи на функции (т.е. отделните типове, дефинирани за всяка функция)
/// * Типове указатели на функции (напр. `fn() -> i32`)
/// * Типове масиви за всички размери, ако типът артикул също така изпълнява `Copy` (напр. `[i32; 123456]`)
/// * Типове типове, ако всеки компонент също така изпълнява `Copy` (например `()`, `(i32, bool)`)
/// * Типове затваряне, ако те не улавят никаква стойност от околната среда или ако всички такива уловени стойности сами реализират `Copy`.
///   Обърнете внимание, че променливите, заснети от споделена препратка, винаги изпълняват `Copy` (дори ако референтът не го прави), докато променливите, заснети от променлива препратка, никога не изпълняват `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Това позволява копиране на тип, който не изпълнява `Copy` поради неудовлетворени граници през целия живот (копиране на `A<'_>`, когато само `A<'static>: Copy` и `A<'_>: Clone`).
// Засега имаме този атрибут тук само защото има доста съществуващи специализации на `Copy`, които вече съществуват в стандартната библиотека, и няма начин безопасно да имаме това поведение в момента.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Извлечете макрос, генериращ impl на Portrait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Видове, за които е безопасно да споделяте препратки между нишки.
///
/// Този Portrait се прилага автоматично, когато компилаторът определи, че е подходящ.
///
/// Точната дефиниция е: тип `T` е [`Sync`] тогава и само ако `&T` е [`Send`].
/// С други думи, ако няма възможност за [undefined behavior][ub] (включително състезания с данни) при предаване на `&T` препратки между нишки.
///
/// Както бихме могли да очакваме, всички примитивни типове като [`u8`] и [`f64`] са [`Sync`], както и простите агрегирани типове, които ги съдържат, като кортежи, структури и изброявания.
/// Още примери за основни типове [`Sync`] включват типове "immutable" като `&T` и такива с проста наследствена променливост, като [`Box<T>`][box], [`Vec<T>`][vec] и повечето други типове колекции.
///
/// (Общите параметри трябва да бъдат [`Sync`], за да може контейнерът им да бъде [`Sync`].)
///
/// Донякъде изненадваща последица от дефиницията е, че `&mut T` е `Sync` (ако `T` е `Sync`), въпреки че изглежда, че това може да осигури несинхронизирана мутация.
/// Номерът е, че изменяема препратка зад споделена препратка (т.е. `& &mut T`) става само за четене, сякаш е `& &T`.
/// Следователно няма риск от състезание с данни.
///
/// Типовете, които не са `Sync`, са тези, които имат "interior mutability" в не-безопасна форма, като [`Cell`][cell] и [`RefCell`][refcell].
/// Тези типове позволяват мутация на тяхното съдържание дори чрез неизменна, споделена препратка.
/// Например методът `set` на [`Cell<T>`][cell] отнема `&self`, така че той изисква само споделена референция [`&Cell<T>`][cell].
/// Методът не извършва синхронизация, поради което [`Cell`][cell] не може да бъде `Sync`.
///
/// Друг пример за тип, който не е "Sync", е указателят за преброяване на референции [`Rc`][rc].
/// Като се има предвид всеки референтен [`&Rc<T>`][rc], можете да клонирате нов [`Rc<T>`][rc], като промените броя на референциите по неатомен начин.
///
/// За случаите, когато някой се нуждае от безопасна за резбата вътрешна променливост, Rust осигурява [atomic data types], както и изрично заключване чрез [`sync::Mutex`][mutex] и [`sync::RwLock`][rwlock].
/// Тези типове гарантират, че всяка мутация не може да причини състезания с данни, следователно типовете са `Sync`.
/// По същия начин [`sync::Arc`][arc] осигурява аналог на [`Rc`][rc], безопасен за нишки.
///
/// Всички типове с вътрешна изменчивост също трябва да използват обвивката [`cell::UnsafeCell`][unsafecell] около value(s), която може да се мутира чрез споделена препратка.
/// Невъзможността да се направи това е [undefined behavior][ub].
/// Например [" трансмутиране`][трансмутиране]-ing от `&T` в `&mut T` е невалидно.
///
/// Вижте [the Nomicon][nomicon-send-and-sync] за повече подробности относно `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): след като поддръжката за добавяне на бележки в `rustc_on_unimplemented` попада в бета версия и тя е удължена, за да се провери дали затварянето е някъде във веригата на изискванията, разширете го като такъв (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Нулев размер, използван за маркиране на неща, които "act like" притежават `T`.
///
/// Добавянето на поле `PhantomData<T>` към вашия тип казва на компилатора, че вашият тип действа така, сякаш съхранява стойност от тип `T`, въпреки че всъщност не го прави.
/// Тази информация се използва при изчисляване на определени свойства за безопасност.
///
/// За по-задълбочено обяснение как да използвате `PhantomData<T>`, моля вижте [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Ужасна бележка 👻👻👻
///
/// Въпреки че и двамата имат страшни имена, `PhantomData` и " фантомни типове` са свързани, но не са идентични.Параметърът на фантомен тип е просто параметър на типа, който никога не се използва.
/// В Rust това често кара компилаторът да се оплаква и решението е да се добави използване на "dummy" чрез `PhantomData`.
///
/// # Examples
///
/// ## Неизползвани параметри за целия живот
///
/// Може би най-често използваният случай за `PhantomData` е структура, която има неизползван параметър за цял живот, обикновено като част от някакъв опасен код.
/// Например, тук е структура `Slice`, която има два указателя от тип `*const T`, вероятно насочени някъде към масив:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Намерението е основните данни да са валидни само за целия живот `'a`, така че `Slice` не трябва да надживява `'a`.
/// Това намерение обаче не е изразено в кода, тъй като не се използват по време на живота `'a` и следователно не е ясно за какви данни се отнася.
/// Можем да коригираме това, като кажем на компилатора да действа *така, сякаш* структурата `Slice` съдържа референтен `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Това също от своя страна изисква пояснението `T: 'a`, което показва, че всички препратки в `T` са валидни през целия живот `'a`.
///
/// Когато инициализирате `Slice`, просто предоставяте стойността `PhantomData` за полето `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Неизползвани параметри на типа
///
/// Понякога се случва да имате неизползвани параметри на типа, които посочват към кой тип данни дадена структура е "tied", въпреки че тези данни всъщност не се намират в самата структура.
/// Ето пример, когато това възниква при [FFI].
/// Външният интерфейс използва манипулатори от тип `*mut ()` за препращане към стойности на Rust от различни типове.
/// Проследяваме типа Rust, като използваме параметър фантомен тип на struct `ExternalResource`, който обвива дръжка.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Собственост и проверка за спад
///
/// Добавянето на поле от тип `PhantomData<T>` показва, че вашият тип притежава данни от тип `T`.Това от своя страна предполага, че когато типът ви отпадне, той може да отпадне един или повече екземпляра от типа `T`.
/// Това има отношение към анализа на [drop check] на компилатора на Rust.
///
/// Ако вашата структура всъщност не *притежава* данните от тип `T`, по-добре е да използвате референтен тип, като `PhantomData<&'a T>` (ideally) или `PhantomData<*const T>` (ако не е приложим живот), за да не се посочва собствеността.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Вътрешен компилатор Portrait, използван за обозначаване на типа дискриминанти на enum.
///
/// Този Portrait се прилага автоматично за всеки тип и не добавя никакви гаранции към [`mem::Discriminant`].
/// **Недефинирано поведение** е преобразуването между `DiscriminantKind::Discriminant` и `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Типът на дискриминанта, който трябва да отговаря на Portrait bounds, изискван от `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Вътрешен компилатор Portrait, използван за определяне дали даден тип съдържа някакъв `UnsafeCell` вътрешно, но не чрез индирекция.
///
/// Това засяга например дали `static` от този тип е поставен в статична памет само за четене или статична памет, която може да се записва.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Типове, които могат да бъдат безопасно премествани след фиксиране.
///
/// Самият Rust няма понятие за неподвижни типове и счита движенията (например чрез присвояване или [`mem::replace`]) за винаги безопасни.
///
/// Вместо това се използва тип [`Pin`][Pin], за да се предотврати движението през системата на типа.Указателите `P<T>`, увити в обвивката [`Pin<P<T>>`][Pin], не могат да бъдат преместени.
/// Вижте документацията за [`pin` module] за повече информация относно закрепването.
///
/// Внедряването на `Unpin` Portrait за `T` премахва ограниченията за фиксиране на типа, което след това позволява преместването на `T` от [`Pin<P<T>>`][Pin] с функции като [`mem::replace`].
///
///
/// `Unpin` изобщо няма последица за незакачените данни.
/// По-специално, [`mem::replace`] премества щастливо данните на `!Unpin` (работи за всеки `&mut T`, а не само когато `T: Unpin`).
/// Не можете обаче да използвате [`mem::replace`] за данни, увити в [`Pin<P<T>>`][Pin], защото не можете да получите `&mut T`, който ви е необходим за това, и *това* е, което кара тази система да работи.
///
/// Така че това, например, може да се направи само за типове, изпълняващи `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Нуждаем се от изменяема препратка, за да се обадим на `mem::replace`.
/// // Можем да получим такава препратка, като (implicitly) извика `Pin::deref_mut`, но това е възможно само защото `String` реализира `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Този Portrait се прилага автоматично за почти всеки тип.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Тип маркер, който не прилага `Unpin`.
///
/// Ако даден тип съдържа `PhantomPinned`, той няма да внедри `Unpin` по подразбиране.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Реализации на `Copy` за примитивни типове.
///
/// Реализации, които не могат да бъдат описани в Rust, са внедрени в `traits::SelectionContext::copy_clone_conditions()` в `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Споделените препратки могат да се копират, но променливите препратки *не могат*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}