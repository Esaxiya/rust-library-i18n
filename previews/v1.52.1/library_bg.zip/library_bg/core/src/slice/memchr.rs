// Оригинална реализация, взета от rust-memchr.
// Copyright 2015 Андрю Галант, блус и Николас Кох

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Използвайте съкращаване.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Връща `true`, ако `x` съдържа нулев байт.
///
/// От *Matters Computational*, J. Arndt:
///
/// "Идеята е да се извади по един от всеки от байтовете и след това да се търсят байтове, където заемът се разпространява чак до най-значимите
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Връща първия индекс, съответстващ на байта `x` в `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Бърз път за малки филийки
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Сканирайте за единична байтова стойност, като четете две думи `usize` наведнъж.
    //
    // Разделете `text` на три части
    // - несравнена начална част, преди първия адрес, подравнен в текста
    // - тяло, сканирайте по 2 думи наведнъж
    // - последната останала част, <2 думи

    // търсене до подравнена граница
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // търсене в тялото на текста
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // БЕЗОПАСНОСТ: предикатът на while гарантира разстояние от поне 2 * usize_bytes
        // между отместването и края на среза.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // break, ако има съвпадащ байт
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Намерете байта след точката, в която цикълът на тялото е спрял.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Връща последния индекс, съответстващ на байта `x` в `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Сканирайте за единична байтова стойност, като четете две думи `usize` наведнъж.
    //
    // Разделете `text` на три части:
    // - неодобрена опашка, след адреса, подравнен с последната дума в текста,
    // - тяло, сканирано по 2 думи наведнъж,
    // - първите останали байтове, <2 думи.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Това наричаме само за да получим дължината на префикса и суфикса.
        // В средата винаги обработваме две парчета наведнъж.
        // БЕЗОПАСНОСТ: преобразуването на `[u8]` в `[usize]` е безопасно, с изключение на разликите в размера, които се обработват от `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Претърсете тялото на текста, уверете се, че не пресичаме min_aligned_offset.
    // офсетът винаги е подравнен, така че само тестването на `>` е достатъчно и избягва евентуално преливане.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // БЕЗОПАСНОСТ: отместването започва от len, suffix.len(), стига да е по-голямо от
        // min_aligned_offset (prefix.len()) оставащото разстояние е поне 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Прекъсване, ако има съвпадащ байт.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Намерете байта преди точката, в която цикълът на тялото е спрял.
    text[..offset].iter().rposition(|elt| *elt == x)
}