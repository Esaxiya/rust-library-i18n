//! Сортиране на филийки
//!
//! Този модул съдържа алгоритъм за сортиране, базиран на бързата сортираща победа на Орсън Питърс, публикувана на: <https://github.com/orlp/pdqsort>
//!
//!
//! Нестабилното сортиране е съвместимо с libcore, защото не разпределя памет, за разлика от нашата стабилна реализация на сортиране.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// При изпускане копира от `src` в `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // БЕЗОПАСНОСТ: Това е помощен клас.
        //          Моля, обърнете се към неговото използване за коректност.
        //          А именно, трябва да сте сигурни, че `src` и `dst` не се припокриват, както се изисква от `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Премества първия елемент надясно, докато срещне по-голям или равен елемент.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // БЕЗОПАСНОСТ: Небезопасните операции по-долу включват индексиране без обвързана проверка (`get_unchecked` и `get_unchecked_mut`)
    // и копиране на памет (`ptr::copy_nonoverlapping`).
    //
    // а.Индексиране:
    //  1. Проверихме размера на масива до>=2.
    //  2. Цялото индексиране, което ще правим, е винаги между {0 <= index < len} най-много.
    //
    // б.Копиране в паметта
    //  1. Получаваме указатели за препратки, които са гарантирано валидни.
    //  2. Те не могат да се припокриват, защото получаваме указатели за индекси на разликата в среза.
    //     А именно `i` и `i-1`.
    //  3. Ако срезът е правилно подравнен, елементите са правилно подравнени.
    //     Отговорността на повикващия е да се увери, че филията е правилно подравнена.
    //
    // Вижте коментарите по-долу за повече подробности.
    unsafe {
        // Ако първите два елемента не са в ред ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Прочетете първия елемент в променлива, разпределена в стека.
            // Ако следваща операция за сравнение panics, `hole` ще изпадне и автоматично ще запише елемента обратно в среза.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Преместете `i`-ия елемент с едно място наляво, като по този начин дупката се измества надясно.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` се изпуска и по този начин копира `tmp` в останалата дупка в `v`.
        }
    }
}

/// Премества последния елемент наляво, докато срещне по-малък или равен елемент.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // БЕЗОПАСНОСТ: Небезопасните операции по-долу включват индексиране без обвързана проверка (`get_unchecked` и `get_unchecked_mut`)
    // и копиране на памет (`ptr::copy_nonoverlapping`).
    //
    // а.Индексиране:
    //  1. Проверихме размера на масива до>=2.
    //  2. Цялото индексиране, което ще правим, е винаги между `0 <= index < len-1` най-много.
    //
    // б.Копиране в паметта
    //  1. Получаваме указатели за препратки, които са гарантирано валидни.
    //  2. Те не могат да се припокриват, защото получаваме указатели за индекси на разликата в среза.
    //     А именно `i` и `i+1`.
    //  3. Ако срезът е правилно подравнен, елементите са правилно подравнени.
    //     Отговорността на повикващия е да се увери, че филията е правилно подравнена.
    //
    // Вижте коментарите по-долу за повече подробности.
    unsafe {
        // Ако последните два елемента не са в ред ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Прочетете последния елемент в променлива, разпределена в стека.
            // Ако следваща операция за сравнение panics, `hole` ще изпадне и автоматично ще запише елемента обратно в среза.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Преместете `i`-ия елемент с едно място надясно, като по този начин дупката се измества наляво.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` се изпуска и по този начин копира `tmp` в останалата дупка в `v`.
        }
    }
}

/// Частично сортира парче, като премества няколко неподходящи елемента.
///
/// Връща `true`, ако среза е сортиран в края.Тази функция е *O*(*n*) в най-лошия случай.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Максимален брой съседни двойки, които не са в ред, които ще бъдат изместени.
    const MAX_STEPS: usize = 5;
    // Ако среза е по-кратък от това, не премествайте никакви елементи.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // БЕЗОПАСНОСТ: Вече изрично направихме обвързаната проверка с `i < len`.
        // Цялото ни последващо индексиране е само в диапазона `0 <= index < len`
        unsafe {
            // Намерете следващата двойка съседни неподходящи елементи.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Готови ли сме?
        if i == len {
            return true;
        }

        // Не премествайте елементи на къси масиви, което има разходи за производителност.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Разменете намерената двойка елементи.Това ги поставя в правилен ред.
        v.swap(i - 1, i);

        // Преместете по-малкия елемент наляво.
        shift_tail(&mut v[..i], is_less);
        // Преместете по-големия елемент надясно.
        shift_head(&mut v[i..], is_less);
    }

    // Не успях да сортирам среза в ограничения брой стъпки.
    false
}

/// Сортира парче с помощта на сортиране при вмъкване, което е *O*(*n*^ 2) в най-лошия случай.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Сортира `v` с помощта на купчина, която гарантира *O*(*n*\*log(* n*)) в най-лошия случай.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Тази двоична купчина зачита инвариантния `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Деца от `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Изберете по-голямото дете.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Спрете, ако инвариантът е при `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Разменете `node` с по-голямото дете, преместете се една стъпка надолу и продължете да пресявате.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Изградете купчината за линейно време.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Изскачайте максимални елементи от купчината.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Разделя `v` на елементи, по-малки от `pivot`, последвани от елементи, по-големи или равни на `pivot`.
///
///
/// Връща броя на елементите, по-малки от `pivot`.
///
/// Разделянето се извършва блок по блок, за да се минимизират разходите за разклоняване.
/// Тази идея е представена в статията [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Брой елементи в типичен блок.
    const BLOCK: usize = 128;

    // Алгоритъмът за разделяне повтаря следните стъпки до завършване:
    //
    // 1. Проследете блок от лявата страна, за да идентифицирате елементи, по-големи или равни на ос.
    // 2. Проследете блок от дясната страна, за да идентифицирате елементи, по-малки от ос.
    // 3. Разменете идентифицираните елементи между лявата и дясната страна.
    //
    // Съхраняваме следните променливи за блок от елементи:
    //
    // 1. `block` - Брой елементи в блока.
    // 2. `start` - Стартирайте показалеца в масива `offsets`.
    // 3. `end` - Краен указател в масива `offsets`.
    // 4. `offset, Индекси на елементи, които не са в ред в рамките на блока.

    // Текущият блок от лявата страна (от `l` до `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Текущият блок от дясната страна (от `r.sub(block_r)` to `r`).
    // БЕЗОПАСНОСТ: В документацията за .add() специално се споменава, че `vec.as_ptr().add(vec.len())` е винаги в безопасност`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Когато получим VLA, опитайте да създадете един масив с дължина `min(v.len(), 2 * BLOCK) `
    // от два масива с фиксиран размер с дължина `BLOCK`.VLA могат да бъдат по-ефективни от кеша.

    // Връща броя на елементите между указателите `l` (inclusive) и `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Приключихме с разделянето блок по блок, когато `l` и `r` се приближат много.
        // След това правим някои корекции, за да разделим останалите елементи между тях.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Брой останали елементи (все още не в сравнение с ос).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Регулирайте размерите на блоковете, така че левият и десният блок да не се припокриват, но да бъдат перфектно подравнени, за да покрият цялата останала празнина.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Проследете елементите `block_l` от лявата страна.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // БЕЗОПАСНОСТ: Операциите по безопасност по-долу включват използването на `offset`.
                //         Според условията, изисквани от функцията, ние ги удовлетворяваме, защото:
                //         1. `offsets_l` е разпределен в стека и по този начин се счита за отделен разпределен обект.
                //         2. Функцията `is_less` връща `bool`.
                //            Предаването на `bool` никога няма да прелее `isize`.
                //         3. Гарантирали сме, че `block_l` ще бъде `<= BLOCK`.
                //            Плюс това, `end_l` първоначално беше настроен на началния указател на `offsets_`, който беше деклариран в стека.
                //            По този начин знаем, че дори и в най-лошия случай (всички извиквания на `is_less` връща false) ще имаме само 1 байт да премине края.
                //        Друга несигурна операция тук е пренасочването на `elem`.
                //        Въпреки това, `elem` първоначално е началният указател към среза, който винаги е валиден.
                unsafe {
                    // Сравнение без клонове.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Проследете елементите `block_r` от дясната страна.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // БЕЗОПАСНОСТ: Операциите по безопасност по-долу включват използването на `offset`.
                //         Според условията, изисквани от функцията, ние ги удовлетворяваме, защото:
                //         1. `offsets_r` е разпределен в стека и по този начин се счита за отделен разпределен обект.
                //         2. Функцията `is_less` връща `bool`.
                //            Предаването на `bool` никога няма да прелее `isize`.
                //         3. Гарантирали сме, че `block_r` ще бъде `<= BLOCK`.
                //            Плюс това, `end_r` първоначално беше настроен на началния указател на `offsets_`, който беше деклариран в стека.
                //            По този начин знаем, че дори в най-лошия случай (всички извиквания на `is_less` връщат истина) ще имаме най-много 1 байт да премине края.
                //        Друга несигурна операция тук е пренасочването на `elem`.
                //        Обаче `elem` първоначално беше `1 *sizeof(T)` след края и ние го декрементираме с `1* sizeof(T)`, преди да го осъществим.
                //        Освен това се твърди, че `block_r` е по-малък от `BLOCK` и следователно `elem` най-много ще сочи към началото на среза.
                unsafe {
                    // Сравнение без клонове.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Брой неизправни елементи, които да се сменят между лявата и дясната страна.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Вместо да разменяте по една двойка в даден момент, е по-ефективно да извършите циклична пермутация.
            // Това не е строго еквивалентно на размяна, но дава подобен резултат, използвайки по-малко операции с памет.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Всички неработещи елементи в левия блок бяха преместени.Преминаване към следващия блок.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Всички неподходящи елементи в десния блок бяха преместени.Преминаване към предишния блок.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Всичко, което остава сега, е най-много един блок (или вляво или вдясно) с неподходящи елементи, които трябва да бъдат преместени.
    // Такива останали елементи могат просто да бъдат изместени до края в рамките на техния блок.
    //

    if start_l < end_l {
        // Лявият блок остава.
        // Преместете останалите елементи в ред в крайната дясна част.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Остава десният блок.
        // Преместете останалите елементи, които не са в ред, в ляво.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Няма какво друго да правим, готови сме.
        width(v.as_mut_ptr(), l)
    }
}

/// Разделя `v` на елементи, по-малки от `v[pivot]`, последвани от елементи, по-големи или равни на `v[pivot]`.
///
///
/// Връща кортеж от:
///
/// 1. Брой елементи, по-малки от `v[pivot]`.
/// 2. Вярно, ако `v` вече е разделен.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Поставете шарнира в началото на среза.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Прочетете въртенето в променлива, разпределена в стека, за ефективност.
        // Ако следва операция за сравнение panics, въртенето автоматично ще бъде записано обратно в среза.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Намерете първата двойка неизправни елементи.
        let mut l = 0;
        let mut r = v.len();

        // БЕЗОПАСНОСТ: Несигурността по-долу включва индексиране на масив.
        // За първата: Вече правим проверка на границите тук с `l < r`.
        // За второто: Първоначално имаме `l == 0` и `r == v.len()` и проверихме, че `l < r` при всяка операция по индексиране.
        //                     Оттук знаем, че `r` трябва да бъде поне `r == l`, за който беше доказано, че е валиден от първия.
        unsafe {
            // Намерете първия елемент, по-голям или равен на ос.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Намерете последния елемент, по-малък от ос.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` излиза извън обхвата и записва въртенето (което е променлива, разпределена на стека) обратно в среза, където е бил първоначално.
        // Тази стъпка е от решаващо значение за осигуряване на безопасност!
        //
    };

    // Поставете опората между двата дяла.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Разделя `v` на елементи, равни на `v[pivot]`, последвани от елементи, по-големи от `v[pivot]`.
///
/// Връща броя на елементите, равен на ос.
/// Предполага се, че `v` не съдържа елементи, по-малки от ос.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Поставете шарнира в началото на среза.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Прочетете въртенето в променлива, разпределена в стека, за ефективност.
    // Ако следва операция за сравнение panics, въртенето автоматично ще бъде записано обратно в среза.
    // БЕЗОПАСНОСТ: Указателят тук е валиден, защото е получен от препратка към отрязък.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Сега разделете среза.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // БЕЗОПАСНОСТ: Несигурността по-долу включва индексиране на масив.
        // За първата: Вече правим проверка на границите тук с `l < r`.
        // За второто: Първоначално имаме `l == 0` и `r == v.len()` и проверихме, че `l < r` при всяка операция по индексиране.
        //                     Оттук знаем, че `r` трябва да бъде поне `r == l`, за който беше доказано, че е валиден от първия.
        unsafe {
            // Намерете първия елемент, по-голям от ос.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Намерете последния елемент, равен на ос.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Готови ли сме?
            if l >= r {
                break;
            }

            // Разменете намерената двойка неизправни елементи.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Намерихме `l` елементи, равни на ос.Добавете 1 към акаунта за самия пивот.
    l + 1

    // `_pivot_guard` излиза извън обхвата и записва въртенето (което е променлива, разпределена на стека) обратно в среза, където е бил първоначално.
    // Тази стъпка е от решаващо значение за осигуряване на безопасност!
}

/// Разпръсква някои елементи наоколо в опит да разчупи шаблони, които могат да причинят дисбалансирани дялове в бърза сортировка.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Генератор на псевдослучайни числа от хартията "Xorshift RNGs" на Джордж Марсаля.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Вземете произволни числа по модул на това число.
        // Номерът се вписва в `usize`, защото `len` не е по-голям от `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Някои пивотни кандидати ще бъдат в близост до този индекс.Нека ги рандомизираме.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Генерирайте произволно число по модул `len`.
            // Въпреки това, за да избегнем скъпи операции, първо го приемаме по модул с мощност от две, а след това намаляваме с `len`, докато се побере в диапазона `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` гарантирано е по-малко от `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Избира пивот в `v` и връща индекса и `true`, ако слайсът вероятно вече е сортиран.
///
/// Елементите в `v` може да бъдат пренаредени в процеса.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Минимална дължина за избор на метода медиана на медианите.
    // По-късите филийки използват простия метод медиана на три.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Максимален брой суапове, които могат да бъдат извършени с тази функция.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Три индекса, близо до които ще изберем опора.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Брои общия брой суапове, които предстои да извършим, докато сортираме индексите.
    let mut swaps = 0;

    if len >= 8 {
        // Разменя индекси, така че `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Разменя индекси, така че `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Намира медианата на `v[a - 1], v[a], v[a + 1]` и съхранява индекса в `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Намерете медиани в кварталите на `a`, `b` и `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Намерете медианата между `a`, `b` и `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Извършен е максималният брой суапове.
        // Шансовете е среза да се спуска или най-вече да се спуска, така че обръщането вероятно ще помогне за по-бързото му сортиране.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Сортира `v` рекурсивно.
///
/// Ако среза е имал предшественик в оригиналния масив, той е посочен като `pred`.
///
/// `limit` е броят на разрешените небалансирани дялове преди преминаване към `heapsort`.
/// Ако е нула, тази функция незабавно ще премине към сорт.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Резени до тази дължина се сортират чрез сортиране с вмъкване.
    const MAX_INSERTION: usize = 20;

    // Вярно, ако последното разделяне беше разумно балансирано.
    let mut was_balanced = true;
    // Вярно, ако последното разделяне не е разбъркало елементи (фрагментът вече е разделен).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Много кратки резени се сортират чрез сортиране с вмъкване.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Ако са направени твърде много лоши избори за въртене, просто се върнете към купчина, за да гарантирате най-лошия случай на `O(n * log(n))`.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Ако последното разделяне е небалансирано, опитайте да разчупите шаблони в среза, като разбъркате някои елементи наоколо.
        // Надяваме се, че този път ще изберем по-добра ос.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Изберете ос и опитайте да познаете дали среза вече е сортиран.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Ако последното разделяне е било прилично балансирано и не е разбърквало елементи и ако селектирането предвижда, че среза вероятно вече е сортиран ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Опитайте се да идентифицирате няколко неподходящи елемента и да ги преместите в правилни позиции.
            // Ако филийката в крайна сметка бъде напълно сортирана, приключихме.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Ако избраната ос е равна на предшественика, това е най-малкият елемент в среза.
        // Разделете среза на елементи, равни на и елементи, по-големи от ос.
        // Този случай обикновено се удря, когато разрезът съдържа много дублиращи се елементи.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Продължете да сортирате елементи, по-големи от ос.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Разделете среза.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Разделете среза на `left`, `pivot` и `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Върнете се в по-късата страна само, за да сведете до минимум общия брой рекурсивни повиквания и да изразходвате по-малко място в стека.
        // След това просто продължете с по-дългата страна (това е подобно на рекурсията на опашката).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Сортира `v`, използвайки бърза сортировка, побеждаваща модела, което е *O*(*n*\*log(* n*)) в най-лошия случай.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Сортирането няма смислено поведение при типове с нулев размер.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Ограничете броя на небалансираните дялове до `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // За филийки с тази дължина вероятно е по-бързо просто да ги сортирате.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Изберете ос
        let (pivot, _) = choose_pivot(v, is_less);

        // Ако избраната ос е равна на предшественика, това е най-малкият елемент в среза.
        // Разделете среза на елементи, равни на и елементи, по-големи от ос.
        // Този случай обикновено се удря, когато разрезът съдържа много дублиращи се елементи.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Ако сме преминали нашия индекс, значи сме добре.
                if mid > index {
                    return;
                }

                // В противен случай продължете да сортирате елементи, по-големи от ос.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Разделете среза на `left`, `pivot` и `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Ако mid==индекс, тогава сме готови, тъй като partition() гарантира, че всички елементи след mid са по-големи или равни на mid.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Сортирането няма смислено поведение при типове с нулев размер.Не правете нищо.
    } else if index == v.len() - 1 {
        // Намерете max елемент и го поставете в последната позиция на масива.
        // Тук можем да използваме `unwrap()`, защото знаем, че v не трябва да е празно.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Намерете min елемент и го поставете на първо място в масива.
        // Тук можем да използваме `unwrap()`, защото знаем, че v не трябва да е празно.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}