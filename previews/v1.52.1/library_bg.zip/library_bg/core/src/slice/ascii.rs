//! Операции на ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Проверява дали всички байтове в този отрязък са в диапазона ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Проверява дали две срезове не отговарят на регистъра на ASCII.
    ///
    /// Същото като `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, но без разпределяне и копиране на времеви периоди.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Преобразува този фрагмент в неговия ASCII главен еквивалент на място.
    ///
    /// ASCII буквите 'a' до 'z' се преобразуват в 'A' до 'Z', но буквите извън ASCII остават непроменени.
    ///
    /// За да върнете нова главна стойност, без да модифицирате съществуващата, използвайте [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Преобразува този фрагмент в неговия ASCII малък еквивалент на място.
    ///
    /// ASCII буквите 'A' до 'Z' се преобразуват в 'a' до 'z', но буквите извън ASCII остават непроменени.
    ///
    /// За да върнете нова малка буква, без да модифицирате съществуващата, използвайте [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Връща `true`, ако някой байт в думата `v` е nonascii (>=128).
/// Snarfed от `../str/mod.rs`, който прави нещо подобно за валидиране на utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Оптимизиран ASCII тест, който ще използва операции за използване на време вместо операции с байт в момент (когато е възможно).
///
/// Алгоритъмът, който използваме тук, е доста прост.Ако `s` е твърде кратък, ние просто проверяваме всеки байт и приключваме с него.В противен случай:
///
/// - Прочетете първата дума с неподравен товар.
/// - Подравнете показалеца, прочетете следващите думи до края с подравнени товари.
/// - Прочетете последния `usize` от `s` с ненатоварен товар.
///
/// Ако някой от тези натоварвания създаде нещо, за което `contains_nonascii` (above) връща вярно, тогава знаем, че отговорът е невярен.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Ако не можем да спечелим нищо от внедряването на дума, върнете се към скаларен цикъл.
    //
    // Правим това и за архитектури, където `size_of::<usize>()` не е достатъчно подравняване за `usize`, защото това е странен случай edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Винаги четем първата дума, която не е подравнена, което означава, че `align_offset` е
    // 0, бихме прочели същата стойност отново за подравненото четене.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // БЕЗОПАСНОСТ: Проверяваме `len < USIZE_SIZE` по-горе.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Проверихме това по-горе, донякъде неявно.
    // Имайте предвид, че `offset_to_aligned` е или `align_offset`, или `USIZE_SIZE`, и двете са изрично проверени по-горе.
    //
    debug_assert!(offset_to_aligned <= len);

    // БЕЗОПАСНОСТ: word_ptr е (правилно подравнен) pize за използване, който използваме за четене на
    // средна част от филийката.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` е байтовият индекс на `word_ptr`, използван за проверки в края на цикъла.
    let mut byte_pos = offset_to_aligned;

    // Проверка на параноята за подравняването, тъй като сме на път да направим куп несравнени товари.
    // На практика това би трябвало да е невъзможно с изключение на грешка в `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Прочетете следващите думи до последната подравнена дума, с изключение на последната изравнена дума сама по себе си, за да бъде направена при проверка на опашката по-късно, за да сте сигурни, че опашката винаги е най-много една `usize` за допълнително branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Проверете разумно, че четенето е в граници
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // И че нашите предположения за `byte_pos` са валидни.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // БЕЗОПАСНОСТ: Знаем, че `word_ptr` е правилно подравнен (поради
        // `align_offset`) и знаем, че имаме достатъчно байта между `word_ptr` и края
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // БЕЗОПАСНОСТ: Ние знаем, че `byte_pos <= len - USIZE_SIZE`, което означава, че
        // след този `add`, `word_ptr` ще бъде най-много от миналото.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Проверка на здравословното състояние, за да се уверите, че наистина е останал само един `usize`.
    // Това трябва да бъде гарантирано от нашето условие за цикъл.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // БЕЗОПАСНОСТ: Това разчита на `len >= USIZE_SIZE`, който проверяваме в началото.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}