//! Макроси, използвани от итератори на слайс.

// Inlining is_empty и len прави огромна разлика в производителността
macro_rules! is_empty {
    // Начинът, по който кодираме дължината на ZST итератор, това работи както за ZST, така и за не-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// За да се отървем от някои проверки за граници (вижте `position`), изчисляваме дължината по малко неочакван начин.
// (Тествано от `codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // понякога сме използвани в опасен блок

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Този _cannot_ използва `unchecked_sub`, тъй като зависим от обвиването, за да представим дължината на дългите итератори на ZST срезове.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Знаем, че `start <= end`, така че може да се справя по-добре от `offset_from`, който трябва да се раздава подписан.
            // Като зададем подходящи флагове тук, можем да кажем на LLVM това, което му помага да премахне проверките за граници.
            // БЕЗОПАСНОСТ: От типа инвариант, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Като също така казва на LLVM, че указателите са разделени с точно кратно на размера на типа, той може да оптимизира `len() == 0` до `start == end` вместо `(end - start) < size`.
            //
            // БЕЗОПАСНОСТ: По тип инвариант, указателите са подравнени така, че
            //         разстоянието между тях трябва да е кратно на размера на пуанта
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Споделената дефиниция на итераторите `Iter` и `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Връща първия елемент и премества началото на итератора напред с 1.
        // Подобрява значително производителността в сравнение с вградената функция.
        // Итераторът не трябва да е празен.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Връща последния елемент и премества края на итератора назад с 1.
        // Подобрява значително производителността в сравнение с вградената функция.
        // Итераторът не трябва да е празен.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Свива итератора, когато T е ZST, чрез преместване на края на итератора назад с `n`.
        // `n` не трябва да надвишава `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Помощна функция за създаване на фрагмент от итератора.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // БЕЗОПАСНОСТ: итераторът е създаден от парче с указател
                // `self.ptr` и дължина `len!(self)`.
                // Това гарантира, че са изпълнени всички предпоставки за `from_raw_parts`.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Помощна функция за преместване на началото на итератора напред от елементи `offset`, връщайки старото начало.
            //
            // Небезопасно, тъй като изместването не трябва да надвишава `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // БЕЗОПАСНОСТ: повикващият гарантира, че `offset` не надвишава `self.len()`,
                    // така че този нов указател е вътре в `self` и по този начин гарантира, че няма нула.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Помощна функция за преместване на края на итератора назад от елементи `offset`, връщайки новия край.
            //
            // Небезопасно, тъй като изместването не трябва да надвишава `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // БЕЗОПАСНОСТ: повикващият гарантира, че `offset` не надвишава `self.len()`,
                    // което гарантирано няма да препълни `isize`.
                    // Освен това полученият указател е в границите на `slice`, който отговаря на другите изисквания за `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // може да се реализира с филийки, но това избягва проверки за граници

                // БЕЗОПАСНОСТ: Обажданията на `assume` са безопасни от началния указател на среза
                // трябва да е ненулево, а отрязъците над не-ZST също трябва да имат ненулев краен указател.
                // Обаждането до `next_unchecked!` е безопасно, тъй като първо проверяваме дали итераторът е празен.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Този итератор вече е празен.
                    if mem::size_of::<T>() == 0 {
                        // Трябва да го направим по този начин, тъй като `ptr` може никога да не е 0, но `end` може да бъде (поради опаковане).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // БЕЗОПАСНОСТ: end не може да бъде 0, ако T не е ZST, защото ptr не е 0 и end>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // БЕЗОПАСНОСТ: Ние сме в граници.`post_inc_start` прави правилното нещо дори за ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Ние заместваме изпълнението по подразбиране, което използва `try_fold`, тъй като това просто изпълнение генерира по-малко LLVM IR и е по-бързо за компилиране.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Ние заместваме изпълнението по подразбиране, което използва `try_fold`, тъй като това просто изпълнение генерира по-малко LLVM IR и е по-бързо за компилиране.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Ние заместваме изпълнението по подразбиране, което използва `try_fold`, тъй като това просто изпълнение генерира по-малко LLVM IR и е по-бързо за компилиране.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Ние заместваме изпълнението по подразбиране, което използва `try_fold`, тъй като това просто изпълнение генерира по-малко LLVM IR и е по-бързо за компилиране.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Ние заместваме изпълнението по подразбиране, което използва `try_fold`, тъй като това просто изпълнение генерира по-малко LLVM IR и е по-бързо за компилиране.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Ние заместваме изпълнението по подразбиране, което използва `try_fold`, тъй като това просто изпълнение генерира по-малко LLVM IR и е по-бързо за компилиране.
            // Също така `assume` избягва проверка на граници.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // БЕЗОПАСНОСТ: гарантира се, че сме в граници от инварианта на цикъла:
                        // когато `i >= n`, `self.next()` връща `None` и цикълът се прекъсва.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Ние заместваме изпълнението по подразбиране, което използва `try_fold`, тъй като това просто изпълнение генерира по-малко LLVM IR и е по-бързо за компилиране.
            // Също така `assume` избягва проверка на граници.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // БЕЗОПАСНОСТ: `i` трябва да е по-ниска от `n`, тъй като започва от `n`
                        // и само намалява.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // БЕЗОПАСНОСТ: повикващият трябва да гарантира, че `i` е в границите на
                // основния фрагмент, така че `i` не може да препълни `isize` и върнатите препратки са гарантирани, че се отнасят до елемент от среза и по този начин се гарантира, че са валидни.
                //
                // Също така имайте предвид, че повикващият също така гарантира, че никога повече няма да бъдем извикани с един и същ индекс и че не се извикват други методи, които ще осъществяват достъп до този подраздел, така че е валидно връщаната препратка да бъде изменяема в случай на
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // може да се реализира с филийки, но това избягва проверки за граници

                // БЕЗОПАСНОСТ: `assume` повикванията са безопасни, тъй като началният указател на среза не трябва да е нулев,
                // и срезовете над не-ZST също трябва да имат ненулев краен указател.
                // Обаждането до `next_back_unchecked!` е безопасно, тъй като първо проверяваме дали итераторът е празен.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Този итератор вече е празен.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // БЕЗОПАСНОСТ: Ние сме в граници.`pre_dec_end` прави правилното нещо дори за ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}