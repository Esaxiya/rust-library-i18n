#![feature(no_core)]
#![no_core]

// Вижте rustc-std-workspace-core за това защо е необходим този crate.

// Преименувайте crate, за да избегнете конфликт с модула alloc в liballoc.
extern crate alloc as foo;

pub use foo::*;