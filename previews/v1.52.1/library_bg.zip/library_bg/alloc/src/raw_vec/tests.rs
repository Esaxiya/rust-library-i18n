use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Написването на тест за интеграция между разпределители на трети страни и `RawVec` е малко сложно, тъй като API на `RawVec` не излага грешни методи за разпределение, така че не можем да проверим какво се случва, когато разпределителят е изчерпан (освен откриването на panic)
    //
    //
    // Вместо това това само проверява дали методите `RawVec` минават поне през API на Allocator, когато резервират място за съхранение.
    //
    //
    //
    //
    //

    // Тъп разпределител, който консумира фиксирано количество гориво, преди опитите за разпределение да започнат да се провалят.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (причинява преразпределение, като по този начин се използват 50 + 150=200 единици гориво)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Първо, `reserve` разпределя като `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 е повече от двойно от 7, така че `reserve` трябва да работи като `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 е по-малко от половината от 12, така че `reserve` трябва да расте експоненциално.
        // По време на писането на този тест коефициентът на растеж е 2, така че новият капацитет е 24, но факторът на растеж на 1.5 също е в ред.
        //
        // Следователно `>= 18` в утвърждаване.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}