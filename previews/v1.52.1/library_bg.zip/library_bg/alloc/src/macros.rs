/// Създава [`Vec`], съдържащ аргументите.
///
/// `vec!` позволява `Vec`s да бъдат дефинирани със същия синтаксис като изразите на масива.
/// Има две форми на този макрос:
///
/// - Създайте [`Vec`], съдържащ даден списък с елементи:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Създайте [`Vec`] от даден елемент и размер:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Имайте предвид, че за разлика от изразите на масиви, този синтаксис поддържа всички елементи, които изпълняват [`Clone`] и броят на елементите не трябва да е константа.
///
/// Това ще използва `clone` за дублиране на израз, така че трябва да внимавате да го използвате с типове, които имат нестандартно изпълнение на `Clone`.
/// Например `vec![Rc::new(1);5] "ще създаде vector от пет препратки към една и съща стойност на цяло число, а не пет препратки, сочещи към независимо поставени в полето цели числа.
///
///
/// Също така имайте предвид, че `vec![expr; 0]` е разрешен и създава празен vector.
/// Това все пак ще оцени `expr` и веднага ще свали получената стойност, така че имайте предвид страничните ефекти.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): с cfg(test) присъщият метод `[T]::into_vec`, който се изисква за тази дефиниция на макрос, не е наличен.
// Вместо това използвайте функцията `slice::into_vec`, която е достъпна само с cfg(test) NB, вижте модула slice::hack в slice.rs за повече информация
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Създава `String`, използвайки интерполация на изрази по време на изпълнение.
///
/// Първият аргумент, който `format!` получава, е низ за формат.Това трябва да е литералов низ.Силата на форматиращия низ е в съдържащите се " {}`.
///
/// Допълнителни параметри, предадени на `format!`, заменят символите `{} в рамките на форматиращия низ в дадения ред, освен ако не се използват имена или позиционни параметри;вижте [`std::fmt`] за повече информация.
///
///
/// Често използвана за `format!` е конкатенация и интерполация на низове.
/// Същата конвенция се използва с макроси [`print!`] и [`write!`], в зависимост от предназначението на низа.
///
/// За да конвертирате единична стойност в низ, използвайте метода [`to_string`].Това ще използва [`Display`] форматиране Portrait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics, ако изпълнението на форматиране Portrait връща грешка.
/// Това показва неправилно изпълнение, тъй като `fmt::Write for String` никога не връща самата грешка.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Принудете AST възел до израз, за да подобрите диагностиката в позиция на шаблон.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}