//! Разпределението Prelude
//!
//! Целта на този модул е да облекчи вноса на често използвани елементи от `alloc` crate, като добави глобален импорт в горната част на модулите:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;