#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Съдържанието на новата памет е неинициализирано.
    Uninitialized,
    /// Новата памет е гарантирано нулирана.
    Zeroed,
}

/// Помощна програма на ниско ниво за по-ергономично разпределение, преразпределение и освобождаване на буфер памет в купчината, без да се налага да се притеснявате за всички ъглови случаи.
///
/// Този тип е отличен за изграждане на ваши собствени структури от данни като Vec и VecDeque.
/// В частност:
///
/// * Произвежда `Unique::dangling()` на типове с нулев размер.
/// * Произвежда `Unique::dangling()` на разпределения с нулева дължина.
/// * Избягва освобождаването на `Unique::dangling()`.
/// * Улавя всички препълвания при изчисления на капацитета (повишава ги до "capacity overflow" panics).
/// * Предпазва от 32-битови системи, разпределящи повече от isize::MAX байта.
/// * Предпазва от препълване на дължината ви.
/// * Призовава `handle_alloc_error` за грешни разпределения.
/// * Съдържа `ptr::Unique` и по този начин предоставя на потребителя всички свързани предимства.
/// * Използва излишъка, върнат от разпределителя, за да използва най-големия наличен капацитет.
///
/// Този тип по никакъв начин не проверява паметта, която управлява.При изпускане *ще* освободи паметта си, но *няма* да се опита да изпусне съдържанието си.
/// От потребителя на `RawVec` зависи да се справи с действителните неща,*съхранени* в `RawVec`.
///
/// Имайте предвид, че излишъкът от типове с нулев размер винаги е безкраен, така че `capacity()` винаги връща `usize::MAX`.
/// Това означава, че трябва да бъдете внимателни, когато задействате този тип с `Box<[T]>`, тъй като `capacity()` няма да даде дължината.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Това съществува, защото `#[unstable]` `const fn`s не трябва да отговарят на `min_const_fn` и затова те не могат да бъдат извикани и в`min_const_fn`s.
    ///
    /// Ако промените `RawVec<T>::new` или зависимости, моля, внимавайте да не въвеждате нищо, което наистина да нарушава `min_const_fn`.
    ///
    /// NOTE: Бихме могли да избегнем този хак и да проверим съответствието с някакъв атрибут `#[rustc_force_min_const_fn]`, който изисква съответствие с `min_const_fn`, но не е задължително да го извиквам в `stable(...) const fn`/потребителски код, който не позволява `foo`, когато `#[rustc_const_unstable(feature = "foo", issue = "01234")]` присъства.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Създава възможно най-големия `RawVec` (в системната купчина), без да разпределя.
    /// Ако `T` има положителен размер, това прави `RawVec` с капацитет `0`.
    /// Ако `T` е с нулев размер, тогава той прави `RawVec` с капацитет `usize::MAX`.
    /// Полезно за прилагане на забавено разпределение.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Създава `RawVec` (в системната купчина) с точно изискванията за капацитет и подравняване за `[T; capacity]`.
    /// Това е еквивалентно на повикване на `RawVec::new`, когато `capacity` е `0` или `T` е с нулев размер.
    /// Имайте предвид, че ако `T` е с нулев размер, това означава, че *няма* да получите `RawVec` със заявения капацитет.
    ///
    /// # Panics
    ///
    /// Panics, ако заявеният капацитет надвишава `isize::MAX` байта.
    ///
    /// # Aborts
    ///
    /// Аборти в OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Подобно на `with_capacity`, но гарантира, че буферът е нулиран.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Възстановява `RawVec` от показалеца и капацитета.
    ///
    /// # Safety
    ///
    /// `ptr` трябва да бъде разпределен (в системната купчина) и с дадения `capacity`.
    /// `capacity` не може да надвишава `isize::MAX` за големи типове.(само загриженост за 32-битовите системи).
    /// ZST vectors може да има капацитет до `usize::MAX`.
    /// Ако `ptr` и `capacity` идват от `RawVec`, това е гарантирано.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Малките Vecs са тъпи.Премини към:
    // - 8, ако размерът на елемента е 1, тъй като всеки разпределител на купчина вероятно ще закръгли заявка от по-малко от 8 байта до най-малко 8 байта.
    //
    // - 4, ако елементите са с умерен размер (<=1 KiB).
    // - 1 в противен случай, за да избегнете загубата на твърде много място за много кратки Vecs.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Подобно на `new`, но параметризиран при избора на разпределител за върнатия `RawVec`.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` означава "unallocated".типовете с нулев размер се игнорират.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Подобно на `with_capacity`, но параметризиран при избора на разпределител за върнатия `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Подобно на `with_capacity_zeroed`, но параметризиран при избора на разпределител за върнатия `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Преобразува `Box<[T]>` в `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Преобразува целия буфер в `Box<[MaybeUninit<T>]>` с посочения `len`.
    ///
    /// Имайте предвид, че това правилно ще възстанови всички промени в `cap`, които може да са били извършени.(За подробности вижте описанието на типа.)
    ///
    /// # Safety
    ///
    /// * `len` трябва да е по-голям или равен на последния заявен капацитет, и
    /// * `len` трябва да бъде по-малко или равно на `self.capacity()`.
    ///
    /// Имайте предвид, че заявеният капацитет и `self.capacity()` могат да се различават, тъй като разпределителят може да преразпредели и върне по-голям блок памет от поискания.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Проверете здравословността на половината от изискването за безопасност (не можем да проверим другата половина).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Тук избягваме `unwrap_or_else`, защото той задушава количеството генериран LLVM IR.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Възстановява `RawVec` от указател, капацитет и разпределител.
    ///
    /// # Safety
    ///
    /// `ptr` трябва да бъде разпределен (чрез дадения разпределител `alloc`) и с дадения `capacity`.
    /// `capacity` не може да надвишава `isize::MAX` за големи типове.
    /// (само загриженост за 32-битовите системи).
    /// ZST vectors може да има капацитет до `usize::MAX`.
    /// Ако `ptr` и `capacity` идват от `RawVec`, създаден чрез `alloc`, това е гарантирано.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Получава суров указател към началото на разпределението.
    /// Имайте предвид, че това е `Unique::dangling()`, ако `capacity == 0` или `T` е с нулев размер.
    /// В първия случай трябва да внимавате.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Получава капацитета на разпределението.
    ///
    /// Това винаги ще бъде `usize::MAX`, ако `T` е с нулев размер.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Връща споделена препратка към разпределителя, подкрепящ този `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Имаме разпределена част от паметта, така че можем да заобиколим проверките по време на изпълнение, за да получим текущото си оформление.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Гарантира, че буферът съдържа поне достатъчно място, за да побере `len + additional` елементи.
    /// Ако все още няма достатъчно капацитет, ще преразпредели достатъчно място плюс удобно свободно място, за да получи амортизирано поведение *O*(1).
    ///
    /// Ще ограничи това поведение, ако ненужно би се причинило до panic.
    ///
    /// Ако `len` надвишава `self.capacity()`, това може да не успее действително да разпредели исканото пространство.
    /// Това всъщност не е опасно, но опасният код *, който пишете, който разчита на поведението на тази функция, може да се счупи.
    ///
    /// Това е идеално за изпълнение на групова операция като `extend`.
    ///
    /// # Panics
    ///
    /// Panics, ако новият капацитет надвишава `isize::MAX` байта.
    ///
    /// # Aborts
    ///
    /// Аборти в OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // резервът би прекъснал или изпаднал в паника, ако обективът надвиши `isize::MAX`, така че това е безопасно да се направи отметнато сега.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Същото като `reserve`, но се връща при грешки, вместо да се паникьосва или абортира.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Гарантира, че буферът съдържа поне достатъчно място, за да побере `len + additional` елементи.
    /// Ако все още не е, ще преразпредели минимално възможното необходимо количество памет.
    /// Като цяло това ще бъде точно необходимото количество памет, но по принцип разпределителят е свободен да върне повече, отколкото поискахме.
    ///
    ///
    /// Ако `len` надвишава `self.capacity()`, това може да не успее действително да разпредели исканото пространство.
    /// Това всъщност не е опасно, но опасният код *, който пишете, който разчита на поведението на тази функция, може да се счупи.
    ///
    /// # Panics
    ///
    /// Panics, ако новият капацитет надвишава `isize::MAX` байта.
    ///
    /// # Aborts
    ///
    /// Аборти в OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Същото като `reserve_exact`, но се връща при грешки, вместо да се паникьосва или абортира.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Свива разпределението до определената сума.
    /// Ако дадената сума е 0, всъщност напълно освобождава.
    ///
    /// # Panics
    ///
    /// Panics, ако даденото количество е *по-голямо* от текущия капацитет.
    ///
    /// # Aborts
    ///
    /// Аборти в OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Връща, ако буферът трябва да нарасне, за да изпълни необходимия допълнителен капацитет.
    /// Използва се главно, за да направи вградените резервни обаждания възможни без вграждане на `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Този метод обикновено се екземпляри много пъти.Затова искаме да бъде възможно най-малък, за да се подобри времето за компилиране.
    // Но ние също така искаме колкото се може повече от съдържанието му да бъде статично изчислимо, за да направим генерирания код да работи по-бързо.
    // Следователно този метод е внимателно написан, така че целият код, който зависи от `T`, да е в него, докато колкото се може повече от кода, който не зависи от `T`, е във функции, които не са общи за `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Това се осигурява от призоваващия контекст.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Тъй като връщаме капацитет от `usize::MAX`, когато `elem_size` е
            // 0, стигането до тук непременно означава, че `RawVec` е препълнен.
            return Err(CapacityOverflow);
        }

        // За съжаление нищо не можем да направим за тези проверки.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Това гарантира експоненциален растеж.
        // Удвояването не може да прелее, защото `cap <= isize::MAX` и типът `cap` е `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` не е родово в сравнение с `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Ограниченията за този метод са почти същите като тези за `grow_amortized`, но този метод обикновено се създава по-рядко, така че е по-малко критичен.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Тъй като връщаме капацитет от `usize::MAX`, когато размерът на типа е
            // 0, стигането до тук непременно означава, че `RawVec` е препълнен.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` не е родово в сравнение с `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Тази функция е извън `RawVec`, за да минимизира времето за компилиране.Вижте коментара по-горе `RawVec::grow_amortized` за подробности.
// (Параметърът `A` не е значителен, тъй като броят на различните типове `A`, наблюдавани на практика, е много по-малък от броя на типовете `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Проверете за грешка тук, за да минимизирате размера на `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Разпределителят проверява за равенство на подравняването
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Освобождава паметта, собственост на `RawVec`*, без* да се опитва да изпусне съдържанието му.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Централна функция за обработка на резервни грешки.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Трябва да гарантираме следното:
// * Ние никога не разпределяме обекти с размер на байт `> isize::MAX`.
// * Ние не преливаме `usize::MAX` и всъщност разпределяме твърде малко.
//
// На 64-битово просто трябва да проверим за препълване, тъй като опитът за разпределяне на байтове `> isize::MAX` със сигурност ще се провали.
// На 32-битови и 16-битови трябва да добавим допълнителен предпазител за това, в случай че работим на платформа, която може да използва всичките 4 GB в потребителско пространство, например PAE или x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Една централна функция, отговорна за препълването на капацитета за отчитане.
// Това ще гарантира, че генерирането на код, свързано с тези panics, е минимално, тъй като има само едно местоположение, което panics, а не куп в целия модул.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}