//! Кодиран в UTF-8 низ, който може да се отглежда.
//!
//! Този модул съдържа типа [`String`], [`ToString`] Portrait за конвертиране в низове и няколко типа грешки, които могат да възникнат в резултат на работа с [`String`] s.
//!
//!
//! # Examples
//!
//! Има няколко начина за създаване на нов [`String`] от низов литерал:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Можете да създадете нов [`String`] от съществуващ, като обедините с
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Ако имате vector с валидни байтове UTF-8, можете да направите [`String`] от него.Можете да направите и обратното.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Знаем, че тези байтове са валидни, затова ще използваме `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// Кодиран в UTF-8 низ, който може да се отглежда.
///
/// Типът `String` е най-често срещаният тип низ, който притежава собствеността върху съдържанието на низа.Той е в тясна връзка със заимствания си колега, примитивния [`str`].
///
/// # Examples
///
/// Можете да създадете `String` от [a literal string][`str`] с [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Можете да добавите [`char`] към `String` с метода [`push`] и да добавите [`&str`] с метода [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Ако имате vector от UTF-8 байта, можете да създадете `String` от него с метода [`from_utf8`]:
///
/// ```
/// // някои байтове, в vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Знаем, че тези байтове са валидни, затова ще използваме `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `String`s са винаги валидни UTF-8.Това има няколко последици, първото от които е, че ако имате нужда от низ, който не е UTF-8, помислете за [`OsString`].Подобно е, но без ограничението UTF-8.Второто внушение е, че не можете да индексирате в `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Индексирането е предназначено да бъде операция с постоянно време, но кодирането UTF-8 не ни позволява да правим това.Освен това не е ясно какви неща трябва да върне индексът: байт, кодова точка или графемен клъстер.
/// Методите [`bytes`] и [`chars`] връщат итератори съответно през първите два.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `String`s Implement [`Deref`] `<Target=str>`, и така наследява всички методи на [`str`].В допълнение, това означава, че можете да предадете `String` на функция, която приема [`&str`], като използвате амперсанд (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Това ще създаде [`&str`] от `String` и ще го предаде. Това преобразуване е много евтино и така обикновено функциите ще приемат [`&str`] s като аргументи, освен ако не се нуждаят от `String` по някаква конкретна причина.
///
/// В определени случаи Rust няма достатъчно информация, за да извърши това преобразуване, известно като принуда [`Deref`].В следващия пример низ отрязък [`&'a str`][`&str`] реализира Portrait `TraitExample`, а функцията `example_func` приема всичко, което реализира Portrait.
/// В този случай Rust ще трябва да направи две неявни преобразувания, което Rust няма средства да направи.
/// Поради тази причина следващият пример няма да се компилира.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Вместо това има две възможности.Първият би бил да се смени реда `example_func(&example_string);` на `example_func(example_string.as_str());`, като се използва методът [`as_str()`], за да се извлече изрично фрагментът от низа, съдържащ низа.
/// Вторият начин променя `example_func(&example_string);` на `example_func(&*example_string);`.
/// В този случай пренасочваме `String` към [`str`][`&str`], след което връщаме [`str`][`&str`] обратно към [`&str`].
/// Вторият начин е по-идиоматичен, но и двамата работят, за да направят преобразуването изрично, вместо да разчитат на неявното преобразуване.
///
/// # Representation
///
/// `String` се състои от три компонента: указател към някои байтове, дължина и капацитет.Указателят сочи към вътрешен буфер, който `String` използва за съхраняване на своите данни.Дължината е броят на байтовете, съхранявани в момента в буфера, а капацитетът е размерът на буфера в байтове.
///
/// Като такава, дължината винаги ще бъде по-малка или равна на капацитета.
///
/// Този буфер винаги се съхранява в купчината.
///
/// Можете да ги разгледате с методите [`as_ptr`], [`len`] и [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Актуализирайте това, когато vec_into_raw_parts се стабилизира.
/// // Предотвратете автоматичното изпускане на данните на String
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // историята има деветнадесет байта
/// assert_eq!(19, len);
///
/// // Можем да възстановим String от ptr, len и капацитет.
/// // Всичко това е опасно, защото ние носим отговорност да гарантираме, че компонентите са валидни:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Ако `String` има достатъчен капацитет, добавянето на елементи към него няма да бъде преразпределено.Например, помислете за тази програма:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Това ще изведе следното:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Първоначално изобщо нямаме разпределена памет, но докато се добавяме към низа, той увеличава капацитета си по подходящ начин.Ако вместо това използваме метода [`with_capacity`], за да разпределим първоначално правилния капацитет:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// В крайна сметка получаваме различен изход:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Тук няма нужда да отделяте повече памет вътре в цикъла.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Възможна стойност на грешка при конвертиране на `String` от UTF-8 байт vector.
///
/// Този тип е типът грешка за метода [`from_utf8`] на [`String`].
/// Той е проектиран по такъв начин, че внимателно да се избегнат преразпределения: методът [`into_bytes`] ще върне байта vector, който е бил използван в опита за преобразуване.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Типът [`Utf8Error`], предоставен от [`std::str`], представлява грешка, която може да възникне при преобразуване на парче [`u8`] s в [`&str`].
/// В този смисъл това е аналог на `FromUtf8Error` и можете да го получите от `FromUtf8Error` чрез метода [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Основна употреба:
///
/// ```
/// // някои невалидни байтове в vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Възможна стойност на грешка при преобразуване на `String` от байтов фрагмент UTF-16.
///
/// Този тип е типът грешка за метода [`from_utf16`] на [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Основна употреба:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Създава нов празен `String`.
    ///
    /// Като се има предвид, че `String` е празен, това няма да разпредели начален буфер.Въпреки че това означава, че тази първоначална операция е много евтина, тя може да доведе до прекомерно разпределение по-късно, когато добавите данни.
    ///
    /// Ако имате представа колко данни ще съдържа `String`, помислете за метода [`with_capacity`], за да предотвратите прекомерно преразпределение.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Създава нов празен `String` с определен капацитет.
    ///
    /// `String`s имат вътрешен буфер за съхранение на техните данни.
    /// Капацитетът е дължината на този буфер и може да бъде заявен с метода [`capacity`].
    /// Този метод създава празен `String`, но такъв с начален буфер, който може да побере `capacity` байта.
    /// Това е полезно, когато може да добавяте куп данни към `String`, намалявайки броя на преразпределенията, които трябва да направи.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Ако даденият капацитет е `0`, няма да се извърши разпределение и този метод е идентичен с метода [`new`].
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // String не съдържа символи, въпреки че има капацитет за повече
    /// assert_eq!(s.len(), 0);
    ///
    /// // Всичко това се прави без преразпределение ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... но това може да направи преразпределението на низа
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): с cfg(test) присъщият метод `[T]::to_vec`, който се изисква за дефиницията на този метод, не е наличен.
    // Тъй като ние не се нуждаем от този метод за целите на тестването, просто ще го заглуша. NB. Вижте модула slice::hack в slice.rs за повече информация
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Преобразува vector байтове в `String`.
    ///
    /// Низ ([`String`]) е направен от байтове ([`u8`]), а vector от байтове ([`Vec<u8>`]) е направен от байтове, така че тази функция преобразува между двете.
    /// Не всички байтови срезове са валидни `String`s, обаче: `String` изисква да е валиден UTF-8.
    /// `from_utf8()` проверява дали байтовете са валидни UTF-8 и след това извършва преобразуването.
    ///
    /// Ако сте сигурни, че байтовият фрагмент е валиден UTF-8 и не искате да поемате допълнителни разходи за проверката на валидността, има опасна версия на тази функция, [`from_utf8_unchecked`], която има същото поведение, но пропуска проверката.
    ///
    ///
    /// Този метод ще се погрижи да не копира vector, за по-голяма ефективност.
    ///
    /// Ако имате нужда от [`&str`] вместо `String`, помислете за [`str::from_utf8`].
    ///
    /// Обратното на този метод е [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Връща [`Err`], ако фрагментът не е UTF-8 с описание защо предоставените байтове не са UTF-8.Включен е и vector, в който сте се преместили.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// // някои байтове, в vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Знаем, че тези байтове са валидни, затова ще използваме `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Неправилни байтове:
    ///
    /// ```
    /// // някои невалидни байтове в vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Вижте документите за [`FromUtf8Error`] за повече подробности за това какво можете да направите с тази грешка.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Преобразува парче байтове в низ, включително невалидни знаци.
    ///
    /// Низовете са направени от байтове ([`u8`]), а част от байтове ([`&[u8]`][byteslice]) е направена от байтове, така че тази функция се преобразува между двете.Не всички байтови срезове са валидни низове, но: низовете трябва да са валидни UTF-8.
    /// По време на това преобразуване `from_utf8_lossy()` ще замени всички невалидни последователности на UTF-8 с [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], което изглежда така:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Ако сте сигурни, че байтовият фрагмент е валиден UTF-8 и не искате да поемате режийни разходи за преобразуването, има опасна версия на тази функция, [`from_utf8_unchecked`], която има същото поведение, но пропуска проверките.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Тази функция връща [`Cow<'a, str>`].Ако нашият байтов фрагмент е невалиден UTF-8, тогава трябва да вмъкнем заместващите символи, които ще променят размера на низа и следователно ще изискват `String`.
    /// Но ако вече е валиден UTF-8, нямаме нужда от ново разпределение.
    /// Този тип връщане ни позволява да обработваме и двата случая.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// // някои байтове, в vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Неправилни байтове:
    ///
    /// ```
    /// // някои невалидни байтове
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Декодирайте кодиран с UTF-16 vector `v` в `String`, връщайки [`Err`], ако `v` съдържа невалидни данни.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Това не се прави чрез collect: : <Result<_, _>> () поради съображения за ефективност.
        // FIXME: функцията може да бъде опростена отново, когато #48994 е затворен.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Декодирайте кодиран с UTF-16 фрагмент `v` в `String`, замествайки невалидни данни с [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// За разлика от [`from_utf8_lossy`], който връща [`Cow<'a, str>`], `from_utf16_lossy` връща `String`, тъй като преобразуването UTF-16 в UTF-8 изисква разпределение на паметта.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Разлага `String` на неговите сурови компоненти.
    ///
    /// Връща суровия указател към основните данни, дължината на низа (в байтове) и разпределения капацитет на данните (в байтове).
    /// Това са същите аргументи в същия ред като аргументите на [`from_raw_parts`].
    ///
    /// След извикване на тази функция, повикващият е отговорен за паметта, управлявана преди от `String`.
    /// Единственият начин да направите това е да преобразувате суровия указател, дължина и капацитет обратно в `String` с функцията [`from_raw_parts`], позволявайки на деструктора да извърши почистването.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Създава нов `String` от дължина, капацитет и показалец.
    ///
    /// # Safety
    ///
    /// Това е крайно опасно, поради броя на инвариантите, които не са проверени:
    ///
    /// * Паметта в `buf` трябва да е била предварително разпределена от същия разпределител, който използва стандартната библиотека, с необходимо подравняване точно 1.
    /// * `length` трябва да бъде по-малко или равно на `capacity`.
    /// * `capacity` трябва да е правилната стойност.
    /// * Първите `length` байта в `buf` трябва да са валидни UTF-8.
    ///
    /// Нарушаването им може да доведе до проблеми като повреждане на вътрешните структури от данни на разпределителя.
    ///
    /// Собствеността на `buf` се прехвърля ефективно на `String`, който след това може да освободи, преразпредели или промени съдържанието на паметта, посочено от указателя по желание.
    /// Уверете се, че нищо друго не използва указателя след извикване на тази функция.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Актуализирайте това, когато vec_into_raw_parts се стабилизира.
    ///     // Предотвратете автоматичното изпускане на данните на String
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Преобразува vector байтове в `String`, без да проверява дали низът съдържа валиден UTF-8.
    ///
    /// Вижте безопасната версия, [`from_utf8`], за повече подробности.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Тази функция е опасна, тъй като не проверява дали байтовете, подадени към нея, са валидни UTF-8.
    /// Ако това ограничение бъде нарушено, това може да доведе до проблеми с безопасността на паметта при потребителите на future на `String`, тъй като останалата част от стандартната библиотека приема, че `String`s са валидни UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// // някои байтове, в vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Преобразува `String` в байт vector.
    ///
    /// Това консумира `String`, така че не е необходимо да копираме съдържанието му.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Извлича фрагмент от низ, съдържащ целия `String`.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Преобразува `String` в изменяем низ отрязък.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Добавя даден низ отрязък в края на този `String`.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Връща капацитета на този "низ" в байтове.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Гарантира, че капацитетът на този " низ` е поне `additional` байта по-голям от дължината му.
    ///
    /// Капацитетът може да бъде увеличен с повече от `additional` байта, ако избере, за да предотврати чести преразпределения.
    ///
    ///
    /// Ако не искате това поведение на "at least", вижте метода [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics, ако новият капацитет препълни [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Това може всъщност да не увеличи капацитета:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s вече има дължина 2 и капацитет 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Тъй като вече имаме допълнителни 8 капацитета, извиквайки това ...
    /// s.reserve(8);
    ///
    /// // ... всъщност не се увеличава.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Гарантира, че капацитетът на този " низ` е `additional` байта по-голям от дължината му.
    ///
    /// Помислете за използването на метода [`reserve`], освен ако не знаете абсолютно по-добре от разпределителя.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics, ако новият капацитет препълни `usize`.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Това може всъщност да не увеличи капацитета:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s вече има дължина 2 и капацитет 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Тъй като вече имаме допълнителни 8 капацитета, извиквайки това ...
    /// s.reserve_exact(8);
    ///
    /// // ... всъщност не се увеличава.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Опитва се да запази капацитет за поне `additional` повече елементи, които да бъдат вмъкнати в дадения `String`.
    /// Колекцията може да запази повече място, за да се избегнат чести преразпределения.
    /// След извикване на `reserve`, капацитетът ще бъде по-голям или равен на `self.len() + additional`.
    /// Не прави нищо, ако капацитетът вече е достатъчен.
    ///
    /// # Errors
    ///
    /// Ако капацитетът препълни или разпределителят съобщи за повреда, се връща грешка.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Предварително запазете паметта, излизайки, ако не можем
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Сега знаем, че това не може да се случи в средата на нашата сложна работа
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Опитва се да запази минималния капацитет за точно `additional` повече елементи, които да бъдат вмъкнати в дадения `String`.
    ///
    /// След извикване на `reserve_exact`, капацитетът ще бъде по-голям или равен на `self.len() + additional`.
    /// Не прави нищо, ако капацитетът вече е достатъчен.
    ///
    /// Обърнете внимание, че разпределителят може да даде на колекцията повече място, отколкото изисква.
    /// Следователно не може да се разчита, че капацитетът е точно минимален.
    /// Предпочитайте `reserve`, ако се очакват вмъквания на future.
    ///
    /// # Errors
    ///
    /// Ако капацитетът препълни или разпределителят съобщи за повреда, се връща грешка.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Предварително запазете паметта, излизайки, ако не можем
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Сега знаем, че това не може да се случи в средата на нашата сложна работа
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Свива капацитета на този `String`, за да съответства на дължината му.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Свива капацитета на този `String` с долна граница.
    ///
    /// Капацитетът ще остане поне толкова голям, колкото дължината и доставената стойност.
    ///
    ///
    /// Ако текущият капацитет е по-малък от долната граница, това е не-операция.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Добавя дадения [`char`] към края на този `String`.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Връща байтов фрагмент от съдържанието на този "низ".
    ///
    /// Обратното на този метод е [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Съкращава този `String` до определената дължина.
    ///
    /// Ако `new_len` е по-голяма от текущата дължина на низа, това няма ефект.
    ///
    ///
    /// Имайте предвид, че този метод няма ефект върху разпределения капацитет на низа
    ///
    /// # Panics
    ///
    /// Panics, ако `new_len` не лежи на граница на [`char`].
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Премахва последния знак от буфера на низа и го връща.
    ///
    /// Връща [`None`], ако този `String` е празен.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Премахва [`char`] от този `String` в байтова позиция и го връща.
    ///
    /// Това е операция *O*(*n*), тъй като изисква копиране на всеки елемент в буфера.
    ///
    /// # Panics
    ///
    /// Panics, ако `idx` е по-голяма или равна на дължината на "String" или ако не лежи на граница на [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Премахнете всички съвпадения на модел `pat` в `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Съвпаденията ще бъдат открити и премахнати итеративно, така че в случаите, когато шаблоните се припокриват, ще бъде премахнат само първият модел:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // БЕЗОПАСНОСТ: начало и край ще бъдат на байтови граници utf8 за
        // документите на Търсача
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Задържа само символите, посочени от предиката.
    ///
    /// С други думи, премахнете всички символи `c`, така че `f(c)` връща `false`.
    /// Този метод работи на място, като посещава всеки знак точно веднъж в първоначалния ред и запазва реда на запазените символи.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Точният ред може да бъде полезен за проследяване на външно състояние, като индекс.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Насочете idx към следващия знак
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Вмъква знак в този `String` на байтова позиция.
    ///
    /// Това е операция *O*(*n*), тъй като изисква копиране на всеки елемент в буфера.
    ///
    /// # Panics
    ///
    /// Panics, ако `idx` е по-голяма от дължината на "String" или ако не лежи на граница на [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Вмъква срезов низ в този `String` на байтова позиция.
    ///
    /// Това е операция *O*(*n*), тъй като изисква копиране на всеки елемент в буфера.
    ///
    /// # Panics
    ///
    /// Panics, ако `idx` е по-голяма от дължината на "String" или ако не лежи на граница на [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Връща изменяема препратка към съдържанието на този `String`.
    ///
    /// # Safety
    ///
    /// Тази функция е опасна, тъй като не проверява дали байтовете, подадени към нея, са валидни UTF-8.
    /// Ако това ограничение бъде нарушено, това може да доведе до проблеми с безопасността на паметта при потребителите на future на `String`, тъй като останалата част от стандартната библиотека приема, че `String`s са валидни UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Връща дължината на този `String` в байтове, а не [`char`] или графеми.
    /// С други думи, може да не е това, което човек смята за дължината на струната.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Връща `true`, ако този `String` има дължина нула, а `false`-в противен случай.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Разделя низа на две при дадения индекс на байта.
    ///
    /// Връща новоразпределен `String`.
    /// `self` съдържа байтове `[0, at)`, а върнатият `String` съдържа байтове `[at, len)`.
    /// `at` трябва да е на границата на кодова точка UTF-8.
    ///
    /// Имайте предвид, че капацитетът на `self` не се променя.
    ///
    /// # Panics
    ///
    /// Panics, ако `at` не е на граница на кодова точка `UTF-8` или ако е извън последната кодова точка на низа.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Съкращава този `String`, като премахва цялото съдържание.
    ///
    /// Въпреки че това означава, че `String` ще има дължина нула, той не докосва капацитета си.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Създава източващ итератор, който премахва посочения диапазон в `String` и дава премахнатия `chars`.
    ///
    ///
    /// Note: Обхватът на елементите се премахва, дори ако итераторът не се консумира до края.
    ///
    /// # Panics
    ///
    /// Panics, ако началната или крайната точка не се намират на граница на [`char`] или ако са извън границите.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Премахнете диапазона, докато β от низа
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Пълен диапазон изчиства низа
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Безопасност на паметта
        //
        // Версията String на Drain няма проблеми с безопасността на паметта на версията vector.
        // Данните са само обикновени байтове.
        // Тъй като премахването на диапазона се случва в Drop, ако итераторът Drain изтече, премахването няма да се случи.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Извадете две едновременни заеми.
        // Низът &mut няма да бъде достъпен, докато итерацията не приключи, в Drop.
        let self_ptr = self as *mut _;
        // БЕЗОПАСНОСТ: `slice::range` и `is_char_boundary` правят съответните проверки на границите.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Премахва посочения диапазон в низа и го заменя с дадения низ.
    /// Даденият низ не трябва да бъде със същата дължина като диапазона.
    ///
    /// # Panics
    ///
    /// Panics, ако началната или крайната точка не се намират на граница на [`char`] или ако са извън границите.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Заменете диапазона нагоре, докато β от низа
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Безопасност на паметта
        //
        // Replace_range няма проблеми с безопасността на паметта на vector Splice.
        // на версията vector.Данните са само обикновени байтове.

        // ПРЕДУПРЕЖДЕНИЕ: Включването на тази променлива би било несъстоятелно (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // ПРЕДУПРЕЖДЕНИЕ: Включването на тази променлива би било несъстоятелно (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Използването на `range` отново би било несъстоятелно (#81138) Предполагаме, че границите, отчетени от `range`, остават същите, но състезателното изпълнение може да се промени между обажданията
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Преобразува този `String` в [`Box`]`<`[`str`] `>`.
    ///
    /// Това ще намали излишния капацитет.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Връща фрагмент от [`u8`] байта, които са се опитали да конвертират в `String`.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// // някои невалидни байтове в vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Връща байтовете, които са се опитали да конвертират в `String`.
    ///
    /// Този метод е конструиран внимателно, за да се избегне разпределението.
    /// Той ще погълне грешката, измествайки байтовете, така че не е необходимо да се прави копие на байтовете.
    ///
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// // някои невалидни байтове в vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Вземете `Utf8Error`, за да получите повече подробности за неуспешната конверсия.
    ///
    /// Типът [`Utf8Error`], предоставен от [`std::str`], представлява грешка, която може да възникне при преобразуване на парче [`u8`] s в [`&str`].
    /// В този смисъл това е аналог на `FromUtf8Error`.
    /// Вижте документацията му за повече подробности относно използването му.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// // някои невалидни байтове в vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // първият байт е невалиден тук
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Тъй като се итерираме върху `String`s, можем да избегнем поне едно разпределение, като вземем първия низ от итератора и добавим към него всички следващи низове.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Тъй като итерираме за CoWs, можем да избегнем (potentially) поне едно разпределение, като получим първия елемент и добавим към него всички следващи елементи.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Удобен impl, който делегира на impl за `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Създава празен `String`.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Прилага оператора `+` за обединяване на два низа.
///
/// Това консумира `String` от лявата страна и използва повторно неговия буфер (при необходимост го увеличава).
/// Това се прави, за да се избегне разпределянето на нов `String` и копирането на цялото съдържание при всяка операция, което би довело до *O*(*n*^ 2) време на работа при изграждане на *n*-байтов низ чрез повторно обединяване.
///
///
/// Низът от дясната страна е заимстван само;съдържанието му се копира във върнатия `String`.
///
/// # Examples
///
/// Обединяването на две " String` взема първата по стойност и заема втората:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` е преместен и вече не може да се използва тук.
/// ```
///
/// Ако искате да продължите да използвате първия `String`, можете да го клонирате и да го добавите към клонинга:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` все още важи тук.
/// ```
///
/// Обединяването на `&str` срезове може да се извърши чрез преобразуване на първия в `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Прилага оператор `+=` за добавяне към `String`.
///
/// Това има същото поведение като метода [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Типов псевдоним за [`Infallible`].
///
/// Този псевдоним съществува за обратна съвместимост и в крайна сметка може да бъде остарял.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// Portrait за преобразуване на стойност в `String`.
///
/// Този Portrait се прилага автоматично за всеки тип, който прилага [`Display`] Portrait.
/// Като такъв, `ToString` не трябва да се прилага директно:
/// [`Display`] трябва да бъде внедрен вместо това и получавате внедряването на `ToString` безплатно.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Преобразува дадената стойност в `String`.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// При това изпълнение методът `to_string` panics, ако изпълнението `Display` връща грешка.
/// Това показва неправилно изпълнение на `Display`, тъй като `fmt::Write for String` никога не връща самата грешка.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Обща насока е да не се вграждат родови функции.
    // Премахването на `#[inline]` от този метод обаче води до пренебрежими регресии.
    // Вижте <https://github.com/rust-lang/rust/pull/74852>, последният опит за премахване.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Преобразува `&mut str` в `String`.
    ///
    /// Резултатът се разпределя в купчината.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: тест дърпа в libstd, което причинява грешки тук
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Преобразува дадения в кутия `str` парче в `String`.
    /// Забележително е, че `str` парче е притежание.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Преобразува дадения `String` в кутия `str` парче, което е собственост.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Преобразува фрагмент от низ в заемна версия.
    /// Не се извършва разпределение на купчина и низът не се копира.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Преобразува низ в притежаван вариант.
    /// Не се извършва разпределение на купчина и низът не се копира.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Преобразува препратка към String във вариант за заем.
    /// Не се извършва разпределение на купчина и низът не се копира.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Преобразува дадения `String` в vector `Vec`, който съдържа стойности от тип `u8`.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Итератор за източване за `String`.
///
/// Тази структура е създадена по метода [`drain`] на [`String`].
/// Вижте документацията му за повече.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Ще бъде използван като&'a mutt String в деструктора
    string: *mut String,
    /// Начало на част за премахване
    start: usize,
    /// Краят на частта за премахване
    end: usize,
    /// Текущият оставащ диапазон за премахване
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Използвайте Vec::drain.
            // "Reaffirm" границите проверява, за да се избегне повторно вмъкване на panic код.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Връща останалия (под) низ на този итератор като парче.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: разкоментирайте AsRef импулси отдолу при стабилизиране.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Коментирайте при стабилизиране на `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>за Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> за Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}