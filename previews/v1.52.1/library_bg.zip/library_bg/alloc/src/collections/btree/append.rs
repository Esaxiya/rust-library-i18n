use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Добавя всички двойки ключ-стойност от обединението на два възходящи итератора, увеличавайки `length` променлива по пътя.Последното улеснява повикващия да избегне изтичане, когато манипулаторът за изпускане изпадне в паника.
    ///
    /// Ако и двата итератора произвеждат един и същ ключ, този метод изпуска двойката от левия итератор и добавя двойката от десния итератор.
    ///
    /// Ако искате дървото да завърши в строго възходящ ред, като за `BTreeMap`, и двата итератора трябва да генерират ключове в строго възходящ ред, всеки по-голям от всички ключове в дървото, включително всички ключове, които вече са в дървото при влизане.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Подготвяме се да обединим `left` и `right` в сортирана последователност за линейно време.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Междувременно изграждаме дърво от сортираната последователност за линейно време.
        self.bulk_push(iter, length)
    }

    /// Избутва всички двойки ключ-стойност до края на дървото, увеличавайки променлива `length` по пътя.
    /// Последното улеснява повикващия да избегне изтичане, когато итераторът се паникьоса.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Итерирайте през всички двойки ключ-стойност, като ги натискате във възли на правилното ниво.
        for (key, value) in iter {
            // Опитайте да натиснете двойката ключ-стойност в текущия листен възел.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Не остава място, качете се нагоре и натиснете там.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Намерен възел с ляво място, натиснете тук.
                                open_node = parent;
                                break;
                            } else {
                                // Качи се отново.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Ние сме на върха, създайте нов корен възел и натиснете там.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Натиснете двойка ключ-стойност и ново дясно поддърво.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Спуснете се отново до най-десния лист отново.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Увеличавайте дължината на всяка итерация, за да сте сигурни, че картата изпуска добавените елементи, дори ако напредването на итератора се паникьосва.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Итератор за обединяване на две сортирани последователности в една
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Ако два ключа са равни, връща двойката ключ-стойност от десния източник.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}