use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Временно изважда друг, неизменяем еквивалент от същия диапазон.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Намира различните ръбове на листа, ограничаващи определен диапазон в дърво.
    /// Връща или двойка различни манипулатори в едно и също дърво, или двойка празни опции.
    ///
    /// # Safety
    ///
    /// Освен ако `BorrowType` не е `Immut`, не използвайте дублиращите се дръжки, за да посетите едно и също KV два пъти.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Еквивалентно на `(root1.first_leaf_edge(), root2.last_leaf_edge())`, но по-ефективно.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Намира двойката ръбове на листа, ограничаваща определен диапазон в дърво.
    ///
    /// Резултатът има значение само ако дървото е подредено по ключ, както е дървото в `BTreeMap`.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // БЕЗОПАСНОСТ: нашият тип заем е неизменим.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Намира двойката ръбове на листа, ограничаващи цяло дърво.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Разделя уникална препратка в двойка ръбове на листа, ограничаващи определен диапазон.
    /// Резултатът са уникални референции, позволяващи мутация на (some), които трябва да се използват внимателно.
    ///
    /// Резултатът има значение само ако дървото е подредено по ключ, както е дървото в `BTreeMap`.
    ///
    ///
    /// # Safety
    /// Не използвайте дублиращите се дръжки, за да посетите едно и също KV два пъти.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Разделя уникална препратка в двойка ръбове на листа, ограничаващи пълния обхват на дървото.
    /// Резултатите са уникални препратки, позволяващи мутация (само на стойности), така че трябва да се използват внимателно.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Дублираме коренния NodeRef тук-никога няма да посетим една и съща KV два пъти и никога няма да имаме припокриващи се препратки към стойности.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Разделя уникална препратка в двойка ръбове на листа, ограничаващи пълния обхват на дървото.
    /// Резултатите са уникални препратки, позволяващи масово деструктивна мутация, така че трябва да се използват с най-голямо внимание.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Дублираме коренния NodeRef тук-никога няма да го осъществим по начин, който да припокрива препратки, получени от рут.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Като се получи лист edge, връща [`Result::Ok`] с дръжка към съседния KV от дясната страна, който е или в същия листен възел, или в предшествен възел.
    ///
    /// Ако листът edge е последният в дървото, връща [`Result::Err`] с кореновия възел.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Като се получи лист edge, връща [`Result::Ok`] с дръжка към съседния KV от лявата страна, който е или в същия листен възел, или в предшествен възел.
    ///
    /// Ако листът edge е първият в дървото, връща [`Result::Err`] с кореновия възел.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Като се има предвид вътрешен манипулатор edge, връща [`Result::Ok`] с манипулатор към съседния KV от дясната страна, който е или в същия вътрешен възел, или във възел предшественик.
    ///
    /// Ако вътрешният edge е последният в дървото, връща [`Result::Err`] с кореновия възел.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Даден лист edge на лист в умиращо дърво, връща следващия лист edge от дясната страна и двойката ключ-стойност между тях, която е или в същия възел на листа, в възел на предшественик или не съществува.
    ///
    ///
    /// Този метод освобождава и всеки node(s), до който е достигнал края.
    /// Това предполага, че ако не съществува повече двойка ключ-стойност, целият остатък от дървото ще бъде освободен и няма какво да се върне.
    ///
    /// # Safety
    /// Даденият edge не трябва да е бил връщан по-рано от аналог `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Даден лист на edge в умиращо дърво, връща следващия лист edge от лявата страна и двойката ключ-стойност между тях, която е или в същия възел на листа, във възел на предшественик или не съществува.
    ///
    ///
    /// Този метод освобождава и всеки node(s), до който е достигнал края.
    /// Това предполага, че ако не съществува повече двойка ключ-стойност, целият остатък от дървото ще бъде освободен и няма какво да се върне.
    ///
    /// # Safety
    /// Даденият edge не трябва да е бил връщан по-рано от аналог `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Разпределя купчина възли от листа до корена.
    /// Това е единственият начин да се освободи остатъкът от дърво, след като `deallocating_next` и `deallocating_next_back` са хапали от двете страни на дървото и са ударили същия edge.
    /// Тъй като е предназначен само за извикване, когато всички ключове и стойности са върнати, не се извършва почистване на нито един от ключовете или стойностите.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Премества листчето edge на следващия лист edge и връща препратки към ключа и стойността между тях.
    ///
    ///
    /// # Safety
    /// Трябва да има още KV в изминатата посока.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Премества манипулатора на листа edge към предишния лист edge и връща препратки към ключа и стойността между тях.
    ///
    ///
    /// # Safety
    /// Трябва да има още KV в изминатата посока.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Премества листчето edge на следващия лист edge и връща препратки към ключа и стойността между тях.
    ///
    ///
    /// # Safety
    /// Трябва да има още KV в изминатата посока.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Правенето на това последно е по-бързо, според бенчмарковете.
        kv.into_kv_valmut()
    }

    /// Премества листчето edge на предходния лист и връща препратки към ключа и стойността между тях.
    ///
    ///
    /// # Safety
    /// Трябва да има още KV в изминатата посока.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Правенето на това последно е по-бързо, според бенчмарковете.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Премества ръчката на листа edge към следващия лист edge и връща ключа и стойността между тях, освобождавайки всеки възел, останал след това, оставяйки съответния edge в родителския си възел да виси.
    ///
    /// # Safety
    /// - Трябва да има още KV в изминатата посока.
    /// - Това KV не е било върнато преди от `next_back_unchecked` на нито едно копие на дръжките, използвани за пресичане на дървото.
    ///
    /// Единственият безопасен начин да продължите с актуализираната манипулация е да я сравните, пуснете, да извикате отново този метод при спазване на условията му за безопасност или да се обадите на аналог `next_back_unchecked` при условията на неговата безопасност.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Премества листчето edge на предишния лист edge и връща ключа и стойността между тях, освобождавайки всеки възел, останал след това, оставяйки съответния edge в неговия родителски възел, висящ.
    ///
    /// # Safety
    /// - Трябва да има още KV в изминатата посока.
    /// - Този лист edge не е бил върнат преди от колегата `next_unchecked` на нито едно копие на дръжките, използвани за пресичане на дървото.
    ///
    /// Единственият безопасен начин да продължите с актуализираната манипулация е да я сравните, пуснете, да извикате отново този метод при спазване на условията му за безопасност или да се обадите на аналог `next_unchecked` при условията на безопасност.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Връща най-левия лист edge във или под възел, с други думи, edge, от който се нуждаете първо при навигация напред (или последно при навигация назад).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Връща най-десния лист edge във или под възел, с други думи, edge, от който се нуждаете последен при навигация напред (или първи при навигация назад).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Посещава листни възли и вътрешни KV в порядък на възходящи ключове, а също така посещава вътрешни възли като цяло в дълбочина първи ред, което означава, че вътрешните възли предхождат техните индивидуални KV и техните дъщерни възли.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Изчислява броя на елементите в (под) дърво.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Връща листа edge най-близо до KV за навигация напред.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Връща листа edge най-близо до KV за навигация назад.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}