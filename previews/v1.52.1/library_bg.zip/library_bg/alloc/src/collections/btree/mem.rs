use core::intrinsics;
use core::mem;
use core::ptr;

/// Това замества стойността зад уникалната препратка `v`, като извиква съответната функция.
///
///
/// Ако при затварянето на `change` възникне panic, целият процес ще бъде прекъснат.
#[allow(dead_code)] // съхранявайте като илюстрация и за използване на future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Това замества стойността зад уникалната препратка `v` чрез извикване на съответната функция и връща резултат, получен по пътя.
///
///
/// Ако при затварянето на `change` възникне panic, целият процес ще бъде прекъснат.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}