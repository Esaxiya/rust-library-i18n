// Това е опит за изпълнение, следващо идеала
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Тъй като Rust всъщност няма зависими типове и полиморфна рекурсия, ние се справяме с много опасности.
//

// Основна цел на този модул е да се избегне сложността, като се третира дървото като общ (макар и странно оформен) контейнер и се избягва справянето с повечето инварианти на B-Tree.
//
// Като такъв, този модул не се интересува дали записите са сортирани, кои възли могат да бъдат недостатъчни или дори какво означава underfull.Разчитаме обаче на няколко инварианти:
//
// - Дърветата трябва да имат еднакъв depth/height.Това означава, че всеки път надолу към лист от даден възел има точно същата дължина.
// - Възел с дължина `n` има ключове `n`, стойности `n` и ръбове `n + 1`.
//   Това предполага, че дори празен възел има поне един edge.
//   За листен възел "having an edge" означава само, че можем да идентифицираме позиция във възела, тъй като ръбовете на листа са празни и не се нуждаят от представяне на данни.
// Във вътрешен възел edge едновременно идентифицира позиция и съдържа указател към дъщерен възел.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Основното представяне на листни възли и част от представянето на вътрешни възли.
struct LeafNode<K, V> {
    /// Искаме да бъдем ковариантни в `K` и `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Индексът на този възел в масива `edges` на родителския възел.
    /// `*node.parent.edges[node.parent_idx]` трябва да е същото като `node`.
    /// Това е гарантирано, че ще бъде инициализирано, когато `parent` не е нулев.
    parent_idx: MaybeUninit<u16>,

    /// Броят на ключовете и стойностите, които съхранява този възел.
    len: u16,

    /// Масивите, съхраняващи действителните данни на възела.
    /// Само първите `len` елементи от всеки масив са инициализирани и валидни.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Инициализира нов `LeafNode` на място.
    unsafe fn init(this: *mut Self) {
        // Като обща политика оставяме полетата неинициализирани, ако могат, тъй като това трябва да бъде едновременно малко по-бързо и по-лесно за проследяване във Valgrind.
        //
        unsafe {
            // parent_idx, ключовете и vals са всички MaybeUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Създава нов `LeafNode` в кутия.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Основното представяне на вътрешни възли.Както при `LeafNode`s, те трябва да бъдат скрити зад`BoxedNode`s, за да се предотврати изпускането на неинициализирани ключове и стойности.
/// Всеки указател към `InternalNode` може да бъде директно кастиран към указател към основната част на `LeafNode` на възела, което позволява на кода да действа върху листни и вътрешни възли общо, без дори да е необходимо да проверява към кой от двата сочи указателят.
///
/// Това свойство се активира от използването на `repr(C)`.
///
#[repr(C)]
// gdb_providers.py използва името на този тип за самоанализ.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Указателите към децата на този възел.
    /// `len + 1` от тях се считат за инициализирани и валидни, с изключение на това, че към края, докато дървото се държи чрез тип заем `Dying`, някои от тези указатели са висящи.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Създава нов `InternalNode` в кутия.
    ///
    /// # Safety
    /// Инвариант на вътрешните възли е, че те имат поне един инициализиран и валиден edge.
    /// Тази функция не настройва такъв edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Трябва само да инициализираме данните;ръбовете са MaybeUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Управляван, ненулеви указател към възел.Това е или притежаван указател към `LeafNode<K, V>`, или притежаван указател към `InternalNode<K, V>`.
///
/// `BoxedNode` обаче не съдържа информация кой от двата типа възли всъщност съдържа и, отчасти поради липсата на информация, не е отделен тип и няма деструктор.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Коренният възел на притежавано дърво.
///
/// Имайте предвид, че в него няма деструктор и трябва да се почисти ръчно.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Връща ново притежавано дърво със собствен корен възел, който първоначално е празен.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` не трябва да е нула.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Mutably заема притежавания корен възел.
    /// За разлика от `reborrow_mut`, това е безопасно, защото връщаната стойност не може да се използва за унищожаване на корена и не може да има други препратки към дървото.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Леко изменчиво заема притежавания корен възел.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Необратимо преминава към препратка, която позволява обхождане и предлага деструктивни методи и малко друго.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Добавя нов вътрешен възел с единичен edge, сочещ към предишния корен възел, прави този нов възел коренния възел и го връща.
    /// Това увеличава височината с 1 и е обратното на `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, с изключение на това, че просто забравихме, че сме вътрешни сега:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Премахва вътрешния корен възел, като използва първото му дъщерно устройство като новия корен възел.
    /// Тъй като е предназначен само за извикване, когато коренният възел има само едно дъщерно устройство, не се извършва почистване на нито един от ключовете, стойностите и другите дъщерни елементи.
    ///
    /// Това намалява височината с 1 и е обратното на `push_internal_level`.
    ///
    /// Изисква изключителен достъп до обекта `Root`, но не и до основния възел;
    /// няма да обезсили други манипулатори или препратки към основния възел.
    ///
    /// Panics, ако няма вътрешно ниво, т.е. ако коренният възел е лист.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // БЕЗОПАСНОСТ: ние твърдим, че сме вътрешни.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // БЕЗОПАСНОСТ: взехме назаем изключително `self` и неговият тип заем е изключителен.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // БЕЗОПАСНОСТ: първият edge винаги се инициализира.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` винаги е ковариант в `K` и `V`, дори когато `BorrowType` е `Mut`.
// Това е технически погрешно, но не може да доведе до някаква несигурност поради вътрешна употреба на `NodeRef`, защото ние оставаме напълно общи за `K` и `V`.
//
// Въпреки това, когато публичен тип обвива `NodeRef`, уверете се, че има правилната дисперсия.
//
/// Препратка към възел.
///
/// Този тип има редица параметри, които контролират как действа:
/// - `BorrowType`: Фиктивен тип, който описва вида на заема и носи цял живот.
///    - Когато това е `Immut<'a>`, `NodeRef` действа приблизително като `&'a Node`.
///    - Когато това е `ValMut<'a>`, `NodeRef` действа приблизително като `&'a Node` по отношение на ключовете и дървесната структура, но също така позволява да съществуват много променливи препратки към стойности в цялото дърво.
///    - Когато това е `Mut<'a>`, `NodeRef` действа приблизително като `&'a mut Node`, въпреки че методите за вмъкване позволяват съжителство на изменяем указател към стойност.
///    - Когато това е `Owned`, `NodeRef` действа приблизително като `Box<Node>`, но няма деструктор и трябва да се почисти ръчно.
///    - Когато това е `Dying`, `NodeRef` все още действа приблизително като `Box<Node>`, но има методи за унищожаване на дървото бит по бит и обикновените методи, макар и да не са маркирани като опасни за извикване, могат да извикат UB, ако са извикани неправилно.
///
///   Тъй като всеки `NodeRef` позволява навигация през дървото, `BorrowType` ефективно се прилага към цялото дърво, а не само към самия възел.
/// - `K` и `V`: Това са типовете ключове и стойности, съхранявани в възлите.
/// - `Type`: Това може да бъде `Leaf`, `Internal` или `LeafOrInternal`.
/// Когато това е `Leaf`, `NodeRef` сочи към листен възел, когато това е `Internal`, `NodeRef` сочи към вътрешен възел, а когато това е `LeafOrInternal`, `NodeRef` може да сочи към всеки тип възел.
///   `Type` се нарича `NodeType`, когато се използва извън `NodeRef`.
///
/// Както `BorrowType`, така и `NodeType` ограничават какви методи прилагаме, за да се използва безопасността от статичен тип.Има ограничения в начина, по който можем да прилагаме такива ограничения:
/// - За всеки параметър тип можем да дефинираме метод само общо или за един определен тип.
/// Например, не можем да дефинираме метод като `into_kv` като цяло за всички `BorrowType` или веднъж за всички типове, които носят цял живот, защото искаме той да връща референции `&'a`.
///   Следователно ние го дефинираме само за най-мощния тип `Immut<'a>`.
/// - Не можем да получим имплицитна принуда от да речем `Mut<'a>` до `Immut<'a>`.
///   Следователно трябва изрично да извикаме `reborrow` на по-мощен `NodeRef`, за да достигнем до метод като `into_kv`.
///
/// Всички методи на `NodeRef`, които връщат някакъв вид препратка, или:
/// - Вземете `self` по стойност и върнете живота на `BorrowType`.
///   Понякога, за да извикаме такъв метод, трябва да извикаме `reborrow_mut`.
/// - Вземете `self` по референция и (implicitly) върнете живота на тази референция, вместо живота, носен от `BorrowType`.
/// По този начин проверката на заема гарантира, че `NodeRef` остава заем, докато се използва върнатата препратка.
///   Методите, поддържащи вмъкване, огъват това правило, като връщат суров указател, т.е.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Броят на нивата, които възелът и нивото на листата са разделени, константа на възела, която не може да бъде изцяло описана от `Type` и която самият възел не съхранява.
    /// Трябва само да съхраним височината на кореновия възел и да извлечем височината на всеки друг възел от него.
    /// Трябва да е нула, ако `Type` е `Leaf` и ненулева, ако `Type` е `Internal`.
    ///
    ///
    height: usize,
    /// Показалецът към листа или вътрешен възел.
    /// Дефиницията на `InternalNode` гарантира, че указателят е валиден и в двата случая.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Разопаковайте референция към възел, която беше опакована като `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Излага данните на вътрешен възел.
    ///
    /// Връща необработен ptr, за да се избегне невалидност на други препратки към този възел.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // БЕЗОПАСНОСТ: типът статичен възел е `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Заема изключителен достъп до данните на вътрешен възел.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Намира дължината на възела.Това е броят на ключовете или стойностите.
    /// Броят на ръбовете е `len() + 1`.
    /// Обърнете внимание, че въпреки че е безопасно, извикването на тази функция може да има страничен ефект от обезсилване на изменяеми препратки, които е създал опасен код.
    ///
    pub fn len(&self) -> usize {
        // Важно е, че тук имаме достъп само до полето `len`.
        // Ако BorrowType е marker::ValMut, може да има изключителни изменяеми препратки към стойности, които не трябва да обезсилваме.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Връща броя на нивата, които възелът и листата са разделени.
    /// Нулева височина означава, че възелът е сам лист.
    /// Ако изобразите дървета с корена отгоре, числото казва на коя кота се появява възелът.
    /// Ако си представите дървета с листа отгоре, числото показва колко високо се простира дървото над възела.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Временно изважда друга, неизменяема препратка към същия възел.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Излага листната част на всеки лист или вътрешен възел.
    ///
    /// Връща необработен ptr, за да се избегне невалидност на други препратки към този възел.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Възелът трябва да е валиден поне за частта LeafNode.
        // Това не е препратка в типа NodeRef, защото не знаем дали трябва да бъде уникална или споделена.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Намира родителя на текущия възел.
    /// Връща `Ok(handle)`, ако текущият възел действително има родител, където `handle` сочи към edge на родителя, който сочи към текущия възел.
    ///
    /// Връща `Err(self)`, ако текущият възел няма родител, връщайки оригиналния `NodeRef`.
    ///
    /// Името на метода предполага, че изобразявате дървета с кореновия възел отгоре.
    ///
    /// `edge.descend().ascend().unwrap()` и `node.ascend().unwrap().descend()` трябва и двамата след успех да не правят нищо.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Трябва да използваме сурови указатели към възли, защото, ако BorrowType е marker::ValMut, може да има изключителни изменяеми препратки към стойности, които не трябва да обезсилваме.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Имайте предвид, че `self` не трябва да е празен.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Имайте предвид, че `self` не трябва да е празен.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Излага листната част на всеки лист или вътрешен възел в неизменяемо дърво.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // БЕЗОПАСНОСТ: не може да има променящи се препратки към това дърво, заети като `Immut`.
        unsafe { &*ptr }
    }

    /// Заема изглед в ключовете, съхранявани в възела.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Подобно на `ascend`, получава препратка към родителския възел на възел, но също така освобождава текущия възел в процеса.
    /// Това е опасно, тъй като текущият възел все още ще бъде достъпен, въпреки че е освободен.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Несигурно заявява на компилатора статичната информация, че този възел е `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Несигурно заявява на компилатора статичната информация, че този възел е `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Временно изважда друга, променяща се препратка към същия възел.Внимавайте, тъй като този метод е много опасен, двойно по-голям, тъй като може да не изглежда веднага опасен.
    ///
    /// Тъй като изменяемите указатели могат да се движат навсякъде около дървото, върнатият указател може лесно да се използва, за да направи оригиналния указател висящ, извън границите или невалиден при подредени правила за заем.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) помислете за добавяне на още един параметър от тип към `NodeRef`, който ограничава използването на навигационни методи за презаредени указатели, предотвратявайки тази несигурност.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Взема в заем изключителен достъп до листната част на всеки лист или вътрешен възел.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // БЕЗОПАСНОСТ: имаме изключителен достъп до целия възел.
        unsafe { &mut *ptr }
    }

    /// Предлага изключителен достъп до листната част на всеки лист или вътрешен възел.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // БЕЗОПАСНОСТ: имаме изключителен достъп до целия възел.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Заема изключителен достъп до елемент от зоната за съхранение на ключове.
    ///
    /// # Safety
    /// `index` е в граници от 0..КАПАЦИТЕТ
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // БЕЗОПАСНОСТ: повикващият няма да може да извика допълнителни методи самостоятелно
        // докато референцията на ключовия отрязък не отпадне, тъй като имаме уникален достъп за целия живот на заема.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Взема назаем изключителен достъп до елемент или фрагмент от областта за съхранение на стойността на възела.
    ///
    /// # Safety
    /// `index` е в граници от 0..КАПАЦИТЕТ
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // БЕЗОПАСНОСТ: повикващият няма да може да извика допълнителни методи самостоятелно
        // докато референтът на среза на стойност не отпадне, тъй като имаме уникален достъп за целия живот на заема.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Взема назаем изключителен достъп до елемент или фрагмент от зоната за съхранение на възела за съдържанието на edge.
    ///
    /// # Safety
    /// `index` е в граници от 0..КАПАЦИТЕТ + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // БЕЗОПАСНОСТ: повикващият няма да може да извика допълнителни методи самостоятелно
        // докато справка edge отрязък не отпадне, тъй като имаме уникален достъп през целия живот на заема.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Възелът има повече от `idx` инициализирани елементи.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Ние създаваме само препратка към един елемент, който ни интересува, за да избегнем псевдоними с изключителни препратки към други елементи, по-специално тези, върнати на повикващия в по-ранни итерации.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Трябва да принудим указателите на масиви с голям размер поради Rust издание #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Заема изключителен достъп до дължината на възела.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Задава връзката на възела към неговия родител edge, без да анулира други препратки към възела.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Изчиства връзката на корена към родителя си edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Добавя двойка ключ-стойност в края на възела.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Всеки елемент, върнат от `range`, е валиден индекс edge за възела.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Добавя двойка ключ-стойност и edge, за да премине вдясно от тази двойка, до края на възела.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Проверява дали възелът е `Internal` възел или `Leaf` възел.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Препратка към конкретна двойка ключ-стойност или edge в рамките на възел.
/// Параметърът `Node` трябва да бъде `NodeRef`, докато `Type` може да бъде `KV` (означаващ манипулатор на двойка ключ-стойност) или `Edge` (означаващ манипулатор на edge).
///
/// Имайте предвид, че дори възлите `Leaf` могат да имат манипулатори `Edge`.
/// Вместо да представляват указател към дъщерен възел, те представляват пространствата, където дъщерните указатели ще преминат между двойките ключ-стойност.
/// Например във възел с дължина 2 ще има 3 възможни местоположения edge, едно вляво от възела, едно между двете двойки и едно вдясно от възела.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Ние не се нуждаем от пълната универсалност на `#[derive(Clone)]`, тъй като единственият момент, когато `Node` ще бъде " Clone`able, е когато е неизменяема референция и следователно `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Извлича възела, който съдържа edge или двойка ключ-стойност, към която сочи този манипулатор.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Връща позицията на този манипулатор във възела.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Създава нов манипулатор на двойка ключ-стойност в `node`.
    /// Несигурно, защото повикващият трябва да гарантира, че `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Възможно е публично изпълнение на PartialEq, но използвано само в този модул.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Временно изважда друга, неизменяема дръжка на същото място.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Не можем да използваме Handle::new_kv или Handle::new_edge, защото не познаваме типа си
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Несигурно заявява на компилатора статичната информация, че възелът на манипулатора е `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Временно изважда друга, подвижна дръжка на същото място.
    /// Внимавайте, тъй като този метод е много опасен, двойно по-голям, тъй като може да не изглежда веднага опасен.
    ///
    ///
    /// За подробности вижте `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Не можем да използваме Handle::new_kv или Handle::new_edge, защото не познаваме типа си
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Създава нова манипулация на edge в `node`.
    /// Несигурно, защото повикващият трябва да гарантира, че `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Като се има предвид индекс edge, където искаме да вмъкнем в възел, запълнен до капацитет, изчислява разумен KV индекс на точка на разделяне и къде да извършим вмъкването.
///
/// Целта на точката на разделяне е нейният ключ и стойност да се озоват в родителски възел;
/// клавишите, стойностите и ръбовете вляво от точката на разделяне стават лявото дете;
/// ключовете, стойностите и ръбовете вдясно от точката на разделяне стават правилното дете.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust издание #74834 се опитва да обясни тези симетрични правила.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Вмъква нова двойка ключ-стойност между двойките ключ-стойност вдясно и вляво от този edge.
    /// Този метод предполага, че има достатъчно място във възела, за да може новата двойка да се побере.
    ///
    /// Върнатият указател сочи към вмъкнатата стойност.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Вмъква нова двойка ключ-стойност между двойките ключ-стойност вдясно и вляво от този edge.
    /// Този метод разделя възела, ако няма достатъчно място.
    ///
    /// Върнатият указател сочи към вмъкнатата стойност.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Коригира родителския указател и индекс в дъщерния възел, към който се свързва този edge.
    /// Това е полезно, когато подреждането на ръбовете е променено,
    fn correct_parent_link(self) {
        // Създайте backpointer, без да анулирате други препратки към възела.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Вмъква нова двойка ключ-стойност и edge, които ще отидат вдясно от тази нова двойка между тази edge и двойката ключ-стойност вдясно от тази edge.
    /// Този метод предполага, че има достатъчно място във възела, за да може новата двойка да се побере.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Вмъква нова двойка ключ-стойност и edge, които ще отидат вдясно от тази нова двойка между тази edge и двойката ключ-стойност вдясно от тази edge.
    /// Този метод разделя възела, ако няма достатъчно място.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Вмъква нова двойка ключ-стойност между двойките ключ-стойност вдясно и вляво от този edge.
    /// Този метод разделя възела, ако няма достатъчно място, и се опитва да вмъкне разделената част в родителския възел рекурсивно, докато се достигне коренът.
    ///
    ///
    /// Ако върнатият резултат е `Fit`, възелът на неговия манипулатор може да бъде възелът на този edge или предшественик.
    /// Ако върнатият резултат е `Split`, полето `left` ще бъде основният възел.
    /// Върнатият указател сочи към вмъкнатата стойност.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Намира възела, посочен от този edge.
    ///
    /// Името на метода предполага, че изобразявате дървета с кореновия възел отгоре.
    ///
    /// `edge.descend().ascend().unwrap()` и `node.ascend().unwrap().descend()` трябва и двамата след успех да не правят нищо.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Трябва да използваме сурови указатели към възли, защото, ако BorrowType е marker::ValMut, може да има изключителни изменяеми препратки към стойности, които не трябва да обезсилваме.
        // Няма притеснение за достъп до полето за височина, защото тази стойност се копира.
        // Внимавайте, че след като пренасочваме указателя към възела, ние осъществяваме достъп до масива от краища с препратка (Rust издание #73987) и обезсилваме всички други препратки към или вътре в масива, ако има такива.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Не можем да извикаме отделни методи ключ и стойност, тъй като извикването на втория обезсилва препратката, върната от първата.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Заменете ключа и стойността, за които се отнася KV манипулаторът.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Помага за внедряването на `split` за конкретен `NodeType`, като се грижи за листовите данни.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Разделя основния възел на три части:
    ///
    /// - Възелът е отсечен, за да съдържа само двойките ключ-стойност вляво от тази манипулатор.
    /// - Ключът и стойността, посочени от този манипулатор, се извличат.
    /// - Всички двойки ключ-стойност вдясно от този манипулатор се поставят в новоразпределен възел.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Премахва двойката ключ-стойност, посочена от този манипулатор, и я връща, заедно с edge, в която двойката ключ-стойност е свита.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Разделя основния възел на три части:
    ///
    /// - Възелът е отсечен, за да съдържа само ръбовете и двойките ключ-стойност вляво от тази манипулатор.
    /// - Ключът и стойността, посочени от този манипулатор, се извличат.
    /// - Всички ръбове и двойки ключ-стойност вдясно от тази дръжка се поставят в новоразпределен възел.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Представлява сесия за оценка и извършване на операция за балансиране около вътрешна двойка ключ-стойност.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Избира балансиращ контекст, включващ възела като дете, като по този начин между KV веднага вляво или вдясно в родителския възел.
    /// Връща `Err`, ако няма родител.
    /// Panics, ако родителят е празен.
    ///
    /// Предпочита лявата страна, за да бъде оптимална, ако даденият възел е някак недопълнен, което означава тук само, че той има по-малко елементи от левия си брат и от десния си брат, ако те съществуват.
    /// В този случай сливането с левия брат е по-бързо, тъй като трябва само да преместим N елементите на възела, вместо да ги изместим надясно и да преместим повече от N елемента отпред.
    /// Кражбата от левия брат също обикновено е по-бърза, тъй като трябва само да изместим N елементите на възела надясно, вместо да изместим поне N от елементите на братя и сестри наляво.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Връща дали е възможно обединяване, т.е. дали има достатъчно място във възел, за да се комбинира централната KV и с двата съседни дъщерни възела.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Извършва обединяване и позволява затваряне да реши какво да се върне.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // БЕЗОПАСНОСТ: височината на обединяваните възли е една под височината
                // на възела на този edge, като по този начин над нулата, така че те са вътрешни.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Обединява двойката ключ-стойност на родителя и двете съседни дъщерни възли в левия дъщерен възел и връща свития родителски възел.
    ///
    ///
    /// Panics, освен ако не сме `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Обединява двойката ключ-стойност на родителя и двете съседни дъщерни възли в левия дъщерен възел и връща този дъщерен възел.
    ///
    ///
    /// Panics, освен ако не сме `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Обединява двойката ключ-стойност на родителя и двата съседни дъщерни възела в левия дъщерен възел и връща манипулатора edge в този дъщерен възел, където е попаднало проследеното дете edge,
    ///
    ///
    /// Panics, освен ако не сме `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Премахва двойка ключ-стойност от лявото дете и я поставя в хранилището ключ-стойност на родителя, като същевременно бута старата двойка ключ-стойност родител в дясното дете.
    ///
    /// Връща манипулатор на edge в дясното дете, съответстващо на мястото, където е свършил оригиналният edge, посочен от `track_right_edge_idx`.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Премахва двойка ключ-стойност от дясното дете и я поставя в хранилището ключ-стойност на родителя, като същевременно натиска старата двойка ключ-стойност родител върху лявото дете.
    ///
    /// Връща манипулатор на edge в лявото дъщерно устройство, посочено от `track_left_edge_idx`, което не се движи.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Това краде подобно на `steal_left`, но краде няколко елемента наведнъж.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Уверете се, че можем да крадем безопасно.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Преместване на данни за листа.
            {
                // Направете място за откраднати елементи в правилното дете.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Преместете елементи от лявото дете към дясното.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Преместете най-лявата крадена двойка при родителя.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Преместете двойката ключ-стойност на родителя в дясното дете.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Направете място за откраднати ръбове.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Крадете ръбове.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Симетричният клон на `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Уверете се, че можем да крадем безопасно.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Преместване на данни за листа.
            {
                // Преместете най-дясната крадена двойка на родителя.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Преместете двойката ключ-стойност на родителя в лявото дете.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Преместете елементи от дясното дете в лявото.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Запълнете празнина там, където преди са били откраднати елементи.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Крадете ръбове.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Запълнете празнината там, където преди са били откраднатите ръбове.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Премахва всяка статична информация, която твърди, че този възел е възел `Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Премахва всяка статична информация, която твърди, че този възел е възел `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Проверява дали основният възел е възел `Internal` или възел `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Преместете суфикса след `self` от един възел на друг.`right` трябва да е празно.
    /// Първият edge на `right` остава непроменен.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Резултат от вмъкването, когато възел трябва да се разшири отвъд капацитета си.
pub struct SplitResult<'a, K, V, NodeType> {
    // Променен възел в съществуващо дърво с елементи и ръбове, които принадлежат отляво на `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Някои ключ и стойност се разделят, за да бъдат вмъкнати другаде.
    pub kv: (K, V),
    // Притежаван, необвързан, нов възел с елементи и ръбове, които принадлежат отдясно на `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Дали препратките към възли от този тип заем позволяват преминаване към други възли в дървото.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Преминаването не е необходимо, това се случва с помощта на резултата от `borrow_mut`.
        // Като деактивираме обръщането и създаваме само нови препратки към корени, знаем, че всяка препратка от типа `Owned` е към корен възел.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Вмъква стойност в парче инициализирани елементи, последвани от един неинициализиран елемент.
///
/// # Safety
/// Срезът има повече от `idx` елементи.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Премахва и връща стойност от парче от всички инициализирани елементи, оставяйки след себе си един последващ неинициализиран елемент.
///
///
/// # Safety
/// Срезът има повече от `idx` елементи.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Премества елементите в разрез `distance` позиции вляво.
///
/// # Safety
/// Срезът има поне `distance` елементи.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Премества елементите в позиции на среза `distance` вдясно.
///
/// # Safety
/// Срезът има поне `distance` елементи.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Премества всички стойности от парче инициализирани елементи към парче неинициализирани елементи, оставяйки `src` като всички неинициализирани.
///
/// Работи като `dst.copy_from_slice(src)`, но не изисква `T` да бъде `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;