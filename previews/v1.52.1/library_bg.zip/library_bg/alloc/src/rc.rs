//! Еднонишкови указатели за преброяване на референции.'Rc' означава " Справка`
//! Counted'.
//!
//! Типът [`Rc<T>`][`Rc`] осигурява споделена собственост върху стойност от тип `T`, разпределена в купчината.
//! Извикването на [`clone`][clone] на [`Rc`] създава нов указател към същото разпределение в купчината.
//! Когато последният указател [`Rc`] към дадено разпределение бъде унищожен, стойността, съхранена в това разпределение (често наричана "inner value"), също се отпада.
//!
//! Споделените препратки в Rust забраняват мутацията по подразбиране и [`Rc`] не е изключение: по принцип не можете да получите изменяема препратка към нещо вътре в [`Rc`].
//! Ако имате нужда от променливост, поставете [`Cell`] или [`RefCell`] вътре в [`Rc`];вижте [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] използва неатомно преброяване на референции.
//! Това означава, че режийните разходи са много ниски, но [`Rc`] не може да бъде изпратен между нишките и следователно [`Rc`] не реализира [`Send`][send].
//! В резултат на това компилаторът на Rust ще провери *по време на компилация*, че не изпращате [`Rc`] s между нишки.
//! Ако имате нужда от многонишково, атомно преброяване на референции, използвайте [`sync::Arc`][arc].
//!
//! Методът [`downgrade`][downgrade] може да се използва за създаване на непритежаващ указател [`Weak`].
//! Указателят [`Weak`] може да бъде [`надстройка`][надстройка] d до [`Rc`], но това ще върне [`None`], ако стойността, съхранена в разпределението, вече е отпаднала.
//! С други думи, указателите `Weak` не поддържат стойността вътре в разпределението жива;те обаче *поддържат* разпределението (резервното хранилище за вътрешната стойност) живо.
//!
//! Цикъл между указатели [`Rc`] никога няма да бъде освободен.
//! Поради тази причина [`Weak`] се използва за прекъсване на цикли.
//! Например едно дърво може да има силни [`Rc`] указатели от родителски възли към деца и [`Weak`] указатели от деца обратно към техните родители.
//!
//! `Rc<T>` автоматично пренасочва към `T` (чрез [`Deref`] Portrait), така че можете да извикате методите на T на стойност от тип [`Rc<T>`][`Rc`].
//! За да се избегнат сблъсъци на имена с методите на " T`, методите на самия [`Rc<T>`][`Rc`] са свързани функции, извикани с помощта на [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>Внедряванията на traits като `Clone` също могат да бъдат извикани, използвайки напълно квалифициран синтаксис.
//! Някои хора предпочитат да използват напълно квалифициран синтаксис, докато други предпочитат да използват синтаксис за извикване на метод.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Синтаксис на извикване на метод
//! let rc2 = rc.clone();
//! // Напълно квалифициран синтаксис
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] не извършва автоматично пренасочване към `T`, тъй като вътрешната стойност може вече да е отпаднала.
//!
//! # Референции за клониране
//!
//! Създаването на нова препратка към същото разпределение като съществуващ указател за преброяване на референции се извършва с помощта на `Clone` Portrait, внедрен за [`Rc<T>`][`Rc`] и [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Двата синтаксиса по-долу са еквивалентни.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a и b и двете сочат към същото място в паметта като foo.
//! ```
//!
//! Синтаксисът `Rc::clone(&from)` е най-идиоматичният, тъй като предава по-изрично значението на кода.
//! В горния пример този синтаксис улеснява виждането, че този код създава нова препратка, вместо да копира цялото съдържание на foo.
//!
//! # Examples
//!
//! Помислете за сценарий, при който набор от " джаджи` се притежава от даден `Owner`.
//! Искаме да посочим нашата " Джаджа` към техния `Owner`.Не можем да направим това с уникална собственост, тъй като повече от една джаджа може да принадлежи на един и същ `Owner`.
//! [`Rc`] ни позволява да споделяме `Owner` между множество `Gadget`s и `Owner` да остане разпределен, докато всеки `Gadget` сочи към него.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... други полета
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... други полета
//! }
//!
//! fn main() {
//!     // Създайте преброен `Owner`.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Създайте `Gadget`, принадлежащи на `gadget_owner`.
//!     // Клонирането на `Rc<Owner>` ни дава нов указател към същото разпределение на `Owner`, увеличавайки броя на референтите в процеса.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Изхвърлете нашата локална променлива `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Въпреки отпадането на `gadget_owner`, все още можем да отпечатаме името на `Owner` на `Gadget`s.
//!     // Това е така, защото изпуснахме само един `Rc<Owner>`, а не `Owner`, към който сочи.
//!     // Докато има други `Rc<Owner>`, сочещи към същото разпределение `Owner`, той ще остане активен.
//!     // Проекцията на поле `gadget1.owner.name` работи, защото `Rc<Owner>` автоматично пренасочва към `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // В края на функцията `gadget1` и `gadget2` се унищожават, а заедно с тях и последните преброени препратки към нашия `Owner`.
//!     // Gadget Man сега също се унищожава.
//!     //
//! }
//! ```
//!
//! Ако нашите изисквания се променят и ние също трябва да можем да преминем от `Owner` до `Gadget`, ще срещнем проблеми.
//! Указател [`Rc`] от `Owner` до `Gadget` въвежда цикъл.
//! Това означава, че броят им на референции никога не може да достигне 0 и разпределението никога няма да бъде унищожено:
//! изтичане на памет.За да заобиколим това, можем да използваме указатели [`Weak`].
//!
//! Rust всъщност затруднява създаването на този цикъл на първо място.За да се получат две стойности, които сочат една към друга, една от тях трябва да бъде променлива.
//! Това е трудно, защото [`Rc`] налага безопасността на паметта, като дава само споделени препратки към стойността, която обгръща, и те не позволяват директна мутация.
//! Трябва да обгърнем частта от стойността, която искаме да мутираме, в [`RefCell`], която осигурява *вътрешна променливост*: метод за постигане на изменяемост чрез споделена препратка.
//! [`RefCell`] принуждава правилата за заемане на Rust по време на изпълнение.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... други полета
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... други полета
//! }
//!
//! fn main() {
//!     // Създайте преброен `Owner`.
//!     // Обърнете внимание, че сме поставили vector на " Притежателя`на " Gadget`s вътре в `RefCell`, за да можем да го мутираме чрез споделена препратка.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Създайте `Gadget`, принадлежащи на `gadget_owner`, както преди.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Добавете `Gadget`s към техния `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` динамичният заем свършва тук.
//!     }
//!
//!     // Повтаряйте над нашите " джаджи`, като отпечатвате техните подробности.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` е `Weak<Gadget>`.
//!         // Тъй като указателите `Weak` не могат да гарантират, че разпределението все още съществува, трябва да извикаме `upgrade`, който връща `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // В този случай знаем, че разпределението все още съществува, така че ние просто `unwrap` `Option`.
//!         // В по-сложна програма може да се наложи изящна обработка на грешки за резултат `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // В края на функцията `gadget_owner`, `gadget1` и `gadget2` се унищожават.
//!     // Сега няма силни указатели (`Rc`) към джаджите, така че те са унищожени.
//!     // Това нулира броя на референтите на Gadget Man, така че и той се унищожава.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Това е устойчиво на repr(C) до future срещу евентуално пренареждане на полето, което би попречило на иначе безопасното [into|from]_raw() на трансмутиращи се вътрешни типове.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Еднонизов указател за преброяване на референции.'Rc' означава " Справка`
/// Counted'.
///
/// Вижте [module-level documentation](./index.html) за повече подробности.
///
/// Присъщите методи на `Rc` са всички свързани функции, което означава, че трябва да ги извикате като например [`Rc::get_mut(&mut value)`][get_mut] вместо `value.get_mut()`.
/// Това избягва конфликти с методи от вътрешния тип `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Тази несигурност е добре, защото докато този Rc е жив, ние гарантираме, че вътрешният указател е валиден.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Конструира нов `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Има имплицитен слаб указател, притежаван от всички силни указатели, което гарантира, че слабият деструктор никога не освобождава разпределението, докато силен деструктор работи, дори ако слабият указател се съхранява в силния.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Конструира нов `Rc<T>`, използвайки слаба препратка към себе си.
    /// Опитът за надграждане на слабата препратка преди връщането на тази функция ще доведе до стойност `None`.
    ///
    /// Слабата справка обаче може да се клонира свободно и да се съхранява за използване по-късно.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... още полета
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Постройте вътрешното в състояние "uninitialized" с една слаба референция.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Важно е да не се отказваме от собствеността върху слабия указател, в противен случай паметта може да се освободи по времето, когато `data_fn` се върне.
        // Ако наистина искахме да предадем собствеността, бихме могли да създадем допълнителен слаб указател за себе си, но това би довело до допълнителни актуализации на броя на слабите референции, които в противен случай може да не са необходими.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Силните референции трябва заедно да притежават споделена слаба референция, така че не стартирайте деструктора за старата ни слаба референция.
        //
        mem::forget(weak);
        strong
    }

    /// Конструира нов `Rc` с неинициализирано съдържание.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Отложена инициализация:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Конструира нов `Rc` с неинициализирано съдържание, като паметта се запълва с байтове `0`.
    ///
    ///
    /// Вижте [`MaybeUninit::zeroed`][zeroed] за примери за правилно и неправилно използване на този метод.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Конструира нов `Rc<T>`, връщайки грешка, ако разпределението е неуспешно
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Има имплицитен слаб указател, притежаван от всички силни указатели, което гарантира, че слабият деструктор никога не освобождава разпределението, докато силен деструктор работи, дори ако слабият указател се съхранява в силния.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Конструира нов `Rc` с неинициализирано съдържание, връщайки грешка, ако разпределението е неуспешно
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Отложена инициализация:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Конструира нов `Rc` с неинициализирано съдържание, като паметта се запълва с байтове `0`, връщайки грешка, ако разпределението е неуспешно
    ///
    ///
    /// Вижте [`MaybeUninit::zeroed`][zeroed] за примери за правилно и неправилно използване на този метод.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Конструира нов `Pin<Rc<T>>`.
    /// Ако `T` не реализира `Unpin`, тогава `value` ще бъде фиксиран в паметта и не може да бъде преместен.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Връща вътрешната стойност, ако `Rc` има точно една силна референция.
    ///
    /// В противен случай се връща [`Err`] със същия `Rc`, който е бил предаден.
    ///
    ///
    /// Това ще успее, дори ако има изключителни слаби референции.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // копирайте съдържащия се обект

                // Посочете на Weaks, че те не могат да бъдат повишени, като намалят силния брой и след това премахнете неявния "strong weak" указател, като същевременно обработвате логиката на отпадане, като просто създадете фалшив слаб.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Конструира нов преброен референтен фрагмент с неинициализирано съдържание.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Отложена инициализация:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Конструира нов преброен референтен фрагмент с неинициализирано съдържание, като паметта се запълва с байтове `0`.
    ///
    ///
    /// Вижте [`MaybeUninit::zeroed`][zeroed] за примери за правилно и неправилно използване на този метод.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Преобразува в `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Както при [`MaybeUninit::assume_init`], зависи от повикващия да гарантира, че вътрешната стойност наистина е в инициализирано състояние.
    ///
    /// Извикването на това, когато съдържанието все още не е напълно инициализирано, причинява незабавно недефинирано поведение.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Отложена инициализация:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Преобразува в `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Както при [`MaybeUninit::assume_init`], зависи от повикващия да гарантира, че вътрешната стойност наистина е в инициализирано състояние.
    ///
    /// Извикването на това, когато съдържанието все още не е напълно инициализирано, причинява незабавно недефинирано поведение.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Отложена инициализация:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Консумира `Rc`, връщайки увития указател.
    ///
    /// За да се избегне изтичане на памет, показалеца трябва да се преобразува обратно в `Rc` с помощта на [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Предоставя суров указател към данните.
    ///
    /// Броят не се влияе по никакъв начин и `Rc` не се консумира.
    /// Показалецът е валиден, докато в `Rc` има силен брой.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // БЕЗОПАСНОСТ: Това не може да премине през Deref::deref или Rc::inner, защото
        // това е необходимо, за да се запази raw/mut произход така, че напр
        // `get_mut` може да пише през показалеца, след като Rc е възстановен чрез `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Конструира `Rc<T>` от суров указател.
    ///
    /// Необработеният указател трябва да е бил върнат преди това чрез повикване към [`Rc<U>::into_raw`][into_raw], където `U` трябва да има същия размер и подравняване като `T`.
    /// Това е тривиално вярно, ако `U` е `T`.
    /// Имайте предвид, че ако `U` не е `T`, но има еднакъв размер и подравняване, това е като трансмутиране на референции от различни типове.
    /// Вижте [`mem::transmute`][transmute] за повече информация относно това какви ограничения се прилагат в този случай.
    ///
    /// Потребителят на `from_raw` трябва да се увери, че определена стойност на `T` е отпаднала само веднъж.
    ///
    /// Тази функция е опасна, тъй като неправилната употреба може да доведе до несигурност на паметта, дори ако върнатият `Rc<T>` никога не бъде осъществен.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Преобразувайте обратно в `Rc`, за да предотвратите изтичане.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // По-нататъшните повиквания към `Rc::from_raw(x_ptr)` биха били опасни за паметта.
    /// }
    ///
    /// // Паметта беше освободена, когато `x` излезе от обхвата по-горе, така че `x_ptr` сега е висящ!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Обърнете отместването, за да намерите оригиналния RcBox.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Създава нов [`Weak`] указател към това разпределение.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Уверете се, че не създаваме висящ слаб
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Получава броя на указателите [`Weak`] към това разпределение.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Получава броя на силните указатели (`Rc`) към това разпределение.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Връща `true`, ако няма други указатели `Rc` или [`Weak`] към това разпределение.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Връща изменяема препратка към дадения `Rc`, ако няма други указатели `Rc` или [`Weak`] към същото разпределение.
    ///
    ///
    /// Връща [`None`] в противен случай, защото не е безопасно да мутирате споделена стойност.
    ///
    /// Вижте също [`make_mut`][make_mut], който ще [`clone`][clone] вътрешната стойност, когато има други указатели.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Връща изменяема препратка в дадения `Rc`, без никаква проверка.
    ///
    /// Вижте също [`get_mut`], който е безопасен и прави подходящи проверки.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Всички други указатели на `Rc` или [`Weak`] към същото разпределение не трябва да бъдат дереферирани за продължителността на върнатия заем.
    ///
    /// Това е тривиален случай, ако не съществуват такива указатели, например веднага след `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Внимаваме да не създаваме референция, която да покрива полетата "count", тъй като това би противоречило на достъпа до броя на референциите (напр.
        // от `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Връща `true`, ако двата `Rc` сочат към едно и също разпределение (във вена, подобна на [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Прави изменяема препратка към дадения `Rc`.
    ///
    /// Ако има други указатели `Rc` към същото разпределение, тогава `make_mut` ще [`clone`] вътрешната стойност към ново разпределение, за да осигури уникална собственост.
    /// Това също се нарича клониране върху запис.
    ///
    /// Ако няма други указатели `Rc` към това разпределение, тогава указателите [`Weak`] към това разпределение ще бъдат разделени.
    ///
    /// Вижте също [`get_mut`], който ще се провали, вместо да клонира.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Няма да клонира нищо
    /// let mut other_data = Rc::clone(&data);    // Няма да клонира вътрешни данни
    /// *Rc::make_mut(&mut data) += 1;        // Клонира вътрешни данни
    /// *Rc::make_mut(&mut data) += 1;        // Няма да клонира нищо
    /// *Rc::make_mut(&mut other_data) *= 2;  // Няма да клонира нищо
    ///
    /// // Сега `data` и `other_data` сочат към различни разпределения.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] указателите ще бъдат разделени:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Трябва да клонирам данните, има и други Rcs.
            // Предварително разпределете паметта, за да позволите директно писане на клонираната стойност.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Може просто да открадне данните, остава само Weaks
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Премахнете неявния силен и слаб реф (няма нужда да създавате фалшив слаб тук-знаем, че други слаби могат да ни почистят)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Тази несигурност е добре, защото ние гарантираме, че върнатият указател е *единственият* указател, който някога ще бъде върнат на T.
        // Гарантирано е, че броят ни на референции в този момент е 1 и ние изисквахме самият `Rc<T>` да бъде `mut`, така че връщаме единствената възможна препратка към разпределението.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Опит за понижаване на `Rc<dyn Any>` до конкретен тип.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Разпределя `RcBox<T>` с достатъчно пространство за евентуално неоразмерена вътрешна стойност, където стойността има предоставеното оформление.
    ///
    /// Функцията `mem_to_rcbox` се извиква с указателя за данни и трябва да върне обратно (потенциално дебел) указател за `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Изчислете оформлението, като използвате даденото оформление на стойността.
        // Преди това оформлението беше изчислено върху израза `&*(ptr as* const RcBox<T>)`, но това създаде грешно подравнена препратка (вж. #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Разпределя `RcBox<T>` с достатъчно място за евентуално неоразмерена вътрешна стойност, където стойността има предоставено оформление, връщайки грешка, ако разпределението е неуспешно.
    ///
    ///
    /// Функцията `mem_to_rcbox` се извиква с указателя за данни и трябва да върне обратно (потенциално дебел) указател за `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Изчислете оформлението, като използвате даденото оформление на стойността.
        // Преди това оформлението беше изчислено върху израза `&*(ptr as* const RcBox<T>)`, но това създаде грешно подравнена препратка (вж. #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Разпределете за оформлението.
        let ptr = allocate(layout)?;

        // Инициализирайте RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Разпределя `RcBox<T>` с достатъчно място за оразмерена вътрешна стойност
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Разпределете за `RcBox<T>`, като използвате дадената стойност.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Копиране на стойност като байтове
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Освободете разпределението, без да изпускате съдържанието му
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Разпределя `RcBox<[T]>` с дадената дължина.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Копирайте елементи от среза в новоразпределен Rc <\[T\]>
    ///
    /// Несигурно, защото повикващият трябва или да поеме собствеността, или да обвърже `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Конструира `Rc<[T]>` от итератор, за който е известно, че е с определен размер.
    ///
    /// Поведението е неопределено, ако размерът е грешен.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic предпазител при клониране на Т елементи.
        // В случай на panic, елементите, които са записани в новия RcBox, ще бъдат изпуснати, след което паметта ще бъде освободена.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Показалец към първия елемент
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Всичко е ясно.Забравете пазача, за да не освободи новия RcBox.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Специализация Portrait, използвана за `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Изпуска `Rc`.
    ///
    /// Това ще намали силния референтен брой.
    /// Ако броят на силните референции достигне нула, тогава единствените други референции (ако има такива) са [`Weak`], така че ние `drop` вътрешната стойност.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Не печата нищо
    /// drop(foo2);   // Отпечатва "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // унищожи съдържащия се обект
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // премахнете неявния указател "strong weak" сега, след като сме унищожили съдържанието.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Прави клон на показалеца `Rc`.
    ///
    /// Това създава друг указател към същото разпределение, увеличавайки силния брой референции.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Създава нов `Rc<T>` със стойността `Default` за `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Хак, за да позволи специализиране на `Eq`, въпреки че `Eq` има метод.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Ние правим тази специализация тук, а не като по-обща оптимизация на `&T`, защото в противен случай това би добавило разходи към всички проверки за равенство на референциите.
/// Предполагаме, че `Rc`s се използват за съхраняване на големи стойности, които са бавни за клониране, но и тежки за проверка за равенство, което води до по-лесно изплащане на тези разходи.
///
/// Също така е по-вероятно да има два клона `Rc`, които сочат към една и съща стойност, отколкото два `&T`s.
///
/// Можем да направим това само когато `T: Eq` като `PartialEq` може да е умишлено нерефлексивен.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Равенство за два `Rc`.
    ///
    /// Две `Rc` са равни, ако вътрешните им стойности са равни, дори ако се съхраняват в различно разпределение.
    ///
    /// Ако `T` също така изпълнява `Eq` (предполагащ рефлексивност на равенството), два `Rc, които сочат към едно и също разпределение, винаги са равни.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Неравенство за два `Rc`s.
    ///
    /// Две `Rc` са неравни, ако вътрешните им стойности са неравномерни.
    ///
    /// Ако `T` също така изпълнява `Eq` (което предполага рефлексивност на равенството), два `Rc`, които сочат към едно и също разпределение, никога не са неравномерни.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Частично сравнение за два `Rc`.
    ///
    /// Двамата се сравняват чрез извикване на `partial_cmp()` за техните вътрешни стойности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// По-малко от сравнение за два `Rc`.
    ///
    /// Двамата се сравняват чрез извикване на `<` за техните вътрешни стойности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Сравнение " По-малко или равно на`за два " Rc`.
    ///
    /// Двамата се сравняват чрез извикване на `<=` за техните вътрешни стойности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// По-голямо сравнение за два `Rc`.
    ///
    /// Двамата се сравняват чрез извикване на `>` за техните вътрешни стойности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// " По-голямо или равно на`сравнение за два " Rc`.
    ///
    /// Двамата се сравняват чрез извикване на `>=` за техните вътрешни стойности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Сравнение за две `Rc`.
    ///
    /// Двамата се сравняват чрез извикване на `cmp()` за техните вътрешни стойности.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Разпределете преброен референт и го попълнете, като клонирате елементите на " v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Разпределете преброен референтен фрагмент и копирайте `v` в него.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Разпределете преброен референтен фрагмент и копирайте `v` в него.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Преместете кутиран обект в ново, преброено препращане, разпределение.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Разпределете преброен референт и преместете елементите на " v` в него.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Позволете на Vec да освободи паметта си, но не и да унищожава съдържанието му
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Взема всеки елемент в `Iterator` и го събира в `Rc<[T]>`.
    ///
    /// # Характеристики на изпълнението
    ///
    /// ## Общият случай
    ///
    /// В общия случай събирането в `Rc<[T]>` се извършва чрез първо събиране в `Vec<T>`.Тоест, когато пишете следното:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// това се държи така, сякаш сме писали:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Тук се случва първият набор от разпределения.
    ///     .into(); // Тук се случва второ разпределение за `Rc<[T]>`.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Това ще разпредели толкова пъти, колкото е необходимо за конструиране на `Vec<T>` и след това ще разпредели веднъж за превръщане на `Vec<T>` в `Rc<[T]>`.
    ///
    ///
    /// ## Итератори с известна дължина
    ///
    /// Когато вашият `Iterator` внедри `TrustedLen` и е с точен размер, ще бъде направено едно разпределение за `Rc<[T]>`.Например:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Тук се случва само едно разпределение.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Специализация Portrait, използвана за събиране в `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Такъв е случаят с итератор `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // БЕЗОПАСНОСТ: Трябва да гарантираме, че итераторът има точна дължина и ние го имаме.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Върнете се към нормалното изпълнение.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` е версия на [`Rc`], която съдържа непритежаваща препратка към управляваното разпределение.Разпределението се осъществява чрез извикване на [`upgrade`] на указателя `Weak`, който връща [`Option`]`<`[`Rc`] `<T>>`.
///
/// Тъй като референцията на `Weak` не се брои за собственост, тя няма да попречи на стойността, съхранена в разпределението, да бъде отпаднала, а самият `Weak` не дава гаранции за стойността, която все още присъства.
/// По този начин той може да върне [`None`], когато [`надстройка`] d.
/// Имайте предвид обаче, че референцията `Weak`*не* предотвратява освобождаването на самото разпределение (резервното хранилище).
///
/// Указателят `Weak` е полезен за запазване на временна препратка към разпределението, управлявано от [`Rc`], без да предотвратява отпадането на вътрешната му стойност.
/// Също така се използва за предотвратяване на кръгови препратки между указатели [`Rc`], тъй като взаимните собствени препратки никога не биха позволили нито един от [`Rc`] да отпадне.
/// Например едно дърво може да има силни [`Rc`] указатели от родителски възли към деца и `Weak` указатели от деца обратно към техните родители.
///
/// Типичният начин за получаване на указател `Weak` е извикването на [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Това е `NonNull`, за да позволи оптимизиране на размера на този тип в изброявания, но не е непременно валиден указател.
    //
    // `Weak::new` задава това на `usize::MAX`, така че да не се налага да разпределя място в купчината.
    // Това не е стойност, която истинският указател някога ще има, защото RcBox има подравняване поне 2.
    // Това е възможно само когато `T: Sized`;неоразмерен `T` никога не се мотае.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Конструира нов `Weak<T>`, без да разпределя памет.
    /// Извикването на [`upgrade`] на връщаната стойност винаги дава [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Тип помощник, който позволява достъп до референтното броене, без да прави твърдения за полето с данни.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Връща суров указател към обекта `T`, посочен от този `Weak<T>`.
    ///
    /// Указателят е валиден само ако има някои силни препратки.
    /// Указателят може да е висящ, неравномерен или дори [`null`] в противен случай.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // И двете сочат към един и същ обект
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Силните тук го поддържат жив, така че все още можем да имаме достъп до обекта.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Но вече не.
    /// // Можем да направим weak.as_ptr(), но достъпът до показалеца би довел до недефинирано поведение.
    /// // assert_eq! ("здравей", опасно {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Ако показалецът е висящ, ние връщаме директно сентинела.
            // Това не може да бъде валиден адрес на полезен товар, тъй като полезният товар е поне толкова подравнен, колкото RcBox (usize).
            ptr as *const T
        } else {
            // БЕЗОПАСНОСТ: ако is_dangling връща false, тогава указателят е нереференцируем.
            // В този момент полезният товар може да отпадне и ние трябва да поддържаме произход, така че използвайте манипулация на суров указател.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Консумира `Weak<T>` и го превръща в суров указател.
    ///
    /// Това преобразува слабия указател в суров указател, като същевременно запазва собствеността върху една слаба препратка (слабият брой не се променя от тази операция).
    /// Той може да бъде превърнат обратно в `Weak<T>` с [`from_raw`].
    ///
    /// Прилагат се същите ограничения за достъп до целта на показалеца, както при [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Преобразува суров указател, създаден преди това от [`into_raw`], обратно в `Weak<T>`.
    ///
    /// Това може да се използва за безопасно получаване на силна референция (чрез извикване на [`upgrade`] по-късно) или за освобождаване на слабия брой чрез пускане на `Weak<T>`.
    ///
    /// Отнема собственост върху една слаба препратка (с изключение на указатели, създадени от [`new`], тъй като те не притежават нищо; методът все още работи върху тях).
    ///
    /// # Safety
    ///
    /// Указателят трябва да произхожда от [`into_raw`] и все още трябва да притежава потенциалната си слаба препратка.
    ///
    /// Позволено е силното броене да бъде 0 по време на извикване на това.
    /// Независимо от това, това придобива собственост върху една слаба препратка, представена в момента като суров указател (слабият брой не се променя от тази операция) и следователно трябва да се сдвои с предишно повикване към [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Намалете последния слаб брой.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Вижте Weak::as_ptr за контекст за това как се извежда указателят за въвеждане.

        let ptr = if is_dangling(ptr as *mut T) {
            // Това е висящ Слаб.
            ptr as *mut RcBox<T>
        } else {
            // В противен случай ние гарантираме, че показалецът е дошъл от неразбиращ се слаб.
            // БЕЗОПАСНОСТ: data_offset е безопасно за извикване, тъй като ptr се позовава на реална (потенциално отпаднала) T.
            let offset = unsafe { data_offset(ptr) };
            // По този начин обръщаме отместването, за да получим целия RcBox.
            // БЕЗОПАСНОСТ: указателят произхожда от слаб, така че това отместване е безопасно.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // БЕЗОПАСНОСТ: сега възстановихме оригиналния слаб указател, така че можем да създадем слабия.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Опити за надграждане на показалеца `Weak` до [`Rc`], забавяне на отпадането на вътрешната стойност, ако е успешно.
    ///
    ///
    /// Връща [`None`], ако вътрешната стойност оттогава е отпаднала.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Унищожи всички силни указатели.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Получава броя на силните указатели (`Rc`), сочещи към това разпределение.
    ///
    /// Ако `self` е създаден с помощта на [`Weak::new`], това ще върне 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Получава броя на указателите `Weak`, сочещи към това разпределение.
    ///
    /// Ако не останат силни указатели, това ще върне нула.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // извадете неявния слаб ptr
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Връща `None`, когато указателят е висящ и няма разпределен `RcBox`, (т.е. когато този `Weak` е създаден от `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Внимаваме да *не* създаваме препратка, покриваща полето "data", тъй като полето може да бъде едновременно мутирано (например, ако последният `Rc` бъде изпуснат, полето с данни ще бъде изпуснато на място).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Връща `true`, ако двете " слаби` сочат към едно и също разпределение (подобно на [`ptr::eq`]), или ако и двете не сочат към никакво разпределение (защото са създадени с `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Тъй като това сравнява указателите, това означава, че `Weak::new()` ще се изравнят помежду си, въпреки че те не сочат към никакво разпределение.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Сравняване на `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Изпуска показалеца `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Не печата нищо
    /// drop(foo);        // Отпечатва "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // слабият брой започва от 1 и ще стигне до нула само ако всички силни указатели са изчезнали.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Прави клон на показалеца `Weak`, който сочи към същото разпределение.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Конструира нов `Weak<T>`, като разпределя памет за `T`, без да го инициализира.
    /// Извикването на [`upgrade`] на връщаната стойност винаги дава [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Проверихме_добавяне тук, за да се справим безопасно с mem::forget.В частност
// ако сте mem::forget Rcs (или Weaks), броят на реф. може да се препълни и след това можете да освободите разпределението, докато съществуват неизплатени Rcs (или Weaks).
//
// Прекъсваме, защото това е толкова дегенеративен сценарий, че не ни интересува какво се случва-никоя истинска програма никога не би трябвало да преживява това.
//
// Това трябва да има незначителни режийни разходи, тъй като всъщност не е нужно да клонирате толкова много в Rust благодарение на собствеността и семантиката на преместване.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Искаме да прекъснем при преливане, вместо да изпуснем стойността.
        // Броят на референциите никога няма да бъде нула, когато това се извика;
        // въпреки това тук вмъкваме прекъсване, за да намекнем LLVM за иначе пропусната оптимизация.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Искаме да прекъснем при преливане, вместо да изпуснем стойността.
        // Броят на референциите никога няма да бъде нула, когато това се извика;
        // въпреки това тук вмъкваме прекъсване, за да намекнем LLVM за иначе пропусната оптимизация.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Вземете отместването в рамките на `RcBox` за полезния товар зад указател.
///
/// # Safety
///
/// Указателят трябва да сочи към (и да има валидни метаданни за) по-рано валиден екземпляр на T, но T е позволено да бъде отпаднал.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Подравнете неоразмерената стойност в края на RcBox.
    // Тъй като RcBox е repr(C), той винаги ще бъде последното поле в паметта.
    // БЕЗОПАСНОСТ: тъй като единствените неразмерени типове са резени, обекти Z0 смут
    // и външни типове, изискването за безопасност на входа в момента е достатъчно, за да задоволи изискванията на align_of_val_raw;това е подробност за изпълнението на езика, на която не може да се разчита извън std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}