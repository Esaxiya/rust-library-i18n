//! Изглед с динамичен размер в непрекъсната последователност, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Резените са изглед към блок памет, представен като указател и дължина.
//!
//! ```
//! // нарязване на Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // принуждаване на масив към парче
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Резените могат да се променят или да се споделят.
//! Споделеният тип слайс е `&[T]`, докато изменяемият тип слайс е `&mut [T]`, където `T` представлява типа елемент.
//! Например можете да мутирате блока памет, към който сочи изменяем фрагмент:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Ето някои от нещата, които съдържа този модул:
//!
//! ## Structs
//!
//! Има няколко структури, които са полезни за срезове, като [`Iter`], който представлява итерация върху парче.
//!
//! ## Trait Изпълнения
//!
//! Има няколко реализации на общи traits за резени.Някои примери включват:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], за резени, чийто тип елемент е [`Eq`] или [`Ord`].
//! * [`Hash`] - за филийки, чийто тип елемент е [`Hash`].
//!
//! ## Iteration
//!
//! Резените изпълняват `IntoIterator`.Итераторът дава препратки към елементите на среза.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Изменяемият фрагмент дава изменяеми препратки към елементите:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Този итератор дава изменяеми препратки към елементите на среза, така че докато типът на елемента на среза е `i32`, типът на елемента на итератора е `&mut i32`.
//!
//!
//! * [`.iter`] и [`.iter_mut`] са изричните методи за връщане на итераторите по подразбиране.
//! * Други методи, които връщат итератори, са [`.split`], [`.splitn`], [`.chunks`], [`.windows`] и други.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Много от използванията в този модул се използват само в тестовата конфигурация.
// По-чисто е просто да изключите предупреждението unused_imports, отколкото да ги поправите.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Основни методи за удължаване на среза
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) необходими за внедряването на макрос `vec!` по време на тестване NB, вижте модула `hack` в този файл за повече подробности.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) необходими за внедряването на `Vec::clone` по време на тестване NB, вижте модула `hack` в този файл за повече подробности.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Тъй като cfg(test) `impl [T]` не е наличен, тези три функции всъщност са методи, които са в `impl [T]`, но не и в `core::slice::SliceExt`, трябва да предоставим тези функции за теста `test_permutations`
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Не трябва да добавяме вграден атрибут към това, тъй като това се използва най-вече в макрос `vec!` и причинява регресия на перф.
    // Вижте #71204 за дискусия и резултати от представянето.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // елементи бяха маркирани инициализирани в цикъла по-долу
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) е необходимо за LLVM да премахне проверки за граници и има по-добър кодген от zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec беше разпределен и инициализиран по-горе поне на тази дължина.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // разпределени по-горе с капацитет `s` и инициализирайте до `s.len()` в ptr::copy_to_non_overlapping по-долу.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Сортира парчето.
    ///
    /// Този сортиране е стабилен (т.е. не пренарежда равни елементи) и *O*(*n*\*log(* n*)) най-лошия случай.
    ///
    /// Когато е приложимо, се предпочита нестабилното сортиране, тъй като обикновено е по-бързо от стабилното сортиране и не разпределя спомагателна памет.
    /// Вижте [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Текущо изпълнение
    ///
    /// Настоящият алгоритъм е адаптивно, итеративно сортиране на сливания, вдъхновено от [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Той е проектиран да бъде много бърз в случаите, когато слайсът е почти сортиран или се състои от две или повече сортирани последователности, обединени една след друга.
    ///
    ///
    /// Също така, той разпределя временно съхранение наполовина от размера на `self`, но за кратки срезове вместо това се използва неразпределително сортиране на вмъкване.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Сортира среза с функция за сравнение.
    ///
    /// Този сортиране е стабилен (т.е. не пренарежда равни елементи) и *O*(*n*\*log(* n*)) най-лошия случай.
    ///
    /// Функцията за сравнение трябва да дефинира общо подреждане на елементите в среза.Ако подреждането не е общо, редът на елементите е неуточнен.
    /// Поръчката е обща поръчка, ако е (за всички `a`, `b` и `c`):
    ///
    /// * общо и антисиметрично: точно едно от `a < b`, `a == b` или `a > b` е вярно, и
    /// * преходен, `a < b` и `b < c` предполага `a < c`.Същото трябва да важи както за `==`, така и за `>`.
    ///
    /// Например, докато [`f64`] не прилага [`Ord`], защото `NaN != NaN`, ние можем да използваме `partial_cmp` като наша функция за сортиране, когато знаем, че отрязъкът не съдържа `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Когато е приложимо, се предпочита нестабилното сортиране, тъй като обикновено е по-бързо от стабилното сортиране и не разпределя спомагателна памет.
    /// Вижте [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Текущо изпълнение
    ///
    /// Настоящият алгоритъм е адаптивно, итеративно сортиране на сливания, вдъхновено от [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Той е проектиран да бъде много бърз в случаите, когато слайсът е почти сортиран или се състои от две или повече сортирани последователности, обединени една след друга.
    ///
    /// Също така, той разпределя временно съхранение наполовина от размера на `self`, но за кратки срезове вместо това се използва неразпределително сортиране на вмъкване.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // обратно сортиране
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Сортира среза с функция за извличане на ключ.
    ///
    /// Този сортиране е стабилен (т.е. не пренарежда равни елементи) и *O*(*m*\* * n *\* log(*n*)) най-лошия случай, където ключовата функция е *O*(*m*).
    ///
    /// За скъпи ключови функции (напр
    /// функции, които не са лесен достъп до свойства или основни операции), [`sort_by_cached_key`](slice::sort_by_cached_key) вероятно ще бъде значително по-бърз, тъй като не преизчислява ключовете на елементите.
    ///
    ///
    /// Когато е приложимо, се предпочита нестабилното сортиране, тъй като обикновено е по-бързо от стабилното сортиране и не разпределя спомагателна памет.
    /// Вижте [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Текущо изпълнение
    ///
    /// Настоящият алгоритъм е адаптивно, итеративно сортиране на сливания, вдъхновено от [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Той е проектиран да бъде много бърз в случаите, когато слайсът е почти сортиран или се състои от две или повече сортирани последователности, обединени една след друга.
    ///
    /// Също така, той разпределя временно съхранение наполовина от размера на `self`, но за кратки срезове вместо това се използва неразпределително сортиране на вмъкване.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Сортира среза с функция за извличане на ключ.
    ///
    /// По време на сортирането ключовата функция се извиква само веднъж за елемент.
    ///
    /// Този сортиране е стабилен (т.е. не пренарежда равни елементи) и *O*(*m*\* * n *+* n *\* log(*n*)) най-лошия случай, където ключовата функция е *O*(*m*) .
    ///
    /// За прости ключови функции (например функции, които са достъп до свойства или основни операции), [`sort_by_key`](slice::sort_by_key) вероятно ще бъде по-бърз.
    ///
    /// # Текущо изпълнение
    ///
    /// Настоящият алгоритъм се основава на [pattern-defeating quicksort][pdqsort] от Орсън Питърс, който комбинира бързия среден случай на рандомизирана бърза сортировка с бързия най-лош случай на купчина, като същевременно постига линейно време на резени с определени модели.
    /// Той използва известна рандомизация, за да избегне дегенеративни случаи, но с фиксиран seed, за да осигури винаги детерминирано поведение.
    ///
    /// В най-лошия случай алгоритъмът разпределя временно съхранение в `Vec<(K, usize)>` дължината на среза.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Помощен макрос за индексиране на нашия vector по възможно най-малкия тип, за да се намали разпределението.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Елементите на `indices` са уникални, тъй като са индексирани, така че всякакъв вид ще бъде стабилен по отношение на оригиналния парче.
                // Тук използваме `sort_unstable`, защото изисква по-малко разпределение на паметта.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Копира `self` в нов `Vec`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Тук `s` и `x` могат да бъдат модифицирани независимо.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Копира `self` в нов `Vec` с разпределител.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Тук `s` и `x` могат да бъдат модифицирани независимо.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // Забележка, вижте модула `hack` в този файл за повече подробности.
        hack::to_vec(self, alloc)
    }

    /// Преобразува `self` в vector без клонинги или разпределение.
    ///
    /// Полученият vector може да се преобразува обратно в кутия чрез `Vec<T>е метод `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` вече не може да се използва, защото е преобразуван в `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // Забележка, вижте модула `hack` в този файл за повече подробности.
        hack::into_vec(self)
    }

    /// Създава vector чрез повтаряне на резен `n` пъти.
    ///
    /// # Panics
    ///
    /// Тази функция ще panic, ако капацитетът препълни.
    ///
    /// # Examples
    ///
    /// Основна употреба:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// A panic при преливане:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Ако `n` е по-голям от нула, той може да бъде разделен като `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` е числото, представено от най-левия '1' бит на `n`, а `rem` е останалата част от `n`.
        //
        //

        // Използване на `Vec` за достъп до `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` повторението се извършва чрез удвояване на `buf` `expn`-пъти.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Ако `m > 0`, остават битове до най-левия '1'.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` има капацитет от `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) повторение се извършва чрез копиране на първите повторения `rem` от самия `buf`.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Това не се припокрива от `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` е равно на `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Изравнява парче `T` в единична стойност `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Изравнява парче `T` в единична стойност `Self::Output`, като поставя даден разделител между всеки.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Изравнява парче `T` в единична стойност `Self::Output`, като поставя даден разделител между всеки.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Връща vector, съдържащ копие на този отрязък, където всеки байт се преобразува в неговия ASCII еквивалент с главни букви.
    ///
    ///
    /// ASCII буквите 'a' до 'z' се преобразуват в 'A' до 'Z', но буквите извън ASCII остават непроменени.
    ///
    /// За да заглавите стойността на място, използвайте [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Връща vector, съдържащ копие на този отрязък, където всеки байт се преобразува в неговия ASCII еквивалент с малки букви.
    ///
    ///
    /// ASCII буквите 'A' до 'Z' се преобразуват в 'a' до 'z', но буквите извън ASCII остават непроменени.
    ///
    /// За да намалите стойността на място, използвайте [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Разширение traits за срезове за конкретни видове данни
////////////////////////////////////////////////////////////////////////////////

/// Помощник Portrait за [`[T]: : concat`](срез::concat).
///
/// Note: параметърът тип `Item` не се използва в този Portrait, но позволява импулсите да бъдат по-общи.
/// Без него получаваме тази грешка:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Това е така, защото може да съществуват типове `V` с множество импулси на `Borrow<[_]>`, така че да се прилагат множество типове `T`:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Полученият тип след конкатенация
    type Output;

    /// Внедряване на [`[T]: : concat`](slice::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Помощник Portrait за [`[T]: : join`](слайс::присъединяване)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Полученият тип след конкатенация
    type Output;

    /// Внедряване на [`[T]: : join`](slice::join)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Стандартни изпълнения на Portrait за срезове
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // пуснете всичко в целта, което няма да бъде заменено
        target.truncate(self.len());

        // target.len <= self.len поради съкращението по-горе, така че резените тук винаги са в границите.
        //
        let (init, tail) = self.split_at(target.len());

        // използвайте повторно съдържащите се стойности allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Вмъква `v[0]` в предварително сортирана последователност `v[1..]`, така че целият `v[..]` да бъде сортиран.
///
/// Това е интегралната подпрограма на сортирането при вмъкване.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Има три начина за прилагане на вмъкването тук:
            //
            // 1. Разменяйте съседни елементи, докато първият стигне до крайната си цел.
            //    По този начин обаче копираме данни около повече, отколкото е необходимо.
            //    Ако елементите са големи структури (скъпи за копиране), този метод ще бъде бавен.
            //
            // 2. Повтаряйте, докато се намери правилното място за първия елемент.
            // След това преместете елементите, които го наследяват, за да освободите място за него и накрая го поставете в останалия отвор.
            // Това е добър метод.
            //
            // 3. Копирайте първия елемент във временна променлива.Повтаряйте, докато се намери подходящото място за него.
            // Докато вървим, копирайте всеки преминат елемент в слота пред него.
            // И накрая, копирайте данните от временната променлива в останалата дупка.
            // Този метод е много добър.
            // Бенчмарковете показаха малко по-добро представяне, отколкото при втория метод.
            //
            // Всички методи бяха сравнени, а третият показа най-добри резултати.Затова избрахме този.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Междинното състояние на процеса на вмъкване винаги се проследява от `hole`, който служи за две цели:
            // 1. Защитава целостта на `v` от panics в `is_less`.
            // 2. В края запълва останалата дупка в `v`.
            //
            // Panic безопасност:
            //
            // Ако `is_less` panics в който и да е момент по време на процеса, `hole` ще падне и ще запълни дупката в `v` с `tmp`, като по този начин гарантира, че `v` все още държи всеки обект, който първоначално е държал точно веднъж.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` се изпуска и по този начин копира `tmp` в останалата дупка в `v`.
        }
    }

    // При изпускане копира от `src` в `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Обединява не намаляващите тиражи `v[..mid]` и `v[mid..]`, използвайки `buf` като временно съхранение, и съхранява резултата в `v[..]`.
///
/// # Safety
///
/// Двата среза не трябва да са празни и `mid` трябва да бъде в граници.
/// Буферът `buf` трябва да е достатъчно дълъг, за да съхранява копие на по-късия фрагмент.
/// Също така `T` не трябва да бъде от нулев размер.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Процесът на сливане първо копира по-краткото изпълнение в `buf`.
    // След това проследява ново копираното изпълнение и по-продължителното изпълнение напред (или назад), сравнявайки следващите им непотребени елементи и копирайки по-малкия (или по-големия) в `v`.
    //
    // Веднага след като по-краткият цикъл е напълно изразходван, процесът е завършен.Ако по-дългият пробег се консумира първо, тогава трябва да копираме всичко, което е останало от по-късия пробег, в останалата дупка в `v`.
    //
    // Междинното състояние на процеса винаги се проследява от `hole`, който служи за две цели:
    // 1. Защитава целостта на `v` от panics в `is_less`.
    // 2. Запълва останалата дупка в `v`, ако по-дългият цикъл се консумира първи.
    //
    // Panic безопасност:
    //
    // Ако `is_less` panics в който и да е момент по време на процеса, `hole` ще падне и ще запълни дупката в `v` с неконсумирания диапазон в `buf`, като по този начин гарантира, че `v` все още държи всеки обект, който първоначално е държал точно веднъж.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Лявото бягане е по-кратко.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Първоначално тези указатели сочат началото на техните масиви.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Консумирайте по-малката страна.
            // Ако е равно, предпочитайте левия ход, за да запазите стабилността.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Правилното бягане е по-кратко.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Първоначално тези указатели сочат краищата на техните масиви.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Консумирайте по-голямата страна.
            // Ако е равно, предпочитайте правилния пробег, за да запазите стабилността.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // И накрая, `hole` отпада.
    // Ако по-краткият цикъл не е бил изразходван напълно, всичко, което е останало от него, сега ще бъде копирано в дупката в `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // При изпускане копира диапазона `start..end` в `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` не е тип с нулев размер, така че е добре да се разделя на неговия размер.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Това обединяване сортира назаем някои (но не всички) идеи от TimSort, което е подробно описано [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// Алгоритъмът идентифицира строго низходящи и неспускащи се последователности, които се наричат естествени пробези.Има куп изчакващи изпълнения, които все още не са обединени.
/// Всяко новооткрито изпълнение се изтласква върху стека и след това няколко двойки съседни тиражи се обединяват, докато тези два инварианта бъдат удовлетворени:
///
/// 1. за всеки `i` в `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. за всеки `i` в `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Инвариантите гарантират, че общото време на работа е *O*(*n*\*log(* n*)) най-лошия случай.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Резени до тази дължина се сортират чрез сортиране с вмъкване.
    const MAX_INSERTION: usize = 20;
    // Много кратки пробези се удължават с помощта на сортиране на вмъкване, за да обхванат поне толкова много елементи.
    const MIN_RUN: usize = 10;

    // Сортирането няма смислено поведение при типове с нулев размер.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Кратките масиви се сортират на място чрез вмъкване, за да се избегнат разпределения.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Разпределете буфер, който да използвате като скреч памет.Запазваме дължината 0, за да можем да съхраняваме в нея плитки копия на съдържанието на `v`, без да рискуваме двигателите да работят на копия, ако `is_less` panics.
    //
    // При обединяване на два сортирани пробега, този буфер съдържа копие на по-късото изпълнение, което винаги ще има дължина най-много `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // За да идентифицираме естествените пробези в `v`, ние го обхождаме назад.
    // Това може да изглежда странно решение, но помислете за факта, че сливанията по-често отиват в обратната посока (forwards).
    // Според бенчмарковете сливането напред е малко по-бързо от сливането назад.
    // В заключение, идентифицирането на тиражи чрез обхождане назад подобрява производителността.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Намерете следващия естествен пробег и го обърнете, ако е строго низходящ.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Вмъкнете още няколко елемента в изпълнението, ако е твърде кратко.
        // Сортирането при вмъкване е по-бързо от сортирането при сливане на кратки последователности, така че това значително подобрява производителността.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Натиснете този ход върху стека.
        runs.push(Run { start, len: end - start });
        end = start;

        // Обединете няколко двойки съседни писти, за да задоволите инвариантите.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // И накрая, точно един пробег трябва да остане в стека.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Проучва стека от изпълнения и идентифицира следващата двойка от изпълнения, които да се слеят.
    // По-конкретно, ако `Some(r)` бъде върнат, това означава, че `runs[r]` и `runs[r + 1]` трябва да бъдат обединени след това.
    // Ако алгоритъмът вместо това продължи да изгражда ново изпълнение, се връща `None`.
    //
    // TimSort е скандален със своите бъги реализации, както е описано тук:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Същността на историята е: трябва да наложим инвариантите в четирите най-добри писти на стека.
    // Прилагането им само на първите три не е достатъчно, за да се гарантира, че инвариантите ще продължат да се задържат за *всички* писти в стека.
    //
    // Тази функция правилно проверява инвариантите за четирите най-добри изпълнения.
    // Освен това, ако най-горното изпълнение започва с индекс 0, то винаги ще изисква операция за сливане, докато стекът бъде напълно свит, за да завърши сортирането.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}