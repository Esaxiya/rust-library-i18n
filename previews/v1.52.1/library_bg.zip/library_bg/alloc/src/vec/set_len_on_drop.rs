// Задайте дължината на vec, когато стойността на `SetLenOnDrop` излезе извън обхвата.
//
// Идеята е: Полето за дължина в SetLenOnDrop е локална променлива, която оптимизаторът ще види, не псевдоним на никакви магазини през указателя за данни на Vec.
// Това е решение за проблема с анализа на псевдоними #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}