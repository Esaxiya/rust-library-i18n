use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Специализация Portrait, използвана за Vec::from_iter
///
/// ## Графика на делегиране:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Често срещан случай е предаването на vector във функция, която веднага се събира отново в vector.
        // Можем да направим късо съединение, ако IntoIter изобщо не е усъвършенстван.
        // Когато е усъвършенстван Ние също можем да използваме паметта отново и да преместим данните отпред.
        // Но ние го правим само когато полученият Vec не би имал по-неизползван капацитет, отколкото би го създал чрез общото изпълнение на FromIterator.
        //
        // Това ограничение не е строго необходимо, тъй като поведението на разпределение на Vec е умишлено неуточнено.
        // Но това е консервативен избор.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // трябва да делегира на spec_extend(), тъй като самият extend() делегира на spec_from за празни Vecs
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Това използва `iterator.as_slice().to_vec()`, тъй като spec_extend трябва да предприеме повече стъпки, за да разсъждава относно крайния капацитет + дължина и по този начин да свърши повече работа.
// `to_vec()` директно разпределя правилното количество и го попълва точно.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): с cfg(test) присъщият метод `[T]::to_vec`, който се изисква за дефиницията на този метод, не е наличен.
    // Вместо това използвайте функцията `slice::to_vec`, която е достъпна само с cfg(test) NB, вижте модула slice::hack в slice.rs за повече информация
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}