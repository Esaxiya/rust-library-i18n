use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// Итератор, който използва затваряне, за да определи дали даден елемент трябва да бъде премахнат.
///
/// Тази структура е създадена от [`Vec::drain_filter`].
/// Вижте документацията му за повече.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// Индексът на елемента, който ще бъде проверен при следващото повикване към `next`.
    pub(super) idx: usize,
    /// Броят на елементите, които до момента са източени (removed).
    pub(super) del: usize,
    /// Оригиналната дължина на `vec` преди източване.
    pub(super) old_len: usize,
    /// Тестовият предикат на филтъра.
    pub(super) pred: F,
    /// Флаг, който указва panic е възникнал в предикатния тест на филтъра.
    /// Това се използва като намек в изпълнението на капките, за да се предотврати консумацията на останалата част от `DrainFilter`.
    /// Всички необработени елементи ще бъдат преместени обратно в `vec`, но никакви други елементи няма да бъдат изпуснати или тествани от предикатния филтър.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// Връща препратка към основния разпределител.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Актуализирайте индекса *след* извикването на предиката.
                // Ако индексът се актуализира преди и предикатът panics, елементът в този индекс ще изтече.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // Това е доста объркано състояние и всъщност няма очевидно правилно нещо.
                        // Не искаме да продължаваме да се опитваме да изпълним `pred`, затова просто превключваме всички необработени елементи и казваме на vec, че те все още съществуват.
                        //
                        // Обратното превключване е необходимо, за да се предотврати двойно изпускане на последния успешно източен елемент преди panic в предиката.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Опитайте да използвате всички останали елементи, ако предикатът на филтъра все още не е изпаднал в паника.
        // Ще сменим всички останали елементи, независимо дали вече сме се паникьосали или ако потреблението тук е panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}