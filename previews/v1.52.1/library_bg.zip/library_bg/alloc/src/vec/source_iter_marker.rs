use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Маркер за специализация за събиране на итератор на конвейер във Vec при повторно използване на разпределението на източника, т.е.
/// изпълнение на тръбопровода на място.
///
/// Родителят SourceIter Portrait е необходим за специализиращата функция за достъп до разпределението, което трябва да се използва повторно.
/// Но не е достатъчно специализацията да е валидна.
/// Вижте допълнителни граници на импл.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-вътрешните SourceIter/InPlaceIterable traits се изпълняват само от вериги на адаптер <Adapter<Adapter<IntoIter>>> (всички притежавани от core/std).
// Допълнителните граници на реализациите на адаптера (извън `impl<I: Trait> Trait for Adapter<I>`) зависят само от други traits, вече маркирани като специализация traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. маркерът не зависи от живота на доставените от потребителя типове.Модулирайте дупката за копиране, от която вече зависят няколко други специализации.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Допълнителни изисквания, които не могат да бъдат изразени чрез Portrait bounds.Вместо това разчитаме на const eval:
        // а) няма ZST, тъй като няма да има разпределение за повторна употреба и аритметиката на указателя би panic b) съвпадение на размера, както се изисква от договора на Alloc в) съвпадение на подравняванията, както се изисква от договора на Alloc
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // отстъпление към по-общи реализации
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // използвайте try-fold от
        // - той се векторизира по-добре за някои итераторни адаптери
        // - за разлика от повечето вътрешни итерационни методи, той отнема само &mut самостоятелно
        // - той ни позволява да прекараме указателя за запис през вътрешностите му и да го върнем накрая
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // итерацията е успяла, не изпускайте главата
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // проверете дали договорът SourceIter е бил спазен: ако не са, ние дори не можем да стигнем до този момент
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // проверете InPlaceIterable договор.Това е възможно само ако итераторът изобщо е усъвършенствал указателя на източника.
        // Ако използва непроверен достъп чрез TrustedRandomAccess, тогава указателят на източника ще остане в първоначалната си позиция и не можем да го използваме като справка
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // пуснете всички останали стойности в опашката на източника, но предотвратете падането на самото разпределение, след като IntoIter излезе извън обхвата, ако отпадне panics, тогава ние също изпускаме всички елементи, събрани в dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // договорът InPlaceIterable не може да бъде проверен точно тук, тъй като try_fold има изключителна препратка към указателя на източника, всичко, което можем да направим, е да проверим дали все още е в обхват
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}