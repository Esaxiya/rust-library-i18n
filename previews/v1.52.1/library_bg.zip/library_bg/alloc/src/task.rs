#![stable(feature = "wake_trait", since = "1.51.0")]
//! Типове и Traits за работа с асинхронни задачи.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Изпълнението на събуждане на задача върху изпълнител.
///
/// Този Portrait може да се използва за създаване на [`Waker`].
/// Изпълнителят може да дефинира изпълнение на този Portrait и да го използва, за да конструира Waker, за да премине към задачите, които се изпълняват на този изпълнител.
///
/// Този Portrait е безопасна за паметта и ергономична алтернатива на конструирането на [`RawWaker`].
/// Той поддържа общия дизайн на изпълнителя, при който данните, използвани за събуждане на задача, се съхраняват в [`Arc`].
/// Някои изпълнители (особено тези за вградени системи) не могат да използват този API, поради което [`RawWaker`] съществува като алтернатива за тези системи.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Основна функция `block_on`, която приема future и го изпълнява до завършване на текущата нишка.
///
/// **Note:** Този пример търгува с коректност за простота.
/// За да се предотвратят блокировки, внедряванията от производствен клас също ще трябва да обработват междинни повиквания към `thread::unpark`, както и вложени извиквания.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Waker, който събужда текущата нишка при извикване.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Изпълнете future до завършване на текущата нишка.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Закачете future, за да може да бъде анкетиран.
///     let mut fut = Box::pin(fut);
///
///     // Създайте нов контекст, който да бъде предаден на future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Стартирайте future до завършване.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Събудете тази задача.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Събудете тази задача, без да консумирате будника.
    ///
    /// Ако изпълнител поддържа по-евтин начин за събуждане, без да консумира waker, той трябва да замени този метод.
    /// По подразбиране той клонира [`Arc`] и извиква [`wake`] в клонинга.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // БЕЗОПАСНОСТ: Това е безопасно, защото raw_waker безопасно конструира
        // RawWaker от Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Тази частна функция за конструиране на RawWaker се използва, а не
// вграждайки това в `From<Arc<W>> for RawWaker` impl, за да се гарантира, че безопасността на `From<Arc<W>> for Waker` не зависи от правилното изпращане на Portrait, вместо това и двата импулса извикват тази функция директно и изрично.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Увеличете референтния брой на дъгата, за да я клонирате.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Събудете се по стойност, премествайки дъгата във функцията Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Събудете се по справка, увийте waker-a в ManuallyDrop, за да избегнете изпускането му
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Намалете референтния брой на Arc при падане
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}