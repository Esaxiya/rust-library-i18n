//! # Библиотеката за разпределение и колекции на ядрото Rust
//!
//! Тази библиотека предоставя интелигентни указатели и колекции за управление на стойности, разпределени в купчина.
//!
//! Тази библиотека, подобно на libcore, обикновено не трябва да се използва директно, тъй като нейното съдържание се реекспортира в [`std` crate](../std/index.html).
//! Crates, които използват атрибута `#![no_std]`, обаче обикновено не зависят от `std`, така че вместо това ще използват този crate.
//!
//! ## Стойни стойности
//!
//! Типът [`Box`] е тип интелигентен указател.Собственикът на [`Box`] може да бъде само един и той може да реши да мутира съдържанието, което живее в купчината.
//!
//! Този тип може да се изпраща ефективно между нишките, тъй като размерът на стойност `Box` е същият като този на показалеца.
//! Дървовидните структури от данни често се изграждат с полета, тъй като всеки възел често има само един собственик, родителя.
//!
//! ## Референтни преброени указатели
//!
//! Типът [`Rc`] е не-безопасен тип указател с преброен референтен номер, предназначен за споделяне на памет в рамките на нишка.
//! Указателят [`Rc`] обгръща тип `T` и позволява достъп само до `&T`, споделена препратка.
//!
//! Този тип е полезен, когато наследената мутабилност (като например използване на [`Box`]) е твърде ограничаваща за приложение и често се сдвоява с типовете [`Cell`] или [`RefCell`], за да позволи мутация.
//!
//!
//! ## Атомно преброени указатели
//!
//! Типът [`Arc`] е еквивалентът на безопасността на резбата на типа [`Rc`].Той предоставя същата функционалност на [`Rc`], освен че изисква съдържащият се тип `T` да бъде споделен.
//! Освен това [`Arc<T>`][`Arc`] сам по себе си може да се предаде, докато [`Rc<T>`][`Rc`] не.
//!
//! Този тип позволява споделен достъп до съдържащите се данни и често се сдвоява с примитиви за синхронизация като mutexes, за да позволи мутация на споделени ресурси.
//!
//! ## Collections
//!
//! В тази библиотека са дефинирани изпълненията на най-често срещаните структури от данни с общо предназначение.Те се реекспортират през [standard collections library](../std/collections/index.html).
//!
//! ## Куп интерфейси
//!
//! Модулът [`alloc`](alloc/index.html) дефинира интерфейса на ниско ниво към глобалния разпределител по подразбиране.Той не е съвместим с API за разпределение на libc.
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// Технически това е грешка в rustdoc: rustdoc вижда, че документацията за блокове `#[lang = slice_alloc]` е за `&[T]`, която също има документация, използваща тази функция в `core`, и се ядосва, че функцията-gate не е активирана.
// В идеалния случай това не би проверило функцията за документи за други crates, но тъй като това може да се появи само за елементи от езика, изглежда не си струва да се поправя.
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// Разрешаване на тестване на тази библиотека

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// Модул с вътрешни макроси, използвани от други модули (трябва да бъдат включени преди други модули).
#[macro_use]
mod macros;

// Купчини, предвидени за стратегии за разпределение на ниско ниво

pub mod alloc;

// Примитивни типове, използващи купчините по-горе

// Необходимо е да дефинирате условно мода от `boxed.rs`, за да избегнете дублиране на lang-елементите при вграждане в тест cfg;но също така трябва да позволите на кода да има декларации `use boxed::Box;`.
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}