# `rustc-std-workspace-std` crate

Вижте документацията за `rustc-std-workspace-core` crate.