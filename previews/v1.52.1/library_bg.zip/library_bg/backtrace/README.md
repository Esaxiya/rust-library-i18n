# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Библиотека за придобиване на обратни следи по време на изпълнение за Rust.
Тази библиотека има за цел да подобри поддръжката на стандартната библиотека, като предоставя програмен интерфейс за работа, но също така поддържа просто лесно отпечатване на текущата обратна следа като panics на libstd.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

За просто заснемане на обратна следа и отлагане на справянето с нея до по-късно време, можете да използвате типа `Backtrace` от най-високо ниво.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Ако обаче искате повече суров достъп до действителната функционалност за проследяване, можете да използвате функциите `trace` и `resolve` директно.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Разрешете този указател на инструкция към име на символ
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // продължете към следващия кадър
    });
}
```

# License

Този проект е лицензиран под някоя от

 * Apache лиценз, версия 2.0, ([LICENSE-APACHE](LICENSE-APACHE) или http://www.apache.org/licenses/LICENSE-2.0)
 * MIT лиценз ([LICENSE-MIT](LICENSE-MIT) или http://opensource.org/licenses/MIT)

по ваш избор.

### Contribution

Освен ако изрично не посочите друго, всеки принос, умишлено изпратен за включване във backtrace-rs от вас, както е дефинирано в лиценза Apache-2.0, ще бъде двойно лицензиран, както по-горе, без никакви допълнителни условия или условия.







