#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Форматиращ инструмент за обратни следи.
///
/// Този тип може да се използва за отпечатване на обратна следа, независимо откъде идва самата обратна следа.
/// Ако имате тип `Backtrace`, тогава неговата реализация `Debug` вече използва този формат за печат.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Стиловете на печат, които можем да отпечатаме
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Отпечатва терзерна обратна следа, която в идеалния случай съдържа само съответна информация
    Short,
    /// Отпечатва обратна следа, която съдържа цялата възможна информация
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Създайте нов `BacktraceFmt`, който ще записва изхода към предоставения `fmt`.
    ///
    /// Аргументът `format` ще контролира стила, в който се отпечатва обратната следа, а аргументът `print_path` ще се използва за отпечатване на екземплярите на `BytesOrWideString` на имена на файлове.
    /// Самият този тип не прави никакъв печат на имена на файлове, но за това е необходимо това обратно извикване.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Отпечатва преамбюл за обратната следа, която ще бъде отпечатана.
    ///
    /// Това се изисква на някои платформи, за да могат обратните следи да бъдат напълно символизирани по-късно, и в противен случай това трябва да е първият метод, който извиквате след създаването на `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Добавя кадър към изхода за обратно проследяване.
    ///
    /// Този ангажимент връща RAII екземпляр на `BacktraceFrameFmt`, който може да се използва за реално отпечатване на кадър и при унищожаване ще увеличи брояча на кадрите.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Завършва изхода на обратното проследяване.
    ///
    /// Понастоящем това е не-операция, но е добавено за съвместимост на future с формати за обратно проследяване.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Понастоящем не е включено-включително този hook, за да се позволи добавяне на future.
        Ok(())
    }
}

/// Форматиращо устройство само за един кадър на обратна следа.
///
/// Този тип е създаден от функцията `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Отпечатва `BacktraceFrame` с този формат за кадри.
    ///
    /// Това ще отпечата рекурсивно всички копия на `BacktraceSymbol` в рамките на `BacktraceFrame`.
    ///
    /// # Необходими функции
    ///
    /// Тази функция изисква функцията `std` на `backtrace` crate да бъде активирана, а функцията `std` е активирана по подразбиране.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Отпечатва `BacktraceSymbol` в рамките на `BacktraceFrame`.
    ///
    /// # Необходими функции
    ///
    /// Тази функция изисква функцията `std` на `backtrace` crate да бъде активирана, а функцията `std` е активирана по подразбиране.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: това не е страхотно, че в крайна сметка не отпечатваме нищо
            // с не-utf8 имена на файлове.
            // За щастие почти всичко е utf8, така че това не трябва да е твърде лошо.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Отпечатва сурово проследени `Frame` и `Symbol`, обикновено от необработените обратни извиквания на този crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Добавя суров кадър към изхода на обратното проследяване.
    ///
    /// Този метод, за разлика от предишния, взема суровите аргументи, в случай че те са източници от различни местоположения.
    /// Имайте предвид, че това може да бъде извикано няколко пъти за един кадър.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Добавя суров кадър към изхода за обратно проследяване, включително информация за колона.
    ///
    /// Този метод, както и предишния, взема суровите аргументи, в случай че те са източници от различни местоположения.
    /// Имайте предвид, че това може да бъде извикано няколко пъти за един кадър.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia не е в състояние да символизира в рамките на един процес, така че има специален формат, който може да се използва за символизиране по-късно.
        // Отпечатайте това, вместо да печатате адреси в нашия собствен формат тук.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Няма нужда да отпечатвате "null" кадри, това всъщност просто означава, че обратното проследяване на системата беше малко нетърпеливо да проследи назад много далеч.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // За да намалим размера на TCB в анклава Sgx, не искаме да прилагаме функционалност за разделителна способност на символи.
        // По-скоро можем да отпечатаме отместването на адреса тук, което по-късно може да бъде картографирано, за да коригира функцията.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Отпечатайте индекса на кадъра, както и незадължителния указател за инструкции на кадъра.
        // Ако сме извън първия символ на тази рамка, ние просто отпечатваме подходящи интервали.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // След това напишете името на символа, като използвате алтернативно форматиране за повече информация, ако сме пълна обратна следа.
        // Тук също обработваме символи, които нямат име,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // И последно, разпечатайте номера filename/line, ако те са налични.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line се отпечатват на редове под името на символа, така че отпечатайте подходящо празно пространство, за да се подравним вдясно.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Делегирайте във вътрешния ни обратен разговор, за да отпечатате името на файла и след това отпечатайте номера на реда.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Добавете номер на колона, ако е наличен.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Ние се грижим само за първия символ на рамка
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}