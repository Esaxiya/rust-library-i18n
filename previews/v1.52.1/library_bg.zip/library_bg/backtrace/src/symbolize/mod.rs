use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Разрешете адрес към символ, като предадете символа на определеното затваряне.
///
/// Тази функция ще търси дадения адрес в области като местната таблица със символи, динамична таблица със символи или информация за отстраняване на грешки в DWARF (в зависимост от активираното изпълнение), за да намери символи, които да се получат.
///
///
/// Затварянето може да не се извика, ако не може да се извърши разделителна способност, а също така може да се извика повече от веднъж в случай на вградени функции.
///
/// Получените символи представляват изпълнението на посочения `addr`, връщайки двойки file/line за този адрес (ако е наличен).
///
/// Имайте предвид, че ако имате `Frame`, тогава се препоръчва да използвате функцията `resolve_frame` вместо тази.
///
/// # Необходими функции
///
/// Тази функция изисква функцията `std` на `backtrace` crate да бъде активирана, а функцията `std` е активирана по подразбиране.
///
/// # Panics
///
/// Тази функция се стреми никога да не panic, но ако `cb` предоставя panics, тогава някои платформи ще принудят двойно panic да прекрати процеса.
/// Някои платформи използват библиотека C, която вътрешно използва обратно извикване, което не може да се развие, така че паниката от `cb` може да предизвика прекъсване на процеса.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // погледнете само горната рамка
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Разрешете предишен кадър за заснемане на символ, предавайки символа на определеното затваряне.
///
/// Този функтин изпълнява същата функция като `resolve`, с изключение на това, че приема `Frame` като аргумент вместо адрес.
/// Това може да позволи на някои реализации на платформата за проследяване да предоставят по-точна информация за символи или информация за вградени рамки например.
///
/// Препоръчително е да използвате това, ако можете.
///
/// # Необходими функции
///
/// Тази функция изисква функцията `std` на `backtrace` crate да бъде активирана, а функцията `std` е активирана по подразбиране.
///
/// # Panics
///
/// Тази функция се стреми никога да не panic, но ако `cb` предоставя panics, тогава някои платформи ще принудят двойно panic да прекрати процеса.
/// Някои платформи използват библиотека C, която вътрешно използва обратно извикване, което не може да се развие, така че паниката от `cb` може да предизвика прекъсване на процеса.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // погледнете само горната рамка
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Стойностите на IP от кадрите на стека обикновено са (always?) инструкцията *след* повикването, което е действителната проследяване на стека.
// Символизирайки това, номерът на filename/line е с един напред и може би в празнотата, ако е близо до края на функцията.
//
// Изглежда, че това по принцип винаги е така на всички платформи, така че винаги изваждаме един от разрешен ip, за да го разрешим до предишната инструкция за повикване, вместо да бъде върната инструкцията.
//
//
// В идеалния случай не бихме направили това.
// В идеалния случай бихме искали повикващите API на `resolve` тук да направят ръчно -1 и да отчетат, че искат информация за местоположението за *предишната* инструкция, а не текущата.
// В идеалния случай бихме изложили и на `Frame`, ако наистина сме адресът на следващата инструкция или текущата.
//
// Засега обаче това е доста нишово притеснение, така че ние просто вътрешно винаги изваждаме едно.
// Потребителите трябва да продължат да работят и да постигат доста добри резултати, така че трябва да сме достатъчно добри.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Същото като `resolve`, само опасно, тъй като е несинхронизирано.
///
/// Тази функция няма гаранции за синхронизация, но е налична, когато функцията `std` на този crate не е компилирана.
/// Вижте функцията `resolve` за повече документация и примери.
///
/// # Panics
///
/// Вижте информация за `resolve` за предупреждения относно паниката на `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Същото като `resolve_frame`, само опасно, тъй като е несинхронизирано.
///
/// Тази функция няма гаранции за синхронизация, но е налична, когато функцията `std` на този crate не е компилирана.
/// Вижте функцията `resolve_frame` за повече документация и примери.
///
/// # Panics
///
/// Вижте информация за `resolve_frame` за предупреждения относно паниката на `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// Portrait, представляваща разделителната способност на символ във файл.
///
/// Този Portrait се получава като Portrait обект на затварянето, дадено на функцията `backtrace::resolve`, и на практика се изпраща, тъй като не е известно коя реализация стои зад него.
///
///
/// Символът може да даде контекстуална информация за функция, например име, име на файл, номер на ред, точен адрес и т.н.
/// Не винаги всяка информация е налична в символ, така че всички методи връщат `Option`.
///
///
pub struct Symbol {
    // TODO: тази обвързаност за цял живот трябва да се запази в крайна сметка до `Symbol`,
    // но това в момента е нова промяна.
    // Засега това е безопасно, тъй като `Symbol` се раздава само по справка и не може да бъде клониран.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Връща името на тази функция.
    ///
    /// Върнатата структура може да се използва за заявки за различни свойства относно името на символа:
    ///
    ///
    /// * Реализацията `Display` ще отпечата демонтирания символ.
    /// * Може да се получи необработената стойност на `str` на символа (ако е валидна utf-8).
    /// * Достъп до необработените байтове за името на символа.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Връща началния адрес на тази функция.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Връща необработеното име на файл като парче.
    /// Това е полезно главно за `no_std` среди.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Връща номера на колоната за мястото, където този символ се изпълнява в момента.
    ///
    /// Понастоящем само gimli предоставя стойност тук и дори тогава, само ако `filename` върне `Some`, и следователно е обект на подобни предупреждения.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Връща номера на реда, където този символ се изпълнява в момента.
    ///
    /// Тази възвръщаема стойност обикновено е `Some`, ако `filename` връща `Some` и следователно е обект на подобни предупреждения.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Връща името на файла, където е дефинирана тази функция.
    ///
    /// Понастоящем това е достъпно само когато се използва libbacktrace или gimli (напр
    /// unix платформи други) и когато се компилира двоичен файл с debuginfo.
    /// Ако нито едно от тези условия не е изпълнено, това вероятно ще върне `None`.
    ///
    /// # Необходими функции
    ///
    /// Тази функция изисква функцията `std` на `backtrace` crate да бъде активирана, а функцията `std` е активирана по подразбиране.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Може би анализиран C++ символ, ако анализирането на изкривения символ като Rust е неуспешно.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Не забравяйте да запазите този нулев размер, така че функцията `cpp_demangle` да няма разходи, когато е деактивирана.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Опаковка около име на символ, за да осигури ергономични аксесоари към демантираното име, необработените байтове, суровия низ и т.н.
///
// Позволете мъртъв код, когато функцията `cpp_demangle` не е активирана.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Създава ново име на символ от суровите базови байтове.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Връща суровото име на символа (mangled) като `str`, ако символът е валиден utf-8.
    ///
    /// Използвайте внедряването на `Display`, ако искате демонтираната версия.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Връща суровото име на символ като списък с байтове
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Това може да се отпечата, ако демонтираният символ всъщност не е валиден, така че обработете грешката тук грациозно, като не я разпространявате навън.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Опит за възстановяване на тази кеширана памет, използвана за символизиране на адреси.
///
/// Този метод ще се опита да освободи всички глобални структури от данни, които иначе са кеширани глобално или в нишката, които обикновено представляват анализирана информация за DWARF или подобна.
///
///
/// # Caveats
///
/// Въпреки че тази функция е винаги достъпна, тя всъщност не прави нищо за повечето внедрения.
/// Библиотеките като dbghelp или libbacktrace не предоставят средства за освобождаване на състоянието и управление на разпределената памет.
/// Засега характеристиката `gimli-symbolize` на този crate е единствената функция, при която тази функция има някакъв ефект.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}