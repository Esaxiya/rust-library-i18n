//! Стратегия за символизиране, използваща кода за разбор на DWARF в libbacktrace.
//!
//! Библиотеката libbacktrace C, обикновено разпространявана с gcc, поддържа не само генериране на обратна следа (която всъщност не използваме), но и символизиране на обратната следа и обработка на информация за отстраняване на грешки на джудже за неща като вградени рамки и какво ли още не.
//!
//!
//! Това е относително сложно поради много различни опасения тук, но основната идея е:
//!
//! * Първо се обаждаме на `backtrace_syminfo`.Това получава информация за символите от динамичната таблица със символи, ако можем.
//! * След това се обаждаме на `backtrace_pcinfo`.Това ще анализира debuginfo таблици, ако са налични, и ще ни позволи да възстановим информация за вградени рамки, имена на файлове, номера на редове и т.н.
//!
//! Има много хитрости за въвеждането на таблиците на джуджетата в libbacktrace, но се надяваме, че това не е краят на света и е достатъчно ясен, когато четете по-долу.
//!
//! Това е стратегията по подразбиране за символизиране за платформи, които не са MSVC и не OSX.В libstd обаче това е стратегията по подразбиране за OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Ако е възможно, предпочетете името `function`, което идва от debuginfo и обикновено може да бъде по-точно за вградени рамки например.
                // Ако това не е налице, върнете се към името на таблицата със символи, посочено в `symname`.
                //
                // Имайте предвид, че понякога `function` може да се почувства малко по-малко точен, например да бъде включен в списъка като `try<i32,closure>`, вместо `std::panicking::try::do_call`.
                //
                // Всъщност не е ясно защо, но като цяло името на `function` изглежда по-точно.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // не правете нищо засега
}

/// Тип на показалеца `data`, прехвърлен в `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // След като този обратно повикване бъде извикан от `backtrace_syminfo`, когато започнем да разрешаваме, отиваме по-нататък, за да се обадим на `backtrace_pcinfo`.
    // Функцията `backtrace_pcinfo` ще се консултира с информация за отстраняване на грешки и ще се опита да направи неща като възстановяване на информация за file/line, както и вградени рамки.
    // Имайте предвид обаче, че `backtrace_pcinfo` може да се провали или да не направи много, ако няма информация за отстраняване на грешки, така че ако това се случи, със сигурност ще извикаме обратно обаждане с поне един символ от `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Тип на показалеца `data`, прехвърлен в `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// API libbacktrace поддържа създаването на състояние, но не поддържа унищожаване на състояние.
// Аз лично приемам, че това означава, че държавата е създадена и след това ще живее вечно.
//
// Бих искал да регистрирам манипулатор at_exit(), който изчиства това състояние, но libbacktrace не предоставя начин за това.
//
// С тези ограничения тази функция има статично кеширано състояние, което се изчислява при първото заявяване.
//
// Не забравяйте, че проследяването на всичко се случва последователно (една глобална ключалка).
//
// Имайте предвид, че липсата на синхронизация тук се дължи на изискването `resolve` да се синхронизира външно.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Не упражнявайте безопасността на нишките на libbacktrace, тъй като ние винаги го наричаме синхронизирано.
        //
        0,
        error_cb,
        ptr::null_mut(), // без допълнителни данни
    );

    return STATE;

    // Имайте предвид, че за да работи libbacktrace изобщо, трябва да намери информация за отстраняване на грешки в DWARF за текущия изпълним файл.Обикновено прави това чрез редица механизми, включително, но не само:
    //
    // * /proc/self/exe на поддържани платформи
    // * Името на файла, предадено изрично при създаване на състояние
    //
    // Библиотеката libbacktrace е голяма пачка от C код.Това естествено означава, че има уязвимости в безопасността на паметта, особено при работа с деформиран debuginfo.
    // Libstd е срещал много такива в исторически план.
    //
    // Ако се използва /proc/self/exe, тогава обикновено можем да ги игнорираме, тъй като предполагаме, че libbacktrace е "mostly correct" и в противен случай не прави странни неща с информация за отстраняване на грешки на "attempted to be correct".
    //
    //
    // Ако обаче предадем име на файл, тогава е възможно на някои платформи (като BSD), където злонамерен актьор може да доведе до поставяне на произволен файл на това място.
    // Това означава, че ако кажем на libbacktrace за име на файл, той може да използва произволен файл, вероятно причиняващ сегменти.
    // Ако не кажем на libbacktrace нищо, тогава той няма да направи нищо на платформи, които не поддържат пътища като /proc/self/exe!
    //
    // Като се има предвид всичко, което се опитваме възможно най-много *да не* предаваме име на файл, но трябва на платформи, които изобщо не поддържат /proc/self/exe.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Имайте предвид, че в идеалния случай бихме използвали `std::env::current_exe`, но тук не можем да изискваме `std`.
            //
            // Използвайте `_NSGetExecutablePath`, за да заредите текущия изпълним път в статична област (която, ако е твърде малка, просто се откажете).
            //
            //
            // Имайте предвид, че ние се доверяваме сериозно на libbacktrace тук, за да не умрем при корумпирани изпълними файлове, но със сигурност го прави ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows има режим на отваряне на файлове, при който след отваряне не може да бъде изтрит.
            // По принцип това искаме тук, защото искаме да гарантираме, че изпълнимият ни файл не се променя изпод нас, след като го предадем на libbacktrace, надяваме се да смекчим възможността за предаване на произволни данни в libbacktrace (което може да бъде неправилно обработено).
            //
            //
            // Като се има предвид, че тук правим малко танци, за да се опитаме да получим нещо като заключване на собствения си образ:
            //
            // * Вземете манипулатор на текущия процес, заредете неговото име на файл.
            // * Отворете файл с това име на файла с правилните флагове.
            // * Презаредете името на файла на текущия процес, като се уверите, че е същото
            //
            // Ако всичко това мине, ние на теория наистина сме отворили файла на нашия процес и сме гарантирани, че няма да се промени.FWIW куп от това е копиран от libstd в исторически план, така че това е най-добрата ми интерпретация на случващото се.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Това живее в статична памет, за да можем да го върнем ..
                static mut BUF: [i8; N] = [0; N];
                // ... и това живее в стека, тъй като е временно
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // умишлено изпускате `handle` тук, защото отварянето му трябва да запази заключването на името на този файл.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Искаме да върнем отрязък, който е завършен с нула, така че ако всичко е попълнено и е равно на общата дължина, тогава приравнете това на отказ.
                //
                //
                // В противен случай, когато връщате успеха, уверете се, че нулевият байт е включен в среза.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // грешките при обратното проследяване в момента са пометени под килима
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Обадете се на API на `backtrace_syminfo`, който (от четене на кода) трябва да извика `syminfo_cb` точно веднъж (или да се провали с грешка вероятно).
    // След това обработваме повече в рамките на `syminfo_cb`.
    //
    // Имайте предвид, че правим това, тъй като `syminfo` ще провери таблицата със символи, намирайки имена на символи, дори ако в двоичния файл няма информация за отстраняване на грешки.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}