// в момента се използва само на Linux, така че позволете мъртъв код другаде
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Прост разпределител на арени за байтови буфери.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Разпределя буфер с посочения размер и му връща променлива препратка.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // БЕЗОПАСНОСТ: това е единствената функция, която някога създава мутабел
        // препратка към `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // БЕЗОПАСНОСТ: ние никога не премахваме елементи от `self.buffers`, така че справка
        // към данните във всеки буфер ще живеят толкова дълго, колкото `self` живее.
        &mut buffers[i]
    }
}