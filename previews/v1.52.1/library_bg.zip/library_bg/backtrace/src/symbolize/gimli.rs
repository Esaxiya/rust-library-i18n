//! Поддръжка за символизиране с помощта на `gimli` crate на crates.io
//!
//! Това е изпълнението на символиката по подразбиране за Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // " статичният живот е лъжа за хакване около липсата на подкрепа за самореферентни структури.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Преобразувайте в " статичен живот`, тъй като символите трябва да заемат само `map` и `stash` и ние ги запазваме по-долу.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // За зареждане на собствени библиотеки на Windows вижте дискусия за rust-lang/rust#71060 за различните стратегии тук.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // Понастоящем библиотеките на MinGW не поддържат ASLR (rust-lang/rust#16514), но DLL все още могат да бъдат премествани в адресното пространство.
            // Изглежда, че адресите в информацията за отстраняване на грешки са все едно тази библиотека е заредена в своя "image base", което е поле в заглавките на COFF файла.
            // Тъй като това изглежда, че debuginfo изброява, ние анализираме таблицата със символи и съхраняваме адреси, сякаш библиотеката е била заредена и в "image base".
            //
            // Библиотеката обаче може да не се зарежда в "image base".
            // (вероятно там може да се зареди нещо друго?) Тук влиза полето `bias` и тук трябва да разберем стойността на `bias`.За съжаление обаче не е ясно как да се получи това от зареден модул.
            // Това, което имаме обаче, е действителният адрес за зареждане (`modBaseAddr`).
            //
            // Като малко копие засега ние картографираме файла, четем информацията за заглавката на файла, след което пускаме mmap.Това е разточително, защото вероятно ще отворим отново картата по-късно, но това трябва да работи достатъчно добре засега.
            //
            // След като имаме `image_base` (желано място за зареждане) и `base_addr` (действително място за зареждане), можем да попълним `bias` (разлика между действителното и желаното) и тогава посоченият адрес на всеки сегмент е `image_base`, тъй като това казва файлът.
            //
            //
            // Засега изглежда, че за разлика от ELF/MachO можем да се справим с един сегмент на библиотека, като използваме `modBaseSize` като целия размер.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS използва файловия формат Mach-O и използва специфични за DYLD API, за да зареди списък с местни библиотеки, които са част от приложението.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Вземете името на тази библиотека, което съответства на пътя до къде да го заредите.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Заредете заглавката на изображението на тази библиотека и делегирайте на `object`, за да анализирате всички команди за зареждане, за да можем да разберем всички включени тук сегменти.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Итерирайте над сегментите и регистрирайте известни региони за сегменти, които откриваме.
            // Допълнително записвайте информация за текстовите сегменти за обработка по-късно, вижте коментарите по-долу.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Определете "slide" за тази библиотека, което в крайна сметка е пристрастието, което използваме, за да разберем къде в паметта са заредени обекти.
            // Това обаче е малко странно изчисление и е резултат от опитите на няколко неща в дивата природа и виждането на това, което се придържа.
            //
            // Общата идея е, че `bias` плюс сегмент `stated_virtual_memory_address` ще бъде там, където в действителното адресно пространство се намира сегментът.
            // Другото нещо, на което разчитаме обаче, е, че реален адрес минус `bias` е индексът, който трябва да се търси в таблицата със символи и debuginfo.
            //
            // Оказва се обаче, че за заредените от системата библиотеки тези изчисления са неправилни.За родните изпълними файлове обаче изглежда правилно.
            // Вдигайки някаква логика от източника на LLDB, той има специален корпус за първата секция `__TEXT`, заредена от отместване на файл 0 с ненулев размер.
            // По каквато и да е причина, когато това е налице, изглежда, че таблицата със символи е свързана само с плъзгача vmaddr за библиотеката.
            // Ако *не* присъства, тогава таблицата със символи е спрямо слайда vmaddr плюс посочения адрес на сегмента.
            //
            // За да се справим с тази ситуация, ако *не* намерим текстова секция с нулево отместване на файла, тогава увеличаваме пристрастието с посочения адрес на първите текстови раздели и намаляваме всички посочени адреси с тази сума.
            //
            // По този начин таблицата със символи винаги се появява спрямо размера на пристрастието на библиотеката.
            // Това изглежда има правилните резултати за символизиране чрез таблицата със символи.
            //
            // Честно казано, не съм напълно сигурен дали това е правилно или има нещо друго, което трябва да посочва как да се направи това.
            // Засега обаче това изглежда работи достатъчно добре (?) и винаги трябва да можем да го променим с времето, ако е необходимо.
            //
            // За повече информация вижте #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Други Unix (напр
        // Linux) платформите използват ELF като обектен файлов формат и обикновено прилагат API, наречен `dl_iterate_phdr` за зареждане на собствени библиотеки.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` трябва да са валидни указатели.
        // `vec` трябва да е валиден указател към `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 не поддържа изначално информация за отстраняване на грешки, но системата за изграждане ще постави информация за отстраняване на грешки в пътя `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Всичко останало трябва да използва ELF, но не знае как да зареди родните библиотеки.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Всички известни споделени библиотеки, които са заредени.
    libraries: Vec<Library>,

    /// Кеш за картографиране, където съхраняваме анализирана информация за джуджета.
    ///
    /// Този списък има фиксиран капацитет за цялото времетраене, който никога не се увеличава.
    /// Елементът `usize` на всяка двойка е индекс в `libraries` по-горе, където `usize::max_value()` представлява текущия изпълним файл.
    ///
    /// `Mapping` е съответната анализирана информация за джуджета.
    ///
    /// Имайте предвид, че това е основно LRU кеш и ще преместваме нещата тук, тъй като символизираме адресите.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Сегментите от тази библиотека се зареждат в паметта и къде се зареждат.
    segments: Vec<LibrarySegment>,
    /// "bias" на тази библиотека, обикновено там, където е заредена в паметта.
    /// Тази стойност се добавя към посочения адрес на всеки сегмент, за да се получи действителният адрес на виртуална памет, в който е зареден сегментът.
    /// Освен това това пристрастие се изважда от реални адреси на виртуална памет, за да се индексира в debuginfo и таблицата със символи.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Посоченият адрес на този сегмент в обектния файл.
    /// Това всъщност не е мястото, където се зарежда сегментът, а по-скоро този адрес плюс съдържащата библиотека `bias` е мястото, където да го намерите.
    ///
    stated_virtual_memory_address: usize,
    /// Размерът на ths сегмента в паметта.
    len: usize,
}

// опасно, защото това се изисква, за да бъде външно синхронизирано
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // опасно, защото това се изисква, за да бъде външно синхронизирано
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Много малък, много прост LRU кеш за съпоставяне на информация за отстраняване на грешки.
        //
        // Честотата на посещенията трябва да бъде много висока, тъй като типичният стек не пресича между много споделени библиотеки.
        //
        // Структурите на `addr2line::Context` са доста скъпи за създаване.
        // Очаква се цената му да бъде амортизирана от последващи заявки за `locate`, които използват структурите, изградени при изграждането на `addr2line: : Context`s, за да получат приятни ускорения.
        //
        // Ако нямахме този кеш, тази амортизация никога нямаше да се случи и символизиращите обратни следи щяха да бъдат ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Първо, тествайте дали този `lib` има някакъв сегмент, съдържащ `addr` (обработка на преместване).Ако тази проверка премине, можем да продължим по-долу и всъщност да преведем адреса.
                //
                // Имайте предвид, че тук използваме `wrapping_add`, за да избегнем проверки за препълване.Вижда се в дивата природа, че изчислението на SVMA + пристрастия прелива.
                // Изглежда малко странно, което би се случило, но не можем да направим огромно количество по този въпрос, освен вероятно просто да игнорираме тези сегменти, тъй като те вероятно сочат в космоса.
                //
                // Това първоначално се появи в rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Сега, когато знаем, че `lib` съдържа `addr`, можем да компенсираме пристрастията, за да намерим посочения адрес на вирусна памет.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Инвариант: след това условното завършване без ранно връщане
        // от грешка записът в кеша за този път е с индекс 0.

        if let Some(idx) = idx {
            // Когато картографирането вече е в кеша, преместете го отпред.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Когато картографирането не е в кеша, създайте ново картографиране, поставете го в предната част на кеша и извадете най-стария запис в кеша, ако е необходимо.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // не изпускайте `'static` през целия живот, уверете се, че той е обхванат само до нас
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Удължете живота на `sym` до `'static`, тъй като за съжаление се изисква тук, но той винаги излиза като референция, така че никакво позоваване на него не трябва да се запазва извън тази рамка.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // И накрая, вземете кеширано картографиране или създайте ново картографиране за този файл и оценете информацията за DWARF, за да намерите file/line/name за този адрес.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Успяхме да намерим информацията за рамката за този символ, а рамката на " addr2line` вътрешно съдържа всички подробности.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Не можахме да намерим информация за отстраняване на грешки, но я намерихме в таблицата със символи на изпълнимия файл на elf.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}