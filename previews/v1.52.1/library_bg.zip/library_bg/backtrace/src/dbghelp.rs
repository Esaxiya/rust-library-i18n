//! Модул за подпомагане на управлението на dbghelp обвързвания на Windows
//!
//! Обратните следи на Windows (поне за MSVC) се захранват до голяма степен чрез `dbghelp.dll` и различните функции, които той съдържа.
//! Понастоящем тези функции се зареждат *динамично*, вместо да се свързват статично с `dbghelp.dll`.
//! Понастоящем това се прави от стандартната библиотека (и на теория се изисква там), но е усилие да се помогне за намаляване на статичните dll зависимости на библиотеката, тъй като обратните следи обикновено са доста незадължителни.
//!
//! Като се има предвид това, `dbghelp.dll` почти винаги успешно се зарежда на Windows.
//!
//! Имайте предвид обаче, че тъй като зареждаме цялата тази поддръжка динамично, всъщност не можем да използваме суровите дефиниции в `winapi`, а по-скоро трябва да дефинираме типовете функционални указатели и да ги използваме.
//! Ние наистина не искаме да се занимаваме с дублиране на winapi, така че имаме функция Cargo `verify-winapi`, която твърди, че всички обвързвания съвпадат с тези в winapi и тази функция е активирана на CI.
//!
//! И накрая, тук ще забележите, че dll за `dbghelp.dll` никога не се разтоварва и в момента това е умишлено.
//! Мисълта е, че можем да го кешираме в глобален мащаб и да го използваме между обаждания към API, като избягваме скъпите loads/unloads.
//! Ако това е проблем за детектори за течове или нещо подобно, можем да преминем моста, когато стигнем там.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Работете около `SymGetOptions` и `SymSetOptions`, които не присъстват в самия winapi.
// В противен случай това се използва само когато проверяваме двойно типовете срещу winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Все още не е дефинирано в winapi
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Това е дефинирано в winapi, но е неправилно (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Все още не е дефинирано в winapi
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Този макрос се използва за дефиниране на `Dbghelp` структура, която вътрешно съдържа всички указатели на функции, които бихме могли да заредим.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// Заредената DLL за `dbghelp.dll`
            dll: HMODULE,

            // Всеки показалец на функция за всяка функция, която бихме могли да използваме
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Първоначално не сме заредили DLL
            dll: 0 as *mut _,
            // Първоначално всички функции са настроени на нула, за да казват, че трябва да се зареждат динамично.
            //
            $($name: 0,)*
        };

        // Удобство typedef за всеки тип функция.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Опити за отваряне на `dbghelp.dll`.
            /// Връща успех, ако работи или грешка, ако `LoadLibraryW` не успее.
            ///
            /// Panics, ако библиотеката вече е заредена.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Функция за всеки метод, който бихме искали да използваме.
            // Когато бъде извикан, той ще прочете указателя на кешираната функция или ще го зареди и ще върне заредената стойност.
            // Натоварванията се твърдят за успех.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Удобен прокси за използване на ключалките за почистване за препращане към dbghelp функции.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Инициализирайте цялата поддръжка, необходима за достъп до функциите на API на `dbghelp` от този crate.
///
///
/// Имайте предвид, че тази функция е **безопасна**, тя има собствена синхронизация.
/// Също така имайте предвид, че е безопасно да извикате тази функция няколко пъти рекурсивно.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Първото нещо, което трябва да направим, е да синхронизираме тази функция.Това може да се извика едновременно от други нишки или рекурсивно в рамките на една нишка.
        // Имайте предвид, че е по-сложно от това, тъй като това, което използваме тук, `dbghelp`,*също* трябва да бъде синхронизирано с всички останали повикващи към `dbghelp` в този процес.
        //
        // Обикновено няма толкова много обаждания към `dbghelp` в рамките на един и същ процес и вероятно можем спокойно да предположим, че само ние имаме достъп до него.
        // Има обаче един първичен друг потребител, за когото трябва да се притесняваме, който е иронично ние самите, но в стандартната библиотека.
        // Стандартната библиотека на Rust зависи от тази crate за поддръжка на обратното проследяване и тази crate съществува и на crates.io.
        // Това означава, че ако стандартната библиотека отпечатва обратна следа panic, тя може да се състезава с този crate, идващ от crates.io, причинявайки сегментни грешки.
        //
        // За да помогнем в решаването на този проблем със синхронизирането, тук използваме специфичен за Windows трик (в крайна сметка това е специфично за Windows ограничение относно синхронизацията).
        // Ние създаваме *сесия локално* с име mutex, за да защитим това обаждане.
        // Намерението тук е, че стандартната библиотека и този crate не трябва да споделят API на ниво Rust, за да се синхронизират тук, а вместо това могат да работят зад кулисите, за да се уверят, че се синхронизират помежду си.
        //
        // По този начин, когато тази функция се извиква чрез стандартната библиотека или чрез crates.io, можем да бъдем сигурни, че се придобива същия мутекс.
        //
        // Така че всичко това е да се каже, че първото нещо, което правим тук, е, че атомно създаваме `HANDLE`, който е наименуван мютекс на Windows.
        // Синхронизираме малко с други нишки, споделящи тази функция специално и гарантираме, че е създаден само един манипулатор за екземпляр на тази функция.
        // Имайте предвид, че манипулаторът никога не се затваря, след като се съхранява в глобалния.
        //
        // След като действително извадим ключалката, ние просто я придобиваме и нашата дръжка `Init`, която раздаваме, ще бъде отговорна за изпускането й в крайна сметка.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Добре, Фу!Сега, когато всички сме безопасно синхронизирани, нека всъщност да започнем да обработваме всичко.
        // Първо трябва да се уверим, че `dbghelp.dll` действително се зарежда в този процес.
        // Правим това динамично, за да избегнем статична зависимост.
        // Исторически това е правено, за да се заобиколят странни проблеми с свързването и има за цел да направи двоичните файлове малко по-преносими, тъй като това е до голяма степен само програма за отстраняване на грешки.
        //
        //
        // След като отворим `dbghelp.dll`, трябва да извикаме някои функции за инициализация в него и това е подробно по-долу.
        // Правим това само веднъж, така че имаме глобален булев знак, който показва дали сме готови или не.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Уверете се, че флагът `SYMOPT_DEFERRED_LOADS` е зададен, защото според собствените документи на MSVC за това: "This is the fastest, most efficient way to use the symbol handler.", така че нека направим това!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Всъщност инициализирайте символи с MSVC.Имайте предвид, че това може да се провали, но ние го игнорираме.
        // Няма много предшестващо състояние на техниката само по себе си, но LLVM вътрешно изглежда пренебрегва възвръщаемата стойност тук и една от дезинфектантските библиотеки в LLVM отпечатва страшно предупреждение, ако това се провали, но основно го игнорира в дългосрочен план.
        //
        //
        // Един от случаите, когато това се случва много за Rust, е, че и стандартната библиотека, и тази crate на crates.io искат да се конкурират за `SymInitializeW`.
        // В миналото стандартната библиотека искаше да инициализира след това почистване през повечето време, но сега, когато използва този crate, това означава, че някой първо ще стигне до инициализацията, а другият ще вземе тази инициализация.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}