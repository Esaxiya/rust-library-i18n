use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Представяне на собствена и самостоятелна обратна връзка.
///
/// Тази структура може да се използва за улавяне на обратна следа в различни точки на програма и по-късно да се използва за проверка на обратната следа по това време.
///
///
/// `Backtrace` поддържа красив печат на обратни следи чрез изпълнението на `Debug`.
///
/// # Необходими функции
///
/// Тази функция изисква функцията `std` на `backtrace` crate да бъде активирана, а функцията `std` е активирана по подразбиране.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Рамките тук са изброени отгоре надолу на стека
    frames: Vec<BacktraceFrame>,
    // Индексът, който смятаме, е действителното начало на обратната следа, пропускайки рамки като `Backtrace::new` и `backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Заловена версия на кадър в обратна следа.
///
/// Този тип се връща като списък от `Backtrace::frames` и представлява един кадър на стека в заснета обратна следа.
///
/// # Необходими функции
///
/// Тази функция изисква функцията `std` на `backtrace` crate да бъде активирана, а функцията `std` е активирана по подразбиране.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Уловена версия на символ в обратна следа.
///
/// Този тип се връща като списък от `BacktraceFrame::symbols` и представлява метаданните за символ в обратна следа.
///
/// # Необходими функции
///
/// Тази функция изисква функцията `std` на `backtrace` crate да бъде активирана, а функцията `std` е активирана по подразбиране.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Записва обратна следа на мястото на повикване на тази функция, връщайки притежавано представяне.
    ///
    /// Тази функция е полезна за представяне на обратна следа като обект в Rust.Тази върната стойност може да бъде изпратена през нишки и отпечатана другаде и целта на тази стойност е да бъде изцяло самостоятелна.
    ///
    /// Имайте предвид, че на някои платформи придобиването на пълна обратна следа и разрешаването й може да бъде изключително скъпо.
    /// Ако цената е твърде голяма за вашето приложение, препоръчително е вместо това да използвате `Backtrace::new_unresolved()`, който избягва стъпката за разделителна способност на символа (която обикновено отнема най-много време) и позволява отлагането на това на по-късна дата.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Необходими функции
    ///
    /// Тази функция изисква функцията `std` на `backtrace` crate да бъде активирана, а функцията `std` е активирана по подразбиране.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // искам да се уверя, че тук има рамка за премахване
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Подобно на `new`, с изключение на това, че това не разрешава никакви символи, това просто улавя обратното проследяване като списък с адреси.
    ///
    /// По-късно може да се извика функцията `resolve`, за да разреши символите на това обратно проследяване в четливи имена.
    /// Тази функция съществува, тъй като процесът на разрешаване понякога може да отнеме значително време, докато някоя обратна следа може да бъде отпечатана рядко.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // без имена на символи
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // налични имена на символи
    /// ```
    ///
    /// # Необходими функции
    ///
    /// Тази функция изисква функцията `std` на `backtrace` crate да бъде активирана, а функцията `std` е активирана по подразбиране.
    ///
    ///
    ///
    #[inline(never)] // искам да се уверя, че тук има рамка за премахване
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Връща кадрите от момента на заснемане на тази обратна следа.
    ///
    /// Първият запис на този отрязък е вероятно функцията `Backtrace::new`, а последният кадър вероятно е нещо за това как тази нишка или основната функция стартира.
    ///
    ///
    /// # Необходими функции
    ///
    /// Тази функция изисква функцията `std` на `backtrace` crate да бъде активирана, а функцията `std` е активирана по подразбиране.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Ако тази обратна следа е създадена от `new_unresolved`, тогава тази функция ще разреши всички адреси в обратната следа към техните символни имена.
    ///
    ///
    /// Ако това проследяване е разрешено преди това или е създадено чрез `new`, тази функция не прави нищо.
    ///
    /// # Необходими функции
    ///
    /// Тази функция изисква функцията `std` на `backtrace` crate да бъде активирана, а функцията `std` е активирана по подразбиране.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Същото като `Frame::ip`
    ///
    /// # Необходими функции
    ///
    /// Тази функция изисква функцията `std` на `backtrace` crate да бъде активирана, а функцията `std` е активирана по подразбиране.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Същото като `Frame::symbol_address`
    ///
    /// # Необходими функции
    ///
    /// Тази функция изисква функцията `std` на `backtrace` crate да бъде активирана, а функцията `std` е активирана по подразбиране.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Същото като `Frame::module_base_address`
    ///
    /// # Необходими функции
    ///
    /// Тази функция изисква функцията `std` на `backtrace` crate да бъде активирана, а функцията `std` е активирана по подразбиране.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Връща списъка със символи, на които съответства този кадър.
    ///
    /// Обикновено има само един символ на кадър, но понякога, ако редица функции са вградени в един кадър, ще бъдат върнати множество символи.
    /// Първият изброен символ е "innermost function", докато последният символ е най-външният (последният повикващ).
    ///
    /// Имайте предвид, че ако този кадър е дошъл от неразрешена обратна следа, това ще върне празен списък.
    ///
    /// # Необходими функции
    ///
    /// Тази функция изисква функцията `std` на `backtrace` crate да бъде активирана, а функцията `std` е активирана по подразбиране.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Същото като `Symbol::name`
    ///
    /// # Необходими функции
    ///
    /// Тази функция изисква функцията `std` на `backtrace` crate да бъде активирана, а функцията `std` е активирана по подразбиране.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Същото като `Symbol::addr`
    ///
    /// # Необходими функции
    ///
    /// Тази функция изисква функцията `std` на `backtrace` crate да бъде активирана, а функцията `std` е активирана по подразбиране.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Същото като `Symbol::filename`
    ///
    /// # Необходими функции
    ///
    /// Тази функция изисква функцията `std` на `backtrace` crate да бъде активирана, а функцията `std` е активирана по подразбиране.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Същото като `Symbol::lineno`
    ///
    /// # Необходими функции
    ///
    /// Тази функция изисква функцията `std` на `backtrace` crate да бъде активирана, а функцията `std` е активирана по подразбиране.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Същото като `Symbol::colno`
    ///
    /// # Необходими функции
    ///
    /// Тази функция изисква функцията `std` на `backtrace` crate да бъде активирана, а функцията `std` е активирана по подразбиране.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Когато отпечатваме пътища, ние се опитваме да премахнем cwd, ако съществува, в противен случай просто отпечатваме пътя както е.
        // Имайте предвид, че ние също правим това само за краткия формат, защото ако е пълен, вероятно искаме да отпечатаме всичко.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}