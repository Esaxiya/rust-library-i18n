use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr приема обратно повикване, което ще получи указател dl_phdr_info за всеки DSO, който е свързан в процеса.
    // dl_iterate_phdr също гарантира, че динамичният свързващ механизъм е заключен от началото до края на итерацията.
    // Ако обратното повикване връща ненулева стойност, итерацията се прекратява по-рано.
    // 'data' ще бъде предаден като трети аргумент на обратното обаждане при всяко обаждане.
    // 'size' дава размера на dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Трябва да анализираме идентификатора на компилация и някои основни данни на заглавието на програмата, което означава, че се нуждаем и от малко неща от спецификацията на ELF.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Сега трябва да репликираме, бит за бит, структурата на типа dl_phdr_info, използван от текущия динамичен линкер на fuchsia.
// Chromium също има тази ABI граница, както и crashpad.
// В крайна сметка бихме искали да преместим тези случаи, за да използваме elf-search, но ще трябва да предоставим това в SDK и това все още не е направено.
//
// По този начин ние (и те) сме останали да се налага да използваме този метод, който води до плътно свързване с fuchsia libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Ние няма как да знаем дали да проверяваме дали e_phoff и e_phnum са валидни.
    // libc трябва да осигури това за нас, така че е безопасно да формирате парче тук.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr представлява заглавка на 64-битова програма на ELF в крайността на целевата архитектура.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr представлява валидна заглавка на програмата ELF и нейното съдържание.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Нямаме начин да проверим дали p_addr или p_memsz са валидни.
    // Libc на Fuchsia първо анализира бележките, но поради това, че са тук, тези заглавия трябва да са валидни.
    //
    // NoteIter не изисква основните данни да са валидни, но изисква границите да са валидни.
    // Вярваме, че libc е гарантирал, че случаят е такъв за нас тук.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Типът бележка за идентификатори на компилация.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr представлява заглавка на бележка ELF в крайността на целта.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Бележката представлява ELF бележка (заглавка + съдържание).
// Името е оставено като u8 слайс, тъй като не винаги е прекратено с нула и rust улеснява достатъчно, за да провери дали байтовете така или иначе съвпадат.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter ви позволява безопасно да прелиствате сегмент от бележка.
// Прекратява се веднага щом възникне грешка или няма повече бележки.
// Ако прегледате невалидни данни, той ще функционира така, сякаш не са намерени бележки.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Инвариант на функцията е, че посоченият указател и размер означават валиден диапазон от байтове, които всички могат да бъдат прочетени.
    // Съдържанието на тези байтове може да бъде всичко, но диапазонът трябва да е валиден, за да е безопасно.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to подравнява 'x' към подравняване на байта, приемайки, че 'to' е степен 2.
// Това следва стандартен модел в C/C ++ ELF кода за синтактичен анализ, където се използва (x + до, 1)&-to.
// Rust не ви позволява да отричате usize, затова използвам
// Преобразуване на допълнение 2, за да го пресъздадете.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 консумира брой байта от среза (ако има такъв) и допълнително гарантира, че крайният слайс е правилно подравнен.
// Ако броят на поисканите байтове е твърде голям или фрагментът не може да бъде подравнен впоследствие поради липсата на достатъчно останали байтове, се връща None и фрагментът не се променя.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Тази функция няма реални инварианти, които повикващият трябва да поддържа, освен може би, че 'bytes' трябва да бъде подравнен за производителност (и за някои архитектури коректност).
// Стойностите в полетата Elf_Nhdr може да са глупости, но тази функция не гарантира такова нещо.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Това е безопасно, стига да има достатъчно място и току-що потвърдихме, че в изявлението по-горе, така че това не трябва да е опасно.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Имайте предвид, че sice_of: :<Elf_Nhdr>() винаги е 4-байтово подравнено.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Проверете дали сме стигнали до края.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Преобразуваме nhdr, но внимателно обмисляме получената структура.
        // Нямаме доверие на namesz или descsz и не вземаме несигурни решения въз основа на типа.
        //
        // Така че дори да извадим пълния боклук, пак трябва да сме в безопасност.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Показва, че сегментът е изпълним.
const PERM_X: u32 = 0b00000001;
/// Показва, че даден сегмент може да се записва.
const PERM_W: u32 = 0b00000010;
/// Показва, че сегментът е четим.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Представлява ELF сегмент по време на изпълнение.
struct Segment {
    /// Дава виртуалния адрес по време на изпълнение на съдържанието на този сегмент.
    addr: usize,
    /// Дава размер на паметта на съдържанието на този сегмент.
    size: usize,
    /// Дава виртуалния адрес на модула на този сегмент с ELF файла.
    mod_rel_addr: usize,
    /// Дава разрешенията, намерени във файла ELF.
    /// Тези разрешения обаче не са непременно разрешенията, налични по време на изпълнение.
    flags: Perm,
}

/// Позволява една итерация над сегменти от DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Представлява ELF DSO (динамичен споделен обект).
/// Този тип се позовава на данните, съхранявани в действителния DSO, вместо да прави свое копие.
struct Dso<'a> {
    /// Динамичният линкер винаги ни дава име, дори ако името е празно.
    /// В случая на основния изпълним файл това име ще бъде празно.
    /// В случай на споделен обект това ще бъде soname (вижте DT_SONAME).
    name: &'a str,
    /// На Fuchsia почти всички двоични файлове имат идентификатори на компилация, но това не е строго изискване.
    /// Няма начин да съпоставим информацията за DSO с истински ELF файл след това, ако няма build_id, така че ние изискваме всеки DSO да има такъв тук.
    ///
    /// DSO без build_id се игнорират.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Връща итератор над сегменти в този DSO.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Тези грешки кодират проблеми, които възникват при анализиране на информация за всеки DSO.
///
enum Error {
    /// NameError означава, че е възникнала грешка при преобразуване на низ от стил C в низ rust.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError означава, че не намерихме идентификатор на компилация.
    /// Това може да се дължи на това, че DSO няма идентификатор на компилация или защото сегментът, съдържащ идентификатора на компилация, е деформиран неправилно.
    ///
    BuildIDError,
}

/// Извиква 'dso' или 'error' за всеки DSO, свързан в процеса от динамичния свързващ елемент.
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter, който ще има един от методите за ядене, наречен foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr гарантира, че info.name ще сочи към валидно местоположение.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Тази функция отпечатва маркирането на символа Fuchsia за цялата информация, съдържаща се в DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}