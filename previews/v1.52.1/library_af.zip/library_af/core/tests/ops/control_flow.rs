use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Dit is nie 'n stabiele oppervlak nie, maar help om `?` goedkoop tussen hulle te hou, selfs al kan LLVM nie altyd hiervan gebruik maak nie.
    //
    // (Ongelukkig is Resultaat en Opsie nie-konsekwent, dus ControlFlow kan nie met beide ooreenstem nie.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}