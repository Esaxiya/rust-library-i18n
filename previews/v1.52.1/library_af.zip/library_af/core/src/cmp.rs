//! Funksionaliteit vir bestelling en vergelyking.
//!
//! Hierdie module bevat verskillende instrumente vir die ordening en vergelyking van waardes.Samevattend:
//!
//! * [`Eq`] en [`PartialEq`] is traits wat u toelaat om onderskeidelik totale en gedeeltelike gelykheid tussen waardes te definieer.
//! Die implementering daarvan oorlaai die `==`-en `!=`-bedieners.
//! * [`Ord`] en [`PartialOrd`] is traits wat u toelaat om onderskeidelik totale en gedeeltelike volgorde tussen waardes te definieer.
//!
//! Die implementering daarvan oorlaai die `<`-, `<=`-, `>`-en `>=`-operateurs.
//! * [`Ordering`] is 'n enum wat deur die hooffunksies van [`Ord`] en [`PartialOrd`] teruggestuur word, en beskryf 'n ordening.
//! * [`Reverse`] is 'n struktuur waarmee u 'n bestelling maklik kan omkeer.
//! * [`max`] en [`min`] is funksies wat voortbou van [`Ord`] en waarmee u die maksimum of minimum van twee waardes kan vind.
//!
//! Vir meer besonderhede, sien die onderskeie dokumentasie van elke item in die lys.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait vir vergelykings wat gelyk is aan [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation).
///
/// Hierdie trait maak voorsiening vir gedeeltelike gelykheid, vir tipes wat nie 'n volledige ekwivalensieverhouding het nie.
/// Byvoorbeeld in drywingsgetalle `NaN != NaN`, so drywende puntetipes implementeer `PartialEq` maar nie [`trait@Eq`] nie.
///
/// Formeel moet die gelykheid wees (vir alle `a`, `b`, `c` van die tipe `A`, `B`, `C`):
///
/// - **Simmetries**: as `A: PartialEq<B>` en `B: PartialEq<A>`, dan impliseer **`a==b`` b==a`**;en
///
/// - **Transitief**: as `A: PartialEq<B>` en `B: PartialEq<C>` en `A:
///   Gedeeltelik<C>`, dan **` a==b`en `b == c` impliseer`a==c`**.
///
/// Let daarop dat die `B: PartialEq<A>` (symmetric) en `A: PartialEq<C>` (transitive) impls nie gedwing word om te bestaan nie, maar hierdie vereistes is van toepassing wanneer dit ook al bestaan.
///
/// ## Derivable
///
/// Hierdie trait kan met `#[derive]` gebruik word.Wanneer 'struts' afgelei word, is twee gevalle gelyk as alle velde gelyk is, en nie gelyk as enige velde nie gelyk is nie.Wanneer 'afgelei' word op enums, is elke variant gelyk aan homself en nie gelyk aan die ander variante nie.
///
/// ## Hoe kan ek `PartialEq` implementeer?
///
/// `PartialEq` vereis slegs dat die [`eq`]-metode geïmplementeer word;[`ne`] word standaard daaraan gedefinieer.Enige handmatige implementering van [`ne`]*moet* die reël dat [`eq`] 'n streng omgekeerde van [`ne`] is, respekteer;dit wil sê `!(a == b)` as en slegs as `a != b`.
///
/// Implementasies van `PartialEq`, [`PartialOrd`] en [`Ord`]*moet* met mekaar ooreenstem.Dit is maklik om hulle per ongeluk te laat verskil deur sommige van die traits af te lei en ander met die hand te implementeer.
///
/// 'N Voorbeeld implementering vir 'n domein waarin twee boeke as dieselfde boek beskou word as hulle ISBN ooreenstem, selfs al verskil die formate:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Hoe kan ek twee verskillende soorte vergelyk?
///
/// Die tipe waarmee u kan vergelyk word beheer deur die tipe parameter van 'PartialEq'.
/// Laat ons byvoorbeeld ons vorige kode 'n bietjie aanpas:
///
/// ```
/// // Die aflei implemente<BookFormat>==<BookFormat>vergelykings
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Implementeer<Book>==<BookFormat>vergelykings
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // Implementeer<BookFormat>==<Book>vergelykings
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// Deur `impl PartialEq for Book` in `impl PartialEq<BookFormat> for Book` te verander, laat ons toe dat 'BookFormat`s met' Book`s vergelyk word.
///
/// 'N Vergelyking soos hierbo, wat sommige velde van die struktuur ignoreer, kan gevaarlik wees.Dit kan maklik lei tot 'n onbedoelde oortreding van die vereistes vir 'n gedeeltelike ekwivalensieverhouding.
/// As ons byvoorbeeld die bostaande implementering van `PartialEq<Book>` vir `BookFormat` behou en 'n implementering van `PartialEq<Book>` vir `Book` byvoeg (óf via 'n `#[derive]` óf via die handmatige implementering van die eerste voorbeeld), sou die resultaat die transitiwiteit skend:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Hierdie metode toets of `self`-en `other`-waardes gelyk is, en word deur `==` gebruik.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Hierdie metode toets vir `!=`.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// Lei makro af wat 'n impl. Van die trait `PartialEq` genereer.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait vir vergelykings wat gelyk is aan [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation).
///
/// Dit beteken dat, behalwe dat `a == b` en `a != b` streng omgekeerd is, die gelykheid moet wees (vir alle `a`, `b` en `c`):
///
/// - reflexive: `a == a`;
/// - simmetries: `a == b` impliseer `b == a`;en
/// - oorgang: `a == b` en `b == c` impliseer `a == c`.
///
/// Hierdie eienskap kan nie deur die samesteller nagegaan word nie, en `Eq` impliseer dus [`PartialEq`] en het geen ekstra metodes nie.
///
/// ## Derivable
///
/// Hierdie trait kan met `#[derive]` gebruik word.
/// As X afgelei word, omdat `Eq` geen ekstra metodes het nie, is dit slegs die samesteller in te lig dat dit 'n ekwivalensieverhouding is eerder as 'n gedeeltelike ekwivalensieverhouding.
///
/// Let daarop dat die `derive`-strategie vereis dat alle velde `Eq` is, wat nie altyd verlang word nie.
///
/// ## Hoe kan ek `Eq` implementeer?
///
/// As u nie die `derive`-strategie kan gebruik nie, moet u spesifiseer dat u tipe `Eq` implementeer, wat geen metodes het nie:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // hierdie metode word uitsluitlik deur#[afgelei] gebruik om te beweer dat elke komponent van 'n soort self implementeer, die huidige afleidingsinfrastruktuur beteken dat hierdie bewering gedoen word sonder om 'n metode op hierdie trait te gebruik, is amper onmoontlik.
    //
    //
    // Dit moet nooit met die hand geïmplementeer word nie.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// Lei makro af wat 'n impl. Van die trait `Eq` genereer.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: hierdie struktuur word slegs deur#[afgelei] gebruik
// beweer dat elke komponent van 'n tipe Vgl.
//
// Hierdie struktuur moet nooit in die gebruikerskode verskyn nie.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// 'N `Ordering` is die resultaat van 'n vergelyking tussen twee waardes.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// 'N Ordening waar 'n vergelykbare waarde minder is as 'n ander.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// 'N Ordening waar 'n vergelykbare waarde gelyk is aan 'n ander.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// 'N Ordening waar 'n vergelykbare waarde groter is as 'n ander.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Wys `true` as die bestelling die `Equal`-variant is.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Wys `true` as die bestelling nie die `Equal`-variant is nie.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Wys `true` as die bestelling die `Less`-variant is.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Wys `true` as die bestelling die `Greater`-variant is.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Wys `true` as die bestelling die `Less`-of `Equal`-variant is.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Wys `true` as die bestelling die `Greater`-of `Equal`-variant is.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// Omkeer die `Ordering`.
    ///
    /// * `Less` word `Greater`.
    /// * `Greater` word `Less`.
    /// * `Equal` word `Equal`.
    ///
    /// # Examples
    ///
    /// Basiese gedrag:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Hierdie metode kan gebruik word om 'n vergelyking om te keer:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // sorteer die skikking van die grootste na die kleinste.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Kettings twee bestellings.
    ///
    /// Wys `self` as dit nie `Equal` is nie.Andersins gee `other` terug.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Ketting die ordening met die gegewe funksie.
    ///
    /// Wys `self` as dit nie `Equal` is nie.
    /// Bel `f` anders en lewer die resultaat op.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// 'N Helper-struktuur vir omgekeerde ordening.
///
/// Hierdie struktuur is 'n helper wat gebruik kan word met funksies soos [`Vec::sort_by_key`] en kan gebruik word om 'n gedeelte van die sleutel in omgekeerde volgorde te orden.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait vir soorte wat 'n [total order](https://en.wikipedia.org/wiki/Total_order) vorm.
///
/// 'N Bestelling is 'n totale bestelling as dit is (vir alle `a`, `b` en `c`):
///
/// - totaal en asimmetries: presies een van `a < b`, `a == b` of `a > b` is waar;en
/// - oorgang, `a < b` en `b < c` impliseer `a < c`.Dieselfde moet geld vir beide `==` en `>`.
///
/// ## Derivable
///
/// Hierdie trait kan met `#[derive]` gebruik word.
/// As 'structs' afgelei word, sal dit 'n [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order)-bestelling voortbring gebaseer op die top-tot-onder-verklaringsvolgorde van die lede van die struktuur.
///
/// As 'afgelei' word op enums, word variante georden volgens hul onderskeie volgorde van bo na onder.
///
/// ## Leksikografiese vergelyking
///
/// Leksikografiese vergelyking is 'n bewerking met die volgende eienskappe:
///  - Twee rye word element vir element vergelyk.
///  - Die eerste ooreenstemmende element definieer watter volgorde leksikografies minder of groter is as die ander.
///  - As een ry 'n voorvoegsel van 'n ander is, is die korter volgorde leksikografies minder as die ander.
///  - As twee reekse ekwivalente elemente het en ewe lank is, is die rye leksikografies gelyk.
///  - 'N Leë ry is leksikografies minder as enige nie-leë reeks.
///  - Twee leë rye is leksikografies gelyk.
///
/// ## Hoe kan ek `Ord` implementeer?
///
/// `Ord` vereis dat die tipe ook [`PartialOrd`] en [`Eq`] moet wees (wat [`PartialEq`] benodig).
///
/// Dan moet u 'n implementering vir [`cmp`] definieer.U mag dit nuttig vind om [`cmp`] op die velde van u tipe te gebruik.
///
/// Implementasies van [`PartialEq`], [`PartialOrd`] en `Ord`*moet* met mekaar ooreenstem.
/// Dit wil sê `a.cmp(b) == Ordering::Equal` as en net as `a == b` en `Some(a.cmp(b)) == a.partial_cmp(b)` vir alle `a` en `b`.
/// Dit is maklik om hulle per ongeluk te laat verskil deur sommige van die traits af te lei en ander met die hand te implementeer.
///
/// Hier is 'n voorbeeld waar u mense slegs volgens die hoogte wil sorteer, sonder om `id` en `name` te ignoreer:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// Hierdie metode gee 'n [`Ordering`] tussen `self` en `other`.
    ///
    /// Volgens konvensie gee `self.cmp(&other)` die volgorde wat ooreenstem met die uitdrukking `self <operator> other` as dit waar is.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Vergelyk en lewer die maksimum van twee waardes op.
    ///
    /// Wys die tweede argument as die vergelyking bepaal dat hulle gelyk is.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Vergelyk en lewer die minimum van twee waardes op.
    ///
    /// Wys die eerste argument as die vergelyking bepaal dat hulle gelyk is.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Beperk 'n waarde tot 'n sekere interval.
    ///
    /// Wys `max` as `self` groter is as `max`, en `min` as `self` minder as `min` is.
    /// Anders gee dit `self` terug.
    ///
    /// # Panics
    ///
    /// Panics as `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// Lei makro af wat 'n impl. Van die trait `Ord` genereer.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait vir waardes wat vergelyk kan word vir 'n sorteervolgorde.
///
/// Die vergelyking moet vir alle `a`, `b` en `c` voldoen:
///
/// - asimmetrie: as `a < b` dan `!(a > b)`, sowel as `a > b` wat `!(a < b)` impliseer;en
/// - oorgang: `a < b` en `b < c` impliseer `a < c`.Dieselfde moet geld vir beide `==` en `>`.
///
/// Let op dat hierdie vereistes beteken dat die trait self simmetries en deurlopend geïmplementeer moet word: as `T: PartialOrd<U>` en `U: PartialOrd<V>` dan `U: PartialOrd<T>` en `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// Hierdie trait kan met `#[derive]` gebruik word.Wanneer 'structs' afgelei word, sal dit 'n leksikografiese volgorde opstel gebaseer op die top-tot-onder-verklaringsvolgorde van die lede van die struktuur.
/// As 'afgelei' word op enums, word variante georden volgens hul onderskeie volgorde van bo na onder.
///
/// ## Hoe kan ek `PartialOrd` implementeer?
///
/// `PartialOrd` vereis slegs die implementering van die [`partial_cmp`]-metode, met die ander wat gegenereer word uit standaardimplementasies.
///
/// Dit bly egter moontlik om die ander afsonderlik te implementeer vir soorte wat nie 'n totale bestelling het nie.
/// Byvoorbeeld, vir drywingsgetalle, `NaN < 0 == false` en `NaN >= 0 == false` (vgl.
/// IEEE 754-2008 afdeling 5.11).
///
/// `PartialOrd` vereis dat u tipe [`PartialEq`] is.
///
/// Implementasies van [`PartialEq`], `PartialOrd` en [`Ord`]*moet* met mekaar ooreenstem.
/// Dit is maklik om hulle per ongeluk te laat verskil deur sommige van die traits af te lei en ander met die hand te implementeer.
///
/// As u tipe [`Ord`] is, kan u [`partial_cmp`] implementeer deur [`cmp`] te gebruik:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// U kan dit ook nuttig vind om [`partial_cmp`] op die velde van u tipe te gebruik.
/// Hier is 'n voorbeeld van `Person`-tipes wat 'n drywende `height`-veld het wat die enigste veld is wat gebruik kan word om te sorteer:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Hierdie metode gee 'n orde tussen `self`-en `other`-waardes as dit bestaan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// Wanneer vergelyking onmoontlik is:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Hierdie metode toets minder as (vir `self` en `other`) en word deur die `<`-operateur gebruik.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Hierdie metode toets minder as of gelyk aan (vir `self` en `other`) en word deur die `<=`-operateur gebruik.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Hierdie metode toets groter as (vir `self` en `other`) en word deur die `>`-operateur gebruik.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Hierdie metode toets groter as of gelyk aan (vir `self` en `other`) en word deur die `>=`-operateur gebruik.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// Lei makro af wat 'n impl. Van die trait `PartialOrd` genereer.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Vergelyk en lewer die minimum van twee waardes op.
///
/// Wys die eerste argument as die vergelyking bepaal dat hulle gelyk is.
///
/// Gebruik intern 'n alias vir [`Ord::min`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Wys die minimum van twee waardes met betrekking tot die gespesifiseerde vergelykingsfunksie.
///
/// Wys die eerste argument as die vergelyking bepaal dat hulle gelyk is.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Wys die element wat die minimum waarde van die gespesifiseerde funksie gee.
///
/// Wys die eerste argument as die vergelyking bepaal dat hulle gelyk is.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Vergelyk en lewer die maksimum van twee waardes op.
///
/// Wys die tweede argument as die vergelyking bepaal dat hulle gelyk is.
///
/// Gebruik intern 'n alias vir [`Ord::max`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Wys die maksimum van twee waardes met betrekking tot die gespesifiseerde vergelykingsfunksie.
///
/// Wys die tweede argument as die vergelyking bepaal dat hulle gelyk is.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Wys die element wat die maksimum waarde van die gespesifiseerde funksie gee.
///
/// Wys die tweede argument as die vergelyking bepaal dat hulle gelyk is.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// Implementering van PartialEq, Eq, PartialOrd en Ord vir primitiewe tipes
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // Die volgorde hier is belangrik om meer optimale montering te genereer.
                    // Sien <https://github.com/rust-lang/rust/issues/63758> vir meer inligting.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // Om na i8's te gooi en die verskil na 'n bestelling te omskep, genereer 'n meer optimale samestelling.
            //
            // Sien <https://github.com/rust-lang/rust/issues/66780> vir meer inligting.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // VEILIGHEID: bool as i8 lewer 0 of 1 op, dus kan die verskil niks anders wees nie
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &aanwysings

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}