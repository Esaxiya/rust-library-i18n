//! Komponeerbare asinchrone iterasie.
//!
//! As futures asynchrone waardes is, is strome asynchrone iteratore.
//! As u 'n asynchrone versameling van die een of ander aard het, en u moet die bewerking van die elemente van die versameling uitvoer, sal u 'streams' vinnig raakloop.
//! Strome word sterk gebruik in idiomatiese asynchrone Rust-kode, dus dit is die moeite werd om hulle vertroud te maak.
//!
//! Kom ons bespreek eers hoe hierdie module gestruktureer is, voordat ons meer verduidelik:
//!
//! # Organization
//!
//! Hierdie module is hoofsaaklik volgens tipe georganiseer:
//!
//! * [Traits] is die kerngedeelte: hierdie traits definieer watter soort strome bestaan en wat u daarmee kan doen.Die metodes van hierdie traits is die moeite werd om ekstra studietyd in te ruim.
//! * Funksies bied 'n paar nuttige maniere om basiese strome te skep.
//! * Structs is dikwels die retourtipes van die verskillende metodes op die traits van hierdie module.U wil gewoonlik na die metode wat die `struct` skep, eerder as na die `struct` kyk.
//! Raadpleeg '[Implementing Stream](#implementing-stream)' vir meer besonderhede oor waarom.
//!
//! [Traits]: #traits
//!
//! Dis dit!Kom ons grawe in strome.
//!
//! # Stream
//!
//! Die hart en siel van hierdie module is die [`Stream`] trait.Die kern van [`Stream`] lyk soos volg:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Anders as `Iterator`, maak `Stream` 'n onderskeid tussen die [`poll_next`]-metode wat gebruik word by die implementering van 'n `Stream`, en 'n (to-be-implemented) `next`-metode wat gebruik word wanneer 'n stroom verbruik word.
//!
//! Verbruikers van `Stream` hoef slegs `next` te oorweeg, wat, wanneer dit genoem word, 'n future oplewer wat `Option<Stream::Item>` oplewer.
//!
//! Die future wat deur `next` terugbesorg word, sal `Some(Item)` oplewer solank daar elemente is, en sodra almal uitgeput is, sal dit `None` oplewer om aan te dui dat die herhaling voltooi is.
//! As ons wag op iets asynchrone om op te los, sal die future wag totdat die stroom weer gereed is om op te lewer.
//!
//! Individuele strome kan kies om herhaling te hervat, en om `next` weer te bel, sal `Some(Item)` dalk op 'n stadium weer oplewer.
//!
//! ['Stream'] se volledige definisie bevat ook 'n aantal ander metodes, maar dit is standaardmetodes, bo-op die [`poll_next`] gebou, en u kry dit dus gratis.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Implementering van stroom
//!
//! Om u eie stroom te skep, behels twee stappe: die skep van 'n `struct` om die stroom se status te behou en dan die implementering van [`Stream`] vir die `struct`.
//!
//! Laat ons 'n stroom met die naam `Counter` maak wat van `1` tot `5` tel:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Eerstens die struktuur:
//!
//! /// 'N Stroom wat van een tot vyf tel
//! struct Counter {
//!     count: usize,
//! }
//!
//! // ons wil hê dat ons telling by een moet begin, dus laat ons 'n new()-metode byvoeg om te help.
//! // Dit is nie streng nodig nie, maar is gerieflik.
//! // Let daarop dat ons `count` op nul begin, ons sal sien waarom in `poll_next()`'s-implementering hieronder.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Dan implementeer ons `Stream` vir ons `Counter`:
//!
//! impl Stream for Counter {
//!     // ons sal tel met die grootte
//!     type Item = usize;
//!
//!     // poll_next() is die enigste vereiste metode
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Verhoog ons telling.Dit is waarom ons op nul begin het.
//!         self.count += 1;
//!
//!         // Kyk of ons klaar getel het of nie.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Strome is *lui*.Dit beteken dat die skep van 'n stroom nie 'n hele klomp _do_ is nie.Niks gebeur regtig voordat u `next` bel nie.
//! Dit is soms 'n bron van verwarring as u 'n stroom skep slegs vir die newe-effekte daarvan.
//! Die samesteller sal ons waarsku oor hierdie soort gedrag:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;