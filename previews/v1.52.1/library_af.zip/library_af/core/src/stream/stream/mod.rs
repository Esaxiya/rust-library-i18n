use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// 'N Koppelvlak vir die hantering van asynchrone iteratore.
///
/// Dit is die hoofstroom trait.
/// Vir meer inligting oor die konsep van strome in die algemeen, raadpleeg die [module-level documentation].
/// In die besonder wil u dalk weet hoe u [implement `Stream`][impl] kan doen.
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Die tipe items wat deur die stroom opgelewer word.
    type Item;

    /// Probeer die volgende waarde van hierdie stroom uittrek, registreer die huidige taak vir ontwaking as die waarde nog nie beskikbaar is nie, en stuur `None` terug as die stroom uitgeput is.
    ///
    /// # Opbrengswaarde
    ///
    /// Daar is verskeie moontlike terugkeerwaardes wat elk 'n duidelike stroomtoestand aandui:
    ///
    /// - `Poll::Pending` beteken dat die stroom se volgende waarde nog nie gereed is nie.Implementasies sal verseker dat die huidige taak in kennis gestel word wanneer die volgende waarde gereed kan wees.
    ///
    /// - `Poll::Ready(Some(val))` beteken dat die stroom 'n waarde, `val`, suksesvol geproduseer het en verdere waardes kan lewer op daaropvolgende `poll_next`-oproepe.
    ///
    /// - `Poll::Ready(None)` beteken dat die stroom beëindig is en dat `poll_next` nie weer opgeroep moet word nie.
    ///
    /// # Panics
    ///
    /// Sodra 'n stroom klaar is (`Ready(None)` from `poll_next`) terugbesorg het, as hy sy `poll_next`-metode weer oproep, kan dit panic wees, vir ewig blokkeer of ander probleme veroorsaak; die `Stream` trait stel geen vereistes vir die gevolge van so 'n oproep nie.
    ///
    /// Aangesien die `poll_next`-metode egter nie as `unsafe` gemerk is nie, geld die gewone reëls van Rust: oproepe moet nooit ongedefinieerde gedrag veroorsaak nie (geheue-korrupsie, verkeerde gebruik van `unsafe`-funksies, ensovoorts), ongeag die toestand van die stroom.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Wys die grense vir die oorblywende lengte van die stroom.
    ///
    /// Spesifiek, `size_hint()` gee 'n tupel terug waar die eerste element die onderste grens is en die tweede element die boonste grens.
    ///
    /// Die tweede helfte van die tupel wat terugbesorg word, is 'n [`Opsie`] <`[`usize`]`> `.
    /// 'N [`None`] beteken hier dat daar geen bekende boonste grens is nie, of dat die boonste grens groter is as [`usize`].
    ///
    /// # Implementeringsnotas
    ///
    /// Dit word nie afgedwing dat 'n stroomimplementering die verklaarde aantal elemente lewer nie.'N Buggiestroom kan minder as die onderste of meer as die boonste grens van elemente lewer.
    ///
    /// `size_hint()` is hoofsaaklik bedoel om gebruik te word vir optimalisasies, soos om ruimte vir die elemente van die stroom te bespreek, maar mag nie vertrou word om bv. grense vir tjeks in onveilige kode uit te laat nie.
    /// 'N Verkeerde implementering van `size_hint()` mag nie tot skending van geheueveiligheid lei nie.
    ///
    /// Dit gesê, die implementering moet 'n korrekte skatting bied, want anders sou dit 'n oortreding van die trait se protokol wees.
    ///
    /// Die standaardimplementering gee '(0, `[` Geen'] ') terug wat korrek is vir enige stroom.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}