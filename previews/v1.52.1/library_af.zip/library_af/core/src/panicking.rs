//! Panic ondersteuning vir libcore
//!
//! Die kernbiblioteek kan nie paniekerig definieer nie, maar wel *verklaar* paniekbevange.
//! Dit beteken dat die funksies binne-in libcore toegelaat word vir panic, maar om nuttig te wees, moet 'n stroomopwaartse crate paniek definieer vir die gebruik van libcore.
//! Die huidige koppelvlak vir paniek is:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Hierdie definisie maak voorsiening vir paniek met enige algemene boodskap, maar dit laat nie toe om met 'n `Box<Any>`-waarde te misluk nie.
//! (`PanicInfo` bevat net 'n `&(dyn Any + Send)`, waarvoor ons 'n dummy-waarde invul in 'PanicInfo: : internal_constructor'.) Die rede hiervoor is dat libcore nie mag toewys nie.
//!
//!
//! Hierdie module bevat 'n paar ander paniekfunksies, maar dit is net die nodige lang items vir die samesteller.Alle panics word deur hierdie een funksie gelei.
//! Die werklike simbool word verklaar deur die `#[panic_handler]`-eienskap.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Die onderliggende implementering van libcore se `panic!`-makro as geen formatering gebruik word nie.
#[cold]
// moet nooit ingebou word nie, tensy paniek_onmiddellik is om die kode so veel as moontlik op die oproeppersele te vermy
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // benodig deur codegen vir panic by oorloop en ander `Assert` MIR-terminators
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Gebruik Arguments::new_v1 in plaas van format_args! ("{}", Expr) om die grootte van die bokoste moontlik te verminder.
    // Die formaat_sake!makro gebruik str's Display trait om expr te skryf, wat Formatter::pad noem, wat snaarafkorting en opvulling moet akkommodeer (alhoewel hier nie gebruik word nie).
    //
    // Deur Arguments::new_v1 te gebruik, kan die samesteller Formatter::pad van die uitvoerbinaire weglaat, wat tot enkele kilobytes bespaar.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // benodig vir konstante-geëvalueerde panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // benodig deur codegen vir panic met OOB array/slice toegang
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Die onderliggende implementering van die `panic!`-makro van libcore wanneer formatering gebruik word.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // OPMERKING Hierdie funksie oorskry nooit die FFI-grens nie;dit is 'n Rust-tot-Rust-oproep wat na die `#[panic_handler]`-funksie opgelos word.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // VEILIGHEID: `panic_impl` is gedefinieër in veilige Rust-kode en is dus veilig om te skakel.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Interne funksie vir `assert_eq!`-en `assert_ne!`-makro's
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}