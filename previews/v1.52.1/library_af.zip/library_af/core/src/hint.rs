#![stable(feature = "core_hint", since = "1.27.0")]

//! Wenke aan die samesteller wat beïnvloed hoe kode uitgestuur of geoptimaliseer moet word.
//! Wenke kan tyd of tyd wees.

use crate::intrinsics;

/// Stel die samesteller in kennis dat hierdie punt in die kode nie bereik kan word nie, wat verdere optimalisering moontlik maak.
///
/// # Safety
///
/// Die bereiking van hierdie funksie is heeltemal *ongedefinieerde gedrag*(UB).Die samesteller neem veral aan dat alle UB nooit mag gebeur nie, en sal dus alle takke wat tot 'n oproep na `unreachable_unchecked()` beland, uitskakel.
///
/// Soos met alle gevalle van UB, as hierdie aanname verkeerd blyk te wees, dws die `unreachable_unchecked()`-oproep is eintlik bereikbaar tussen alle moontlike beheervloei, sal die samesteller die verkeerde optimaliseringstrategie toepas, en kan dit soms selfs skynbaar onverwante kode korrup maak, wat moeilik veroorsaak probleme om op te spoor.
///
///
/// Gebruik hierdie funksie slegs as u kan bewys dat die kode dit nooit sal noem nie.
/// Andersins, oorweeg dit om die [`unreachable!`]-makro te gebruik, wat nie optimerings toelaat nie, maar wel panic wanneer dit uitgevoer word.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` is altyd positief (nie nul nie), daarom sal `checked_div` nooit `None` terugbesorg nie.
/////
///     // Daarom is die ander branch onbereikbaar.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // VEILIGHEID: die veiligheidskontrak vir `intrinsics::unreachable` moet
    // deur die oproeper gehandhaaf word.
    unsafe { intrinsics::unreachable() }
}

/// Stuur 'n masjieninstruksie om die verwerker aan te dui dat dit in 'n draai-lus besig is ('spin lock').
///
/// By ontvangs van die draai-lus sein kan die verwerker sy gedrag optimaliseer deur byvoorbeeld krag te bespaar of van hyper-draadjies te skakel.
///
/// Hierdie funksie verskil van [`thread::yield_now`] wat direk oplewer vir die skeduleerder van die stelsel, terwyl `spin_loop` nie met die bedryfstelsel kommunikeer nie.
///
/// 'N Algemene gebruiksgeval vir `spin_loop` is die implementering van begrensde optimistiese draai in 'n CAS-lus in primitiewe sinchronisasie.
/// Om probleme soos inversie van prioriteit te vermy, word dit sterk aanbeveel dat die draai-lus beëindig word nadat 'n beperkte hoeveelheid herhalings en 'n toepaslike blokkeerplan gemaak is.
///
///
/// **Opmerking**: Op platforms wat nie die wenke van spin-loop ondersteun nie, doen hierdie funksie niks nie.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // 'N Gedeelde atoomwaarde wat drade sal gebruik om te koördineer
/// let live = Arc::new(AtomicBool::new(false));
///
/// // In 'n agtergronddraad sal ons uiteindelik die waarde instel
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Doen werk en maak die waarde lewendig
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Terug op ons huidige draad, wag ons tot die waarde gestel word
/// while !live.load(Ordering::Acquire) {
///     // Die draai-lus is 'n wenk vir die SVE waarop ons wag, maar waarskynlik nie baie lank nie
/////
///     hint::spin_loop();
/// }
///
/// // Die waarde is nou gestel
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // VEILIGHEID: die `cfg` attr verseker dat ons dit slegs op x86-teikens uitvoer.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // VEILIGHEID: die `cfg` attr verseker dat ons dit slegs op x86_64-teikens uitvoer.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // VEILIGHEID: die `cfg` attr verseker dat ons dit slegs op aarch64-teikens uitvoer.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // VEILIGHEID: die `cfg` attr verseker dat ons dit slegs op armteikens uitvoer
            // met ondersteuning vir die v6-funksie.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// 'N Identiteitsfunksie wat *__ aan die samesteller wenk __* om maksimaal pessimisties te wees oor wat `black_box` kan doen.
///
/// In teenstelling met [`std::convert::identity`], word 'n Rust-samesteller aangemoedig om aan te neem dat `black_box` `dummy` op enige moontlike geldige manier kan gebruik waarvoor Rust-kode toegelaat word sonder om ongedefinieerde gedrag in die belkode in te voer.
///
/// Hierdie eienskap maak `black_box` nuttig vir die skryf van kode waarin sekere optimalisasies nie verlang word nie, soos maatstawwe.
///
/// Let daarop dat `black_box` slegs op 'n "best-effort"-basis (en kan slegs aangebied word) aangebied word.Die mate waartoe dit optimalisasies kan blokkeer, kan afhang van die platform en die kodegenerasie wat gebruik word.
/// Programme kan op geen manier op `black_box` staatmaak vir *korrektheid* nie.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Ons moet die argument op 'n manier "use" op 'n manier nie introspekteer nie, en op teikens wat dit ondersteun, kan ons gewoonlik die inline-vergadering gebruik om dit te doen.
    // Die interpretasie van LLVM van inline-assemblage is dat dit wel 'n swart boks is.
    // Dit is nie die grootste implementering nie, aangesien dit waarskynlik meer optimaliseer as wat ons wil hê, maar dit is tot dusver goed genoeg.
    //
    //

    #[cfg(not(miri))] // Dit is net 'n wenk, dus dit is goed om Miri oor te slaan.
    // VEILIGHEID: die inline vergadering is 'n no-op.
    unsafe {
        // FIXME: Kan nie `asm!` gebruik nie, want dit ondersteun nie MIPS en ander argitekture nie.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}