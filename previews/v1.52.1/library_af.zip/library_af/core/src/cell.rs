//! Deelbare veranderlike houers.
//!
//! Die geheueveiligheid van Rust is gebaseer op hierdie reël: Gegewe 'n voorwerp `T`, is dit slegs moontlik om een van die volgende te hê:
//!
//! - Met verskeie onveranderlike verwysings (`&T`) na die voorwerp (ook bekend as **aliasing**).
//! - Met een veranderlike verwysing ('&mut T') na die voorwerp (ook bekend as **veranderlikheid**).
//!
//! Dit word deur die Rust-samesteller afgedwing.Daar is egter situasies waar hierdie reël nie soepel genoeg is nie.Soms is dit nodig om verskeie verwysings na 'n voorwerp te hê en dit tog te verander.
//!
//! Deelbare veranderlike houers bestaan om veranderlikhede op 'n beheerde manier moontlik te maak, selfs in die teenwoordigheid van 'n aliasing.Beide [`Cell<T>`] en [`RefCell<T>`] laat dit toe op 'n enkele draad.
//! Nie `Cell<T>` of `RefCell<T>` is egter draadvry nie (hulle implementeer nie [`Sync`] nie).
//! As u aliasing en mutasie tussen verskeie drade moet doen, is dit moontlik om [`Mutex<T>`]-, [`RwLock<T>`]-of [`atomic`]-tipes te gebruik.
//!
//! Waardes van die tipes `Cell<T>` en `RefCell<T>` kan gemuteer word deur middel van gedeelde verwysings (dws
//! die gewone `&T`-tipe), terwyl die meeste Rust-tipes slegs gemuteer kan word deur middel van unieke ('&mut T') verwysings.
//! Ons sê dat `Cell<T>` en `RefCell<T>` 'interieur-veranderlikheid' bied, in teenstelling met tipiese Rust-tipes wat 'geërfde veranderlikheid' vertoon.
//!
//! Seltipes kom in twee geure voor: `Cell<T>` en `RefCell<T>`.`Cell<T>` implementeer veranderings aan die binnekant deur waardes in en uit die `Cell<T>` te skuif.
//! Om verwysings in plaas van waardes te gebruik, moet 'n mens die `RefCell<T>`-tipe gebruik en 'n skryfslot verkry voordat dit gemuteer word.`Cell<T>` bied metodes om die huidige interieurwaarde op te haal en te verander:
//!
//!  - Vir soorte wat [`Copy`] implementeer, haal die [`get`](Cell::get)-metode die huidige interieurwaarde op.
//!  - Vir soorte wat [`Default`] implementeer, vervang die [`take`](Cell::take)-metode die huidige interieurwaarde met [`Default::default()`] en lewer die vervangde waarde terug.
//!  - Vir alle soorte vervang die [`replace`](Cell::replace)-metode die huidige interieurwaarde en lewer die vervangde waarde op, en die [`into_inner`](Cell::into_inner)-metode verbruik die `Cell<T>` en lewer die interieurwaarde op.
//!  Daarbenewens vervang die [`set`](Cell::set)-metode die interieurwaarde en laat die vervangde waarde val.
//!
//! `RefCell<T>` gebruik die leeftyd van Rust om 'dinamiese lenings' te implementeer, 'n proses waardeur 'n mens tydelike, eksklusiewe, veranderlike toegang tot die innerlike waarde kan eis.
//! Leen vir `RefCell<T>`s word 'tydens looptyd' nagespoor, in teenstelling met die oorspronklike verwysingstipes van Rust wat volledig saamgestel word tydens kompileringstyd.
//! Omdat `RefCell<T>`-lenings dinamies is, is dit moontlik om 'n waarde te leen wat reeds veranderlik geleen is;as dit gebeur, lei dit tot draad panic.
//!
//! # Wanneer om binne-veranderlikhede te kies
//!
//! Die meer algemene oorerflike veranderlikheid, waar 'n mens unieke toegang moet hê om 'n waarde te muteer, is een van die belangrikste taalelemente wat Rust in staat stel om sterk te redeneer oor die wysiging van wysers, wat die ongeluk foute staties voorkom.
//! As gevolg hiervan word oorgeërfde veranderlikheid verkies, en binne-veranderlikheid is 'n laaste uitweg.
//! Aangesien seltipes mutasie moontlik maak waar dit andersins nie toegelaat word nie, is daar geleenthede waar binne-veranderlikhede gepas kan wees, of selfs *moet* gebruik moet word, bv.
//!
//! * Bekendstelling van veranderlikheid 'inside' van iets onveranderlik
//! * Implementeringsbesonderhede van logies-onveranderlike metodes.
//! * Muterende implementasies van [`Clone`].
//!
//! ## Bekendstelling van veranderlikheid 'inside' van iets onveranderlik
//!
//! Baie gedeelde slimwysertipes, waaronder [`Rc<T>`] en [`Arc<T>`], bied houers wat gekloon en gedeel kan word tussen verskeie partye.
//! Omdat die vervat waardes vermenigvuldig kan word, kan dit slegs met `&` geleen word, nie met `&mut` nie.
//! Sonder selle sou dit onmoontlik wees om data binne hierdie slim aanwysers te muteer.
//!
//! Dit is baie algemeen om 'n `RefCell<T>` in gedeelde wysertipes te plaas om weer veranderbaarheid in te stel:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Skep 'n nuwe blok om die omvang van die dinamiese lening te beperk
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Let daarop dat as ons nie die vorige lening van die kas buite die omvang laat val het nie, dan sou die daaropvolgende lening 'n dinamiese draad panic veroorsaak.
//!     //
//!     // Dit is die grootste gevaar van die gebruik van `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Let daarop dat hierdie voorbeeld `Rc<T>` gebruik en nie `Arc<T>` nie.`RefCell<T>`s is vir scenario's met 'n enkele draad.Oorweeg dit om [`RwLock<T>`] of [`Mutex<T>`] te gebruik as u gedeelde veranderlikheid in 'n situasie met meerdere drade benodig.
//!
//! ## Implementeringsbesonderhede van logies-onveranderlike metodes
//!
//! Soms kan dit wenslik wees om nie in 'n API bloot te stel dat daar "under the hood"-mutasie is nie.
//! Dit kan wees omdat die bewerking logies onveranderlik is, maar byvoorbeeld dwing die kas die implementering om mutasie uit te voer;of omdat u mutasie moet gebruik om 'n trait-metode te implementeer wat oorspronklik gedefinieer is om `&self` te neem.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Duur berekeninge is hier
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Muterende implementasies van `Clone`
//!
//! Dit is bloot 'n spesiale, maar algemene geval van die vorige: die wegsteek van veranderlikes vir operasies wat onveranderlik blyk te wees.
//! Daar word verwag dat die [`clone`](Clone::clone)-metode nie die bronwaarde sal verander nie, en word verklaar dat dit `&self` neem, nie `&mut self` nie.
//! Daarom moet enige mutasie wat in die `clone`-metode voorkom, seltipes gebruik.
//! [`Rc<T>`] hou byvoorbeeld sy verwysingstellings binne 'n `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// 'N Veranderlike geheue-plek.
///
/// # Examples
///
/// In hierdie voorbeeld kan u sien dat `Cell<T>` mutasie binne 'n onveranderlike struktuur moontlik maak.
/// Met ander woorde, dit stel "interior mutability" in staat.
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // FOUT: `my_struct` is onveranderlik
/// // my_struct.regular_field =nuwe_waarde;
///
/// // WERKE: hoewel `my_struct` onveranderlik is, is `special_field` 'n `Cell`,
/// // wat altyd gemuteer kan word
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Lees die [module-level documentation](self) vir meer inligting.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Skep 'n `Cell<T>`, met die `Default`-waarde vir T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Skep 'n nuwe `Cell` wat die gegewe waarde bevat.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Stel die ingeslote waarde in.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Ruil die waardes van twee selle om.
    /// Verskil met `std::mem::swap` is dat hierdie funksie nie `&mut`-verwysing benodig nie.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // VEILIGHEID: Dit kan gevaarlik wees as u dit van aparte drade gebruik, maar `Cell`
        // is `!Sync`, so dit sal nie gebeur nie.
        // Dit sal ook geen aanwysings ongeldig maak nie, aangesien `Cell` sorg dat niks anders in een van hierdie `Cell`s sal wys nie.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Vervang die ingeslote waarde met `val` en lewer die ou bevatwaarde terug.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // VEILIGHEID: Dit kan dataresies veroorsaak as dit vanuit 'n aparte draad gebel word,
        // maar `Cell` is `!Sync`, so dit sal nie gebeur nie.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Pak die waarde uit.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Lewer 'n afskrif van die vervat waarde.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // VEILIGHEID: Dit kan dataresies veroorsaak as dit vanuit 'n aparte draad gebel word,
        // maar `Cell` is `!Sync`, so dit sal nie gebeur nie.
        unsafe { *self.value.get() }
    }

    /// Werk die ingeslote waarde op met behulp van 'n funksie en gee die nuwe waarde terug.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Wys 'n rou wyser na die onderliggende data in hierdie sel.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Wys 'n veranderlike verwysing na die onderliggende data.
    ///
    /// Hierdie oproep leen `Cell` veranderbaar (tydens kompileringstyd), wat waarborg dat ons die enigste verwysing het.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Wys 'n `&Cell<T>` vanaf 'n `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // VEILIGHEID: `&mut` verseker unieke toegang.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Neem die waarde van die sel en laat `Default::default()` op sy plek.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Wys 'n `&[Cell<T>]` vanaf 'n `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // VEILIGHEID: `Cell<T>` het dieselfde geheue-uitleg as `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// 'N Veranderlike geheue-plek met dinamies gekontroleerde leenreëls
///
/// Lees die [module-level documentation](self) vir meer inligting.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// 'N Fout is teruggestuur deur [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// 'N Fout is teruggestuur deur [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Positiewe waardes stel die aantal `Ref` aktief voor.Negatiewe waardes stel die aantal `RefMut` aktief voor.
// Verskeie `RefMut`s kan slegs op 'n slag aktief wees as dit verwys na verskillende, nie-oorvleuelende komponente van 'n `RefCell` (bv. Verskillende reekse van 'n sny).
//
// `Ref` en `RefMut` is albei twee woorde groot, en daarom sal daar waarskynlik nooit genoeg 'Ref''s of' RefMut's bestaan om die helfte van die `usize`-reeks te oorstroom nie.
// Dus sal 'n `BorrowFlag` waarskynlik nooit oorloop of ondervloei nie.
// Dit is egter nie 'n waarborg nie, aangesien 'n patologiese program herhaaldelik mem::forget `Ref`s of`RefMut`s kan skep.
// Dus, alle kode moet eksplisiet op oor-en ondervloei kyk om onveiligheid te vermy, of ten minste korrek moet optree in die geval van oor-of ondervloei (byvoorbeeld, sien BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Skep 'n nuwe `RefCell` wat `value` bevat.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Verbruik die `RefCell` en gee die toegepaste waarde terug.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Aangesien hierdie funksie `self` (die `RefCell`) volgens waarde neem, verifieer die samesteller dat dit nie tans geleen word nie.
        //
        self.value.into_inner()
    }

    /// Vervang die toegedraaide waarde met 'n nuwe waarde en gee die ou waarde terug, sonder om een te deitialiseer.
    ///
    ///
    /// Hierdie funksie kom ooreen met [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics as die waarde tans geleen is.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Vervang die toegedraaide waarde met 'n nuwe waarde wat van `f` bereken is, en sodoende die ou waarde teruggee, sonder om een te desitialiseer.
    ///
    ///
    /// # Panics
    ///
    /// Panics as die waarde tans geleen is.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Ruil die verpakte waarde van `self` met die verpakte waarde van `other` om, sonder om een te deitialiseer.
    ///
    ///
    /// Hierdie funksie kom ooreen met [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics as die waarde in een van die `RefCell` tans geleen word.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Leen die verpakte waarde onveranderlik.
    ///
    /// Die lening duur totdat die teruggekeerde `Ref` van toepassing is.
    /// Verskeie onveranderlike lenings kan op dieselfde tyd uitgeneem word.
    ///
    /// # Panics
    ///
    /// Panics as die waarde tans geleen word.
    /// Gebruik 'n [`try_borrow`](#method.try_borrow) vir 'n nie-paniekerige variant.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// 'N Voorbeeld van panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Leen die verpakte waarde onveranderlik en gee 'n fout as die waarde tans geleen is.
    ///
    ///
    /// Die lening duur totdat die teruggekeerde `Ref` van toepassing is.
    /// Verskeie onveranderlike lenings kan op dieselfde tyd uitgeneem word.
    ///
    /// Dit is die nie-paniekerige variant van [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // VEILIGHEID: `BorrowRef` verseker dat daar slegs onveranderlike toegang is
            // tot die waarde terwyl dit geleen is.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Leen die verpakte waarde mutabel.
    ///
    /// Die lening duur totdat die teruggekeerde `RefMut` of al die 'RefMut`s daaruit verkry word.
    ///
    /// Die waarde kan nie geleen word terwyl die lening aktief is nie.
    ///
    /// # Panics
    ///
    /// Panics as die waarde tans geleen is.
    /// Gebruik 'n [`try_borrow_mut`](#method.try_borrow_mut) vir 'n nie-paniekerige variant.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// 'N Voorbeeld van panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Leen die verpakte waarde op 'n wisselvallige manier en lewer 'n fout op as die waarde tans geleen is.
    ///
    ///
    /// Die lening duur totdat die teruggekeerde `RefMut` of al die 'RefMut`s daaruit verkry word.
    /// Die waarde kan nie geleen word terwyl die lening aktief is nie.
    ///
    /// Dit is die nie-paniekerige variant van [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // VEILIGHEID: `BorrowRef` waarborg unieke toegang.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Wys 'n rou wyser na die onderliggende data in hierdie sel.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Wys 'n veranderlike verwysing na die onderliggende data.
    ///
    /// Hierdie oproep leen `RefCell` veranderlik (tydens kompileringstyd), sodat daar geen dinamiese tjeks nodig is nie.
    ///
    /// Wees egter versigtig: hierdie metode verwag dat `self` veranderbaar sal wees, wat gewoonlik nie die geval is as u 'n `RefCell` gebruik nie.
    ///
    /// Kyk eerder na die [`borrow_mut`]-metode as `self` nie veranderbaar is nie.
    ///
    /// Let ook daarop dat hierdie metode slegs vir spesiale omstandighede bedoel is en gewoonlik nie is wat u wil hê nie.
    /// In geval van twyfel, gebruik eerder [`borrow_mut`].
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Ontdoen die effek van lekkasies op die leenstaat van die `RefCell`.
    ///
    /// Hierdie oproep is soortgelyk aan [`get_mut`], maar meer gespesialiseerd.
    /// Dit leen `RefCell` veranderlik om te verseker dat daar geen lenings bestaan nie en stel dan die staat wat gedeelde lenings dop, na.
    /// Dit is relevant as sommige `Ref`-of `RefMut`-lenings lek.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Leen die verpakte waarde onveranderlik en gee 'n fout as die waarde tans geleen is.
    ///
    /// # Safety
    ///
    /// In teenstelling met `RefCell::borrow`, is hierdie metode onveilig omdat dit nie 'n `Ref` oplewer nie, wat die leenvlag onaangeraak laat.
    /// Dit is ongedefinieerde gedrag om die `RefCell` te verander terwyl die verwysing met hierdie metode lewendig is.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // VEILIGHEID: Ons kyk dat niemand nou aktief skryf nie, maar wel
            // die oproeper se verantwoordelikheid om te verseker dat niemand skryf totdat die teruggekeerde verwysing nie meer gebruik word nie.
            // `self.value.get()` verwys ook na die waarde wat `self` besit en is dus gewaarborg vir die leeftyd van `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Neem die verpakte waarde en laat `Default::default()` op sy plek.
    ///
    /// # Panics
    ///
    /// Panics as die waarde tans geleen is.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics as die waarde tans geleen word.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Skep 'n `RefCell<T>`, met die `Default`-waarde vir T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics as die waarde in een van die `RefCell` tans geleen word.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics as die waarde in een van die `RefCell` tans geleen word.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics as die waarde in een van die `RefCell` tans geleen word.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics as die waarde in een van die `RefCell` tans geleen word.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics as die waarde in een van die `RefCell` tans geleen word.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics as die waarde in een van die `RefCell` tans geleen word.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics as die waarde in een van die `RefCell` tans geleen word.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Verhoging van lenings kan in hierdie gevalle 'n nie-leeswaarde (<=0) tot gevolg hê:
            // 1. Dit was <0, dit wil sê daar is lenings vir die skryf, dus kan ons nie 'n geleende lening toelaat nie weens Rust se verwysingsaliaseringsreëls
            // 2.
            // Dit was isize::MAX (die maksimum hoeveelheid leeslenings) en dit het oorgeloop in isize::MIN (die maksimum aantal lenings wat geskryf is), dus kan ons nie 'n ekstra leeslening toelaat nie, want isize kan nie soveel leeslenings verteenwoordig nie (dit kan slegs gebeur as u mem::forget meer as 'n klein konstante hoeveelheid `Ref`s, wat nie goeie praktyk is nie)
            //
            //
            //
            //
            None
        } else {
            // Verhoging van lenings kan in hierdie gevalle 'n leeswaarde (> 0) tot gevolg hê:
            // 1. Dit was=0, dit wil sê dit is nie geleen nie, en ons neem die eerste geleende lening
            // 2. Dit was> 0 en <isize::MAX, dws
            // daar is gelees-lenings, en isize is groot genoeg om 'n verdere geleende lening te gee
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Aangesien hierdie verwysing bestaan, weet ons dat die leenvlag 'n leeslening is.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Voorkom dat die leenteller oorloop na 'n skriftelike lening.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Wikkel 'n geleende verwysing na 'n waarde in 'n `RefCell`-boks.
/// 'N Wikkel tipe vir 'n onveranderlike geleende waarde van 'n `RefCell<T>`.
///
/// Lees die [module-level documentation](self) vir meer inligting.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Kopieer 'n `Ref`.
    ///
    /// Die `RefCell` is reeds onveranderlik geleen, dus dit kan nie misluk nie.
    ///
    /// Dit is 'n geassosieerde funksie wat as `Ref::clone(...)` gebruik moet word.
    /// 'N `Clone`-implementering of 'n metode sal die wydverspreide gebruik van `r.borrow().clone()` inmeng om die inhoud van 'n `RefCell` te kloon.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Maak 'n nuwe `Ref` vir 'n onderdeel van die geleende data.
    ///
    /// Die `RefCell` is reeds onveranderlik geleen, dus dit kan nie misluk nie.
    ///
    /// Dit is 'n geassosieerde funksie wat as `Ref::map(...)` gebruik moet word.
    /// 'N Metode sal die metodes van dieselfde naam op die inhoud van 'n `RefCell` wat deur `Deref` gebruik word, inmeng.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Maak 'n nuwe `Ref` vir 'n opsionele onderdeel van die geleende data.
    /// Die oorspronklike beskerming word as 'n `Err(..)` terugbesorg as die sluiting `None` terugbesorg.
    ///
    /// Die `RefCell` is reeds onveranderlik geleen, dus dit kan nie misluk nie.
    ///
    /// Dit is 'n geassosieerde funksie wat as `Ref::filter_map(...)` gebruik moet word.
    /// 'N Metode sal die metodes van dieselfde naam op die inhoud van 'n `RefCell` wat deur `Deref` gebruik word, inmeng.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Verdeel 'n `Ref` in veelvoudige 'Ref' vir verskillende komponente van die geleende data.
    ///
    /// Die `RefCell` is reeds onveranderlik geleen, dus dit kan nie misluk nie.
    ///
    /// Dit is 'n geassosieerde funksie wat as `Ref::map_split(...)` gebruik moet word.
    /// 'N Metode sal die metodes van dieselfde naam op die inhoud van 'n `RefCell` wat deur `Deref` gebruik word, inmeng.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Skakel om na 'n verwysing na die onderliggende data.
    ///
    /// Die onderliggende `RefCell` kan nooit weer verander word nie en sal altyd onveranderlik geleen word.
    ///
    /// Dit is nie 'n goeie idee om meer as 'n konstante aantal verwysings te lek nie.
    /// Die `RefCell` kan onveranderlik weer geleen word as slegs 'n kleiner aantal lekkasies in totaal plaasgevind het.
    ///
    /// Dit is 'n geassosieerde funksie wat as `Ref::leak(...)` gebruik moet word.
    /// 'N Metode sal die metodes van dieselfde naam op die inhoud van 'n `RefCell` wat deur `Deref` gebruik word, inmeng.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Deur hierdie verwysing te vergeet, verseker ons dat die leenteller in die RefCell nie binne die leeftyd van `'b` na ONGEBRUIK kan teruggaan nie.
        // Die terugstel van die verwysingsopsporingstoestand vereis 'n unieke verwysing na die geleende RefCell.
        // Geen verdere veranderlike verwysings kan uit die oorspronklike sel geskep word nie.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Maak 'n nuwe `RefMut` vir 'n onderdeel van die geleende data, byvoorbeeld 'n enum-variant.
    ///
    /// Die `RefCell` is al mutant geleen, dus dit kan nie misluk nie.
    ///
    /// Dit is 'n geassosieerde funksie wat as `RefMut::map(...)` gebruik moet word.
    /// 'N Metode sal die metodes van dieselfde naam op die inhoud van 'n `RefCell` wat deur `Deref` gebruik word, inmeng.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): regstel leen-tjek
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Maak 'n nuwe `RefMut` vir 'n opsionele onderdeel van die geleende data.
    /// Die oorspronklike beskerming word as 'n `Err(..)` terugbesorg as die sluiting `None` terugbesorg.
    ///
    /// Die `RefCell` is al mutant geleen, dus dit kan nie misluk nie.
    ///
    /// Dit is 'n geassosieerde funksie wat as `RefMut::filter_map(...)` gebruik moet word.
    /// 'N Metode sal die metodes van dieselfde naam op die inhoud van 'n `RefCell` wat deur `Deref` gebruik word, inmeng.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): regstel leen-tjek
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // VEILIGHEID: funksie hou 'n eksklusiewe verwysing vir die duur
        // van die oproep deur `orig`, en daar word slegs verwys na die wyser binne die funksie-oproep om nooit die eksklusiewe verwysing te laat ontsnap nie.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // VEILIGHEID: dieselfde as hierbo.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Verdeel 'n `RefMut` in veelvuldige 'RefMut`s vir verskillende komponente van die geleende data.
    ///
    /// Die onderliggende `RefCell` sal veranderlik geleen word totdat albei teruggekeerde 'RefMut''s buite omvang gaan.
    ///
    /// Die `RefCell` is al mutant geleen, dus dit kan nie misluk nie.
    ///
    /// Dit is 'n geassosieerde funksie wat as `RefMut::map_split(...)` gebruik moet word.
    /// 'N Metode sal die metodes van dieselfde naam op die inhoud van 'n `RefCell` wat deur `Deref` gebruik word, inmeng.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Skakel om in 'n veranderlike verwysing na die onderliggende data.
    ///
    /// Die onderliggende `RefCell` kan nie weer uitgeleen word nie en sal altyd reeds mutant geleen voorkom, wat die teruggekeerde verwysing die enigste na die binnekant maak.
    ///
    ///
    /// Dit is 'n geassosieerde funksie wat as `RefMut::leak(...)` gebruik moet word.
    /// 'N Metode sal die metodes van dieselfde naam op die inhoud van 'n `RefCell` wat deur `Deref` gebruik word, inmeng.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Deur hierdie BorrowRefMut te vergeet, verseker ons dat die leenteller in die RefCell nie binne die leeftyd van `'b` na ONGEBRUIK kan teruggaan nie.
        // Die terugstel van die verwysingsopsporingstoestand vereis 'n unieke verwysing na die geleende RefCell.
        // Geen verdere verwysings kan binne daardie leeftyd uit die oorspronklike sel geskep word nie, wat die huidige lening die enigste verwysing vir die oorblywende leeftyd maak.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Anders as BorrowRefMut::clone, word nuut geroep om die voorletter te skep
        // veranderlike verwysing, en dus moet daar tans geen bestaande verwysings wees nie.
        // Terwyl kloon dus die veranderlike heropname verhoog, laat ons hier eksplisiet slegs toe om van ONGEBRUIK na ONGEBRUIK te gaan, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Klone 'n `BorrowRefMut`.
    //
    // Dit is slegs geldig as elke `BorrowRefMut` gebruik word om 'n veranderlike verwysing na 'n duidelike, nie-oorvleuelende reeks van die oorspronklike voorwerp na te spoor.
    //
    // Dit is nie in 'n Clone impl nie, sodat die kode dit nie implisiet noem nie.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Voorkom dat die leenteller ondervloei.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// 'N Wikkeltipe vir 'n mutante geleende waarde van 'n `RefCell<T>`.
///
/// Lees die [module-level documentation](self) vir meer inligting.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Die kern primitief vir interieur veranderlikheid in Rust.
///
/// As u 'n verwysing `&T` het, voer die samesteller normaalweg in Rust optimalisasies uit gebaseer op die kennis dat `&T` op onveranderlike data wys.Om die data te verander, byvoorbeeld deur 'n alias of deur 'n `&T` in 'n `&mut T` oor te dra, word as ongedefinieerde gedrag beskou.
/// `UnsafeCell<T>` kies uit die waarborg vir onveranderlikheid vir `&T`: 'n gedeelde verwysing `&UnsafeCell<T>` kan dui op data wat gemuteer word.Dit word "interior mutability" genoem.
///
/// Alle ander tipes wat interne veranderlikhede toelaat, soos `Cell<T>` en `RefCell<T>`, gebruik `UnsafeCell` intern om hul data te verpak.
///
/// Let daarop dat `UnsafeCell` slegs die waarborg vir onveranderlikheid vir gedeelde verwysings beïnvloed.Die uniekheidswaarborg vir veranderlike verwysings word nie beïnvloed nie.Daar is *geen* wettige manier om 'n aliasing van `&mut` te verkry nie, selfs nie met `UnsafeCell<T>` nie.
///
/// Die `UnsafeCell` API self is tegnies baie eenvoudig: [`.get()`] gee u 'n rou wyser `*mut T` na die inhoud daarvan.Dit is tot _you_ om die abstrakte ontwerper korrek te gebruik as die abstrakte ontwerper.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Die presiese Rust-aliaseringsreëls is ietwat aan die gang, maar die hoofpunte is nie omstrede nie:
///
/// - As u 'n veilige verwysing met 'n lewenslange `'a` ('n `&T`-of `&mut T`-verwysing) skep wat toeganklik is met 'n veilige kode (byvoorbeeld omdat u dit terugbesorg het), moet u nie toegang tot die data hê op enige manier wat die resensie weerspreek nie van `'a`.
/// Dit beteken byvoorbeeld dat as u die `*mut T` van 'n `UnsafeCell<T>` neem en dit na 'n `&T` gooi, dan moet die data in `T` onveranderlik bly (modulo alle `UnsafeCell`-data wat natuurlik binne `T` gevind word) totdat die lewensduur van die verwysing verval.
/// Net so, as u 'n `&mut T`-verwysing skep wat vrygestel word na veilige kode, moet u nie toegang tot die data binne die `UnsafeCell` hê voordat die verwysing verval nie.
///
/// - U moet te alle tye dateresies vermy.As veelvuldige drade toegang tot dieselfde `UnsafeCell` het, moet enige skrywes 'n regte gebeurtenis hê voor alle ander toegang (of gebruik atoom).
///
/// Om die regte ontwerp te help, word die volgende scenario's uitdruklik wettig verklaar vir enkeldraadkode:
///
/// 1. 'N `&T`-verwysing kan vrygestel word na veilige kode en daar kan dit saam met ander `&T`-verwysings bestaan, maar nie met 'n `&mut T` nie.
///
/// 2. 'N `&mut T`-verwysing kan na veilige kode vrygestel word, mits geen ander `&mut T` of `&T` daarmee saam bestaan nie.'N `&mut T` moet altyd uniek wees.
///
/// Let daarop dat die mutasie van die inhoud van 'n `&UnsafeCell<T>` (alhoewel ander `&UnsafeCell<T>` na alias in die sel verwys) ok is (mits u bogenoemde invariërs op 'n ander manier afdwing), is dit steeds ongedefinieerde gedrag om veelvuldige `&mut UnsafeCell<T>`-aliasse te hê.
/// Dit wil sê, `UnsafeCell` is 'n omslag wat ontwerp is om 'n spesiale interaksie met _shared_ accesses (_i.e._ te hê, deur middel van 'n `&UnsafeCell<_>`-verwysing);daar is geen towerkuns hoegenaamd as u met _exclusive_ accesses (_e.g._, deur middel van 'n `&mut UnsafeCell<_>`, handel nie: nie die sel of die toegedraaide waarde mag gedurende die duur van die `&mut`-lening 'n alias wees nie.
///
/// Dit word getoon deur die [`.get_mut()`] accessor, wat 'n _safe_ getter is wat 'n `&mut T` lewer.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Hier is 'n voorbeeld wat aandui hoe die inhoud van 'n `UnsafeCell<_>` op 'n goeie manier gemuteer kan word, alhoewel daar verskeie verwysings is wat die sel alias:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Kry verskeie/gedeelde verwysings na dieselfde `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // VEILIGHEID: binne hierdie omvang is daar geen ander verwysings na die inhoud van 'x' nie,
///     // ons s`n is dus effektief uniek.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- leen-+
///     *p1_exclusive += 27; // |
/// } // <---------- kan nie verder gaan as hierdie punt nie -------------------+
///
/// unsafe {
///     // VEILIGHEID: binne hierdie bestek verwag niemand dat hulle eksklusiewe toegang tot die inhoud van 'x' sal hê nie,
///     // sodat ons gelyktydig verskeie gedeelde toegang kan hê.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Die volgende voorbeeld toon die feit dat eksklusiewe toegang tot 'n `UnsafeCell<T>` eksklusiewe toegang tot sy `T` impliseer:
///
/// ```rust
/// #![forbid(unsafe_code)] // met eksklusiewe toegang,
///                         // `UnsafeCell` is 'n deursigtige no-op-verpakking, dus is `unsafe` nie hier nodig nie.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Kry 'n unieke verwysing na `x` wat deur die kompileringstyd gekontroleer word.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Met 'n eksklusiewe verwysing kan ons die inhoud gratis verander.
/// *p_unique.get_mut() = 0;
/// // Of, gelykstaande:
/// x = UnsafeCell::new(0);
///
/// // As ons die waarde besit, kan ons die inhoud gratis onttrek.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Konstrueer 'n nuwe instansie van `UnsafeCell` wat die gespesifiseerde waarde sal omvou.
    ///
    ///
    /// Alle toegang tot die innerlike waarde deur middel van metodes is `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Pak die waarde uit.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Kry 'n veranderlike wyser na die toegedraaide waarde.
    ///
    /// Dit kan op enige wyser gegooi word.
    /// Verseker dat die toegang uniek is (geen aktiewe verwysings, veranderbaar of nie) wanneer u na `&mut T` gooi, en maak seker dat daar geen mutasies of veranderlike aliasse plaasvind wanneer u na `&T` gooi nie
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Ons kan die wyser net van `UnsafeCell<T>` na `T` gooi as gevolg van #[repr(transparent)].
        // Hiermee word die spesiale status van libstd benut, daar is geen waarborg vir die gebruikerskode dat dit in die future-weergawes van die samesteller sal werk nie!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Wys 'n veranderlike verwysing na die onderliggende data.
    ///
    /// Hierdie oproep leen die `UnsafeCell` veranderlik (tydens kompileringstyd), wat waarborg dat ons die enigste verwysing het.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Kry 'n veranderlike wyser na die toegedraaide waarde.
    /// Die verskil aan [`get`] is dat hierdie funksie 'n rou wyser aanvaar, wat nuttig is om tydelike verwysings te skep.
    ///
    /// Die resultaat kan na enige wyser gegooi word.
    /// Verseker dat die toegang uniek is (geen aktiewe verwysings, veranderbaar of nie) wanneer u na `&mut T` gooi, en maak seker dat daar geen mutasies of veranderlike aliasse plaasvind wanneer u na `&T` gooi nie.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Geleidelike inisiëring van 'n `UnsafeCell` vereis `raw_get`, aangesien die oproep van `get` vereis dat 'n verwysing na nie-geïnitialiseerde data geskep moet word:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Ons kan die wyser net van `UnsafeCell<T>` na `T` gooi as gevolg van #[repr(transparent)].
        // Hiermee word die spesiale status van libstd benut, daar is geen waarborg vir die gebruikerskode dat dit in die future-weergawes van die samesteller sal werk nie!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Skep 'n `UnsafeCell`, met die `Default`-waarde vir T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}