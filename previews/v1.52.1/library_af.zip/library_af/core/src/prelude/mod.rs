//! Die libcore prelude
//!
//! Hierdie module is bedoel vir gebruikers van libcore wat ook nie na libstd skakel nie.
//! Hierdie module word standaard ingevoer as `#![no_std]` op dieselfde manier gebruik word as die standaardbiblioteek se prelude.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Die 2015-weergawe van die kern prelude.
///
/// Lees die [module-level documentation](self) vir meer inligting.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Die 2018-weergawe van die kern prelude.
///
/// Lees die [module-level documentation](self) vir meer inligting.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Die 2021-weergawe van die kern prelude.
///
/// Lees die [module-level documentation](self) vir meer inligting.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Voeg nog dinge by.
}