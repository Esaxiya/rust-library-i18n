//! Makro's wat deur iteratore van sny gebruik word.

// Inlyne is_vol en len maak 'n groot prestasieverskil
macro_rules! is_empty {
    // Die manier waarop ons die lengte van 'n ZST-iterator kodeer, dit werk beide vir ZST en nie-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Om van 'n paar perke-tjeks ontslae te raak (bereken `position`), bereken ons die lengte op 'n ietwat onverwagte manier.
// (Getoets deur 'codegen/slice-position-bounds-check'.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // ons word soms binne 'n onveilige blok gebruik

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Hierdie _cannot_ gebruik `unchecked_sub` omdat ons afhanklik is van die verpakking om die lengte van lang ZST sny-iteratore voor te stel.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Ons weet dat `start <= end` dus beter kan vaar as `offset_from`, wat onderteken moet word.
            // Deur hier toepaslike vlaggies in te stel, kan ons dit vir LLVM vertel, wat u help om perke-tjeks te verwyder.
            // VEILIGHEID: Volgens die tipe invariant, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Deur ook aan LLVM te vertel dat die aanwysers met 'n presiese veelvoud van die tipe grootte uitmekaar is, kan dit `len() == 0` tot `start == end` in plaas van `(end - start) < size` optimaliseer.
            //
            // VEILIGHEID: Volgens die tipe invariant is die wysers in lyn sodat die
            //         die afstand tussen hulle moet 'n veelvoud van die wyser wees
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Die gedeelde definisie van die `Iter`-en `IterMut`-iteratore
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Wys die eerste element terug en beweeg die begin van die iterator met 1 vorentoe.
        // Verbeter die prestasie aansienlik in vergelyking met 'n ingelyste funksie.
        // Die herhaling mag nie leeg wees nie.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Wys die laaste element en beweeg die einde van die iterator met 1 agteruit.
        // Verbeter die prestasie aansienlik in vergelyking met 'n ingelyste funksie.
        // Die herhaling mag nie leeg wees nie.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Krimp die iterator wanneer T 'n ZST is, deur die einde van die iterator met `n` agteruit te skuif.
        // `n` mag nie `self.len()` oorskry nie.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Helperfunksie vir die skep van 'n deel van die iterator.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // VEILIGHEID: die iterator is geskep uit 'n sny met wyser
                // `self.ptr` en lengte `len!(self)`.
                // Dit verseker dat al die voorvereistes vir `from_raw_parts` nagekom word.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Helperfunksie om die begin van die iterator met `offset`-elemente vorentoe te skuif, om die ou begin terug te gee.
            //
            // Onveilig omdat die verrekening nie `self.len()` mag oorskry nie.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // VEILIGHEID: die beller waarborg dat `offset` nie `self.len()` oorskry nie,
                    // hierdie nuwe wyser is dus binne `self` en is dus gewaarborg dat dit nie-nul is.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Helperfunksie om die einde van die iterator met `offset`-elemente agteruit te skuif en die nuwe punt terug te gee.
            //
            // Onveilig omdat die verrekening nie `self.len()` mag oorskry nie.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // VEILIGHEID: die beller waarborg dat `offset` nie `self.len()` oorskry nie,
                    // wat verseker is dat dit nie 'n `isize` sal oorloop nie.
                    // Die resulterende wyser is ook in grense van `slice`, wat aan die ander vereistes vir `offset` voldoen.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // kan met skywe geïmplementeer word, maar dit vermy perke

                // VEILIGHEID: `assume`-oproepe is veilig aangesien die beginwyser van 'n stuk is
                // moet nie-nul wees, en snye oor nie-ZST's moet ook 'n nie-nul-eindwyser hê.
                // Die oproep na `next_unchecked!` is veilig, aangesien ons eers nagaan of die iterator leeg is.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Hierdie herhaling is nou leeg.
                    if mem::size_of::<T>() == 0 {
                        // Ons moet dit so doen, want `ptr` is miskien nooit 0 nie, maar `end` kan wel wees (as gevolg van verpakking).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // VEILIGHEID: einde kan nie 0 wees as T nie ZST is nie omdat ptr nie 0 is nie en einde>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // VEILIGHEID: Ons is binne perke.`post_inc_start` doen die regte ding selfs vir ZST's.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Ons vervang die standaardimplementering, wat `try_fold` gebruik, omdat hierdie eenvoudige implementering minder LLVM IR genereer en vinniger is om saam te stel.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Ons vervang die standaardimplementering, wat `try_fold` gebruik, omdat hierdie eenvoudige implementering minder LLVM IR genereer en vinniger is om saam te stel.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Ons vervang die standaardimplementering, wat `try_fold` gebruik, omdat hierdie eenvoudige implementering minder LLVM IR genereer en vinniger is om saam te stel.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Ons vervang die standaardimplementering, wat `try_fold` gebruik, omdat hierdie eenvoudige implementering minder LLVM IR genereer en vinniger is om saam te stel.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Ons vervang die standaardimplementering, wat `try_fold` gebruik, omdat hierdie eenvoudige implementering minder LLVM IR genereer en vinniger is om saam te stel.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Ons vervang die standaardimplementering, wat `try_fold` gebruik, omdat hierdie eenvoudige implementering minder LLVM IR genereer en vinniger is om saam te stel.
            // Die `assume` vermy ook 'n perke-tjek.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // VEILIGHEID: ons word gewaarborg deur die lus-invariant:
                        // wanneer `i >= n`, `self.next()` `None` terugbesorg en die lus breek.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Ons vervang die standaardimplementering, wat `try_fold` gebruik, omdat hierdie eenvoudige implementering minder LLVM IR genereer en vinniger is om saam te stel.
            // Die `assume` vermy ook 'n perke-tjek.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // VEILIGHEID: `i` moet laer wees as `n`, aangesien dit by `n` begin
                        // en neem net af.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // VEILIGHEID: die beller moet waarborg dat `i` binne perke is
                // die onderliggende sny, sodat `i` nie 'n `isize` kan oorloop nie, en die teruggekeerde verwysings is gewaarborg om na 'n element van die sny te verwys en is dus gewaarborg.
                //
                // Let ook daarop dat die oproeper ook waarborg dat ons nooit weer met dieselfde indeks gebel word nie, en dat daar geen ander metodes word wat toegang tot hierdie subskyf kry nie. Dit is dus geldig dat die teruggekeerde verwysing veranderbaar is in die geval van
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // kan met skywe geïmplementeer word, maar dit vermy perke

                // VEILIGHEID: `assume`-oproepe is veilig, aangesien die beginwyser van 'n stuk nie-null moet wees,
                // en snye oor nie-ZST's moet ook 'n nie-nul-eindwyser hê.
                // Die oproep na `next_back_unchecked!` is veilig, aangesien ons eers nagaan of die iterator leeg is.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Hierdie herhaling is nou leeg.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // VEILIGHEID: Ons is binne perke.`pre_dec_end` doen die regte ding selfs vir ZST's.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}