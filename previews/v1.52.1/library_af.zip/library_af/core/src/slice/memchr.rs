// Oorspronklike implementering geneem uit rust-memchr.
// Kopiereg 2015 Andrew Gallant, bluss en Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Gebruik afkapping.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Wys `true` as `x` enige byte bevat.
///
/// Uit *Matters Computational*, J. Arndt:
///
/// "Die idee is om een van elk van die grepe af te trek en dan na grepe te soek waar die lening tot by die belangrikste gepropageer is.
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Wys die eerste indeks wat ooreenstem met die byte `x` in `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Vinnige pad vir klein skywe
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Soek na een byte-waarde deur twee `usize`-woorde tegelyk te lees.
    //
    // Verdeel `text` in drie dele
    // - onbelynde aanvanklike deel, voor die eerste woordbelynde adres in die teks
    // - liggaam, skandeer met twee woorde op 'n slag
    // - die laaste oorblywende deel, <2 woordgrootte

    // soek tot by 'n uitlynlyn
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // soek die liggaam van die teks
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // VEILIGHEID: die while-predikaat waarborg 'n afstand van minstens 2 * usize_bytes
        // tussen die offset en die einde van die sny.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // breek as daar 'n byte is wat ooreenstem
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Bepaal die byte na die punt waarop die liggaamslus stop.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Wys die laaste indeks wat ooreenstem met die byte `x` in `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Soek na een byte-waarde deur twee `usize`-woorde tegelyk te lees.
    //
    // Verdeel `text` in drie dele:
    // - onbelynde stert, na die laaste woordgerigte adres in teks,
    // - liggaam, met twee woorde op 'n slag geskandeer,
    // - die eerste oorblywende grepe, <2 woordgrootte.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Ons noem dit net om die lengte van die voor-en agtervoegsel te verkry.
        // In die middel verwerk ons altyd twee stukke gelyktydig.
        // VEILIGHEID: om `[u8]` na `[usize]` te transformeer, is veilig, behalwe vir grootteverskille wat deur `align_to` hanteer word.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Soek in die hoofletter van die teks en maak seker dat ons nie die min_bepaalde verrekening oorskry nie.
    // offset is altyd in lyn, dus net die toets van `>` is voldoende en vermy moontlike oorloop.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // VEILIGHEID: verrekening begin by len, suffix.len(), solank dit groter is as
        // min_aligned_offset (prefix.len()) is die oorblywende afstand minstens 2 * stuk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Breek as daar 'n byte is wat ooreenstem.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Soek die byte voor die punt waarop die liggaamslus gestop het.
    text[..offset].iter().rposition(|elt| *elt == x)
}