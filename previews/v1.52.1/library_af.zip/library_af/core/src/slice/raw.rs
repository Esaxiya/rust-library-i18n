//! Gratis funksies om `&[T]` en `&mut [T]` te skep.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Vorm 'n sny van 'n wyser en 'n lengte.
///
/// Die `len`-argument is die aantal **elemente**, nie die aantal grepe nie.
///
/// # Safety
///
/// Gedrag is ongedefinieerd as een van die volgende voorwaardes oortree word:
///
/// * `data` moet [valid] wees vir lees vir `len * mem::size_of::<T>()` baie grepe, en dit moet behoorlik in lyn wees.Dit beteken veral:
///
///     * Die hele geheue-reeks van hierdie sny moet binne 'n enkele toegekende voorwerp vervat wees!
///       Snye kan nooit oor veelvuldige toegekende voorwerpe strek nie.Kyk [below](#incorrect-usage) vir 'n voorbeeld wat verkeerdelik nie in ag geneem word nie.
///     * `data` moet nie-nul wees en selfs vir snitte met 'n nul lengte in lyn wees.
///     Een rede hiervoor is dat die optimering van enum-uitleg daarop kan staatmaak dat verwysings (insluitend snye van enige lengte) in lyn is en nie-nul is om dit van ander data te onderskei.
///     U kan 'n aanwyser verkry wat as `data` gebruik kan word vir snylengtes met [`NonNull::dangling()`].
///
/// * `data` moet wys op `len` opeenvolgende behoorlik geïnisialiseerde waardes van die tipe `T`.
///
/// * Die geheue waarna die teruggedeelde stuk verwys, mag nie gedurende die leeftyd van `'a` gemuteer word nie, behalwe in 'n `UnsafeCell`.
///
/// * Die totale grootte `len * mem::size_of::<T>()` van die sny mag nie groter as `isize::MAX` wees nie.
///   Sien die veiligheidsdokumentasie van [`pointer::offset`].
///
/// # Caveat
///
/// Die gebruiksduur van die sny word afgelei.
/// Om per ongeluk misbruik te voorkom, word voorgestel om die lewensduur te koppel aan die bron se leeftyd wat veilig is in die konteks, soos deur 'n hulpfunksie te bied wat die leeftyd van 'n gasheerwaarde vir die sny neem, of deur eksplisiete aantekeninge.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // manifesteer 'n sny vir 'n enkele element
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Verkeerde gebruik
///
/// Die volgende `join_slices`-funksie is **onklink** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Die bewering hierbo verseker dat `fst` en `snd` aaneengeslote is, maar dit kan steeds in _different allocated objects_ vervat word. In hierdie geval is die skep van hierdie sny ongedefinieerde gedrag.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` en `b` is verskillende toegekende voorwerpe ...
///     let a = 42;
///     let b = 27;
///     // ... wat nietemin aangrensend in die geheue uitgelê kan word: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // VEILIGHEID: die beller moet die veiligheidskontrak vir `from_raw_parts` handhaaf.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Voer dieselfde funksionaliteit uit as [`from_raw_parts`], behalwe dat 'n veranderbare snit teruggestuur word.
///
/// # Safety
///
/// Gedrag is ongedefinieerd as een van die volgende voorwaardes oortree word:
///
/// * `data` moet [valid] wees vir beide lees en skryf vir baie grepe vir `len * mem::size_of::<T>()`, en dit moet behoorlik in lyn wees.Dit beteken veral:
///
///     * Die hele geheue-reeks van hierdie sny moet binne 'n enkele toegekende voorwerp vervat wees!
///       Snye kan nooit oor veelvuldige toegekende voorwerpe strek nie.
///     * `data` moet nie-nul wees en selfs vir snitte met 'n nul lengte in lyn wees.
///     Een rede hiervoor is dat die optimering van enum-uitleg daarop kan staatmaak dat verwysings (insluitend snye van enige lengte) in lyn is en nie-nul is om dit van ander data te onderskei.
///
///     U kan 'n aanwyser verkry wat as `data` gebruik kan word vir snylengtes met [`NonNull::dangling()`].
///
/// * `data` moet wys op `len` opeenvolgende behoorlik geïnisialiseerde waardes van die tipe `T`.
///
/// * Die geheue waarna die teruggekeerde plak verwys, moet gedurende enige leeftyd van `'a` nie verkry word deur enige ander aanwyser (nie afgelei van die terugkeerwaarde nie).
///   Beide toegang tot lees en skryf is verbode.
///
/// * Die totale grootte `len * mem::size_of::<T>()` van die sny mag nie groter as `isize::MAX` wees nie.
///   Sien die veiligheidsdokumentasie van [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // VEILIGHEID: die beller moet die veiligheidskontrak vir `from_raw_parts_mut` handhaaf.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Skakel 'n verwysing na T in 'n snit van lengte 1 (sonder kopiëring).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Skakel 'n verwysing na T in 'n snit van lengte 1 (sonder kopiëring).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}