// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Draai die reeks `[mid-left, mid+right)` so dat die element by `mid` die eerste element word.Draai die reeks `left`-elemente ewewydig na links of `right`-elemente na regs.
///
/// # Safety
///
/// Die gespesifiseerde reeks moet geldig wees vir lees en skryf.
///
/// # Algorithm
///
/// Algoritme 1 word gebruik vir klein waardes van `left + right` of vir groot `T`.
/// Die elemente word een vir een in hul finale posisies geskuif, begin by `mid - left` en vorder met `right`-stappe modulo `left + right`, sodat slegs een tydelike nodig is.
/// Uiteindelik kom ons terug by `mid - left`.
/// As `gcd(left + right, right)` egter nie 1 is nie, gaan die bogenoemde stappe oor elemente.
/// Byvoorbeeld:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Gelukkig is die aantal oorgeslaande elemente tussen gefinaliseerde elemente altyd gelyk, dus kan ons net ons beginposisie verreken en meer rondes doen (die totale aantal rondes is die `gcd(left + right, right)` value).
///
/// Die eindresultaat is dat alle elemente eenmalig en net een keer gefinaliseer word.
///
/// Algoritme 2 word gebruik as `left + right` groot is, maar `min(left, right)` klein genoeg is om op 'n stapelbuffer te pas.
/// Die `min(left, right)`-elemente word op die buffer gekopieër, `memmove` word op die ander toegepas en die elemente op die buffer word weer in die gat aan die oorkant van die plek waar hulle ontstaan het, verskuif.
///
/// Algoritmes wat gevektoriseer kan word, oortref die bogenoemde sodra `left + right` groot genoeg word.
/// Algoritme 1 kan gevektoreer word deur baie rondes tegelykertyd uit te voer, maar gemiddeld is daar te min rondtes totdat `left + right` enorm is, en die ergste geval van 'n enkele rondte is altyd daar.
/// In plaas daarvan gebruik algoritme 3 herhaalde ruil van `min(left, right)`-elemente totdat 'n kleiner draai-probleem oorbly.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// as `left < right` eerder van links afruil.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. die onderstaande algoritmes kan misluk as hierdie gevalle nie nagegaan word nie
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algoritme 1 Microbenchmarks dui aan dat die gemiddelde prestasie vir ewekansige skofte tot op ongeveer `left + right == 32` beter is, maar die slegste prestasie is selfs ongeveer 16.
            // 24 is as middelgrond gekies.
            // As die grootte van `T` groter is as 4 'grootte, oortref hierdie algoritme ook beter as ander algoritmes.
            //
            //
            let x = unsafe { mid.sub(left) };
            // begin van die eerste ronde
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` kan voor die hand gevind word deur `gcd(left + right, right)` te bereken, maar dit is vinniger om een lus te doen wat die gcd as newe-effek bereken, en dan die res van die stuk te doen
            //
            //
            let mut gcd = right;
            // maatstawwe onthul dat dit vinniger is om tydeliks deur te ruil in plaas daarvan om een tydelike eenmal te lees, agteruit te kopieer en dan daardie tydelike aan die einde te skryf.
            // Dit is moontlik te wyte aan die feit dat die uitruil of vervanging van tydelike slegs een geheueadres in die lus gebruik, in plaas daarvan om twee te moet bestuur.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // in plaas daarvan om `i` te verhoog en dan te kyk of dit buite die perke is, gaan ons na of `i` buite die perke gaan met die volgende toename.
                // Dit voorkom dat die aanwysers of `usize` toegedraai word.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // einde van die eerste ronde
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // hierdie voorwaardelike moet hier wees as `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // eindig die stuk met nog rondtes
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` is nie 'n nulgrootte tipe nie, dus dit is goed om deur die grootte daarvan te deel.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algoritme 2 Die `[T; 0]` is hier om te verseker dat dit toepaslik in lyn is met T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algoritme 3 Daar is 'n alternatiewe manier om te ruil wat behels om te bepaal waar die laaste ruil van hierdie algoritme sou wees, en om te ruil met die laaste stuk in plaas van omruilende stukke om te ruil soos hierdie algoritme doen, maar hierdie manier is nog steeds vinniger.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algoritme 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}