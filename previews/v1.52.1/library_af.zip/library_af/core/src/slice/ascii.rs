//! Werksaamhede op ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Kontroleer of al die grepe in hierdie deel binne die ASCII-reeks is.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Kontroleer of twee snye 'n ASCII-saakgevoelige pas is.
    ///
    /// Dieselfde as `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, maar sonder tydelike toekenning en kopiëring.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Skakel hierdie sny om na die ASCII-hoofletter-ekwivalent in die plek.
    ///
    /// ASCII-letters 'a' tot 'z' word gekoppel aan 'A' tot 'Z', maar nie-ASCII-letters is onveranderd.
    ///
    /// Gebruik [`to_ascii_uppercase`] om 'n nuwe hoofletterwaarde terug te gee sonder om die bestaande waarde te wysig.
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Skakel hierdie sny om na die ASCII-kleinletter-ekwivalent in die plek.
    ///
    /// ASCII-letters 'A' tot 'Z' word gekoppel aan 'a' tot 'z', maar nie-ASCII-letters is onveranderd.
    ///
    /// Gebruik [`to_ascii_lowercase`] om 'n nuwe waarde met 'n laer waarde terug te gee sonder om die bestaande waarde te wysig.
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Wys `true` as enige byte in die woord `v` nonascii is (>=128).
/// Snarfed van `../str/mod.rs`, wat iets soortgelyks doen vir utf8-validering.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Geoptimaliseerde ASCII-toets wat gebruik-op-tyd-bewerkings sal gebruik in plaas van byte-op-een-tyd-bewerkings (indien moontlik).
///
/// Die algoritme wat ons hier gebruik, is redelik eenvoudig.As `s` te kort is, gaan ons elke greep na en is daarmee klaar.Andersins:
///
/// - Lees die eerste woord met 'n onbelynde las.
/// - Rig die wyser uit, lees die daaropvolgende woorde tot die einde met uitgeluste vragte.
/// - Lees die laaste `usize` van `s` met 'n ongerigte vrag.
///
/// As een van hierdie ladings iets lewer waarvoor `contains_nonascii` (above) waar is, dan weet ons dat die antwoord onwaar is.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // As ons niks met die woord-op-een-tyd-implementering sou verdien nie, val dan terug na 'n skalêre lus.
    //
    // Ons doen dit ook vir argitekture waar `size_of::<usize>()` nie voldoende belyning vir `usize` is nie, want dit is 'n vreemde edge-geval.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Ons lees altyd die eerste woord onbelyn, wat beteken dat `align_offset` is
    // 0, sal ons dieselfde waarde weer lees vir die belynde lees.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // VEILIGHEID: Ons verifieer `len < USIZE_SIZE` hierbo.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Ons het dit hierbo, ietwat implisiet, nagegaan.
    // Let daarop dat `offset_to_aligned` óf `align_offset` óf `USIZE_SIZE` is. Albei word eksplisiet hierbo nagegaan.
    //
    debug_assert!(offset_to_aligned <= len);

    // VEILIGHEID: word_ptr is die (behoorlik belynde) grootte ptr wat ons gebruik om die te lees
    // middelste stuk van die sny.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` is die byte-indeks van `word_ptr`, wat gebruik word vir lus-eindkontroles.
    let mut byte_pos = offset_to_aligned;

    // Paranoia kyk na die belyning, want ons is op die punt om 'n klomp ongerigte vragte te doen.
    // In die praktyk moet dit egter onmoontlik wees om 'n fout in `align_offset` te voorkom.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Lees daaropvolgende woorde tot die laaste gerigte woord, met uitsluiting van die laaste gerigte woord op sigself wat later in stertkontrole gedoen moet word, om te verseker dat die stert altyd hoogstens een `usize` is tot ekstra tak `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Sanity moet seker maak dat die lees binne perke is
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // En dat ons aannames oor `byte_pos` geld.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // VEILIGHEID: Ons weet dat `word_ptr` behoorlik in lyn is (as gevolg van
        // 'align_offset'), en ons weet dat ons genoeg bytes het tussen `word_ptr` en die einde
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // VEILIGHEID: Ons weet dat `byte_pos <= len - USIZE_SIZE`, wat beteken dat
        // na hierdie `add` sal `word_ptr` hoogstens een-aan-die-einde wees.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Sanity check om te verseker dat daar regtig net een `usize` oor is.
    // Dit moet gewaarborg word deur ons lustoestand.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // VEILIGHEID: Dit berus op `len >= USIZE_SIZE`, wat ons aan die begin nagaan.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}