//! Sny sorteer
//!
//! Hierdie module bevat 'n sorteeralgoritme gebaseer op Orson Peters se patroonverslaanende kwiksort, gepubliseer op: <https://github.com/orlp/pdqsort>
//!
//!
//! Onstabiele sorteer is versoenbaar met libcore omdat dit nie geheue toewys nie, anders as ons stabiele sorteerimplementering.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Wanneer dit afgelaai word, kopieer dit van `src` na `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // VEILIGHEID: Dit is 'n helperklas.
        //          Verwys na die gebruik daarvan vir korrektheid.
        //          'N Mens moet naamlik seker wees dat `src` en `dst` nie oorvleuel soos vereis deur `ptr::copy_nonoverlapping` nie.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Skuif die eerste element na regs totdat dit 'n groter of gelyke element teëkom.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // VEILIGHEID: Onderstaande onveilige bedrywighede behels indeksering sonder gebonde tjek (`get_unchecked` en `get_unchecked_mut`)
    // en kopieer geheue (`ptr::copy_nonoverlapping`).
    //
    // a.Indeksering:
    //  1. Ons het die grootte van die skikking na>=2 nagegaan.
    //  2. Al die indeksering wat ons sal doen, is hoogstens altyd tussen {0 <= index < len}.
    //
    // b.Geheue kopiëring
    //  1. Ons kry aanwysings na verwysings wat gewaarborg is om geldig te wees.
    //  2. Hulle kan nie oorvleuel nie, want ons kry aanwysings na die verskilindekse van die sny.
    //     Naamlik `i` en `i-1`.
    //  3. As die sny behoorlik in lyn is, is die elemente behoorlik in lyn.
    //     Dit is die verantwoordelikheid van die beller om seker te maak dat die sny reg is.
    //
    // Sien kommentaar hieronder vir verdere besonderhede.
    unsafe {
        // As die eerste twee elemente buite werking is ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Lees die eerste element in 'n veranderlike wat aan stapels toegeken is.
            // As 'n volgende vergelykingsbewerking panics, `hole` val, sal die element outomaties in die sny teruggeskryf word.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Beweeg `i`-de element een plek na links en skuif die gat na regs.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` word laat val en kopieer dus `tmp` in die oorblywende gat in `v`.
        }
    }
}

/// Skuif die laaste element na links totdat dit 'n kleiner of gelyke element teëkom.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // VEILIGHEID: Onderstaande onveilige bedrywighede behels indeksering sonder gebonde tjek (`get_unchecked` en `get_unchecked_mut`)
    // en kopieer geheue (`ptr::copy_nonoverlapping`).
    //
    // a.Indeksering:
    //  1. Ons het die grootte van die skikking na>=2 nagegaan.
    //  2. Al die indeksering wat ons gaan doen, is altyd hoogstens tussen `0 <= index < len-1`.
    //
    // b.Geheue kopiëring
    //  1. Ons kry aanwysings na verwysings wat gewaarborg is om geldig te wees.
    //  2. Hulle kan nie oorvleuel nie, want ons kry aanwysings na die verskilindekse van die sny.
    //     Naamlik `i` en `i+1`.
    //  3. As die sny behoorlik in lyn is, is die elemente behoorlik in lyn.
    //     Dit is die verantwoordelikheid van die beller om seker te maak dat die sny reg is.
    //
    // Sien kommentaar hieronder vir verdere besonderhede.
    unsafe {
        // As die laaste twee elemente buite werking is ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Lees die laaste element in 'n stapel-toegekende veranderlike.
            // As 'n volgende vergelykingsbewerking panics, `hole` val, sal die element outomaties in die sny teruggeskryf word.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Beweeg `i`-de element een plek na regs, en skuif die gat na links.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` word laat val en kopieer dus `tmp` in die oorblywende gat in `v`.
        }
    }
}

/// Sorteer 'n deel gedeeltelik deur verskillende buite-orde elemente te skuif.
///
/// Wys `true` as die sny aan die einde gesorteer is.Hierdie funksie is *O*(*n*) in die ergste geval.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Maksimum aantal aangrensende pare wat buite werking is, sal verskuif word.
    const MAX_STEPS: usize = 5;
    // As die sny korter as hierdie is, moenie enige elemente skuif nie.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // VEILIGHEID: Ons het die gebonde kontrole reeds met `i < len` uitdruklik gedoen.
        // Al ons daaropvolgende indeksering is slegs in die reeks `0 <= index < len`
        unsafe {
            // Soek die volgende paar aangrensende elemente wat buite werking is.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Is ons klaar?
        if i == len {
            return true;
        }

        // Moenie elemente op kort skikkings skuif nie, dit het 'n prestasiekoste.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Ruil die gevindte elemente om.Dit plaas hulle in die regte volgorde.
        v.swap(i - 1, i);

        // Skuif die kleiner element na links.
        shift_tail(&mut v[..i], is_less);
        // Skuif die groter element na regs.
        shift_head(&mut v[i..], is_less);
    }

    // Het nie daarin geslaag om die sny in die beperkte aantal stappe te sorteer nie.
    false
}

/// Sorteer 'n sny met behulp van invoegingsoort, wat die ergste geval is *O*(*n*^ 2).
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Sorteer `v` met behulp van heapsort, wat *O*(*n*\*log(* n*)) in die ergste geval waarborg.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Hierdie binêre hoop respekteer die onveranderlike `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Kinders van `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Kies die groter kind.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Stop as die invariant op `node` hou.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Ruil `node` met die groter kind, beweeg een tree af en gaan voort met sif.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Bou die hoop in lineêre tyd.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pop maksimale elemente van die hoop.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Partisies `v` in elemente kleiner as `pivot`, gevolg deur elemente groter as of gelyk aan `pivot`.
///
///
/// Wys die aantal elemente kleiner as `pivot`.
///
/// Partisies word blok-vir-blok uitgevoer om die koste van vertakkings te verminder.
/// Hierdie idee word in die [BlockQuicksort][pdf]-artikel aangebied.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Aantal elemente in 'n tipiese blok.
    const BLOCK: usize = 128;

    // Die partisie-algoritme herhaal die volgende stappe totdat dit voltooi is:
    //
    // 1. Trek 'n blok van die linkerkant af om elemente groter as of gelyk aan die spilpunt te identifiseer.
    // 2. Trek 'n blok van die regterkant af om elemente kleiner as die spilpunt te identifiseer.
    // 3. Ruil die geïdentifiseerde elemente tussen die linker-en regterkant uit.
    //
    // Ons hou die volgende veranderlikes vir 'n blok elemente:
    //
    // 1. `block` - Aantal elemente in die blok.
    // 2. `start` - Begin aanwyser in die `offsets`-skikking.
    // 3. `end` - Eindpunt in die `offsets`-skikking.
    // 4. `offsets, indekse van buite-orde elemente binne die blok.

    // Die huidige blok aan die linkerkant (van `l` tot `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Die huidige blok aan die regterkant (vanaf `r.sub(block_r)` to `r`).
    // VEILIGHEID: Die dokumentasie vir .add() noem spesifiek dat `vec.as_ptr().add(vec.len())` altyd veilig is '
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: As u VLA's kry, probeer eerder een skikking met die lengte `min(v.len(), 2 * BLOCK) te skep
    // as twee vaste skikkings van lengte `BLOCK`.VLA's kan meer kas-doeltreffend wees.

    // Wys die aantal elemente tussen wysers `l` (inclusive) en `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Ons is klaar met die skeiding van blok-vir-blok wanneer `l` en `r` baie naby kom.
        // Dan doen ons 'n bietjie lapwerk om die oorblywende elemente tussenin te verdeel.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Aantal oorblywende elemente (steeds nie in vergelyking met die spilpunt nie).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Pas blokgroottes aan sodat die linker-en regterblok nie oorvleuel nie, maar perfek in lyn is om die hele oorblywende gaping te bedek.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Spoor `block_l`-elemente van die linkerkant af.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // VEILIGHEID: Die onderstaande onveiligheidsoperasies behels die gebruik van die `offset`.
                //         Volgens die voorwaardes wat deur die funksie vereis word, voldoen ons daaraan omdat:
                //         1. `offsets_l` word toegeken aan stapels en word dus as afsonderlike toegewysde voorwerp beskou.
                //         2. Die funksie `is_less` gee 'n `bool` terug.
                //            Om 'n `bool` te gooi, sal `isize` nooit oorstroom nie.
                //         3. Ons het gewaarborg dat `block_l` `<= BLOCK` sal wees.
                //            Boonop is `end_l` aanvanklik ingestel op die beginwyser van `offsets_` wat op die stapel verklaar is.
                //            Dus weet ons dat selfs in die ergste geval (alle aanroepe van `is_less` vals oplewer) ons hoogstens 1 greep aan die einde sal slaag.
                //        'N Ander onveiligheidsoperasie hier is die verwysing van `elem`.
                //        `elem` was egter aanvanklik die beginwyser vir die sny wat altyd geldig is.
                unsafe {
                    // Taklose vergelyking.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Spoor `block_r`-elemente van die regterkant af.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // VEILIGHEID: Die onderstaande onveiligheidsoperasies behels die gebruik van die `offset`.
                //         Volgens die voorwaardes wat deur die funksie vereis word, voldoen ons daaraan omdat:
                //         1. `offsets_r` word toegeken aan stapels en word dus as afsonderlike toegewysde voorwerp beskou.
                //         2. Die funksie `is_less` gee 'n `bool` terug.
                //            Om 'n `bool` te gooi, sal `isize` nooit oorstroom nie.
                //         3. Ons het gewaarborg dat `block_r` `<= BLOCK` sal wees.
                //            Boonop is `end_r` aanvanklik ingestel op die beginwyser van `offsets_` wat op die stapel verklaar is.
                //            Ons weet dus dat selfs in die ergste geval (alle aanroepe van `is_less` waar is) ons hoogstens 1 greep aan die einde sal slaag.
                //        'N Ander onveiligheidsoperasie hier is die verwysing van `elem`.
                //        Aanvanklik was `elem` egter `1 *sizeof(T)` en ons het dit met `1* sizeof(T)` verminder voordat ons toegang daartoe verkry het.
                //        Daarbenewens is beweer dat `block_r` minder as `BLOCK` is, en `elem` sal dus hoogstens na die begin van die sny wys.
                unsafe {
                    // Taklose vergelyking.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Aantal elemente wat buite werking is om tussen die linker-en regterkant te wissel.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // In plaas daarvan om een paar terselfdertyd om te ruil, is dit doeltreffender om 'n sikliese permutasie uit te voer.
            // Dit is nie heeltemal gelykstaande aan ruil nie, maar lewer 'n soortgelyke resultaat met minder geheue-bewerkings.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Alle buite-orde-elemente in die linkerblok is verskuif.Skuif na die volgende blok.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Alle buite-orde-elemente in die regte blok is verskuif.Skuif na die vorige blok.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Al wat nou oorbly, is hoogstens een blok (links of regs) met elemente wat buite werking is wat verskuif moet word.
    // Sulke oorblywende elemente kan eenvoudig binne die blok na die einde geskuif word.
    //

    if start_l < end_l {
        // Die linkerblok bly.
        // Skuif die oorblywende buite-orde-elemente heel regs.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Die regte blok bly.
        // Skuif die oorblywende buite-orde-elemente heel links.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Niks anders om te doen nie, ons is klaar.
        width(v.as_mut_ptr(), l)
    }
}

/// Partisies `v` in elemente kleiner as `v[pivot]`, gevolg deur elemente groter as of gelyk aan `v[pivot]`.
///
///
/// Wys 'n tou van:
///
/// 1. Aantal elemente kleiner as `v[pivot]`.
/// 2. Waar as `v` reeds verdeel was.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Plaas die spilpunt aan die begin van die sny.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Lees die spilpunt in 'n veranderlike wat aan stapel toegeken word vir doeltreffendheid.
        // As 'n volgende vergelykingsbewerking panics word, word die spilpunt outomaties in die sny teruggeskryf.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Soek die eerste paar buite-orde elemente.
        let mut l = 0;
        let mut r = v.len();

        // VEILIGHEID: Die onderstaande onveiligheid behels die indeksering van 'n skikking.
        // Vir die eerste een: Ons doen reeds die perke hier met `l < r`.
        // Vir die tweede een: ons het aanvanklik `l == 0` en `r == v.len()` en ons het die `l < r` by elke indekseringsbewerking nagegaan.
        //                     Van hier af weet ons dat `r` ten minste `r == l` moet wees, wat vanaf die eerste een geldig is.
        unsafe {
            // Vind die eerste element groter as of gelyk aan die spilpunt.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Vind die laaste element kleiner as die spilpunt.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` gaan buite die omvang en skryf die spilpunt (wat 'n stapel-toegekende veranderlike is) terug in die sny waar dit oorspronklik was.
        // Hierdie stap is van kardinale belang om veiligheid te verseker!
        //
    };

    // Plaas die spil tussen die twee afskortings.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Partisies `v` in elemente gelyk aan `v[pivot]` gevolg deur elemente groter as `v[pivot]`.
///
/// Wys die aantal elemente wat gelyk is aan die spilpunt.
/// Daar word aanvaar dat `v` nie elemente kleiner as die spilpunt bevat nie.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Plaas die spilpunt aan die begin van die sny.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Lees die spilpunt in 'n veranderlike wat aan stapel toegeken word vir doeltreffendheid.
    // As 'n volgende vergelykingsbewerking panics word, word die spilpunt outomaties in die sny teruggeskryf.
    // VEILIGHEID: Die aanwyser hier is geldig omdat dit verkry word uit 'n verwysing na 'n sny.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Verdeel nou die sny.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // VEILIGHEID: Die onderstaande onveiligheid behels die indeksering van 'n skikking.
        // Vir die eerste een: Ons doen reeds die perke hier met `l < r`.
        // Vir die tweede een: ons het aanvanklik `l == 0` en `r == v.len()` en ons het die `l < r` by elke indekseringsbewerking nagegaan.
        //                     Van hier af weet ons dat `r` ten minste `r == l` moet wees, wat vanaf die eerste een geldig is.
        unsafe {
            // Vind die eerste element groter as die spilpunt.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Vind die laaste element gelyk aan die spilpunt.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Is ons klaar?
            if l >= r {
                break;
            }

            // Ruil die gevindte paar buite-orde-elemente om.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Ons het `l`-elemente gevind wat gelyk is aan die spilpunt.Voeg 1 by om die spilpunt self te verantwoord.
    l + 1

    // `_pivot_guard` gaan buite die omvang en skryf die spilpunt (wat 'n stapel-toegekende veranderlike is) terug in die sny waar dit oorspronklik was.
    // Hierdie stap is van kardinale belang om veiligheid te verseker!
}

/// Versprei sommige elemente in 'n poging om patrone te breek wat kan lei tot ongebalanseerde afskortings in die kwiksort.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Pseudorandom getalgenerator van die "Xorshift RNGs"-artikel deur George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Neem ewekansige getalle volgens hierdie getal.
        // Die getal pas in `usize` omdat `len` nie groter is as `isize::MAX` nie.
        let modulus = len.next_power_of_two();

        // Sommige spilkandidate sal in die nabye omgewing van hierdie indeks wees.Laat ons dit willekeurig maak.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Genereer 'n ewekansige getal modulo `len`.
            // Om duur bedrywighede te vermy, neem ons dit egter eers met modulo 'n krag van twee en daal dan met `len` totdat dit in die reeks `[0, len - 1]` pas.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` is gewaarborg dat dit minder as `2 * len` is.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Kies 'n spilpunt in `v` en gee die indeks en `true` as die sny waarskynlik reeds gesorteer is.
///
/// Elemente in `v` kan in die proses herbestel word.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Minimum lengte om die mediaan-van-mediaan-metode te kies.
    // Korter snye gebruik die eenvoudige mediaan-van-drie-metode.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Maksimum aantal ruilings wat met hierdie funksie uitgevoer kan word.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Drie indekse waarby ons 'n spilpunt gaan kies.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Tel die totale aantal ruiltransaksies wat ons op die punt staan om te doen terwyl ons indekse sorter.
    let mut swaps = 0;

    if len >= 8 {
        // Ruil indekse sodat `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Ruil indekse sodat `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Vind die mediaan van `v[a - 1], v[a], v[a + 1]` en stoor die indeks in `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Soek mediane in die buurte `a`, `b` en `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Soek die mediaan tussen `a`, `b` en `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Die maksimum aantal ruilings is uitgevoer.
        // Die kans is groot dat die sny afneem of meestal daal, dus omkeer sal waarskynlik help om dit vinniger te sorteer.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Sorteer `v` rekursief.
///
/// As die sny 'n voorganger in die oorspronklike skikking gehad het, word dit as `pred` gespesifiseer.
///
/// `limit` is die aantal toegelate ongebalanseerde partisies voordat u na `heapsort` oorskakel.
/// As nul, sal hierdie funksie onmiddellik oorskakel na heapsort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Snye van tot hierdie lengte word gesorteer volgens invoegsorteer.
    const MAX_INSERTION: usize = 20;

    // Dit is waar as die laaste skeiding redelik gebalanseerd was.
    let mut was_balanced = true;
    // Dit is waar as die laaste partisie nie elemente geskommel het nie (die sny was reeds verdeel).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Baie kort snye word gesorteer met behulp van invoegingsorteer.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // As daar te veel slegte spilpuntkeuses gemaak is, moet u eenvoudig terugval na die heapsort om die slegste geval van `O(n * log(n))` te waarborg.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // As die laaste skeiding nie in balans was nie, probeer om patrone in die sny te breek deur 'n paar elemente rond te skuif.
        // Hopelik kies ons hierdie keer 'n beter spilpunt.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Kies 'n spilpunt en probeer raai of die sny al gesorteer is.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // As die laaste partisie ordentlik gebalanseerd was en nie elemente geskommel het nie, en as die spilpunt voorspel, is die sny waarskynlik reeds gesorteer ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Probeer om verskillende elemente buite orde te identifiseer en na die regte posisies te skuif.
            // As die plak uiteindelik heeltemal gesorteer is, is ons klaar.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // As die gekose spilpunt gelyk is aan die voorganger, dan is dit die kleinste element in die sny.
        // Verdeel die sny in elemente gelyk aan en elemente groter as die spilpunt.
        // Hierdie saak word gewoonlik getref as die plak baie duplikaat-elemente bevat.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Sorteer elemente wat groter is as die spilpunt.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Verdeel die sny.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Verdeel die sny in `left`, `pivot` en `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Beweeg slegs in die korter kant om die totale aantal rekursiewe oproepe te verminder en minder stapelruimte te verbruik.
        // Gaan dan voort met die langer kant (dit is soortgelyk aan stertrekursie).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Sorteer `v` deur gebruik te maak van patroonverslaanende kwiksort, wat *O*(*n*\*log(* n*)) in die ergste geval is).
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Sortering het geen betekenisvolle gedrag op soorte nulgrootte nie.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Beperk die aantal ongebalanseerde partisies tot `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Vir snye tot hierdie lengte is dit waarskynlik vinniger om dit eenvoudig te sorteer.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Kies 'n spilpunt
        let (pivot, _) = choose_pivot(v, is_less);

        // As die gekose spilpunt gelyk is aan die voorganger, dan is dit die kleinste element in die sny.
        // Verdeel die sny in elemente gelyk aan en elemente groter as die spilpunt.
        // Hierdie saak word gewoonlik getref as die plak baie duplikaat-elemente bevat.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // As ons ons indeks geslaag het, is ons goed.
                if mid > index {
                    return;
                }

                // Andersins, gaan voort om sorteer elemente groter as die spilpunt.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Verdeel die sny in `left`, `pivot` en `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // As mid==index, dan is ons klaar, want partition() het gewaarborg dat alle elemente na mid groter of gelyk is aan middel.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Sortering het geen betekenisvolle gedrag op soorte nulgrootte nie.Doen niks.
    } else if index == v.len() - 1 {
        // Vind maksimum element en plaas dit in die laaste posisie van die skikking.
        // Ons kan `unwrap()` hier gebruik, want ons weet dat v nie mag leeg wees nie.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Vind min element en plaas dit in die eerste posisie van die skikking.
        // Ons kan `unwrap()` hier gebruik, want ons weet dat v nie mag leeg wees nie.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}