use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` maar nie-nul en covariant.
///
/// Dit is dikwels die regte ding om te gebruik as u datastrukture bou met rou aanwysers, maar is uiteindelik gevaarliker om te gebruik vanweë die addisionele eienskappe daarvan.As u nie seker is of u `NonNull<T>` moet gebruik nie, gebruik dan net `*mut T`!
///
/// In teenstelling met `*mut T`, moet die wyser altyd nie-nul wees, selfs al word die wyser nooit anders verwys nie.Dit is sodat enums hierdie verbode waarde as 'n diskriminant kan gebruik-`Option<NonNull<T>>` het dieselfde grootte as `* mut T`.
/// Die aanwyser kan egter steeds hang as dit nie verwys word nie.
///
/// In teenstelling met `*mut T`, is `NonNull<T>` gekies om meer as `T` te wees.Dit maak dit moontlik om `NonNull<T>` te gebruik wanneer u soorte variëteite bou, maar dit lei tot die risiko van ongerustheid indien dit gebruik word in 'n soort wat nie eintlik covariant moet wees nie.
/// (Die teenoorgestelde keuse is vir `*mut T` gemaak, alhoewel die ongesondheid tegnies slegs veroorsaak kon word deur onveilige funksies aan te roep.)
///
/// Kovariansie is korrek vir die meeste veilige abstraksies, soos `Box`, `Rc`, `Arc`, `Vec` en `LinkedList`.Dit is die geval omdat hulle 'n openbare API bied wat die normale gedeelde XOR-veranderlike reëls van Rust volg.
///
/// As u tipe nie veilig kan wees nie, moet u seker maak dat dit 'n addisionele veld bevat om onveranderlik te wees.Dikwels sal hierdie veld 'n [`PhantomData`]-tipe soos `PhantomData<Cell<T>>` of `PhantomData<&'a mut T>` wees.
///
/// Let op dat `NonNull<T>` 'n `From`-instansie vir `&T` het.Dit verander egter nie die feit dat mutasie deur 'n (wyser afgelei van 'n) gedeelde verwysing ongedefinieerde gedrag is nie, tensy die mutasie binne 'n [`UnsafeCell<T>`] plaasvind.Dieselfde geld vir die skep van 'n veranderlike verwysing vanuit 'n gedeelde verwysing.
///
/// Wanneer u hierdie `From`-instansie sonder 'n `UnsafeCell<T>` gebruik, is dit u verantwoordelikheid om te sorg dat `as_mut` nooit gebel word nie en dat `as_ptr` nooit vir mutasie gebruik word nie.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` wysers is nie `Send` nie, want die data waarna hulle verwys, kan alias wees.
// NB, hierdie impl is onnodig, maar behoort beter foutboodskappe te bied.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` wysers is nie `Sync` nie, want die data waarna hulle verwys, kan alias wees.
// NB, hierdie impl is onnodig, maar behoort beter foutboodskappe te bied.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Skep 'n nuwe `NonNull` wat hang, maar goed belyn is.
    ///
    /// Dit is handig om tipes wat lui toewys, te initialiseer, soos `Vec::new` ook doen.
    ///
    /// Let daarop dat die wyserwaarde moontlik 'n geldige wyser vir 'n `T` kan verteenwoordig, wat beteken dat dit nie as 'n "not yet initialized"-sentinelwaarde gebruik mag word nie.
    /// Tipes wat lui toewys, moet die initialisering op 'n ander manier volg.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // VEILIGHEID: mem::align_of() gee 'n nie-nul grootte terug wat dan gegiet word
        // na 'n * mut T.
        // Daarom is `ptr` nie nul nie en word die voorwaardes vir die oproep van new_unchecked() nagekom.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Wys 'n gedeelde verwysing na die waarde.In teenstelling met [`as_ref`], is dit nie nodig dat die waarde geïnisialiseer moet word nie.
    ///
    /// Sien [`as_uninit_mut`] vir die veranderlike eweknie.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// As u hierdie metode aanroep, moet u seker maak dat al die volgende waar is:
    ///
    /// * Die wyser moet behoorlik gerig wees.
    ///
    /// * Dit moet "dereferencable" wees in die sin wat in [the module documentation] gedefinieer word.
    ///
    /// * U moet die aliasingsreëls van Rust toepas, aangesien die teruggekeerde leeftyd `'a` willekeurig gekies word en nie noodwendig die werklike leeftyd van die data weerspieël nie.
    ///
    ///   In die besonder, vir die duur van hierdie leeftyd, moet die geheue waarop die aanwyser wys, nie gemuteer word nie (behalwe in `UnsafeCell`).
    ///
    /// Dit geld selfs al is die resultaat van hierdie metode ongebruik!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // VEILIGHEID: die beller moet waarborg dat `self` aan al die
        // vereistes vir 'n verwysing.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Wys 'n unieke verwysing na die waarde.In teenstelling met [`as_mut`], is dit nie nodig dat die waarde geïnisialiseer moet word nie.
    ///
    /// Vir die gedeelde eweknie, sien [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// As u hierdie metode aanroep, moet u seker maak dat al die volgende waar is:
    ///
    /// * Die wyser moet behoorlik gerig wees.
    ///
    /// * Dit moet "dereferencable" wees in die sin wat in [the module documentation] gedefinieer word.
    ///
    /// * U moet die aliasingsreëls van Rust toepas, aangesien die teruggekeerde leeftyd `'a` willekeurig gekies word en nie noodwendig die werklike leeftyd van die data weerspieël nie.
    ///
    ///   In die besonder, gedurende die leeftyd van hierdie leeftyd, mag die geheue waarop die aanwyser wys, nie deur enige ander aanwyser (gelees of geskryf) verkry word nie.
    ///
    /// Dit geld selfs al is die resultaat van hierdie metode ongebruik!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // VEILIGHEID: die beller moet waarborg dat `self` aan al die
        // vereistes vir 'n verwysing.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Skep 'n nuwe `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` moet nie-nul wees.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // VEILIGHEID: die beller moet waarborg dat `ptr` nie-nul is.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Skep 'n nuwe `NonNull` as `ptr` nie-nul is.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // VEILIGHEID: die wyser is reeds gekontroleer en is nie nul nie
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Voer dieselfde funksionaliteit uit as [`std::ptr::from_raw_parts`], behalwe dat 'n `NonNull`-wyser teruggestuur word, in teenstelling met 'n rou `*const`-wyser.
    ///
    ///
    /// Raadpleeg die dokumentasie van [`std::ptr::from_raw_parts`] vir meer besonderhede.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // VEILIGHEID: Die resultaat van `ptr::from::raw_parts_mut` is nie-nul omdat `data_address` is.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Ontbind 'n (moontlik wye) wyser in adres-en metadatakomponente.
    ///
    /// Die wyser kan later met [`NonNull::from_raw_parts`] gerekonstrueer word.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Verkry die onderliggende `*mut`-wyser.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Wys 'n gedeelde verwysing na die waarde.As die waarde moontlik nie geïnisialiseer is nie, moet [`as_uninit_ref`] eerder gebruik word.
    ///
    /// Sien [`as_mut`] vir die veranderlike eweknie.
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// As u hierdie metode aanroep, moet u seker maak dat al die volgende waar is:
    ///
    /// * Die wyser moet behoorlik gerig wees.
    ///
    /// * Dit moet "dereferencable" wees in die sin wat in [the module documentation] gedefinieer word.
    ///
    /// * Die aanwyser moet na 'n geïnisialiseerde voorbeeld van `T` wys.
    ///
    /// * U moet die aliasingsreëls van Rust toepas, aangesien die teruggekeerde leeftyd `'a` willekeurig gekies word en nie noodwendig die werklike leeftyd van die data weerspieël nie.
    ///
    ///   In die besonder, vir die duur van hierdie leeftyd, moet die geheue waarop die aanwyser wys, nie gemuteer word nie (behalwe in `UnsafeCell`).
    ///
    /// Dit geld selfs al is die resultaat van hierdie metode ongebruik!
    /// (Die gedeelte oor die inisiëring is nog nie volledig beslis nie, maar tot dusver is die enigste veilige benadering om te verseker dat dit wel geïnisialiseer word.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // VEILIGHEID: die beller moet waarborg dat `self` aan al die
        // vereistes vir 'n verwysing.
        unsafe { &*self.as_ptr() }
    }

    /// Wys 'n unieke verwysing na die waarde.As die waarde moontlik nie geïnisialiseer is nie, moet [`as_uninit_mut`] eerder gebruik word.
    ///
    /// Vir die gedeelde eweknie, sien [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// As u hierdie metode aanroep, moet u seker maak dat al die volgende waar is:
    ///
    /// * Die wyser moet behoorlik gerig wees.
    ///
    /// * Dit moet "dereferencable" wees in die sin wat in [the module documentation] gedefinieer word.
    ///
    /// * Die aanwyser moet na 'n geïnisialiseerde voorbeeld van `T` wys.
    ///
    /// * U moet die aliasingsreëls van Rust toepas, aangesien die teruggekeerde leeftyd `'a` willekeurig gekies word en nie noodwendig die werklike leeftyd van die data weerspieël nie.
    ///
    ///   In die besonder, gedurende die leeftyd van hierdie leeftyd, mag die geheue waarop die aanwyser wys, nie deur enige ander aanwyser (gelees of geskryf) verkry word nie.
    ///
    /// Dit geld selfs al is die resultaat van hierdie metode ongebruik!
    /// (Die gedeelte oor die inisiëring is nog nie volledig beslis nie, maar tot dusver is die enigste veilige benadering om te verseker dat dit wel geïnisialiseer word.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // VEILIGHEID: die beller moet waarborg dat `self` aan al die
        // vereistes vir 'n veranderlike verwysing.
        unsafe { &mut *self.as_ptr() }
    }

    /// Werp na 'n wyser van 'n ander tipe.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // VEILIGHEID: `self` is 'n `NonNull`-aanwyser wat noodwendig nie-nul is
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Skep 'n nie-nul rou sny van 'n dun wyser en 'n lengte.
    ///
    /// Die `len`-argument is die aantal **elemente**, nie die aantal grepe nie.
    ///
    /// Hierdie funksie is veilig, maar die verwysing van die retourwaarde is onveilig.
    /// Raadpleeg die dokumentasie van [`slice::from_raw_parts`] vir veiligheidsvereistes vir snye.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // maak 'n snywyser wanneer u met 'n wyser na die eerste element begin
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Let op dat hierdie voorbeeld kunsmatig die gebruik van hierdie metode demonstreer, maar 'laat sny= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // VEILIGHEID: `data` is 'n `NonNull`-aanwyser wat noodwendig nie-nul is
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Wys die lengte van 'n nie-nul rou sny.
    ///
    /// Die teruggekeerde waarde is die aantal **elemente**, nie die aantal grepe nie.
    ///
    /// Hierdie funksie is veilig, selfs as die nie-nul rou sny nie na 'n sny verwys kan word nie omdat die wyser nie 'n geldige adres het nie.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Wys 'n nie-nul aanwyser na die buffer van die sny.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // VEILIGHEID: Ons weet dat `self` nie-nul is.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Wys 'n rou wyser na die buffer van die sny.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Wys 'n gedeelde verwysing na 'n deel van moontlik nie-geïnisialiseerde waardes.In teenstelling met [`as_ref`], is dit nie nodig dat die waarde geïnisialiseer moet word nie.
    ///
    /// Sien [`as_uninit_slice_mut`] vir die veranderlike eweknie.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// As u hierdie metode aanroep, moet u seker maak dat al die volgende waar is:
    ///
    /// * Die aanwyser moet [valid] wees vir lees vir `ptr.len() * mem::size_of::<T>()` baie grepe, en dit moet behoorlik in lyn wees.Dit beteken veral:
    ///
    ///     * Die hele geheue-reeks van hierdie sny moet binne 'n enkele toegekende voorwerp vervat wees!
    ///       Snye kan nooit oor veelvuldige toegekende voorwerpe strek nie.
    ///
    ///     * Die wyser moet gelyk wees vir snye sonder lengte.
    ///     Een rede hiervoor is dat die optimering van enum-uitleg daarop kan staatmaak dat verwysings (insluitend snye van enige lengte) in lyn is en nie-nul is om dit van ander data te onderskei.
    ///
    ///     U kan 'n aanwyser verkry wat as `data` gebruik kan word vir snylengtes met [`NonNull::dangling()`].
    ///
    /// * Die totale grootte `ptr.len() * mem::size_of::<T>()` van die sny mag nie groter as `isize::MAX` wees nie.
    ///   Sien die veiligheidsdokumentasie van [`pointer::offset`].
    ///
    /// * U moet die aliasingsreëls van Rust toepas, aangesien die teruggekeerde leeftyd `'a` willekeurig gekies word en nie noodwendig die werklike leeftyd van die data weerspieël nie.
    ///   In die besonder, vir die duur van hierdie leeftyd, moet die geheue waarop die aanwyser wys, nie gemuteer word nie (behalwe in `UnsafeCell`).
    ///
    /// Dit geld selfs al is die resultaat van hierdie metode ongebruik!
    ///
    /// Sien ook [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // VEILIGHEID: die beller moet die veiligheidskontrak vir `as_uninit_slice` handhaaf.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Wys 'n unieke verwysing na 'n stukkie waardes wat moontlik nie geïnisialiseer is nie.In teenstelling met [`as_mut`], is dit nie nodig dat die waarde geïnisialiseer moet word nie.
    ///
    /// Vir die gedeelde eweknie, sien [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// As u hierdie metode aanroep, moet u seker maak dat al die volgende waar is:
    ///
    /// * Die aanwyser moet [valid] wees vir lees en skryf vir `ptr.len() * mem::size_of::<T>()` baie grepe, en dit moet behoorlik in lyn wees.Dit beteken veral:
    ///
    ///     * Die hele geheue-reeks van hierdie sny moet binne 'n enkele toegekende voorwerp vervat wees!
    ///       Snye kan nooit oor veelvuldige toegekende voorwerpe strek nie.
    ///
    ///     * Die wyser moet gelyk wees vir snye sonder lengte.
    ///     Een rede hiervoor is dat die optimering van enum-uitleg daarop kan staatmaak dat verwysings (insluitend snye van enige lengte) in lyn is en nie-nul is om dit van ander data te onderskei.
    ///
    ///     U kan 'n aanwyser verkry wat as `data` gebruik kan word vir snylengtes met [`NonNull::dangling()`].
    ///
    /// * Die totale grootte `ptr.len() * mem::size_of::<T>()` van die sny mag nie groter as `isize::MAX` wees nie.
    ///   Sien die veiligheidsdokumentasie van [`pointer::offset`].
    ///
    /// * U moet die aliasingsreëls van Rust toepas, aangesien die teruggekeerde leeftyd `'a` willekeurig gekies word en nie noodwendig die werklike leeftyd van die data weerspieël nie.
    ///   In die besonder, gedurende die leeftyd van hierdie leeftyd, mag die geheue waarop die aanwyser wys, nie deur enige ander aanwyser (gelees of geskryf) verkry word nie.
    ///
    /// Dit geld selfs al is die resultaat van hierdie metode ongebruik!
    ///
    /// Sien ook [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Dit is veilig, aangesien `memory` geldig is vir lees en skryf vir `memory.len()` baie grepe.
    /// // Let daarop dat hier nie `memory.as_mut()` gebel kan word nie, aangesien die inhoud moontlik nie geïnisialiseer kan word nie.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // VEILIGHEID: die beller moet die veiligheidskontrak vir `as_uninit_slice_mut` handhaaf.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Wys 'n rou wyser na 'n element of onderdeel, sonder om grense te kontroleer.
    ///
    /// Die oproep van hierdie metode met 'n indeks buite die perke of as `self` nie herverwysbaar is nie, is *[ongedefinieerde gedrag]*, selfs al word die aanwyser wat hieruit gevolg word nie gebruik nie.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // VEILIGHEID: die oproeper sorg dat `self` herverwysbaar is en `index` binne-perke is.
        // As gevolg hiervan kan die resulterende wyser nie NUL wees nie.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // VEILIGHEID: 'n Unieke wyser kan nie nul wees nie, dus die voorwaardes vir
        // new_unchecked() gerespekteer word.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // VEILIGHEID: 'n Veranderlike verwysing kan nie nul wees nie.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // VEILIGHEID: 'n Verwysing kan nie ongeldig wees nie, dus die voorwaardes vir
        // new_unchecked() gerespekteer word.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}