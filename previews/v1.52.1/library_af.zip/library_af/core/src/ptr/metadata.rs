#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Verskaf die wyser-metadatatipe van enige tipe wat aangedui word.
///
/// # Metadata vir wyser
///
/// Rou wysertipes en verwysingstipes in Rust kan beskou word uit twee dele:
/// 'n datawyser wat die geheue-adres van die waarde bevat, en 'n paar metadata.
///
/// Vir soorte staties (wat die `Sized` traits implementeer) sowel as vir `extern`-soorte, word daar gesê dat aanwysers 'dun' is: metadata is nulgrootte en die soort is `()`.
///
///
/// Aanwysers na [dynamically-sized types][dst] is na bewering "breed" of "vet", hulle het nie-grootte metadata:
///
/// * Vir strukture waarvan die laaste veld 'n DST is, is metadata die metadata vir die laaste veld
/// * Vir die `str`-tipe is metadata die lengte in grepe as `usize`
/// * Vir snytipes soos `[T]` is metadata die lengte in items as `usize`
/// * Vir trait-voorwerpe soos `dyn SomeTrait` is metadata [`DynMetadata<Self>`][DynMetadata] (bv. `DynMetadata<dyn SomeTrait>`)
///
/// In die future kan die Rust-taal nuwe soorte soorte kry met verskillende wysermetadata.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # Die `Pointee` trait
///
/// Die punt van hierdie trait is sy `Metadata`-geassosieerde tipe, wat `()` of `usize` of `DynMetadata<_>` is soos hierbo beskryf.
/// Dit word outomaties geïmplementeer vir elke tipe.
/// Daar kan aanvaar word dat dit in 'n generiese konteks geïmplementeer word, selfs sonder 'n ooreenstemmende beperking.
///
/// # Usage
///
/// Rou aanwysers kan met hul [`to_raw_parts`]-metode in die data-adres en metadatakomponente ontbind word.
///
/// Alternatiewelik kan metadata alleen met die [`metadata`]-funksie onttrek word.
/// 'N Verwysing kan na [`metadata`] oorgedra word en implisiet gedwing word.
///
/// 'N (possibly-wide)-wyser kan vanaf sy adres en metadata saamgestel word met [`from_raw_parts`] of [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Die tipe metadata in verwysings en verwysings na `Self`.
    #[lang = "metadata_type"]
    // NOTE: Hou trait bounds in `static_assert_expected_bounds_for_metadata`
    //
    // in `library/core/src/ptr/metadata.rs` in ooreenstemming met dié hier:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Aanwysings na tipes wat hierdie trait-alias implementeer, is 'dun'.
///
/// Dit sluit staties-grootte-tipes en `extern`-tipes in.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: stabiliseer dit nie voordat trait-aliasse stabiel is in die taal nie?
pub trait Thin = Pointee<Metadata = ()>;

/// Onttrek die metadata-komponent van 'n wyser.
///
/// Waardes van die tipe `*mut T`, `&T` of `&mut T` kan direk na hierdie funksie oorgedra word, aangesien dit implisiet na `* const T` gedwing word.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // VEILIGHEID: Toegang tot die waarde van die `PtrRepr`-unie is veilig omdat * konst T
    // en PtrComponents<T>dieselfde geheue-uitlegte hê.
    // Slegs std kan hierdie waarborg lewer.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Vorm 'n (possibly-wide) rou aanwyser vanaf 'n data-adres en metadata.
///
/// Hierdie funksie is veilig, maar die teruggekeerde wyser is nie noodwendig veilig om te verskil nie.
/// Raadpleeg die dokumentasie van [`slice::from_raw_parts`] vir veiligheidsvereistes vir snye.
/// Vir trait-voorwerpe moet die metadata van 'n aanwyser na dieselfde onderliggende weergawe kom.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // VEILIGHEID: Toegang tot die waarde van die `PtrRepr`-unie is veilig omdat * konst T
    // en PtrComponents<T>dieselfde geheue-uitlegte hê.
    // Slegs std kan hierdie waarborg lewer.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Voer dieselfde funksionaliteit uit as [`from_raw_parts`], behalwe dat 'n rou `*mut`-wyser terugbesorg word, in teenstelling met 'n rou `* const`-wyser.
///
///
/// Raadpleeg die dokumentasie van [`from_raw_parts`] vir meer besonderhede.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // VEILIGHEID: Toegang tot die waarde van die `PtrRepr`-unie is veilig omdat * konst T
    // en PtrComponents<T>dieselfde geheue-uitlegte hê.
    // Slegs std kan hierdie waarborg lewer.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Handleiding benodig om `T: Copy` gebind te vermy.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Handleiding benodig om `T: Clone` gebind te vermy.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Die metadata vir 'n `Dyn = dyn SomeTrait` trait-voorwerptipe.
///
/// Dit is 'n aanwyser na 'n tabel (virtuele oproeptabel) wat al die nodige inligting voorstel om die betontipe wat in 'n trait-voorwerp gestoor word, te manipuleer.
/// Die tabel bevat veral:
///
/// * tipe grootte
/// * tipe belyning
/// * 'n aanwyser na die `drop_in_place`-impl van die tipe (kan 'n no-op vir gewone-ou-data wees)
/// * wys na al die metodes vir die implementering van die trait
///
/// Let daarop dat die eerste drie spesiaal is omdat dit nodig is om enige trait-voorwerp toe te ken, te laat val en te herplaas.
///
/// Dit is moontlik om hierdie struktuur te benoem met 'n tipe parameter wat nie 'n `dyn` trait-voorwerp is nie (byvoorbeeld `DynMetadata<u64>`), maar om nie 'n betekenisvolle waarde van die struktuur te verkry nie.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Die algemene voorvoegsel van alle tabelle.Dit word gevolg deur funksiewysers vir trait-metodes.
///
/// Privaat implementeringsdetail van `DynMetadata::size_of` ens.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Wys die grootte van die tipe wat met hierdie vtabel geassosieer word.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Wys die belyning van die tipe wat met hierdie vtabel geassosieer word.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Wys die grootte en belyning saam as 'n `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // VEILIGHEID: die samesteller het hierdie vtabel uitgestuur vir 'n konkrete Rust-tipe wat
        // dit is bekend dat dit 'n geldige uitleg het.Dieselfde rasionaal as in `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Handleiding is nodig om `Dyn: $Trait`-perke te vermy.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}