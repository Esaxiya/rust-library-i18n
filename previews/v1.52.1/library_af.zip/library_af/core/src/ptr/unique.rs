use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// 'N Omhulsel rondom 'n rou nie-nul `*mut T` wat aandui dat die eienaar van hierdie omslag die referent besit.
/// Nuttig vir die bou van abstraksies soos `Box<T>`, `Vec<T>`, `String` en `HashMap<K, V>`.
///
/// Anders as `*mut T`, gedra `Unique<T>` "as if", dit was 'n voorbeeld van `T`.
/// Dit implementeer `Send`/`Sync` as `T` `Send`/`Sync` is.
/// Dit impliseer ook die soort sterk aliasing waarborge wat 'n geval van `T` kan verwag:
/// die verwysing van die wyser moet nie gewysig word sonder 'n unieke pad na die besit daarvan nie.
///
/// As u nie seker is of dit korrek is om `Unique` vir u doeleindes te gebruik nie, oorweeg dit om `NonNull`, wat swakker semantiek het, te gebruik.
///
///
/// In teenstelling met `*mut T`, moet die wyser altyd nie-nul wees, selfs as die wyser nooit herverwys word nie.
/// Dit is so dat enums hierdie verbode waarde as 'n diskriminant kan gebruik-`Option<Unique<T>>` het dieselfde grootte as `Unique<T>`.
/// Die aanwyser kan egter steeds hang as dit nie verwys word nie.
///
/// Anders as `*mut T`, is `Unique<T>` meer as `T`.
/// Dit moet altyd korrek wees vir enige tipe wat voldoen aan Unique se aliaseringsvereistes.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: hierdie merker het geen gevolge vir afwyking nie, maar is nodig
    // vir dropck om te verstaan dat ons logies genoeg 'n `T` besit.
    //
    // Vir meer besonderhede, sien:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` wysers is `Send` as `T` `Send` is, omdat die gegewens waarna verwys word, nie geskat is nie.
/// Let daarop dat hierdie aliasing-invariant nie deur die tipe stelsel afgedwing word nie;die abstraksie met behulp van die `Unique` moet dit afdwing.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` wysers is `Sync` as `T` `Sync` is, omdat die gegewens waarna verwys word, nie geskat is nie.
/// Let daarop dat hierdie aliasing-invariant nie deur die tipe stelsel afgedwing word nie;die abstraksie met behulp van die `Unique` moet dit afdwing.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Skep 'n nuwe `Unique` wat hang, maar goed belyn is.
    ///
    /// Dit is handig om tipes wat lui toewys, te initialiseer, soos `Vec::new` ook doen.
    ///
    /// Let daarop dat die wyserwaarde moontlik 'n geldige wyser vir 'n `T` kan verteenwoordig, wat beteken dat dit nie as 'n "not yet initialized"-sentinelwaarde gebruik mag word nie.
    /// Tipes wat lui toewys, moet die initialisering op 'n ander manier volg.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // VEILIGHEID: mem::align_of() gee 'n geldige, nie-nul aanwyser terug.Die
        // voorwaardes om new_unchecked() te skakel, word dus gerespekteer.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Skep 'n nuwe `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` moet nie-nul wees.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // VEILIGHEID: die beller moet waarborg dat `ptr` nie-nul is.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Skep 'n nuwe `Unique` as `ptr` nie-nul is.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // VEILIGHEID: die wyser is reeds gekontroleer en is nie nul nie.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Verkry die onderliggende `*mut`-wyser.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Verwys na die inhoud.
    ///
    /// Die resulterende leeftyd is vanselfsprekend, dus dit gedra "as if", dit was eintlik 'n geval van T wat geleen word.
    /// Gebruik 'n langer (unbound)-leeftyd, gebruik `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // VEILIGHEID: die beller moet waarborg dat `self` aan al die
        // vereistes vir 'n verwysing.
        unsafe { &*self.as_ptr() }
    }

    /// Verander die inhoud onderling.
    ///
    /// Die resulterende leeftyd is vanselfsprekend, dus dit gedra "as if", dit was eintlik 'n geval van T wat geleen word.
    /// Gebruik 'n langer (unbound)-leeftyd, gebruik `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // VEILIGHEID: die beller moet waarborg dat `self` aan al die
        // vereistes vir 'n veranderlike verwysing.
        unsafe { &mut *self.as_ptr() }
    }

    /// Werp na 'n wyser van 'n ander tipe.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // VEILIGHEID: Unique::new_unchecked() skep 'n nuwe unieke behoefte
        // die gegewe wyser om nie nul te wees nie.
        // Aangesien ons self as 'n aanwyser aangee, kan dit nie nul wees nie.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // VEILIGHEID: 'n Veranderlike verwysing kan nie nul wees nie
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}