use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Wys `true` as die wyser nul is.
    ///
    /// Let daarop dat tipes wat nie groot is nie, baie moontlike nulaanwysers het, aangesien slegs die rou data-aanwyser in ag geneem word, nie hul lengte, vtabel, ens.
    /// Daarom kan twee wenke wat nul is, steeds nie gelyk wees aan mekaar nie.
    ///
    /// ## Gedrag tydens konst. Evaluering
    ///
    /// Wanneer hierdie funksie tydens konst evaluering gebruik word, kan dit `false` teruggee vir aanwysers wat tydens runtime nul blyk te wees.
    /// Spesifiek, wanneer 'n wyser na een of ander geheue so buite die perke verreken word dat die resulterende wyser nul is, sal die funksie steeds `false` terugstuur.
    ///
    /// Daar is geen manier vir CTFE om die absolute posisie van daardie geheue te ken nie, dus kan ons nie weet of die wyser nul is of nie.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Vergelyk dit via 'n rolverdeling met 'n dun wyser, dus vetwysers oorweeg slegs hul "data"-onderdeel vir nietigheid.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Werp na 'n wyser van 'n ander tipe.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Ontbind 'n (moontlik wye) wyser in adres-en metadatakomponente.
    ///
    /// Die wyser kan later met [`from_raw_parts_mut`] gerekonstrueer word.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Wys `None` as die wyser nul is, of gee 'n gedeelde verwysing terug na die waarde wat in `Some` toegedraai is.As die waarde dalk nie geïnisialiseer is nie, moet [`as_uninit_ref`] eerder gebruik word.
    ///
    /// Sien [`as_mut`] vir die veranderlike eweknie.
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// As u hierdie metode aanroep, moet u seker maak dat *die aanwyser NUL* is of dat * die volgende waar is:
    ///
    /// * Die wyser moet behoorlik gerig wees.
    ///
    /// * Dit moet "dereferencable" wees in die sin wat in [the module documentation] gedefinieer word.
    ///
    /// * Die aanwyser moet na 'n geïnisialiseerde voorbeeld van `T` wys.
    ///
    /// * U moet die aliasingsreëls van Rust toepas, aangesien die teruggekeerde leeftyd `'a` willekeurig gekies word en nie noodwendig die werklike leeftyd van die data weerspieël nie.
    ///   In die besonder, vir die duur van hierdie leeftyd, moet die geheue waarop die aanwyser wys, nie gemuteer word nie (behalwe in `UnsafeCell`).
    ///
    /// Dit geld selfs al is die resultaat van hierdie metode ongebruik!
    /// (Die gedeelte oor die inisiëring is nog nie volledig beslis nie, maar tot dusver is die enigste veilige benadering om te verseker dat dit wel geïnisialiseer word.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Nul-ongekontroleerde weergawe
    ///
    /// As u seker is dat die aanwyser nooit nul kan wees nie en op soek is na 'n soort `as_ref_unchecked` wat die `&T` in plaas van `Option<&T>` oplewer, moet u weet dat u die wyser direk kan verwys.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // VEILIGHEID: die beller moet waarborg dat `self` geldig is vir a
        // verwysing as dit nie nul is nie.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Wys `None` as die wyser nul is, of gee 'n gedeelde verwysing terug na die waarde wat in `Some` toegedraai is.
    /// In teenstelling met [`as_ref`], is dit nie nodig dat die waarde geïnisialiseer moet word nie.
    ///
    /// Sien [`as_uninit_mut`] vir die veranderlike eweknie.
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// As u hierdie metode aanroep, moet u seker maak dat *die aanwyser NUL* is of dat * die volgende waar is:
    ///
    /// * Die wyser moet behoorlik gerig wees.
    ///
    /// * Dit moet "dereferencable" wees in die sin wat in [the module documentation] gedefinieer word.
    ///
    /// * U moet die aliasingsreëls van Rust toepas, aangesien die teruggekeerde leeftyd `'a` willekeurig gekies word en nie noodwendig die werklike leeftyd van die data weerspieël nie.
    ///
    ///   In die besonder, vir die duur van hierdie leeftyd, moet die geheue waarop die aanwyser wys, nie gemuteer word nie (behalwe in `UnsafeCell`).
    ///
    /// Dit geld selfs al is die resultaat van hierdie metode ongebruik!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // VEILIGHEID: die beller moet waarborg dat `self` aan al die
        // vereistes vir 'n verwysing.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Bereken die verrekening vanaf 'n wyser.
    ///
    /// `count` is in eenhede van T;'n `count` van 3 stel byvoorbeeld 'n wyserversetting van `3 * size_of::<T>()` bytes voor.
    ///
    /// # Safety
    ///
    /// As een van die volgende voorwaardes oortree word, is die resultaat ongedefinieerde gedrag:
    ///
    /// * Beide die begin-en resulterende wyser moet binne perke of een byte aan die einde van dieselfde toegekende voorwerp wees.
    /// Let daarop dat in Rust elke (stack-allocated)-veranderlike as 'n afsonderlike toegekende voorwerp beskou word.
    ///
    /// * Die berekende verrekening,**in bytes**, kan nie 'n `isize` oorloop nie.
    ///
    /// * Die verrekening binne perke kan nie op "wrapping around" die adresruimte staatmaak nie.Dit wil sê, die oneindige presisie-som,**in grepe**, moet in 'n gebruiksgrootte pas.
    ///
    /// Die samesteller en standaardbiblioteek probeer gewoonlik verseker dat toewysings nooit 'n grootte bereik waar dit 'n verrekening is nie.
    /// `Vec` en `Box` verseker byvoorbeeld dat hulle nooit meer as `isize::MAX` bytes toewys nie, dus `vec.as_ptr().add(vec.len())` is altyd veilig.
    ///
    /// Die meeste platforms kan fundamenteel nie eers so 'n toekenning opstel nie.
    /// Byvoorbeeld, geen bekende 64-bis-platform kan ooit 'n versoek van 2 <sup>63</sup> byte indien nie, omdat die bladsytabel beperk is of die adresruimte verdeel is.
    /// Sommige 32-en 16-bis-platforms kan egter suksesvol 'n versoek vir meer as `isize::MAX` bytes met dinge soos uitbreiding van fisiese adres, dien.
    ///
    /// As sodanig kan geheue wat direk van toewysers of geheuekaarte lêers verkry word * te groot wees om met hierdie funksie te hanteer.
    ///
    /// Oorweeg dit eerder om [`wrapping_offset`] te gebruik as dit moeilik is om hierdie beperkings te bevredig.
    /// Die enigste voordeel van hierdie metode is dat dit meer aggressiewe samestellingsoptimalisasies moontlik maak.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // VEILIGHEID: die beller moet die veiligheidskontrak vir `offset` handhaaf.
        // Die verkreë wyser is geldig vir skryfwerk, aangesien die oproeper moet waarborg dat dit op dieselfde toegewysde voorwerp as `self` wys.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Bereken die verrekening vanaf 'n wyser met behulp van wikkelrekene.
    /// `count` is in eenhede van T;'n `count` van 3 stel byvoorbeeld 'n wyserversetting van `3 * size_of::<T>()` bytes voor.
    ///
    /// # Safety
    ///
    /// Hierdie bewerking self is altyd veilig, maar die gebruik van die daaropvolgende wyser is nie.
    ///
    /// Die resulterende wyser bly vas aan dieselfde toegewysde voorwerp waarop `self` wys.
    /// Dit kan *nie* gebruik word om toegang te verkry tot 'n ander toegewysde voorwerp nie.Let daarop dat in Rust elke (stack-allocated)-veranderlike as 'n afsonderlike toegekende voorwerp beskou word.
    ///
    /// Met ander woorde, `let z = x.wrapping_offset((y as isize) - (x as isize))` maak *nie*`z` dieselfde as `y` nie, selfs al neem ons aan dat `T` die grootte `1` het en dat daar geen oorloop is nie: `z` is steeds aan die voorwerp waaraan `x` geheg is, en die verwysing daarvan is ongedefinieerde gedrag, tensy `x` en `y` wys in dieselfde toegekende voorwerp.
    ///
    /// In vergelyking met [`offset`] vertraag hierdie metode basies die vereiste om binne dieselfde toegewysde voorwerp te bly: [`offset`] is onmiddellike ongedefinieerde gedrag wanneer u objekgrense oorskry;`wrapping_offset` produseer 'n wyser, maar lei steeds tot ongedefinieerde gedrag as 'n aanwyser herverwys word as dit buite die perke is van die voorwerp waaraan dit geheg is.
    /// [`offset`] kan beter geoptimaliseer word en is dus verkieslik in prestasie-sensitiewe kode.
    ///
    /// Die vertraagde tjek neem slegs rekening met die waarde van die wyser waarna verwys is, nie die tussenwaardes wat tydens die berekening van die finale resultaat gebruik is nie.
    /// `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` is byvoorbeeld altyd dieselfde as `x`.Met ander woorde, dit is toegelaat om die toegekende voorwerp te verlaat en dit later weer in te voer.
    ///
    /// As u voorwerpgrense moet oorsteek, gooi die wyser na 'n heelgetal en doen die rekenkunde daar.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// // Iterasie met behulp van 'n rou wyser in inkremente van twee elemente
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // VEILIGHEID: die `arith_offset`-intrinsiek het geen voorvereistes om te kan noem nie.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Wys `None` as die wyser nul is, of anders gee u 'n unieke verwysing na die waarde wat in `Some` toegedraai is.As die waarde dalk nie geïnisialiseer is nie, moet [`as_uninit_mut`] eerder gebruik word.
    ///
    /// Vir die gedeelde eweknie, sien [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// As u hierdie metode aanroep, moet u seker maak dat *die aanwyser NUL* is of dat * die volgende waar is:
    ///
    /// * Die wyser moet behoorlik gerig wees.
    ///
    /// * Dit moet "dereferencable" wees in die sin wat in [the module documentation] gedefinieer word.
    ///
    /// * Die aanwyser moet na 'n geïnisialiseerde voorbeeld van `T` wys.
    ///
    /// * U moet die aliasingsreëls van Rust toepas, aangesien die teruggekeerde leeftyd `'a` willekeurig gekies word en nie noodwendig die werklike leeftyd van die data weerspieël nie.
    ///   In die besonder, gedurende die leeftyd van hierdie leeftyd, mag die geheue waarop die aanwyser wys, nie deur enige ander aanwyser (gelees of geskryf) verkry word nie.
    ///
    /// Dit geld selfs al is die resultaat van hierdie metode ongebruik!
    /// (Die gedeelte oor die inisiëring is nog nie volledig beslis nie, maar tot dusver is die enigste veilige benadering om te verseker dat dit wel geïnisialiseer word.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Dit sal druk: "[4, 2, 3]".
    /// ```
    ///
    /// # Nul-ongekontroleerde weergawe
    ///
    /// As u seker is dat die aanwyser nooit nul kan wees nie en op soek is na 'n soort `as_mut_unchecked` wat die `&mut T` in plaas van `Option<&mut T>` oplewer, moet u weet dat u die wyser direk kan verwys.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Dit sal druk: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // VEILIGHEID: die beller moet waarborg dat `self` geldig is vir
        // 'n veranderlike verwysing as dit nie nul is nie.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Wys `None` as die wyser nul is, of gee 'n unieke verwysing na die waarde wat in `Some` toegedraai is.
    /// In teenstelling met [`as_mut`], is dit nie nodig dat die waarde geïnisialiseer moet word nie.
    ///
    /// Vir die gedeelde eweknie, sien [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// As u hierdie metode aanroep, moet u seker maak dat *die aanwyser NUL* is of dat * die volgende waar is:
    ///
    /// * Die wyser moet behoorlik gerig wees.
    ///
    /// * Dit moet "dereferencable" wees in die sin wat in [the module documentation] gedefinieer word.
    ///
    /// * U moet die aliasingsreëls van Rust toepas, aangesien die teruggekeerde leeftyd `'a` willekeurig gekies word en nie noodwendig die werklike leeftyd van die data weerspieël nie.
    ///
    ///   In die besonder, gedurende die leeftyd van hierdie leeftyd, mag die geheue waarop die aanwyser wys, nie deur enige ander aanwyser (gelees of geskryf) verkry word nie.
    ///
    /// Dit geld selfs al is die resultaat van hierdie metode ongebruik!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // VEILIGHEID: die beller moet waarborg dat `self` aan al die
        // vereistes vir 'n verwysing.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Wys of twee wenke gewaarborg is om gelyk te wees.
    ///
    /// Gedurende runtime gedra hierdie funksie soos `self == other`.
    /// In sommige kontekste (bv. Kompileringstyd-evaluering) is dit egter nie altyd moontlik om die gelykheid van twee wysers te bepaal nie, daarom kan hierdie funksie `false` verkeerdelik teruggee vir aanwysers wat later gelyk blyk te wees.
    ///
    /// Maar as dit `true` terugbesorg, is die aanwysers gewaarborg om gelyk te wees.
    ///
    /// Hierdie funksie is die spieël van [`guaranteed_ne`], maar nie die omgekeerde nie.Daar is wysersvergelykings waarvoor albei funksies `false` lewer.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Die retourwaarde kan verander na gelang van die samestellerweergawe, en onveilige kode berus miskien nie op die resultaat van hierdie funksie vir 'n goeie weergawe nie.
    /// Daar word voorgestel om hierdie funksie slegs te gebruik vir prestasie-optimalisasies waar valse `false`-retourwaardes deur hierdie funksie nie die uitkoms beïnvloed nie, maar net die prestasie.
    /// Die gevolge van die gebruik van hierdie metode om looptyd en kompileringskode anders te laat optree, is nie ondersoek nie.
    /// Hierdie metode moet nie gebruik word om sulke verskille in te stel nie, en dit moet ook nie gestabiliseer word voordat ons 'n beter begrip van hierdie kwessie het nie.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Wys terug of twee aanwysers gewaarborg is om ongelyk te wees.
    ///
    /// Gedurende runtime gedra hierdie funksie soos `self != other`.
    /// In sommige kontekste (bv. Kompileringstyd-evaluering) is dit egter nie altyd moontlik om die ongelykheid van twee wysers vas te stel nie, dus kan hierdie funksie `false` verkeerdelik weergee vir verwysings wat later ongelyk blyk te wees.
    ///
    /// Maar wanneer dit `true` terugbesorg, is die aanwysers gewaarborg dat hulle ongelyk is.
    ///
    /// Hierdie funksie is die spieël van [`guaranteed_eq`], maar nie die omgekeerde nie.Daar is wysersvergelykings waarvoor albei funksies `false` lewer.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Die retourwaarde kan verander na gelang van die samestellerweergawe, en onveilige kode berus miskien nie op die resultaat van hierdie funksie vir 'n goeie weergawe nie.
    /// Daar word voorgestel om hierdie funksie slegs te gebruik vir prestasie-optimalisasies waar valse `false`-retourwaardes deur hierdie funksie nie die uitkoms beïnvloed nie, maar net die prestasie.
    /// Die gevolge van die gebruik van hierdie metode om looptyd en kompileringskode anders te laat optree, is nie ondersoek nie.
    /// Hierdie metode moet nie gebruik word om sulke verskille in te stel nie, en dit moet ook nie gestabiliseer word voordat ons 'n beter begrip van hierdie kwessie het nie.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Bereken die afstand tussen twee wysers.Die teruggekeerde waarde is in eenhede van T: die afstand in grepe word gedeel deur `mem::size_of::<T>()`.
    ///
    /// Hierdie funksie is die omgekeerde van [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// As een van die volgende voorwaardes oortree word, is die resultaat ongedefinieerde gedrag:
    ///
    /// * Beide die begin-en ander wyser moet binne perke of een byte verby die einde van dieselfde voorwerp wees.
    /// Let daarop dat in Rust elke (stack-allocated)-veranderlike as 'n afsonderlike toegekende voorwerp beskou word.
    ///
    /// * Albei aanwysers moet *afgelei word van*'n wyser na dieselfde voorwerp.
    ///   (Kyk hieronder vir 'n voorbeeld.)
    ///
    /// * Die afstand tussen die aanwysers, in grepe, moet 'n presiese veelvoud van die grootte van `T` wees.
    ///
    /// * Die afstand tussen die wysers,**in grepe**, kan nie 'n `isize` oorloop nie.
    ///
    /// * Die afstand wat binne perke is, kan nie op "wrapping around" die adresruimte staatmaak nie.
    ///
    /// Rust-tipes is nooit groter as `isize::MAX` nie, en Rust-toekennings word nooit om die adresruimte gevou nie, dus twee aanwysers binne die waarde van enige Rust-tipe `T` sal altyd aan die laaste twee voorwaardes voldoen.
    ///
    /// Die standaardbiblioteek verseker ook gewoonlik dat toewysings nooit die grootte bereik waar dit 'n kwessie is nie.
    /// `Vec` en `Box` verseker byvoorbeeld dat hulle nooit meer as `isize::MAX` bytes toewys nie, dus voldoen `ptr_into_vec.offset_from(vec.as_ptr())` altyd aan die laaste twee voorwaardes.
    ///
    /// Die meeste platforms kan fundamenteel nie eers so 'n groot toekenning opstel nie.
    /// Byvoorbeeld, geen bekende 64-bis-platform kan ooit 'n versoek van 2 <sup>63</sup> byte indien nie, omdat die bladsytabel beperk is of die adresruimte verdeel is.
    /// Sommige 32-en 16-bis-platforms kan egter suksesvol 'n versoek vir meer as `isize::MAX` bytes met dinge soos uitbreiding van fisiese adres, dien.
    /// As sodanig kan geheue wat direk van toewysers of geheuekaarte lêers verkry word * te groot wees om met hierdie funksie te hanteer.
    /// (Let daarop dat [`offset`] en [`add`] ook 'n soortgelyke beperking het en dus ook nie op sulke groot toekennings gebruik kan word nie.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Hierdie funksie panics as `T` 'n nulgrootte tipe ("ZST") is.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Verkeerde* gebruik:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Maak ptr2_other 'n "alias" van ptr2, maar afgelei van ptr1.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Aangesien ptr2_other en ptr2 afgelei is van aanwysings na verskillende voorwerpe, is die berekening van hul verrekening ongedefinieerde gedrag, al wys dit op dieselfde adres!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Ongedefinieerde gedrag
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // VEILIGHEID: die beller moet die veiligheidskontrak vir `offset_from` handhaaf.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Bereken die verrekening vanaf 'n wyser (gemak vir `.offset(count as isize)`).
    ///
    /// `count` is in eenhede van T;'n `count` van 3 stel byvoorbeeld 'n wyserversetting van `3 * size_of::<T>()` bytes voor.
    ///
    /// # Safety
    ///
    /// As een van die volgende voorwaardes oortree word, is die resultaat ongedefinieerde gedrag:
    ///
    /// * Beide die begin-en resulterende wyser moet binne perke of een byte aan die einde van dieselfde toegekende voorwerp wees.
    /// Let daarop dat in Rust elke (stack-allocated)-veranderlike as 'n afsonderlike toegekende voorwerp beskou word.
    ///
    /// * Die berekende verrekening,**in bytes**, kan nie 'n `isize` oorloop nie.
    ///
    /// * Die verrekening binne perke kan nie op "wrapping around" die adresruimte staatmaak nie.Dit wil sê, die oneindige presisie-som moet in 'n `usize` pas.
    ///
    /// Die samesteller en standaardbiblioteek probeer gewoonlik verseker dat toewysings nooit 'n grootte bereik waar dit 'n verrekening is nie.
    /// `Vec` en `Box` verseker byvoorbeeld dat hulle nooit meer as `isize::MAX` bytes toewys nie, dus `vec.as_ptr().add(vec.len())` is altyd veilig.
    ///
    /// Die meeste platforms kan fundamenteel nie eers so 'n toekenning opstel nie.
    /// Byvoorbeeld, geen bekende 64-bis-platform kan ooit 'n versoek van 2 <sup>63</sup> byte indien nie, omdat die bladsytabel beperk is of die adresruimte verdeel is.
    /// Sommige 32-en 16-bis-platforms kan egter suksesvol 'n versoek vir meer as `isize::MAX` bytes met dinge soos uitbreiding van fisiese adres, dien.
    ///
    /// As sodanig kan geheue wat direk van toewysers of geheuekaarte lêers verkry word * te groot wees om met hierdie funksie te hanteer.
    ///
    /// Oorweeg dit eerder om [`wrapping_add`] te gebruik as dit moeilik is om hierdie beperkings te bevredig.
    /// Die enigste voordeel van hierdie metode is dat dit meer aggressiewe samestellingsoptimalisasies moontlik maak.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // VEILIGHEID: die beller moet die veiligheidskontrak vir `offset` handhaaf.
        unsafe { self.offset(count as isize) }
    }

    /// Bereken die verrekening vanaf 'n aanwyser (gemak vir '.offset ((tel as isize).wrapping_neg())`).
    ///
    /// `count` is in eenhede van T;'n `count` van 3 stel byvoorbeeld 'n wyserversetting van `3 * size_of::<T>()` bytes voor.
    ///
    /// # Safety
    ///
    /// As een van die volgende voorwaardes oortree word, is die resultaat ongedefinieerde gedrag:
    ///
    /// * Beide die begin-en resulterende wyser moet binne perke of een byte aan die einde van dieselfde toegekende voorwerp wees.
    /// Let daarop dat in Rust elke (stack-allocated)-veranderlike as 'n afsonderlike toegekende voorwerp beskou word.
    ///
    /// * Die berekende verrekening mag nie `isize::MAX`**bytes** oorskry nie.
    ///
    /// * Die verrekening binne perke kan nie op "wrapping around" die adresruimte staatmaak nie.Dit wil sê, die oneindige presisie-som moet in 'n grootte pas.
    ///
    /// Die samesteller en standaardbiblioteek probeer gewoonlik verseker dat toewysings nooit 'n grootte bereik waar dit 'n verrekening is nie.
    /// `Vec` en `Box` verseker byvoorbeeld dat hulle nooit meer as `isize::MAX` bytes toewys nie, dus `vec.as_ptr().add(vec.len()).sub(vec.len())` is altyd veilig.
    ///
    /// Die meeste platforms kan fundamenteel nie eers so 'n toekenning opstel nie.
    /// Byvoorbeeld, geen bekende 64-bis-platform kan ooit 'n versoek van 2 <sup>63</sup> byte indien nie, omdat die bladsytabel beperk is of die adresruimte verdeel is.
    /// Sommige 32-en 16-bis-platforms kan egter suksesvol 'n versoek vir meer as `isize::MAX` bytes met dinge soos uitbreiding van fisiese adres, dien.
    ///
    /// As sodanig kan geheue wat direk van toewysers of geheuekaarte lêers verkry word * te groot wees om met hierdie funksie te hanteer.
    ///
    /// Oorweeg dit eerder om [`wrapping_sub`] te gebruik as dit moeilik is om hierdie beperkings te bevredig.
    /// Die enigste voordeel van hierdie metode is dat dit meer aggressiewe samestellingsoptimalisasies moontlik maak.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // VEILIGHEID: die beller moet die veiligheidskontrak vir `offset` handhaaf.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Bereken die verrekening vanaf 'n wyser met behulp van wikkelrekene.
    /// (gerief vir `.wrapping_offset(count as isize)`)
    ///
    /// `count` is in eenhede van T;'n `count` van 3 stel byvoorbeeld 'n wyserversetting van `3 * size_of::<T>()` bytes voor.
    ///
    /// # Safety
    ///
    /// Hierdie bewerking self is altyd veilig, maar die gebruik van die daaropvolgende wyser is nie.
    ///
    /// Die resulterende wyser bly vas aan dieselfde toegewysde voorwerp waarop `self` wys.
    /// Dit kan *nie* gebruik word om toegang te verkry tot 'n ander toegewysde voorwerp nie.Let daarop dat in Rust elke (stack-allocated)-veranderlike as 'n afsonderlike toegekende voorwerp beskou word.
    ///
    /// Met ander woorde, `let z = x.wrapping_add((y as usize) - (x as usize))` maak *nie*`z` dieselfde as `y` nie, selfs al neem ons aan dat `T` die grootte `1` het en daar geen oorloop is nie: `z` is steeds aan die voorwerp waaraan `x` geheg is, en die verwysing daarvan is ongedefinieerde gedrag, tensy `x` en `y` wys in dieselfde toegekende voorwerp.
    ///
    /// In vergelyking met [`add`] vertraag hierdie metode basies die vereiste om binne dieselfde toegewysde voorwerp te bly: [`add`] is onmiddellike ongedefinieerde gedrag wanneer u objekgrense oorskry;`wrapping_add` produseer 'n wyser, maar lei steeds tot ongedefinieerde gedrag as 'n aanwyser herverwys word as dit buite die perke is van die voorwerp waaraan dit geheg is.
    /// [`add`] kan beter geoptimaliseer word en is dus verkieslik in prestasie-sensitiewe kode.
    ///
    /// Die vertraagde tjek neem slegs rekening met die waarde van die wyser waarna verwys is, nie die tussenwaardes wat tydens die berekening van die finale resultaat gebruik is nie.
    /// `x.wrapping_add(o).wrapping_sub(o)` is byvoorbeeld altyd dieselfde as `x`.Met ander woorde, dit is toegelaat om die toegekende voorwerp te verlaat en dit later weer in te voer.
    ///
    /// As u voorwerpgrense moet oorsteek, gooi die wyser na 'n heelgetal en doen die rekenkunde daar.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// // Iterasie met behulp van 'n rou wyser in inkremente van twee elemente
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Hierdie lus druk "1, 3, 5, " af
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Bereken die verrekening vanaf 'n wyser met behulp van wikkelrekene.
    /// (gemak vir `.wrapping_offset ((tel as isize).wrapping_neg())`)
    ///
    /// `count` is in eenhede van T;'n `count` van 3 stel byvoorbeeld 'n wyserversetting van `3 * size_of::<T>()` bytes voor.
    ///
    /// # Safety
    ///
    /// Hierdie bewerking self is altyd veilig, maar die gebruik van die daaropvolgende wyser is nie.
    ///
    /// Die resulterende wyser bly vas aan dieselfde toegewysde voorwerp waarop `self` wys.
    /// Dit kan *nie* gebruik word om toegang te verkry tot 'n ander toegewysde voorwerp nie.Let daarop dat in Rust elke (stack-allocated)-veranderlike as 'n afsonderlike toegekende voorwerp beskou word.
    ///
    /// Met ander woorde, `let z = x.wrapping_sub((x as usize) - (y as usize))` maak *nie*`z` dieselfde as `y` nie, selfs al neem ons aan dat `T` die grootte `1` het en dat daar geen oorloop is nie: `z` is steeds aan die voorwerp waaraan `x` geheg is, en die verwysing daarvan is ongedefinieerde gedrag, tensy `x` en `y` wys in dieselfde toegekende voorwerp.
    ///
    /// In vergelyking met [`sub`] vertraag hierdie metode basies die vereiste om binne dieselfde toegewysde voorwerp te bly: [`sub`] is onmiddellike ongedefinieerde gedrag wanneer u objekgrense oorskry;`wrapping_sub` produseer 'n wyser, maar lei steeds tot ongedefinieerde gedrag as 'n aanwyser herverwys word as dit buite die perke is van die voorwerp waaraan dit geheg is.
    /// [`sub`] kan beter geoptimaliseer word en is dus verkieslik in prestasie-sensitiewe kode.
    ///
    /// Die vertraagde tjek neem slegs rekening met die waarde van die wyser waarna verwys is, nie die tussenwaardes wat tydens die berekening van die finale resultaat gebruik is nie.
    /// `x.wrapping_add(o).wrapping_sub(o)` is byvoorbeeld altyd dieselfde as `x`.Met ander woorde, dit is toegelaat om die toegekende voorwerp te verlaat en dit later weer in te voer.
    ///
    /// As u voorwerpgrense moet oorsteek, gooi die wyser na 'n heelgetal en doen die rekenkunde daar.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// // Iterasie met behulp van 'n rou wyser in inkremente van twee elemente (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Hierdie lus druk "5, 3, 1, " af
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Stel die wyserwaarde op `ptr`.
    ///
    /// In die geval dat `self` 'n (fat)-aanwyser van 'n ongroot grootte is, sal hierdie bewerking slegs die wysergedeelte beïnvloed, terwyl dit vir (thin)-aanwysers na groot tipes dieselfde uitwerking het as 'n eenvoudige opdrag.
    ///
    /// Die resulterende wyser het oorsprong van `val`, dws vir 'n vetwyser is hierdie bewerking semanties dieselfde as om 'n nuwe vetwyser te skep met die datawyserwaarde van `val`, maar die metadata van `self`.
    ///
    ///
    /// # Examples
    ///
    /// Hierdie funksie is hoofsaaklik nuttig om byte-wys wyserrekeninge op potensieel vetwysers toe te laat:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // sal "3" druk
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // VEILIGHEID: In die geval van 'n dun wyser, is hierdie bewerking identies
        // na 'n eenvoudige opdrag.
        // In die geval van 'n vetwyser, met die huidige implementering van die vetwyser-uitleg, is die eerste veld van so 'n wyser altyd die datawyser, wat ook toegeken word.
        //
        unsafe { *thin = val };
        self
    }

    /// Lees die waarde van `self` af sonder om dit te skuif.
    /// Dit laat die geheue in `self` onveranderd.
    ///
    /// Kyk na [`ptr::read`] vir veiligheidsprobleme en voorbeelde.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // VEILIGHEID: die beller moet die veiligheidskontrak vir `` handhaaf.
        unsafe { read(self) }
    }

    /// Voer die waarde van `self` vlugtig uit sonder om dit te skuif.Dit laat die geheue in `self` onveranderd.
    ///
    /// Vlugtige bedrywighede is bedoel om op die I/O-geheue te reageer en word gewaarborg dat die samesteller dit nie in ander vlugtige bedrywighede sal verander of herbestel nie.
    ///
    ///
    /// Kyk na [`ptr::read_volatile`] vir veiligheidsprobleme en voorbeelde.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // VEILIGHEID: die beller moet die veiligheidskontrak vir `read_volatile` handhaaf.
        unsafe { read_volatile(self) }
    }

    /// Lees die waarde van `self` af sonder om dit te skuif.
    /// Dit laat die geheue in `self` onveranderd.
    ///
    /// In teenstelling met `read`, is die wyser moontlik nie uitlyn nie.
    ///
    /// Kyk na [`ptr::read_unaligned`] vir veiligheidsprobleme en voorbeelde.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // VEILIGHEID: die beller moet die veiligheidskontrak vir `read_unaligned` handhaaf.
        unsafe { read_unaligned(self) }
    }

    /// Kopieer `count * size_of<T>`-grepe van `self` na `dest`.
    /// Die bron en bestemming kan mekaar oorvleuel.
    ///
    /// NOTE: dit het die *dieselfde* argumentorde as [`ptr::copy`].
    ///
    /// Kyk na [`ptr::copy`] vir veiligheidsprobleme en voorbeelde.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // VEILIGHEID: die beller moet die veiligheidskontrak vir `copy` handhaaf.
        unsafe { copy(self, dest, count) }
    }

    /// Kopieer `count * size_of<T>`-grepe van `self` na `dest`.
    /// Die bron en bestemming kan *nie* oorvleuel nie.
    ///
    /// NOTE: dit het die *dieselfde* argumentorde as [`ptr::copy_nonoverlapping`].
    ///
    /// Kyk na [`ptr::copy_nonoverlapping`] vir veiligheidsprobleme en voorbeelde.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // VEILIGHEID: die beller moet die veiligheidskontrak vir `copy_nonoverlapping` handhaaf.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Kopieer `count * size_of<T>`-grepe van `src` na `self`.
    /// Die bron en bestemming kan mekaar oorvleuel.
    ///
    /// NOTE: dit het die *teenoorgestelde* argumentvolgorde van [`ptr::copy`].
    ///
    /// Kyk na [`ptr::copy`] vir veiligheidsprobleme en voorbeelde.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // VEILIGHEID: die beller moet die veiligheidskontrak vir `copy` handhaaf.
        unsafe { copy(src, self, count) }
    }

    /// Kopieer `count * size_of<T>`-grepe van `src` na `self`.
    /// Die bron en bestemming kan *nie* oorvleuel nie.
    ///
    /// NOTE: dit het die *teenoorgestelde* argumentvolgorde van [`ptr::copy_nonoverlapping`].
    ///
    /// Kyk na [`ptr::copy_nonoverlapping`] vir veiligheidsprobleme en voorbeelde.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // VEILIGHEID: die beller moet die veiligheidskontrak vir `copy_nonoverlapping` handhaaf.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Voer die vernietiger (indien enige) van die gewysde waarde uit.
    ///
    /// Kyk na [`ptr::drop_in_place`] vir veiligheidsprobleme en voorbeelde.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // VEILIGHEID: die beller moet die veiligheidskontrak vir `drop_in_place` handhaaf.
        unsafe { drop_in_place(self) }
    }

    /// Skryf 'n geheueplek met die gegewe waarde oor sonder om die ou waarde te lees of te laat val.
    ///
    ///
    /// Kyk na [`ptr::write`] vir veiligheidsprobleme en voorbeelde.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // VEILIGHEID: die beller moet die veiligheidskontrak vir `write` handhaaf.
        unsafe { write(self, val) }
    }

    /// Roep 'n geheuestel op die gespesifiseerde aanwyser en stel `count * size_of::<T>()` bytes geheue in wat begin by `self` tot `val`.
    ///
    ///
    /// Kyk na [`ptr::write_bytes`] vir veiligheidsprobleme en voorbeelde.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // VEILIGHEID: die beller moet die veiligheidskontrak vir `write_bytes` handhaaf.
        unsafe { write_bytes(self, val, count) }
    }

    /// Voer 'n vlugtige skryf van 'n geheueplek met die gegewe waarde uit sonder om die ou waarde te lees of te laat val.
    ///
    /// Vlugtige bedrywighede is bedoel om op die I/O-geheue te reageer en word gewaarborg dat die samesteller dit nie in ander vlugtige bedrywighede sal verander of herbestel nie.
    ///
    ///
    /// Kyk na [`ptr::write_volatile`] vir veiligheidsprobleme en voorbeelde.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // VEILIGHEID: die beller moet die veiligheidskontrak vir `write_volatile` handhaaf.
        unsafe { write_volatile(self, val) }
    }

    /// Skryf 'n geheueplek met die gegewe waarde oor sonder om die ou waarde te lees of te laat val.
    ///
    ///
    /// In teenstelling met `write`, is die wyser moontlik nie uitlyn nie.
    ///
    /// Kyk na [`ptr::write_unaligned`] vir veiligheidsprobleme en voorbeelde.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // VEILIGHEID: die beller moet die veiligheidskontrak vir `write_unaligned` handhaaf.
        unsafe { write_unaligned(self, val) }
    }

    /// Vervang die waarde op `self` met `src`, met die terugkeer van die ou waarde, sonder om dit te laat val.
    ///
    ///
    /// Kyk na [`ptr::replace`] vir veiligheidsprobleme en voorbeelde.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // VEILIGHEID: die beller moet die veiligheidskontrak vir `replace` handhaaf.
        unsafe { replace(self, src) }
    }

    /// Ruil die waardes op twee veranderlike plekke van dieselfde tipe om, sonder om ook te deitialiseer.
    /// Hulle kan oorvleuel, anders as `mem::swap` wat andersins gelyk is.
    ///
    /// Kyk na [`ptr::swap`] vir veiligheidsprobleme en voorbeelde.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // VEILIGHEID: die beller moet die veiligheidskontrak vir `swap` handhaaf.
        unsafe { swap(self, with) }
    }

    /// Bereken die verrekening wat op die aanwyser toegepas moet word om dit op `align` uit te laat.
    ///
    /// As dit nie moontlik is om die wyser in lyn te bring nie, gee die implementering `usize::MAX` terug.
    /// Dit is toelaatbaar dat die implementering `usize::MAX`*altyd* terugbesorg.
    /// Slegs die prestasie van u algoritme kan daarvan afhang dat u 'n bruikbare verrekening hier kry, nie die korrektheid daarvan nie.
    ///
    /// Die verrekening word uitgedruk in aantal `T`-elemente, en nie bytes nie.Die teruggestuurde waarde kan met die `wrapping_add`-metode gebruik word.
    ///
    /// Daar is hoegenaamd geen waarborge dat die verrekening van die wyser nie sal oorloop of verder gaan as die toewysing waarop die wyser wys nie.
    ///
    /// Dit is aan die beller om te verseker dat die teruggekeerde verrekening korrek is in alle ander terme as die belyning.
    ///
    /// # Panics
    ///
    /// Die funksie panics as `align` nie 'n krag-van-twee is nie.
    ///
    /// # Examples
    ///
    /// Toegang tot aangrensende `u8` as `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // terwyl die wyser via `offset` in lyn kan wees, sal dit buite die toekenning wys
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // VEILIGHEID: Daar is gekontroleer dat `align` 'n krag van 2 hierbo is
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Wys die lengte van 'n rou sny.
    ///
    /// Die teruggekeerde waarde is die aantal **elemente**, nie die aantal grepe nie.
    ///
    /// Hierdie funksie is veilig, selfs as die rou sny nie na 'n snyverwysing kan gegooi word nie, omdat die wyser nul of onbelyn is.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // VEILIGHEID: dit is veilig omdat `*const [T]` en `FatPtr<T>` dieselfde uitleg het.
            // Slegs `std` kan hierdie waarborg gee.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Wys 'n rou wyser na die buffer van die sny.
    ///
    /// Dit is gelykstaande aan die gooi van `self` na `*mut T`, maar meer veilig.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Wys 'n rou wyser na 'n element of onderdeel, sonder om grense te kontroleer.
    ///
    /// Die oproep van hierdie metode met 'n indeks buite die perke of as `self` nie herverwysbaar is nie, is *[ongedefinieerde gedrag]*, selfs al word die aanwyser wat hieruit gevolg word nie gebruik nie.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // VEILIGHEID: die oproeper sorg dat `self` herverwysbaar is en `index` binne-perke is.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Wys `None` as die wyser nul is, of gee 'n gedeelde deel terug na die waarde wat in `Some` toegedraai is.
    /// In teenstelling met [`as_ref`], is dit nie nodig dat die waarde geïnisialiseer moet word nie.
    ///
    /// Sien [`as_uninit_slice_mut`] vir die veranderlike eweknie.
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// As u hierdie metode aanroep, moet u seker maak dat *die aanwyser NUL* is of dat * die volgende waar is:
    ///
    /// * Die aanwyser moet [valid] wees vir lees vir `ptr.len() * mem::size_of::<T>()` baie grepe, en dit moet behoorlik in lyn wees.Dit beteken veral:
    ///
    ///     * Die hele geheue-reeks van hierdie sny moet binne 'n enkele toegekende voorwerp vervat wees!
    ///       Snye kan nooit oor veelvuldige toegekende voorwerpe strek nie.
    ///
    ///     * Die wyser moet gelyk wees vir snye sonder lengte.
    ///     Een rede hiervoor is dat die optimering van enum-uitleg daarop kan staatmaak dat verwysings (insluitend snye van enige lengte) in lyn is en nie-nul is om dit van ander data te onderskei.
    ///
    ///     U kan 'n aanwyser verkry wat as `data` gebruik kan word vir snylengtes met [`NonNull::dangling()`].
    ///
    /// * Die totale grootte `ptr.len() * mem::size_of::<T>()` van die sny mag nie groter as `isize::MAX` wees nie.
    ///   Sien die veiligheidsdokumentasie van [`pointer::offset`].
    ///
    /// * U moet die aliasingsreëls van Rust toepas, aangesien die teruggekeerde leeftyd `'a` willekeurig gekies word en nie noodwendig die werklike leeftyd van die data weerspieël nie.
    ///   In die besonder, vir die duur van hierdie leeftyd, moet die geheue waarop die aanwyser wys, nie gemuteer word nie (behalwe in `UnsafeCell`).
    ///
    /// Dit geld selfs al is die resultaat van hierdie metode ongebruik!
    ///
    /// Sien ook [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // VEILIGHEID: die beller moet die veiligheidskontrak vir `as_uninit_slice` handhaaf.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Wys `None` as die aanwyser nul is, of anders gee u 'n unieke deel terug na die waarde wat in `Some` toegedraai is.
    /// In teenstelling met [`as_mut`], is dit nie nodig dat die waarde geïnisialiseer moet word nie.
    ///
    /// Vir die gedeelde eweknie, sien [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// As u hierdie metode aanroep, moet u seker maak dat *die aanwyser NUL* is of dat * die volgende waar is:
    ///
    /// * Die aanwyser moet [valid] wees vir lees en skryf vir `ptr.len() * mem::size_of::<T>()` baie grepe, en dit moet behoorlik in lyn wees.Dit beteken veral:
    ///
    ///     * Die hele geheue-reeks van hierdie sny moet binne 'n enkele toegekende voorwerp vervat wees!
    ///       Snye kan nooit oor veelvuldige toegekende voorwerpe strek nie.
    ///
    ///     * Die wyser moet gelyk wees vir snye sonder lengte.
    ///     Een rede hiervoor is dat die optimering van enum-uitleg daarop kan staatmaak dat verwysings (insluitend snye van enige lengte) in lyn is en nie-nul is om dit van ander data te onderskei.
    ///
    ///     U kan 'n aanwyser verkry wat as `data` gebruik kan word vir snylengtes met [`NonNull::dangling()`].
    ///
    /// * Die totale grootte `ptr.len() * mem::size_of::<T>()` van die sny mag nie groter as `isize::MAX` wees nie.
    ///   Sien die veiligheidsdokumentasie van [`pointer::offset`].
    ///
    /// * U moet die aliasingsreëls van Rust toepas, aangesien die teruggekeerde leeftyd `'a` willekeurig gekies word en nie noodwendig die werklike leeftyd van die data weerspieël nie.
    ///   In die besonder, gedurende die leeftyd van hierdie leeftyd, mag die geheue waarop die aanwyser wys, nie deur enige ander aanwyser (gelees of geskryf) verkry word nie.
    ///
    /// Dit geld selfs al is die resultaat van hierdie metode ongebruik!
    ///
    /// Sien ook [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // VEILIGHEID: die beller moet die veiligheidskontrak vir `as_uninit_slice_mut` handhaaf.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Gelykheid vir aanwysers
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}