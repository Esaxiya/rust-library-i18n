use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// 'N Omslag om te keer dat samesteller outomaties' T 'se vernietiger noem.
/// Hierdie verpakking is 0-koste.
///
/// `ManuallyDrop<T>` is onderhewig aan dieselfde uitlegoptimalisasies as `T`.
/// As gevolg daarvan het dit geen invloed op die aannames wat die samesteller oor die inhoud daarvan maak nie.
/// Die initialisering van 'n `ManuallyDrop<&mut T>` met [`mem::zeroed`] is byvoorbeeld ongedefinieerde gedrag.
/// As u nie-geïnitialiseerde data moet hanteer, gebruik dan [`MaybeUninit<T>`].
///
/// Let daarop dat toegang tot die waarde binne 'n `ManuallyDrop<T>` veilig is.
/// Dit beteken dat 'n `ManuallyDrop<T>` waarvan die inhoud weggelaat is, nie blootgestel moet word deur 'n openbare veilige API nie.
/// Op ooreenstemmende wyse is `ManuallyDrop::drop` onveilig.
///
/// # `ManuallyDrop` en drop order.
///
/// Rust het 'n goed gedefinieerde [drop order] waardes.
/// Om te verseker dat velde of inwoners in 'n spesifieke volgorde laat val word, rangskik u die verklarings sodat die implisiete valbestelling die korrekte is.
///
/// Dit is moontlik om `ManuallyDrop` te gebruik om die drop order te beheer, maar dit vereis onveilige kode en dit is moeilik om reg te doen in die teenwoordigheid van afwikkeling.
///
///
/// As u byvoorbeeld wil seker maak dat 'n spesifieke veld na die ander val, maak dit die laaste veld van 'n struktuur:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` sal na `children` laat vaar word.
///     // Rust waarborg dat velde in die volgorde van verklaring laat val word.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Draai 'n waarde toe om handmatig te laat vaar.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // U kan steeds die waarde veilig gebruik
    /// assert_eq!(*x, "Hello");
    /// // Maar `Drop` sal nie hier bestuur word nie
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Onttrek die waarde uit die `ManuallyDrop`-houer.
    ///
    /// Hierdeur kan die waarde weer gedaal word.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Dit laat die `Box` val.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Haal die waarde van die `ManuallyDrop<T>`-houer uit.
    ///
    /// Hierdie metode is hoofsaaklik bedoel vir die verskuiwing van waardes in druppel.
    /// In plaas daarvan om [`ManuallyDrop::drop`] te gebruik om die waarde handmatig te laat val, kan u hierdie metode gebruik om die waarde te neem en dit te gebruik soos u wil.
    ///
    /// Indien moontlik, is dit beter om [`into_inner`][`ManuallyDrop::into_inner`] te gebruik, wat voorkom dat die inhoud van die `ManuallyDrop<T>` dupliseer word.
    ///
    ///
    /// # Safety
    ///
    /// Hierdie funksie skuif die ingeslote waarde semanties uit sonder om verdere gebruik te voorkom, en laat die toestand van hierdie houer onveranderd.
    /// U moet toesien dat hierdie `ManuallyDrop` nie weer gebruik word nie.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // VEILIGHEID: ons lees uit 'n verwysing wat gewaarborg is
        // geldig te wees vir lees.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Laat die ingeslote waarde handmatig daal.Dit is presies gelykstaande aan die oproep van [`ptr::drop_in_place`] met 'n wyser na die inhoud.
    /// As sodanig, sal die vernietiger in die plek genoem word sonder om die waarde te verskuif, tensy die ingeslote waarde 'n verpakte struktuur is, en kan dit dus gebruik word om [pinned]-data veilig te laat val.
    ///
    /// As u die waarde besit, kan u eerder [`ManuallyDrop::into_inner`] gebruik.
    ///
    /// # Safety
    ///
    /// Hierdie funksie voer die vernietiger van die ingeslote waarde uit.
    /// Behalwe vir veranderinge wat deur die vernietiger self aangebring is, word die geheue onveranderd gelaat, en wat die samesteller betref, is dit steeds 'n bietjie patroon wat geldig is vir die tipe `T`.
    ///
    ///
    /// Hierdie "zombie"-waarde moet egter nie aan veilige kode blootgestel word nie, en hierdie funksie moet nie meer as een keer genoem word nie.
    /// Om 'n waarde te gebruik nadat dit gedaal is of 'n waarde meermale te laat val, kan ongedefinieerde gedrag veroorsaak (afhangende van wat `drop` doen).
    /// Dit word normaalweg deur die tipe stelsel voorkom, maar gebruikers van `ManuallyDrop` moet die waarborge handhaaf sonder hulp van die samesteller.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // VEILIGHEID: ons laat die waarde wat deur 'n veranderlike verwysing aangedui word, neer
        // wat verseker geldig is vir skryfwerk.
        // Dit is die oproeper om te sorg dat `slot` nie weer val nie.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}