//! Basiese funksies vir die hantering van geheue.
//!
//! Hierdie module bevat funksies om die grootte en belyning van soorte te ondersoek, geheue te initialiseer en te manipuleer.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Neem eienaarskap en "forgets" oor die waarde **sonder om die vernietiger** te laat loop.
///
/// Enige hulpbronne wat die waarde bestuur, soos die geheue van 'n lêer of 'n lêerhandvatsel, sal vir altyd in 'n onbereikbare toestand vertoef.Dit waarborg egter nie dat aanwysings na hierdie geheue geldig sal bly nie.
///
/// * Kyk na [`Box::leak`] as u geheue wil lek.
/// * Raadpleeg [`Box::into_raw`] as u 'n rou wyser na die geheue wil verkry.
/// * Raadpleeg [`mem::drop`] as u 'n waarde op die regte manier wil verkoop en die vernietiger daarvan wil gebruik.
///
/// # Safety
///
/// `forget` word nie as `unsafe` gemerk nie, omdat die veiligheidswaarborge van Rust nie 'n waarborg bevat dat vernietigers altyd sal werk nie.
/// Byvoorbeeld, 'n program kan 'n verwysingsiklus met behulp van [`Rc`][rc] skep, of [`process::exit`][exit] bel om te verlaat sonder om vernietigers uit te voer.
/// Die toelaat van `mem::forget` van veilige kode verander dus nie die veiligheidswaarborge van Rust fundamenteel nie.
///
/// Dit gesê, lekkasies van bronne soos geheue of I/O-voorwerpe is gewoonlik ongewens.
/// Die behoefte kom in sommige gespesialiseerde gebruiksgevalle vir FFI of onveilige kode voor, maar selfs dan word [`ManuallyDrop`] gewoonlik verkies.
///
/// Omdat vergeet van 'n waarde toegelaat word, moet enige `unsafe`-kode wat u skryf, hierdie moontlikheid moontlik maak.U kan nie 'n waarde teruggee nie en verwag dat die beller noodwendig die waarde se vernietiger sal bestuur.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Die kanonieke veilige gebruik van `mem::forget` is om die vernietiger van 'n waarde wat deur die `Drop` trait geïmplementeer word, te omseil.Dit sal byvoorbeeld 'n `File` lek, dws
/// herwin die ruimte wat deur die veranderlike geneem word, maar sluit nooit die onderliggende stelselbron nie:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Dit is handig wanneer die eienaarskap van die onderliggende bron voorheen na kode buite Rust oorgedra is, byvoorbeeld deur die rou lêerbeskrywer na C-kode oor te dra.
///
/// # Verhouding met `ManuallyDrop`
///
/// Terwyl `mem::forget` ook gebruik kan word om *geheue* eienaarskap oor te dra, is dit foutloos.
/// [`ManuallyDrop`] moet eerder gebruik word.Beskou byvoorbeeld hierdie kode:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Bou 'n `String` met behulp van die inhoud van `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // lek `v` omdat die geheue daarvan nou deur `s` bestuur word
/// mem::forget(v);  // FOUT, v is ongeldig en moet nie aan 'n funksie oorgedra word nie
/// assert_eq!(s, "Az");
/// // `s` word implisiet laat vaar en die geheue daarvan herdeel.
/// ```
///
/// Daar is twee probleme met die bostaande voorbeeld:
///
/// * As meer kode tussen die konstruksie van `String` en die aanroep van `mem::forget()` bygevoeg word, sal 'n panic daarin 'n dubbele vryheid veroorsaak omdat dieselfde geheue deur beide `v` en `s` hanteer word.
/// * Nadat `v.as_mut_ptr()` gebel en die eienaarskap van die data na `s` oorgedra is, is die `v`-waarde ongeldig.
/// Selfs wanneer 'n waarde net na `mem::forget` geskuif word (wat dit nie sal inspekteer nie), is daar sekere soorte vereistes vir hul waardes wat dit ongeldig maak wanneer dit hang of nie meer besit word nie.
/// Die gebruik van ongeldige waardes op enige manier, insluitend die oordra daarvan na of die terugstuur van die funksies, vorm ongedefinieerde gedrag en kan die aannames van die samesteller breek.
///
/// Om na `ManuallyDrop` oor te skakel, vermy albei probleme:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Voordat ons `v` in sy onbewerkte dele demonteer, moet u seker maak dat dit nie val nie!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Demonteer nou `v`.Hierdie bewerkings kan nie panic wees nie, dus kan daar nie lek wees nie.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Laastens, bou 'n `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` word implisiet laat vaar en die geheue daarvan herdeel.
/// ```
///
/// `ManuallyDrop` voorkom dubbelvry omdat ons die vernietiger van 'v' uitskakel voordat ons iets anders doen.
/// `mem::forget()` laat dit nie toe nie omdat dit sy argument verorber, wat ons dwing om dit eers te bel nadat ons alles wat ons benodig uit `v` onttrek het.
/// Al is 'n panic ingestel tussen die konstruksie van `ManuallyDrop` en die bou van die tou (wat nie in die kode soos aangedui kan voorkom nie), sal dit lei tot 'n lek en nie 'n dubbele vryheid nie.
/// Met ander woorde, `ManuallyDrop` fouteer aan die kant van lekkasie in plaas van om te dwaal aan die kant van (dubbele) val.
///
/// `ManuallyDrop` verhoed ons ook om na "touch" `v` te moet gaan nadat ons die eienaarskap na `s` oorgedra het. Die laaste stap van interaksie met `v` om dit weg te doen sonder om die vernietiger daarvan te bestuur, word heeltemal vermy.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Soos [`forget`], maar aanvaar ook ongepaste waardes.
///
/// Hierdie funksie is slegs 'n shim wat bedoel is om verwyder te word wanneer die `unsized_locals`-funksie gestabiliseer word.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Wys die grootte van 'n tipe in grepe.
///
/// Meer spesifiek, dit is die verrekening in grepe tussen opeenvolgende elemente in 'n skikking met die artikeltipe, insluitend die opstelling van die opstelling.
///
/// Dus, vir enige tipe `T` en lengte `n`, het `[T; n]` 'n grootte van `n * size_of::<T>()`.
///
/// Oor die algemeen is die grootte van 'n tipe nie stabiel in samestellings nie, maar wel spesifieke tipes soos primitiewe.
///
/// Die volgende tabel gee die grootte van primitiewe.
///
/// Tik |grootte_van: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Verder het `usize` en `isize` dieselfde grootte.
///
/// Die tipes `*const T`, `&T`, `Box<T>`, `Option<&T>` en `Option<Box<T>>` het almal dieselfde grootte.
/// As `T` groot is, het al die tipes dieselfde grootte as `usize`.
///
/// Die veranderlikheid van 'n wyser verander nie die grootte daarvan nie.As sodanig het `&T` en `&mut T` dieselfde grootte.
/// Net so vir `*const T` en `* mut T`.
///
/// # Grootte van `#[repr(C)]` items
///
/// Die `C`-voorstelling vir items het 'n gedefinieerde uitleg.
/// Met hierdie uitleg is die grootte van items ook stabiel, solank alle velde 'n stabiele grootte het.
///
/// ## Grootte van structs
///
/// Vir `structs` word die grootte bepaal deur die volgende algoritme.
///
/// Vir elke veld in die struktuur volgens volgorde van verklaring:
///
/// 1. Voeg die grootte van die veld by.
/// 2. Rond die huidige grootte af tot die naaste veelvoud van die volgende veld se [alignment].
///
/// Rond ten slotte die grootte van die struktuur af tot die naaste veelvoud van sy [alignment].
/// Die belyning van die struktuur is gewoonlik die grootste belyning van al sy velde;dit kan verander word met die gebruik van `repr(align(N))`.
///
/// In teenstelling met `C`, is die grootte van nulgrootte nie tot een greep afgerond nie.
///
/// ## Grootte van Enums
///
/// Enums wat geen ander data as die diskriminant bevat nie, het dieselfde grootte as C enums op die platform waarvoor hulle saamgestel is.
///
/// ## Grootte van vakbonde
///
/// Die grootte van 'n unie is die grootte van sy grootste veld.
///
/// In teenstelling met `C`, is vakbonde van nulgrootte nie tot een greep afgerond nie.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Sommige primitiewe
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Sommige skikkings
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Gelykheid wysergrootte
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Gebruik `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Die grootte van die eerste veld is 1, dus voeg 1 by die grootte.Grootte is 1.
/// // Die tweede veld se belyning is 2, dus voeg 1 by die grootte vir die vulling.Grootte is 2.
/// // Die grootte van die tweede veld is 2, dus voeg 2 by die grootte.Grootte is 4.
/// // Die belyning van die derde veld is 1, dus voeg 0 by die grootte vir vulling.Grootte is 4.
/// // Die grootte van die derde veld is 1, so voeg 1 by die grootte.Grootte is 5.
/// // Laastens is die belyning van die struktuur 2 (omdat die grootste belyning onder sy velde 2 is), voeg dus 1 by die grootte vir die vulling.
/// // Grootte is 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tupelstroke volg dieselfde reëls.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Let daarop dat die herorden van die velde die grootte kan verlaag.
/// // Ons kan albei vullingbyte verwyder deur `third` voor `second` te plaas.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Unie grootte is die grootte van die grootste veld.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Wys die grootte van die aangeduide waarde in grepe.
///
/// Dit is gewoonlik dieselfde as `size_of::<T>()`.
/// Wanneer `T` * egter geen staties bekende grootte het nie, byvoorbeeld 'n sny [`[T]`][slice] of 'n [trait object], kan `size_of_val` gebruik word om die dinamies bekende grootte te kry.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // VEILIGHEID: `val` is 'n verwysing, dus dit is 'n geldige rou aanwyser
    unsafe { intrinsics::size_of_val(val) }
}

/// Wys die grootte van die aangeduide waarde in grepe.
///
/// Dit is gewoonlik dieselfde as `size_of::<T>()`.Wanneer `T` * egter geen staties bekende grootte het nie, bv. 'N sny [`[T]`][slice] of 'n [trait object], kan `size_of_val_raw` gebruik word om die dinamies bekende grootte te kry.
///
/// # Safety
///
/// Hierdie funksie is slegs veilig om te skakel as die volgende voorwaardes geld:
///
/// - As `T` `Sized` is, is hierdie funksie altyd veilig om te skakel.
/// - As die ongroot grootte stert van `T` die volgende is:
///     - 'n [slice], dan moet die lengte van die snytestert 'n geïnitialiseerde heelgetal wees, en die grootte van die *hele waarde*(dinamiese stertlengte + voorvoegsel met statiese grootte) moet in `isize` pas.
///     - 'n [trait object], dan moet die vtabelgedeelte van die aanwyser wys op 'n geldige vtabel wat verkry word deur 'n onbeduidende dwang, en die grootte van die *hele waarde*(dinamiese stertlengte + voorvoegsel staties) moet in `isize` pas.
///
///     - 'n (unstable) [extern type], dan is hierdie funksie altyd veilig om te skakel, maar kan panic of andersins die verkeerde waarde oplewer, aangesien die uitleg van die eksterne tipe nie bekend is nie.
///     Dit is dieselfde gedrag as [`size_of_val`] as u verwys na 'n tipe met 'n eksterne stert.
///     - anders is dit konserwatief nie toegelaat om hierdie funksie te noem nie.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // VEILIGHEID: die beller moet 'n geldige rou aanwyser verskaf
    unsafe { intrinsics::size_of_val(val) }
}

/// Wys die [ABI]-vereiste minimum belyning van 'n tipe.
///
/// Elke verwysing na 'n waarde van die tipe `T` moet 'n veelvoud van hierdie getal wees.
///
/// Dit is die belyning wat vir struktuurvelde gebruik word.Dit kan kleiner wees as die voorkeurbelyning.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Wys die [ABI] vereiste minimum belyning van die tipe waarde waarop `val` wys.
///
/// Elke verwysing na 'n waarde van die tipe `T` moet 'n veelvoud van hierdie getal wees.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // VEILIGHEID: val is 'n verwysing, dus dit is 'n geldige rou aanwyser
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Wys die [ABI]-vereiste minimum belyning van 'n tipe.
///
/// Elke verwysing na 'n waarde van die tipe `T` moet 'n veelvoud van hierdie getal wees.
///
/// Dit is die belyning wat vir struktuurvelde gebruik word.Dit kan kleiner wees as die voorkeurbelyning.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Wys die [ABI] vereiste minimum belyning van die tipe waarde waarop `val` wys.
///
/// Elke verwysing na 'n waarde van die tipe `T` moet 'n veelvoud van hierdie getal wees.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // VEILIGHEID: val is 'n verwysing, dus dit is 'n geldige rou aanwyser
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Wys die [ABI] vereiste minimum belyning van die tipe waarde waarop `val` wys.
///
/// Elke verwysing na 'n waarde van die tipe `T` moet 'n veelvoud van hierdie getal wees.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Hierdie funksie is slegs veilig om te skakel as die volgende voorwaardes geld:
///
/// - As `T` `Sized` is, is hierdie funksie altyd veilig om te skakel.
/// - As die ongroot grootte stert van `T` die volgende is:
///     - 'n [slice], dan moet die lengte van die snytestert 'n geïnitialiseerde heelgetal wees, en die grootte van die *hele waarde*(dinamiese stertlengte + voorvoegsel met statiese grootte) moet in `isize` pas.
///     - 'n [trait object], dan moet die vtabelgedeelte van die aanwyser wys op 'n geldige vtabel wat verkry word deur 'n onbeduidende dwang, en die grootte van die *hele waarde*(dinamiese stertlengte + voorvoegsel staties) moet in `isize` pas.
///
///     - 'n (unstable) [extern type], dan is hierdie funksie altyd veilig om te skakel, maar kan panic of andersins die verkeerde waarde oplewer, aangesien die uitleg van die eksterne tipe nie bekend is nie.
///     Dit is dieselfde gedrag as [`align_of_val`] as u verwys na 'n tipe met 'n eksterne stert.
///     - anders is dit konserwatief nie toegelaat om hierdie funksie te noem nie.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // VEILIGHEID: die beller moet 'n geldige rou aanwyser verskaf
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Wys `true` as valwaarde van die tipe `T` saak maak.
///
/// Dit is 'n optimale wenk en kan konserwatief geïmplementeer word:
/// dit kan `true` teruggee vir soorte wat eintlik nie hoef te val nie.
/// As sodanig is die terugkeer van `true` altyd 'n geldige implementering van hierdie funksie.As hierdie funksie egter `false` terugbesorg, kan u seker wees dat die `T`-effek geen newe-effek het nie.
///
/// Lae vlak implementasies van dinge soos versamelings, wat hul data handmatig moet laat vaar, moet hierdie funksie gebruik om te verhoed dat dit onnodig probeer om al hul inhoud te laat val as dit vernietig word.
///
/// Dit maak miskien nie 'n verskil in release builds nie (waar 'n lus sonder newe-effekte maklik opgespoor en uitgeskakel kan word), maar is dikwels 'n groot oorwinning vir debug builds.
///
/// Let daarop dat [`drop_in_place`] reeds hierdie kontrole uitvoer, dus as u werklas tot 'n klein aantal [`drop_in_place`]-oproepe kan verminder, is dit onnodig.
/// Let veral daarop dat u 'n stuk [`drop_in_place`] kan gebruik, en dat dit 'n enkele behoefte-druppel-ondersoek vir al die waardes sal doen.
///
/// Soorte soos Vec is dus net `drop_in_place(&mut self[..])` sonder om `needs_drop` eksplisiet te gebruik.
/// Tipes soos [`HashMap`], daarenteen, moet waardes een vir een laat val en moet hierdie API gebruik.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Hier is 'n voorbeeld van hoe 'n versameling van `needs_drop` gebruik kan maak:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // laat val die data
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Wys die waarde van die tipe `T`, voorgestel deur die totaal-nul-byte-patroon.
///
/// Dit beteken dat die vullingbyte in `(u8, u16)` byvoorbeeld nie noodwendig nul is nie.
///
/// Daar is geen waarborg dat 'n byte-patroon van nul 'n geldige waarde van 'n tipe `T` verteenwoordig nie.
/// Die byte-patroon van nul is byvoorbeeld nie 'n geldige waarde vir verwysingstipes (`&T`, `&mut T`) en funksie-aanwysers nie.
/// Die gebruik van `zeroed` op sulke tipes veroorsaak onmiddellike [undefined behavior][ub] omdat [the Rust compiler assumes][inv] dat daar altyd 'n geldige waarde is in 'n veranderlike wat hy as geïnitialiseerd beskou.
///
///
/// Dit het dieselfde effek as [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Dit is soms nuttig vir FFI, maar moet gewoonlik vermy word.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Korrekte gebruik van hierdie funksie: initialisering van 'n heelgetal met nul.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Verkeerde* gebruik van hierdie funksie: om 'n verwysing met nul te initialiseer.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Ongedefinieerde gedrag!
/// let _y: fn() = unsafe { mem::zeroed() }; // En weer!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // VEILIGHEID: die beller moet waarborg dat 'n waarde van nul vir `T` geldig is.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Omseil die normale geheue-inisialiseringskontrole van Rust deur voor te gee dat dit 'n waarde van die tipe `T` produseer, terwyl jy glad niks doen nie.
///
/// **Hierdie funksie is verouderd.** Gebruik eerder [`MaybeUninit<T>`].
///
/// Die rede vir veroudering is dat die funksie basies nie korrek gebruik kan word nie: dit het dieselfde effek as [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Soos die [`assume_init` documentation][assume_init] verduidelik, word [the Rust compiler assumes][inv] dat waardes behoorlik geïnisialiseer is.
/// As gevolg hiervan, roep bv
/// `mem::uninitialized::<bool>()` veroorsaak onmiddellike ongedefinieerde gedrag vir die teruggee van 'n `bool` wat nie beslis `true` of `false` is nie.
/// Erger nog, waarlik ongeïnitialiseerde geheue soos wat hier terugbesorg word, is spesiaal omdat die samesteller weet dat dit nie 'n vaste waarde het nie.
/// Dit maak dit ongedefinieerde gedrag om nie-geïnitialiseerde data in 'n veranderlike te hê, selfs al het die veranderlike 'n heelgetal-tipe.
/// (Let op dat die reëls rondom nie-geïnitialiseerde heelgetalle nog nie afgehandel is nie, maar tot dusver is dit raadsaam om dit te vermy.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // VEILIGHEID: die beller moet waarborg dat 'n eenheidswaarde geldig is vir `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Ruil die waardes op twee veranderbare plekke om, sonder om een te deïtitialiseer.
///
/// * Raadpleeg [`take`] as u met 'n standaard-of dummy-waarde wil ruil.
/// * Raadpleeg [`replace`] as u met 'n geslaagde waarde wil ruil en die ou waarde wil teruggee.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // VEILIGHEID: die rou aanwysers is geskep uit veilige veranderlike verwysings wat voldoen aan al die
    // beperkings op `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Vervang `dest` met die standaardwaarde van `T`, en gee die vorige `dest`-waarde terug.
///
/// * Raadpleeg [`swap`] as u die waardes van twee veranderlikes wil vervang.
/// * Raadpleeg [`replace`] as u met 'n geslaagde waarde in plaas van die standaardwaarde wil vervang.
///
/// # Examples
///
/// 'N Eenvoudige voorbeeld:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` kan eienaarskap neem van 'n struktuurveld deur dit deur 'n "empty"-waarde te vervang.
/// Sonder `take` kan u probleme soos hierdie raakloop:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Let daarop dat `T` nie noodwendig [`Clone`] implementeer nie, dus kan hy nie eers `self.buf` kloon en weer instel nie.
/// Maar `take` kan gebruik word om die oorspronklike waarde van `self.buf` van `self` los te maak, sodat dit teruggestuur kan word:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Skuif `src` in die `dest` waarna verwys word, en gee die vorige `dest`-waarde terug.
///
/// Geen waarde val nie.
///
/// * Raadpleeg [`swap`] as u die waardes van twee veranderlikes wil vervang.
/// * Raadpleeg [`take`] as u 'n standaardwaarde wil vervang.
///
/// # Examples
///
/// 'N Eenvoudige voorbeeld:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` maak gebruik van 'n struktuurveld moontlik deur dit deur 'n ander waarde te vervang.
/// Sonder `replace` kan u probleme soos hierdie raakloop:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Let daarop dat `T` nie noodwendig [`Clone`] implementeer nie, dus kan ons nie eers `self.buf[i]` kloon om die skuif te vermy nie.
/// Maar `replace` kan gebruik word om die oorspronklike waarde van die indeks van `self` los te maak, sodat dit teruggestuur kan word:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // VEILIGHEID: Ons lees van `dest`, maar skryf `src` direk daarna in,
    // sodanig dat die ou waarde nie gedupliseer word nie.
    // Niks word laat val nie en niks hier kan panic nie.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Beskik oor 'n waarde.
///
/// Dit word gedoen deur die implementering van die argument van [`Drop`][drop] te noem.
///
/// Dit doen effektief niks vir tipes wat `Copy` implementeer nie, bv
/// integers.
/// Sulke waardes word gekopieër en _then_ na die funksie oorgeskuif, dus bly die waarde na hierdie funksie-oproep.
///
///
/// Hierdie funksie is nie towery nie;dit word letterlik gedefinieer as
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Omdat `_x` na die funksie oorgeskuif word, word dit outomaties laat val voordat die funksie terugkeer.
///
/// [drop]: Drop
///
/// # Examples
///
/// Basiese gebruik:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // laat val die vector eksplisiet
/// ```
///
/// Aangesien [`RefCell`] die leenreëls tydens looptyd toepas, kan `drop` 'n [`RefCell`]-lening vrystel:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // afstand doen van die veranderlike lening op hierdie slot
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Heelgetalle en ander soorte wat [`Copy`] implementeer, word nie beïnvloed deur `drop` nie.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // 'n eksemplaar van `x` word verskuif en laat val
/// drop(y); // 'n eksemplaar van `y` word verskuif en laat val
///
/// println!("x: {}, y: {}", x, y.0); // steeds beskikbaar
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Interpreteer `src` as die tipe `&U`, en lees dan `src` sonder om die vervat waarde te skuif.
///
/// Hierdie funksie neem onveilig aan dat die wyser `src` geldig is vir [`size_of::<U>`][size_of] bytes deur `&T` na `&U` te transmuteer en dan die `&U` te lees (behalwe dat dit op 'n manier gedoen word wat korrek is, selfs as `&U` strenger belyningsvereistes as `&T` stel).
/// Dit sal ook onveilig 'n kopie van die vervat waarde skep in plaas daarvan om uit `src` te skuif.
///
/// Dit is nie 'n kompilasietydfout as `T` en `U` verskillende groottes het nie, maar dit word sterk aangemoedig om slegs hierdie funksie aan te roep waar `T` en `U` dieselfde grootte het.Hierdie funksie aktiveer [undefined behavior][ub] as `U` groter is as `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Kopieer die data vanaf 'foo_array' en behandel dit as 'n 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Verander die gekopieerde data
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Die inhoud van 'foo_array' moes nie verander het nie
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // As U 'n hoër belyningsvereiste het, kan src nie geskik wees nie.
    if align_of::<U>() > align_of::<T>() {
        // VEILIGHEID: `src` is 'n verwysing wat verseker geldig is vir leeswerk.
        // Die oproeper moet waarborg dat die werklike transmutasie veilig is.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // VEILIGHEID: `src` is 'n verwysing wat verseker geldig is vir leeswerk.
        // Ons het net gekontroleer of `src as *const U` reg is.
        // Die oproeper moet waarborg dat die werklike transmutasie veilig is.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Ondeursigtige tipe wat die diskriminant van 'n enum voorstel.
///
/// Raadpleeg die [`discriminant`]-funksie in hierdie module vir meer inligting.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Hierdie trait-implementasies kan nie afgelei word nie omdat ons geen perke op T wil hê nie.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Wys 'n waarde wat uniek is om die enum-variant in `v` te identifiseer.
///
/// As `T` nie 'n enum is nie, sal die oproep van hierdie funksie nie lei tot ongedefinieerde gedrag nie, maar die terugkeerwaarde is nie gespesifiseer nie.
///
///
/// # Stability
///
/// Die diskriminant van 'n enum-variant kan verander as die definisie van enum verander.
/// 'N Diskriminant van een of ander variant sal nie tussen die samestellings met dieselfde samesteller verander nie.
///
/// # Examples
///
/// Dit kan gebruik word om enums wat data dra te vergelyk, terwyl die werklike data buite rekening gelaat word:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Wys die aantal variante in die enum tipe `T`.
///
/// As `T` nie 'n enum is nie, sal die oproep van hierdie funksie nie lei tot ongedefinieerde gedrag nie, maar die terugkeerwaarde is nie gespesifiseer nie.
/// Net so, as `T` 'n enum met meer variante as `usize::MAX` is, is die terugkeerwaarde nie gespesifiseer nie.
/// Onbewoonde variante sal getel word.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}