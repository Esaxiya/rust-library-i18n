use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// 'N Soort omhulsel om nie-geïnitialiseerde gevalle van `T` te konstrueer.
///
/// # Initialisering onveranderlik
///
/// Die samesteller neem in die algemeen aan dat 'n veranderlike behoorlik geïnisialiseer word volgens die vereistes van die tipe veranderlike.'N Veranderlike van die verwysingstipe moet byvoorbeeld in lyn en nie-NULL wees.
/// Dit is 'n invariant wat *altyd* gehandhaaf moet word, selfs in 'n onveilige kode.
/// As gevolg hiervan veroorsaak nulinitialisering van 'n veranderlike van die verwysingstipe oombliklike [undefined behavior][ub], ongeag of die verwysing ooit gewoond raak om toegang tot geheue te kry:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // ongedefinieerde gedrag!⚠️
/// // Die ekwivalente kode met `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // ongedefinieerde gedrag!⚠️
/// ```
///
/// Dit word deur die samesteller benut vir verskillende optimalisasies, soos om looptydkontroles uit te wis en die `enum`-uitleg te optimaliseer.
///
/// Net so kan geheue wat nie geïnisialiseer is nie, enige inhoud hê, terwyl 'n `bool` altyd `true` of `false` moet wees.Die skep van 'n ongeïnitialiseerde `bool` is dus ongedefinieerde gedrag:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // ongedefinieerde gedrag!⚠️
/// // Die ekwivalente kode met `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // ongedefinieerde gedrag!⚠️
/// ```
///
/// Boonop is ongeïnitialiseerde geheue spesiaal omdat dit nie 'n vaste waarde het nie ("fixed" wat "it won't change without being written to" beteken).As u dieselfde onge-geïnitialiseerde greep meermale lees, kan dit verskillende resultate lewer.
/// Dit maak dit ongedefinieerde gedrag om nie-geïnitialiseerde data in 'n veranderlike te hê, selfs as die veranderlike 'n heelgetal het, wat andersins *vaste* bispatroon kan bevat:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // ongedefinieerde gedrag!⚠️
/// // Die ekwivalente kode met `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // ongedefinieerde gedrag!⚠️
/// ```
/// (Let op dat die reëls rondom nie-geïnitialiseerde heelgetalle nog nie afgehandel is nie, maar tot dusver is dit raadsaam om dit te vermy.)
///
/// Onthou boonop dat die meeste soorte addisionele invariërs het, behalwe dat dit as geïnitialiseerd op die tipe vlak beskou word.
/// 'N [`Vec<T>`]-geïnisialiseerde [`Vec<T>`] word byvoorbeeld as geïnitialiseerd beskou (onder die huidige implementering; dit is nie 'n stabiele waarborg nie), want die enigste vereiste wat die samesteller daarvan weet, is dat die datawyser nie-nul moet wees.
/// Die skep van so 'n `Vec<T>` veroorsaak nie *onmiddellike* ongedefinieerde gedrag nie, maar sal ongedefinieerde gedrag veroorsaak met die veiligste operasies (insluitend om dit te laat val).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` dien om onveilige kode in staat te stel om nie-geïnisialiseerde data te hanteer.
/// Dit is 'n sein aan die samesteller wat aandui dat die gegewens hier moontlik nie * geïnisialiseer sal word nie:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Skep 'n eksplisiet nie-geïnitialiseerde verwysing.
/// // Die samesteller weet dat data binne 'n `MaybeUninit<T>` ongeldig kan wees, en dit is dus nie UB nie:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Stel dit op 'n geldige waarde.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Onttrek die geïnisialiseerde data-dit is slegs toegelaat *nadat*`x` behoorlik geïnisialiseer is!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Die samesteller weet dan dat hy geen verkeerde aannames of optimerings op hierdie kode moet maak nie.
///
/// U kan aan `MaybeUninit<T>` dink dat dit 'n bietjie soos `Option<T>` is, maar sonder dat u die looptyd dopgehou het en sonder enige van die veiligheidskontroles.
///
/// ## out-pointers
///
/// U kan `MaybeUninit<T>` gebruik om "out-pointers" te implementeer: in plaas daarvan om data van 'n funksie terug te stuur, stuur dit 'n wyser na een of ander (uninitialized)-geheue om die resultaat in te bring.
/// Dit kan handig wees as dit belangrik is vir die oproeper om te beheer hoe die geheue waarin die resultaat gestoor word, toegeken word, en u onnodige bewegings wil vermy.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` laat die ou inhoud nie val nie, wat belangrik is.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Nou weet ons dat `v` geïnisialiseer is!Dit sorg ook dat die vector behoorlik laat val.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Initialiseer 'n skikking element-vir-element
///
/// `MaybeUninit<T>` kan gebruik word om 'n groot skikking element-vir-element te inisieer:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Skep 'n ongeïnitialiseerde skikking van `MaybeUninit`.
///     // Die `assume_init` is veilig, want die tipe wat ons beweer dat ons hier geïnisialiseer het, is 'n klomp `MaybeUninit`s wat nie geïnisialiseer is nie.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Om 'n `MaybeUninit` te laat val, doen niks.
///     // Die gebruik van rou wysertoewysing in plaas van `ptr::write` veroorsaak dus nie dat die ou ongeïnisialiseerde waarde gedaal word nie.
/////
///     // Ook as daar 'n panic tydens hierdie lus is, het ons 'n geheue-lek, maar daar is geen probleem met geheueveiligheid nie.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Alles is geïnisialiseer.
///     // Verander die skikking na die geïnitialiseerde tipe.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// U kan ook werk met gedeeltelik geïnisialiseerde skikkings, wat gevind kan word in lae-vlak datastrukture.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Skep 'n ongeïnitialiseerde skikking van `MaybeUninit`.
/// // Die `assume_init` is veilig, want die tipe wat ons beweer dat ons hier geïnisialiseer het, is 'n klomp `MaybeUninit`s wat nie geïnisialiseer is nie.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Tel die aantal elemente wat ons toegeken het.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Laat val as ons dit toegeken het vir elke item in die skikking.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Inisialisering van 'n struktuur veld-vir-veld
///
/// U kan `MaybeUninit<T>` en die [`std::ptr::addr_of_mut`]-makro gebruik om stukke veld vir veld te initialiseer:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Initialiseer die `name`-veld
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Initialiseer die `list`-veld As hier 'n panic is, lek die `String` in die `name`-veld.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Al die velde is geïnisialiseer, daarom bel ons `assume_init` om 'n geïnitialiseerde Foo te kry.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` is gewaarborg dat dit dieselfde grootte, belyning en ABI het as `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Onthou egter dat 'n tipe *wat*'n `MaybeUninit<T>` bevat nie noodwendig dieselfde uitleg is nie;Rust waarborg in die algemeen nie dat die velde van 'n `Foo<T>` dieselfde volgorde het as 'n `Foo<U>` nie, selfs al het `T` en `U` dieselfde grootte en belyning.
///
/// Verder omdat enige bitwaarde geldig is vir 'n `MaybeUninit<T>`, kan die samesteller nie non-zero/niche-filling-optimalisasies toepas nie, wat moontlik 'n groter grootte tot gevolg het:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// As `T` FFI-veilig is, is `MaybeUninit<T>` ook so.
///
/// Terwyl `MaybeUninit` `#[repr(transparent)]` is (wat aandui dat dit dieselfde grootte, belyning en ABI as `T` waarborg), verander dit geen van die vorige voorbehoude nie.
/// `Option<T>` en `Option<MaybeUninit<T>>` kan nog steeds verskillende groottes hê, en tipes wat 'n veld van die tipe `T` bevat, kan anders uitgelê (en grootgemaak word) as wanneer die veld `MaybeUninit<T>` was.
/// `MaybeUninit` is 'n vakbondtipe en `#[repr(transparent)]` op vakbonde is onstabiel (sien [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Met verloop van tyd kan die presiese waarborge van `#[repr(transparent)]` op vakbonde ontwikkel, en `MaybeUninit` mag `#[repr(transparent)]` bly of nie.
/// Dit gesê, `MaybeUninit<T>` sal *altyd* waarborg dat dit dieselfde grootte, belyning en ABI het as `T`;dit is net so dat die manier waarop `MaybeUninit` die waarborg implementeer, kan ontwikkel.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang item sodat ons ander soorte daarin kan draai.Dit is nuttig vir kragopwekkers.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // As ons nie `T::clone()` skakel nie, kan ons nie weet of ons genoeg daarvoor geïnisialiseer is nie.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Skep 'n nuwe `MaybeUninit<T>` wat geïnitialiseer is met die gegewe waarde.
    /// Dit is veilig om [`assume_init`] op die terugkeerwaarde van hierdie funksie te skakel.
    ///
    /// Let daarop dat die val van 'n `MaybeUninit<T>` nooit 'T' se drukkode sal noem nie.
    /// U moet seker maak dat `T` laat vaar as dit geïnisialiseer word.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Skep 'n nuwe `MaybeUninit<T>` in 'n ongeïnitialiseerde toestand.
    ///
    /// Let daarop dat die val van 'n `MaybeUninit<T>` nooit 'T' se drukkode sal noem nie.
    /// U moet seker maak dat `T` laat vaar as dit geïnisialiseer word.
    ///
    /// Kyk na die [type-level documentation][MaybeUninit] vir enkele voorbeelde.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Skep 'n nuwe reeks `MaybeUninit<T>`-items in 'n ongeïnisialiseerde toestand.
    ///
    /// Note: in 'n weergawe future Rust kan hierdie metode onnodig word as letterkundige sintaksis van [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) toegelaat word.
    ///
    /// Die onderstaande voorbeeld kan dan `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` gebruik.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Wys 'n (moontlik kleiner) stukkie data wat werklik gelees is
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // VEILIGHEID: 'n Nie-geïnitialiseerde `[MaybeUninit<_>; LEN]` is geldig.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Skep 'n nuwe `MaybeUninit<T>` in 'n ongeïnitialiseerde toestand, met die geheue gevul met `0` bytes.Dit hang van `T` af of dit alreeds 'n behoorlike inisialisering maak.
    ///
    /// `MaybeUninit<usize>::zeroed()` is byvoorbeeld geïnisialiseer, maar `MaybeUninit<&'static i32>::zeroed()` is nie omdat verwysings nie nul mag wees nie.
    ///
    /// Let daarop dat die val van 'n `MaybeUninit<T>` nooit 'T' se drukkode sal noem nie.
    /// U moet seker maak dat `T` laat vaar as dit geïnisialiseer word.
    ///
    /// # Example
    ///
    /// Korrekte gebruik van hierdie funksie: om 'n struktuur met nul te initialiseer, waar alle velde van die struktuur die bitpatroon 0 as 'n geldige waarde kan hou.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Verkeerde* gebruik van hierdie funksie: roep `x.zeroed().assume_init()` wanneer `0` nie 'n geldige bitpatroon vir die tipe is nie:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Binne 'n paar skep ons 'n `NotZero` wat nie 'n geldige diskriminant het nie.
    /// // Dit is ongedefinieerde gedrag.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // VEILIGHEID: `u.as_mut_ptr()` wys op die geheue.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Stel die waarde van die `MaybeUninit<T>` in.
    /// Dit skryf enige vorige waarde oor sonder om dit te laat val, dus wees versigtig om dit nie twee keer te gebruik nie, tensy u die vernietiger wil laat loop.
    ///
    /// Vir u gemak gee dit ook 'n veranderlike verwysing na die (nou veilig geïnitialiseerde) inhoud van `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // VEILIGHEID: Ons het hierdie waarde pas geïnisialiseer.
        unsafe { self.assume_init_mut() }
    }

    /// Kry 'n wyser na die vervat waarde.
    /// Lees van hierdie aanwyser of omskep dit in 'n verwysing is ongedefinieerde gedrag, tensy die `MaybeUninit<T>` geïnisialiseer word.
    /// Om na die geheue te skryf waarop hierdie wyser (non-transitively) wys, is ongedefinieerde gedrag (behalwe in 'n `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Korrekte gebruik van hierdie metode:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Skep 'n verwysing in die `MaybeUninit<T>`.Dit is goed, want ons het dit geïnisialiseer.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Verkeerde* gebruik van hierdie metode:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Ons het 'n verwysing na 'n ongeïnitialiseerde vector!Dit is ongedefinieerde gedrag.⚠️
    /// ```
    ///
    /// (Let op dat die reëls rondom verwysings na ongeïnisialiseerde data nog nie afgehandel is nie, maar dit is tot dusverreeds aan te beveel om dit te vermy.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` en `ManuallyDrop` is albei `repr(transparent)`, sodat ons die wyser kan gooi.
        self as *const _ as *const T
    }

    /// Kry 'n veranderlike wyser na die vervat waarde.
    /// Lees van hierdie aanwyser of omskep dit in 'n verwysing is ongedefinieerde gedrag, tensy die `MaybeUninit<T>` geïnisialiseer word.
    ///
    /// # Examples
    ///
    /// Korrekte gebruik van hierdie metode:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Skep 'n verwysing in die `MaybeUninit<Vec<u32>>`.
    /// // Dit is goed, want ons het dit geïnisialiseer.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Verkeerde* gebruik van hierdie metode:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Ons het 'n verwysing na 'n ongeïnitialiseerde vector!Dit is ongedefinieerde gedrag.⚠️
    /// ```
    ///
    /// (Let op dat die reëls rondom verwysings na ongeïnisialiseerde data nog nie afgehandel is nie, maar dit is tot dusverreeds aan te beveel om dit te vermy.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` en `ManuallyDrop` is albei `repr(transparent)`, sodat ons die wyser kan gooi.
        self as *mut _ as *mut T
    }

    /// Onttrek die waarde uit die `MaybeUninit<T>`-houer.Dit is 'n uitstekende manier om te verseker dat die data wegval, want die resulterende `T` is onderhewig aan die gewone valhantering.
    ///
    /// # Safety
    ///
    /// Dit is aan die beller om te waarborg dat die `MaybeUninit<T>` regtig in 'n geïnitialiseerde toestand is.Om dit te noem as die inhoud nog nie volledig geïnisialiseer is nie, veroorsaak onmiddellike ongedefinieerde gedrag.
    /// Die [type-level documentation][inv] bevat meer inligting oor hierdie initialiseringsvariant.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Onthou boonop dat die meeste soorte addisionele invariërs het, behalwe dat dit as geïnitialiseerd op die tipe vlak beskou word.
    /// 'N [`Vec<T>`]-geïnisialiseerde [`Vec<T>`] word byvoorbeeld as geïnitialiseerd beskou (onder die huidige implementering; dit is nie 'n stabiele waarborg nie), want die enigste vereiste wat die samesteller daarvan weet, is dat die datawyser nie-nul moet wees.
    ///
    /// Die skep van so 'n `Vec<T>` veroorsaak nie *onmiddellike* ongedefinieerde gedrag nie, maar sal ongedefinieerde gedrag veroorsaak met die veiligste operasies (insluitend om dit te laat val).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Korrekte gebruik van hierdie metode:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Verkeerde* gebruik van hierdie metode:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` is nog nie geïnisialiseer nie, dus het hierdie laaste reël ongedefinieerde gedrag veroorsaak.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // VEILIGHEID: die beller moet waarborg dat `self` geïnisialiseer word.
        // Dit beteken ook dat `self` 'n `value`-variant moet wees.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Lees die waarde van die `MaybeUninit<T>`-houer.Die resulterende `T` is onderhewig aan die gewone valhantering.
    ///
    /// Indien moontlik, is dit beter om [`assume_init`] te gebruik, wat voorkom dat die inhoud van die `MaybeUninit<T>` dupliseer word.
    ///
    /// # Safety
    ///
    /// Dit is aan die beller om te waarborg dat die `MaybeUninit<T>` regtig in 'n geïnitialiseerde toestand is.Om dit te noem as die inhoud nog nie volledig geïnisialiseer is nie, veroorsaak ongedefinieerde gedrag.
    /// Die [type-level documentation][inv] bevat meer inligting oor hierdie initialiseringsvariant.
    ///
    /// Daarbenewens laat dit 'n kopie van dieselfde data agter in die `MaybeUninit<T>`.
    /// Wanneer u meerdere kopieë van die data gebruik (deur `assume_init_read` meermale te bel, of eers `assume_init_read` en dan [`assume_init`] te bel), is dit u verantwoordelikheid om te verseker dat die data wel gedupliseer kan word.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Korrekte gebruik van hierdie metode:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` is `Copy`, so ons kan meermale lees.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Die duplisering van 'n `None`-waarde is goed, dus kan ons dit meermale lees.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Verkeerde* gebruik van hierdie metode:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Ons het nou twee eksemplare van dieselfde vector geskep, wat lei tot 'n dubbelvrye ⚠️ wanneer hulle albei laat val word!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // VEILIGHEID: die beller moet waarborg dat `self` geïnisialiseer word.
        // Lees van `self.as_ptr()` is veilig, aangesien `self` geïnisialiseer moet word.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Laat die ingeslote waarde op sy plek val.
    ///
    /// As u die `MaybeUninit` besit, kan u [`assume_init`] eerder gebruik.
    ///
    /// # Safety
    ///
    /// Dit is aan die beller om te waarborg dat die `MaybeUninit<T>` regtig in 'n geïnitialiseerde toestand is.Om dit te noem as die inhoud nog nie volledig geïnisialiseer is nie, veroorsaak ongedefinieerde gedrag.
    ///
    /// Boonop moet aan alle addisionele invariërs van die tipe `T` voldoen word, aangesien die `Drop`-implementering van `T` (of sy lede) hierop kan staatmaak.
    /// 'N [`Vec<T>`]-geïnisialiseerde [`Vec<T>`] word byvoorbeeld as geïnitialiseerd beskou (onder die huidige implementering; dit is nie 'n stabiele waarborg nie), want die enigste vereiste wat die samesteller daarvan weet, is dat die datawyser nie-nul moet wees.
    ///
    /// As u so 'n `Vec<T>` laat val, sal dit ongedefinieerde gedrag veroorsaak.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // VEILIGHEID: die beller moet waarborg dat `self` geïnisialiseer is en
        // voldoen aan alle inwoners van `T`.
        // As dit die geval is, is dit veilig om die waarde te laat val.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Kry 'n gedeelde verwysing na die vervat waarde.
    ///
    /// Dit kan handig wees as ons toegang wil hê tot 'n `MaybeUninit` wat geïnitialiseer is, maar nie die `MaybeUninit` besit nie (wat die gebruik van `.assume_init()`) voorkom.
    ///
    /// # Safety
    ///
    /// Om dit te noem as die inhoud nog nie volledig geïnisialiseer is nie, veroorsaak ongedefinieerde gedrag: dit is aan die oproeper om te waarborg dat die `MaybeUninit<T>` regtig in 'n geïnitialiseerde toestand is.
    ///
    ///
    /// # Examples
    ///
    /// ### Korrekte gebruik van hierdie metode:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Initialiseer `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Noudat bekend is dat ons `MaybeUninit<_>` geïnisialiseer is, is dit goed om 'n gedeelde verwysing daarna te skep:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // VEILIGHEID: `x` is geïnisialiseer.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Verkeerde* gebruike van hierdie metode:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Ons het 'n verwysing na 'n ongeïnitialiseerde vector!Dit is ongedefinieerde gedrag.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Initialiseer die `MaybeUninit` met `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Verwysing na 'n ongeïnisialiseerde `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // VEILIGHEID: die beller moet waarborg dat `self` geïnisialiseer word.
        // Dit beteken ook dat `self` 'n `value`-variant moet wees.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Kry 'n veranderlike (unique) verwysing na die vervat waarde.
    ///
    /// Dit kan handig wees as ons toegang wil hê tot 'n `MaybeUninit` wat geïnitialiseer is, maar nie die `MaybeUninit` besit nie (wat die gebruik van `.assume_init()`) voorkom.
    ///
    /// # Safety
    ///
    /// Om dit te noem as die inhoud nog nie volledig geïnisialiseer is nie, veroorsaak ongedefinieerde gedrag: dit is aan die oproeper om te waarborg dat die `MaybeUninit<T>` regtig in 'n geïnitialiseerde toestand is.
    /// `.assume_init_mut()` kan byvoorbeeld nie gebruik word om 'n `MaybeUninit` te initialiseer nie.
    ///
    /// # Examples
    ///
    /// ### Korrekte gebruik van hierdie metode:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Inisialiseer *al* die grepe van die invoerbuffer.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Initialiseer `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Nou weet ons dat `buf` geïnisialiseer is, dus kan ons dit `.assume_init()`.
    /// // Die gebruik van `.assume_init()` kan egter 'n `memcpy` van die 2048 grepe veroorsaak.
    /// // Om te beweer dat ons buffer geïnisialiseer is sonder om dit te kopieer, gradeer ons die `&mut MaybeUninit<[u8; 2048]>` op na 'n `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // VEILIGHEID: `buf` is geïnisialiseer.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Nou kan ons `buf` as 'n normale sny gebruik:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Verkeerde* gebruike van hierdie metode:
    ///
    /// U kan nie `.assume_init_mut()` gebruik om 'n waarde te initialiseer nie:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Ons het 'n (mutable)-verwysing na 'n ongeïnitialiseerde `bool` geskep!
    ///     // Dit is ongedefinieerde gedrag.⚠️
    /// }
    /// ```
    ///
    /// U kan byvoorbeeld nie [`Read`] in 'n nie-geïnitialiseerde buffer:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) verwysing na ongeïnisialiseerde geheue!
    ///                             // Dit is ongedefinieerde gedrag.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// U kan ook nie direkte veldtoegang gebruik om veld-vir-veld-geleidelike inisialisering te doen nie:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) verwysing na ongeïnisialiseerde geheue!
    ///                  // Dit is ongedefinieerde gedrag.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) verwysing na ongeïnisialiseerde geheue!
    ///                  // Dit is ongedefinieerde gedrag.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Ons vertrou tans daarop dat die bogenoemde verkeerd is, dit wil sê, ons het verwysings na ongeïnisialiseerde data (bv. In `libcore/fmt/float.rs`).
    // Ons moet 'n finale besluit neem oor die reëls voordat ons dit stabiliseer.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // VEILIGHEID: die beller moet waarborg dat `self` geïnisialiseer word.
        // Dit beteken ook dat `self` 'n `value`-variant moet wees.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Onttrek die waardes uit 'n verskeidenheid `MaybeUninit`-houers.
    ///
    /// # Safety
    ///
    /// Dit is die oproeper om te waarborg dat alle elemente van die skikking in 'n geïnitialiseerde toestand is.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // VEILIGHEID: Nou veilig, aangesien ons alle elemente geïnisialiseer het
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Die oproeper waarborg dat alle elemente van die skikking geïnisialiseer word
        // * `MaybeUninit<T>` en T is gewaarborg om dieselfde uitleg te hê
        // * MaybeUnint val nie, dus is daar geen dubbele vryhede nie. Die omskakeling is dus veilig
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Neem aan dat al die elemente geïnisialiseer is, kry 'n deel daarvan.
    ///
    /// # Safety
    ///
    /// Dit is aan die beller om te waarborg dat die `MaybeUninit<T>`-elemente regtig in 'n geïnitialiseerde toestand is.
    ///
    /// Om dit te noem as die inhoud nog nie volledig geïnisialiseer is nie, veroorsaak ongedefinieerde gedrag.
    ///
    /// Sien [`assume_init_ref`] vir meer besonderhede en voorbeelde.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // VEILIGHEID: om 'n `*const [T]`-plak te gooi, is veilig, aangesien die oproeper dit waarborg
        // `slice` is geïnisialiseer, en 'MaybeUninit' het gewaarborg dat dit dieselfde uitleg as `T` het.
        // Die verkrygde wyser is geldig aangesien dit verwys na geheue wat deur `slice` besit word, wat 'n verwysing is en dus gewaarborg is om te lees.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Neem aan dat al die elemente geïnisialiseer is, kry 'n veranderlike sny daarby.
    ///
    /// # Safety
    ///
    /// Dit is aan die beller om te waarborg dat die `MaybeUninit<T>`-elemente regtig in 'n geïnitialiseerde toestand is.
    ///
    /// Om dit te noem as die inhoud nog nie volledig geïnisialiseer is nie, veroorsaak ongedefinieerde gedrag.
    ///
    /// Sien [`assume_init_mut`] vir meer besonderhede en voorbeelde.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // VEILIGHEID: soortgelyk aan veiligheidsaanwysings vir `slice_get_ref`, maar ons het 'n
        // veranderlike verwysing wat ook geldig is vir skryfwerk.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Kry 'n wyser na die eerste element van die skikking.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Kry 'n veranderlike wyser na die eerste element van die skikking.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Kopieer die elemente van `src` na `this`, en gee 'n veranderlike verwysing na die nou geïitaliseerde inhoud van `this`.
    ///
    /// Gebruik [`write_slice_cloned`] as `T` nie `Copy` implementeer nie
    ///
    /// Dit is soortgelyk aan [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Hierdie funksie sal panic as die twee snye verskillende lengtes het.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // VEILIGHEID: ons het pas al die elemente van len in die vrye kapasiteit gekopieer
    /// // die eerste src.len()-elemente van die vec is nou geldig.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // VEILIGHEID: &[T] en&[MaybeUninit<T>] het dieselfde uitleg
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // VEILIGHEID: Geldige elemente is pas in `this` gekopieer, sodat dit geïitaliseer word
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Kloneer die elemente van `src` tot `this`, en gee 'n veranderlike verwysing na die nou geïitaliseerde inhoud van `this`.
    /// Enige elemente wat reeds geïitaliseer is, sal nie verwyder word nie.
    ///
    /// Gebruik [`write_slice`] as `T` `Copy` implementeer
    ///
    /// Dit is soortgelyk aan [`slice::clone_from_slice`], maar laat nie bestaande elemente val nie.
    ///
    /// # Panics
    ///
    /// Hierdie funksie sal panic as die twee snye verskillende lengtes het, of as die implementering van `Clone` panics.
    ///
    /// As daar 'n panic is, sal die reeds gekloonde elemente laat val word.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // VEILIGHEID: ons het pas al die elemente van len in die vrye kapasiteit gekloon
    /// // die eerste src.len()-elemente van die vec is nou geldig.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // in teenstelling met copy_from_slice word dit nie clone_from_slice op die segment genoem nie, dit is omdat `MaybeUninit<T: Clone>` Clone nie implementeer nie.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // VEILIGHEID: hierdie rou sny bevat slegs geïnisialiseerde voorwerpe
                // dit is hoekom dit toegelaat word om dit te laat val.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Ons moet hulle eksplisiet op dieselfde lengte sny
        // vir die beheer van perke wat verwyder moet word, en die optimaliseerder sal memcpy genereer vir eenvoudige gevalle (byvoorbeeld T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // wag is nodig b/c panic kan tydens 'n kloon gebeur
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // VEILIGHEID: Geldige elemente is pas in `this` geskryf, sodat dit geïitaliseer word
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}