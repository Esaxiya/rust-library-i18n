//! Komponeerbare eksterne iterasie.
//!
//! As u 'n versameling van die een of ander aard het, en u moet die bewerking van die elemente van die versameling uitvoer, sal u 'iterators' vinnig raakloop.
//! Iterators word baie gebruik in die idiomatiese Rust-kode, dus dit is die moeite werd om vertroud te raak met hulle.
//!
//! Kom ons bespreek eers hoe hierdie module gestruktureer is, voordat ons meer verduidelik:
//!
//! # Organization
//!
//! Hierdie module is hoofsaaklik volgens tipe georganiseer:
//!
//! * [Traits] is die kerngedeelte: hierdie traits definieer watter soort iteratore bestaan en wat u daarmee kan doen.Die metodes van hierdie traits is die moeite werd om ekstra studietyd in te ruim.
//! * [Functions] bied 'n paar nuttige maniere om basiese herhalers te skep.
//! * [Structs] is dikwels die retourtipes van die verskillende metodes op die traits van hierdie module.U wil gewoonlik na die metode wat die `struct` skep, eerder as na die `struct` kyk.
//! Raadpleeg '[Implementing Iterator](#implementerings-iterator)' vir meer besonderhede.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Dis dit!Kom ons kyk na iteratore.
//!
//! # Iterator
//!
//! Die hart en siel van hierdie module is die [`Iterator`] trait.Die kern van [`Iterator`] lyk soos volg:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! 'N Iterator het 'n metode, [`next`], wat 'n [' Opsie '] gee as dit genoem word<Item>`.
//! [`next`] sal [`Some(Item)`] terugstuur solank daar elemente is, en sodra almal uitgeput is, sal `None` teruggestuur word om aan te dui dat die herhaling klaar is.
//! Individuele herhalers kan kies om die herhaling te hervat, en om [`next`] weer te bel, kan [`Some(Item)`] dan weer op 'n stadium begin terugbesorg (sien byvoorbeeld [`TryIter`]).
//!
//!
//! [Iterator`] se volledige definisie bevat ook 'n aantal ander metodes, maar dit is standaardmetodes, gebou bo-op [`next`], en u kry dit dus gratis.
//!
//! Iterators is ook komponeerbaar, en dit is algemeen om dit aanmekaar te ketting om meer ingewikkelde vorms van verwerking te doen.Raadpleeg die [Adapters](#adapters)-afdeling hieronder vir meer besonderhede.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Die drie vorme van iterasie
//!
//! Daar is drie algemene metodes wat iteratore uit 'n versameling kan skep:
//!
//! * `iter()`, wat meer as `&T` herhaal.
//! * `iter_mut()`, wat meer as `&mut T` herhaal.
//! * `into_iter()`, wat meer as `T` herhaal.
//!
//! Verskeie dinge in die standaardbiblioteek kan een of meer van die drie implementeer, waar toepaslik.
//!
//! # Implementering van Iterator
//!
//! Om u eie iterator te skep, behels twee stappe: om 'n `struct` te skep om die status van die iterator te behou en dan [`Iterator`] vir die `struct` te implementeer.
//! Dit is waarom daar soveel strukture in hierdie module is: daar is een vir elke iterator en iterator-adapter.
//!
//! Laat ons 'n iterator genaamd `Counter` maak wat van `1` tot `5` tel:
//!
//! ```
//! // Eerstens die struktuur:
//!
//! /// 'N Herhaling wat van een tot vyf tel
//! struct Counter {
//!     count: usize,
//! }
//!
//! // ons wil hê dat ons telling by een moet begin, dus laat ons 'n new()-metode byvoeg om te help.
//! // Dit is nie streng nodig nie, maar is gerieflik.
//! // Let daarop dat ons `count` op nul begin, ons sal sien waarom in `next()`'s-implementering hieronder.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Dan implementeer ons `Iterator` vir ons `Counter`:
//!
//! impl Iterator for Counter {
//!     // ons sal tel met die grootte
//!     type Item = usize;
//!
//!     // next() is die enigste vereiste metode
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Verhoog ons telling.Dit is waarom ons op nul begin het.
//!         self.count += 1;
//!
//!         // Kyk of ons klaar getel het of nie.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // En nou kan ons dit gebruik!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Om [`next`] so te noem, word herhalend.Rust het 'n konstruk wat [`next`] op u itator kan noem, totdat dit `None` bereik.Kom ons gaan daarna verder.
//!
//! Let ook daarop dat `Iterator` 'n standaard implementering bied van metodes soos `nth` en `fold` wat `next` intern skakel.
//! Dit is egter ook moontlik om 'n persoonlike implementering van metodes soos `nth` en `fold` te skryf as 'n iterator dit doeltreffender kan bereken sonder om `next` te bel.
//!
//! # `for` lusse en `IntoIterator`
//!
//! Rust se `for`-linsintaksis is eintlik suiker vir iteratore.Hier is 'n basiese voorbeeld van `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Hiermee word die getalle een tot vyf afgedruk, elk op hul eie lyn.Maar u sal hier iets sien: ons het nooit iets op ons vector gebel om 'n iterator te produseer nie.Wat gee?
//!
//! Daar is 'n trait in die standaardbiblioteek om iets in 'n itator te omskep: [`IntoIterator`].
//! Hierdie trait het een metode, [`into_iter`], wat die ding wat [`IntoIterator`] implementeer, omskakel in 'n iterator.
//! Kom ons kyk weer na die `for`-lus en wat die samesteller dit omskakel in:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust suiker dit in:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Eerstens noem ons `into_iter()` op die waarde.Dan pas ons op die iterator wat terugkeer, en bel [`next`] telkens totdat ons 'n `None` sien.
//! Op daardie stadium is ons `break` buite die loop, en ons is klaar met itereer.
//!
//! Hier is nog 'n subtiele stukkie: die standaardbiblioteek bevat 'n interessante implementering van [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Met ander woorde, almal [`Iterator`] implementeer [`IntoIterator`] deur net hulself terug te gee.Dit beteken twee dinge:
//!
//! 1. As u 'n [`Iterator`] skryf, kan u dit met 'n `for`-lus gebruik.
//! 2. As u 'n versameling skep, kan u die versameling met die `for`-lus gebruik as u [`IntoIterator`] daarvoor implementeer.
//!
//! # Iterasie deur verwysing
//!
//! Aangesien [`into_iter()`] `self` volgens waarde neem, verbruik dit die versameling deur 'n `for`-lus te gebruik om te herhaal oor 'n versameling.Dikwels wil u dit oor 'n versameling herhaal sonder om dit te verbruik.
//! Baie versamelings bied metodes wat herhalings bied oor verwysings, wat gewoonlik `iter()` en `iter_mut()` genoem word:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` word steeds deur hierdie funksie besit.
//! ```
//!
//! As 'n versamelingstipe `C` `iter()` bied, implementeer dit gewoonlik ook `IntoIterator` vir `&C`, met 'n implementering wat net `iter()` noem.
//! Net so implementeer 'n versameling `C` wat `iter_mut()` bied, `IntoIterator` vir `&mut C` oor die algemeen deur dit na `iter_mut()` te delegeer.Dit maak 'n gerieflike snelskrif moontlik:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // dieselfde as `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // dieselfde as `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Alhoewel baie versamelings `iter()` aanbied, bied nie almal `iter_mut()` nie.
//! Die mutasie van die sleutels van 'n [`HashSet<T>`] of [`HashMap<K, V>`] kan byvoorbeeld die versameling in 'n inkonsekwente toestand plaas as die sleutelhash verander, dus hierdie versamelings bied slegs `iter()` aan.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Funksies wat 'n [`Iterator`] neem en 'n ander [`Iterator`] terugstuur, word dikwels 'iterator-adapters' genoem, omdat dit 'n vorm van die 'adapter' is.
//! pattern'.
//!
//! Gewone iterator-adapters sluit in [`map`], [`take`] en [`filter`].
//! Raadpleeg hul dokumentasie vir meer inligting.
//!
//! As 'n iterator-adapter panics, sal die iterator in 'n ongespesifiseerde (maar geheueveilige) toestand wees.
//! Daar kan ook nie gewaarborg word dat hierdie toestand dieselfde is in alle weergawes van Rust nie, dus moet u vermy om op die presiese waardes te vertrou wat deur 'n iterator wat paniekbevange is, teruggestuur word.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iterators (en iterator [adapters](#adapters)) is *lui*. Dit beteken dat die skep van 'n iterator nie 'n hele klomp _do_ is nie. Niks gebeur regtig voordat u [`next`] bel nie.
//! Dit is soms 'n bron van verwarring as u 'n iterator slegs vir die newe-effekte daarvan skep.
//! Byvoorbeeld, die [`map`]-metode noem 'n afsluiting van elke element waaroor dit gaan:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Hierdeur word geen waardes gedruk nie, aangesien ons slegs 'n iterator gemaak het, eerder as om dit te gebruik.Die samesteller sal ons waarsku oor hierdie soort gedrag:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Die idiomatiese manier om 'n [`map`] vir sy newe-effekte te skryf, is om 'n `for`-lus te gebruik of die [`for_each`]-metode te noem:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! 'N Ander algemene manier om 'n iterator te evalueer, is om die [`collect`]-metode te gebruik om 'n nuwe versameling te vervaardig.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iterators hoef nie eindig te wees nie.'N Ooplopende reeks is byvoorbeeld 'n oneindige herhaling:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Dit is algemeen om die [`take`] iterator-adapter te gebruik om van 'n oneindige iterator 'n eindige te maak:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Hiermee word die nommers `0` tot `4` gedruk, elk op hul eie lyn.
//!
//! Onthou dat metodes op oneindige iteratore, selfs die waarvoor 'n resultaat wiskundig op 'n beperkte tyd bepaal kan word, moontlik nie sal eindig nie.
//! Spesifiek, metodes soos [`min`], wat in die algemeen die noodsaaklikheid is om elke element in die iterator te deurkruis, sal waarskynlik nie suksesvol terugkeer vir enige oneindige iteratore nie.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Ag nee!'N Oneindige lus!
//! // `ones.min()` veroorsaak 'n oneindige lus, so ons sal nie hierdie punt bereik nie!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;