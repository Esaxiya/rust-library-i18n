use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// Voorwerpe wat die begrip *opvolger* en *voorganger* bewerk.
///
/// Die *opvolger*-bewerking beweeg na waardes wat groter vergelyk.
/// Die *voorganger*-bewerking beweeg na waardes wat minder vergelyk.
///
/// # Safety
///
/// Hierdie trait is `unsafe` omdat die implementering daarvan korrek moet wees vir die veiligheid van `unsafe trait TrustedLen`-implementasies, en die resultate van die gebruik van hierdie trait kan andersins deur die `unsafe`-kode vertrou word om korrek te wees en die gelyste verpligtinge na te kom.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// Wys die aantal * opvolgerstappe wat nodig is om van `start` na `end` te beweeg.
    ///
    /// Wys `None` as die aantal stappe `usize` sou oorloop (of oneindig is, of as `end` nooit bereik sou word nie).
    ///
    ///
    /// # Invariants
    ///
    /// Vir enige `a`, `b` en `n`:
    ///
    /// * `steps_between(&a, &b) == Some(n)` as en net as `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` as en net as `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` slegs as `a <= b`
    ///   * Gevolg: `steps_between(&a, &b) == Some(0)` indien en slegs as `a == b`
    ///   * Let daarop dat `a <= b` _not_ impliseer `steps_between(&a, &b) != None`;
    ///     dit is die geval wanneer meer as `usize::MAX`-stappe benodig word om by `b` uit te kom
    /// * `steps_between(&a, &b) == None` as `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// Wys die waarde wat verkry sou word deur die *opvolger* van `self` `count` keer te neem.
    ///
    /// As dit die reeks waardes wat deur `Self` ondersteun word, sal oorloop, gee dit `None` terug.
    ///
    /// # Invariants
    ///
    /// Vir enige `a`, `n` en `m`:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// Vir enige `a`, `n` en `m` waar `n + m` nie oorloop nie:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// Vir enige `a` en `n`:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// Wys die waarde wat verkry sou word deur die *opvolger* van `self` `count` keer te neem.
    ///
    /// As dit die reeks waardes wat deur `Self` ondersteun word, sal oorstroom, kan hierdie funksie panic, verpak of versadig.
    ///
    /// Die voorgestelde gedrag is om panic te gebruik wanneer ontfoutings bewerings geaktiveer is, en om anders te draai of te versadig.
    ///
    /// Onveilige kode moet nie afhang van die korrektheid van gedrag na oorloop nie.
    ///
    /// # Invariants
    ///
    /// Vir enige `a`, `n` en `m`, waar geen oorloop plaasvind nie:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// Vir enige `a` en `n`, waar geen oorloop plaasvind nie:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// Wys die waarde wat verkry sou word deur die *opvolger* van `self` `count` keer te neem.
    ///
    /// # Safety
    ///
    /// Dit is ongedefinieerde gedrag vir hierdie bewerking om die reeks waardes wat deur `Self` ondersteun word, te oorskry.
    /// Gebruik `forward` of `forward_checked` in plaas daarvan as u nie kan waarborg dat dit nie sal oorloop nie.
    ///
    /// # Invariants
    ///
    /// Vir enige `a`:
    ///
    /// * as daar `b` bestaan soos `b > a`, is dit veilig om `Step::forward_unchecked(a, 1)` te skakel
    /// * as daar `b`, `n` bestaan soos `steps_between(&a, &b) == Some(n)`, is dit veilig om `Step::forward_unchecked(a, m)` vir enige `m <= n` te skakel.
    ///
    ///
    /// Vir enige `a` en `n`, waar geen oorloop plaasvind nie:
    ///
    /// * `Step::forward_unchecked(a, n)` is gelykstaande aan `Step::forward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// Wys die waarde wat verkry sou word deur die *voorganger* van `self` `count` keer te neem.
    ///
    /// As dit die reeks waardes wat deur `Self` ondersteun word, sal oorloop, gee dit `None` terug.
    ///
    /// # Invariants
    ///
    /// Vir enige `a`, `n` en `m`:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// Vir enige `a` en `n`:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// Wys die waarde wat verkry sou word deur die *voorganger* van `self` `count` keer te neem.
    ///
    /// As dit die reeks waardes wat deur `Self` ondersteun word, sal oorstroom, kan hierdie funksie panic, verpak of versadig.
    ///
    /// Die voorgestelde gedrag is om panic te gebruik wanneer ontfoutings bewerings geaktiveer is, en om anders te draai of te versadig.
    ///
    /// Onveilige kode moet nie afhang van die korrektheid van gedrag na oorloop nie.
    ///
    /// # Invariants
    ///
    /// Vir enige `a`, `n` en `m`, waar geen oorloop plaasvind nie:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// Vir enige `a` en `n`, waar geen oorloop plaasvind nie:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// Wys die waarde wat verkry sou word deur die *voorganger* van `self` `count` keer te neem.
    ///
    /// # Safety
    ///
    /// Dit is ongedefinieerde gedrag vir hierdie bewerking om die reeks waardes wat deur `Self` ondersteun word, te oorskry.
    /// As u nie kan waarborg dat dit nie oorloop nie, gebruik dan `backward` of `backward_checked`.
    ///
    /// # Invariants
    ///
    /// Vir enige `a`:
    ///
    /// * as daar `b` bestaan soos `b < a`, is dit veilig om `Step::backward_unchecked(a, 1)` te skakel
    /// * as daar `b`, `n` bestaan soos `steps_between(&b, &a) == Some(n)`, is dit veilig om `Step::backward_unchecked(a, m)` vir enige `m <= n` te skakel.
    ///
    ///
    /// Vir enige `a` en `n`, waar geen oorloop plaasvind nie:
    ///
    /// * `Step::backward_unchecked(a, n)` is gelykstaande aan `Step::backward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// Dit word steeds makro-gegenereer omdat die heelgetalle letterlik op verskillende tipes verander.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // VEILIGHEID: die beller moet waarborg dat `start + n` nie oorloop nie.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // VEILIGHEID: die beller moet waarborg dat `start - n` nie oorloop nie.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // Skakel 'n panic by oorloop in foutopsporings.
            // Dit behoort heeltemal te optimaliseer in die release builds.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // Doen wiskunde om dit toe te laat, bv `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // Skakel 'n panic by oorloop in foutopsporings.
            // Dit behoort heeltemal te optimaliseer in die release builds.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // Doen wiskunde om dit toe te laat, bv `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Dit berus op $u_narrower <=gebruiksgrootte
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // as n buite bereik is, is `unsigned_start + n` ook
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // as n buite bereik is, is `unsigned_start - n` ook
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Dit berus op $i_narrower <=gebruiksgrootte
                        //
                        // Gietwerk na isize brei die breedte uit, maar bewaar die teken.
                        // Gebruik wrapping_sub in die grootte van die grootte en giet dit om die grootte te gebruik om die verskil te bereken wat miskien nie binne die reeks isize is nie.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Verpakking hanteer gevalle soos `Step::forward(-120_i8, 200) == Some(80_i8)`, alhoewel 200 vir i8 buite bereik is.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // Toevoeging het oorgeloop
                            }
                        }
                        // As n buite bereik is, bv
                        // u8, dan is dit groter as die hele reeks vir i8 wyd is, sodat `any_i8 + n` noodwendig oor i8 loop.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Verpakking hanteer gevalle soos `Step::forward(-120_i8, 200) == Some(80_i8)`, alhoewel 200 vir i8 buite bereik is.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // Aftrekking oorgeloop
                            }
                        }
                        // As n buite bereik is, bv
                        // u8, dan is dit groter as die hele reeks vir i8 wyd is, sodat `any_i8 - n` noodwendig oor i8 loop.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // As die verskil te groot is vir bv
                            // i128, dit sal ook te groot wees vir gebruik met minder stukkies.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // VEILIGHEID: res is 'n geldige unicode-skalaar
            // (onder 0x110000 en nie in 0xD800..0xE000 nie)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // VEILIGHEID: res is 'n geldige unicode-skalaar
        // (onder 0x110000 en nie in 0xD800..0xE000 nie)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // VEILIGHEID: die beller moet waarborg dat dit nie oorloop nie
        // die reeks waardes vir 'n teken.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // VEILIGHEID: die beller moet waarborg dat dit nie oorloop nie
            // die reeks waardes vir 'n teken.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // VEILIGHEID: as gevolg van die vorige kontrak is dit gewaarborg
        // deur die oproeper 'n geldige char te wees.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // VEILIGHEID: die beller moet waarborg dat dit nie oorloop nie
        // die reeks waardes vir 'n teken.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // VEILIGHEID: die beller moet waarborg dat dit nie oorloop nie
            // die reeks waardes vir 'n teken.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // VEILIGHEID: as gevolg van die vorige kontrak is dit gewaarborg
        // deur die oproeper 'n geldige char te wees.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // VEILIGHEID: pas gekontroleerde voorwaarde
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // VEILIGHEID: pas gekontroleerde voorwaarde
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// Hierdie makro's genereer `ExactSizeIterator`-implemente vir verskillende soorte reeks.
//
// * `ExactSizeIterator::len` is nodig om altyd 'n presiese `usize` terug te gee, dus geen bereik kan langer as `usize::MAX` wees nie.
//
// * Vir heel tipes in `Range<_>` is dit die geval vir tipes smaller as of so wyd as `usize`.
//   Vir heelgetipes in `RangeInclusive<_>` is dit die geval vir tipes *streng smaller* as `usize` aangesien bv
//   `(0..=u64::MAX).len()` `u64::MAX + 1` sou wees.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // Dit is verkeerd volgens die bostaande redenasie, maar die verwydering daarvan sou 'n breekende verandering wees, aangesien dit in Rust 1.0.0 gestabiliseer is.
    // So bv
    // `(0..66_000_u32).len()` sal byvoorbeeld sonder foute of waarskuwings op 16-bis-platforms saamstel, maar voortgaan om 'n verkeerde resultaat te gee.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // Dit is verkeerd volgens die bostaande redenasie, maar die verwydering daarvan sou 'n breekende verandering wees, aangesien dit in Rust 1.26.0 gestabiliseer is.
    // So bv
    // `(0..=u16::MAX).len()` sal byvoorbeeld sonder foute of waarskuwings op 16-bis-platforms saamstel, maar voortgaan om 'n verkeerde resultaat te gee.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // VEILIGHEID: pas gekontroleerde voorwaarde
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // VEILIGHEID: pas gekontroleerde voorwaarde
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // VEILIGHEID: pas gekontroleerde voorwaarde
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // VEILIGHEID: pas gekontroleerde voorwaarde
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // VEILIGHEID: pas gekontroleerde voorwaarde
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // VEILIGHEID: pas gekontroleerde voorwaarde
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}