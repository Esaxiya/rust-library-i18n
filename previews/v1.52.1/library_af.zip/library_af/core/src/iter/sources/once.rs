use crate::iter::{FusedIterator, TrustedLen};

/// Skep 'n iterator wat presies een keer 'n element lewer.
///
/// Dit word gewoonlik gebruik om 'n enkele waarde aan te pas in 'n [`chain()`] van ander soorte iterasie.
/// Miskien het u 'n iterator wat byna alles dek, maar u het 'n ekstra spesiale saak nodig.
/// Miskien het u 'n funksie wat op iteratore werk, maar u hoef slegs een waarde te verwerk.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Basiese gebruik:
///
/// ```
/// use std::iter;
///
/// // een is die eensaamste nommer
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // net een, dit is al wat ons kry
/// assert_eq!(None, one.next());
/// ```
///
/// Ketting saam met 'n ander itator.
/// Laat ons sê dat ons wil herhaal oor elke lêer van die `.foo`-gids, maar ook 'n konfigurasielêer,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // ons moet van 'n iterator van DirEntry-s na 'n iterator van PathBufs omskakel, dus gebruik ons kaart
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // nou, ons herhaling net vir ons konfigurasielêer
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // ketting die twee iteratore saam in een groot iterator
/// let files = dirs.chain(config);
///
/// // dit gee ons al die lêers in .foo sowel as .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// 'N Iterator wat 'n element presies een keer lewer.
///
/// Hierdie `struct` is geskep deur die [`once()`]-funksie.Sien die dokumentasie daarvan vir meer inligting.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}