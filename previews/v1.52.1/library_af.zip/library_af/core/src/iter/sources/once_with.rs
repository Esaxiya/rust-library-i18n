use crate::iter::{FusedIterator, TrustedLen};

/// Skep 'n iterator wat presies een keer lui 'n waarde genereer deur die afgeslote sluiting aan te roep.
///
/// Dit word gewoonlik gebruik om 'n enkele waardegenerator aan te pas in 'n [`chain()`] van ander soorte iterasie.
/// Miskien het u 'n iterator wat byna alles dek, maar u het 'n ekstra spesiale saak nodig.
/// Miskien het u 'n funksie wat op iteratore werk, maar u hoef slegs een waarde te verwerk.
///
/// In teenstelling met [`once()`], sal hierdie funksie die waarde op aanvraag lui genereer.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Basiese gebruik:
///
/// ```
/// use std::iter;
///
/// // een is die eensaamste nommer
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // net een, dit is al wat ons kry
/// assert_eq!(None, one.next());
/// ```
///
/// Ketting saam met 'n ander itator.
/// Laat ons sê dat ons wil herhaal oor elke lêer van die `.foo`-gids, maar ook 'n konfigurasielêer,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // ons moet van 'n iterator van DirEntry-s na 'n iterator van PathBufs omskakel, dus gebruik ons kaart
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // nou, ons herhaling net vir ons konfigurasielêer
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // ketting die twee iteratore saam in een groot iterator
/// let files = dirs.chain(config);
///
/// // dit gee ons al die lêers in .foo sowel as .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// 'N Iterator wat 'n enkele element van die tipe `A` lewer deur die bygevoegde sluiting `F: FnOnce() -> A` toe te pas.
///
///
/// Hierdie `struct` is geskep deur die [`once_with()`]-funksie.
/// Sien die dokumentasie daarvan vir meer inligting.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}