use crate::iter::{FusedIterator, TrustedLen};

/// Skep 'n nuwe iterator wat eindeloos 'n enkele element herhaal.
///
/// Die `repeat()`-funksie herhaal 'n enkele waarde telkens weer.
///
/// Oneindige iteratore soos `repeat()` word dikwels met adapters soos [`Iterator::take()`] gebruik om dit eindig te maak.
///
/// As die elementtipe van die iterator wat u benodig nie `Clone` implementeer nie, of as u nie die herhaalde element in die geheue wil hou nie, kan u die [`repeat_with()`]-funksie gebruik.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Basiese gebruik:
///
/// ```
/// use std::iter;
///
/// // die nommer vier 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // ja, nog steeds vier
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Gaan eindig met [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // daardie laaste voorbeeld was te veel viere.Laat ons net vier viere hê.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... en nou is ons klaar
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// 'N Iterator wat 'n element eindeloos herhaal.
///
/// Hierdie `struct` is geskep deur die [`repeat()`]-funksie.Sien die dokumentasie daarvan vir meer inligting.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}