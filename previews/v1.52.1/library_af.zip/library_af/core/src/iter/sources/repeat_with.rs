use crate::iter::{FusedIterator, TrustedLen};

/// Skep 'n nuwe iterator wat elemente van die tipe `A` eindeloos herhaal deur die bygevoegde sluiting, die herhaler, toe te pas `F: FnMut() -> A`.
///
/// Die `repeat_with()`-funksie roep die herhaler telkens weer op.
///
/// Oneindige iteratore soos `repeat_with()` word dikwels met adapters soos [`Iterator::take()`] gebruik om dit eindig te maak.
///
/// As die elementtipe van die iterator wat u benodig, [`Clone`] implementeer en dit goed is om die bronelement in die geheue te hou, moet u eerder die [`repeat()`]-funksie gebruik.
///
///
/// 'N Itator wat deur `repeat_with()` vervaardig word, is nie 'n [`DoubleEndedIterator`] nie.
/// As u `repeat_with()` nodig het om 'n [`DoubleEndedIterator`] terug te gee, maak asseblief 'n GitHub-uitgawe wat u gebruiksgeval verduidelik.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Basiese gebruik:
///
/// ```
/// use std::iter;
///
/// // kom ons neem aan dat ons 'n sekere waarde het van 'n tipe wat nie `Clone` is nie, of wat nog nie in die geheue wil wees nie omdat dit duur is:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // 'n bepaalde waarde vir altyd:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Gebruik mutasie en gaan eindig:
///
/// ```rust
/// use std::iter;
///
/// // Van die nul tot die derde krag van twee:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... en nou is ons klaar
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// 'N Iterator wat elemente van die tipe `A` eindeloos herhaal deur die bygevoegde sluiting `F: FnMut() -> A` toe te pas.
///
///
/// Hierdie `struct` is geskep deur die [`repeat_with()`]-funksie.
/// Sien die dokumentasie daarvan vir meer inligting.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}