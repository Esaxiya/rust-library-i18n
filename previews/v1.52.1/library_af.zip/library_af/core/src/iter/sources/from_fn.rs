use crate::fmt;

/// Skep 'n nuwe iterator waar elke herhaling die verstrekte sluiting `F: FnMut() -> Option<T>` noem.
///
/// Hierdeur kan u 'n aangepaste iterator skep met enige gedrag sonder om die meer uitgebreide sintaksis te gebruik om 'n toegewyde tipe te skep en die [`Iterator`] trait daarvoor te implementeer.
///
/// Let op dat die `FromFn`-iterator nie aannames maak oor die gedrag van die sluiting nie, en daarom nie [`FusedIterator`] implementeer of [`Iterator::size_hint()`] van sy standaard `(0, None)` vervang nie.
///
///
/// Met die sluiting kan opnames en sy omgewing gebruik word om die toestand deur herhalings op te spoor.Afhangend van hoe die iterator gebruik word, moet u dalk die [`move`]-sleutelwoord op die sluiting spesifiseer.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Kom ons implementeer die teen-iterator van [module-level documentation] weer:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Verhoog ons telling.Dit is waarom ons op nul begin het.
///     count += 1;
///
///     // Kyk of ons klaar getel het of nie.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// 'N Iterator waar elke herhaling die verstrekte sluiting `F: FnMut() -> Option<T>` noem.
///
/// Hierdie `struct` is geskep deur die [`iter::from_fn()`]-funksie.
/// Sien die dokumentasie daarvan vir meer inligting.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}