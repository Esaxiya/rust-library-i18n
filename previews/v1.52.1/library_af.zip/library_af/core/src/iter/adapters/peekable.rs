use crate::iter::{adapters::SourceIter, FusedIterator, InPlaceIterable, TrustedLen};
use crate::ops::Try;

/// 'N Iterator met 'n `peek()` wat 'n opsionele verwysing na die volgende element gee.
///
///
/// Hierdie `struct` is geskep deur die [`peekable`]-metode op [`Iterator`].
/// Sien die dokumentasie daarvan vir meer inligting.
///
/// [`peekable`]: Iterator::peekable
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Peekable<I: Iterator> {
    iter: I,
    /// Onthou 'n gekykte waarde, selfs al was dit Geen.
    peeked: Option<Option<I::Item>>,
}

impl<I: Iterator> Peekable<I> {
    pub(in crate::iter) fn new(iter: I) -> Peekable<I> {
        Peekable { iter, peeked: None }
    }
}

// Peekable moet onthou as 'n Geen in die `.peek()`-metode gesien is.
// Dit verseker dat `.peek();.peek();` of `.peek();.next();` bevorder die onderliggende herhaling hoogstens een keer.
// Dit maak nie dat die iterator saamgesmelt word nie.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> Iterator for Peekable<I> {
    type Item = I::Item;

    #[inline]
    fn next(&mut self) -> Option<I::Item> {
        match self.peeked.take() {
            Some(v) => v,
            None => self.iter.next(),
        }
    }

    #[inline]
    #[rustc_inherit_overflow_checks]
    fn count(mut self) -> usize {
        match self.peeked.take() {
            Some(None) => 0,
            Some(Some(_)) => 1 + self.iter.count(),
            None => self.iter.count(),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        match self.peeked.take() {
            Some(None) => None,
            Some(v @ Some(_)) if n == 0 => v,
            Some(Some(_)) => self.iter.nth(n - 1),
            None => self.iter.nth(n),
        }
    }

    #[inline]
    fn last(mut self) -> Option<I::Item> {
        let peek_opt = match self.peeked.take() {
            Some(None) => return None,
            Some(v) => v,
            None => None,
        };
        self.iter.last().or(peek_opt)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let peek_len = match self.peeked {
            Some(None) => return (0, Some(0)),
            Some(Some(_)) => 1,
            None => 0,
        };
        let (lo, hi) = self.iter.size_hint();
        let lo = lo.saturating_add(peek_len);
        let hi = match hi {
            Some(x) => x.checked_add(peek_len),
            None => None,
        };
        (lo, hi)
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let acc = match self.peeked.take() {
            Some(None) => return try { init },
            Some(Some(v)) => f(init, v)?,
            None => init,
        };
        self.iter.try_fold(acc, f)
    }

    #[inline]
    fn fold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        let acc = match self.peeked {
            Some(None) => return init,
            Some(Some(v)) => fold(init, v),
            None => init,
        };
        self.iter.fold(acc, fold)
    }
}

#[stable(feature = "double_ended_peek_iterator", since = "1.38.0")]
impl<I> DoubleEndedIterator for Peekable<I>
where
    I: DoubleEndedIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        match self.peeked.as_mut() {
            Some(v @ Some(_)) => self.iter.next_back().or_else(|| v.take()),
            Some(None) => None,
            None => self.iter.next_back(),
        }
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        match self.peeked.take() {
            Some(None) => try { init },
            Some(Some(v)) => match self.iter.try_rfold(init, &mut f).into_result() {
                Ok(acc) => f(acc, v),
                Err(e) => {
                    self.peeked = Some(Some(v));
                    Try::from_error(e)
                }
            },
            None => self.iter.try_rfold(init, f),
        }
    }

    #[inline]
    fn rfold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        match self.peeked {
            Some(None) => init,
            Some(Some(v)) => {
                let acc = self.iter.rfold(init, &mut fold);
                fold(acc, v)
            }
            None => self.iter.rfold(init, fold),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator> ExactSizeIterator for Peekable<I> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator> FusedIterator for Peekable<I> {}

impl<I: Iterator> Peekable<I> {
    /// Wys 'n verwysing na die next()-waarde sonder om die iterator te bevorder.
    ///
    /// Net soos [`next`], as dit 'n waarde is, word dit in 'n `Some(T)` toegedraai.
    /// Maar as die herhaling verby is, word `None` teruggestuur.
    ///
    /// [`next`]: Iterator::next
    ///
    /// Omdat `peek()` 'n verwysing teruggee, en baie iteratore oor verwysings herhaal, kan daar 'n moontlike verwarrende situasie wees waar die terugkeerwaarde 'n dubbele verwysing is.
    /// U kan hierdie effek in die onderstaande voorbeelde sien.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() laat ons kyk na die future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // Die iterator gaan nie voort nie, selfs as ons meermale `peek`
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Nadat die iterator klaar is, is `peek()` ook so
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&mut self) -> Option<&I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_ref()
    }

    /// Wys 'n veranderlike verwysing na die next()-waarde sonder om die iterator te bevorder.
    ///
    /// Net soos [`next`], as dit 'n waarde is, word dit in 'n `Some(T)` toegedraai.
    /// Maar as die herhaling verby is, word `None` teruggestuur.
    ///
    /// Omdat `peek_mut()` 'n verwysing teruggee, en baie iteratore oor verwysings herhaal, kan daar 'n moontlike verwarrende situasie wees waar die terugkeerwaarde 'n dubbele verwysing is.
    /// U kan hierdie effek in die onderstaande voorbeelde sien.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// #![feature(peekable_peek_mut)]
    /// let mut iter = [1, 2, 3].iter().peekable();
    ///
    /// // Soos met `peek()`, kan ons in die future kyk sonder om die iterator te bevorder.
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // Loer in die itator en stel die waarde agter die veranderlike verwysing.
    /// if let Some(p) = iter.peek_mut() {
    ///     assert_eq!(*p, &2);
    ///     *p = &5;
    /// }
    ///
    /// // Die waarde wat ons insit, verskyn weer as die iterator voortgaan.
    /// assert_eq!(iter.collect::<Vec<_>>(), vec![&5, &3]);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "peekable_peek_mut", issue = "78302")]
    pub fn peek_mut(&mut self) -> Option<&mut I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_mut()
    }

    /// Verbruik en gee die volgende waarde van hierdie iterator terug as 'n voorwaarde waar is.
    /// As `func` `true` vir die volgende waarde van hierdie iterator oplewer, gebruik dit en stuur dit terug.
    /// Andersins, stuur `None` terug.
    /// # Examples
    /// Gebruik 'n getal as dit gelyk is aan 0.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // Die eerste item van die iterator is 0;verteer dit.
    /// assert_eq!(iter.next_if(|&x| x == 0), Some(0));
    /// // Die volgende item wat terugbesorg word, is nou 1, dus sal `consume` `false` terugbesorg.
    /// assert_eq!(iter.next_if(|&x| x == 0), None);
    /// // `next_if` stoor die waarde van die volgende item as dit nie gelyk is aan `expected` nie.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    ///
    /// Verbruik enige getal minder as 10.
    ///
    /// ```
    /// let mut iter = (1..20).peekable();
    /// // Verbruik alle getalle kleiner as 10
    /// while iter.next_if(|&x| x < 10).is_some() {}
    /// // Die volgende waarde is 10
    /// assert_eq!(iter.next(), Some(10));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if(&mut self, func: impl FnOnce(&I::Item) -> bool) -> Option<I::Item> {
        match self.next() {
            Some(matched) if func(&matched) => Some(matched),
            other => {
                // Aangesien ons `self.next()` gebel het, het ons `self.peeked` verbruik.
                assert!(self.peeked.is_none());
                self.peeked = Some(other);
                None
            }
        }
    }

    /// Gebruik en stuur die volgende item terug as dit gelyk is aan `expected`.
    /// # Example
    /// Gebruik 'n getal as dit gelyk is aan 0.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // Die eerste item van die iterator is 0;verteer dit.
    /// assert_eq!(iter.next_if_eq(&0), Some(0));
    /// // Die volgende item wat terugbesorg word, is nou 1, dus sal `consume` `false` terugbesorg.
    /// assert_eq!(iter.next_if_eq(&0), None);
    /// // `next_if_eq` stoor die waarde van die volgende item as dit nie gelyk is aan `expected` nie.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if_eq<T>(&mut self, expected: &T) -> Option<I::Item>
    where
        T: ?Sized,
        I::Item: PartialEq<T>,
    {
        self.next_if(|next| next == expected)
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I> TrustedLen for Peekable<I> where I: TrustedLen {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S: Iterator, I: Iterator> SourceIter for Peekable<I>
where
    I: SourceIter<Source = S>,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // VEILIGHEID: onveilige funksie-aanstuur na onveilige funksie met dieselfde vereistes
        unsafe { SourceIter::as_inner(&mut self.iter) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I: InPlaceIterable> InPlaceIterable for Peekable<I> {}