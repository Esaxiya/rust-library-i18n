use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Hierdie trait bied oorganklike toegang tot die bronstadium in 'n interator-adapterpypleiding onder die voorwaardes wat
/// * die iteratore-bron `S` self implementeer `SourceIter<Source = S>`
/// * daar is 'n delegerende implementering van hierdie trait vir elke adapter in die pyplyn tussen die bron en die pyplynverbruiker.
///
/// Wanneer die bron 'n iterator-struktuur is (gewoonlik `IntoIter` genoem), kan dit nuttig wees om [`FromIterator`]-implementasies te spesialiseer of om die oorblywende elemente te herstel nadat 'n iterator gedeeltelik uitgeput is.
///
///
/// Let daarop dat implementasies nie noodwendig toegang tot die binneste bron van 'n pypleiding hoef te bied nie.'N Statige tussenadapter kan 'n deel van die pypleiding gretig evalueer en die interne berging daarvan as bron blootstel.
///
/// Die trait is onveilig omdat implementeerders addisionele veiligheidseienskappe moet handhaaf.
/// Sien [`as_inner`] vir meer inligting.
///
/// # Examples
///
/// Haal 'n gedeeltelik verbruikte bron op:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// 'N Bronfase in 'n iteratorpyplyn.
    type Source: Iterator;

    /// Haal die bron van 'n iteratorpyplyn op.
    ///
    /// # Safety
    ///
    /// Implementasies moet dieselfde veranderlike verwysing vir hul leeftyd oplewer, tensy dit deur 'n oproeper vervang word.
    /// Bellers mag die verwysing eers vervang wanneer hulle iterasie gestaak het en die iterator-pyplyn laat val nadat die bron onttrek is.
    ///
    /// Dit beteken dat iterator-adapters daarop kan staatmaak dat die bron nie tydens iterasie verander nie, maar dat hulle nie daarop kan staatmaak in hul Drop-implementasies nie.
    ///
    /// Die implementering van hierdie metode beteken dat adapters afstand doen van privaat toegang tot hul bron en kan slegs staatmaak op waarborge wat gebaseer is op die tipe ontvanger.
    /// Die gebrek aan beperkte toegang vereis ook dat adapters die bron se openbare API moet handhaaf, selfs wanneer hulle toegang het tot die interne.
    ///
    /// Oproepers moet op hul beurt verwag dat die bron in enige toestand moet wees wat ooreenstem met die openbare API, aangesien adapters wat tussen die bron sit en dieselfde toegang het.
    /// In die besonder het 'n adapter meer elemente verbruik as wat streng nodig is.
    ///
    /// Die algemene doel van hierdie vereistes is om die verbruiker van 'n pypleiding te laat gebruik
    /// * alles wat in die bron oorbly nadat die herhaling gestaak is
    /// * die geheue wat onbenut geraak het deur die bevordering van 'n verterende iterator
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// 'N Iterator-adapter wat uitset lewer solank die onderliggende iterator `Result::Ok`-waardes lewer.
///
///
/// As 'n fout voorkom, stop die iterator en word die fout gestoor.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Verwerk die gegewe iterator asof dit 'n `T` in plaas van 'n `Result<T, _>` lewer.
/// Enige foute sal die innerlike iterator stop en die algehele resultaat sal 'n fout wees.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}