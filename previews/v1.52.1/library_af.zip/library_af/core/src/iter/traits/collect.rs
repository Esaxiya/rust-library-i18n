/// Omskakeling vanaf 'n [`Iterator`].
///
/// Deur `FromIterator` vir 'n tipe te implementeer, bepaal u hoe dit vanuit 'n iterator geskep sal word.
/// Dit is algemeen vir soorte wat 'n versameling van een of ander aard beskryf.
///
/// [`FromIterator::from_iter()`] word selde eksplisiet genoem, en word eerder gebruik deur die [`Iterator::collect()`]-metode.
///
/// Sien [`Iterator::collect()`]'s-dokumentasie vir meer voorbeelde.
///
/// Sien ook: [`IntoIterator`].
///
/// # Examples
///
/// Basiese gebruik:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Gebruik [`Iterator::collect()`] om implisiet `FromIterator` te gebruik:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Implementering van `FromIterator` vir u tipe:
///
/// ```
/// use std::iter::FromIterator;
///
/// // 'N Voorbeeldversameling, dit is net 'n omslag oor Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Kom ons gee 'n paar metodes sodat ons een kan skep en dinge daarby kan voeg.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // en ons implementeer FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Nou kan ons 'n nuwe iterator maak ...
/// let iter = (0..5).into_iter();
///
/// // ... en maak 'n MyCollection daarvan
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // versamel ook werke!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Skep 'n waarde van 'n iterator.
    ///
    /// Lees die [module-level documentation] vir meer inligting.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Omskakeling in 'n [`Iterator`].
///
/// Deur `IntoIterator` vir 'n tipe te implementeer, definieer u hoe dit na 'n iterator omgeskakel sal word.
/// Dit is algemeen vir soorte wat 'n versameling van een of ander aard beskryf.
///
/// Een voordeel van die implementering van `IntoIterator` is dat u tipe [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator) sal hê.
///
///
/// Sien ook: [`FromIterator`].
///
/// # Examples
///
/// Basiese gebruik:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Implementering van `IntoIterator` vir u tipe:
///
/// ```
/// // 'N Voorbeeldversameling, dit is net 'n omslag oor Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Kom ons gee 'n paar metodes sodat ons een kan skep en dinge daarby kan voeg.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // en ons sal IntoIterator implementeer
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Nou kan ons 'n nuwe versameling ...
/// let mut c = MyCollection::new();
///
/// // ... voeg 'n paar dinge daarby ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... en verander dit dan in 'n Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Dit is algemeen om `IntoIterator` as 'n trait bound te gebruik.Hierdeur kan die invoerversamelingstipe verander, solank dit nog steeds 'n iterator is.
/// Bykomende perke kan gespesifiseer word deur op te beperk
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Die tipe elemente waaroor dit herhaal word.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// In watter soort iterator verander ons dit?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Skep 'n iterator uit 'n waarde.
    ///
    /// Lees die [module-level documentation] vir meer inligting.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Brei 'n versameling uit met die inhoud van 'n iterator.
///
/// Iterators produseer 'n reeks waardes, en versamelings kan ook beskou word as 'n reeks waardes.
/// Die `Extend` trait oorbrug hierdie gaping, wat u toelaat om 'n versameling uit te brei deur die inhoud van die iterator in te sluit.
/// Wanneer u 'n versameling met 'n reeds bestaande sleutel uitbrei, word die inskrywing opgedateer, of, in die geval van versamelings wat meerdere inskrywings met gelyke sleutels toelaat, word die inskrywing ingevoeg.
///
///
/// # Examples
///
/// Basiese gebruik:
///
/// ```
/// // U kan 'n string met 'n paar karakters verleng:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Implementering van `Extend`:
///
/// ```
/// // 'N Voorbeeldversameling, dit is net 'n omslag oor Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Kom ons gee 'n paar metodes sodat ons een kan skep en dinge daarby kan voeg.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // Aangesien MyCollection 'n lys van i32's het, implementeer ons Extend vir i32
/// impl Extend<i32> for MyCollection {
///
///     // Dit is 'n bietjie eenvoudiger met die konkrete tipe handtekening: ons kan alles uitbrei wat omskep kan word in 'n Iterator wat ons i32's gee.
///     // Omdat ons i32's nodig het om in MyCollection te sit.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Die implementering is baie eenvoudig: loop deur die iterator en add() elke element vir onsself.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // kom ons brei ons versameling uit met nog drie nommers
/// c.extend(vec![1, 2, 3]);
///
/// // ons het hierdie elemente aan die einde bygevoeg
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Brei 'n versameling uit met die inhoud van 'n iterator.
    ///
    /// Aangesien dit die enigste vereiste metode vir hierdie trait is, bevat die [trait-level]-dokumente meer besonderhede.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// // U kan 'n string met 'n paar karakters verleng:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Brei 'n versameling uit met presies een element.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Bespreek kapasiteit in 'n versameling vir die gegewe aantal addisionele elemente.
    ///
    /// Die standaardimplementering doen niks.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}