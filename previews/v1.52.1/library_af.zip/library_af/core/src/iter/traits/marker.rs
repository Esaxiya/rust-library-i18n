/// 'N Iterator wat altyd `None` lewer as dit uitgeput is.
///
/// As u die volgende skakel na 'n versmelt iterator wat een keer `None` teruggestuur het, sal dit gewaarborg word om [`None`] weer terug te gee.
/// Hierdie trait moet geïmplementeer word deur alle iteratore wat so optree, omdat dit die optimalisering van [`Iterator::fuse()`] moontlik maak.
///
///
/// Note: Oor die algemeen moet u nie `FusedIterator` in algemene perke gebruik as u 'n versmelt iterator benodig nie.
/// In plaas daarvan moet u net [`Iterator::fuse()`] op die iterator skakel.
/// As die iterator reeds saamgesmelt is, is die addisionele [`Fuse`]-omhulsel 'n no-op sonder prestasieboete.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// 'N Iterator wat 'n akkurate lengte met behulp van size_hint rapporteer.
///
/// Die iterator rapporteer 'n groottewenk waar dit presies is (onderste grens is gelyk aan boonste grens), of die boonste grens is [`None`].
///
/// Die boonste grens moet slegs [`None`] wees as die werklike iteratuurlengte groter is as [`usize::MAX`].
/// In daardie geval moet die onderste grens [`usize::MAX`] wees, wat 'n [`Iterator::size_hint()`] van `(usize::MAX, None)` tot gevolg het.
///
/// Die iterator moet presies die aantal elemente wat dit gerapporteer het, opstel of afwyk voordat dit aan die einde kom.
///
/// # Safety
///
/// Hierdie trait moet slegs geïmplementeer word wanneer die kontrak gehandhaaf word.
/// Verbruikers van hierdie trait moet [`Iterator::size_hint()`]’s boonste grens inspekteer.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// 'N Herhaling wat ten minste een element uit die onderliggende [`SourceIter`] by die opbrengs van 'n item sal haal.
///
/// Noem enige metode wat die iterator bevorder, bv
/// [`next()`] of [`try_fold()`], waarborg dat vir elke stap minstens een waarde van die onderliggende bron van die iterator verwyder is en die resultaat van die iteratorketting op sy plek kan plaas, in die veronderstelling dat strukturele beperkings van die bron so 'n invoeging moontlik maak.
///
/// Met ander woorde, hierdie trait dui aan dat 'n iterator-pyplyn in plek kan word.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}