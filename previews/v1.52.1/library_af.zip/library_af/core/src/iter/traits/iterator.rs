// ignore-tidy-filelength Hierdie lêer bestaan feitlik uitsluitlik uit die definisie van `Iterator`.
// Ons kan dit nie in verskeie lêers verdeel nie.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// 'N Koppelvlak vir die hantering van iteratore.
///
/// Dit is die hoof iterator trait.
/// Raadpleeg die [module-level documentation] vir meer inligting oor die konsep van iteratore.
/// In die besonder wil u dalk weet hoe u [implement `Iterator`][impl] kan doen.
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Die tipe elemente waaroor dit herhaal word.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Bevorder die iterator en gee die volgende waarde terug.
    ///
    /// Wys [`None`] as die herhaling voltooi is.
    /// Individuele iterator-implementasies kan kies om iterasie te hervat, en om `next()` weer te bel, kan [`Some(Item)`] dan op 'n stadium weer begin terugbesorg.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // 'N Oproep na next() gee die volgende waarde terug ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... en dan None sodra dit verby is.
    /// assert_eq!(None, iter.next());
    ///
    /// // Meer oproepe stuur `None` al dan nie.Hier sal hulle altyd doen.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Wys die perke op die oorblywende lengte van die iterator.
    ///
    /// Spesifiek, `size_hint()` gee 'n tupel terug waar die eerste element die onderste grens is en die tweede element die boonste grens.
    ///
    /// Die tweede helfte van die tupel wat terugbesorg word, is 'n [`Opsie`] <`[`usize`]`> `.
    /// 'N [`None`] beteken hier dat daar geen bekende boonste grens is nie, of dat die boonste grens groter is as [`usize`].
    ///
    /// # Implementeringsnotas
    ///
    /// Dit word nie afgedwing dat 'n iteratore-implementering die verklaarde aantal elemente lewer nie.'N Buggy-iterator kan minder as die ondergrens of meer as die boonste grens van elemente lewer.
    ///
    /// `size_hint()` is hoofsaaklik bedoel om gebruik te word vir optimalisasies, soos om ruimte te bespreek vir die elemente van die iterator, maar moet nie vertrou word om bv. grense vir tjeks in onveilige kode uit te laat nie.
    /// 'N Verkeerde implementering van `size_hint()` mag nie tot skending van geheueveiligheid lei nie.
    ///
    /// Dit gesê, die implementering moet 'n korrekte skatting bied, want anders sou dit 'n oortreding van die trait se protokol wees.
    ///
    /// Die standaardimplementering gee terug '(0, `[` Geen`]`)` wat korrek is vir enige herhaling.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// 'N Meer komplekse voorbeeld:
    ///
    /// ```
    /// // Die ewe getalle van nul tot tien.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Ons kan van nul tot tien keer herhaal.
    /// // Die wete dat dit presies vyf is, sou nie moontlik wees sonder om filter() uit te voer nie.
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Kom ons voeg nog vyf getalle by met chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // nou word albei grense met vyf verhoog
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Terugkeer van `None` vir 'n boonste grens:
    ///
    /// ```
    /// // 'n oneindige iterator het geen boonste grens nie en die maksimum moontlike ondergrens
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Verbruik die iterator, tel die aantal iterasies en stuur dit terug.
    ///
    /// Met hierdie metode word [`next`] herhaaldelik gebel totdat [`None`] aangetref word, en word die aantal kere wat [`Some`] gesien het, terugbesorg.
    /// Let daarop dat [`next`] minstens een keer gebel moet word, selfs as die iterator geen elemente het nie.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Oorloopgedrag
    ///
    /// Die metode beskerm nie teen oorvloei nie, dus tel elemente van 'n iterator met meer as [`usize::MAX`]-elemente die verkeerde resultaat, of panics.
    ///
    /// As debug-bewerings geaktiveer is, word 'n panic gewaarborg.
    ///
    /// # Panics
    ///
    /// Hierdie funksie kan panic wees as die iterator meer as [`usize::MAX`] elemente het.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Verbruik die iterator en gee die laaste element terug.
    ///
    /// Met hierdie metode word die iterator geëvalueer totdat dit [`None`] terugbesorg.
    /// Terwyl u dit doen, hou dit die huidige element by.
    /// Nadat [`None`] teruggestuur is, sal `last()` dan die laaste element teruggee wat hy gesien het.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Bevorder die iterator met `n`-elemente.
    ///
    /// Hierdie metode sal `n`-elemente gretig oorslaan deur [`next`] tot `n` keer te bel totdat [`None`] aangetref word.
    ///
    /// `advance_by(n)` sal [`Ok(())`][Ok] terugstuur as die iterator suksesvol deur `n`-elemente vorder, of [`Err(k)`][Err] as [`None`] teëgekom word, waar `k` die aantal elemente is waarmee die iterator gevorder word voordat die elemente opraak (dws
    /// die lengte van die iterator).
    /// Let daarop dat `k` altyd minder as `n` is.
    ///
    /// As u `advance_by(0)` skakel, word geen elemente verbruik nie en word altyd [`Ok(())`][Ok] terugbesorg.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // slegs `&4` is oorgeslaan
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Wys die `n` element van die iterator.
    ///
    /// Soos die meeste indekseringsbewerkings, begin die telling vanaf nul, dus gee `nth(0)` die eerste waarde, `nth(1)` die tweede, ensovoorts.
    ///
    /// Let daarop dat alle voorafgaande elemente, sowel as die teruggekeerde element, van die iterator gebruik sal word.
    /// Dit beteken dat die voorafgaande elemente weggegooi word, en ook dat die oproep van `nth(0)` meerdere kere op dieselfde iterator verskillende elemente sal oplewer.
    ///
    ///
    /// `nth()` sal [`None`] teruggee as `n` groter is as of gelyk aan die lengte van die iterator.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Om die herhaling meermale te bel, herhaal die herhaling nie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Terugkeer van `None` as daar minder as `n + 1`-elemente is:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Skep 'n iterator wat op dieselfde punt begin, maar by elke herhaling met die gegewe bedrag trap.
    ///
    /// Opmerking 1: Die eerste element van die iterator sal altyd teruggestuur word, ongeag die gegewe stap.
    ///
    /// Nota 2: die tyd waarop geïgnoreerde elemente getrek word, is nie vasgestel nie.
    /// `StepBy` gedra hom soos die reeks `next(), nth(step-1), nth(step-1),…`, maar is ook vry om hom soos die reeks te gedra
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Die manier waarop gebruik word, kan om prestasie-redes vir sommige iteratore verander.
    /// Die tweede manier sal die itator vroeër bevorder en kan meer items verbruik.
    ///
    /// `advance_n_and_return_first` is die ekwivalent van:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Die metode sal panic as die gegewe stap `0` is.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Neem twee iterators en skep 'n nuwe iterator oor albei in volgorde.
    ///
    /// `chain()` sal 'n nuwe iterator terugstuur wat eers oor waardes van die eerste iterator en dan oor waardes van die tweede iterator sal herhaal.
    ///
    /// Met ander woorde, dit verbind twee iteratore in 'n ketting.🔗
    ///
    /// [`once`] word gewoonlik gebruik om 'n enkele waarde aan te pas in 'n ketting van ander soorte iterasie.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Aangesien die argument met `chain()` [`IntoIterator`] gebruik, kan ons alles wat in 'n [`Iterator`] omskep kan word, nie net 'n [`Iterator`] self gee nie.
    /// Snye (`&[T]`) implementeer byvoorbeeld [`IntoIterator`] en kan dus direk na `chain()` oorgedra word:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// As u met Windows API werk, kan u [`OsStr`] na `Vec<u16>` omskakel:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// Rits twee iteratore op in 'n enkele iterator van pare.
    ///
    /// `zip()` gee 'n nuwe iterator wat oor twee ander iteratore sal terugkeer, en gee 'n tupel terug waar die eerste element van die eerste iterator af kom, en die tweede element van die tweede iterator.
    ///
    ///
    /// Met ander woorde, dit rits twee iteratore saam, in 'n enkele een.
    ///
    /// As een van die iteratore [`None`] terugbesorg, sal [`next`] vanaf die ritssluitende iterator [`None`] terugstuur.
    /// As die eerste iterator [`None`] terugbesorg, sal `zip` kortsluit en word `next` nie op die tweede iterator aangeroep nie.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Aangesien die argument met `zip()` [`IntoIterator`] gebruik, kan ons alles wat in 'n [`Iterator`] omskep kan word, nie net 'n [`Iterator`] self gee nie.
    /// Snye (`&[T]`) implementeer byvoorbeeld [`IntoIterator`] en kan dus direk na `zip()` oorgedra word:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` word dikwels gebruik om 'n oneindige iterator na 'n eindige te rits.
    /// Dit werk omdat die eindige iterator uiteindelik [`None`] sal terugbesorg en die rits beëindig.Om met `(0..)` te rits, kan baie soos [`enumerate`] lyk:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Skep 'n nuwe iterator wat 'n kopie van `separator` tussen aangrensende items van die oorspronklike iterator plaas.
    ///
    /// As `separator` nie [`Clone`] implementeer nie of elke keer bereken moet word, gebruik [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Die eerste element van `a`.
    /// assert_eq!(a.next(), Some(&100)); // Die skeier.
    /// assert_eq!(a.next(), Some(&1));   // Die volgende element van `a`.
    /// assert_eq!(a.next(), Some(&100)); // Die skeier.
    /// assert_eq!(a.next(), Some(&2));   // Die laaste element van `a`.
    /// assert_eq!(a.next(), None);       // Die iterator is klaar.
    /// ```
    ///
    /// `intersperse` kan baie handig wees om by 'n itatore se items aan te sluit met 'n algemene element:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Skep 'n nuwe iterator wat 'n item wat deur `separator` gegenereer word tussen aangrensende items van die oorspronklike iterator plaas.
    ///
    /// Die sluiting sal presies een keer genoem word elke keer as 'n item tussen twee aangrensende items van die onderliggende iterator geplaas word;
    /// die sluiting word spesifiek nie genoem as die onderliggende iteratore minder as twee items lewer nie en nadat die laaste item opgelewer is.
    ///
    ///
    /// As die item van die iterator [`Clone`] implementeer, kan dit makliker wees om [`intersperse`] te gebruik.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Die eerste element van `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Die skeier.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Die volgende element van `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Die skeier.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Die laaste element van `v`.
    /// assert_eq!(it.next(), None);               // Die iterator is klaar.
    /// ```
    ///
    /// `intersperse_with` kan gebruik word in situasies waar die skeier bereken moet word:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Die sluiting leen veranderlik sy konteks om 'n item te genereer.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Maak 'n sluiting en skep 'n iterator wat die sluiting op elke element noem.
    ///
    /// `map()` transformeer een iterator in 'n ander, deur middel van sy argument:
    /// iets wat [`FnMut`] implementeer.Dit lewer 'n nuwe iterator wat hierdie sluiting noem op elke element van die oorspronklike iterator.
    ///
    /// As u goed in tipes dink, kan u `map()` so dink:
    /// As u 'n iterator het wat u elemente van die een of ander tipe `A` gee, en u 'n iterator van 'n ander tipe `B` wil hê, kan u `map()` gebruik deur 'n sluiting te slaag wat 'n `A` neem en 'n `B` teruggee.
    ///
    ///
    /// `map()` is konseptueel soortgelyk aan 'n [`for`]-lus.Aangesien `map()` lui is, word dit egter die beste gebruik as u reeds met ander iteratore werk.
    /// As u 'n soort lus vir 'n newe-effek doen, word dit as idiomaties beskou om [`for`] te gebruik as `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// As u 'n soort newe-effek doen, verkies [`for`] bo `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // moenie dit doen nie:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // dit sal nie eers uitgevoer word nie, want dit is lui.Rust sal u hieroor waarsku.
    ///
    /// // Gebruik eerder vir:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Noem 'n afsluiting van elke element van 'n iterator.
    ///
    /// Dit is gelykstaande aan die gebruik van 'n [`for`]-lus op die iterator, hoewel `break` en `continue` nie moontlik is vanaf 'n sluiting nie.
    /// Dit is oor die algemeen idiomatischer om 'n `for`-lus te gebruik, maar `for_each` is miskien meer leesbaar as items aan die einde van langer iteratorkettings verwerk word.
    ///
    /// In sommige gevalle kan `for_each` ook vinniger as 'n lus wees, omdat dit interne iterasie op adapters soos `Chain` sal gebruik.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Vir so 'n klein voorbeeld kan 'n `for`-lus skoner wees, maar `for_each` kan verkieslik wees om 'n funksionele styl te behou met langer iteratore:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Skep 'n iterator wat 'n sluiting gebruik om te bepaal of 'n element opgelewer moet word.
    ///
    /// Gegewe 'n element moet die sluiting `true` of `false` teruggee.Die teruggekeerde iterator lewer slegs die elemente waarvoor die sluiting waar is.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Omdat die sluiting wat aan `filter()` oorgedra word, verwys word en baie iteratore oor verwysings herhaal, lei dit tot 'n moontlik verwarrende situasie, waar die tipe sluiting 'n dubbele verwysing is:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // benodig twee * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Dit is algemeen om eerder die argument te gebruik om die argument te verwyder:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // beide en *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// of albei:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // twee &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// van hierdie lae.
    ///
    /// Let daarop dat `iter.filter(f).next()` gelykstaande is aan `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Skep 'n iterator wat beide filter en kaarte.
    ///
    /// Die teruggestuurde iterator lewer slegs die 'waarde' waarvoor die afgeslote sluiting `Some(value)` oplewer.
    ///
    /// `filter_map` kan gebruik word om kettings van [`filter`] en [`map`] bondiger te maak.
    /// Die onderstaande voorbeeld toon aan hoe 'n `map().filter().map()` verkort kan word tot 'n enkele oproep na `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Hier is dieselfde voorbeeld, maar met [`filter`] en [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Skep 'n iterator wat die huidige iterasie-telling sowel as die volgende waarde gee.
    ///
    /// Die iterator wat terugbesorg word, lewer pare `(i, val)`, waar `i` die huidige iterasie-indeks is en `val` die waarde is wat deur die iterator terugbesorg word.
    ///
    ///
    /// `enumerate()` hou sy telling as 'n [`usize`].
    /// As u op 'n ander getal wil tel, bied die [`zip`]-funksie soortgelyke funksies.
    ///
    /// # Oorloopgedrag
    ///
    /// Die metode kan nie teen oorstromings gewaak word nie, dus om meer as [`usize::MAX`]-elemente op te tel, hetsy die verkeerde resultaat of panics lewer.
    /// As debug-bewerings geaktiveer is, word 'n panic gewaarborg.
    ///
    /// # Panics
    ///
    /// Die teruggekeerde iterator sal moontlik panic wees as die indeks wat teruggestuur moet word 'n [`usize`] sal oorstroom.
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Skep 'n iterator wat [`peek`] kan gebruik om na die volgende element van die iterator te kyk sonder om dit te verbruik.
    ///
    /// Voeg 'n [`peek`]-metode by 'n iterator.Sien die dokumentasie daarvan vir meer inligting.
    ///
    /// Let daarop dat die onderliggende iterator nog gevorderd is wanneer [`peek`] vir die eerste keer geroep word: om die volgende element te herwin, word [`next`] op die onderliggende iterator geroep, vandaar enige newe-effekte (dws
    ///
    /// enigiets anders as om die volgende waarde te haal) van die [`next`]-metode, sal plaasvind.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() laat ons kyk na die future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // as ons verskeie kere peek() kan doen, sal die iterator nie verder gaan nie
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // nadat die iterator klaar is, is peek() ook
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Skep 'n iterator wat elemente ['oorslaan'] gebaseer op 'n predikaat.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` neem 'n afsluiting as argument.Dit sal hierdie afsluiting op elke element van die iterator noem en elemente ignoreer totdat dit `false` terugbesorg.
    ///
    /// Nadat `false` teruggestuur is, is die `skip_while()`'s-taak verby en die res van die elemente word opgelewer.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Aangesien die sluiting wat aan `skip_while()` oorgedra word verwys, en baie iteratore herhaal, verwys dit na 'n moontlike verwarrende situasie, waar die tipe sluitingsargument 'n dubbele verwysing is:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // benodig twee * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stop na 'n eerste `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // alhoewel dit onwaar sou gewees het, word skip_while() nie meer gebruik nie, aangesien ons reeds 'n vals gekry het
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Skep 'n iterator wat elemente op grond van 'n predikaat lewer.
    ///
    /// `take_while()` neem 'n afsluiting as argument.Dit sal hierdie sluiting op elke element van die iterator noem en opbrengste lewer terwyl dit `true` oplewer.
    ///
    /// Nadat `false` teruggestuur is, is die `take_while()`'s-taak verby en die res van die elemente word geïgnoreer.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Omdat die sluiting wat aan `take_while()` oorgedra word, verwys word en baie iteratore oor verwysings herhaal, lei dit tot 'n moontlik verwarrende situasie, waar die tipe sluiting 'n dubbele verwysing is:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // benodig twee * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stop na 'n eerste `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Ons het meer elemente wat minder as nul is, maar omdat ons al 'n vals het, word take_while() nie meer gebruik nie
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Omdat `take_while()` na die waarde moet kyk om te sien of dit opgeneem moet word of nie, sal verbruikende iterators sien dat dit verwyder word:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// Die `3` is nie meer daar nie, want dit is verbruik om te sien of die iterasie moet stop, maar is nie weer in die iterator geplaas nie.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Skep 'n iterator wat beide elemente op grond van 'n predikaat en kaarte lewer.
    ///
    /// `map_while()` neem 'n afsluiting as argument.
    /// Dit sal hierdie sluiting op elke element van die iterator noem en opbrengste lewer terwyl dit [`Some(_)`][`Some`] oplewer.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Hier is dieselfde voorbeeld, maar met [`take_while`] en [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stop na 'n eerste [`None`]:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Ons het meer elemente wat in u32 (4, 5) kan pas, maar `map_while` het `None` vir `-3` teruggestuur (aangesien die `predicate` `None` terugbesorg het) en `collect` stop by die eerste `None` wat teëgekom is.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Omdat `map_while()` na die waarde moet kyk om te sien of dit opgeneem moet word of nie, sal verbruikende iterators sien dat dit verwyder word:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// Die `-3` is nie meer daar nie, want dit is verbruik om te sien of die iterasie moet stop, maar is nie weer in die iterator geplaas nie.
    ///
    /// Let daarop dat hierdie iterator in teenstelling met [`take_while`]**nie** versmelt is nie.
    /// Daar word ook nie gespesifiseer wat hierdie herhaling teruggee nadat die eerste [`None`] teruggestuur is nie.
    /// Gebruik [`fuse`] as u versmelt iterator benodig.
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Skep 'n iterator wat die eerste `n`-elemente oorslaan.
    ///
    /// Nadat dit verteer is, word die res van die elemente opgelewer.
    /// In plaas daarvan om hierdie metode direk te oorheers, moet u die `nth`-metode vervang.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Skep 'n iterator wat sy eerste `n`-elemente lewer.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` word dikwels saam met 'n oneindige iterator gebruik om dit eindig te maak:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// As minder as `n`-elemente beskikbaar is, sal `take` homself beperk tot die grootte van die onderliggende iterator:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// 'N Iterator-adapter soortgelyk aan [`fold`] wat die interne toestand behou en 'n nuwe iterator produseer.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` neem twee argumente: 'n aanvanklike waarde wat die interne toestand saai, en 'n afsluiting met twee argumente, waarvan die eerste 'n veranderlike verwysing na die interne toestand is en die tweede 'n iteratore-element.
    ///
    /// Die sluiting kan aan die interne toestand toewys om die staat tussen herhalings te deel.
    ///
    /// By iterasie sal die sluiting op elke element van die iterator toegepas word en die opbrengwaarde van die sluiting, 'n [`Option`], word deur die iterator opgelewer.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // elke herhaling vermenigvuldig ons die toestand met die element
    ///     *state = *state * x;
    ///
    ///     // dan sal ons die ontkenning van die staat oplewer
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Skep 'n iterator wat soos kaart werk, maar die geneste struktuur plat maak.
    ///
    /// Die [`map`]-adapter is baie handig, maar slegs wanneer die sluitingsargument waardes lewer.
    /// As dit eerder 'n iterator vervaardig, is daar 'n ekstra laag indireksie.
    /// `flat_map()` sal hierdie ekstra laag op sy eie verwyder.
    ///
    /// U kan aan `flat_map(f)` dink as die semantiese ekwivalent van [`map`] ping, en dan ["plat"] soos in `map(f).flatten()`.
    ///
    /// 'N Ander manier van dink oor `flat_map()`: die sluiting van [`map`] gee een item vir elke element, en die `flat_map()`'s-sluiting gee 'n iterator vir elke element.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() gee 'n iterator terug
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Skep 'n iterator wat die geneste struktuur plat maak.
    ///
    /// Dit is handig as u 'n iterator van iteratore of 'n iterator het van dinge wat in iteratore verander kan word en u een vlak van indireksie wil verwyder.
    ///
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Kartering en dan platmaak:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() gee 'n iterator terug
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// U kan dit ook herskryf in terme van [`flat_map()`], wat in hierdie geval verkieslik is omdat dit die bedoeling duideliker oordra:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() gee 'n iterator terug
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Afplatting verwyder net een vlak van nes op 'n slag:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Hier sien ons dat `flatten()` nie 'n "deep"-vlak uitvoer nie.
    /// In plaas daarvan word slegs een vlak van nes verwyder.Dit wil sê, as u 'n driedimensionele skikking `flatten()` het, sal die resultaat tweedimensioneel en nie eendimensioneel wees nie.
    /// Om 'n eendimensionele struktuur te kry, moet u weer `flatten()` doen.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Skep 'n iterator wat eindig na die eerste [`None`].
    ///
    /// Nadat 'n iterator [`None`] terugbesorg het, kan future-oproepe [`Some(T)`] al dan nie weer oplewer nie.
    /// `fuse()` pas 'n iterator aan en verseker dat dit altyd vir altyd [`None`] sal teruggee nadat 'n [`None`] gegee is.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// // 'n herhaling wat wissel tussen Sommige en Geen
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // as dit gelyk is, Some(i32), anders Geen
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // ons kan sien dat ons iterator heen en weer gaan
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // as ons dit eers versmelt ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // dit sal altyd `None` na die eerste keer terugbesorg.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Doen iets met elke element van 'n iterator, en gee die waarde deur.
    ///
    /// Wanneer u iteratore gebruik, sal u verskeie daarvan dikwels aan mekaar vasmaak.
    /// As u aan so 'n kode werk, wil u dalk kyk wat op verskillende dele in die pyplyn gebeur.Om dit te doen, plaas 'n oproep na `inspect()`.
    ///
    /// Dit is meer algemeen dat `inspect()` as ontfoutingsinstrument gebruik word as in u finale kode, maar toepassings kan dit nuttig vind in sekere situasies wanneer foute moet aangeteken word voordat dit weggegooi word.
    ///
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // hierdie iteratore volgorde is kompleks.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // kom ons voeg 'n paar inspect()-oproepe by om te ondersoek wat gebeur
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Dit sal druk:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Logfoute voordat u dit weggooi:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Dit sal druk:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Leen 'n itator, eerder as om dit te verbruik.
    ///
    /// Dit is handig om die toepassing van iterator-adapters toe te laat terwyl u steeds die eienaarskap van die oorspronklike iterator behou.
    ///
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // as ons iter weer probeer gebruik, sal dit nie werk nie.
    /// // Die volgende reël gee 'fout': gebruik van verskuifde waarde: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // kom ons probeer dit weer
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // in plaas daarvan voeg ons 'n .by_ref() by
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // nou is dit net goed:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Omskep 'n iterator in 'n versameling.
    ///
    /// `collect()` kan enigiets herhaalbaar neem en dit in 'n relevante versameling verander.
    /// Dit is een van die kragtiger metodes in die standaardbiblioteek wat in verskillende kontekste gebruik word.
    ///
    /// Die mees basiese patroon waarin `collect()` gebruik word, is om een versameling in 'n ander te omskep.
    /// U neem 'n versameling, bel [`iter`] daarop, doen 'n klomp transformasies en dan `collect()` aan die einde.
    ///
    /// `collect()` kan ook gevalle van tipes skep wat nie tipiese versamelings is nie.
    /// 'N [`String`] kan byvoorbeeld gebou word uit [`char`] s en 'n iterator van [`Result<T, E>`][`Result`]-items kan in `Result<Collection<T>, E>` versamel word.
    ///
    /// Sien die voorbeelde hieronder vir meer inligting.
    ///
    /// Omdat `collect()` so algemeen is, kan dit probleme veroorsaak met tipe afleiding.
    /// As sodanig is `collect()` een van die min kere dat u die sintaksis met liefde bekend as die 'turbofish' sal sien: `::<>`.
    /// Dit help die afleidingsalgoritme om spesifiek te verstaan in watter versameling u probeer versamel.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Let daarop dat ons die `: Vec<i32>` aan die linkerkant nodig gehad het.Dit is omdat ons eerder in byvoorbeeld 'n [`VecDeque<T>`] kon versamel:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Gebruik die 'turbofish' in plaas van om `doubled` te annoteer:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Omdat `collect()` net omgee vir wat u versamel, kan u steeds 'n gedeeltelike wenk, `_`, gebruik met die turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Gebruik `collect()` om 'n [`String`] te maak:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// As u 'n lys met [`Resultaat<T, E>`][`Resultaat`] s, u kan `collect()` gebruik om te sien of een van hulle misluk het:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // gee ons die eerste fout
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // gee ons 'n lys antwoorde
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Gebruik 'n iterator en skep twee versamelings daaruit.
    ///
    /// Die predikaat wat aan `partition()` oorgedra word, kan `true` of `false` teruggee.
    /// `partition()` gee 'n paar terug, al die elemente waarvoor dit `true` teruggestuur het, en al die elemente waarvoor dit `false` terugbesorg het.
    ///
    ///
    /// Sien ook [`is_partitioned()`] en [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Rangskik die elemente van hierdie iterator *in plek* volgens die gegewe predikaat, sodat almal wat `true` teruggee, voorafgaan aan almal wat `false` terugstuur.
    ///
    /// Wys die aantal `true`-elemente wat gevind is.
    ///
    /// Die relatiewe volgorde van afgeskeide items word nie gehandhaaf nie.
    ///
    /// Sien ook [`is_partitioned()`] en [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Verdeling op die plek tussen ewe en kans
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: moet ons bekommerd wees oor die telling wat oorloop?Die enigste manier om meer as
        // `usize::MAX` veranderlike verwysings is met ZST's, wat nie nuttig is om te partisieer nie ...

        // Hierdie "factory"-funksies sluit om generiteit in `Self` te voorkom.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Vind die eerste `false` herhaaldelik en ruil dit met die laaste `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Kontroleer of die elemente van hierdie iterator volgens die gegewe predikaat verdeel is, sodat almal wat `true` teruggee, voorafgaan aan almal wat `false` terugstuur.
    ///
    ///
    /// Sien ook [`partition()`] en [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Óf alle items toets `true`, óf die eerste lid stop by `false`, en ons kyk of daar nie meer `true`-items is nie.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// 'N Iteratormetode wat 'n funksie toepas solank dit suksesvol terugkeer en 'n enkele finale waarde lewer.
    ///
    /// `try_fold()` neem twee argumente: 'n aanvanklike waarde, en 'n slot met twee argumente: 'n 'accumulator' en 'n element.
    /// Die sluiting keer óf suksesvol terug met die waarde wat die akkumulator vir die volgende iterasie moet hê, óf hy lewer mislukking op, met 'n foutwaarde wat onmiddellik (short-circuiting) weer na die oproeper oorgedra word.
    ///
    ///
    /// Die aanvanklike waarde is die waarde wat die akkumulator by die eerste oproep sal hê.As die toepassing van die sluiting op elke element van die itator suksesvol is, lewer `try_fold()` die finale akkumulator op as sukses.
    ///
    /// Vou is handig wanneer u 'n versameling van iets het en 'n enkele waarde daaruit wil produseer.
    ///
    /// # Nota aan implementeerders
    ///
    /// Verskeie van die ander (forward)-metodes het standaardimplementasies in terme van hierdie metode, dus probeer dit eksplisiet te implementeer as dit iets beter kan doen as die standaard `for`-lusimplementering.
    ///
    /// Probeer veral om hierdie oproep `try_fold()` te hê op die interne dele waaruit hierdie iterator saamgestel is.
    /// As u meerdere oproepe nodig het, kan die `?`-operateur die akkumulasiewaarde gemaklik saamvoeg, maar pas op vir enige invariërs wat gehandhaaf moet word voor die vroeë terugkeer.
    /// Dit is 'n `&mut self`-metode, dus moet herhaling hervat kan word nadat u hier 'n fout getref het.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // die gekontroleerde som van al die elemente van die skikking
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Hierdie som loop oor wanneer die 100-element bygevoeg word
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Omdat die kortsluiting beskikbaar is, is die oorblywende elemente steeds beskikbaar via die iterator.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// 'N Iterator-metode wat 'n feilbare funksie toepas op elke item in die iterator, wat by die eerste fout stop en die fout weergee.
    ///
    ///
    /// Dit kan ook beskou word as die feilbare vorm van [`for_each()`] of as die staatlose weergawe van [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Dit het kortsluit, so die oorblywende items is nog steeds in die herhaling:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Vou elke element in 'n akkumulator in deur 'n bewerking toe te pas om die finale resultaat terug te gee.
    ///
    /// `fold()` neem twee argumente: 'n aanvanklike waarde, en 'n slot met twee argumente: 'n 'accumulator' en 'n element.
    /// Die sluiting gee die waarde terug wat die akkumulator moet hê vir die volgende herhaling.
    ///
    /// Die aanvanklike waarde is die waarde wat die akkumulator by die eerste oproep sal hê.
    ///
    /// Nadat hierdie sluiting op elke element van die iterator toegepas is, gee `fold()` die akkumulator terug.
    ///
    /// Hierdie bewerking word soms 'reduce' of 'inject' genoem.
    ///
    /// Vou is handig wanneer u 'n versameling van iets het en 'n enkele waarde daaruit wil produseer.
    ///
    /// Note: `fold()`, en soortgelyke metodes wat die hele iterator deurkruis, sal moontlik nie eindig vir oneindige iteratore nie, selfs nie op traits waarvoor 'n resultaat binne 'n eindige tyd bepaalbaar is nie.
    ///
    /// Note: [`reduce()`] kan gebruik word om die eerste element as die aanvanklike waarde te gebruik, as die akkumulatietipe en artikeltipe dieselfde is.
    ///
    /// # Nota aan implementeerders
    ///
    /// Verskeie van die ander (forward)-metodes het standaardimplementasies in terme van hierdie metode, dus probeer dit eksplisiet te implementeer as dit iets beter kan doen as die standaard `for`-lusimplementering.
    ///
    ///
    /// Probeer veral om hierdie oproep `fold()` te hê op die interne dele waaruit hierdie iterator saamgestel is.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // die som van al die elemente van die skikking
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Kom ons stap hier deur elke stap van die herhaling:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// En so, ons finale uitslag, `6`.
    ///
    /// Dit is algemeen dat mense wat nie veel iteratore gebruik het nie, 'n `for`-lus gebruik met 'n lys van dinge om 'n resultaat op te bou.Dit kan in `fold()`s verander word:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // vir lus:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // hulle is dieselfde
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Verminder die elemente tot een, deur herhaaldelik 'n verkleinerende bewerking toe te pas.
    ///
    /// As die iterator leeg is, gee [`None`] terug;anders gee dit die resultaat van die vermindering terug.
    ///
    /// Vir iteratore met ten minste een element, is dit dieselfde as [`fold()`] met die eerste element van die iterator as die aanvanklike waarde, en vou elke daaropvolgende element daarin.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Bepaal die maksimum waarde:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Toets of elke element van die iterator ooreenstem met 'n predikaat.
    ///
    /// `all()` neem 'n afsluiting wat `true` of `false` terugbesorg.Dit pas hierdie sluiting toe op elke element van die iterator, en as hulle almal `true` terugbesorg, dan ook `all()`.
    /// As een van hulle `false` terugbesorg, gee dit `false` terug.
    ///
    /// `all()` is kortsluiting;met ander woorde, dit sal ophou verwerk sodra 'n `false` gevind word, aangesien die saak ook `false` sal wees, ongeag wat anders gebeur.
    ///
    ///
    /// 'N Leë iterator gee `true` terug.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Stop by die eerste `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // ons kan steeds `iter` gebruik, aangesien daar meer elemente is.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Toets of enige element van die iterator ooreenstem met 'n predikaat.
    ///
    /// `any()` neem 'n afsluiting wat `true` of `false` terugbesorg.Dit pas hierdie sluiting toe op elke element van die iterator, en as een van hulle `true` terugbesorg, dan ook `any()`.
    /// As hulle almal `false` terugbesorg, gee dit `false` terug.
    ///
    /// `any()` is kortsluiting;dit sal met ander woorde ophou verwerk sodra 'n `true` gevind word, aangesien die saak ook `true` sal wees, ongeag wat anders gebeur.
    ///
    ///
    /// 'N Leë iterator gee `false` terug.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Stop by die eerste `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // ons kan steeds `iter` gebruik, aangesien daar meer elemente is.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Soek na 'n element van 'n iterator wat aan 'n predikaat voldoen.
    ///
    /// `find()` neem 'n sluiting wat `true` of `false` terugbesorg.
    /// Dit pas hierdie sluiting toe op elke element van die iterator, en as een van hulle `true` terugbesorg, dan gee `find()` [`Some(element)`] terug.
    /// As hulle almal `false` terugbesorg, gee dit [`None`] terug.
    ///
    /// `find()` is kortsluiting;met ander woorde, dit sal stop met verwerking sodra die sluiting `true` terugbesorg.
    ///
    /// Omdat `find()` 'n verwysing neem en baie iteratore bo verwysings herhaal, lei dit tot 'n moontlik verwarrende situasie waar die argument 'n dubbele verwysing is.
    ///
    /// U kan hierdie effek sien in die onderstaande voorbeelde, met `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Stop by die eerste `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // ons kan steeds `iter` gebruik, aangesien daar meer elemente is.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Let daarop dat `iter.find(f)` gelykstaande is aan `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Pas funksie toe op die elemente van iterator en lewer die eerste nie-geen resultaat op.
    ///
    ///
    /// `iter.find_map(f)` is gelykstaande aan `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Pas funksie toe op die elemente van iterator en gee die eerste ware resultaat of die eerste fout terug.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Soek na 'n element in 'n iterator en gee die indeks terug.
    ///
    /// `position()` neem 'n sluiting wat `true` of `false` terugbesorg.
    /// Dit pas hierdie sluiting toe op elke element van die iterator, en as een van hulle `true` terugbesorg, dan gee `position()` weer [`Some(index)`].
    /// As almal `false` terugbesorg, gee dit [`None`] terug.
    ///
    /// `position()` is kortsluiting;dit sal met ander woorde ophou verwerk sodra 'n `true` gevind word.
    ///
    /// # Oorloopgedrag
    ///
    /// Die metode beskerm nie teen oorvloei nie, dus as daar meer as [`usize::MAX`]-elemente is wat nie ooreenstem nie, lewer dit die verkeerde resultaat of panics.
    ///
    /// As debug-bewerings geaktiveer is, word 'n panic gewaarborg.
    ///
    /// # Panics
    ///
    /// Hierdie funksie kan panic as die iterator meer as `usize::MAX`-elemente het wat nie ooreenstem nie.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Stop by die eerste `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // ons kan steeds `iter` gebruik, aangesien daar meer elemente is.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Die teruggekeerde indeks hang af van die iteratortoestand
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Soek na 'n element in 'n iterator aan die regterkant en gee die indeks terug.
    ///
    /// `rposition()` neem 'n sluiting wat `true` of `false` terugbesorg.
    /// Dit pas hierdie sluiting toe op elke element van die iterator, vanaf die einde, en as een van hulle `true` terugbesorg, dan gee `rposition()` [`Some(index)`] terug.
    ///
    /// As almal `false` terugbesorg, gee dit [`None`] terug.
    ///
    /// `rposition()` is kortsluiting;dit sal met ander woorde ophou verwerk sodra 'n `true` gevind word.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Stop by die eerste `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // ons kan steeds `iter` gebruik, aangesien daar meer elemente is.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Dit is nie nodig om 'n oorloopkontrole hier te neem nie, want `ExactSizeIterator` impliseer dat die aantal elemente in 'n `usize` pas.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Wys die maksimum element van 'n iterator.
    ///
    /// As verskeie elemente ewe maksimum is, word die laaste element teruggestuur.
    /// As die iterator leeg is, word [`None`] teruggestuur.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Wys die minimum element van 'n iterator.
    ///
    /// As verskeie elemente ewe min is, word die eerste element teruggestuur.
    /// As die iterator leeg is, word [`None`] teruggestuur.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Wys die element wat die maksimum waarde van die gespesifiseerde funksie gee.
    ///
    ///
    /// As verskeie elemente ewe maksimum is, word die laaste element teruggestuur.
    /// As die iterator leeg is, word [`None`] teruggestuur.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Wys die element wat die maksimum waarde gee ten opsigte van die gespesifiseerde vergelykingsfunksie.
    ///
    ///
    /// As verskeie elemente ewe maksimum is, word die laaste element teruggestuur.
    /// As die iterator leeg is, word [`None`] teruggestuur.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Wys die element wat die minimum waarde van die gespesifiseerde funksie gee.
    ///
    ///
    /// As verskeie elemente ewe min is, word die eerste element teruggestuur.
    /// As die iterator leeg is, word [`None`] teruggestuur.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Wys die element wat die minimum waarde gee ten opsigte van die gespesifiseerde vergelykingsfunksie.
    ///
    ///
    /// As verskeie elemente ewe min is, word die eerste element teruggestuur.
    /// As die iterator leeg is, word [`None`] teruggestuur.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Draai die rigting van 'n iterator om.
    ///
    /// Gewoonlik herhaal iteratore van links na regs.
    /// Nadat `rev()` gebruik is, sal 'n iterator van regs na links herhaal.
    ///
    /// Dit is slegs moontlik as die iterator 'n einde het, dus `rev()` werk slegs op ['DoubleEndedIterator'] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Verander 'n iterator van pare in 'n paar houers.
    ///
    /// `unzip()` verbruik 'n hele iterator van pare en lewer twee versamelings: een uit die linker elemente van die pare en een uit die regte elemente.
    ///
    ///
    /// Hierdie funksie is in 'n sekere sin die teenoorgestelde van [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Skep 'n iterator wat al sy elemente kopieer.
    ///
    /// Dit is handig as u 'n iterator van meer as `&T` het, maar u het 'n iterator van meer as `T` nodig.
    ///
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // gekopieër is dieselfde as .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Skep 'n iterator wat al die elemente ["kloon"].
    ///
    /// Dit is handig as u 'n iterator van meer as `&T` het, maar u het 'n iterator van meer as `T` nodig.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // gekloon is dieselfde as .map(|&x| x), vir heelgetalle
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Herhaal 'n iterator eindeloos.
    ///
    /// In plaas daarvan om by [`None`] te stop, sal die iterator weer van voor af begin.Nadat u weer herhaal het, sal dit weer aan die begin begin.En weer.
    /// En weer.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Som die elemente van 'n iterator op.
    ///
    /// Neem elke element, voeg dit bymekaar en lewer die resultaat.
    ///
    /// 'N Leë iterator gee die nulwaarde van die tipe terug.
    ///
    /// # Panics
    ///
    /// Wanneer `sum()` gebel word en 'n primitiewe heelgetal word teruggestuur, sal hierdie metode panic word as die berekening oorloop en foutopsporings geaktiveer word.
    ///
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Itereer oor die hele iterator en vermenigvuldig al die elemente
    ///
    /// 'N Leë iterator gee die een waarde van die tipe terug.
    ///
    /// # Panics
    ///
    /// As u `product()` oproep en 'n primitiewe heelgetal-tipe word teruggestuur, sal die metode panic word as die berekening oorloop en foutopsporings is geaktiveer.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) vergelyk die elemente van hierdie [`Iterator`] met die van 'n ander.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) vergelyk die elemente van hierdie [`Iterator`] met die van 'n ander met betrekking tot die gespesifiseerde vergelykingsfunksie.
    ///
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) vergelyk die elemente van hierdie [`Iterator`] met die van 'n ander.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) vergelyk die elemente van hierdie [`Iterator`] met die van 'n ander met betrekking tot die gespesifiseerde vergelykingsfunksie.
    ///
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Bepaal of die elemente van hierdie [`Iterator`] gelyk is aan die van 'n ander.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Bepaal of die elemente van hierdie [`Iterator`] gelyk is aan dié van 'n ander met betrekking tot die gespesifiseerde gelykheidsfunksie.
    ///
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Bepaal of die elemente van hierdie [`Iterator`] nie gelyk is aan dié van 'n ander nie.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Bepaal of die elemente van hierdie [`Iterator`] [lexicographically](Ord#lexicographical-comparison) minder is as die van 'n ander.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Bepaal of die elemente van hierdie [`Iterator`] [lexicographically](Ord#lexicographical-comparison) minder of gelyk is aan die van 'n ander.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Bepaal of die elemente van hierdie [`Iterator`] [lexicographically](Ord#lexicographical-comparison) groter is as die van 'n ander.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Bepaal of die elemente van hierdie [`Iterator`] [lexicographically](Ord#lexicographical-comparison) groter of gelyk is aan die van 'n ander.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Kontroleer of die elemente van hierdie itatorator gesorteer is.
    ///
    /// Dit wil sê, vir elke element `a` en die volgende element `b`, moet `a <= b` hou.As die iterator presies nul of een element lewer, word `true` teruggestuur.
    ///
    /// Let daarop dat as `Self::Item` slegs `PartialOrd` is, maar nie `Ord` nie, die bostaande definisie impliseer dat hierdie funksie `false` oplewer as twee opeenvolgende items nie vergelykbaar is nie.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Kontroleer of die elemente van hierdie iterator volgens die gegewe vergelykingsfunksie gesorteer is.
    ///
    /// In plaas daarvan om `PartialOrd::partial_cmp` te gebruik, gebruik hierdie funksie die gegewe `compare`-funksie om die volgorde van twee elemente te bepaal.
    /// Afgesien daarvan is dit gelykstaande aan [`is_sorted`];sien die dokumentasie daarvan vir meer inligting.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Kontroleer of die elemente van hierdie iterator gesorteer is met behulp van die gegewe sleutelonttrekfunksie.
    ///
    /// In plaas daarvan om die iteratoreelemente direk te vergelyk, vergelyk hierdie funksie die sleutels van die elemente, soos bepaal deur `f`.
    /// Afgesien daarvan is dit gelykstaande aan [`is_sorted`];sien die dokumentasie daarvan vir meer inligting.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Sien [TrustedRandomAccess]
    // Die ongewone naam is om naambotsings in die metodeoplossing te vermy, sien #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}