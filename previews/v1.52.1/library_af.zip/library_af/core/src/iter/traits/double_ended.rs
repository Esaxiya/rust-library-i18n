use crate::ops::{ControlFlow, Try};

/// 'N Iterator wat elemente van beide kante kan oplewer.
///
/// Iets wat `DoubleEndedIterator` implementeer, het een ekstra vermoë bo iets wat [`Iterator`] implementeer: die vermoë om ook 'Items' van agter, sowel as van voor te neem.
///
///
/// Dit is belangrik om daarop te let dat heen en weer op dieselfde baan werk, en nie kruis nie: iterasie is verby wanneer hulle in die middel ontmoet.
///
/// Op 'n soortgelyke manier as die [`Iterator`]-protokol, sodra 'n `DoubleEndedIterator` [`None`] van 'n [`next_back()`] terugbesorg, kan dit weer [`Some`] terugbesorg word.
/// [`next()`] en [`next_back()`] is uitruilbaar vir hierdie doel.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Basiese gebruik:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Verwyder en retourneer 'n element vanaf die einde van die iterator.
    ///
    /// Wys `None` as daar nie meer elemente is nie.
    ///
    /// Die [trait-level]-dokumente bevat meer besonderhede.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Die elemente wat deur 'DoubleEndedIterator' se metodes opgelewer word, kan verskil van die elemente wat deur ['Iterator'] se metodes opgelewer word:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Bevorder die iterator van agter met `n`-elemente.
    ///
    /// `advance_back_by` is die omgekeerde weergawe van [`advance_by`].Hierdie metode sal `n`-elemente wat van agter begin, gretig oorslaan deur [`next_back`] tot `n` keer te bel totdat [`None`] teëgekom word.
    ///
    /// `advance_back_by(n)` sal [`Ok(())`] terugstuur as die iterator suksesvol deur `n`-elemente vorder, of [`Err(k)`] as [`None`] teëgekom word, waar `k` die aantal elemente is waarmee die iterator gevorder word voordat die elemente opraak (dws
    /// die lengte van die iterator).
    /// Let daarop dat `k` altyd minder as `n` is.
    ///
    /// As u `advance_back_by(0)` skakel, word geen elemente verbruik nie en word altyd [`Ok(())`] terugbesorg.
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // slegs `&3` is oorgeslaan
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Wys die 'n'de element vanaf die einde van die iterator.
    ///
    /// Dit is in wese die omgekeerde weergawe van [`Iterator::nth()`].
    /// Alhoewel, soos die meeste indekseringsbewerkings, begin die telling vanaf nul, dus gee `nth_back(0)` die eerste waarde van die einde af, `nth_back(1)` die tweede, ensovoorts.
    ///
    ///
    /// Let daarop dat alle elemente tussen die einde en die teruggekeerde element verbruik sal word, insluitend die teruggekeerde element.
    /// Dit beteken ook dat die oproep van `nth_back(0)` verskeie kere op dieselfde iterator verskillende elemente sal oplewer.
    ///
    /// `nth_back()` sal [`None`] teruggee as `n` groter is as of gelyk aan die lengte van die iterator.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Om die herhaling meermale te bel, herhaal die herhaling nie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Terugkeer van `None` as daar minder as `n + 1`-elemente is:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Dit is die omgekeerde weergawe van [`Iterator::try_fold()`]: dit neem elemente vanaf die agterkant van die iterator.
    ///
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Omdat die kortsluiting beskikbaar is, is die oorblywende elemente steeds beskikbaar via die iterator.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// 'N Iterator-metode wat die elemente van die iterator verminder tot 'n enkele finale waarde, begin van agter af.
    ///
    /// Dit is die omgekeerde weergawe van [`Iterator::fold()`]: dit neem elemente wat begin vanaf die agterkant van die iterator.
    ///
    /// `rfold()` neem twee argumente: 'n aanvanklike waarde, en 'n slot met twee argumente: 'n 'accumulator' en 'n element.
    /// Die sluiting gee die waarde terug wat die akkumulator moet hê vir die volgende herhaling.
    ///
    /// Die aanvanklike waarde is die waarde wat die akkumulator by die eerste oproep sal hê.
    ///
    /// Nadat hierdie sluiting op elke element van die iterator toegepas is, gee `rfold()` die akkumulator terug.
    ///
    /// Hierdie bewerking word soms 'reduce' of 'inject' genoem.
    ///
    /// Vou is handig wanneer u 'n versameling van iets het en 'n enkele waarde daaruit wil produseer.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // die som van al die elemente van a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Hierdie voorbeeld bou 'n string, begin met 'n aanvanklike waarde en gaan voort met elke element van agter tot voor:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Soek na 'n element van 'n iterator van agter wat aan 'n predikaat voldoen.
    ///
    /// `rfind()` neem 'n sluiting wat `true` of `false` terugbesorg.
    /// Dit pas hierdie sluiting toe op elke element van die iterator, begin aan die einde, en as een van hulle `true` terugbesorg, dan gee `rfind()` [`Some(element)`] terug.
    /// As hulle almal `false` terugbesorg, gee dit [`None`] terug.
    ///
    /// `rfind()` is kortsluiting;met ander woorde, dit sal stop met verwerking sodra die sluiting `true` terugbesorg.
    ///
    /// Omdat `rfind()` 'n verwysing neem en baie iteratore oor verwysings verwys, lei dit tot 'n moontlik verwarrende situasie waar die argument 'n dubbele verwysing is.
    ///
    /// U kan hierdie effek sien in die onderstaande voorbeelde, met `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Stop by die eerste `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // ons kan steeds `iter` gebruik, aangesien daar meer elemente is.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}