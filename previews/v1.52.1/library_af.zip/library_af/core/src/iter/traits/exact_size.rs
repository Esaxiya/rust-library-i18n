/// 'N Iterator wat die presiese lengte daarvan ken.
///
/// Baie [`Iterator`] weet nie hoeveel keer hulle sal herhaal nie, maar sommige wel.
/// As 'n iterator weet hoeveel keer dit kan herhaal, kan toegang tot die inligting nuttig wees.
/// As u byvoorbeeld agteruit wil herhaal, is 'n goeie begin om te weet waar die einde is.
///
/// Wanneer u 'n `ExactSizeIterator` implementeer, moet u ook [`Iterator`] implementeer.
/// As u dit doen, moet die implementering van [`Iterator::size_hint`] * die presiese grootte van die iterator oplewer.
///
/// Die [`len`]-metode het 'n standaardimplementering, daarom moet u dit gewoonlik nie implementeer nie.
/// U kan egter 'n beter uitvoering as die standaard bied, dus dit is sinvol om dit in hierdie geval te ignoreer.
///
///
/// Let op dat hierdie trait 'n veilige trait is en as sodanig *nie* en *nie* kan waarborg dat die teruggekeerde lengte korrek is nie.
/// Dit beteken dat `unsafe`-kode **nie** op die korrektheid van [`Iterator::size_hint`] moet staatmaak nie.
/// Die onstabiele en onveilige [`TrustedLen`](super::marker::TrustedLen) trait bied hierdie bykomende waarborg.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Basiese gebruik:
///
/// ```
/// // 'n eindige reeks weet presies hoeveel keer dit sal herhaal
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// In die [module-level docs] het ons 'n [`Iterator`] geïmplementeer, `Counter`.
/// Kom ons implementeer ook `ExactSizeIterator` daarvoor:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Ons kan die oorblywende aantal herhalings maklik bereken.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // En nou kan ons dit gebruik!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Wys die presiese lengte van die iteratore.
    ///
    /// Die implementering verseker dat die iterator presies `len()` meer keer 'n [`Some(T)`]-waarde sal oplewer voordat dit [`None`] terugbesorg word.
    ///
    /// Hierdie metode is standaard geïmplementeer, en u moet dit dus nie direk implementeer nie.
    /// As u egter 'n doeltreffender implementering kan bied, kan u dit doen.
    /// Kyk na die [trait-level]-dokumente vir 'n voorbeeld.
    ///
    /// Hierdie funksie het dieselfde veiligheidswaarborge as die [`Iterator::size_hint`]-funksie.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// // 'n eindige reeks weet presies hoeveel keer dit sal herhaal
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Hierdie bewering is té verdedigend, maar dit kontroleer die onveranderlike
        // gewaarborg deur die trait.
        // As hierdie trait rust-intern was, kan ons debug_assert gebruik !;assert_eq!sal ook alle implementerings van die Rust-gebruikers nagaan.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Wys `true` as die herhaling leeg is.
    ///
    /// Hierdie metode is standaard geïmplementeer met behulp van [`ExactSizeIterator::len()`], dus u hoef dit nie self te implementeer nie.
    ///
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}