//! Die `Clone` trait vir tipes wat nie 'implisiet gekopieër' kan word nie.
//!
//! In Rust is 'n paar eenvoudige tipes "implicitly copyable" en as u dit toewys of as argumente deurgee, sal die ontvanger 'n afskrif kry en die oorspronklike waarde op sy plek laat.
//! Hierdie tipes benodig nie toewysing om te kopieer nie en het nie finaliseerders nie (dit wil sê, hulle bevat nie vakke wat u besit of implementeer [`Drop`] nie), dus beskou die samesteller dit as goedkoop en veilig om te kopieer.
//!
//! Vir ander soorte moet kopieë eksplisiet gemaak word deur die [`Clone`] trait te gebruik en die [`clone`]-metode te noem.
//!
//! [`clone`]: Clone::clone
//!
//! Basiese gebruiksvoorbeeld:
//!
//! ```
//! let s = String::new(); // Snaar-implemente Kloon
//! let copy = s.clone(); // sodat ons dit kan kloon
//! ```
//!
//! Om die Clone trait maklik te implementeer, kan u ook `#[derive(Clone)]` gebruik.Voorbeeld:
//!
//! ```
//! #[derive(Clone)] // ons voeg die Clone trait by Morpheus struct
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // en nou kan ons dit kloon!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// 'N Algemene trait vir die vermoë om 'n voorwerp eksplisiet te dupliseer.
///
/// Verskil van [`Copy`] deurdat [`Copy`] implisiet en uiters goedkoop is, terwyl `Clone` altyd eksplisiet is en al dan nie duur is nie.
/// Om hierdie eienskappe af te dwing, laat Rust u nie toe om [`Copy`] weer te implementeer nie, maar wel om `Clone` te implementeer en willekeurige kode uit te voer.
///
/// Aangesien `Clone` meer algemeen is as [`Copy`], kan u ook alles [`Copy`] outomaties `Clone` laat maak.
///
/// ## Derivable
///
/// Hierdie trait kan met `#[derive]` gebruik word as alle velde `Clone` is.Die implementering van 'aflei' van [`Clone`] noem [`clone`] op elke veld.
///
/// [`clone`]: Clone::clone
///
/// Vir 'n generiese struktuur implementeer `#[derive]` `Clone` voorwaardelik deur gebonde `Clone` op generiese parameters by te voeg.
///
/// ```
/// // `derive` implemente Clone for Reading<T>wanneer T kloon is.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Hoe kan ek `Clone` implementeer?
///
/// Tipes wat [`Copy`] is, moet 'n triviale implementering van `Clone` hê.Meer formeel:
/// as `T: Copy`, `x: T` en `y: &T`, dan is `let x = y.clone();` gelykstaande aan `let x = *y;`.
/// Handmatige implementering moet versigtig wees om hierdie invariant te handhaaf;onveilige kode mag egter nie daarop staatmaak om geheueveiligheid te verseker nie.
///
/// 'N Voorbeeld is 'n generiese struktuur wat 'n funksiewyser bevat.In hierdie geval kan die implementering van `Clone` nie 'afgelei' word nie, maar kan dit geïmplementeer word as:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Bykomende implementeerders
///
/// Benewens die [implementors listed below][impls], implementeer die volgende tipes ook `Clone`:
///
/// * Tipes funksie-items (dws die verskillende soorte wat vir elke funksie gedefinieer word)
/// * Funksie wysertipes (bv. `fn() -> i32`)
/// * Reeks tipes, vir alle groottes, as die artikeltipe ook `Clone` implementeer (bv. `[i32; 123456]`)
/// * Tupeltipes, as elke komponent ook `Clone` implementeer (bv. `()`, `(i32, bool)`)
/// * Sluitingstipes, as hulle geen waarde uit die omgewing vang nie, of as al die vasgestelde waardes `Clone` self implementeer.
///   Let daarop dat veranderlikes wat deur gedeelde verwysing vasgelê word, altyd `Clone` implementeer (selfs as die referent dit nie doen nie), terwyl veranderlikes wat deur veranderlike verwysing vasgelê word nooit `Clone` implementeer nie.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Wys 'n afskrif van die waarde.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str implemente Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Voer kopie-opdrag vanaf `source` uit.
    ///
    /// `a.clone_from(&b)` is gelykstaande aan `a = b.clone()` in funksionaliteit, maar kan oorheers word om die hulpbronne van `a` te hergebruik om onnodige toekennings te vermy.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Lei makro af wat 'n impl. Van die trait `Clone` genereer.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): hierdie strukture word slegs deur#[afgelei] gebruik om te beweer dat elke komponent van 'n tipe kloon of kopie implementeer.
//
//
// Hierdie strukture moet nooit in die gebruikerskode verskyn nie.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Implementasies van `Clone` vir primitiewe tipes.
///
/// Implementasies wat nie in Rust beskryf kan word nie, word in `traits::SelectionContext::copy_clone_conditions()` in `rustc_trait_selection` geïmplementeer.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Gedeelde verwysings kan gekloon word, maar veranderlike verwysings *kan nie* nie!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Gedeelde verwysings kan gekloon word, maar veranderlike verwysings *kan nie* nie!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}