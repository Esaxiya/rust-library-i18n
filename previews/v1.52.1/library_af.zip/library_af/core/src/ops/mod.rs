//! Oorlaaibare operateurs.
//!
//! Deur hierdie traits te implementeer, kan u sekere operateurs oorlaai.
//!
//! Sommige van hierdie traits word deur die prelude ingevoer, en is dus beskikbaar in elke Rust-program.Slegs operateurs wat deur traits ondersteun word, kan oorlaai word.
//! Die toevoegingsoperateur (`+`) kan byvoorbeeld oorlaai word deur die [`Add`] trait, maar aangesien die toewysingsoperateur (`=`) geen steun het vir trait nie, is daar geen manier om die semantiek daarvan te oorlaai nie.
//! Daarbenewens bied hierdie module geen meganisme om nuwe operateurs te skep nie.
//! As 'n onbelemmerde oorbelading of persoonlike operateur vereis word, moet u na makro's of samesteller-inproppe kyk om die sintaksis van Rust uit te brei.
//!
//! Die implementering van die operateur traits behoort in hul onderskeie kontekste nie verrassend te wees nie, met inagneming van hul gewone betekenisse en [operator precedence].
//! Byvoorbeeld, wanneer [`Mul`] geïmplementeer word, moet die bewerking 'n mate van vermenigvuldiging hê (en verwagte eienskappe soos assosiatiwiteit moet deel).
//!
//! Let daarop dat die `&&`-en `||`-operateurs kortsluit, dit wil sê dat hulle hul tweede operand slegs evalueer as dit bydra tot die resultaat.Aangesien hierdie gedrag nie deur traits afdwingbaar is nie, word `&&` en `||` nie as oorlaaibare operateurs ondersteun nie.
//!
//! Baie van die operateurs neem hul operande volgens waarde.In nie-generiese kontekste met ingeboude tipes, is dit gewoonlik nie 'n probleem nie.
//! Die gebruik van hierdie operateurs in die generiese kode verg egter 'n bietjie aandag as waardes hergebruik moet word, in teenstelling met die gebruik van die operateurs.Een opsie is om af en toe [`clone`] te gebruik.
//! 'N Ander opsie is om te vertrou op die betrokke tipes om addisionele implementerings vir operatore vir verwysings te verskaf.
//! Byvoorbeeld, vir 'n gebruiker-gedefinieerde tipe `T` wat veronderstel is om toevoeging te ondersteun, is dit waarskynlik 'n goeie idee om beide `T` en `&T` die traits [`Add<T>`][`Add`] en [`Add<&T>`][`Add`] te laat implementeer sodat generiese kode sonder onnodige kloning geskryf kan word.
//!
//!
//! # Examples
//!
//! Hierdie voorbeeld skep 'n `Point`-struktuur wat [`Add`] en [`Sub`] implementeer, en demonstreer dan die optel en aftrek van twee 'Punt'e.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Raadpleeg die dokumentasie vir elke trait vir 'n voorbeeld.
//!
//! Die [`Fn`], [`FnMut`] en [`FnOnce`] traits word geïmplementeer deur tipes wat soos funksies ingeroep kan word.Let op dat [`Fn`] `&self`, [`FnMut`] `&mut self` en [`FnOnce`] `self` neem.
//! Dit kom ooreen met die drie soorte metodes wat op 'n instansie aangewend kan word: oproep-vir-verwysing, oproep-vir-veranderlike-verwysing en oproep-vir-waarde.
//! Die algemeenste gebruik van hierdie traits is om op te tree as funksies op hoër vlak wat funksies of sluitings as argumente gebruik.
//!
//! Neem 'n [`Fn`] as parameter:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Neem 'n [`FnMut`] as parameter:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Neem 'n [`FnOnce`] as parameter:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` verbruik die vasgestelde veranderlikes, dus kan dit nie meer as een keer uitgevoer word nie
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // As u weer probeer om `func()` aan te roep, sal dit 'n `use of moved value`-fout vir `func` veroorsaak
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` kan op hierdie stadium nie meer ingeroep word nie
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;