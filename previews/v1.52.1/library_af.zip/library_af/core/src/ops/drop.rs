/// Pasgemaakte kode binne die vernietiger.
///
/// As 'n waarde nie meer nodig is nie, sal Rust 'n "destructor" op die waarde laat loop.
/// Die algemeenste manier waarop 'n waarde nie meer nodig is nie, is wanneer dit buite die omvang val.Verwoesters kan steeds in ander omstandighede werk, maar ons gaan fokus op die ruimte vir die voorbeelde hier.
/// Raadpleeg die [the reference]-afdeling oor vernietigers om meer oor hierdie ander gevalle te leer.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Hierdie vernietiger bestaan uit twee komponente:
/// - 'N Oproep na `Drop::drop` vir die waarde, as hierdie spesiale `Drop` trait geïmplementeer word vir sy tipe.
/// - Die outomaties gegenereerde "drop glue", wat die vernietigers van alle velde van hierdie waarde rekursief noem.
///
/// Aangesien Rust die vernietigers van alle velde outomaties noem, hoef u in die meeste gevalle nie `Drop` te implementeer nie.
/// Maar in sommige gevalle is dit nuttig, byvoorbeeld vir soorte wat 'n bron direk bestuur.
/// Die bron kan geheue wees, dit kan 'n lêerbeskrywer wees, dit kan 'n netwerksok wees.
/// Sodra 'n waarde van die tipe nie meer gebruik gaan word nie, moet dit die "clean up"-bron gebruik deur die geheue vry te maak of die lêer of sok te sluit.
/// Dit is die taak van 'n vernietiger, en dus die taak van `Drop::drop`.
///
/// ## Examples
///
/// Kom ons kyk na die volgende program om verwoesters in aksie te sien:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust roep eers `Drop::drop` vir `_x` en dan vir beide `_x.one` en `_x.two`, wat beteken dat dit gedruk word om dit te laat loop.
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Selfs as ons die implementering van `Drop` vir `HasTwoDrop` verwyder, word die vernietigers van sy velde steeds genoem.
/// Dit sou lei tot
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## U kan nie `Drop::drop` self bel nie
///
/// Omdat `Drop::drop` gebruik word om 'n waarde op te ruim, kan dit gevaarlik wees om hierdie waarde te gebruik nadat die metode genoem is.
/// Aangesien `Drop::drop` nie die insette daarvan neem nie, verhoed Rust misbruik deur u nie direk na `Drop::drop` te laat skakel nie.
///
/// Met ander woorde, as u `Drop::drop` in die voorbeeld hierbo eksplisiet probeer bel, sal u 'n samestellerfout kry.
///
/// As u die vernietiger van 'n waarde eksplisiet wil noem, kan [`mem::drop`] eerder gebruik word.
///
/// [`mem::drop`]: drop
///
/// ## Drop order
///
/// Maar watter van ons twee `HasDrop` val eers?Vir strukture is dit dieselfde volgorde dat hulle verklaar word: eers `one`, dan `two`.
/// As u dit self wil probeer, kan u die `HasDrop` hierbo wysig om data soos 'n heelgetal te bevat en dit dan in die `println!` binne-in `Drop` te gebruik.
/// Hierdie gedrag word deur die taal gewaarborg.
///
/// Anders as vir strukte, word plaaslike veranderlikes in omgekeerde volgorde laat val:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Dit sal gedruk word
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Raadpleeg [the reference] vir die volledige reëls.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` en `Drop` is eksklusief
///
/// U kan nie beide [`Copy`] en `Drop` op dieselfde tipe implementeer nie.Tipes wat `Copy` is, word implisiet deur die samesteller gedupliseer, wat dit moeilik maak om te voorspel wanneer en hoe gereeld vernietigers uitgevoer sal word.
///
/// As sodanig kan hierdie tipes nie vernietigers hê nie.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Voer die vernietiger vir hierdie tipe uit.
    ///
    /// Hierdie metode word implisiet genoem as die waarde buite die omvang val, en kan nie eksplisiet genoem word nie (dit is kompileringsfout [E0040]).
    /// Die [`mem::drop`]-funksie in die prelude kan egter gebruik word om die argument se `Drop`-implementering te noem.
    ///
    /// Nadat hierdie metode genoem is, is `self` nog nie herdeel nie.
    /// Dit gebeur eers nadat die metode verby is.
    /// As dit nie die geval was nie, sou `self` 'n hangende verwysing wees.
    ///
    /// # Panics
    ///
    /// Aangesien 'n [`panic!`] `drop` sal bel terwyl dit afwikkel, sal enige [`panic!`] in 'n `drop`-implementering waarskynlik afbreek.
    ///
    /// Let daarop dat, selfs al is hierdie panics, die waarde beskou word as val;
    /// u mag nie weer `drop` laat skakel nie.
    /// Dit word normaalweg outomaties deur die samesteller hanteer, maar as u onveilige kode gebruik, kan dit soms onbedoeld voorkom, veral as u [`ptr::drop_in_place`] gebruik.
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}