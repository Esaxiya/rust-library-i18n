use crate::marker::Unpin;
use crate::pin::Pin;

/// Die resultaat van die hervatting van 'n kragopwekker.
///
/// Hierdie enum word teruggestuur vanaf die `Generator::resume`-metode en dui die moontlike retourwaardes van 'n kragopwekker aan.
/// Tans stem dit ooreen met 'n ophangpunt (`Yielded`) of 'n eindpunt (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Die kragopwekker hang af met 'n waarde.
    ///
    /// Hierdie toestand dui aan dat 'n kragopwekker opgeskort is en ooreenstem met 'n `yield`-verklaring.
    /// Die waarde wat in hierdie variant verskaf word, stem ooreen met die uitdrukking wat aan `yield` oorgedra word en stel kragopwekkers in staat om 'n waarde te gee elke keer as dit oplewer.
    ///
    ///
    Yielded(Y),

    /// Die kragopwekker is voltooi met 'n retourwaarde.
    ///
    /// Hierdie toestand dui aan dat 'n kragopwekker met die verstrekte waarde klaar is.
    /// Sodra 'n kragopwekker `Complete` terugbesorg het, word dit as 'n programmeerderfout beskou om `resume` weer te bel.
    ///
    Complete(R),
}

/// Die trait geïmplementeer deur ingeboude kragopwekkers.
///
/// Generators, ook bekend as coroutines, is tans 'n eksperimentele taalfunksie in Rust.
/// Bygevoeg in [RFC 2033]-kragopwekkers is tans bedoel om hoofsaaklik 'n bousteen vir async/await-sintaksis te bied, maar sal waarskynlik ook 'n ergonomiese definisie bied vir iteratore en ander primitiewe.
///
///
/// Die sintaksis en semantiek vir kragopwekkers is onstabiel en benodig 'n verdere RFC vir stabilisering.Op hierdie stadium is die sintaksis egter soos die volgende:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Meer dokumentasie van kragopwekkers kan in die onstabiele boek gevind word.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Die tipe waarde wat hierdie kragopwekker lewer.
    ///
    /// Hierdie geassosieerde tipe stem ooreen met die `yield`-uitdrukking en die waardes wat toegelaat word om terug te keer elke keer as 'n kragopwekker oplewer.
    ///
    /// Byvoorbeeld, 'n iterator-as-'n-kragopwekker sal hierdie tipe waarskynlik as `T` hê, die tipe word herhaal.
    ///
    type Yield;

    /// Die tipe waarde wat hierdie kragopwekker oplewer.
    ///
    /// Dit stem ooreen met die tipe wat vanaf 'n generator met 'n `return`-stelling of implisiet as die laaste uitdrukking van 'n generator letterlik teruggestuur word.
    /// futures sal dit byvoorbeeld as `Result<T, E>` gebruik, aangesien dit 'n voltooide future voorstel.
    ///
    ///
    type Return;

    /// Hervat die uitvoering van hierdie kragopwekker.
    ///
    /// Hierdie funksie sal die uitvoering van die kragopwekker hervat of die uitvoering begin as dit nog nie gedoen is nie.
    /// Hierdie oproep keer terug na die laaste opskortpunt van die kragopwekker, en hervat die uitvoering vanaf die nuutste `yield`.
    /// Die kragopwekker sal voortgaan om te werk totdat dit oplewer of terugkeer, en dan sal hierdie funksie terugkeer.
    ///
    /// # Opbrengswaarde
    ///
    /// Die `GeneratorState`-enum wat van hierdie funksie teruggestuur word, dui aan in watter toestand die kragopwekker is wanneer hy terugkeer.
    /// As die `Yielded`-variant terugbesorg word, het die kragopwekker 'n opskortingspunt bereik en 'n waarde is opgelewer.
    /// Opwekkers in hierdie toestand is op 'n later stadium beskikbaar vir hervatting.
    ///
    /// As `Complete` terugbesorg word, is die kragopwekker heeltemal voltooi met die waarde wat daarvoor verskaf word.Dit is ongeldig dat die kragopwekker weer hervat kan word.
    ///
    /// # Panics
    ///
    /// Hierdie funksie kan panic word as dit genoem word nadat die `Complete`-variant voorheen teruggestuur is.
    /// Terwyl kragopwekker in die taal panic gewaarborg word wanneer dit na `Complete` hervat word, is dit nie gewaarborg vir alle implementerings van die `Generator` trait nie.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}