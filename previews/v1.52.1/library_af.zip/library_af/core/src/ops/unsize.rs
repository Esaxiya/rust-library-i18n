use crate::marker::Unsize;

/// Trait wat aandui dat dit 'n aanwyser of 'n omslag vir een is, waar die grootte van die wyser op die wyser uitgevoer kan word.
///
/// Raadpleeg die [DST coercion RFC][dst-coerce] en [the nomicon entry on coercion][nomicon-coerce] vir meer besonderhede.
///
/// Vir ingeboude wysertipes sal wysers na `T` wysers na `U` dwing as `T: Unsize<U>` deur van 'n dun wyser na 'n vetwyser om te skakel.
///
/// Vir persoonlike tipes werk die dwang hier deur `Foo<T>` tot `Foo<U>` te dwing, mits 'n impl. Van `CoerceUnsized<Foo<U>> for Foo<T>` bestaan.
/// So 'n impl kan slegs geskryf word as `Foo<T>` slegs 'n enkele veld sonder datadata bevat wat `T` insluit.
/// As die tipe veld `Bar<T>` is, moet 'n implementering van `CoerceUnsized<Bar<U>> for Bar<T>` bestaan.
/// Die dwang sal werk deur die `Bar<T>`-veld in `Bar<U>` te dwing en die res van die velde vanaf `Foo<T>` in te vul om 'n `Foo<U>` te skep.
/// Dit sal effektief afboor tot 'n wyserveld en dit dwing.
///
/// Oor die algemeen sal u `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` implementeer vir slim aanwysers, met 'n opsionele `?Sized` wat op `T` self gebind is.
/// Vir soorte omhulsels wat `T` direk insluit soos `Cell<T>` en `RefCell<T>`, kan u `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` direk implementeer.
///
/// Dit sal dwang van soorte soos `Cell<Box<T>>` laat werk.
///
/// [`Unsize`][unsize] word gebruik om soorte te merk wat na DWT's gedwing kan word as dit agter aanwysers is.Dit word outomaties deur die samesteller geïmplementeer.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * konst. U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * konst. U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* konst. U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *konst T->* konst U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Dit word gebruik vir die veiligheid van voorwerpe om te kyk of die ontvanger-tipe van 'n metode gestuur kan word.
///
/// 'N Voorbeeld implementering van die trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *konst T->* konst U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}