/// Die weergawe van die oproepoperateur wat 'n onveranderlike ontvanger neem.
///
/// Gevalle van `Fn` kan herhaaldelik genoem word sonder om die toestand te muteer.
///
/// *Hierdie trait (`Fn`) moet nie verwar word met [function pointers] (`fn`) nie.*
///
/// `Fn` word outomaties geïmplementeer deur sluitings wat slegs onveranderlike verwysings na vasgelegde veranderlikes neem of glad nie iets opneem nie, asook (safe) [function pointers] (met sommige voorbehoude, sien hul dokumentasie vir meer besonderhede).
///
/// Daarbenewens, vir enige tipe `F` wat `Fn` implementeer, implementeer `&F` ook `Fn`.
///
/// Aangesien beide [`FnMut`] en [`FnOnce`] super-eienskappe van `Fn` is, kan enige geval van `Fn` as parameter gebruik word waar 'n [`FnMut`] of [`FnOnce`] verwag word.
///
/// Gebruik `Fn` as 'n bundel wanneer u 'n parameter van 'n funksie-agtige tipe wil aanvaar en dit herhaaldelik moet noem en sonder dat dit gemuteer word (bv. As u dit gelyktydig oproep).
/// As u nie sulke streng vereistes benodig nie, gebruik [`FnMut`] of [`FnOnce`] as perke.
///
/// Raadpleeg die [chapter on closures in *The Rust Programming Language*][book] vir meer inligting oor hierdie onderwerp.
///
/// Opmerklik is ook die spesiale sintaksis vir `Fn` traits (bv
/// `Fn(usize, bool) -> gebruik ').Belangstellendes van die tegniese besonderhede hiervan kan na [the relevant section in the *Rustonomicon*][nomicon] verwys.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Bel 'n sluiting
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Gebruik 'n `Fn`-parameter
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // sodat regex die `&str: !FnMut` kan vertrou
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Voer die oproep uit.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Die weergawe van die oproepoperateur wat 'n veranderlike ontvanger neem.
///
/// Gevalle van `FnMut` kan herhaaldelik genoem word en kan die toestand verander.
///
/// `FnMut` word outomaties geïmplementeer deur sluitings wat veranderlike verwysings na vasgelegde veranderlikes neem, asook alle soorte wat [`Fn`] implementeer, bv. (safe) [function pointers] (aangesien `FnMut` 'n superbaan van [`Fn`] is).
/// Daarbenewens, vir enige tipe `F` wat `FnMut` implementeer, implementeer `&mut F` ook `FnMut`.
///
/// Aangesien [`FnOnce`] 'n superbaan van `FnMut` is, kan enige geval van `FnMut` gebruik word waar 'n [`FnOnce`] verwag word, en aangesien [`Fn`] 'n onderdeel van `FnMut` is, kan enige geval van [`Fn`] gebruik word waar `FnMut` verwag word.
///
/// Gebruik `FnMut` as 'n gebind wanneer u 'n parameter van 'n funksie-soort tipe wil aanvaar en dit herhaaldelik moet noem, terwyl dit toelaat dat die toestand verander.
/// As u nie wil hê dat die parameter die toestand moet verander nie, gebruik dan [`Fn`] as 'n gebind;gebruik [`FnOnce`] as u dit nie herhaaldelik hoef te bel nie.
///
/// Raadpleeg die [chapter on closures in *The Rust Programming Language*][book] vir meer inligting oor hierdie onderwerp.
///
/// Opmerklik is ook die spesiale sintaksis vir `Fn` traits (bv
/// `Fn(usize, bool) -> gebruik ').Belangstellendes van die tegniese besonderhede hiervan kan na [the relevant section in the *Rustonomicon*][nomicon] verwys.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Om 'n afsluitende sluiting te noem
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Gebruik 'n `FnMut`-parameter
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // sodat regex die `&str: !FnMut` kan vertrou
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Voer die oproep uit.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Die weergawe van die oproepoperateur wat 'n bywaarde-ontvanger neem.
///
/// Instansies van `FnOnce` kan gebel word, maar kan nie meermale bel word nie.As die enigste ding wat bekend is aan 'n tipe, is dat dit `FnOnce` implementeer, kan dit slegs een keer gebel word.
///
/// `FnOnce` word outomaties geïmplementeer deur sluitings wat gevange veranderlikes kan verbruik, sowel as alle soorte wat [`FnMut`] implementeer, bv. (safe) [function pointers] (aangesien `FnOnce` 'n superbaan van [`FnMut`] is).
///
///
/// Aangesien beide [`Fn`] en [`FnMut`] subrasse van `FnOnce` is, kan enige geval van [`Fn`] of [`FnMut`] gebruik word waar 'n `FnOnce` verwag word.
///
/// Gebruik `FnOnce` as 'n gebind wanneer u 'n parameter van 'n funksie-soort wil aanvaar en dit net een keer hoef te noem.
/// As u die parameter herhaaldelik moet skakel, gebruik [`FnMut`] as 'n gebind;gebruik [`Fn`] as u dit ook nodig het om die toestand nie te verander nie.
///
/// Raadpleeg die [chapter on closures in *The Rust Programming Language*][book] vir meer inligting oor hierdie onderwerp.
///
/// Opmerklik is ook die spesiale sintaksis vir `Fn` traits (bv
/// `Fn(usize, bool) -> gebruik ').Belangstellendes van die tegniese besonderhede hiervan kan na [the relevant section in the *Rustonomicon*][nomicon] verwys.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Gebruik 'n `FnOnce`-parameter
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` verbruik die vasgestelde veranderlikes, dus kan dit nie meer as een keer uitgevoer word nie.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // As u weer probeer om `func()` aan te roep, sal dit 'n `use of moved value`-fout vir `func` veroorsaak.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` kan op hierdie stadium nie meer ingeroep word nie
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // sodat regex die `&str: !FnMut` kan vertrou
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Die teruggestuurde tipe nadat die oproepoperateur gebruik is.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Voer die oproep uit.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}