/// 'N trait om die gedrag van die `?`-operateur aan te pas.
///
/// 'N Tipe wat `Try` implementeer, is 'n kanonieke manier om dit te sien in terme van 'n success/failure-tweedeling.
/// Met hierdie trait kan u die sukses-of mislukkingswaardes uit 'n bestaande instansie onttrek en 'n nuwe instansie vanuit 'n sukses-of mislukkingswaarde skep.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Die tipe van hierdie waarde as suksesvol beskou.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Die tipe van hierdie waarde wanneer dit as misluk beskou word.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Pas die "?"-operateur toe.'N Terugkeer van `Ok(t)` beteken dat die uitvoering normaal moet voortgaan, en die resultaat van `?` is die waarde `t`.
    /// 'N Terugkeer van `Err(e)` beteken dat die uitvoering moet vertakking tot in die binneste `catch`, of terugkeer vanaf die funksie.
    ///
    /// As 'n `Err(e)`-resultaat teruggestuur word, sal die waarde `e` "wrapped" wees in die retourtipe van die omsluitende omvang (wat self `Try` moet implementeer).
    ///
    /// Spesifiek word die waarde `X::from_error(From::from(e))` teruggestuur, waar `X` die retourtipe van die omsluitende funksie is.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Wikkel 'n foutwaarde om die saamgestelde resultaat te konstrueer.
    /// `Result::Err(x)` en `Result::from_error(x)` is byvoorbeeld gelykstaande.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Wikkel 'n OK-waarde om die saamgestelde resultaat te konstrueer.
    /// `Result::Ok(x)` en `Result::from_ok(x)` is byvoorbeeld gelykstaande.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}