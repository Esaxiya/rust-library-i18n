/// Word gebruik vir onveranderlike bewerkings met ander verwysings, soos `*v`.
///
/// Benewens dat dit gebruik word vir eksplisiete dereferensie-operasies met die (unary) `*`-operateur in onveranderlike kontekste, word `Deref` ook in baie omstandighede implisiet deur die samesteller gebruik.
/// Hierdie meganisme word ['`Deref` coercion'][more] genoem.
/// In veranderlike kontekste word [`DerefMut`] gebruik.
///
/// Die implementering van `Deref` vir slim aanwysers maak toegang tot die data agter hulle gerieflik, daarom implementeer hulle `Deref`.
/// Aan die ander kant is die reëls rakende `Deref` en [`DerefMut`] spesifiek ontwerp om slim aanwysers te akkommodeer.
/// As gevolg hiervan, moet 'Deref' slegs geïmplementeer word vir slim aanwysers ** om verwarring te voorkom.
///
/// Om soortgelyke redes moet **hierdie trait nooit misluk nie**.Mislukking tydens ereferensies kan uiters verwarrend wees as u implisiet op `Deref` beroep.
///
/// # Meer oor `Deref` dwang
///
/// As `T` `Deref<Target = U>` implementeer en `x` 'n waarde van die tipe `T` is, dan:
///
/// * In onveranderlike kontekste is `*x` (waar `T` nie 'n verwysing of 'n rou wyser is nie) gelykstaande aan `* Deref::deref(&x)`.
/// * Waardes van tipe `&T` word gedwing tot waardes van tipe `&U`
/// * `T` implementeer implisiet al die (immutable)-metodes van die tipe `U`.
///
/// Vir meer besonderhede, besoek [the chapter in *The Rust Programming Language*][book] asook die verwysingsafdelings oor [the dereference operator][ref-deref-op], [method resolution] en [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// 'N Struktuur met een enkele veld wat toeganklik is deur die struktuur te verwys.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Die gevolglike tipe na derverwysing.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Stel die waarde uit.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Word gebruik vir veranderlike bewerkings met ander verwysings, soos in `*v = 1;`.
///
/// Benewens dat dit gebruik word vir eksplisiete dereferensie-bewerkings met die (unary) `*`-operateur in veranderlike kontekste, word `DerefMut` ook in baie omstandighede implisiet deur die samesteller gebruik.
/// Hierdie meganisme word ['`Deref` coercion'][more] genoem.
/// In onveranderlike kontekste word [`Deref`] gebruik.
///
/// Die implementering van `DerefMut` vir slim aanwysers maak die data agter hulle maklik om te verander, daarom implementeer hulle `DerefMut`.
/// Aan die ander kant is die reëls rakende [`Deref`] en `DerefMut` spesifiek ontwerp om slim aanwysers te akkommodeer.
/// As gevolg hiervan moet **`DerefMut` slegs geïmplementeer word vir slim aanwysers** om verwarring te voorkom.
///
/// Om soortgelyke redes moet **hierdie trait nooit misluk nie**.Mislukking tydens ereferensies kan uiters verwarrend wees as u implisiet op `DerefMut` beroep.
///
/// # Meer oor `Deref` dwang
///
/// As `T` `DerefMut<Target = U>` implementeer en `x` 'n waarde van die tipe `T` is, dan:
///
/// * In veranderlike kontekste is `*x` (waar `T` nie 'n verwysing of 'n rou wyser is nie) gelykstaande aan `* DerefMut::deref_mut(&mut x)`.
/// * Waardes van tipe `&mut T` word gedwing tot waardes van tipe `&mut U`
/// * `T` implementeer implisiet al die (mutable)-metodes van die tipe `U`.
///
/// Vir meer besonderhede, besoek [the chapter in *The Rust Programming Language*][book] asook die verwysingsafdelings oor [the dereference operator][ref-deref-op], [method resolution] en [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// 'N Struktuur met een enkele veld wat veranderbaar is deur die struktuur te verwys.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Verander die waarde veranderlik.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Dui aan dat 'n struktuur as 'n metode-ontvanger gebruik kan word, sonder die `arbitrary_self_types`-funksie.
///
/// Dit word geïmplementeer deur stdlib-wysertipes soos `Box<T>`, `Rc<T>`, `&T` en `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}