//! 'N Module om met geleende data te werk.

#![stable(feature = "rust1", since = "1.0.0")]

/// 'N trait vir die leen van data.
///
/// In Rust is dit algemeen om verskillende voorstellings van 'n soort vir verskillende gebruiksgevalle te gee.
/// Stoorplek en bestuur vir 'n waarde kan byvoorbeeld spesifiek gekies word as toepaslik vir 'n spesifieke gebruik via wysertipes soos [`Box<T>`] of [`Rc<T>`].
/// Behalwe hierdie generiese verpakkings wat met enige soort gebruik kan word, bied sommige tipes opsionele fasette wat potensieel duur funksionaliteit bied.
/// 'N Voorbeeld vir so 'n tipe is [`String`], wat die moontlikheid toevoeg om 'n string na die basiese [`str`] uit te brei.
/// Dit vereis dat u addisionele inligting onnodig hou vir 'n eenvoudige, onveranderlike string.
///
/// Hierdie tipes bied toegang tot die onderliggende data deur verwysings na die tipe data.Daar word gesê dat hulle die tipe 'geleen is'.
/// 'N [`Box<T>`] kan byvoorbeeld as `T` geleen word, terwyl 'n [`String`] as `str` geleen kan word.
///
/// Tipes gee te kenne dat hulle as een of ander tipe `T` geleen kan word deur `Borrow<T>` te implementeer, wat 'n verwysing na 'n `T` in die trait se [`borrow`]-metode bied.'N Tipe is vry om te leen as verskillende soorte.
/// As dit veranderbaar wil wees as die tipe-sodat die onderliggende data gewysig kan word, kan dit [`BorrowMut<T>`] ook implementeer.
///
/// Verder, wanneer implementerings vir addisionele traits aangebied word, moet daar gekyk word of hulle identies moet optree as dié van die onderliggende tipe as gevolg van die optrede van die onderliggende tipe.
/// Generiese kode gebruik gewoonlik `Borrow<T>` as dit afhanklik is van dieselfde gedrag van hierdie addisionele trait-implementasies.
/// Hierdie traits sal waarskynlik as addisionele trait bounds verskyn.
///
/// In die besonder moet `Eq`, `Ord` en `Hash` ekwivalent wees vir geleende en besitwaardes: `x.borrow() == y.borrow()` moet dieselfde resultaat as `x == y` gee.
///
/// As generiese kode slegs moet werk vir alle soorte wat 'n verwysing kan gee na verwante tipe `T`, is dit dikwels beter om [`AsRef<T>`] te gebruik, aangesien meer soorte dit veilig kan implementeer.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// As data-insameling besit [`HashMap<K, V>`] beide sleutels en waardes.As die werklike data van die sleutel toegedraai word in 'n soort bestuur, moet dit steeds moontlik wees om na 'n waarde te soek met verwysing na die data van die sleutel.
/// As die sleutel byvoorbeeld 'n string is, word dit waarskynlik saam met die hashkaart as 'n [`String`] gestoor, terwyl dit moontlik sou wees om met 'n [`&str`][`str`] te soek.
/// Dus moet `insert` op 'n `String` werk, terwyl `get` 'n `&str` moet kan gebruik.
///
/// Effens vereenvoudig, die relevante dele van `HashMap<K, V>` lyk soos volg:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // velde weggelaat
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Die hele hashkaart is generies oor 'n sleuteltipe `K`.Omdat hierdie sleutels op die hash-kaart gestoor word, moet hierdie tipe die data van die sleutel besit.
/// As u 'n sleutelwaarde-paar invoeg, kry die kaart so 'n `K` en moet dit die regte hash-emmer vind en kyk of die sleutel alreeds op die `K` is.Dit vereis dus `K: Hash + Eq`.
///
/// As u na 'n waarde op die kaart moet soek, moet u egter altyd so 'n waarde skep as u 'n verwysing na 'n `K` as sleutel moet soek om na te soek.
/// Vir toutjiesleutels beteken dit dat 'n `String`-waarde geskep moet word net vir die soeke na gevalle waar slegs 'n `str` beskikbaar is.
///
/// In plaas daarvan is die `get`-metode generies oor die tipe onderliggende sleuteldata, genaamd `Q` in die metodehandtekening hierbo.Dit lui dat `K` as 'n `Q` leen deur die `K: Borrow<Q>` te vereis.
/// Deur ook `Q: Hash + Eq` te vereis, dui dit aan dat `K` en `Q` implementasies van die `Hash` en `Eq` traits moet hê wat dieselfde resultate lewer.
///
/// Die implementering van `get` berus veral op identiese implementasies van `Hash` deur die hash-emmer van die sleutel te bepaal deur `Hash::hash` op die `Q`-waarde aan te roep, alhoewel dit die sleutel ingevoeg het op grond van die hash-waarde bereken uit die `K`-waarde.
///
///
/// As gevolg hiervan breek die hashkaart as 'n `K` wat 'n `Q`-waarde omvou, 'n ander hash as `Q` lewer.Stel jou voor dat jy 'n tipe het wat 'n tou omhul, maar ASCII-letters vergelyk wat die geval nie ignoreer nie:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Omdat twee gelyke waardes dieselfde hashwaarde moet lewer, moet die implementering van `Hash` ook die ASCII-geval ignoreer:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Kan `CaseInsensitiveString` `Borrow<str>` implementeer?Dit kan beslis 'n verwysing na 'n snysnit via sy string bevat.
/// Maar omdat die `Hash`-implementering daarvan verskil, tree dit anders op as `str` en moet dit dus eintlik nie `Borrow<str>` implementeer nie.
/// As dit ander mense toegang tot die onderliggende `str` wil gee, kan dit dit doen via `AsRef<str>`, wat nie ekstra vereistes het nie.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Leen onveranderlik van 'n waarde wat besit word.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// 'N trait om data te verander.
///
/// As 'n metgesel van [`Borrow<T>`] kan hierdie trait 'n tipe leen as 'n onderliggende tipe deur 'n veranderlike verwysing te verskaf.
/// Raadpleeg [`Borrow<T>`] vir meer inligting oor lenings as 'n ander tipe.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Leen onderling van 'n waarde wat besit word.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}