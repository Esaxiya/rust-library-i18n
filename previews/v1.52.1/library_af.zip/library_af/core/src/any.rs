//! Hierdie module implementeer die `Any` trait, wat dinamiese tikwerk van enige `'static`-tipe moontlik maak deur middel van looptydrefleksie.
//!
//! `Any` self kan gebruik word om 'n `TypeId` te kry, en het meer funksies as dit as 'n trait-voorwerp gebruik word.
//! As `&dyn Any` ('n geleende trait-voorwerp), het dit die `is`-en `downcast_ref`-metodes om te toets of die inhoud daarvan van 'n gegewe tipe is, en om die innerlike waarde as 'n verwysing te kry.
//! As `&mut dyn Any` is daar ook die `downcast_mut`-metode om 'n veranderlike verwysing na die innerlike waarde te kry.
//! `Box<dyn Any>` voeg die `downcast`-metode by, wat probeer om na 'n `Box<T>` om te skakel.
//! Raadpleeg die [`Box`]-dokumentasie vir die volledige besonderhede.
//!
//! Let op dat `&dyn Any` beperk is tot die toets of 'n waarde van 'n spesifieke beton is, en dat dit nie gebruik kan word om te toets of 'n tipe 'n trait implementeer nie.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Slim aanwysers en `dyn Any`
//!
//! Een gedrag wat u in gedagte moet hou as u `Any` as 'n trait-voorwerp gebruik, veral met soorte soos `Box<dyn Any>` of `Arc<dyn Any>`, is dat bloot die oproep van `.type_id()` op die waarde die `TypeId` van die *houer* sal produseer, nie die onderliggende trait-voorwerp nie.
//!
//! Dit kan vermy word deur die slim wyser in 'n `&dyn Any` te omskep, wat die `TypeId` van die voorwerp sal teruggee.
//! Byvoorbeeld:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Dit is meer waarskynlik dat u dit wil hê:
//! let actual_id = (&*boxed).type_id();
//! // ... as dit:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Beskou 'n situasie waarin ons 'n waarde wat aan 'n funksie oorgedra word, wil uitteken.
//! Ons weet wat die waarde is waarmee ons Debug implementeer, maar ons ken nie die konkrete tipe nie.Ons wil sekere soorte spesiaal behandel: in hierdie geval druk u die lengte van die stringwaardes voor die waarde daarvan uit.
//! Ons weet nie wat die konkrete waarde van ons waarde tydens kompileringstyd is nie, en daarom moet ons eerder 'runtime refleksie' gebruik.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Logger-funksie vir enige tipe wat Debug implementeer.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Probeer om ons waarde na 'n `String` om te skakel.
//!     // As dit suksesvol is, wil ons die lengte van die string sowel as die waarde daarvan uitvoer.
//!     // Indien nie, is dit 'n ander tipe: druk dit net onversierd uit.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Hierdie funksie wil sy parameter uitlog voordat hy daarmee werk.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... doen ander werk
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Enige trait
///////////////////////////////////////////////////////////////////////////////

/// 'N trait om dinamiese tik na te boots.
///
/// Die meeste soorte implementeer `Any`.Enige tipe wat 'n nie-'statiese 'verwysing bevat, is egter nie so nie.
/// Raadpleeg die [module-level documentation][mod] vir meer besonderhede.
///
/// [mod]: crate::any
// Hierdie trait is nie onveilig nie, maar ons vertrou op die besonderhede van die `type_id`-funksie van sy enigste in onveilige kode (bv. `downcast`).Normaalweg sou dit 'n probleem wees, maar omdat die enigste implikasie van `Any` 'n dekenimplementering is, kan geen ander kode `Any` implementeer nie.
//
// Ons kan hierdie trait onwaarskynlik maak-dit sal nie breek veroorsaak nie, aangesien ons al die implementerings beheer-maar ons kies om dit nie te doen nie, want dit is nie regtig nodig nie en kan gebruikers verwar oor die onderskeid tussen onveilige traits en onveilige metodes (dws `type_id` kan steeds veilig gebel word, maar ons wil dit waarskynlik in die dokumentasie aandui).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Kry die `TypeId` van `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Uitbreidingsmetodes vir enige trait-voorwerpe.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Verseker dat die resultaat van bv. Die koppeling van 'n draad afgedruk kan word en dus saam met `unwrap` gebruik kan word.
// Miskien sal dit uiteindelik nie meer nodig wees as versending met opstootwerk werk nie.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Wys `true` as die tipe boks dieselfde is as `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Kry `TypeId` van die tipe waarmee hierdie funksie geïnstalleer word.
        let t = TypeId::of::<T>();

        // Kry `TypeId` van die tipe in die trait-voorwerp (`self`).
        let concrete = self.type_id();

        // Vergelyk albei die TypeId`s oor gelykheid.
        t == concrete
    }

    /// Wys 'n verwysing na die ingevoegde waarde as dit van die tipe `T` is, of `None` as dit nie is nie.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // VEILIGHEID: kyk net of ons na die regte tipe verwys, en ons kan daarop vertrou
            // wat kyk vir geheueveiligheid omdat ons Any vir alle soorte geïmplementeer het;geen ander impls kan bestaan nie, want dit sou bots met ons impl.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Wys 'n mate van veranderlike verwysing na die ingevoegde waarde as dit van die tipe `T` is, of `None` as dit nie is nie.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // VEILIGHEID: kyk net of ons na die regte tipe verwys, en ons kan daarop vertrou
            // wat kyk vir geheueveiligheid omdat ons Any vir alle soorte geïmplementeer het;geen ander impls kan bestaan nie, want dit sou bots met ons impl.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Stuur deur na die metode wat op die tipe `Any` gedefinieer word.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Stuur deur na die metode wat op die tipe `Any` gedefinieer word.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Stuur deur na die metode wat op die tipe `Any` gedefinieer word.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Stuur deur na die metode wat op die tipe `Any` gedefinieer word.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Stuur deur na die metode wat op die tipe `Any` gedefinieer word.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Stuur deur na die metode wat op die tipe `Any` gedefinieer word.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID en die metodes daarvan
///////////////////////////////////////////////////////////////////////////////

/// 'N `TypeId` verteenwoordig 'n wêreldwye unieke identifiseerder vir 'n tipe.
///
/// Elke `TypeId` is 'n ondeursigtige voorwerp wat die inspeksie van die binnekant nie toelaat nie, maar wel basiese bewerkings soos kloning, vergelyking, druk en vertoon.
///
///
/// 'N `TypeId` is tans slegs beskikbaar vir soorte wat aan `'static` toegeskryf word, maar hierdie beperking kan in die future verwyder word.
///
/// Terwyl `TypeId` `Hash`, `PartialOrd` en `Ord` implementeer, is dit opmerklik dat die hashes en bestelling tussen die Rust-weergawes sal wissel.
/// Pasop dat u daarop vertrou in u kode!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Wys die `TypeId` van die tipe waarmee hierdie generiese funksie geïnstalleer is.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Wys die naam van 'n tipe as 'n snysnit.
///
/// # Note
///
/// Dit is bedoel vir diagnostiese gebruik.
/// Die presiese inhoud en formaat van die string wat teruggestuur word, word nie gespesifiseer nie, behalwe dat dit 'n besondere beskrywing van die tipe is.
/// Onder die snare wat `type_name::<Option<String>>()` kan teruggee, is byvoorbeeld `"Option<String>"` en `"std::option::Option<std::string::String>"`.
///
///
/// Die teruggekeerde string moet nie as 'n unieke identifiseerder van 'n tipe beskou word nie, aangesien veelvoudige tipes op dieselfde tipe naam kan toewys.
/// Daar is ook geen waarborg dat alle dele van 'n tipe in die teruggekeerde string sal verskyn nie; byvoorbeeld, lewenslange spesifikasies is tans nie ingesluit nie.
/// Daarbenewens kan die uitvoer verander tussen die weergawes van die samesteller.
///
/// Die huidige implementering gebruik dieselfde infrastruktuur as die samestellerdiagnostiek en debuginfo, maar dit word nie gewaarborg nie.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Wys die naam van die tipe aangeduide waarde as 'n snysnit.
/// Dit is dieselfde as `type_name::<T>()`, maar kan gebruik word waar die tipe veranderlike nie maklik beskikbaar is nie.
///
/// # Note
///
/// Dit is bedoel vir diagnostiese gebruik.Die presiese inhoud en formaat van die string word nie gespesifiseer nie, behalwe dat dit die beste poging is om die tipe te beskryf.
/// `type_name_of_val::<Option<String>>(None)` kan byvoorbeeld `"Option<String>"` of `"std::option::Option<std::string::String>"` teruggee, maar nie `"foobar"` nie.
///
/// Daarbenewens kan die uitvoer verander tussen die weergawes van die samesteller.
///
/// Hierdie funksie los nie trait-voorwerpe op nie, wat beteken dat `type_name_of_val(&7u32 as &dyn Debug)` `"dyn Debug"` mag terugstuur, maar nie `"u32"` nie.
///
/// Die tipe naam moet nie as 'n unieke identifiseerder van 'n tipe beskou word nie;
/// verskeie soorte kan dieselfde tipe naam deel.
///
/// Die huidige implementering gebruik dieselfde infrastruktuur as die samestellerdiagnostiek en debuginfo, maar dit word nie gewaarborg nie.
///
/// # Examples
///
/// Druk die verstek tipes heelgetal en vlot.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}