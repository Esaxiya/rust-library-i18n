use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Alhoewel hierdie funksie op een plek gebruik word en die implementering daarvan kan wees, kan rustc stadiger wees met die vorige pogings om dit te doen:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Uitleg van 'n blok geheue.
///
/// 'N Voorbeeld van `Layout` beskryf 'n spesifieke uitleg van die geheue.
/// U bou 'n `Layout` op as 'n inset om aan 'n toewyser te gee.
///
/// Alle uitlegte het 'n gepaardgaande grootte en 'n krag-van-twee-belyning.
///
/// (Let daarop dat uitlegte *nie* nodig is om nie-nul-grootte te hê nie, alhoewel `GlobalAlloc` vereis dat alle geheueversoeke nie nul in grootte moet wees nie.
/// 'N Beller moet seker maak dat daar aan hierdie voorwaardes voldoen word, spesifieke toewysers met laer vereistes gebruik, of die sagter `Allocator`-koppelvlak gebruik.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // grootte van die gevraagde geheue-blok, gemeet in grepe.
    size_: usize,

    // belyning van die gevraagde geheue-blok, gemeet in grepe.
    // ons verseker dat dit altyd 'n krag-van-twee is, want API's soos `posix_memalign` vereis dit en dit is 'n redelike beperking om Layout-konstrukteurs op te lê.
    //
    //
    // (Ons benodig egter nie analoog `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.) nie
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Konstrueer 'n `Layout` vanaf 'n gegewe `size` en `align`, of lewer `LayoutError` op as daar aan geen van die volgende voorwaardes voldoen word nie:
    ///
    /// * `align` moet nie nul wees nie,
    ///
    /// * `align` moet 'n krag van twee wees,
    ///
    /// * `size`, as dit afgerond word tot die naaste veelvoud van `align`, mag dit nie oorloop nie (dws die afgeronde waarde moet kleiner as of gelyk wees aan `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (krag-van-twee impliseer belyning!=0.)

        // Afgeronde grootte is:
        //   size_rounded_up=(size + align, 1)&! (align, 1);
        //
        // Ons weet van bo af dat dit ooreenstem!=0.
        // As optel (align, 1) nie oorloop nie, sal afronding goed wees.
        //
        // Omgekeerd sal&-maskering met! (Align, 1) slegs lae-orde-bits aftrek.
        // As oorloop dus met die som voorkom, kan die&-masker nie genoeg aftrek om daardie oorloop ongedaan te maak nie.
        //
        //
        // Bogenoemde impliseer dat dit nodig en voldoende is om na somervloei te kyk.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // VEILIGHEID: die voorwaardes vir `from_size_align_unchecked` was
        // hierbo nagegaan.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Skep 'n uitleg en omseil alle tjeks.
    ///
    /// # Safety
    ///
    /// Hierdie funksie is onveilig, aangesien dit nie die voorwaardes van [`Layout::from_size_align`] bevestig nie.
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // VEILIGHEID: die beller moet toesien dat `align` groter as nul is.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Die minimum grootte in grepe vir 'n geheueblok van hierdie uitleg.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Die minimum byte-belyning vir 'n geheueblok van hierdie uitleg.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Stel 'n `Layout` op wat geskik is om 'n waarde van die tipe `T` te hou.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // VEILIGHEID: die lyn word gewaarborg deur Rust om 'n krag van twee en te wees
        // die kombinasie size + align sal gewaarborg word in ons adresruimte.
        // Gebruik gevolglik die ongemerkte konstrukteur hier om te verhoed dat u die kode panics invoeg as dit nie goed genoeg is nie.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produseer 'n uitleg wat 'n rekord beskryf wat gebruik kan word om rugstruktuur vir `T` toe te ken (wat 'n trait of 'n ander ongroot grootte soos 'n sny kan wees).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // VEILIGHEID: sien die rede in `new` waarom dit die onveilige variant gebruik
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produseer 'n uitleg wat 'n rekord beskryf wat gebruik kan word om rugstruktuur vir `T` toe te ken (wat 'n trait of 'n ander ongroot grootte soos 'n sny kan wees).
    ///
    /// # Safety
    ///
    /// Hierdie funksie is slegs veilig om te skakel as die volgende voorwaardes geld:
    ///
    /// - As `T` `Sized` is, is hierdie funksie altyd veilig om te skakel.
    /// - As die ongroot grootte stert van `T` die volgende is:
    ///     - 'n [slice], dan moet die lengte van die snytestert 'n geïntialiseerde heelgetal wees, en die grootte van die *hele waarde*(dinamiese stertlengte + voorvoegsel met statiese grootte) moet in `isize` pas.
    ///     - 'n [trait object], dan moet die vtabelgedeelte van die aanwyser wys na 'n geldige vtabel vir die tipe `T` wat verkry word deur 'n onbeduidende dwang, en die grootte van die *hele waarde*(dinamiese stertlengte + voorvoegsel staties) moet in `isize` pas.
    ///
    ///     - 'n (unstable) [extern type], dan is hierdie funksie altyd veilig om te skakel, maar kan panic of andersins die verkeerde waarde oplewer, aangesien die uitleg van die eksterne tipe nie bekend is nie.
    ///     Dit is dieselfde gedrag as [`Layout::for_value`] op 'n verwysing na 'n eksterne stert.
    ///     - anders is dit konserwatief nie toegelaat om hierdie funksie te noem nie.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // VEILIGHEID: ons gee die voorvereistes van hierdie funksies deur aan die oproeper
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // VEILIGHEID: sien die rede in `new` waarom dit die onveilige variant gebruik
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Skep 'n `NonNull` wat hangend is, maar goed belyn vir hierdie uitleg.
    ///
    /// Let daarop dat die wyserwaarde moontlik 'n geldige wyser kan voorstel, wat beteken dat dit nie as 'n "not yet initialized"-sentinelwaarde gebruik mag word nie.
    /// Tipes wat lui toewys, moet die initialisering op 'n ander manier volg.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // VEILIGHEID: die opstel is gewis nie-nul
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Skep 'n uitleg wat die rekord beskryf wat 'n waarde van dieselfde uitleg as `self` kan bevat, maar wat ook in lyn is met die belyning `align` (gemeet in grepe).
    ///
    ///
    /// As `self` reeds aan die voorgeskrewe belyning voldoen, gee `self` terug.
    ///
    /// Let daarop dat hierdie metode geen vulling by die algehele grootte voeg nie, ongeag of die teruggestelde uitleg 'n ander belyning het.
    /// Met ander woorde, as `K` grootte 16 het, sal `K.align_to(32)`*steeds* grootte 16 hê.
    ///
    /// Wys 'n fout as die kombinasie van `self.size()` en die gegewe `align` die voorwaardes in [`Layout::from_size_align`] oortree.
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Wys die hoeveelheid vulling wat ons na `self` moet invoeg om te verseker dat die volgende adres aan die `align` (gemeet in grepe) sal voldoen.
    ///
    /// Byvoorbeeld, as `self.size()` 9 is, dan gee `self.padding_needed_for(4)` 3 terug, want dit is die minimum aantal bytes vulling wat benodig word om 'n 4-gerigte adres te kry (met die veronderstelling dat die ooreenstemmende geheue-blok by 'n 4-gerigte adres begin).
    ///
    ///
    /// Die terugkeerwaarde van hierdie funksie het geen betekenis as `align` nie 'n krag-van-twee is nie.
    ///
    /// Let daarop dat die nut van die teruggekeerde waarde vereis dat `align` kleiner of gelyk is aan die belyning van die beginadres vir die hele geheue-blok.Een manier om aan hierdie beperking te voldoen, is om `align <= self.align()` te verseker.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Afgeronde waarde is:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // en dan gee ons die vullingsverskil terug: `len_rounded_up - len`.
        //
        // Ons gebruik deurgaans modulêre rekenkunde:
        //
        // 1. align is gewaarborg om> 0 te wees, so align, 1 is altyd geldig.
        //
        // 2.
        // `len + align - 1` kan hoogstens `align - 1` oorloop, dus sal die&-masker met `!(align - 1)` sorg dat `len_rounded_up` in die geval van oorloop self 0 sal wees.
        //
        //    Die teruggevulde vulling lewer dus 0 as dit by `len` gevoeg word, wat triviaal voldoen aan die belyning `align`.
        //
        // (Natuurlik moet pogings om geheue-blokke toe te ken waarvan die grootte en vulling op die bostaande wyse oorloop, die toewyser in elk geval 'n fout laat oplewer.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Skep 'n uitleg deur die grootte van hierdie uitleg af te rond tot 'n veelvoud van die uitleg se belyning.
    ///
    ///
    /// Dit is gelykstaande aan die toevoeging van die resultaat van `padding_needed_for` tot die huidige grootte van die uitleg.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Dit kan nie oorloop nie.Aanhaling van die invariant van Layout:
        // > `size`, wanneer dit afgerond word tot die naaste veelvoud van `align`,
        // > moet nie oorloop nie (dws die afgeronde waarde moet kleiner wees as
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Skep 'n uitleg waarin die rekord vir `n`-gevalle van `self` beskryf word, met 'n geskikte hoeveelheid vulling tussen elkeen om te verseker dat elke instansie die gevraagde grootte en belyning kry.
    /// Na sukses gee `(k, offs)` terug, waar `k` die uitleg van die skikking is en `offs` die afstand is tussen die begin van elke element in die skikking.
    ///
    /// Op rekenkundige oorloop, gee `LayoutError` terug.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Dit kan nie oorloop nie.Aanhaling van die invariant van Layout:
        // > `size`, wanneer dit afgerond word tot die naaste veelvoud van `align`,
        // > moet nie oorloop nie (dws die afgeronde waarde moet kleiner wees as
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // VEILIGHEID: dit is bekend dat self.align geldig is en dat die toekenningsgrootte al was
        // opgestop al.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Skep 'n uitleg wat die rekord vir `self` beskryf, gevolg deur `next`, insluitend die nodige opvulling om te verseker dat `next` behoorlik in lyn is, maar *geen agterste vulling nie*.
    ///
    /// Om die voorstellingsuitleg `repr(C)` van C te pas, moet u `pad_to_align` skakel nadat u die uitleg met alle velde uitgebrei het.
    /// (Daar is geen manier om die standaard Rust-voorstellingsuitleg `repr(Rust)`, as it is unspecified.) te pas nie
    ///
    /// Let daarop dat die belyning van die resulterende uitleg die maksimum is as dié van `self` en `next`, ten einde die belyning van beide dele te verseker.
    ///
    /// Wys `Ok((k, offset))`, waar `k` die uitleg is van die aaneengeskakelde rekord en `offset` die relatiewe ligging in byte is van die begin van die `next` wat in die aaneengeskakelde rekord ingebed is (met die veronderstelling dat die rekord self begin by verrekening 0).
    ///
    ///
    /// Op rekenkundige oorloop, gee `LayoutError` terug.
    ///
    /// # Examples
    ///
    /// Om die uitleg van 'n `#[repr(C)]`-struktuur en die verrekening van die velde vanaf die velde se uitlegte te bereken:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Onthou om met `pad_to_align` te finaliseer!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // toets dat dit werk
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Skep 'n uitleg wat die rekord vir `n`-gevalle van `self` beskryf, met geen vulling tussen elke instansie nie.
    ///
    /// Let op dat `repeat_packed`, in teenstelling met `repeat`, nie waarborg dat die herhaalde gevalle van `self` behoorlik in lyn sal wees nie, selfs al is 'n gegewe voorbeeld van `self` behoorlik in lyn gebring.
    /// Met ander woorde, as die uitleg wat deur `repeat_packed` teruggestuur word, gebruik word om 'n skikking toe te ken, is dit nie gewaarborg dat alle elemente in die skikking behoorlik in lyn sal wees nie.
    ///
    /// Op rekenkundige oorloop, gee `LayoutError` terug.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Skep 'n uitleg wat die rekord vir `self` beskryf, gevolg deur `next`, met geen ekstra vulling tussen die twee nie.
    /// Aangesien geen vulling ingevoeg is nie, is die belyning van `next` irrelevant en is dit glad nie * opgeneem in die gevolglike uitleg nie.
    ///
    ///
    /// Op rekenkundige oorloop, gee `LayoutError` terug.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Skep 'n uitleg wat die rekord van 'n `[T; n]` beskryf.
    ///
    /// Op rekenkundige oorloop, gee `LayoutError` terug.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Die parameters wat aan `Layout::from_size_align` of 'n ander `Layout`-konstrukteur gegee word, voldoen nie aan die gedokumenteerde beperkings nie.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (ons het dit nodig vir stroomaf impl. van trait Fout)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}