use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// 'N Geheue-toewyser wat deur die `#[global_allocator]`-kenmerk as die standaardbiblioteek geregistreer kan word.
///
/// Sommige van die metodes vereis dat 'n geheueblok *tans* toegeken word via 'n toewyser.Dit beteken dat:
///
/// * die beginadres vir die geheue-blok is vroeër deur 'n vorige oproep na 'n toekenningsmetode soos `alloc`, en
///
/// * die geheueblok is nie vervolgens geallokeer nie, waar blokke geallokeer word, óf deur na 'n deallocation-metode soos `dealloc`, óf deur 'n her-allocation-metode wat 'n nie-nul-wyser teruggee, oorgedra word.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// Die `GlobalAlloc` trait is om 'n aantal redes 'n `unsafe` trait en implementeerders moet toesien dat hulle hierdie kontrakte nakom:
///
/// * Dit is ongedefinieerde gedrag as wêreldwye toewysers ontspanne.Hierdie beperking kan in die future opgehef word, maar tans kan 'n panic van enige van hierdie funksies lei tot geheueveiligheid.
///
/// * `Layout` navrae en berekeninge in die algemeen moet korrek wees.Bellers van hierdie trait mag vertrou op die kontrakte wat volgens elke metode gedefinieer word, en implementeerders moet toesien dat sulke kontrakte waar bly.
///
/// * U mag nie daarop vertrou dat toewysings werklik plaasvind nie, selfs al is daar eksplisiete hope toewysings in die bron.
/// Die optimaliseerder kan ongebruikte toekennings opspoor wat dit heeltemal kan elimineer of na die stapel kan beweeg en sodoende nooit die toekenning kan aanroep nie.
/// Die optimaliseerder kan verder aanneem dat die toekenning onfeilbaar is, dus kan kode wat vroeër misluk het as gevolg van mislukkings van die toewyser, nou skielik werk omdat die optimaliseerder die behoefte aan 'n toekenning nagegaan het.
/// Meer konkreet, die volgende kode-voorbeeld is nie gesond nie, ongeag of u persoonlike toewyser toelaat om te tel hoeveel toewysings gebeur het.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Let daarop dat die bogenoemde optimalisasies nie die enigste optimalisering is wat toegepas kan word nie.Gewoonlik vertrou u gewoonlik nie op die toewysing van hope as dit verwyder kan word sonder om die gedrag van die program te verander nie.
///   Of toekennings plaasvind of nie, maak nie deel uit van die programgedrag nie, selfs al kan dit opgespoor word deur 'n toewyser wat toekennings opspoor deur te druk of andersins newe-effekte het.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Ken geheue toe soos beskryf deur die gegewe `layout`.
    ///
    /// Wys 'n wyser na die nuut toegedeelde geheue, of nul om die toewysingsmislukking aan te dui.
    ///
    /// # Safety
    ///
    /// Hierdie funksie is onveilig, want ongedefinieerde gedrag kan tot gevolg hê as die oproeper nie verseker dat `layout` die grootte nie van nul het nie.
    ///
    /// (Uitbreidingsonderdele kan meer spesifieke perke vir gedrag bied, byvoorbeeld om 'n wagadres of 'n nulaanwyser te waarborg in antwoord op 'n nulgrootte-toekenningsversoek.)
    ///
    /// Die toegekende blok geheue kan wel of nie geïnisialiseer word nie.
    ///
    /// # Errors
    ///
    /// As u 'n nulwyser terugbesorg, dui dit aan dat die geheue leeg is, of dat `layout` nie aan die toewysingsbeperkings of-beperkings voldoen nie.
    ///
    /// Implementasies word aangemoedig om nul te wees op geheue-uitputting eerder as om te staak, maar dit is nie 'n streng vereiste nie.
    /// (Spesifiek: dit is *wettig* om hierdie trait bo-op 'n onderliggende inheemse toewysingsbiblioteek te implementeer wat op geheue-uitputting afbreek.)
    ///
    /// Kliënte wat die berekening wil staak as gevolg van 'n toewysingsfout, word aangemoedig om die [`handle_alloc_error`]-funksie te skakel eerder as om `panic!` of soortgelyk aan te roep.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Plaas die geheueblok by die gegewe `ptr`-wyser met die gegewe `layout`.
    ///
    /// # Safety
    ///
    /// Hierdie funksie is onveilig omdat ongedefinieerde gedrag tot gevolg kan hê as die oproeper nie al die volgende verseker nie:
    ///
    ///
    /// * `ptr` moet 'n blok geheue aandui wat tans deur hierdie toewyser toegeken word,
    ///
    /// * `layout` dieselfde uitleg moet wees wat gebruik is om die geheue-blok toe te ken.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Gedra hom soos `alloc`, maar sorg ook dat die inhoud op nul gestel word voordat dit terugbesorg word.
    ///
    /// # Safety
    ///
    /// Hierdie funksie is om dieselfde redes as `alloc` onveilig.
    /// Die toegewysde blok geheue sal egter gewaarborg word.
    ///
    /// # Errors
    ///
    /// As u 'n nulwyser terugstuur, dui dit aan dat die geheue leeg is, of dat die `layout` nie aan die grootte-of belyningsbeperkings van die toewyser voldoen nie, net soos in `alloc`.
    ///
    /// Kliënte wat die berekening wil staak as gevolg van 'n toewysingsfout, word aangemoedig om die [`handle_alloc_error`]-funksie te skakel eerder as om `panic!` of soortgelyk aan te roep.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // VEILIGHEID: die veiligheidskontrak vir `alloc` moet deur die oproeper gehandhaaf word.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // VEILIGHEID: namate die toekenning geslaag het, die streek vanaf `ptr`
            // van grootte `size` is gewaarborg om geldig te wees vir skryfwerk.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Verklein of groei 'n blok geheue na die gegewe `new_size`.
    /// Die blok word beskryf deur die gegewe `ptr`-aanwyser en `layout`.
    ///
    /// As dit 'n nie-nul-wyser gee, dan is die eienaarskap van die geheueblok waarna `ptr` verwys, oorgedra aan hierdie toewyser.
    /// Die geheue is al dan nie gedeallokeer en moet as onbruikbaar beskou word (tensy dit natuurlik weer na die oproeper oorgedra is via die retourwaarde van hierdie metode).
    /// Die nuwe geheue-blok is toegeken aan `layout`, maar met die `size` opgedateer na `new_size`.
    /// Hierdie nuwe uitleg moet gebruik word wanneer die nuwe geheue-blok met `dealloc` geplaas word.
    /// Die reeks `0..min(layout.size(), new_size) `van die nuwe geheue-blok het gewaarborg dieselfde waardes as die oorspronklike blok.
    ///
    /// As hierdie metode nul is, is die eienaarskap van die geheueblok nie aan hierdie toewyser oorgedra nie, en is die inhoud van die geheueblok onveranderd.
    ///
    /// # Safety
    ///
    /// Hierdie funksie is onveilig omdat ongedefinieerde gedrag tot gevolg kan hê as die oproeper nie al die volgende verseker nie:
    ///
    /// * `ptr` moet tans via hierdie toekenning toegeken word,
    ///
    /// * `layout` dieselfde uitleg moet wees wat gebruik is om die geheue-blok toe te ken,
    ///
    /// * `new_size` moet groter as nul wees.
    ///
    /// * `new_size`, as dit afgerond word tot die naaste veelvoud van `layout.align()`, mag dit nie oorloop nie (dws die afgeronde waarde moet minder as `usize::MAX` wees).
    ///
    /// (Uitbreidingsonderdele kan meer spesifieke perke vir gedrag bied, byvoorbeeld om 'n wagadres of 'n nulaanwyser te waarborg in antwoord op 'n nulgrootte-toekenningsversoek.)
    ///
    /// # Errors
    ///
    /// Wys null as die nuwe uitleg nie aan die beperkinge van grootte en belyning van die toewyser voldoen nie, of as die hertoewysing anders misluk.
    ///
    /// Implementasies word aangemoedig om nul te wees op geheue-uitputting eerder as om paniekerig te raak of te aborteer, maar dit is nie 'n streng vereiste nie.
    /// (Spesifiek: dit is *wettig* om hierdie trait bo-op 'n onderliggende inheemse toewysingsbiblioteek te implementeer wat op geheue-uitputting afbreek.)
    ///
    /// Kliënte wat die berekening wil staak as gevolg van 'n hertoewysingsfout, word aangemoedig om die [`handle_alloc_error`]-funksie te skakel, eerder as om `panic!` of soortgelyk aan te roep.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // VEILIGHEID: die beller moet toesien dat die `new_size` nie oorloop nie.
        // `layout.align()` kom van 'n `Layout` en is dus gewaarborg om geldig te wees.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // VEILIGHEID: die beller moet toesien dat `new_layout` groter as nul is.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // VEILIGHEID: die blok wat voorheen toegeken is, kan nie die pas toegekende blok oorvleuel nie.
            // Die oproeper moet die veiligheidskontrak vir `dealloc` nakom.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}