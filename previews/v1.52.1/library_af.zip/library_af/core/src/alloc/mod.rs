//! Geheuetoekenning-API's

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Die `AllocError`-fout dui aan dat die toewysingsfout kan wees as gevolg van die uitputting van hulpbronne of iets verkeerd as die gegewe invoerargumente met hierdie toewyser gekombineer word.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (ons het dit nodig vir stroomaf impl. van trait Fout)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// 'N Implementering van `Allocator` kan willekeurige blokke data wat via [`Layout`][] beskryf word, toewys, groei, krimp en hanteer.
///
/// `Allocator` is ontwerp om geïmplementeer te word op ZST's, verwysings of slim aanwysers omdat 'n toewyser soos `MyAlloc([u8; N])` nie geskuif kan word nie, sonder om die wysers na die toegewysde geheue op te dateer.
///
/// Anders as [`GlobalAlloc`][], word toewysings van nul grootte in `Allocator` toegelaat.
/// As 'n onderliggende toewyser dit nie ondersteun nie (soos jemalloc) of 'n nulaanwyser (soos `libc::malloc`) teruggee nie, moet dit vasgevang word deur die implementering.
///
/// ### Geheue wat tans toegeken is
///
/// Sommige van die metodes vereis dat 'n geheueblok *tans* toegeken word via 'n toewyser.Dit beteken dat:
///
/// * die beginadres vir daardie geheue-blok is vroeër deur [`allocate`], [`grow`] of [`shrink`] teruggestuur, en
///
/// * die geheueblok is nie later geallokeer nie, waar blokke direk ge-deallokaliseer word deur na [`deallocate`] oorgedra te word, of verander is deur na [`grow`] of [`shrink`] te stuur wat `Ok` teruggee.
///
/// As `grow` of `shrink` `Err` teruggestuur het, bly die geslaagde wyser geldig.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Geheue pas
///
/// Sommige van die metodes vereis dat 'n uitleg 'n geheue-blok * moet pas.
/// Wat dit beteken vir 'n uitleg op "fit", beteken 'n geheueblok (of ekwivalent, vir 'n geheueblok tot "fit" 'n uitleg) dat die volgende voorwaardes moet geld:
///
/// * Die blok moet toegeken word met dieselfde belyning as [`layout.align()`], en
///
/// * Die [`layout.size()`] wat voorsien word, moet in die reeks `min ..= max` val, waar:
///   - `min` is die grootte van die uitleg wat die laaste tyd gebruik is om die blok toe te ken, en
///   - `max` is die nuutste werklike grootte wat van [`allocate`], [`grow`] of [`shrink`] teruggestuur word.
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Geheue-blokke wat van 'n toewyser teruggestuur word, moet na geldige geheue wys en hul geldigheid behou totdat die instansie en al sy klone laat vaar word,
///
/// * kloning of verskuiwing van die toewyser mag nie die geheue blokke wat van hierdie toewyser teruggestuur word ongeldig maak nie.'N Gekloonde toewyser moet soos dieselfde toewyser optree, en
///
/// * enige wyser na 'n geheue-blok wat [*currently allocated*] is, kan na enige ander metode van die toekenning oorgedra word.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Pogings om 'n blok geheue toe te ken.
    ///
    /// Na sukses, lewer 'n [`NonNull<[u8]>`][NonNull] op wat voldoen aan die grootte-en belyningswaarborge van `layout`.
    ///
    /// Die teruggestuurde blok kan 'n groter grootte hê as wat deur `layout.size()` gespesifiseer word, en die inhoud daarvan kan of nie geïnisialiseer word nie.
    ///
    /// # Errors
    ///
    /// Die terugkeer van `Err` dui aan dat die geheue leeg is, of dat die `layout` nie aan die toewysings-of belyningsbeperkings voldoen nie.
    ///
    /// Implementasies word aangemoedig om `Err` terug te gee op geheue-uitputting eerder as om paniekerig te raak of te staak, maar dit is nie 'n streng vereiste nie.
    /// (Spesifiek: dit is *wettig* om hierdie trait bo-op 'n onderliggende inheemse toewysingsbiblioteek te implementeer wat op geheue-uitputting afbreek.)
    ///
    /// Kliënte wat die berekening wil staak as gevolg van 'n toewysingsfout, word aangemoedig om die [`handle_alloc_error`]-funksie te skakel eerder as om `panic!` of soortgelyk aan te roep.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Gedra hom soos `allocate`, maar sorg ook dat die geheue wat teruggestuur is, nie geïnisialiseer is nie.
    ///
    /// # Errors
    ///
    /// Die terugkeer van `Err` dui aan dat die geheue leeg is, of dat die `layout` nie aan die toewysings-of belyningsbeperkings voldoen nie.
    ///
    /// Implementasies word aangemoedig om `Err` terug te gee op geheue-uitputting eerder as om paniekerig te raak of te staak, maar dit is nie 'n streng vereiste nie.
    /// (Spesifiek: dit is *wettig* om hierdie trait bo-op 'n onderliggende inheemse toewysingsbiblioteek te implementeer wat op geheue-uitputting afbreek.)
    ///
    /// Kliënte wat die berekening wil staak as gevolg van 'n toewysingsfout, word aangemoedig om die [`handle_alloc_error`]-funksie te skakel eerder as om `panic!` of soortgelyk aan te roep.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // VEILIGHEID: `alloc` gee 'n geldige geheue-blok terug
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Dealereer die geheue waarna `ptr` verwys.
    ///
    /// # Safety
    ///
    /// * `ptr` moet 'n blok geheue [*currently allocated*] via hierdie toewyser aandui, en
    /// * `layout` moet die blok geheue [*fit*].
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Pogings om die geheueblok uit te brei.
    ///
    /// Wys 'n nuwe [`NonNull<[u8]>`][NonNull] wat 'n wyser bevat en die werklike grootte van die toegewysde geheue.Die aanwyser is geskik vir die bewaring van data wat deur `new_layout` beskryf word.
    /// Om dit te bewerkstellig, kan die toewyser die toekenning waarna `ptr` verwys, uitbrei om by die nuwe uitleg te pas.
    ///
    /// As dit `Ok` oplewer, is die eienaarskap van die geheueblok waarna `ptr` verwys, aan hierdie toewyser oorgedra.
    /// Die geheue is al dan nie bevry, en moet as onbruikbaar beskou word, tensy dit weer na die oproeper oorgedra is via die retourwaarde van hierdie metode.
    ///
    /// As hierdie metode `Err` oplewer, is die eienaarskap van die geheueblok nie aan hierdie toewyser oorgedra nie en is die inhoud van die geheueblok onveranderd.
    ///
    /// # Safety
    ///
    /// * `ptr` moet 'n blok geheue [*currently allocated*] aandui via hierdie toewyser.
    /// * `old_layout` moet die blok geheue [*fit*] hê (die `new_layout`-argument hoef nie daarby te pas nie.).
    /// * `new_layout.size()` moet groter as of gelyk wees aan `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Wys `Err` as die nuwe uitleg nie voldoen aan die grootte en belyning van die toekenning van die toewyser nie, of as groei anders misluk.
    ///
    /// Implementasies word aangemoedig om `Err` terug te gee op geheue-uitputting eerder as om paniekerig te raak of te staak, maar dit is nie 'n streng vereiste nie.
    /// (Spesifiek: dit is *wettig* om hierdie trait bo-op 'n onderliggende inheemse toewysingsbiblioteek te implementeer wat op geheue-uitputting afbreek.)
    ///
    /// Kliënte wat die berekening wil staak as gevolg van 'n toewysingsfout, word aangemoedig om die [`handle_alloc_error`]-funksie te skakel eerder as om `panic!` of soortgelyk aan te roep.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // VEILIGHEID: omdat `new_layout.size()` groter of gelyk aan moet wees
        // `old_layout.size()`, sowel die ou as die nuwe geheuetoekenning is geldig vir lees en skryf vir `old_layout.size()`-grepe.
        // Omdat die ou toekenning nog nie geallokeer is nie, kan dit nie `new_ptr` oorvleuel nie.
        // Die oproep na `copy_nonoverlapping` is dus veilig.
        // Die oproeper moet die veiligheidskontrak vir `dealloc` nakom.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Gedra hom soos `grow`, maar sorg ook dat die nuwe inhoud op nul gestel word voordat dit terugbesorg word.
    ///
    /// Die geheue blok sal die volgende inhoud bevat na 'n suksesvolle oproep na
    /// `grow_zeroed`:
    ///   * Bytes `0..old_layout.size()` word bewaar vanaf die oorspronklike toekenning.
    ///   * Bytes `old_layout.size()..old_size` sal behoue bly of geassosieer word, afhangende van die implementering van die toewyser.
    ///   `old_size` verwys na die grootte van die geheueblok voor die `grow_zeroed`-oproep, wat groter kan wees as die grootte wat oorspronklik aangevra is toe dit toegeken is.
    ///   * Bytes `old_size..new_size` is nul.`new_size` verwys na die grootte van die geheueblok wat deur die `grow_zeroed`-oproep teruggestuur word.
    ///
    /// # Safety
    ///
    /// * `ptr` moet 'n blok geheue [*currently allocated*] aandui via hierdie toewyser.
    /// * `old_layout` moet die blok geheue [*fit*] hê (die `new_layout`-argument hoef nie daarby te pas nie.).
    /// * `new_layout.size()` moet groter as of gelyk wees aan `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Wys `Err` as die nuwe uitleg nie voldoen aan die grootte en belyning van die toekenning van die toewyser nie, of as groei anders misluk.
    ///
    /// Implementasies word aangemoedig om `Err` terug te gee op geheue-uitputting eerder as om paniekerig te raak of te staak, maar dit is nie 'n streng vereiste nie.
    /// (Spesifiek: dit is *wettig* om hierdie trait bo-op 'n onderliggende inheemse toewysingsbiblioteek te implementeer wat op geheue-uitputting afbreek.)
    ///
    /// Kliënte wat die berekening wil staak as gevolg van 'n toewysingsfout, word aangemoedig om die [`handle_alloc_error`]-funksie te skakel eerder as om `panic!` of soortgelyk aan te roep.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // VEILIGHEID: omdat `new_layout.size()` groter of gelyk aan moet wees
        // `old_layout.size()`, sowel die ou as die nuwe geheuetoekenning is geldig vir lees en skryf vir `old_layout.size()`-grepe.
        // Omdat die ou toekenning nog nie geallokeer is nie, kan dit nie `new_ptr` oorvleuel nie.
        // Die oproep na `copy_nonoverlapping` is dus veilig.
        // Die oproeper moet die veiligheidskontrak vir `dealloc` nakom.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Pogings om die geheue blok te laat krimp.
    ///
    /// Wys 'n nuwe [`NonNull<[u8]>`][NonNull] wat 'n wyser bevat en die werklike grootte van die toegewysde geheue.Die aanwyser is geskik vir die bewaring van data wat deur `new_layout` beskryf word.
    /// Om dit te bewerkstellig, kan die toewyser die toewysing waarna `ptr` verwys, krimp om by die nuwe uitleg te pas.
    ///
    /// As dit `Ok` oplewer, is die eienaarskap van die geheueblok waarna `ptr` verwys, aan hierdie toewyser oorgedra.
    /// Die geheue is al dan nie bevry, en moet as onbruikbaar beskou word, tensy dit weer na die oproeper oorgedra is via die retourwaarde van hierdie metode.
    ///
    /// As hierdie metode `Err` oplewer, is die eienaarskap van die geheueblok nie aan hierdie toewyser oorgedra nie en is die inhoud van die geheueblok onveranderd.
    ///
    /// # Safety
    ///
    /// * `ptr` moet 'n blok geheue [*currently allocated*] aandui via hierdie toewyser.
    /// * `old_layout` moet die blok geheue [*fit*] hê (die `new_layout`-argument hoef nie daarby te pas nie.).
    /// * `new_layout.size()` moet kleiner as of gelyk aan `old_layout.size()` wees.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Wys `Err` as die nuwe uitleg nie voldoen aan die grootte en belyningsbeperkings van die toewyser nie, of as krimping anders misluk.
    ///
    /// Implementasies word aangemoedig om `Err` terug te gee op geheue-uitputting eerder as om paniekerig te raak of te staak, maar dit is nie 'n streng vereiste nie.
    /// (Spesifiek: dit is *wettig* om hierdie trait bo-op 'n onderliggende inheemse toewysingsbiblioteek te implementeer wat op geheue-uitputting afbreek.)
    ///
    /// Kliënte wat die berekening wil staak as gevolg van 'n toewysingsfout, word aangemoedig om die [`handle_alloc_error`]-funksie te skakel eerder as om `panic!` of soortgelyk aan te roep.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // VEILIGHEID: omdat `new_layout.size()` laer as of gelyk moet wees aan
        // `old_layout.size()`, sowel die ou as die nuwe geheuetoekenning is geldig vir lees en skryf vir `new_layout.size()`-grepe.
        // Omdat die ou toekenning nog nie geallokeer is nie, kan dit nie `new_ptr` oorvleuel nie.
        // Die oproep na `copy_nonoverlapping` is dus veilig.
        // Die oproeper moet die veiligheidskontrak vir `dealloc` nakom.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Skep 'n "by reference"-adapter vir hierdie geval van `Allocator`.
    ///
    /// Die teruggekeerde adapter implementeer ook `Allocator` en sal dit eenvoudig leen.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // VEILIGHEID: die oproeper moet die veiligheidskontrak nakom
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // VEILIGHEID: die oproeper moet die veiligheidskontrak nakom
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // VEILIGHEID: die oproeper moet die veiligheidskontrak nakom
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // VEILIGHEID: die oproeper moet die veiligheidskontrak nakom
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}