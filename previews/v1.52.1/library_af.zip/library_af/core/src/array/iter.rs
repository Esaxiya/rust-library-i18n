//! Definieer die iterator wat deur `IntoIter` besit word vir skikkings.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// 'N Bywaarde [array]-iterator.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Dit is die skikking waaroor ons herhaal.
    ///
    /// Elemente met indeks `i` waar `alive.start <= i < alive.end` nog nie opgelewer is nie en geldige skikkinginskrywings is.
    /// Elemente met indekse `i < alive.start` of `i >= alive.end` is reeds opgelewer en moet nie meer verkry word nie!Daardie dooie elemente kan selfs in 'n heeltemal ongeïnisialiseerde toestand verkeer!
    ///
    ///
    /// Die invariërs is dus:
    /// - `data[alive]` leef (dws bevat geldige elemente)
    /// - `data[..alive.start]` en `data[alive.end..]` is dood (dws die elemente is al gelees en mag nie meer aangeraak word nie!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Die elemente in `data` wat nog nie opgelewer is nie.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Skep 'n nuwe iterator oor die gegewe `array`.
    ///
    /// *Opmerking*: hierdie metode kan na die [`IntoIterator` is implemented for arrays][array-into-iter] in die future verouder word.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Die tipe `value` is hier 'n `i32` in plaas van `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // VEILIGHEID: Die transmute hier is eintlik veilig.Die dokumente van `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` is gewaarborg om dieselfde grootte en belyning te hê
        // > as `T`.
        //
        // Die dokumente wys selfs 'n transmute van 'n skikking van `MaybeUninit<T>` na 'n skikking van `T`.
        //
        //
        // Daarmee bevredig hierdie inisialisering die invariërs.

        // FIXME(LukasKalbertodt): gebruik `mem::transmute` eintlik hier, sodra dit met const generics werk:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Tot dan kan ons `mem::transmute_copy` gebruik om 'n bitvisse kopie as 'n ander tipe te skep, en vergeet dan `array` sodat dit nie val nie.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Lewer 'n onveranderlike sny van alle elemente wat nog nie opgelewer is nie.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // VEILIGHEID: Ons weet dat alle elemente binne `alive` behoorlik geïnisialiseer is.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Wys 'n veranderlike deel van alle elemente wat nog nie opgelewer is nie.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // VEILIGHEID: Ons weet dat alle elemente binne `alive` behoorlik geïnisialiseer is.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Kry die volgende indeks van voor.
        //
        // Die verhoging van `alive.start` met 1 hou die onveranderlike met betrekking tot `alive` in stand.
        // As gevolg van hierdie verandering is die lewende sone vir 'n kort tydjie nie meer `data[alive]` nie, maar `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Lees die element uit die skikking.
            // VEILIGHEID: `idx` is 'n indeks in die voormalige "alive"-streek van die
            // skikking.Deur hierdie element te lees, word `data[idx]` as dood beskou (dws moenie aanraak nie).
            // Aangesien `idx` die begin van die lewende sone was, is die lewende sone nou weer `data[alive]`, wat alle invariërs herstel.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Kry die volgende indeks van agter.
        //
        // As u `alive.end` met 1 verminder, word die onveranderlike met betrekking tot `alive` gehandhaaf.
        // As gevolg van hierdie verandering is die lewende sone vir 'n kort tydjie nie meer `data[alive]` nie, maar `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Lees die element uit die skikking.
            // VEILIGHEID: `idx` is 'n indeks in die voormalige "alive"-streek van die
            // skikking.Deur hierdie element te lees, word `data[idx]` as dood beskou (dws moenie aanraak nie).
            // Aangesien `idx` die einde van die lewende sone was, is die lewende sone nou weer `data[alive]`, wat alle invariërs herstel.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // VEILIGHEID: Dit is veilig: `as_mut_slice` gee presies die onderstuk terug
        // van elemente wat nog nie verwyder is nie en wat nog moet val.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Sal nooit ondervloei as gevolg van die onveranderlike `lewendige.begin <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Die iterator rapporteer inderdaad die regte lengte.
// Die aantal "alive"-elemente (wat steeds opgelewer sal word) is die lengte van die reeks `alive`.
// Hierdie reeks word in `next` of `next_back` verminder.
// In hierdie metodes word dit altyd met 1 afgeneem, maar slegs as `Some(_)` terugbesorg word.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Let wel, ons hoef nie presies dieselfde lewende reeks te pas nie, dus kan ons net in offset 0 kloon, ongeag waar `self` is.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Kloon alle lewende elemente.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Skryf 'n kloon in die nuwe skikking en werk dan die lewende reeks daarvan op.
            // As u panics kloneer, sal ons die vorige items korrek laat vaar.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Druk slegs die elemente uit wat nog nie opgelewer is nie: ons kan nie meer toegang tot die opgelegde elemente kry nie.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}