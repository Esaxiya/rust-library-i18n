#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// 'N-toekoms stel 'n asynchrone berekening voor.
///
/// 'N future is 'n waarde wat moontlik nog nie klaar is met die berekening nie.
/// Hierdie soort "asynchronous value" maak dit vir 'n draad moontlik om nuttige werk te verrig terwyl dit wag totdat die waarde beskikbaar is.
///
///
/// # Die `poll`-metode
///
/// Die kernmetode van future, `poll`,*probeer* om die future tot 'n finale waarde op te los.
/// Hierdie metode word nie geblokkeer as die waarde nie gereed is nie.
/// In plaas daarvan word die huidige taak beplan om wakker te word as dit moontlik is om verder te vorder deur weer 'te stem'.
/// Die `context` wat na die `poll`-metode oorgedra word, kan 'n [`Waker`] bied, wat 'n handvatsel is om die huidige taak op te wek.
///
/// As u 'n future gebruik, sal u `poll` gewoonlik nie direk skakel nie, maar die waarde `.await`.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Die tipe waarde wat na voltooiing geproduseer word.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Probeer om die future tot 'n finale waarde op te los en registreer die huidige taak vir ontwaking as die waarde nog nie beskikbaar is nie.
    ///
    /// # Opbrengswaarde
    ///
    /// Hierdie funksie gee terug:
    ///
    /// - [`Poll::Pending`] as die future nog nie gereed is nie
    /// - [`Poll::Ready(val)`] met die resultaat `val` van hierdie future as dit suksesvol voltooi is.
    ///
    /// Sodra 'n future klaar is, moet kliënte dit nie weer `poll` nie.
    ///
    /// As 'n future nog nie gereed is nie, gee `poll` `Poll::Pending` terug en stoor 'n kloon van die [`Waker`] wat vanaf die huidige [`Context`] gekopieër is.
    /// Hierdie [`Waker`] word dan wakker gemaak sodra die future vordering kan maak.
    /// Byvoorbeeld, 'n future wat wag dat die sokkie leesbaar is, sal `.clone()` op die [`Waker`] skakel en dit stoor.
    /// Wanneer 'n sein elders aankom wat aandui dat die aansluiting leesbaar is, word [`Waker::wake`] gebel en die taak future se taak ontwaak.
    /// Nadat 'n taak wakker gemaak is, moet dit probeer om die future weer te X00, wat die finale waarde al dan nie kan lewer.
    ///
    /// Let daarop dat by veelvuldige oproepe na `poll` slegs die [`Waker`] van die [`Context`] wat na die mees onlangse oproep oorgedra is, geskeduleer moet wees om wakker te word.
    ///
    /// # Runtime-eienskappe
    ///
    /// Futures alleen is *inert*;hulle moet *aktief*'bestudeer word' om vooruitgang te maak, wat beteken dat elke keer as die huidige taak wakker gemaak word, dit aktief moet weer 'poll' in afwagting van futures waarin dit nog steeds belang het.
    ///
    /// Die `poll`-funksie word nie herhaaldelik in 'n strak lus genoem nie, maar moet slegs genoem word as die future aandui dat dit gereed is om vooruitgang te maak (deur `wake()`) te skakel.
    /// As u vertroud is met die `poll(2)`-of `select(2)`-syscalls op Unix, is dit opmerklik dat futures gewoonlik dieselfde probleme as "all wakeups must poll all events"*nie* ondervind nie;hulle is meer soos `epoll(4)`.
    ///
    /// 'N Implementering van `poll` moet poog om vinnig terug te keer en moet nie blokkeer nie.Om vinnig terug te keer, voorkom dat onnodige drade of gebeurtenislusse verstop word.
    /// As u vooraf weet dat 'n oproep na `poll` 'n rukkie kan neem, moet die werk na 'n draadpoel (of iets soortgelyks) afgelaai word om te verseker dat `poll` vinnig kan terugkeer.
    ///
    /// # Panics
    ///
    /// Sodra 'n future voltooi is (`Ready` van `poll` terugbesorg het), kan die oproep van die `poll`-metode weer panic wees, vir ewig blokkeer of ander probleme veroorsaak;die `Future` trait stel geen vereistes vir die gevolge van so 'n oproep nie.
    /// Aangesien die `poll`-metode egter nie as `unsafe` gemerk is nie, geld die normale reëls van Rust: oproepe mag nooit ongedefinieerde gedrag veroorsaak nie (geheue-korrupsie, verkeerde gebruik van `unsafe`-funksies, of dies meer), ongeag die toestand van die future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}