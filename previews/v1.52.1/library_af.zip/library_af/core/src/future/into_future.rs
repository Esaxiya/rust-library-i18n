use crate::future::Future;

/// Omskakeling in 'n `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Die uitset wat die future sal lewer na voltooiing.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// In watter soort future verander ons dit?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Skep 'n future uit 'n waarde.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}