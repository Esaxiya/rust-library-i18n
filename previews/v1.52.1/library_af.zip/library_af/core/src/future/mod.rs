#![stable(feature = "futures_api", since = "1.36.0")]

//! Asinchrone waardes.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Hierdie tipe is nodig omdat:
///
/// a) Generators kan nie `for<'a, 'b> Generator<&'a mut Context<'b>>` implementeer nie, daarom moet ons 'n rou wyser deurgee (sien <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Rou aanwysers en `NonNull` is nie `Send` of `Sync` nie, so dit sal ook elke future non-Send/Sync maak, en ons wil dit nie hê nie.
///
/// Dit vereenvoudig ook die HIR-verlaging van `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Draai 'n kragopwekker in 'n future toe.
///
/// Hierdie funksie gee 'n `GenFuture` onder, maar verberg dit in `impl Trait` om beter foutboodskappe te gee (`impl Future` eerder as `GenFuture<[closure.....]>`).
///
// Dit is `const` om ekstra foute te vermy nadat ons van `const async fn` herstel het
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Ons vertrou daarop dat async/await futures onroerend is om selfverwysende lenings in die onderliggende kragopwekker te skep.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // VEILIGHEID: Veilig omdat ons !Unpin + !Drop is, en dit is net 'n veldprojeksie.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Hervat die kragopwekker en verander die `&mut Context` in 'n `NonNull` rou aanwyser.
            // Die `.await`-verlaging sal dit veilig na 'n `&mut Context` terugbring.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // VEILIGHEID: die beller moet waarborg dat `cx.0` 'n geldige aanwyser is
    // wat aan al die vereistes vir 'n veranderlike verwysing voldoen.
    unsafe { &mut *cx.0.as_ptr().cast() }
}