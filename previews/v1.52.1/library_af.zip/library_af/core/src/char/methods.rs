//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Die hoogste geldige kodepunt wat 'n `char` kan hê.
    ///
    /// 'N `char` is 'n [Unicode Scalar Value], wat beteken dat dit 'n [Code Point] is, maar slegs binne 'n sekere reeks.
    /// `MAX` is die hoogste geldige kodepunt wat 'n geldige [Unicode Scalar Value] is.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () word in Unicode gebruik om 'n dekoderingsfout voor te stel.
    ///
    /// Dit kan byvoorbeeld voorkom wanneer slegte UTF-8-grepe aan [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy) gegee word.
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Die weergawe van [Unicode](http://www.unicode.org/) waarop die Unicode-dele van `char`-en `str`-metodes gebaseer is.
    ///
    /// Nuwe weergawes van Unicode word gereeld vrygestel en vervolgens word alle metodes in die standaardbiblioteek, afhangende van Unicode, opgedateer.
    /// Daarom verander die gedrag van sommige `char`-en `str`-metodes en die waarde van hierdie konstante oor tyd.
    /// Dit word *nie* as 'n breekende verandering beskou nie.
    ///
    /// Die weergawe-nommeringskema word in [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) uiteengesit.
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Skep 'n iterator oor die UTF-16-gekodeerde kodepunte in `iter`, en gee ongepaarde surrogate as 'Err's' terug.
    ///
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// 'N Verlore dekodeerder kan verkry word deur die `Err`-resultate deur die vervangende karakter te vervang:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Skakel 'n `u32` om na 'n `char`.
    ///
    /// Let daarop dat alle `char`s geldig [`u32`] s is en met een gegooi kan word
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Die omgekeerde is egter nie waar nie: nie alle geldige [`u32`] s is geldig`char`s nie.
    /// `from_u32()` sal `None` terugstuur as die invoer nie 'n geldige waarde vir 'n `char` is nie.
    ///
    /// Vir 'n onveilige weergawe van hierdie funksie wat hierdie tjeks ignoreer, sien [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Terugkeer van `None` wanneer die invoer nie 'n geldige `char` is nie:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Skakel 'n `u32` om na 'n `char`, en ignoreer die geldigheid.
    ///
    /// Let daarop dat alle `char`s geldig [`u32`] s is en met een gegooi kan word
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Die omgekeerde is egter nie waar nie: nie alle geldige [`u32`] s is geldig`char`s nie.
    /// `from_u32_unchecked()` sal dit ignoreer en blindelings na `char` gooi en moontlik 'n ongeldige een skep.
    ///
    ///
    /// # Safety
    ///
    /// Hierdie funksie is onveilig, want dit kan ongeldige `char`-waardes konstrueer.
    ///
    /// Raadpleeg die [`from_u32`]-funksie vir 'n veilige weergawe van hierdie funksie.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // VEILIGHEID: die oproeper moet die veiligheidskontrak nakom.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Skakel 'n syfer in die gegewe radix om na 'n `char`.
    ///
    /// 'N 'radix' word soms ook 'n 'base' genoem.
    /// 'N Radiks van twee dui op 'n binêre getal, 'n radiks van tien, desimale en 'n radiks van sestien, heksadesimaal, om 'n paar algemene waardes te gee.
    ///
    /// Willekeurige radies word ondersteun.
    ///
    /// `from_digit()` sal `None` terugstuur as die invoer nie 'n syfer in die gegewe radiks is nie.
    ///
    /// # Panics
    ///
    /// Panics indien 'n radiks groter as 36 gegee word.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Desimaal 11 is 'n enkele syfer in basis 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Terugkeer van `None` as die invoer nie 'n syfer is nie:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Verby 'n groot radix en veroorsaak 'n panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Kontroleer of 'n `char` 'n syfer in die gegewe radiks is.
    ///
    /// 'N 'radix' word soms ook 'n 'base' genoem.
    /// 'N Radiks van twee dui op 'n binêre getal, 'n radiks van tien, desimale en 'n radiks van sestien, heksadesimaal, om 'n paar algemene waardes te gee.
    ///
    /// Willekeurige radies word ondersteun.
    ///
    /// In vergelyking met [`is_numeric()`], herken hierdie funksie slegs die karakters `0-9`, `a-z` en `A-Z`.
    ///
    /// 'Digit' word slegs die volgende karakters gedefinieer:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Vir 'n meer omvattende begrip van 'digit', sien [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics indien 'n radiks groter as 36 gegee word.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Verby 'n groot radix en veroorsaak 'n panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Skakel 'n `char` om na 'n syfer in die gegewe radiks.
    ///
    /// 'N 'radix' word soms ook 'n 'base' genoem.
    /// 'N Radiks van twee dui op 'n binêre getal, 'n radiks van tien, desimale en 'n radiks van sestien, heksadesimaal, om 'n paar algemene waardes te gee.
    ///
    /// Willekeurige radies word ondersteun.
    ///
    /// 'Digit' word slegs die volgende karakters gedefinieer:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Wys `None` as die `char` nie na 'n syfer in die gegewe radiks verwys nie.
    ///
    /// # Panics
    ///
    /// Panics indien 'n radiks groter as 36 gegee word.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// As u 'n nie-syfer slaag, lei dit tot mislukking:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Verby 'n groot radix en veroorsaak 'n panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // die kode word hier verdeel om die uitvoersnelheid te verbeter vir gevalle waar die `radix` konstant en 10 of kleiner is
        //
        let val = if likely(radix <= 10) {
            // Indien nie 'n syfer nie, sal 'n getal groter as radiks geskep word.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Wys 'n iterator wat die heksadesimale ontsnapping van 'n karakter as 'char' gee.
    ///
    /// Dit ontsnap aan karakters met die Rust-sintaksis van die vorm `\u{NNNNNN}` waar `NNNNNN` 'n heksadesimale voorstelling is.
    ///
    ///
    /// # Examples
    ///
    /// As herhaling:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Gebruik `println!` direk:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Albei is gelykstaande aan:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Gebruik `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // of-ing 1 verseker dat vir c==0 die kode bereken dat een syfer gedruk moet word en (wat dieselfde is) die (31, 32) onderstroom vermy
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // die indeks van die belangrikste heks-syfer
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// 'N Uitgebreide weergawe van die `escape_debug` wat opties vir die ontsnapping van Extended Grapheme-kodepunte moontlik maak.
    /// Dit stel ons in staat om karakters soos nie-spasiëringsmerke beter te formateer as hulle aan die begin van 'n string is.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Wys 'n iterator wat die letterlike ontsnapkode van 'n karakter as 'char' gee.
    ///
    /// Dit sal ontkom aan die karakters soortgelyk aan die `Debug`-implementasies van `str` of `char`.
    ///
    ///
    /// # Examples
    ///
    /// As herhaling:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Gebruik `println!` direk:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Albei is gelykstaande aan:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Gebruik `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Wys 'n iterator wat die letterlike ontsnapkode van 'n karakter as 'char' gee.
    ///
    /// Die standaard word gekies met die vooroordeel om letterkundes te produseer wat wettig is in verskillende tale, insluitend C++ 11 en soortgelyke C-gesinstale.
    /// Die presiese reëls is:
    ///
    /// * Tab is ontsnap as `\t`.
    /// * Vervoer van vervoer word as `\r` ontsnap.
    /// * Lynvoer word as `\n` ontsnap.
    /// * Enkele kwotasie word as `\'` vrygespring.
    /// * Dubbele aanhaling word as `\"` vrygespring.
    /// * Terugslag is as `\\` ontsnap.
    /// * Enige karakter in die 'drukbare ASCII'-reeks `0x20` .. `0x7e` inklusief kan nie ontsnap word nie.
    /// * Alle ander karakters kry heksadesimale Unicode-ontsnappings;sien [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// As herhaling:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Gebruik `println!` direk:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Albei is gelykstaande aan:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Gebruik `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Wys die aantal grepe wat hierdie `char` benodig as dit in UTF-8 gekodeer is.
    ///
    /// Die aantal grepe is altyd tussen 1 en 4.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Die `&str`-tipe waarborg dat die inhoud daarvan UTF-8 is, en daarom kan ons die lengte vergelyk as elke kodepunt as 'n `char` in die `&str` voorgestel word:
    ///
    ///
    /// ```
    /// // as karakters
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // albei kan as drie grepe voorgestel word
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // as 'n &str word hierdie twee in UTF-8 gekodeer
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // ons kan sien dat hulle ses bytes in totaal neem ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... net soos die &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Wys die aantal 16-bis-kode-eenhede wat hierdie `char` benodig as dit in UTF-16 gekodeer is.
    ///
    ///
    /// Raadpleeg die dokumentasie vir [`len_utf8()`] vir meer uiteensetting van hierdie konsep.
    /// Hierdie funksie is 'n spieël, maar vir UTF-16 in plaas van UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Kodeer hierdie karakter as UTF-8 in die verstrekte bytebuffer, en stuur dan die subskyfie van die buffer terug wat die gekodeerde karakter bevat.
    ///
    ///
    /// # Panics
    ///
    /// Panics as die buffer nie groot genoeg is nie.
    /// 'N Buffer van lengte vier is groot genoeg om enige `char` te kodeer.
    ///
    /// # Examples
    ///
    /// In albei hierdie voorbeelde neem 'ß' twee grepe om te kodeer.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// 'N Te klein buffer:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // VEILIGHEID: `char` is nie 'n plaasvervanger nie, dus dit is 'n geldige UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Kodeer hierdie karakter as UTF-16 in die `u16`-buffer wat voorsien word, en stuur dan die subskyfie van die buffer terug wat die gekodeerde karakter bevat.
    ///
    ///
    /// # Panics
    ///
    /// Panics as die buffer nie groot genoeg is nie.
    /// 'N Buffer van lengte 2 is groot genoeg om enige `char` te kodeer.
    ///
    /// # Examples
    ///
    /// In albei hierdie voorbeelde neem '𝕊' twee u16's om te kodeer.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// 'N Te klein buffer:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Wys `true` as hierdie `char` die `Alphabetic`-eienskap het.
    ///
    /// `Alphabetic` word in Hoofstuk 4 (Karaktereienskappe) van die [Unicode Standard] beskryf en in die [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] gespesifiseer.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // liefde is baie dinge, maar dit is nie alfabeties nie
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Wys `true` as hierdie `char` die `Lowercase`-eienskap het.
    ///
    /// `Lowercase` word in Hoofstuk 4 (Karaktereienskappe) van die [Unicode Standard] beskryf en in die [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] gespesifiseer.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Die verskillende Chinese skrifte en leestekens het nie hoofletters nie, en dus:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Wys `true` as hierdie `char` die `Uppercase`-eienskap het.
    ///
    /// `Uppercase` word in Hoofstuk 4 (Karaktereienskappe) van die [Unicode Standard] beskryf en in die [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] gespesifiseer.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Die verskillende Chinese skrifte en leestekens het nie hoofletters nie, en dus:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Wys `true` as hierdie `char` die `White_Space`-eienskap het.
    ///
    /// `White_Space` word in die [Unicode Character Database][ucd] [`PropList.txt`] gespesifiseer.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // 'n onbreekbare ruimte
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Wys `true` as hierdie `char` aan [`is_alphabetic()`] of [`is_numeric()`] voldoen.
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Wys `true` as hierdie `char` die algemene kategorie vir beheerkodes het.
    ///
    /// Beheerkodes (kodepunte met die algemene kategorie `Cc`) word beskryf in Hoofstuk 4 (Karaktereienskappe) van die [Unicode Standard] en in die [Unicode Character Database][ucd] [`UnicodeData.txt`] gespesifiseer.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// // U + 009C, TERMINATOR
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Wys `true` as hierdie `char` die `Grapheme_Extend`-eienskap het.
    ///
    /// `Grapheme_Extend` word in [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] beskryf en in die [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] gespesifiseer.
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Wys `true` as hierdie `char` een van die algemene kategorieë vir getalle het.
    ///
    /// Die algemene kategorieë vir getalle (`Nd` vir desimale syfers, `Nl` vir letteragtige numeriese karakters en `No` vir ander numeriese karakters) word in die [Unicode Character Database][ucd] [`UnicodeData.txt`] gespesifiseer.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Wys 'n iterator wat die klein kartering van hierdie `char` as een of meer gee
    /// `char`s.
    ///
    /// As hierdie `char` nie 'n kleinletterkaart het nie, lewer die iterator dieselfde `char`.
    ///
    /// As hierdie `char` 'n een-tot-een klein kartering het wat deur die [Unicode Character Database][ucd] [`UnicodeData.txt`] gegee word, lewer die iterator die `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// As hierdie `char` spesiale oorwegings benodig (bv. Veelvoudige `char`s '), lewer die iterator die` char' (s) wat deur [`SpecialCasing.txt`] gegee word.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Hierdie bewerking voer 'n onvoorwaardelike kartering uit sonder om dit aan te pas.Die omskakeling is dus onafhanklik van konteks en taal.
    ///
    /// In die [Unicode Standard] word hoofstuk 4 (Karaktereienskappe) in hoofsaak oor kartering van gevalle bespreek en hoofstuk 3 (Conformance) oor die standaardalgoritme vir omskakeling van gevalle.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// As herhaling:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Gebruik `println!` direk:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Albei is gelykstaande aan:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Gebruik `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Soms is die resultaat meer as een karakter:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Karakters wat nie beide hoofletters en kleinletters het nie, verander in hulself.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Wys 'n iterator wat die hoofletters van hierdie `char` as een of meer gee
    /// `char`s.
    ///
    /// As hierdie `char` nie 'n hoofletterkaart het nie, lewer die iterator dieselfde `char`.
    ///
    /// As hierdie `char` 'n een-tot-een-hoofletter-kartering het wat deur die [Unicode Character Database][ucd] [`UnicodeData.txt`] gegee word, lewer die iterator die `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// As hierdie `char` spesiale oorwegings benodig (bv. Veelvoudige `char`s '), lewer die iterator die` char' (s) wat deur [`SpecialCasing.txt`] gegee word.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Hierdie bewerking voer 'n onvoorwaardelike kartering uit sonder om dit aan te pas.Die omskakeling is dus onafhanklik van konteks en taal.
    ///
    /// In die [Unicode Standard] word hoofstuk 4 (Karaktereienskappe) in hoofsaak oor kartering van gevalle bespreek en hoofstuk 3 (Conformance) oor die standaardalgoritme vir omskakeling van gevalle.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// As herhaling:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Gebruik `println!` direk:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Albei is gelykstaande aan:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Gebruik `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Soms is die resultaat meer as een karakter:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Karakters wat nie beide hoofletters en kleinletters het nie, verander in hulself.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Nota oor die land
    ///
    /// In Turks het die ekwivalent van 'i' in Latyn vyf vorms in plaas van twee:
    ///
    /// * 'Dotless': Ek/ı, soms geskryf ï
    /// * 'Dotted': İ/i
    ///
    /// Let daarop dat die 'i' met klein letters gestrooi is, dieselfde as die Latyn.Daarom:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Die waarde van `upper_i` berus hier op die taal van die teks: as ons in `en-US` is, moet dit `"I"` wees, maar as ons in `tr_TR` is, moet dit `"İ"` wees.
    /// `to_uppercase()` neem dit nie in ag nie, en so:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// hou oor tale heen.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Kontroleer of die waarde binne die ASCII-reeks is.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Maak 'n afskrif van die waarde in sy ASCII-hoofletters.
    ///
    /// ASCII-letters 'a' tot 'z' word gekoppel aan 'A' tot 'Z', maar nie-ASCII-letters is onveranderd.
    ///
    /// Gebruik [`make_ascii_uppercase()`] om die waarde in plek te hoofletter.
    ///
    /// Gebruik [`to_uppercase()`] om ASCII-karakters in hoofletters te benewens nie-ASCII-karakters.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Maak 'n afskrif van die waarde in sy ASCII-kleinletter-ekwivalent.
    ///
    /// ASCII-letters 'A' tot 'Z' word gekoppel aan 'a' tot 'z', maar nie-ASCII-letters is onveranderd.
    ///
    /// Gebruik [`make_ascii_lowercase()`] om die waarde klein te maak.
    ///
    /// Gebruik [`to_lowercase()`] om ASCII-karakters in kleinletters te benewens nie-ASCII-karakters.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Kontroleer dat twee waardes 'n ASCII-kleinlettergevoelige pas is.
    ///
    /// Ekwivalent aan `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Skakel hierdie tipe om na die ASCII-hoofletter-ekwivalent in die plek.
    ///
    /// ASCII-letters 'a' tot 'z' word gekoppel aan 'A' tot 'Z', maar nie-ASCII-letters is onveranderd.
    ///
    /// Gebruik [`to_ascii_uppercase()`] om 'n nuwe hoofletterwaarde terug te gee sonder om die bestaande waarde te wysig.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Skakel hierdie tipe om na sy ASCII-kleinletter-ekwivalent in die plek.
    ///
    /// ASCII-letters 'A' tot 'Z' word gekoppel aan 'a' tot 'z', maar nie-ASCII-letters is onveranderd.
    ///
    /// Gebruik [`to_ascii_lowercase()`] om 'n nuwe waarde met 'n laer waarde terug te gee sonder om die bestaande waarde te wysig.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Kontroleer of die waarde 'n ASCII-alfabetiese karakter het:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', of
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Kontroleer of die waarde 'n ASCII-hoofletter is:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Kontroleer of die waarde 'n ASCII-kleinletter is:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Kontroleer of die waarde 'n ASCII-alfanumerieke karakter het:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', of
    /// - U + 0061 'a' ..=U + 007A 'z', of
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Kontroleer of die waarde 'n ASCII desimale syfer is:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Kontroleer of die waarde 'n ASCII-heksadesimale syfer is:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', of
    /// - U + 0041 'A' ..=U + 0046 'F', of
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Kontroleer of die waarde 'n ASCII-leesteken is:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, of
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, of
    /// - U + 005B ..=U + 0060 `[\] ^ _` ``, of
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Kontroleer of die waarde 'n ASCII-grafiese karakter is:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Kontroleer of die waarde 'n ASCII-witruimtekarakter is:
    /// U + 0020 RUIMTE, U + 0009 HORISONTALE TABEL, U + 000A LYNVOER, U + 000C VORMVOEDING, of U + 000D RUIGTERUG.
    ///
    /// Rust gebruik die [definition of ASCII whitespace][infra-aw] van WhatWG Infra Standard.Daar is verskeie ander definisies wat wyd gebruik word.
    /// Byvoorbeeld, [the POSIX locale][pct] bevat U + 000B VERTIKALE TAB, sowel as al die karakters hierbo, maar - uit dieselfde spesifikasie - [die standaardreël vir "field splitting" in die Bourne shell][bfs] neem slegs *ruimte*, HORISONTALE TAB, en LYNVOER as witruimte.
    ///
    ///
    /// As u 'n program skryf wat 'n bestaande lêerformaat sal verwerk, moet u seker maak wat die definisie van die witruimte van die formaat is voordat u hierdie funksie gebruik.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Kontroleer of die waarde 'n ASCII-beheerkarakter is:
    /// U + 0000 NUL ..=U + 001F EENHEIDSSKEIDER, of U + 007F WIS.
    /// Let op dat die meeste ASCII-spasie-karakters kontrolekarakters is, maar SPACE nie.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Kodeer 'n rou u32-waarde as UTF-8 in die gegewe bytebuffer, en gee dan weer die subgedeelte van die buffer wat die gekodeerde karakter bevat, terug.
///
///
/// In teenstelling met `char::encode_utf8`, hanteer hierdie metode ook kodepunte in die surrogaatreeks.
/// (Die skep van 'n `char` in die surrogaatreeks is UB.) Die resultaat is geldig [generalized UTF-8], maar nie geldig UTF-8 nie.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics as die buffer nie groot genoeg is nie.
/// 'N Buffer van lengte vier is groot genoeg om enige `char` te kodeer.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Kodeer 'n onbewerkte u32-waarde as UTF-16 in die `u16`-buffer wat verskaf word, en stuur dan die subgedeelte van die buffer terug wat die gekodeerde karakter bevat.
///
///
/// In teenstelling met `char::encode_utf16`, hanteer hierdie metode ook kodepunte in die surrogaatreeks.
/// (Om 'n `char` in die surrogaatreeks te maak, is UB.)
///
/// # Panics
///
/// Panics as die buffer nie groot genoeg is nie.
/// 'N Buffer van lengte 2 is groot genoeg om enige `char` te kodeer.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // VEILIGHEID: elke arm kyk of daar genoeg stukkies is om in te skryf
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // Die BMP val deur
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Aanvullende vliegtuie breek by surrogate in.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}