//! Karakteromskakelings.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Skakel 'n `u32` om na 'n `char`.
///
/// Let daarop dat alle [`char`] s geldig [`u32`] s is en saam met een gegooi kan word
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Die omgekeerde is egter nie waar nie: nie alle geldige [`u32`] s is geldig [`char`] s nie.
/// `from_u32()` sal `None` terugstuur as die invoer nie 'n geldige waarde vir 'n [`char`] is nie.
///
/// Vir 'n onveilige weergawe van hierdie funksie wat hierdie tjeks ignoreer, sien [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Basiese gebruik:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Terugkeer van `None` wanneer die invoer nie 'n geldige [`char`] is nie:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Skakel 'n `u32` om na 'n `char`, en ignoreer die geldigheid.
///
/// Let daarop dat alle [`char`] s geldig [`u32`] s is en saam met een gegooi kan word
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Die omgekeerde is egter nie waar nie: nie alle geldige [`u32`] s is geldig [`char`] s nie.
/// `from_u32_unchecked()` sal dit ignoreer en blindelings na [`char`] gooi en moontlik 'n ongeldige een skep.
///
///
/// # Safety
///
/// Hierdie funksie is onveilig, want dit kan ongeldige `char`-waardes konstrueer.
///
/// Raadpleeg die [`from_u32`]-funksie vir 'n veilige weergawe van hierdie funksie.
///
/// # Examples
///
/// Basiese gebruik:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // VEILIGHEID: die oproeper moet waarborg dat `i` 'n geldige waarde is.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Skakel 'n [`char`] om in 'n [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Skakel 'n [`char`] om in 'n [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Die kar word gegiet na die waarde van die kodepunt, dan nul uitgebrei tot 64 bit.
        // Sien [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Skakel 'n [`char`] om in 'n [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Die kar word gegiet op die waarde van die kodepunt, dan nul uitgebrei tot 128 bit.
        // Sien [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Kaart 'n byte in 0x00 ..=0xFF na 'n `char` waarvan die kodepunt dieselfde waarde het, in U + 0000 ..=U + 00FF.
///
/// Unicode is so ontwerp dat dit bytes effektief dekodeer met die karakterkodering wat IANA ISO-8859-1 noem.
/// Hierdie kodering is verenigbaar met ASCII.
///
/// Let daarop dat dit anders is as ISO/IEC 8859-1 aka
/// ISO 8859-1 (met een koppelteken minder), wat sommige "blanks"-bytewaardes agterlaat wat aan geen karakter toegeken word nie.
/// ISO-8859-1 (die IANA een) ken hulle toe aan die C0-en C1-beheerkodes.
///
/// Let daarop dat dit *ook* verskil van Windows-1252
/// kode bladsy 1252, wat 'n superset ISO/IEC 8859-1 is wat 'n aantal (nie almal nie!) spasies toewys aan leestekens en verskillende Latynse karakters.
///
/// Om dinge verder te verwar, is [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` en `windows-1252` aliasse vir 'n superset Windows-1252 wat die oorblywende spasies vul met ooreenstemmende C0-en C1-beheerkodes.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Skakel 'n [`u8`] om in 'n [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// 'N Fout wat teruggestuur kan word tydens die ontleding van 'n kol.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // VEILIGHEID: kyk of dit 'n wettige unicode-waarde is
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Die fouttipe is terug wanneer 'n omskakeling van u32 na char mislukking.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Skakel 'n syfer in die gegewe radix om na 'n `char`.
///
/// 'N 'radix' word soms ook 'n 'base' genoem.
/// 'N Radiks van twee dui op 'n binêre getal, 'n radiks van tien, desimale en 'n radiks van sestien, heksadesimaal, om 'n paar algemene waardes te gee.
///
/// Willekeurige radies word ondersteun.
///
/// `from_digit()` sal `None` terugstuur as die invoer nie 'n syfer in die gegewe radiks is nie.
///
/// # Panics
///
/// Panics indien 'n radiks groter as 36 gegee word.
///
/// # Examples
///
/// Basiese gebruik:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Desimaal 11 is 'n enkele syfer in basis 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Terugkeer van `None` as die invoer nie 'n syfer is nie:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Verby 'n groot radix en veroorsaak 'n panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}