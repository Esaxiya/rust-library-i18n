//! Primitiewe-eienskappe en tipes wat basiese eienskappe van soorte voorstel.
//!
//! Rust-tipes kan op verskillende nuttige maniere geklassifiseer word volgens hul intrinsieke eienskappe.
//! Hierdie klassifikasies word voorgestel as traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Tipes wat oor die draadgrense oorgedra kan word.
///
/// Hierdie trait word outomaties geïmplementeer wanneer die samesteller bepaal dat dit toepaslik is.
///
/// 'N Voorbeeld van 'n nie-'Stuur'-tipe is die verwysingstellerwyser [`rc::Rc`][`Rc`].
/// As twee drade probeer om ['Rc'] te kloon wat op dieselfde verwysingsgetelde waarde dui, kan hulle probeer om die verwysingstelling op dieselfde tyd by te werk, dit is [undefined behavior][ub] omdat [`Rc`] geen atoombewerkings gebruik nie.
///
/// Sy neef [`sync::Arc`][arc] gebruik atoombedrywighede (het 'n bietjie bokoste) en is dus `Send`.
///
/// Sien [the Nomicon](../../nomicon/send-and-sync.html) vir meer besonderhede.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Tipes met 'n konstante grootte wat tydens kompileringstyd bekend is.
///
/// Alle tipe parameters het 'n implisiete grens van `Sized`.Die spesiale sintaksis `?Sized` kan gebruik word om hierdie band te verwyder as dit nie geskik is nie.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struktuur FooUse(Foo<[i32]>);//fout: Die grootte is nie geïmplementeer vir [i32] nie
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Die een uitsondering is die implisiete `Self`-tipe trait.
/// 'N trait het nie 'n implisiete `Sized`-band nie, aangesien dit onversoenbaar is met [trait-voorwerpe], waar die trait per definisie met alle moontlike implementeerders moet werk, en dus van enige grootte kan wees.
///
///
/// Alhoewel Rust u toelaat om `Sized` aan 'n trait te bind, kan u dit nie later gebruik om 'n trait-voorwerp te vorm nie:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // laat y: &dyn Bar= &Impl;//fout: die trait `Bar` kan nie in 'n voorwerp gemaak word nie
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // vir Standaard, byvoorbeeld, wat vereis dat `[T]: !Default` beoordeelbaar is
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Tipes wat "unsized" tot 'n dinamiese grootte kan wees.
///
/// Die grootte skikkingstipe `[i8; 2]` implementeer byvoorbeeld `Unsize<[i8]>` en `Unsize<dyn fmt::Debug>`.
///
/// Alle implementasies van `Unsize` word outomaties deur die samesteller voorsien.
///
/// `Unsize` geïmplementeer word vir:
///
/// - `[T; N]` is `Unsize<[T]>`
/// - `T` is `Unsize<dyn Trait>` wanneer `T: Trait`
/// - `Foo<..., T, ...>` is `Unsize<Foo<..., U, ...>>` as:
///   - `T: Unsize<U>`
///   - Foo is 'n struktuur
///   - Slegs die laaste veld van `Foo` het 'n tipe wat `T` insluit
///   - `T` maak nie deel uit van die tipe ander velde nie
///   - `Bar<T>: Unsize<Bar<U>>`, as die laaste veld van `Foo` die tipe `Bar<T>` het
///
/// `Unsize` word saam met [`ops::CoerceUnsized`] gebruik om "user-defined"-houers soos [`Rc`] dinamies groot tipes te bevat.
/// Raadpleeg die [DST coercion RFC][RFC982] en [the nomicon entry on coercion][nomicon-coerce] vir meer besonderhede.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Vereiste trait vir konstantes wat in patroonpassings gebruik word.
///
/// Enige tipe wat `PartialEq` aflei, implementeer hierdie trait outomaties,*ongeag* of die tipe parameters `Eq` implementeer.
///
/// As 'n `const`-item 'n soort bevat wat nie hierdie trait implementeer nie, dan implementeer die (1.) ook nie `PartialEq` nie (wat beteken dat die konstante nie die vergelykingsmetode sal bied nie, wat volgens die kodegenerasie beskikbaar is), of (2.) wat dit implementeer * * weergawe van `PartialEq` (wat ons aanneem nie ooreenstem met 'n strukturele-gelykheidsvergelyking nie).
///
///
/// In een van die twee scenario's hierbo verwerp ons die gebruik van so 'n konstante in 'n patroonsoort.
///
/// Kyk ook na die [structural match RFC][RFC1445] en [issue 63438] wat gemotiveer het om van attribuutgebaseerde ontwerp na hierdie trait te beweeg.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Vereiste trait vir konstantes wat in patroonpassings gebruik word.
///
/// Enige tipe wat `Eq` aflei, implementeer hierdie trait outomaties,*ongeag* of die tipe parameters `Eq` implementeer.
///
/// Dit is 'n hack om 'n beperking in ons tipe stelsel te omseil.
///
/// # Background
///
/// Ons wil vereis dat soorte konsts wat in patroonpassings gebruik word, die kenmerk `#[derive(PartialEq, Eq)]` het.
///
/// In 'n meer ideale wêreld kan ons die vereiste nagaan deur net te kontroleer of die gegewe tipe sowel die `StructuralPartialEq` trait *as* die `Eq` trait implementeer.
/// U kan egter ADT's hê wat *`derive(PartialEq, Eq)`* doen, en 'n geval wees wat ons wil hê dat die samesteller moet aanvaar, en tog kan die tipe van die konstante nie `Eq` implementeer nie.
///
/// 'N Geval soos hierdie:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Die probleem in die bostaande kode is dat `Wrap<fn(&())>` nie `PartialEq` implementeer nie, en ook nie `Eq` nie, want 'vir <' a> fn(&'a _)` does not implement those traits.)
///
/// Daarom kan ons nie op 'n naiewe tjek vir `StructuralPartialEq` en bloot `Eq` staatmaak nie.
///
/// As 'n hack om dit te omseil, gebruik ons twee afsonderlike traits wat deur elk van die twee afgeleide (`#[derive(PartialEq)]` en `#[derive(Eq)]`) ingespuit word, en kyk of albei teenwoordig is as deel van die strukturele wedstrydkontrole.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Tipes waarvan die waardes eenvoudig kan dupliseer deur stukkies te kopieer.
///
/// Veranderlike bindings het standaard 'bewegende semantiek'.Met ander woorde:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` het na `y` oorgeskakel, en kan dus nie gebruik word nie
///
/// // drukln! ("{: ?}", x);//fout: gebruik van verskuifde waarde
/// ```
///
/// As 'n tipe egter `Copy` implementeer, het dit eerder 'kopiesemantiek':
///
/// ```
/// // Ons kan 'n `Copy`-implementering verkry.
/// // `Clone` is ook nodig, want dit is 'n superbaan van `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` is 'n eksemplaar van `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Dit is belangrik om daarop te let dat in hierdie twee voorbeelde die enigste verskil is of u toegang tot `x` mag hê na die opdrag.
/// Onder die enjinkap kan 'n kopie sowel as 'n beweging daartoe lei dat stukkies in die geheue gekopieër word, hoewel dit soms weggeoptimaliseer word.
///
/// ## Hoe kan ek `Copy` implementeer?
///
/// Daar is twee maniere om `Copy` op u tipe te implementeer.Die eenvoudigste is om `derive` te gebruik:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// U kan ook `Copy` en `Clone` handmatig implementeer:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Daar is 'n klein verskil tussen die twee: die `derive`-strategie plaas ook 'n `Copy` gebind op tipe parameters, wat nie altyd verlang word nie.
///
/// ## Wat is die verskil tussen `Copy` en `Clone`?
///
/// Afskrifte geskied implisiet, byvoorbeeld as deel van 'n opdrag `y = x`.Die gedrag van `Copy` is nie oorlaai nie;dit is altyd 'n eenvoudige bietjie wys kopie.
///
/// Kloning is 'n eksplisiete aksie, `x.clone()`.Die implementering van [`Clone`] kan enige tipe spesifieke gedrag bied wat nodig is om waardes veilig te dupliseer.
/// Byvoorbeeld, die implementering van [`Clone`] vir [`String`] moet die gewysde stringbuffer in die hoop kopieer.
/// 'N Eenvoudige bitvisse kopie van [`String`]-waardes sal slegs die aanwyser kopieer, wat lei tot 'n dubbele lyn vry.
/// Om hierdie rede is [`String`] [`Clone`], maar nie `Copy` nie.
///
/// [`Clone`] is 'n superbaan van `Copy`, dus moet alles wat `Copy` is ook [`Clone`] implementeer.
/// As 'n tipe `Copy` is, hoef die [`Clone`]-implementering slegs `*self` terug te gee (sien die voorbeeld hierbo).
///
/// ## Wanneer kan my tipe `Copy` wees?
///
/// 'N Tipe kan `Copy` implementeer as al sy komponente `Copy` implementeer.Hierdie struktuur kan byvoorbeeld `Copy` wees:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// 'N Struct kan `Copy` wees, en [`i32`] is `Copy`, daarom kan `Point` `Copy` wees.
/// Oorweeg dit daarenteen
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Die struktuur `PointList` kan nie `Copy` implementeer nie, omdat [`Vec<T>`] nie `Copy` is nie.As ons 'n `Copy`-implementering probeer aflei, kry ons 'n fout:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Gedeelde verwysings (`&T`) is ook `Copy`, dus kan 'n tipe `Copy` wees, selfs as dit gedeelde verwysings bevat van die tipes `T` wat *nie*`Copy` is nie.
/// Beskou die volgende struktuur, wat `Copy` kan implementeer, omdat dit slegs 'n *gedeelde verwysing* bevat na ons nie-'Kopie'-tipe `PointList` van bo:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Wanneer *kan* my tipe nie `Copy` wees nie?
///
/// Sommige tipes kan nie veilig gekopieer word nie.Kopiëring van `&mut T` sal byvoorbeeld 'n alias veranderlike verwysing skep.
/// Die kopie van [`String`] sal die verantwoordelikheid vir die bestuur van die buffer van die ['String'] dupliseer, wat lei tot 'n dubbele vrystelling.
///
/// Om laasgenoemde geval te veralgemeen, kan [`Drop`] nie `Copy` wees nie, omdat dit 'n bron behalwe sy eie [`size_of::<T>`]-grepe bestuur.
///
/// As u probeer om `Copy` te implementeer op 'n struktuur of enum wat nie-'Kopie'-data bevat, kry u die fout [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Wanneer *moet* my tipe `Copy` wees?
///
/// Oor die algemeen, as u X001-tipe `Copy` implementeer, moet dit.
/// Hou egter in gedagte dat die implementering van `Copy` deel uitmaak van die publieke API van u tipe.
/// As die tipe dalk nie 'Kopie' in die future word nie, kan dit verstandig wees om die `Copy`-implementering nou weg te laat, om 'n breë API-verandering te voorkom.
///
/// ## Bykomende implementeerders
///
/// Benewens die [implementors listed below][impls], implementeer die volgende tipes ook `Copy`:
///
/// * Tipes funksie-items (dws die verskillende soorte wat vir elke funksie gedefinieer word)
/// * Funksie wysertipes (bv. `fn() -> i32`)
/// * Reeks tipes, vir alle groottes, as die artikeltipe ook `Copy` implementeer (bv. `[i32; 123456]`)
/// * Tupeltipes, as elke komponent ook `Copy` implementeer (bv. `()`, `(i32, bool)`)
/// * Sluitingstipes, as hulle geen waarde uit die omgewing vang nie, of as al die vasgestelde waardes `Copy` self implementeer.
///   Let daarop dat veranderlikes wat deur gedeelde verwysing vasgelê word, altyd `Copy` implementeer (selfs as die referent dit nie doen nie), terwyl veranderlikes wat deur veranderlike verwysing vasgelê word, nooit `Copy` implementeer nie.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Hierdeur kan u 'n tipe wat nie `Copy` implementeer nie, kopieer as gevolg van ontevreden leeftydsgrense (kopieer `A<'_>` wanneer slegs `A<'static>: Copy` en `A<'_>: Clone`).
// Ons het hierdie kenmerk nou eers hier omdat daar 'n hele paar spesialiserings op `Copy` bestaan wat reeds in die standaardbiblioteek bestaan, en daar is tans geen manier om hierdie gedrag veilig te hê nie.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Lei makro af wat 'n impl. Van die trait `Copy` genereer.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Tipes waarvoor dit veilig is om verwysings tussen drade te deel.
///
/// Hierdie trait word outomaties geïmplementeer wanneer die samesteller bepaal dat dit toepaslik is.
///
/// Die presiese definisie is: 'n tipe `T` is [`Sync`] as en slegs as `&T` [`Send`] is.
/// Met ander woorde, as daar geen moontlikheid is dat [undefined behavior][ub] (insluitend datarasies) wanneer `&T`-verwysings tussen drade oorgedra word nie.
///
/// Soos 'n mens sou verwag, is primitiewe tipes soos [`u8`] en [`f64`] almal [`Sync`], en so ook eenvoudige soorte tipes wat dit bevat, soos tuples, strucks en enums.
/// Meer voorbeelde van basiese [`Sync`]-tipes sluit in "immutable"-tipes soos `&T`, en dié met eenvoudige oorerflike veranderlikheid, soos [`Box<T>`][box], [`Vec<T>`][vec] en die meeste ander versamelingstipes.
///
/// (Generiese parameters moet [`Sync`] wees om hul houer ['Sync'] te wees.)
///
/// 'N Ietwat verrassende gevolg van die definisie is dat `&mut T` `Sync` is (as `T` `Sync` is), alhoewel dit lyk asof dit ongesinkroniseerde mutasie kan bied.
/// Die truuk is dat 'n veranderlike verwysing agter 'n gedeelde verwysing (dit wil sê `& &mut T`) leesalleen word, asof dit 'n `& &T` is.
/// Daar bestaan dus geen risiko vir 'n dataras nie.
///
/// Tipes wat nie `Sync` is nie, is dié wat "interior mutability" in 'n nie-draad-veilige vorm het, soos [`Cell`][cell] en [`RefCell`][refcell].
/// Hierdie tipes maak voorsiening vir mutasie van hul inhoud, selfs deur 'n onveranderlike, gedeelde verwysing.
/// Byvoorbeeld, die `set`-metode op [`Cell<T>`][cell] neem `&self`, dus dit benodig slegs 'n gedeelde verwysing [`&Cell<T>`][cell].
/// Die metode voer geen sinchronisasie uit nie, dus kan [`Cell`][cell] nie `Sync` wees nie.
///
/// Nog 'n voorbeeld van 'n nie-'Sync'-tipe is die verwysingstellerwyser [`Rc`][rc].
/// Gegewe enige [`&Rc<T>`][rc]-verwysing, kan u 'n nuwe [`Rc<T>`][rc] kloon en die verwysingstellings op 'n nie-atomiese manier verander.
///
/// In gevalle waar 'n draadveilige interieurveranderlikheid nodig is, bied Rust [atomic data types], sowel as eksplisiete vergrendeling via [`sync::Mutex`][mutex] en [`sync::RwLock`][rwlock].
/// Hierdie tipes verseker dat enige mutasie nie dataresies kan veroorsaak nie, dus is die tipes `Sync`.
/// Net so bied [`sync::Arc`][arc] 'n draadvaste analoog van [`Rc`][rc].
///
/// Enige tipes met binne-veranderlikhede moet ook die [`cell::UnsafeCell`][unsafecell]-omhulsel rondom die value(s) gebruik, wat deur 'n gedeelde verwysing gemuteer kan word.
/// Versuim om dit te doen, is [undefined behavior][ub].
/// Byvoorbeeld, [`transmuteer]][transmuteer]-ing van `&T` tot `&mut T` is ongeldig.
///
/// Sien [the Nomicon][nomicon-send-and-sync] vir meer besonderhede oor `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): sodra ondersteuning vir die toevoeging van notas in `rustc_on_unimplemented` in beta beland, en dit is uitgebrei om na te gaan of 'n sluiting oral in die vereiste ketting is, brei dit as sodanig uit (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Nulgrootte tipe word gebruik om dinge wat "act like" besit, te merk, 'n `T`.
///
/// As u 'n `PhantomData<T>`-veld by u tipe voeg, word die samesteller vertel dat u tipe optree asof dit 'n waarde van die tipe `T` stoor, alhoewel dit nie regtig is nie.
/// Hierdie inligting word gebruik vir die berekening van sekere veiligheidseienskappe.
///
/// Raadpleeg [the Nomicon](../../nomicon/phantom-data.html) vir 'n meer diepgaande uiteensetting van hoe u `PhantomData<T>` gebruik.
///
/// # 'N Vreeslike noot 👻👻👻
///
/// Alhoewel albei eng name het, is `PhantomData` en 'fantoomsoorte' verwant, maar nie identies nie.'N Fantome tipe parameter is eenvoudig 'n tipe parameter wat nooit gebruik word nie.
/// In Rust laat dit die samesteller dikwels kla, en die oplossing is om 'n "dummy"-gebruik by wyse van `PhantomData` by te voeg.
///
/// # Examples
///
/// ## Ongebruikte lewensduurparameters
///
/// Miskien is die mees algemene gebruiksgeval vir `PhantomData` 'n struktuur met 'n ongebruikte lewensduurparameter, gewoonlik as deel van 'n onveilige kode.
/// Hier is byvoorbeeld 'n struktuur `Slice` met twee aanwysers van die tipe `*const T` wat vermoedelik êrens in 'n skikking wys:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Die bedoeling is dat die onderliggende data slegs geldig is vir die leeftyd van `'a`, dus `Slice` moet nie `'a` oorleef nie.
/// Hierdie bedoeling word egter nie in die kode uitgedruk nie, aangesien die lewenslange `'a` nie gebruik word nie en dit dus nie duidelik is op watter data dit van toepassing is nie.
/// Ons kan dit regstel deur vir die samesteller te sê dat hy *moet optree asof* die `Slice`-struktuur 'n verwysing `&'a T` bevat:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Dit vereis ook weer die aantekening `T: 'a`, wat aandui dat enige verwysings in `T` gedurende die leeftyd van `'a` geldig is.
///
/// Wanneer u 'n `Slice` inisialiseer, gee u bloot die waarde `PhantomData` vir die veld `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Ongebruikte tipe parameters
///
/// Dit gebeur soms dat u ongebruikte tipe parameters het wat aandui vir watter tipe data 'n struktuur "tied" is, alhoewel die data nie eintlik in die struktuur self gevind word nie.
/// Hier is 'n voorbeeld waar dit met [FFI] ontstaan.
/// Die buitelandse koppelvlak gebruik handvatsels van die tipe `*mut ()` om na Rust-waardes van verskillende soorte te verwys.
/// Ons volg die Rust-tipe op met behulp van 'n fantoomtipe-parameter op die struct `ExternalResource` wat 'n handvatsel draai.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Eienaarskap en die drop check
///
/// Die toevoeging van 'n veld van die tipe `PhantomData<T>` dui aan dat u tipe data van die tipe `T` besit.Dit beteken weer dat wanneer u tipe laat val word, dit een of meer gevalle van die tipe `T` kan laat val.
/// Dit het invloed op die [drop check]-ontleding van die Rust-samesteller.
///
/// As u struktuur nie die data van die tipe `T`*besit nie, is dit beter om 'n verwysingstipe te gebruik, soos `PhantomData<&'a T>` (ideally) of `PhantomData<* const T>` (indien geen leeftyd van toepassing is nie) om nie eienaarskap aan te dui nie.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Samesteller-interne trait word gebruik om die tipe enum-diskriminante aan te dui.
///
/// Hierdie trait word outomaties geïmplementeer vir elke tipe en voeg geen waarborge by [`mem::Discriminant`] nie.
/// Dit is **ongedefinieerde gedrag** om tussen `DiscriminantKind::Discriminant` en `mem::Discriminant` te transformeer.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Die tipe diskriminant wat aan die trait bounds wat deur `mem::Discriminant` vereis word, moet voldoen.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Kompiler-interne trait word gebruik om vas te stel of 'n tipe intern `UnsafeCell` bevat, maar nie deur 'n rigting nie.
///
/// Dit beïnvloed byvoorbeeld of 'n `static` van die tipe in die leesalleen-statiese of skryfbare statiese geheue geplaas word.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Tipes wat veilig beweeg kan word nadat dit vasgepen is.
///
/// Rust self het geen idee van onbeweeglike tipes nie en beskou bewegings (bv. Deur opdrag of [`mem::replace`]) as altyd veilig.
///
/// Die [`Pin`][Pin]-tipe word gebruik om bewegings deur die tipe stelsel te voorkom.Wysers `P<T>` wat in die [`Pin<P<T>>`][Pin]-verpakking toegedraai is, kan nie verwyder word nie.
/// Raadpleeg die [`pin` module]-dokumentasie vir meer inligting oor vasmaak.
///
/// Die implementering van die `Unpin` trait vir `T` verhoog die beperkinge om die tipe vas te pen, wat dit moontlik maak om `T` uit [`Pin<P<T>>`][Pin] te skuif met funksies soos [`mem::replace`].
///
///
/// `Unpin` het glad nie 'n gevolg vir data wat nie vasgepen is nie.
/// In die besonder skuif [`mem::replace`] graag `!Unpin`-data (dit werk vir enige `&mut T`, nie net as `T: Unpin` nie).
/// U kan egter nie [`mem::replace`] gebruik op data wat in 'n [`Pin<P<T>>`][Pin] toegedraai is nie, omdat u nie die `&mut T` wat u nodig het daarvoor kry nie, en *dit* is wat hierdie stelsel laat werk.
///
/// Dit kan byvoorbeeld slegs gedoen word op tipes wat `Unpin` implementeer:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Ons benodig 'n veranderlike verwysing om `mem::replace` te noem.
/// // Ons kan so 'n verwysing verkry deur (implicitly) op `Pin::deref_mut` te beroep, maar dit is slegs moontlik omdat `String` `Unpin` implementeer.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Hierdie trait word outomaties geïmplementeer vir byna elke tipe.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// 'N Merker tipe wat nie `Unpin` implementeer nie.
///
/// As 'n tipe 'n `PhantomPinned` bevat, sal dit nie standaard `Unpin` implementeer nie.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Implementasies van `Copy` vir primitiewe tipes.
///
/// Implementasies wat nie in Rust beskryf kan word nie, word in `traits::SelectionContext::copy_clone_conditions()` in `rustc_trait_selection` geïmplementeer.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Gedeelde verwysings kan gekopieër word, maar veranderlike verwysings *kan nie* nie!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}