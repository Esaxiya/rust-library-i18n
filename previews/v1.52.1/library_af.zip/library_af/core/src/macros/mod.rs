#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Uit te brei na `$crate::panic::panic_2015` of `$crate::panic::panic_2021`, afhangende van die uitgawe van die oproeper.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Stel dat twee uitdrukkings gelyk is aan mekaar (gebruik [`PartialEq`]).
///
/// Op panic sal hierdie makro die waardes van die uitdrukkings met hul ontfoutvoorstellings druk.
///
///
/// Soos met [`assert!`], het hierdie makro 'n tweede vorm, waar 'n persoonlike panic-boodskap verskaf kan word.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Die volgende lenings is doelbewus.
                    // Daarsonder word die stapelgleuf vir die lening geïnisialiseer nog voordat die waardes vergelyk word, wat lei tot 'n merkbare verlangsaming.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Die volgende lenings is doelbewus.
                    // Daarsonder word die stapelgleuf vir die lening geïnisialiseer nog voordat die waardes vergelyk word, wat lei tot 'n merkbare verlangsaming.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Stel dat twee uitdrukkings nie gelyk is aan mekaar nie (gebruik [`PartialEq`]).
///
/// Op panic sal hierdie makro die waardes van die uitdrukkings met hul ontfoutvoorstellings druk.
///
///
/// Soos met [`assert!`], het hierdie makro 'n tweede vorm, waar 'n persoonlike panic-boodskap verskaf kan word.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Die volgende lenings is doelbewus.
                    // Daarsonder word die stapelgleuf vir die lening geïnisialiseer nog voordat die waardes vergelyk word, wat lei tot 'n merkbare verlangsaming.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Die volgende lenings is doelbewus.
                    // Daarsonder word die stapelgleuf vir die lening geïnisialiseer nog voordat die waardes vergelyk word, wat lei tot 'n merkbare verlangsaming.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Stel dat 'n booleaanse uitdrukking `true` tydens looptyd is.
///
/// Dit roep die [`panic!`]-makro op as die gegewe uitdrukking nie tydens looptyd tot `true` geëvalueer kan word nie.
///
/// Net soos [`assert!`], het hierdie makro ook 'n tweede weergawe, waar 'n persoonlike panic-boodskap verskaf kan word.
///
/// # Uses
///
/// Anders as [`assert!`], word `debug_assert!`-stellings standaard slegs in nie-geoptimaliseerde builds geaktiveer.
/// 'N Geoptimaliseerde build sal nie `debug_assert!`-state uitvoer nie, tensy `-C debug-assertions` aan die samesteller gestuur word.
/// Dit maak `debug_assert!` nuttig vir tjeks wat te duur is om in 'n release-build te wees, maar wat nuttig kan wees tydens ontwikkeling.
/// Die resultaat van die uitbreiding van `debug_assert!` word altyd getoets.
///
/// 'N Ongekontroleerde bewering laat 'n program in 'n inkonsekwente toestand aanhou, wat onverwagte gevolge kan hê, maar nie onveiligheid inhou nie, solank dit net in veilige kode gebeur.
///
/// Die prestasiekoste van bewerings is egter oor die algemeen nie meetbaar nie.
/// Die vervanging van [`assert!`] met `debug_assert!` word dus slegs aangemoedig na deeglike profilering, en, nog belangriker, slegs in veilige kode!
///
/// # Examples
///
/// ```
/// // die panic-boodskap vir hierdie bewerings is die gestreepte waarde van die gegewe uitdrukking.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // 'n baie eenvoudige funksie
/// debug_assert!(some_expensive_computation());
///
/// // beweer met 'n persoonlike boodskap
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Stel dat twee uitdrukkings gelyk aan mekaar is.
///
/// Op panic sal hierdie makro die waardes van die uitdrukkings met hul ontfoutvoorstellings druk.
///
/// Anders as [`assert_eq!`], word `debug_assert_eq!`-stellings standaard slegs in nie-geoptimaliseerde builds geaktiveer.
/// 'N Geoptimaliseerde build sal nie `debug_assert_eq!`-state uitvoer nie, tensy `-C debug-assertions` aan die samesteller gestuur word.
/// Dit maak `debug_assert_eq!` nuttig vir tjeks wat te duur is om in 'n release-build te wees, maar wat nuttig kan wees tydens ontwikkeling.
///
/// Die resultaat van die uitbreiding van `debug_assert_eq!` word altyd getoets.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Stel dat twee uitdrukkings nie gelyk is aan mekaar nie.
///
/// Op panic sal hierdie makro die waardes van die uitdrukkings met hul ontfoutvoorstellings druk.
///
/// Anders as [`assert_ne!`], word `debug_assert_ne!`-stellings standaard slegs in nie-geoptimaliseerde builds geaktiveer.
/// 'N Geoptimaliseerde build sal nie `debug_assert_ne!`-state uitvoer tensy `-C debug-assertions` aan die samesteller oorgedra word nie.
/// Dit maak `debug_assert_ne!` nuttig vir tjeks wat te duur is om in 'n release-build te wees, maar wat nuttig kan wees tydens ontwikkeling.
///
/// Die resultaat van die uitbreiding van `debug_assert_ne!` word altyd getoets.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Wys terug of die gegewe uitdrukking ooreenstem met een van die gegewe patrone.
///
/// Soos in 'n `match`-uitdrukking, kan die patroon opsioneel gevolg word deur `if` en 'n beskermingsuitdrukking wat toegang het tot name wat deur die patroon gebind is.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Pak 'n resultaat uit of versprei die fout.
///
/// Die `?`-operateur is bygevoeg om `try!` te vervang en moet eerder gebruik word.
/// Verder is `try` 'n gereserveerde woord in Rust 2018, dus as u dit moet gebruik, moet u die [raw-identifier syntax][ris] gebruik: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` pas by die gegewe [`Result`].In die geval van die `Ok`-variant het die uitdrukking die waarde van die toegedraaide waarde.
///
/// In die geval van die `Err`-variant, haal dit die innerlike fout op.`try!` voer dan die omskakeling uit met behulp van `From`.
/// Dit bied outomatiese omskakeling tussen gespesialiseerde foute en meer algemene foute.
/// Die gevolglike fout word dan onmiddellik teruggestuur.
///
/// Vanweë die vroeë terugkeer kan `try!` slegs gebruik word in funksies wat [`Result`] terugstuur.
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Die voorkeurmetode vir vinnige terugkeer van foute
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Die vorige metode om vinnige foute terug te keer
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Dit is gelykstaande aan:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Skryf geformateerde data in 'n buffer.
///
/// Hierdie makro aanvaar 'n 'writer', 'n formaatreeks en 'n lys argumente.
/// Argumente word geformateer volgens die gespesifiseerde snaar en die resultaat sal aan die skrywer oorgedra word.
/// Die skrywer kan enige waarde hê met 'n `write_fmt`-metode;oor die algemeen kom dit uit die implementering van die [`fmt::Write`] of die [`io::Write`] trait.
/// Die makro lewer terug wat die `write_fmt`-metode oplewer;gewoonlik 'n [`fmt::Result`], of 'n [`io::Result`].
///
/// Raadpleeg [`std::fmt`] vir meer inligting oor die formaat van die sintaksis van die snaar.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// 'N Module kan beide `std::fmt::Write` en `std::io::Write` invoer en `write!` noem op voorwerpe wat geïmplementeer word, aangesien voorwerpe gewoonlik nie albei implementeer nie.
///
/// Die module moet egter die traits-gekwalifiseerde invoer, sodat hul name nie bots nie:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // gebruik fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // gebruik io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Hierdie makro kan ook in `no_std`-opstellings gebruik word.
/// In 'n `no_std`-opstelling is u verantwoordelik vir die implementeringsbesonderhede van die komponente.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Skryf geformateerde data in 'n buffer, met 'n nuwe lyn bygevoeg.
///
/// Op alle platforms is die nuwe lyn slegs die LINE FEED-karakter (`\n`/`U+000A`) (geen addisionele WAGRETOUR (`\r`/`U+000D`) nie.
///
/// Vir meer inligting, sien [`write!`].Vir meer inligting oor die formaat van die sintaksis, sien [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// 'N Module kan beide `std::fmt::Write` en `std::io::Write` invoer en `write!` noem op voorwerpe wat geïmplementeer word, aangesien voorwerpe gewoonlik nie albei implementeer nie.
/// Die module moet egter die traits-gekwalifiseerde invoer, sodat hul name nie bots nie:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // gebruik fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // gebruik io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Dui onbereikbare kode aan.
///
/// Dit is nuttig wanneer die samesteller nie kan vasstel dat sommige kode onbereikbaar is nie.Byvoorbeeld:
///
/// * Pas arms aan by beskermingstoestande.
/// * Lusse wat dinamies eindig.
/// * Iterators wat dinamies beëindig word.
///
/// As die bepaling dat die kode onbereikbaar is, verkeerd blyk, word die program onmiddellik beëindig met 'n [`panic!`].
///
/// Die onveilige eweknie van hierdie makro is die [`unreachable_unchecked`]-funksie, wat ongedefinieerde gedrag sal veroorsaak as die kode bereik word.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Dit sal altyd [`panic!`] wees.
///
/// # Examples
///
/// Pas arms:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // fout saamstel as kommentaar gelewer word
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // een van die swakste implementasies van x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Dui onimplementeerde kode aan deur paniekbevange te raak met die boodskap van "not implemented".
///
/// Hierdeur kan u kode kontroleer, wat handig is as u 'n trait prototipeer of implementeer wat veelvuldige metodes benodig wat u nie van plan is nie.
///
/// Die verskil tussen `unimplemented!` en [`todo!`] is dat hoewel `todo!` die bedoeling oordra om die funksionaliteit later te implementeer en die boodskap "not yet implemented" is, maak `unimplemented!` geen sulke eise nie.
/// Die boodskap daarvan is "not implemented".
/// Sommige IDE's sal ook 'todo!' S aandui.
///
/// # Panics
///
/// Dit sal altyd [`panic!`] wees, want `unimplemented!` is slegs 'n snelskrif vir `panic!` met 'n vaste, spesifieke boodskap.
///
/// Soos met `panic!`, het hierdie makro 'n tweede vorm om persoonlike waardes te vertoon.
///
/// # Examples
///
/// Sê ons het 'n trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Ons wil `Foo` vir 'MyStruct' implementeer, maar om die een of ander rede is dit net sinvol om die `bar()`-funksie te implementeer.
/// `baz()` en `qux()` sal steeds gedefinieër moet word tydens ons implementering van `Foo`, maar ons kan `unimplemented!` in hul definisies gebruik om ons kode saam te stel.
///
/// Ons wil steeds hê dat ons program moet stop as die onimplementeerde metodes bereik word.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Dit is nie sinvol om `baz` en `MyStruct` te gebruik nie, en ons het dus geen logika hier nie.
/////
///         // Dit sal "thread 'main' panicked at 'not implemented'" vertoon.
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Ons het 'n bietjie logika hier, ons kan 'n boodskap by onimplementeer!om ons versuim te vertoon.
///         // Dit sal vertoon: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Dui onvoltooide kode aan.
///
/// Dit kan handig wees as u prototipeer en net u kodetipe wil toets.
///
/// Die verskil tussen [`unimplemented!`] en `todo!` is dat hoewel `todo!` die bedoeling oordra om die funksionaliteit later te implementeer en die boodskap "not yet implemented" is, maak `unimplemented!` geen sulke eise nie.
/// Die boodskap daarvan is "not implemented".
/// Sommige IDE's sal ook 'todo!' S aandui.
///
/// # Panics
///
/// Dit sal altyd [`panic!`] wees.
///
/// # Examples
///
/// Hier is 'n voorbeeld van 'n lopende kode.Ons het 'n trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Ons wil `Foo` op een van ons tipes implementeer, maar ons wil ook eers aan net `bar()` werk.Om ons kode te kan saamstel, moet ons `baz()` implementeer, sodat ons `todo!` kan gebruik:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // implementering gaan hier
///     }
///
///     fn baz(&self) {
///         // laat ons ons nou nie bekommer oor die implementering van baz() nie
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // ons gebruik nie eens baz() nie, so dit is goed.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Definisies van ingeboude makro's.
///
/// Die meeste makro-eienskappe (stabiliteit, sigbaarheid, ens.) Word hier van die bronkode geneem, met uitsondering van uitbreidingsfunksies wat makro-insette in uitsette omskep, word die funksies deur die samesteller voorsien.
///
///
pub(crate) mod builtin {

    /// Laat samestelling misluk met die gegewe foutboodskap wanneer dit teëgekom word.
    ///
    /// Hierdie makro moet gebruik word as 'n crate 'n voorwaardelike samestellingstrategie gebruik om beter foutboodskappe vir foutiewe toestande te bied.
    ///
    /// Dit is die kompilerervlak van [`panic!`], maar gee 'n fout tydens *samestelling* eerder as tydens *runtime*.
    ///
    /// # Examples
    ///
    /// Twee sulke voorbeelde is makro's en `#[cfg]`-omgewings.
    ///
    /// Stuur 'n beter samestellerfout as 'n ongeldige waardes deur 'n makro oorgedra word.
    /// Sonder die finale branch sal die samesteller steeds 'n fout uitstuur, maar die twee geldige waardes word nie in die boodskap van die fout genoem nie.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Stel samestellerfout uit as een van 'n aantal funksies nie beskikbaar is nie.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Stel parameters vir die ander makro's vir snaaropmaak.
    ///
    /// Hierdie makro funksioneer deur 'n formateringstring letterlik met `{}` te neem vir elke bykomende argument.
    /// `format_args!` berei die bykomende parameters voor om te verseker dat die uitvoer as 'n string geïnterpreteer kan word en kan die argumente in 'n enkele tipe kanoniseer.
    /// Enige waarde wat die [`Display`] trait implementeer, kan aan `format_args!` oorgedra word, asook enige [`Debug`]-implementering na 'n `{:?}` binne die opmaakstring.
    ///
    ///
    /// Hierdie makro lewer 'n waarde van die tipe [`fmt::Arguments`].Hierdie waarde kan na die makro's binne [`std::fmt`] oorgedra word om nuttige herleiding uit te voer.
    /// Alle ander formateringsmakro's ([`formaat! '], [`write!`], [`println!`], ens.) Word deur hierdie een gevoeg.
    /// `format_args!`, anders as die afgeleide makro's, word die toewysing van hope vermy.
    ///
    /// U kan die [`fmt::Arguments`]-waarde wat `format_args!` oplewer in `Debug`-en `Display`-kontekste gebruik, soos hieronder gesien.
    /// Die voorbeeld toon ook dat die `Debug`-en `Display`-formaat dieselfde is: die geïnterpoleerde formaatreeks in `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Raadpleeg die dokumentasie in [`std::fmt`] vir meer inligting.
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Dieselfde as `format_args`, maar voeg uiteindelik 'n nuwe lyn by.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Inspekteer 'n omgewingsveranderlike tydens kompileringstyd.
    ///
    /// Hierdie makro sal op kompileringstyd tot die waarde van die genoemde omgewingsveranderlike uitbrei, wat 'n uitdrukking van die tipe `&'static str` lewer.
    ///
    ///
    /// As die omgewingsveranderlike nie gedefinieer word nie, word 'n kompileringsfout uitgestuur.
    /// Gebruik nie die [`option_env!`]-makro om 'n kompileringsfout uit te gee nie.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// U kan die foutboodskap aanpas deur 'n string as die tweede parameter deur te gee:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// As die `documentation`-omgewingsveranderlike nie gedefinieër is nie, kry u die volgende fout:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Inspekteer opsioneel 'n omgewingsveranderlike tydens kompileringstyd.
    ///
    /// As die genoemde omgewingsveranderlike teenwoordig is tydens kompilering, sal dit uitbrei na 'n uitdrukking van die tipe `Option<&'static str>` waarvan die waarde `Some` van die waarde van die omgewingsveranderlike is.
    /// As die omgewingsveranderlike nie aanwesig is nie, sal dit uitbrei na `None`.
    /// Sien [`Option<T>`][Option] vir meer inligting oor hierdie tipe.
    ///
    /// 'N Samestellingstydfout word nooit uitgestraal tydens die gebruik van hierdie makro nie, ongeag of die omgewingsveranderlike wel of nie is nie.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Verbind identifikasies tot een identifiseerder.
    ///
    /// Hierdie makro neem 'n aantal komma-geskeide identifiseerders en verbind dit almal tot een, wat 'n nuwe uitdrukking gee.
    /// Let daarop dat higiëne dit so maak dat hierdie makro nie plaaslike veranderlikes kan vasvang nie.
    /// In die algemeen is makro's slegs toegelaat in die posisie van die item, die stelling of die uitdrukking.
    /// Dit beteken dat, hoewel u hierdie makro mag gebruik om na bestaande veranderlikes, funksies of modules, ens. Te verwys, u nie 'n nuwe een daarmee kan definieer nie.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (nuut, lekker, naam) { }//nie op hierdie manier bruikbaar nie!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Bind literale in 'n statiese snysnit.
    ///
    /// Hierdie makro neem 'n aantal komma-geskeide lettertekens op, wat 'n uitdrukking van die tipe `&'static str` gee wat al die letterkuns van links na regs aaneengeskakel het.
    ///
    ///
    /// Heelgetalle en drywende letterlyste word gestreef om saamgevoeg te word.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Brei uit na die reëlnommer waarop dit aangeroep is.
    ///
    /// Met [`column!`] en [`file!`] bied hierdie makro's ontfoutingsinligting vir ontwikkelaars oor die ligging binne die bron.
    ///
    /// Die uitgebreide uitdrukking het die tipe `u32` en is op 1 gebaseer, dus die eerste reël in elke lêer word geëvalueer tot 1, die tweede tot 2, ens.
    /// Dit stem ooreen met foutboodskappe deur algemene samestellers of gewilde redakteurs.
    /// Die teruggekeerde lyn is *nie noodwendig* die lyn van die `line!`-aanroeping self nie, maar eerder die eerste makro-aanroeping wat lei tot die aanroep van die `line!`-makro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Brei uit na die kolomnommer waarop dit opgeroep is.
    ///
    /// Met [`line!`] en [`file!`] bied hierdie makro's ontfoutingsinligting vir ontwikkelaars oor die ligging binne die bron.
    ///
    /// Die uitgebreide uitdrukking het die tipe `u32` en is op 1 gebaseer, dus die eerste kolom in elke reël word geëvalueer tot 1, die tweede tot 2, ens.
    /// Dit stem ooreen met foutboodskappe deur algemene samestellers of gewilde redakteurs.
    /// Die teruggekeerde kolom is *nie noodwendig* die lyn van die `column!`-aanroeping nie, maar eerder die eerste makro-aanroep wat gelei het tot die aanroep van die `column!`-makro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Brei uit na die lêernaam waarin dit opgeroep is.
    ///
    /// Met [`line!`] en [`column!`] bied hierdie makro's ontfoutingsinligting vir ontwikkelaars oor die ligging binne die bron.
    ///
    /// Die uitgebreide uitdrukking het die tipe `&'static str`, en die teruggestuurde lêer is nie die aanroep van die `file!`-makro self nie, maar eerder die eerste makro-aanroeping wat lei tot die aanroep van die `file!`-makro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Beperk sy argumente.
    ///
    /// Hierdie makro gee 'n uitdrukking van die tipe `&'static str`, wat die stringering is van al die tokens wat aan die makro oorgedra word.
    /// Die sintaksis van die makro-aanroeping word nie beperk nie.
    ///
    /// Let daarop dat die uitgebreide resultate van die invoer tokens in die future kan verander.U moet versigtig wees as u op die uitset vertrou.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Sluit 'n UTF-8-gekodeerde lêer in as 'n string.
    ///
    /// Die lêer is relatief tot die huidige lêer (soortgelyk aan hoe modules gevind word).
    /// Die gegewe pad word op kompileringstyd op 'n platformspesifieke manier geïnterpreteer.
    /// Dus, byvoorbeeld, sou 'n aanroep met 'n Windows-pad wat die terugslag `\` bevat, nie korrek saamstel op Unix nie.
    ///
    ///
    /// Hierdie makro gee 'n uitdrukking van die tipe `&'static str`, wat die inhoud van die lêer is.
    ///
    /// # Examples
    ///
    /// Gestel daar is twee lêers in dieselfde gids met die volgende inhoud:
    ///
    /// Lêer 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Lêer 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// As u 'main.rs' opstel en die resulterende binêre uitvoer, word "adiós" gedruk.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Sluit 'n lêer in as verwysing na 'n byte-skikking.
    ///
    /// Die lêer is relatief tot die huidige lêer (soortgelyk aan hoe modules gevind word).
    /// Die gegewe pad word op kompileringstyd op 'n platformspesifieke manier geïnterpreteer.
    /// Dus, byvoorbeeld, sou 'n aanroep met 'n Windows-pad wat die terugslag `\` bevat, nie korrek saamstel op Unix nie.
    ///
    ///
    /// Hierdie makro gee 'n uitdrukking van die tipe `&'static [u8; N]`, wat die inhoud van die lêer is.
    ///
    /// # Examples
    ///
    /// Gestel daar is twee lêers in dieselfde gids met die volgende inhoud:
    ///
    /// Lêer 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Lêer 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// As u 'main.rs' opstel en die resulterende binêre uitvoer, word "adiós" gedruk.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Brei uit na 'n string wat die huidige modulepad voorstel.
    ///
    /// Die huidige modulepad kan beskou word as die hiërargie van modules wat lei tot die crate root.
    /// Die eerste komponent van die teruggestuurde pad is die naam van die crate wat tans saamgestel word.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Evalueer booleaanse kombinasies van konfigurasievlae tydens kompileringstyd.
    ///
    /// Benewens die `#[cfg]`-kenmerk, word hierdie makro verskaf om die boole-uitdrukking van konfigurasievlae moontlik te maak.
    /// Dit lei gereeld tot minder gedupliseerde kode.
    ///
    /// Die sintaksis wat aan hierdie makro gegee word, is dieselfde sintaksis as die [`cfg`]-kenmerk.
    ///
    /// `cfg!`, in teenstelling met `#[cfg]`, verwyder dit geen kode nie en evalueer dit net waar of onwaar.
    /// Byvoorbeeld, alle blokke in 'n if/else-uitdrukking moet geldig wees wanneer `cfg!` vir die toestand gebruik word, ongeag wat `cfg!` evalueer.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Parseer 'n lêer as 'n uitdrukking of 'n item volgens die konteks.
    ///
    /// Die lêer is relatief tot die huidige lêer (soortgelyk aan hoe modules gevind word).Die gegewe pad word op kompileringstyd op 'n platformspesifieke manier geïnterpreteer.
    /// Dus, byvoorbeeld, sou 'n aanroep met 'n Windows-pad wat die terugslag `\` bevat, nie korrek saamstel op Unix nie.
    ///
    /// Die gebruik van hierdie makro is dikwels 'n slegte idee, want as die lêer as 'n uitdrukking geparseer word, sal dit onhigiënies in die omliggende kode geplaas word.
    /// Dit kan daartoe lei dat veranderlikes of funksies verskil van wat die lêer verwag het as daar veranderlikes of funksies is wat dieselfde naam in die huidige lêer het.
    ///
    ///
    /// # Examples
    ///
    /// Gestel daar is twee lêers in dieselfde gids met die volgende inhoud:
    ///
    /// Lêer 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Lêer 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// As u 'main.rs' opstel en die resulterende binêre uitvoer, word "🙈🙊🙉🙈🙊🙉" gedruk.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Stel dat 'n booleaanse uitdrukking `true` tydens looptyd is.
    ///
    /// Dit roep die [`panic!`]-makro op as die gegewe uitdrukking nie tydens looptyd tot `true` geëvalueer kan word nie.
    ///
    /// # Uses
    ///
    /// Bewerings word altyd in debug-en release-builds nagegaan en kan nie gedeaktiveer word nie.
    /// Kyk na [`debug_assert!`] vir bewerings wat nie in release builds geaktiveer is nie.
    ///
    /// Onveilige kode berus dalk op `assert!` om invoerders van die tydsduur af te dwing wat, as dit oortree word, tot onveiligheid kan lei.
    ///
    /// Ander gebruiksgevalle van `assert!` sluit in die toets en afdwinging van lopende invariërs in veilige kode (waarvan die oortreding nie tot onveiligheid kan lei nie).
    ///
    ///
    /// # Persoonlike boodskappe
    ///
    /// Hierdie makro het 'n tweede vorm, waar 'n persoonlike panic-boodskap voorsien kan word met of sonder argumente vir opmaak.
    /// Sien [`std::fmt`] vir sintaksis vir hierdie vorm.
    /// Uitdrukkings wat as formaatargumente gebruik word, sal slegs geëvalueer word as die bewering misluk.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // die panic-boodskap vir hierdie bewerings is die gestreepte waarde van die gegewe uitdrukking.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // 'n baie eenvoudige funksie
    ///
    /// assert!(some_computation());
    ///
    /// // beweer met 'n persoonlike boodskap
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Inline vergadering.
    ///
    /// Lees die [unstable book] vir gebruik.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM-styl inlyn vergadering.
    ///
    /// Lees die [unstable book] vir gebruik.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Inline-samestelling op modulevlak.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Afdrukke het tokens in die standaarduitset oorgedra.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Aktiveer of deaktiveer opspoorfunksies wat gebruik word vir die ontfouting van ander makro's.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Kenmerkmakro wat gebruik word om afgeleide makro's toe te pas.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Kenmerkingsmakro toegepas op 'n funksie om dit in 'n eenheidstoets te verander.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Kenmerkingsmakro toegepas op 'n funksie om dit in 'n normtoets te verander.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// 'N Implementeringsdetail van die `#[test]`-en `#[bench]`-makro's.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Kenmerkmakro toegepas op 'n statiese om dit as 'n globale toekenning te registreer.
    ///
    /// Sien ook [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Behou die item waarop dit toegepas is as die geslaagde pad toeganklik is, en verwyder dit anders.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Brei alle `#[cfg]`-en `#[cfg_attr]`-eienskappe uit in die kodefragment waarop dit toegepas word.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Onstabiele implementeringsdetail van die `rustc`-samesteller, moenie dit gebruik nie.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Onstabiele implementeringsdetail van die `rustc`-samesteller, moenie dit gebruik nie.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}