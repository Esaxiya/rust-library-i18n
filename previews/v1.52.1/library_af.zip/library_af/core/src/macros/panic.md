Panics die huidige draad.

Dit stel 'n program in staat om onmiddellik te beëindig en terugvoer te gee aan die oproeper van die program.
`panic!` moet gebruik word wanneer 'n program 'n onherstelbare toestand bereik.

Hierdie makro is die perfekte manier om voorwaardes in voorbeeldkode en toetse te laat geld.
`panic!` is nou gekoppel aan die `unwrap`-metode van beide [`Option`][ounwrap]-en [`Result`][runwrap]-enums.
Albei implementasies noem `panic!` wanneer dit op [`None`] of [`Err`]-variante ingestel is.

As u `panic!()` gebruik, kan u 'n snaarbelasting spesifiseer wat gebou is met behulp van die [`format!`]-sintaksis.
Die loonvrag word gebruik as u die panic in die roepende Rust-draad inspuit, wat veroorsaak dat die draad heeltemal panic word.

Die gedrag van die standaard `std` hook, dws
die kode wat direk na die aanroep van die panic gebruik word, is om die loonvrag na `stderr` saam met die file/line/column-inligting van die `panic!()`-oproep te druk.

U kan die panic hook met [`std::panic::set_hook()`] ignoreer.
Binne die hook is toegang tot panic beskikbaar as 'n `&dyn Any + Send`, wat óf 'n `&str` óf `String` bevat vir gewone `panic!()`-aanroepe.
Om panic met 'n ander waarde te gebruik, kan [`panic_any`] gebruik word.

[`Result`] enum is dikwels 'n beter oplossing vir die herstel van foute as om die `panic!`-makro te gebruik.
Hierdie makro moet gebruik word om te verhoed dat u verkeerde waardes gebruik, soos van eksterne bronne.
Gedetailleerde inligting oor fouthantering word in die [book] gevind.

Kyk ook in die makro [`compile_error!`] om foute tydens samestelling op te stel.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Huidige implementering

As die hoofdraad panics al u drade beëindig en u program met kode `101` afsluit.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





