//! Stringmanipulasie.
//!
//! Vir meer besonderhede, sien die [`std::str`]-module.
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. buite perke
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. begin <=einde
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. karaktergrens
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // vind die karakter
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` moet minder as len en 'n kolgrens wees
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Wys die lengte van `self`.
    ///
    /// Hierdie lengte is in grepe, nie [`char`] of grafeme nie.
    /// Met ander woorde, dit is miskien nie wat 'n mens as die lengte van die tou beskou nie.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // fancy f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Wys `true` as `self` 'n lengte van nul grepe het.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Kontroleer of 'index'-de byte die eerste byte in 'n UTF-8-kodepuntreeks of die einde van die string is.
    ///
    ///
    /// Die begin en einde van die string (as `index== self.len()`) as grense beskou word.
    ///
    /// Wys `false` as `index` groter is as `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // begin van `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // tweede greep van `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // derde byte van `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 en len is altyd ok.
        // Toets eksplisiet vir 0 sodat dit die tjek maklik kan optimaliseer en die lees van stringdata vir daardie geval kan oorslaan.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Dit is 'n bietjie towerkrag gelykstaande aan: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Skakel 'n snysny in 'n byte sny om.
    /// Gebruik die [`from_utf8`]-funksie om die byte-stuk weer in 'n snysnit te omskep.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // VEILIGHEID: const-geluid omdat ons twee soorte met dieselfde uitleg transformeer
        unsafe { mem::transmute(self) }
    }

    /// Skakel 'n veranderlike snysnit na 'n veranderlike byte-stuk om.
    ///
    /// # Safety
    ///
    /// Die beller moet toesien dat die inhoud van die sny UTF-8 geldig is voordat die lening eindig en die onderliggende `str` gebruik word.
    ///
    ///
    /// Die gebruik van 'n `str` waarvan die inhoud nie geldig is nie UTF-8 is ongedefinieerde gedrag.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // VEILIGHEID: die rolverdeling van `&str` tot `&[u8]` is veilig sedert `str`
        // het dieselfde uitleg as `&[u8]` (slegs libstd kan hierdie waarborg gee).
        // Die verwysing van die wyser is veilig, want dit kom van 'n veranderlike verwysing wat verseker geldig is vir skryfwerk.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Skakel 'n snysnit na 'n rou wyser om.
    ///
    /// Aangesien snysnitte 'n stuk bytes is, wys die rou wyser op 'n [`u8`].
    /// Hierdie wyser sal na die eerste byte van die snytjie wys.
    ///
    /// Die beller moet toesien dat daar nooit aan die teruggekeerde wyser geskryf word nie.
    /// Gebruik [`as_mut_ptr`] as u die inhoud van die snytjie moet muteer.
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Skakel 'n veranderlike snysnit na 'n rou wyser.
    ///
    /// Aangesien snysnitte 'n stuk bytes is, wys die rou wyser op 'n [`u8`].
    /// Hierdie wyser sal na die eerste byte van die snytjie wys.
    ///
    /// Dit is u verantwoordelikheid om seker te maak dat die snytjie slegs verander word op 'n manier dat dit geldig bly UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Wys 'n onderdeel van `str`.
    ///
    /// Dit is die nie-paniekerige alternatief vir die indeksering van die `str`.
    /// Wys [`None`] as ekwivalente indekseringsbewerking panic sou wees.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // indekse wat nie op UTF-8 volgorde grense is nie
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // buite perke
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Wys 'n veranderlike onderdeel van `str`.
    ///
    /// Dit is die nie-paniekerige alternatief vir die indeksering van die `str`.
    /// Wys [`None`] as ekwivalente indekseringsbewerking panic sou wees.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // korrekte lengte
    /// assert!(v.get_mut(0..5).is_some());
    /// // buite perke
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Wys 'n ongemerkte onderdeel van `str`.
    ///
    /// Dit is die ongekontroleerde alternatief vir die indeksering van die `str`.
    ///
    /// # Safety
    ///
    /// Bellers van hierdie funksie is daarvoor verantwoordelik dat aan hierdie voorwaardes voldoen word:
    ///
    /// * Die beginindeks mag nie die eindindeks oorskry nie;
    /// * Indekse moet binne die perke van die oorspronklike sny wees;
    /// * Indekse moet op UTF-8 volgorde grense lê.
    ///
    /// As dit nie slaag nie, kan die snytjie wat teruggestuur word, verwys na ongeldige geheue of inbreuk maak op die invariërs wat deur die `str`-tipe gekommunikeer word.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // VEILIGHEID: die beller moet die veiligheidskontrak vir `get_unchecked` handhaaf;
        // die plak kan afgelei word omdat `self` 'n veilige verwysing is.
        // Die teruggekeerde aanwyser is veilig, want die implantate van `SliceIndex` moet waarborg dat dit so is.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Wys 'n veranderlike, ongekontroleerde onderdeel van `str`.
    ///
    /// Dit is die ongekontroleerde alternatief vir die indeksering van die `str`.
    ///
    /// # Safety
    ///
    /// Bellers van hierdie funksie is daarvoor verantwoordelik dat aan hierdie voorwaardes voldoen word:
    ///
    /// * Die beginindeks mag nie die eindindeks oorskry nie;
    /// * Indekse moet binne die perke van die oorspronklike sny wees;
    /// * Indekse moet op UTF-8 volgorde grense lê.
    ///
    /// As dit nie slaag nie, kan die snytjie wat teruggestuur word, verwys na ongeldige geheue of inbreuk maak op die invariërs wat deur die `str`-tipe gekommunikeer word.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // VEILIGHEID: die beller moet die veiligheidskontrak vir `get_unchecked_mut` handhaaf;
        // die plak kan afgelei word omdat `self` 'n veilige verwysing is.
        // Die teruggekeerde aanwyser is veilig, want die implantate van `SliceIndex` moet waarborg dat dit so is.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Skep 'n snysnit uit 'n ander snysnit, en omseil veiligheidskontroles.
    ///
    /// Dit word gewoonlik nie aanbeveel nie; gebruik dit met omsigtigheid!Vir 'n veilige alternatief, sien [`str`] en [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Hierdie nuwe deel gaan van `begin` na `end`, insluitend `begin`, maar `end` uitgesluit.
    ///
    /// Raadpleeg die [`slice_mut_unchecked`]-metode om eerder 'n veranderlike snysnit te kry.
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Bellers van hierdie funksie is verantwoordelik dat daar aan drie voorwaardes voldoen word:
    ///
    /// * `begin` mag nie `end` oorskry nie.
    /// * `begin` en `end` moet byteposisies binne die snysnit wees.
    /// * `begin` en `end` moet op UTF-8 volgorde grense lê.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // VEILIGHEID: die beller moet die veiligheidskontrak vir `get_unchecked` handhaaf;
        // die plak kan afgelei word omdat `self` 'n veilige verwysing is.
        // Die teruggekeerde aanwyser is veilig, want die implantate van `SliceIndex` moet waarborg dat dit so is.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Skep 'n snysnit uit 'n ander snysnit, en omseil veiligheidskontroles.
    /// Dit word gewoonlik nie aanbeveel nie; gebruik dit met omsigtigheid!Vir 'n veilige alternatief, sien [`str`] en [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Hierdie nuwe deel gaan van `begin` na `end`, insluitend `begin`, maar `end` uitgesluit.
    ///
    /// Raadpleeg die [`slice_unchecked`]-metode om 'n onveranderlike snysnit te kry.
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Bellers van hierdie funksie is verantwoordelik dat daar aan drie voorwaardes voldoen word:
    ///
    /// * `begin` mag nie `end` oorskry nie.
    /// * `begin` en `end` moet byteposisies binne die snysnit wees.
    /// * `begin` en `end` moet op UTF-8 volgorde grense lê.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // VEILIGHEID: die beller moet die veiligheidskontrak vir `get_unchecked_mut` handhaaf;
        // die plak kan afgelei word omdat `self` 'n veilige verwysing is.
        // Die teruggekeerde aanwyser is veilig, want die implantate van `SliceIndex` moet waarborg dat dit so is.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Verdeel een snysnit in twee by 'n indeks.
    ///
    /// Die argument, `mid`, moet 'n byte-verrekening wees vanaf die begin van die string.
    /// Dit moet ook op die grens van 'n UTF-8-kodepunt wees.
    ///
    /// Die twee snye wat teruggestuur word, gaan vanaf die begin van die snyplaat na `mid`, en van `mid` tot aan die einde van die snyplaat.
    ///
    /// Raadpleeg die [`split_at_mut`]-metode om veranderlike snytjies te kry.
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics as `mid` nie op 'n UTF-8-kodepuntgrens is nie, of as dit aan die einde van die laaste kodepunt van die snyplaat is.
    ///
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary tjeks of die indeks in [0, .len()]
        if self.is_char_boundary(mid) {
            // VEILIGHEID: het net gekontroleer of `mid` op 'n kolgrens is.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Verdeel een veranderlike snysnit in 'n indeks in twee.
    ///
    /// Die argument, `mid`, moet 'n byte-verrekening wees vanaf die begin van die string.
    /// Dit moet ook op die grens van 'n UTF-8-kodepunt wees.
    ///
    /// Die twee snye wat teruggestuur word, gaan vanaf die begin van die snyplaat na `mid`, en van `mid` tot aan die einde van die snyplaat.
    ///
    /// Raadpleeg die [`split_at`]-metode om onveranderlike snysnye te kry.
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics as `mid` nie op 'n UTF-8-kodepuntgrens is nie, of as dit aan die einde van die laaste kodepunt van die snyplaat is.
    ///
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary tjeks of die indeks in [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // VEILIGHEID: het net gekontroleer of `mid` op 'n kolgrens is.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Wys 'n iterator oor die [`char`] s van 'n snytjie.
    ///
    /// Aangesien 'n snysnit uit geldige UTF-8 bestaan, kan ons dit deur 'n snysnit met [`char`] herhaal.
    /// Hierdie metode gee so 'n iterator terug.
    ///
    /// Dit is belangrik om te onthou dat [`char`] 'n Unicode Scalar Value verteenwoordig, en dat dit miskien nie ooreenstem met u idee van wat 'n 'character' is nie.
    ///
    /// Iterasie oor grafeme-trosse is miskien wat u eintlik wil hê.
    /// Hierdie funksie word nie deur die standaardbiblioteek van Rust voorsien nie; kyk crates.io eerder.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Onthou, [`char`] kan nie ooreenstem met u intuïsie oor karakters nie:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // nie 'y̆' nie
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Lewer 'n iterator oor die [`char`] s van 'n snytjie en hul posisies.
    ///
    /// Aangesien 'n snysnit uit geldige UTF-8 bestaan, kan ons dit deur 'n snysnit met [`char`] herhaal.
    /// Hierdie metode gee 'n iterator van beide hierdie [`char`] s sowel as hul byte-posisies terug.
    ///
    /// Die iterator lewer tuisies.Die posisie is eerste, die [`char`] tweede.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Onthou, [`char`] kan nie ooreenstem met u intuïsie oor karakters nie:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // nie (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // let op die 3 hier, die laaste karakter het twee grepe opgeneem
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// 'N Iterator oor die grepe van 'n snytjie.
    ///
    /// Aangesien 'n snysnit uit 'n reeks bytes bestaan, kan ons dit deur 'n string sny vir byte herhaal.
    /// Hierdie metode gee so 'n iterator terug.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Verdeel 'n snysnit op witruimte.
    ///
    /// Die iterator wat teruggestuur word, gee snyskywe terug wat sub-snye van die oorspronklike snysnit is, geskei deur enige hoeveelheid spasie.
    ///
    ///
    /// 'Whitespace' word gedefinieer volgens die bepalings van die Unicode Afgeleide kern-eiendom `White_Space`.
    /// Gebruik [`split_ascii_whitespace`] as u slegs op ASCII-witruimte wil verdeel.
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Alle soorte spasies word beskou as:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Verdeel 'n snysnit deur die ASCII-spasie.
    ///
    /// Die iterator wat teruggekeer word, gee snysnye terug wat sub-snye van die oorspronklike snysnit is, geskei deur enige hoeveelheid ASCII-spasies.
    ///
    ///
    /// Gebruik [`split_whitespace`] om eerder deur Unicode `Whitespace` te verdeel.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Alle soorte ASCII-spasies word beskou:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// 'N Iterator oor die lyne van 'n tou, soos sny snye.
    ///
    /// Lyntjies word beëindig met 'n nuwe lyn (`\n`) of 'n koetsretour met 'n lynvoer (`\r\n`).
    ///
    /// Die finale reël eindig is opsioneel.
    /// 'N Tou wat eindig met 'n finale reël eindig, sal dieselfde reëls as 'n andersins identiese tou terugbring sonder dat 'n finale reël eindig.
    ///
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Die finale reël moet nie geëindig word nie:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// 'N Iterator oor die lyne van 'n tou.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Wys 'n iterator van `u16` oor die string wat as UTF-16 gekodeer is.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Wys `true` as die gegewe patroon ooreenstem met 'n subskyf van hierdie snysnit.
    ///
    /// Wys `false` as dit nie gebeur nie.
    ///
    /// Die [pattern] kan 'n `&str`, [`char`], 'n stuk [`char`] s wees, of 'n funksie of sluiting wat bepaal of 'n karakter ooreenstem.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Wys `true` as die gegewe patroon ooreenstem met 'n voorvoegsel van hierdie snysnit.
    ///
    /// Wys `false` as dit nie gebeur nie.
    ///
    /// Die [pattern] kan 'n `&str`, [`char`], 'n stuk [`char`] s wees, of 'n funksie of sluiting wat bepaal of 'n karakter ooreenstem.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Wys `true` as die gegewe patroon ooreenstem met 'n agtervoegsel van hierdie snysnit.
    ///
    /// Wys `false` as dit nie gebeur nie.
    ///
    /// Die [pattern] kan 'n `&str`, [`char`], 'n stuk [`char`] s wees, of 'n funksie of sluiting wat bepaal of 'n karakter ooreenstem.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Wys die byte-indeks van die eerste karakter van hierdie snysnit wat ooreenstem met die patroon.
    ///
    /// Wys [`None`] as die patroon nie ooreenstem nie.
    ///
    /// Die [pattern] kan 'n `&str`, [`char`], 'n stuk [`char`] s wees, of 'n funksie of sluiting wat bepaal of 'n karakter ooreenstem.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Eenvoudige patrone:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Meer komplekse patrone met puntvrye styl en sluitings:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Soek nie die patroon nie:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Wys die byte-indeks vir die eerste karakter van die regterkantste wedstryd van die patroon in hierdie snytjie.
    ///
    /// Wys [`None`] as die patroon nie ooreenstem nie.
    ///
    /// Die [pattern] kan 'n `&str`, [`char`], 'n stuk [`char`] s wees, of 'n funksie of sluiting wat bepaal of 'n karakter ooreenstem.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Eenvoudige patrone:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Meer komplekse patrone met sluitings:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Soek nie die patroon nie:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// 'N Iterator oor onderdele van hierdie snytjie, geskei deur karakters wat ooreenstem met 'n patroon.
    ///
    /// Die [pattern] kan 'n `&str`, [`char`], 'n stuk [`char`] s wees, of 'n funksie of sluiting wat bepaal of 'n karakter ooreenstem.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator gedrag
    ///
    /// Die teruggekeerde iterator is 'n [`DoubleEndedIterator`] as die patroon 'n omgekeerde soektog moontlik maak en forward/reverse-soeke dieselfde elemente lewer.
    /// Dit geld byvoorbeeld vir [`char`], maar nie vir `&str` nie.
    ///
    /// As die patroon 'n omgekeerde soektog moontlik maak, maar die resultate daarvan kan verskil van 'n vorentoe-soektog, kan die [`rsplit`]-metode gebruik word.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Eenvoudige patrone:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// As die patroon 'n stuk karakters is, verdeel dit op elke voorkoms van een van die karakters:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// 'N Meer komplekse patroon met 'n sluiting:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// As 'n string meerdere aangrensende skeiers bevat, kry u leë snare in die uitvoer:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Aangrensende skeiers word deur die leë string geskei.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Skeiers aan die begin of einde van 'n string word deur leë snare aangrensend.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Wanneer die leë tou as skeier gebruik word, skei dit elke karakter in die tou, tesame met die begin en einde van die tou.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Aangrensende skeiers kan lei tot moontlik verrassende gedrag wanneer die ruimte gebruik word as die skeier.Hierdie kode is korrek:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Dit gee _not_ u:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Gebruik [`split_whitespace`] vir hierdie gedrag.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// 'N Iterator oor onderdele van hierdie snytjie, geskei deur karakters wat ooreenstem met 'n patroon.
    /// Verskil van die iterator wat deur `split` vervaardig word deurdat `split_inclusive` die ooreenstemmende deel as die terminator van die onderlaag agterlaat.
    ///
    ///
    /// Die [pattern] kan 'n `&str`, [`char`], 'n stuk [`char`] s wees, of 'n funksie of sluiting wat bepaal of 'n karakter ooreenstem.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// As die laaste element van die tou ooreenstem, word dit beskou as die terminator van die voorafgaande onderdeel.
    /// Die onderdeel is die laaste item wat deur die iterator teruggestuur word.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// 'N Iterator oor onderstukke van die gegewe snytjie, geskei deur karakters wat ooreenstem met 'n patroon en in omgekeerde volgorde weergegee word.
    ///
    /// Die [pattern] kan 'n `&str`, [`char`], 'n stuk [`char`] s wees, of 'n funksie of sluiting wat bepaal of 'n karakter ooreenstem.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator gedrag
    ///
    /// Die teruggestuurde iterator vereis dat die patroon 'n omgekeerde soektog ondersteun, en dit sal 'n [`DoubleEndedIterator`] wees as 'n forward/reverse-soektog dieselfde elemente lewer.
    ///
    ///
    /// Om van voor af te herhaal, kan die [`split`]-metode gebruik word.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Eenvoudige patrone:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// 'N Meer komplekse patroon met 'n sluiting:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// 'N Iterator oor onderstukke van die gegewe snytjie, geskei deur karakters wat ooreenstem met 'n patroon.
    ///
    /// Die [pattern] kan 'n `&str`, [`char`], 'n stuk [`char`] s wees, of 'n funksie of sluiting wat bepaal of 'n karakter ooreenstem.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Ekwivalent aan [`split`], behalwe dat die agterste onderlaag oorgeslaan word as dit leeg is.
    ///
    /// [`split`]: str::split
    ///
    /// Hierdie metode kan gebruik word vir stringdata wat _terminated_ is, eerder as _separated_ deur 'n patroon.
    ///
    /// # Iterator gedrag
    ///
    /// Die teruggekeerde iterator is 'n [`DoubleEndedIterator`] as die patroon 'n omgekeerde soektog moontlik maak en forward/reverse-soeke dieselfde elemente lewer.
    /// Dit geld byvoorbeeld vir [`char`], maar nie vir `&str` nie.
    ///
    /// As die patroon 'n omgekeerde soektog moontlik maak, maar die resultate daarvan kan verskil van 'n vorentoe-soektog, kan die [`rsplit_terminator`]-metode gebruik word.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// 'N Iterator oor onderdele van `self`, geskei deur karakters wat ooreenstem met 'n patroon en in omgekeerde volgorde weergegee word.
    ///
    /// Die [pattern] kan 'n `&str`, [`char`], 'n stuk [`char`] s wees, of 'n funksie of sluiting wat bepaal of 'n karakter ooreenstem.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Ekwivalent aan [`split`], behalwe dat die agterste onderlaag oorgeslaan word as dit leeg is.
    ///
    /// [`split`]: str::split
    ///
    /// Hierdie metode kan gebruik word vir stringdata wat _terminated_ is, eerder as _separated_ deur 'n patroon.
    ///
    /// # Iterator gedrag
    ///
    /// Die teruggekeerde iterator vereis dat die patroon 'n omgekeerde soektog ondersteun, en dit sal dubbel geëindig word as 'n forward/reverse-soektog dieselfde elemente lewer.
    ///
    ///
    /// Om van voor af te herhaal, kan die [`split_terminator`]-metode gebruik word.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// 'N Iterator oor onderstukke van die gegewe snyskyf, geskei deur 'n patroon, is beperk tot die terugkeer van hoogstens `n`-items.
    ///
    /// As `n`-onderwerpe teruggestuur word, sal die laaste onderdeel (die `n`de onderdeel) die res van die tou bevat.
    ///
    /// Die [pattern] kan 'n `&str`, [`char`], 'n stuk [`char`] s wees, of 'n funksie of sluiting wat bepaal of 'n karakter ooreenstem.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator gedrag
    ///
    /// Die teruggekeerde iterator sal nie dubbel geëindig word nie, omdat dit nie doeltreffend is om te ondersteun nie.
    ///
    /// As die patroon 'n omgekeerde soektog moontlik maak, kan die [`rsplitn`]-metode gebruik word.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Eenvoudige patrone:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// 'N Meer komplekse patroon met 'n sluiting:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// 'N Iterator oor die onderdele van hierdie snysnit, geskei deur 'n patroon, begin vanaf die einde van die tou, is beperk tot die terugkeer van hoogstens `n`-items.
    ///
    ///
    /// As `n`-onderwerpe teruggestuur word, sal die laaste onderdeel (die `n`de onderdeel) die res van die tou bevat.
    ///
    /// Die [pattern] kan 'n `&str`, [`char`], 'n stuk [`char`] s wees, of 'n funksie of sluiting wat bepaal of 'n karakter ooreenstem.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator gedrag
    ///
    /// Die teruggekeerde iterator sal nie dubbel geëindig word nie, omdat dit nie doeltreffend is om te ondersteun nie.
    ///
    /// Om van voor te skeur, kan die [`splitn`]-metode gebruik word.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Eenvoudige patrone:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// 'N Meer komplekse patroon met 'n sluiting:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Verdeel die snaar op die eerste voorkoms van die gespesifiseerde afbakening en gee die voorvoegsel terug voor die afbakening en die agtervoegsel na die afbakening.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Verdeel die snaar op die laaste voorkoms van die gespesifiseerde afbakening en gee die voorvoegsel terug voor die afbakening en die agtervoegsel na die afbakening.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// 'N Iterator oor die losstaande vuurhoutjies van 'n patroon binne die gegewe snytjie.
    ///
    /// Die [pattern] kan 'n `&str`, [`char`], 'n stuk [`char`] s wees, of 'n funksie of sluiting wat bepaal of 'n karakter ooreenstem.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator gedrag
    ///
    /// Die teruggekeerde iterator is 'n [`DoubleEndedIterator`] as die patroon 'n omgekeerde soektog moontlik maak en forward/reverse-soeke dieselfde elemente lewer.
    /// Dit geld byvoorbeeld vir [`char`], maar nie vir `&str` nie.
    ///
    /// As die patroon 'n omgekeerde soektog moontlik maak, maar die resultate daarvan kan verskil van 'n vorentoe-soektog, kan die [`rmatches`]-metode gebruik word.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// 'N Iterator oor die losstaande vuurhoutjies van 'n patroon binne hierdie snytjie, in omgekeerde volgorde opgelewer.
    ///
    /// Die [pattern] kan 'n `&str`, [`char`], 'n stuk [`char`] s wees, of 'n funksie of sluiting wat bepaal of 'n karakter ooreenstem.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator gedrag
    ///
    /// Die teruggestuurde iterator vereis dat die patroon 'n omgekeerde soektog ondersteun, en dit sal 'n [`DoubleEndedIterator`] wees as 'n forward/reverse-soektog dieselfde elemente lewer.
    ///
    ///
    /// Om van voor af te herhaal, kan die [`matches`]-metode gebruik word.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// 'N Iterator oor die losstaande wedstryde van 'n patroon binne hierdie snytjie, sowel as die indeks waarop die wedstryd begin.
    ///
    /// Vir wedstryde van `pat` binne `self` wat oorvleuel, word slegs die indekse wat ooreenstem met die eerste wedstryd, terugbesorg.
    ///
    /// Die [pattern] kan 'n `&str`, [`char`], 'n stuk [`char`] s wees, of 'n funksie of sluiting wat bepaal of 'n karakter ooreenstem.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator gedrag
    ///
    /// Die teruggekeerde iterator is 'n [`DoubleEndedIterator`] as die patroon 'n omgekeerde soektog moontlik maak en forward/reverse-soeke dieselfde elemente lewer.
    /// Dit geld byvoorbeeld vir [`char`], maar nie vir `&str` nie.
    ///
    /// As die patroon 'n omgekeerde soektog moontlik maak, maar die resultate daarvan kan verskil van 'n vorentoe-soektog, kan die [`rmatch_indices`]-metode gebruik word.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // slegs die eerste `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// 'N Iterator oor die losstaande vuurhoutjies van 'n patroon binne `self`, in omgekeerde volgorde, tesame met die indeks van die wedstryd, opgelewer.
    ///
    /// Vir wedstryde van `pat` binne `self` wat oorvleuel, word slegs die indekse wat ooreenstem met die laaste wedstryd, terugbesorg.
    ///
    /// Die [pattern] kan 'n `&str`, [`char`], 'n stuk [`char`] s wees, of 'n funksie of sluiting wat bepaal of 'n karakter ooreenstem.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator gedrag
    ///
    /// Die teruggestuurde iterator vereis dat die patroon 'n omgekeerde soektog ondersteun, en dit sal 'n [`DoubleEndedIterator`] wees as 'n forward/reverse-soektog dieselfde elemente lewer.
    ///
    ///
    /// Om van voor af te herhaal, kan die [`match_indices`]-metode gebruik word.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // slegs die laaste `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Wys 'n snysnit met die voorste en agterste witruimte verwyder.
    ///
    /// 'Whitespace' word gedefinieer volgens die bepalings van die Unicode Afgeleide kern-eiendom `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Wys 'n snysnit met voorste witruimte verwyder.
    ///
    /// 'Whitespace' word gedefinieer volgens die bepalings van die Unicode Afgeleide kern-eiendom `White_Space`.
    ///
    /// # Teksdireksionaliteit
    ///
    /// 'N Tou is 'n reeks bytes.
    /// `start` beteken in hierdie konteks die eerste posisie van daardie byte string;vir 'n taal van links na regs soos Engels of Russies, sal dit aan die linkerkant wees, en vir tale van links na regs soos Arabies of Hebreeus sal dit die regte kant wees.
    ///
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Wys 'n snysnit met agterste witruimte verwyder.
    ///
    /// 'Whitespace' word gedefinieer volgens die bepalings van die Unicode Afgeleide kern-eiendom `White_Space`.
    ///
    /// # Teksdireksionaliteit
    ///
    /// 'N Tou is 'n reeks bytes.
    /// `end` beteken in hierdie konteks die laaste posisie van daardie byte-string;vir 'n taal van links na regs soos Engels of Russies, sal dit aan die regterkant wees, en vir tale van regs na links soos Arabies of Hebreeus, sal dit aan die linkerkant wees.
    ///
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Wys 'n snysnit met voorste witruimte verwyder.
    ///
    /// 'Whitespace' word gedefinieer volgens die bepalings van die Unicode Afgeleide kern-eiendom `White_Space`.
    ///
    /// # Teksdireksionaliteit
    ///
    /// 'N Tou is 'n reeks bytes.
    /// 'Left' beteken in hierdie konteks die eerste posisie van daardie byte-string;vir 'n taal soos Arabies of Hebreeus wat 'van regs na links' in plaas van 'van links na regs' is, is dit die _right_-kant, nie die linkerkant nie.
    ///
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Wys 'n snysnit met agterste witruimte verwyder.
    ///
    /// 'Whitespace' word gedefinieer volgens die bepalings van die Unicode Afgeleide kern-eiendom `White_Space`.
    ///
    /// # Teksdireksionaliteit
    ///
    /// 'N Tou is 'n reeks bytes.
    /// 'Right' beteken in hierdie konteks die laaste posisie van daardie byte-string;vir 'n taal soos Arabies of Hebreeus wat 'regs na links' is eerder as 'links na regs', is dit die _left_-kant, nie die regterkant nie.
    ///
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Wys 'n snysnit met alle voor-en agtervoegsels wat ooreenstem met 'n patroon wat herhaaldelik verwyder is.
    ///
    /// Die [pattern] kan 'n [`char`], 'n stuk ['char'] s wees, of 'n funksie of sluiting wat bepaal of 'n karakter ooreenstem.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Eenvoudige patrone:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// 'N Meer komplekse patroon met 'n sluiting:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Onthou die vroegste bekende wedstryd, stel dit hieronder reg as
            // laaste wedstryd is anders
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // VEILIGHEID: Daar is bekend dat `Searcher` geldige indekse oplewer.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Wys 'n snysnit met alle voorvoegsels wat ooreenstem met 'n patroon wat herhaaldelik verwyder is.
    ///
    /// Die [pattern] kan 'n `&str`, [`char`], 'n stuk [`char`] s wees, of 'n funksie of sluiting wat bepaal of 'n karakter ooreenstem.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Teksdireksionaliteit
    ///
    /// 'N Tou is 'n reeks bytes.
    /// `start` beteken in hierdie konteks die eerste posisie van daardie byte string;vir 'n taal van links na regs soos Engels of Russies, sal dit aan die linkerkant wees, en vir tale van links na regs soos Arabies of Hebreeus sal dit die regte kant wees.
    ///
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // VEILIGHEID: Daar is bekend dat `Searcher` geldige indekse oplewer.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Wys 'n snysnit met die voorvoegsel verwyder.
    ///
    /// As die string met die patroon `prefix` begin, gee u die substring na die voorvoegsel terug, toegedraai in `Some`.
    /// In teenstelling met `trim_start_matches`, word hierdie voorvoegsel presies een keer verwyder.
    ///
    /// As die string nie met `prefix` begin nie, word `None` teruggestuur.
    ///
    /// Die [pattern] kan 'n `&str`, [`char`], 'n stuk [`char`] s wees, of 'n funksie of sluiting wat bepaal of 'n karakter ooreenstem.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Wys 'n snysnit met die agtervoegsel verwyder.
    ///
    /// As die string met die patroon `suffix` eindig, gee die substring voor die agtervoegsel terug, toegedraai in `Some`.
    /// In teenstelling met `trim_end_matches`, word hierdie agtervoegsel presies een keer verwyder.
    ///
    /// As die string nie met `suffix` eindig nie, word `None` teruggestuur.
    ///
    /// Die [pattern] kan 'n `&str`, [`char`], 'n stuk [`char`] s wees, of 'n funksie of sluiting wat bepaal of 'n karakter ooreenstem.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Wys 'n snytjie met alle agtervoegsels wat ooreenstem met 'n patroon wat herhaaldelik verwyder is.
    ///
    /// Die [pattern] kan 'n `&str`, [`char`], 'n stuk [`char`] s wees, of 'n funksie of sluiting wat bepaal of 'n karakter ooreenstem.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Teksdireksionaliteit
    ///
    /// 'N Tou is 'n reeks bytes.
    /// `end` beteken in hierdie konteks die laaste posisie van daardie byte-string;vir 'n taal van links na regs soos Engels of Russies, sal dit aan die regterkant wees, en vir tale van regs na links soos Arabies of Hebreeus, sal dit aan die linkerkant wees.
    ///
    ///
    /// # Examples
    ///
    /// Eenvoudige patrone:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// 'N Meer komplekse patroon met 'n sluiting:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // VEILIGHEID: Daar is bekend dat `Searcher` geldige indekse oplewer.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Wys 'n snysnit met alle voorvoegsels wat ooreenstem met 'n patroon wat herhaaldelik verwyder is.
    ///
    /// Die [pattern] kan 'n `&str`, [`char`], 'n stuk [`char`] s wees, of 'n funksie of sluiting wat bepaal of 'n karakter ooreenstem.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Teksdireksionaliteit
    ///
    /// 'N Tou is 'n reeks bytes.
    /// 'Left' beteken in hierdie konteks die eerste posisie van daardie byte-string;vir 'n taal soos Arabies of Hebreeus wat 'van regs na links' in plaas van 'van links na regs' is, is dit die _right_-kant, nie die linkerkant nie.
    ///
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Wys 'n snytjie met alle agtervoegsels wat ooreenstem met 'n patroon wat herhaaldelik verwyder is.
    ///
    /// Die [pattern] kan 'n `&str`, [`char`], 'n stuk [`char`] s wees, of 'n funksie of sluiting wat bepaal of 'n karakter ooreenstem.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Teksdireksionaliteit
    ///
    /// 'N Tou is 'n reeks bytes.
    /// 'Right' beteken in hierdie konteks die laaste posisie van daardie byte-string;vir 'n taal soos Arabies of Hebreeus wat 'regs na links' is eerder as 'links na regs', is dit die _left_-kant, nie die regterkant nie.
    ///
    ///
    /// # Examples
    ///
    /// Eenvoudige patrone:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// 'N Meer komplekse patroon met 'n sluiting:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Ontleed hierdie snytjie in 'n ander tipe.
    ///
    /// Omdat `parse` so algemeen is, kan dit probleme veroorsaak met tipe afleiding.
    /// As sodanig is `parse` een van die min kere dat u die sintaksis met liefde bekend as die 'turbofish' sal sien: `::<>`.
    ///
    /// Dit help die afleidingsalgoritme om spesifiek te verstaan in watter tipe u probeer ontleed.
    ///
    /// `parse` kan ontleed in enige tipe wat die [`FromStr`] trait implementeer.
    ///

    /// # Errors
    ///
    /// Sal [`Err`] teruggee as dit nie moontlik is om hierdie snysnit in die gewenste tipe te ontleed nie.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Basiese gebruik
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Gebruik die 'turbofish' in plaas van om `four` te annoteer:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Versuim om te ontleed:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Kontroleer of alle karakters in hierdie string binne die ASCII-reeks is.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Ons kan hier elke greep as karakter hanteer: alle multibytkarakters begin met 'n greep wat nie binne die ascii-reeks is nie, dus sal ons reeds daar stop.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Kontroleer dat twee stringe 'n ASCII-saak-ongevoelige pasmaat is.
    ///
    /// Dieselfde as `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, maar sonder tydelike toekenning en kopiëring.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Skakel hierdie string om na die ASCII-hoofletter-ekwivalent in die plek.
    ///
    /// ASCII-letters 'a' tot 'z' word gekoppel aan 'A' tot 'Z', maar nie-ASCII-letters is onveranderd.
    ///
    /// Gebruik [`to_ascii_uppercase()`] om 'n nuwe hoofletterwaarde terug te gee sonder om die bestaande waarde te wysig.
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // VEILIGHEID: veilig omdat ons twee soorte met dieselfde uitleg transformeer.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Skakel hierdie string om na die ASCII-kleinletter-ekwivalent in die plek.
    ///
    /// ASCII-letters 'A' tot 'Z' word gekoppel aan 'a' tot 'z', maar nie-ASCII-letters is onveranderd.
    ///
    /// Gebruik [`to_ascii_lowercase()`] om 'n nuwe waarde met 'n laer waarde terug te gee sonder om die bestaande waarde te wysig.
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // VEILIGHEID: veilig omdat ons twee soorte met dieselfde uitleg transformeer.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Stuur 'n iterator terug wat in `self` met [`char::escape_debug`] ontsnap.
    ///
    ///
    /// Note: slegs uitgebreide grafeme-kodepunte wat die string begin, sal ontsnap word.
    ///
    /// # Examples
    ///
    /// As herhaling:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Gebruik `println!` direk:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Albei is gelykstaande aan:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Gebruik `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Stuur 'n iterator terug wat in `self` met [`char::escape_default`] ontsnap.
    ///
    ///
    /// # Examples
    ///
    /// As herhaling:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Gebruik `println!` direk:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Albei is gelykstaande aan:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Gebruik `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Stuur 'n iterator terug wat in `self` met [`char::escape_unicode`] ontsnap.
    ///
    ///
    /// # Examples
    ///
    /// As herhaling:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Gebruik `println!` direk:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Albei is gelykstaande aan:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Gebruik `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Skep 'n leë str
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Skep 'n leë veranderlike str
    #[inline]
    fn default() -> Self {
        // VEILIGHEID: Die leë string is geldig UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// 'N Naambare, kloonbare fn-tipe
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // VEILIGHEID: nie veilig nie
        unsafe { from_utf8_unchecked(bytes) }
    };
}