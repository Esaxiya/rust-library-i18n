//! Maniere om 'n `str` te skep vanaf byte-sny.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Skakel 'n stukkie grepe om na 'n snysnit.
///
/// 'N Snyplaat ([`&str`]) is gemaak van byte ([`u8`]) en 'n byte-deel ([`&[u8]`][byteslice]) is van byte, dus hierdie funksie skakel tussen die twee om.
/// Nie alle byte-skywe is geldige stringskywe nie: [`&str`] vereis dat dit geldig UTF-8 is.
/// `from_utf8()` kontroleer om te verseker dat die bytes geldig is UTF-8, en doen dan die omskakeling.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// As u seker is dat die byte-stuk 'n geldige UTF-8 is, en u nie die bokoste van die geldigheidskontrole wil aangaan nie, is daar 'n onveilige weergawe van hierdie funksie, [`from_utf8_unchecked`], wat dieselfde gedrag het, maar die tjek oorslaan.
///
///
/// Oorweeg [`String::from_utf8`][string] as u 'n `String` in plaas van 'n `&str` benodig.
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Omdat u 'n `[u8; N]` kan stapel toewys en 'n [`&[u8]`][byteslice] daarvan kan neem, is hierdie funksie een manier om 'n stapel-toegekende string te hê.Daar is 'n voorbeeld hiervan in die onderstaande voorbeelde.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Wys `Err` as die sny nie UTF-8 is nie, met 'n beskrywing waarom die gegewe sny nie UTF-8 is nie.
///
/// # Examples
///
/// Basiese gebruik:
///
/// ```
/// use std::str;
///
/// // sommige grepe, in 'n vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Ons weet dat hierdie grepe geldig is, dus gebruik net `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Verkeerde grepe:
///
/// ```
/// use std::str;
///
/// // sommige ongeldige grepe, in 'n vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Raadpleeg die dokumente vir [`Utf8Error`] vir meer inligting oor die soorte foute wat teruggestuur kan word.
///
/// 'N "stack allocated string":
///
/// ```
/// use std::str;
///
/// // sommige grepe, in 'n stapel-toegewysde skikking
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Ons weet dat hierdie grepe geldig is, dus gebruik net `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // VEILIGHEID: pas validering uitgevoer.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Skakel 'n veranderlike stuk bytes om na 'n veranderlike snysnit.
///
/// # Examples
///
/// Basiese gebruik:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" as 'n veranderlike vector
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Aangesien ons weet dat hierdie grepe geldig is, kan ons `unwrap()` gebruik
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Verkeerde grepe:
///
/// ```
/// use std::str;
///
/// // Sommige ongeldige grepe in 'n veranderlike vector
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Raadpleeg die dokumente vir [`Utf8Error`] vir meer inligting oor die soorte foute wat teruggestuur kan word.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // VEILIGHEID: pas validering uitgevoer.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Skakel 'n stuk grepe om na 'n snysnit sonder om te kyk of die string geldige UTF-8 bevat.
///
/// Raadpleeg die veilige weergawe, [`from_utf8`], vir meer inligting.
///
/// # Safety
///
/// Hierdie funksie is onveilig, want dit maak nie seker dat die bytes wat daarheen deurgegee word, geldig UTF-8 is nie.
/// As hierdie beperking oortree word, kom ongedefinieerde gedrag tot gevolg, aangesien die res van Rust aanvaar dat [`&str`] 's geldige UTF-8 is.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Basiese gebruik:
///
/// ```
/// use std::str;
///
/// // sommige grepe, in 'n vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // VEILIGHEID: die beller moet waarborg dat die byte `v` geldig UTF-8 is.
    // Vertrou ook daarop dat `&str` en `&[u8]` dieselfde uitleg het.
    unsafe { mem::transmute(v) }
}

/// Skakel 'n stuk grepe om na 'n snysnit sonder om te kyk of die string geldige UTF-8 bevat;veranderlike weergawe.
///
///
/// Kyk na die onveranderlike weergawe, [`from_utf8_unchecked()`], vir meer inligting.
///
/// # Examples
///
/// Basiese gebruik:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // VEILIGHEID: die beller moet waarborg dat die byte `v`
    // geldig UTF-8 is, dus is die rolverdeling na `*mut str` veilig.
    // Die verwysing na die aanwyser is ook veilig omdat die aanwyser afkomstig is van 'n verwysing wat verseker geldig is vir skryfwerk.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}