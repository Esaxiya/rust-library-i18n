//! Definieer utf8-fouttipe.

use crate::fmt;

/// Foute wat kan voorkom as u 'n reeks [`u8`] as 'n string wil interpreteer.
///
/// As sodanig maak die `from_utf8`-familie van funksies en metodes vir beide [`String`] en [`&str`] gebruik van hierdie fout, byvoorbeeld.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Metodes van hierdie fouttipe kan gebruik word om funksies soortgelyk aan `String::from_utf8_lossy` te skep sonder om hope geheue toe te ken:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Wys die indeks in die gegewe string waarop geldige UTF-8 geverifieer is.
    ///
    /// Dit is die maksimum indeks sodanig dat `from_utf8(&input[..index])` `Ok(_)` sou oplewer.
    ///
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// use std::str;
    ///
    /// // sommige ongeldige grepe, in 'n vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 gee 'n Utf8Error terug
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // die tweede byte is hier ongeldig
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Verskaf meer inligting oor die mislukking:
    ///
    /// * `None`: die einde van die insette is onverwags bereik.
    ///   `self.valid_up_to()` is 1 tot 3 grepe vanaf die einde van die invoer.
    ///   As 'n byte-stroom (soos 'n lêer of 'n netwerksok) inkrementeel gedekodeer word, kan dit 'n geldige `char` wees waarvan die UTF-8-byte-reeks oor verskeie stukke strek.
    ///
    ///
    /// * `Some(len)`: 'n onverwagse byte is teëgekom.
    ///   Die lengte is die ongeldige byte-volgorde wat begin by die indeks wat deur `valid_up_to()` gegee word.
    ///   Dekodering moet hervat word na die volgorde (na die invoeging van 'n [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) in geval van verlies aan dekodering.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// 'N Fout wat opgelewer is tydens die ontleding van 'n `bool` met behulp van [`from_str`], misluk
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}