//! Trait implementasies vir `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Implementeer die ordening van snare.
///
/// Snare word [lexicographically](Ord#lexicographical-comparison) volgens hul bytewaardes georden.
/// Dit bestel Unicode-kodepunte op grond van hul posisies in die kodekaarte.
/// Dit is nie noodwendig dieselfde as die "alphabetical"-volgorde nie, wat wissel volgens taal en landstreek.
/// Om stringe volgens kultuuraanvaarde standaarde te sorteer, benodig u plaaslike spesifieke data wat buite die bestek van die `str`-tipe val.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Implementeer vergelykingsbewerkings op toutjies.
///
/// Stringe word [lexicographically](Ord#lexicographical-comparison) vergelyk met hul byte-waardes.
/// Dit vergelyk Unicode-kodepunte op grond van hul posisies in die kodekaarte.
/// Dit is nie noodwendig dieselfde as die "alphabetical"-volgorde nie, wat wissel volgens taal en landstreek.
/// Om stringe met kultuuraanvaarde standaarde te vergelyk, benodig u plaaslike spesifieke data wat buite die bestek van die `str`-tipe val.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Implementeer onderkant sny met sintaksis `&self[..]` of `&mut self[..]`.
///
/// Wys 'n deel van die hele string, dws, gee `&self` of `&mut self` terug.Ekwivalent aan `&self [0 ..
/// len] `of`&mut self [0 ..
/// len]`.
/// Anders as ander indekseringsbedrywighede, kan dit nooit panic wees nie.
///
/// Hierdie bewerking is *O*(1).
///
/// Voor 1.20.0 is hierdie indekseringsbewerkings steeds ondersteun deur direkte implementering van `Index` en `IndexMut`.
///
/// Ekwivalent aan `&self[0 .. len]` of `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Implementeer onderkant sny met sintaksis `&self[begin .. end]` of `&mut self[begin .. end]`.
///
/// Wys 'n deel van die gegewe string uit die byte-reeks [`begin ', `end`).
///
/// Hierdie bewerking is *O*(1).
///
/// Voor 1.20.0 is hierdie indekseringsbewerkings steeds ondersteun deur direkte implementering van `Index` en `IndexMut`.
///
/// # Panics
///
/// Panics as `begin` of `end` nie dui op die begin-byte-verrekening van 'n karakter (soos gedefinieer deur `is_char_boundary`), as `begin > end`, of as `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // dit sal panic:
/// // byte 2 lê binne `ö`:
/// // &s [2 ..3];
///
/// // byte 8 lê binne `老`&s [1 ..
/// // 8];
///
/// // byte 100 is buite die tou&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // VEILIGHEID: net gekontroleer dat `start` en `end` aan 'n kolgrens is,
            // en ons gee 'n veilige verwysing deur, dus sal die terugkeerwaarde ook een wees.
            // Ons het ook char grense nagegaan, dus dit is geldig UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // VEILIGHEID: net gekontroleer of `start` en `end` aan 'n kolgrens is.
            // Ons weet dat die aanwyser uniek is omdat ons dit van `slice` gekry het.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // VEILIGHEID: die oproeper waarborg dat `self` binne die perke van `slice` is
        // wat aan al die voorwaardes vir `add` voldoen.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // VEILIGHEID: sien kommentaar vir `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary tjeks of die indeks in [0 is, .len()] kan nie `get` soos hierbo gebruik nie, as gevolg van NLL-probleme
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // VEILIGHEID: net gekontroleer dat `start` en `end` aan 'n kolgrens is,
            // en ons gee 'n veilige verwysing deur, dus sal die terugkeerwaarde ook een wees.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Implementeer onderkant sny met sintaksis `&self[.. end]` of `&mut self[.. end]`.
///
/// Wys 'n deel van die gegewe string uit die byte-reeks [`0`, `end`).
/// Ekwivalent aan `&self[0 .. end]` of `&mut self[0 .. end]`.
///
/// Hierdie bewerking is *O*(1).
///
/// Voor 1.20.0 is hierdie indekseringsbewerkings steeds ondersteun deur direkte implementering van `Index` en `IndexMut`.
///
/// # Panics
///
/// Panics as `end` nie dui op die begin byte verrekening van 'n karakter nie (soos gedefinieer deur `is_char_boundary`), of as `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // VEILIGHEID: net gekontroleer dat `end` op 'n kolgrens is,
            // en ons gee 'n veilige verwysing deur, dus sal die terugkeerwaarde ook een wees.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // VEILIGHEID: net gekontroleer dat `end` op 'n kolgrens is,
            // en ons gee 'n veilige verwysing deur, dus sal die terugkeerwaarde ook een wees.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // VEILIGHEID: net gekontroleer dat `end` op 'n kolgrens is,
            // en ons gee 'n veilige verwysing deur, dus sal die terugkeerwaarde ook een wees.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Implementeer onderkant sny met sintaksis `&self[begin ..]` of `&mut self[begin ..]`.
///
/// Wys 'n deel van die gegewe string uit die byte-reeks [`begin ', `len`).Ekwivalent aan`&self [begin ..
/// len] `of`&mut self [begin ..
/// len]`.
///
/// Hierdie bewerking is *O*(1).
///
/// Voor 1.20.0 is hierdie indekseringsbewerkings steeds ondersteun deur direkte implementering van `Index` en `IndexMut`.
///
/// # Panics
///
/// Panics as `begin` nie dui op die begin byte verrekening van 'n karakter nie (soos gedefinieer deur `is_char_boundary`), of as `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // VEILIGHEID: net gekontroleer of `start` op 'n kolgrens is,
            // en ons gee 'n veilige verwysing deur, dus sal die terugkeerwaarde ook een wees.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // VEILIGHEID: net gekontroleer of `start` op 'n kolgrens is,
            // en ons gee 'n veilige verwysing deur, dus sal die terugkeerwaarde ook een wees.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // VEILIGHEID: die oproeper waarborg dat `self` binne die perke van `slice` is
        // wat aan al die voorwaardes vir `add` voldoen.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // VEILIGHEID: identies aan `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // VEILIGHEID: net gekontroleer of `start` op 'n kolgrens is,
            // en ons gee 'n veilige verwysing deur, dus sal die terugkeerwaarde ook een wees.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Implementeer onderkant sny met sintaksis `&self[begin ..= end]` of `&mut self[begin ..= end]`.
///
/// Wys 'n deel van die gegewe string uit die byte-reeks [`begin`, `end`].Gelyk aan `&self [begin .. end + 1]` of `&mut self[begin .. end + 1]`, behalwe as `end` die maksimum waarde vir `usize` het.
///
/// Hierdie bewerking is *O*(1).
///
/// # Panics
///
/// Panics as `begin` nie wys op die begin byte verrekening van 'n karakter nie (soos gedefinieër deur `is_char_boundary`), as `end` nie wys op die eind byte verrekening van 'n karakter nie (`end + 1` is óf 'n begin byte offset óf gelyk aan `len`), as `begin > end`, of as `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // VEILIGHEID: die beller moet die veiligheidskontrak vir `get_unchecked` handhaaf.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // VEILIGHEID: die beller moet die veiligheidskontrak vir `get_unchecked_mut` handhaaf.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Implementeer onderkant sny met sintaksis `&self[..= end]` of `&mut self[..= end]`.
///
/// Wys 'n deel van die gegewe string uit die byte-reeks [0, `end`].
/// Ekwivalent aan `&self [0 .. end + 1]`, behalwe as `end` die maksimum waarde vir `usize` het.
///
/// Hierdie bewerking is *O*(1).
///
/// # Panics
///
/// Panics as `end` nie dui op die eindbyte-verrekening van 'n karakter nie (`end + 1` is óf 'n begin-byte-verrekening soos gedefinieër deur `is_char_boundary`, óf gelyk aan `len`), of as `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // VEILIGHEID: die beller moet die veiligheidskontrak vir `get_unchecked` handhaaf.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // VEILIGHEID: die beller moet die veiligheidskontrak vir `get_unchecked_mut` handhaaf.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Ontleed 'n waarde van 'n string
///
/// 'FromStr`se [`from_str`]-metode word dikwels implisiet gebruik deur middel van [`str`] se [`parse`]-metode.
/// Kyk na die dokumentasie van [`parse`] vir voorbeelde.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` het nie 'n lewenslange parameter nie, en u kan dus slegs tipes ontleed wat nie self 'n lewenslange parameter bevat nie.
///
/// Met ander woorde, u kan 'n `i32` ontleed met `FromStr`, maar nie 'n `&i32` nie.
/// U kan 'n struktuur ontleed wat 'n `i32` bevat, maar nie een wat 'n `&i32` bevat nie.
///
/// # Examples
///
/// Basiese implementering van `FromStr` op 'n voorbeeld `Point`-tipe:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Die gepaardgaande fout wat vanaf ontleding teruggestuur kan word.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Ontleed 'n string `s` om 'n waarde van hierdie tipe terug te gee.
    ///
    /// As die parsing slaag, moet u die waarde binne [`Ok`] teruggee, anders gee die fout wat spesifiek is aan die binnekant van [`Err`], as die snaar nie geformateer is nie.
    /// Die fouttipe is spesifiek vir die implementering van die trait.
    ///
    /// # Examples
    ///
    /// Basiese gebruik met [`i32`], 'n tipe wat `FromStr` implementeer:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Ontleed 'n `bool` van 'n string.
    ///
    /// Lewer 'n `Result<bool, ParseBoolError>` omdat `s` wel of nie ontleedbaar is nie.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Let op, in baie gevalle is die `.parse()`-metode op `str` meer korrek.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}