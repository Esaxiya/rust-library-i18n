//! Dit is 'n interne module wat deur die ifmt gebruik word!looptyd.Hierdie strukture word uitgestuur aan statiese skikkings om snare vooraf te kompileer.
//!
//! Hierdie definisies is soortgelyk aan hul `ct`-ekwivalente, maar verskil deurdat dit staties toegeken kan word en effens geoptimaliseer is vir die tydsduur.
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Moontlike belyning wat aangevra kan word as deel van 'n opstelriglyn.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Aanduiding dat die inhoud links-gerig moet wees.
    Left,
    /// Aanduiding dat die inhoud regsbelyn moet wees.
    Right,
    /// Aanduiding dat die inhoud middelpunt moet wees.
    Center,
    /// Geen belyning is versoek nie.
    Unknown,
}

/// Word gebruik deur [width](https://doc.rust-lang.org/std/fmt/#width)-en [precision](https://doc.rust-lang.org/std/fmt/#precision)-spesifikasies.
#[derive(Copy, Clone)]
pub enum Count {
    /// Gespesifiseer met 'n letterlike nommer, stoor die waarde
    Is(usize),
    /// Gegee met behulp van `$`-en `*`-sintaksis, stoor die indeks in `args`
    Param(usize),
    /// Nie gespesifiseer nie
    Implied,
}