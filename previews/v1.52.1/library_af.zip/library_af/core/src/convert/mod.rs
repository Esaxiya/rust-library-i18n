//! Traits vir omskakeling tussen soorte.
//!
//! Die traits in hierdie module bied 'n manier om van een tipe na 'n ander soort om te skakel.
//! Elke trait het 'n ander doel:
//!
//! - Implementeer die [`AsRef`] trait vir goedkoop verwysing-na-verwysing-omskakelings
//! - Implementeer die [`AsMut`] trait vir goedkoop veranderbare-na-veranderlike omskakelings
//! - Implementeer die [`From`] trait om waarde-tot-waarde-omskakelings te verbruik
//! - Implementeer die [`Into`] trait vir die verbruik van waarde-tot-waarde-omskakelings na tipes buite die huidige crate
//! - Die [`TryFrom`] en [`TryInto`] traits gedra hulle soos [`From`] en [`Into`], maar moet geïmplementeer word wanneer die omskakeling kan misluk.
//!
//! Die traits in hierdie module word dikwels gebruik as trait bounds vir generiese funksies, sodat argumente van verskeie soorte ondersteun word.Kyk na die dokumentasie van elke trait vir voorbeelde.
//!
//! As biblioteekskrywer moet u altyd verkies om [`From<T>`][`From`] of [`TryFrom<T>`][`TryFrom`] te implementeer eerder as [`Into<U>`][`Into`] of [`TryInto<U>`][`TryInto`], aangesien [`From`] en [`TryFrom`] groter buigsaamheid bied en ekwivalente [`Into`]-of [`TryInto`]-implementasies gratis bied, danksy 'n dekenimplementering in die standaardbiblioteek.
//! As u op 'n weergawe vóór Rust 1.41 teiken, kan dit nodig wees om [`Into`] of [`TryInto`] direk te implementeer as u na 'n tipe buite die huidige crate omskakel.
//!
//! # Generiese implementasies
//!
//! - [`AsRef`] en [`AsMut`] outo-afleiding as die innerlike tipe 'n verwysing is
//! - [`From`]`<U>vir T` impliseer [`Into`]`</u><T><U>vir U`</u>
//! - [`TryFrom`]`<U>vir T` impliseer [`TryInto`]`</u><T><U>vir U`</u>
//! - [`From`] en [`Into`] is refleksief, wat beteken dat alle tipes self `into` en `from` self kan doen
//!
//! Kyk na elke trait vir voorbeelde van gebruik.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Die identiteitsfunksie.
///
/// Twee dinge is belangrik om op te let oor hierdie funksie:
///
/// - Dit is nie altyd gelykstaande aan 'n sluiting soos `|x| x` nie, aangesien die sluiting `x` in 'n ander tipe kan dwing.
///
/// - Dit skuif die invoer `x` wat na die funksie oorgedra word.
///
/// Alhoewel dit vreemd kan lyk om 'n funksie te hê wat net die toevoer teruggee, is daar interessante gebruike.
///
///
/// # Examples
///
/// Gebruik `identity` om niks in 'n reeks ander, interessante funksies te doen nie:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Laat ons voorgee dat die toevoeging van een 'n interessante funksie is.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Gebruik `identity` as 'n "do nothing"-basiskas onder voorwaardelike:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Doen meer interessante dinge ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Gebruik `identity` om die `Some`-variante van 'n iterator van `Option<T>` te behou:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Word gebruik om 'n goedkoop verwysing-na-verwysing-omskakeling te doen.
///
/// Hierdie trait is soortgelyk aan [`AsMut`] wat gebruik word vir die omskakeling tussen veranderlike verwysings.
/// As u 'n duur omskakeling moet doen, is dit beter om [`From`] met die tipe `&T` te implementeer of 'n persoonlike funksie te skryf.
///
/// `AsRef` het dieselfde handtekening as [`Borrow`], maar [`Borrow`] verskil in enkele aspekte:
///
/// - Anders as `AsRef`, het [`Borrow`] 'n dekenimplement vir enige `T`, en kan dit gebruik word om 'n verwysing of 'n waarde te aanvaar.
/// - [`Borrow`] vereis ook dat [`Hash`], [`Eq`] en [`Ord`] vir geleende waarde gelykstaande is aan dié van die waarde wat u besit.
/// Om hierdie rede, as u slegs een enkele veld van 'n struktuur wil leen, kan u `AsRef` implementeer, maar nie [`Borrow`] nie.
///
/// **Note: Hierdie trait mag nie misluk nie **.As die omskakeling kan misluk, gebruik 'n toegewyde metode wat 'n [`Option<T>`] of 'n [`Result<T, E>`] oplewer.
///
/// # Generiese implementasies
///
/// - `AsRef` outo-dereferensies as die innerlike tipe 'n verwysing of 'n veranderlike verwysing is (bv: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Deur trait bounds te gebruik, kan ons argumente van verskillende soorte aanvaar, solank dit na die gespesifiseerde tipe `T` omgeskakel kan word.
///
/// Byvoorbeeld: deur 'n generiese funksie te skep wat 'n `AsRef<str>` neem, spreek ons uit dat ons alle verwysings wat na [`&str`] omgeskakel kan word, wil aanvaar.
/// Aangesien beide [`String`] en [`&str`] `AsRef<str>` implementeer, kan ons albei as invoerargument aanvaar.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Voer die omskakeling uit.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Word gebruik om 'n goedkoop veranderlike-na-veranderlike verwysingsomskakeling te doen.
///
/// Hierdie trait is soortgelyk aan [`AsRef`], maar word gebruik vir omskakeling tussen veranderlike verwysings.
/// As u 'n duur omskakeling moet doen, is dit beter om [`From`] met die tipe `&mut T` te implementeer of 'n persoonlike funksie te skryf.
///
/// **Note: Hierdie trait mag nie misluk nie **.As die omskakeling kan misluk, gebruik 'n toegewyde metode wat 'n [`Option<T>`] of 'n [`Result<T, E>`] oplewer.
///
/// # Generiese implementasies
///
/// - `AsMut` outo-dereferensies as die innerlike tipe 'n veranderlike verwysing is (byvoorbeeld: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Deur `AsMut` te gebruik as trait bound vir 'n generiese funksie, kan ons alle veranderlike verwysings aanvaar wat omgeskakel kan word na tipe `&mut T`.
/// Omdat [`Box<T>`] `AsMut<T>` implementeer, kan ons 'n funksie `add_one` skryf wat alle argumente neem wat na `&mut u64` omgeskakel kan word.
/// Omdat [`Box<T>`] `AsMut<T>` implementeer, aanvaar `add_one` ook argumente van die tipe `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Voer die omskakeling uit.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// 'N Waarde-tot-waarde-omskakeling wat die invoerwaarde verbruik.Die teenoorgestelde van [`From`].
///
/// U moet vermy om [`Into`] te implementeer en [`From`] eerder te implementeer.
/// Die implementering van [`From`] bied outomaties 'n implementering van [`Into`] danksy die dekenimplementering in die standaardbiblioteek.
///
/// Gebruik [`Into`] eerder as [`From`] wanneer u trait bounds op 'n generiese funksie spesifiseer om te verseker dat tipes wat slegs [`Into`] implementeer ook gebruik kan word.
///
/// **Note: Hierdie trait mag nie misluk nie **.As die omskakeling kan misluk, gebruik [`TryInto`].
///
/// # Generiese implementasies
///
/// - [`Van`]`<T>vir U` impliseer `Into<U> for T`
/// - [`Into`] is refleksief, wat beteken dat `Into<T> for T` geïmplementeer word
///
/// # Implementering van [`Into`] vir omskakelings na eksterne tipes in ou weergawes van Rust
///
/// Voor die Rust 1.41, as die bestemmingstipe nie deel was van die huidige crate nie, kon u [`From`] nie direk implementeer nie.
/// Neem byvoorbeeld hierdie kode:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Dit kan nie in ouer weergawes van die taal saamgestel word nie, omdat die weeskinderreëls van Rust vroeër 'n bietjie strenger was.
/// Om dit te omseil, kan u [`Into`] direk implementeer:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Dit is belangrik om te verstaan dat [`Into`] nie 'n [`From`]-implementering bied nie (soos [`From`] ook met [`Into`]).
/// Daarom moet u altyd probeer om [`From`] te implementeer en dan terug te val na [`Into`] as [`From`] nie geïmplementeer kan word nie.
///
/// # Examples
///
/// [`String`] implementeer [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Om uit te druk dat ons wil hê dat 'n generiese funksie alle argumente moet neem wat omgeskakel kan word na 'n gespesifiseerde tipe `T`, kan ons 'n trait bound van ['Into'] 'gebruik.<T>`.
///
/// Byvoorbeeld: die funksie `is_hello` neem alle argumente wat omskep kan word in 'n [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Voer die omskakeling uit.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Word gebruik om waarde-tot-waarde-omskakelings te doen terwyl u die invoerwaarde verbruik.Dit is die wederkerigheid van [`Into`].
///
/// 'N Mens moet altyd verkies om `From` bo [`Into`] te implementeer, omdat die implementering van `From` outomaties 'n implementering van [`Into`] bied danksy die dekenimplementering in die standaardbiblioteek.
///
///
/// Implementeer slegs [`Into`] wanneer u op 'n weergawe vóór Rust 1.41 teiken en na 'n tipe buite die huidige crate omskakel.
/// `From` was nie in staat om hierdie tipe omskakelings in vroeëre weergawes uit te voer nie weens die reëls van weeskinders van Rust.
/// Sien [`Into`] vir meer besonderhede.
///
/// Gebruik [`Into`] eerder as `From` wanneer u trait bounds op 'n generiese funksie spesifiseer.
/// Op hierdie manier kan tipes wat [`Into`] direk implementeer ook as argumente gebruik word.
///
/// Die `From` is ook baie handig as u foute hanteer.Wanneer u 'n funksie konstrueer wat kan misluk, sal die retourtipe gewoonlik die vorm `Result<T, E>` hê.
/// Die `From` trait vereenvoudig die hantering van foute deur die funksie toe te laat om 'n enkele fouttipe terug te gee wat verskeie fouttipes omhul.Raadpleeg die "Examples"-afdeling en [the book][book] vir meer besonderhede.
///
/// **Note: Hierdie trait mag nie misluk nie **.As die omskakeling kan misluk, gebruik [`TryFrom`].
///
/// # Generiese implementasies
///
/// - `From<T> for U` impliseer [`Into`]`<U>vir T`</u>
/// - `From` is refleksief, wat beteken dat `From<T> for T` geïmplementeer word
///
/// # Examples
///
/// [`String`] implementeer `From<&str>`:
///
/// 'N Eksplisiete omskakeling van 'n `&str` na 'n string gebeurt soos volg:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Wanneer u fouthantering uitvoer, is dit dikwels handig om `From` vir u eie fouttipe te implementeer.
/// Deur onderliggende fouttipes om te skakel na ons eie fouttipe wat die onderliggende fouttipe omvat, kan ons 'n enkele foutsoort terugstuur sonder om inligting oor die onderliggende oorsaak te verloor.
/// Die '?'-operateur skakel die onderliggende fouttipe outomaties om na ons persoonlike fouttipe deur `Into<CliError>::into` te skakel wat outomaties by die implementering van `From` voorsien word.
/// Die samesteller bepaal dan watter implementering van `Into` gebruik moet word.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Voer die omskakeling uit.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// 'N Poging tot omskakeling wat `self` verbruik, wat al dan nie duur is nie.
///
/// Biblioteek-outeurs moet hierdie trait gewoonlik nie direk implementeer nie, maar verkies om die [`TryFrom`] trait te implementeer, wat groter buigsaamheid bied en gratis 'n ekwivalente `TryInto`-implementering bied, danksy 'n kombersimplementering in die standaardbiblioteek.
/// Raadpleeg die dokumentasie vir [`Into`] vir meer inligting hieroor.
///
/// # Implementering van `TryInto`
///
/// Dit het dieselfde beperkings en redenasies as die implementering van [`Into`], sien daar vir besonderhede.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Die tipe wat teruggestuur word in geval van 'n omskakelingsfout.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Voer die omskakeling uit.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Eenvoudige en veilige omskakelings wat onder sekere omstandighede op 'n beheerde manier kan misluk.Dit is die wederkerigheid van [`TryInto`].
///
/// Dit is handig as u 'n tipe omskakeling doen wat triviaal kan slaag, maar wat ook spesiale hantering benodig.
/// Daar is byvoorbeeld geen manier om 'n [`i64`] in 'n [`i32`] te omskakel met behulp van die [`From`] trait nie, omdat 'n [`i64`] 'n waarde kan bevat wat 'n [`i32`] nie kan voorstel nie en die omskakeling dus data verloor.
///
/// Dit kan hanteer word deur die [`i64`] op 'n [`i32`] af te kap (in wese die ['i64'] se waarde modulo [`i32::MAX`] te gee) of deur eenvoudig [`i32::MAX`] terug te stuur, of op 'n ander manier.
/// Die [`From`] trait is bedoel vir perfekte omskakelings, dus stel die `TryFrom` trait die programmeerder in kennis wanneer 'n tipe omskakeling sleg kan gaan en laat hulle besluit hoe om dit te hanteer.
///
/// # Generiese implementasies
///
/// - `TryFrom<T> for U` impliseer [`TryInto`]`<U>vir T`</u>
/// - [`try_from`] is refleksief, wat beteken dat `TryFrom<T> for T` geïmplementeer word en nie kan misluk nie-die gepaardgaande `Error`-tipe vir die aanroep van `T::try_from()` op 'n waarde van die tipe `T` is [`Infallible`].
/// As die [`!`]-tipe gestabiliseer is, sal [`Infallible`] en [`!`] gelykstaande wees.
///
/// `TryFrom<T>` kan soos volg geïmplementeer word:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Soos beskryf, implementeer [`i32`] `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Maak `big_number` stilweg af, moet die afkapping opgespoor en hanteer word.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Wys 'n fout omdat `big_number` te groot is om in 'n `i32` te pas.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Lewer `Ok(3)` op.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Die tipe wat teruggestuur word in geval van 'n omskakelingsfout.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Voer die omskakeling uit.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// GENERIESE IMPLS
////////////////////////////////////////////////////////////////////////////////

// As hysbakke oor en
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// As hysbakke meer as &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): vervang bogenoemde impls vir&/&mut deur die volgende meer algemene:
// // As hysbakke oor Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Sized> AsRef <U>for D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut lig meer as &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): vervang bogenoemde impl vir &mut deur die volgende meer algemene:
// // AsMut lig oor DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Sized> AsMut <U>for D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Van impliseer Into
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Van (en dus Into) is refleksief
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Stabiliteitsnota:** Hierdie impl bestaan nog nie, maar ons is "reserving space" om dit in die future by te voeg.
/// Sien [rust-lang/rust#64715][#64715] vir meer inligting.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): doen eerder 'n beginseloplossing.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom impliseer TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Onfeilbare omskakelings is semanties gelyk aan feilbare omskakelings met 'n onbewoonde fouttipe.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// BETON IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// DIE TIPE GEEN FOUT FOUT
////////////////////////////////////////////////////////////////////////////////

/// Die fouttipe vir foute wat nooit kan gebeur nie.
///
/// Aangesien hierdie enum geen variant het nie, kan 'n waarde van hierdie tipe nooit bestaan nie.
/// Dit kan nuttig wees vir generiese API's wat [`Result`] gebruik en die fouttipe parameteriseer, om aan te dui dat die resultaat altyd [`Ok`] is.
///
/// Die [`TryFrom`] trait (omskakeling wat 'n [`Result`] oplewer) het byvoorbeeld 'n dekenimplementering vir alle soorte waar 'n omgekeerde [`Into`]-implementering bestaan.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future versoenbaarheid
///
/// Hierdie enum speel dieselfde rol as [the `!`“never”type][never], wat onstabiel is in hierdie weergawe van Rust.
/// Wanneer `!` gestabiliseer is, beplan ons om `Infallible` 'n soort alias daarvoor te maak:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... en uiteindelik `Infallible` verouder.
///
/// Daar is egter een geval waar `!`-sintaksis gebruik kan word voordat `!` as 'n volwaardige tipe gestabiliseer word: in die posisie van die tipe terugkeer van 'n funksie.
/// Dit is spesifiek moontlik om twee verskillende soorte funksie-aanwysers te implementeer:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Aangesien `Infallible` 'n enum is, is hierdie kode geldig.
/// Wanneer `Infallible` egter 'n alias word vir die never type, sal die twee 'impl' begin oorvleuel en sal dit dus nie toegelaat word deur die samehangsreëls van die taal trait nie.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}