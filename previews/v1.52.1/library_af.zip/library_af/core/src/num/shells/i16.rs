//! Konstante vir die 16-bis getekende heelgetal tipe.
//!
//! *[See also the `i16` primitive type][i16].*
//!
//! Nuwe kode moet die gepaardgaande konstantes direk op die primitiewe tipe gebruik.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i16`"
)]

int_module! { i16 }