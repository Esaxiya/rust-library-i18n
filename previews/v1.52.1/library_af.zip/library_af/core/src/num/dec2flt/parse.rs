//! Validering en ontbinding van 'n desimale string van die vorm:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Met ander woorde, standaard dryfpunt-sintaksis, met twee uitsonderings: geen teken en geen hantering van "inf" en "NaN" nie.Dit word deur die bestuurderfunksie (super::dec2flt) hanteer.
//!
//! Alhoewel die erkenning van geldige insette relatief maklik is, moet hierdie module ook die ontelbare ongeldige variasies verwerp, nooit panic nie, en talle ondersoeke uitvoer waarop die ander modules vertrou om nie weer panic (of te veel) te laat nie.
//!
//! Om sake te vererger, gaan alles wat in een keer gebeur, oor die insette.
//! Wees dus versigtig wanneer u enigiets aanpas, en kyk na die ander modules.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Die interessante dele van 'n desimale string.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Die desimale eksponent het gewis minder as 18 desimale syfers.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Kontroleer of die invoerstring 'n geldige drywingspuntnommer is en soek die integrale deel, die breukdeel en die eksponent daarin.
/// Hanteer nie tekens nie.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Geen syfers voor 'e' nie
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Ons benodig ten minste een enkele syfer voor of na die punt.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Sleep rommel na breukdeel
            }
        }
        _ => Invalid, // Sleep rommel na eerste syfer
    }
}

/// Sny desimale syfers af tot by die eerste nie-syferkarakter.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Eksponentonttrekking en foutkontrole.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Sleep rommel na eksponent
    }
    if number.is_empty() {
        return Invalid; // Leë eksponent
    }
    // Op hierdie stadium het ons beslis 'n geldige reeks syfers.Dit kan te lank wees om 'n `i64` in te sit, maar as dit so groot is, is die invoer beslis nul of oneindig.
    // Aangesien elke nul in die desimale syfers die eksponent net met +/-1 aanpas, sal die invoer by exp=10 ^ 18 17 exabyte (!) nulle moet wees om selfs op 'n afstand te wees om eindig te wees.
    //
    // Dit is nie juis 'n gebruiksgeval waaraan ons moet aandag gee nie.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}