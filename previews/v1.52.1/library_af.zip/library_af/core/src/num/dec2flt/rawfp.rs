//! Bietjie vroetel aan positiewe IEEE 754 drywings.Negatiewe getalle is nie en hoef nie hanteer te word nie.
//! Normale drywingsgetalle het 'n kanonieke voorstelling as (frac, exp) sodat die waarde 2 <sup>exp</sup> * is (1 + sum(frac[N-i] / 2<sup>i</sup>)) waar N die aantal bis is.
//!
//! Ondernormale is effens anders en vreemd, maar dieselfde beginsel geld.
//!
//! Hier stel ons hulle egter voor as (sig, k) met f positief, sodat die waarde f * is
//! 2 <sup>e</sup> .Behalwe dat die "hidden bit" eksplisiet is, verander dit ook die eksponent deur die sogenaamde mantissaskuif.
//!
//! Anders gestel, floats word normaalweg as (1) geskryf, maar hier word dit as (2) geskryf:
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Ons noem (1) die **breukvoorstelling** en (2) die **integrale voorstelling**.
//!
//! Baie funksies in hierdie module hanteer slegs normale getalle.Die dec2flt-roetines neem konserwatief die algemeen korrekte stadige pad (Algoritme M) vir baie klein en baie groot getalle.
//! Die algoritme benodig slegs next_float(), wat wel subnormale en nulle hanteer.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// 'N Helper trait om te verhoed dat die omskakeling van `f32` en `f64` basies gedupliseer word.
///
/// Kyk in die dokument van die ouermodule vir die rede waarom dit nodig is.
///
/// Moet ** nooit vir ander tipes geïmplementeer word nie of buite die dec2flt-module gebruik word nie.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Tipe wat deur `to_bits` en `from_bits` gebruik word.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Voer 'n rou transmutasie na 'n heelgetal uit.
    fn to_bits(self) -> Self::Bits;

    /// Voer 'n rou transmutasie vanaf 'n heelgetal uit.
    fn from_bits(v: Self::Bits) -> Self;

    /// Wys die kategorie waarin hierdie nommer val.
    fn classify(self) -> FpCategory;

    /// Wys die mantissa, eksponent en teken as heelgetalle.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Dekodeer die vlot.
    fn unpack(self) -> Unpacked;

    /// Werp uit 'n klein heelgetal wat presies voorgestel kan word.
    /// Panic as die heelgetal nie voorgestel kan word nie, sorg die ander kode in hierdie module dat dit nooit gebeur nie.
    fn from_int(x: u64) -> Self;

    /// Kry die waarde 10 <sup>e</sup> uit 'n vooraf berekende tabel.
    /// Panics vir `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Wat die naam sê.
    /// Dit is makliker om te kodeer as om intrinsieke te jongleren en hoop dat LLVM dit konstant vou.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // 'N Konserwatiewe lyn met die desimale syfers van insette wat nie oorloop of nul of kan lewer nie
    /// ondernormale.Waarskynlik die desimale eksponent van die maksimum normale waarde, vandaar die naam.
    const MAX_NORMAL_DIGITS: usize;

    /// Wanneer die belangrikste desimale syfer 'n plekwaarde groter as dit het, word die getal beslis afgerond tot oneindig.
    ///
    const INF_CUTOFF: i64;

    /// Wanneer die belangrikste desimale syfer 'n plekwaarde kleiner as dit het, word die getal beslis tot nul afgerond.
    ///
    const ZERO_CUTOFF: i64;

    /// Die aantal bisse in die eksponent.
    const EXP_BITS: u8;

    /// Die aantal bisse in die significand,*insluitend* die verborge bit.
    const SIG_BITS: u8;

    /// Die aantal bisse in die significand,*uitgesluit* die verborge bit.
    const EXPLICIT_SIG_BITS: u8;

    /// Die maksimum wettige eksponent in fraksionele verteenwoordiging.
    const MAX_EXP: i16;

    /// Die minimum wettige eksponent in fraksionele voorstelling, uitgesonderd subnormale.
    const MIN_EXP: i16;

    /// `MAX_EXP` vir integrale voorstelling, dws met die verskuiwing wat toegepas word.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` gekodeer (dws met verrekeningsvooroordeel)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` vir integrale voorstelling, dws met die verskuiwing wat toegepas word.
    const MIN_EXP_INT: i16;

    /// Die maksimum genormaliseerde betekenis in integrale voorstelling.
    const MAX_SIG: u64;

    /// Die minimale genormaliseerde betekenis in integrale voorstelling.
    const MIN_SIG: u64;
}

// Meestal 'n oplossing vir #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Wys die mantissa, eksponent en teken as heelgetalle.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Eksponent-vooroordeel + mantissaskuif
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe is onseker of `as` op alle platforms korrek ronddraai.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Wys die mantissa, eksponent en teken as heelgetalle.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Eksponent-vooroordeel + mantissaskuif
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe is onseker of `as` op alle platforms korrek ronddraai.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Skakel 'n `Fp` om na die naaste masjienvlottertipe.
/// Hanteer nie subnormale resultate nie.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f is 64 bit, dus het xe 'n mantissa-verskuiwing van 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Rond die 64-bis betekenisvol af tot T::SIG_BITS stukkies met half tot gelyk.
/// Hanteer nie eksponentoorloop nie.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Pas mantissa-skuif aan
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Inverse van `RawFloat::unpack()` vir genormaliseerde getalle.
/// Panics as die betekenis of eksponent nie geldig is vir genormaliseerde getalle nie.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Verwyder die verborge bietjie
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Pas die eksponent aan vir eksponentvooroordeel en mantissaskuif
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Laat 'n bietjie op 0 ("+"), ons getalle is positief
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Konstrueer 'n subnormale.'N Mantissa van 0 word toegelaat en konstrueer nul.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Gekodeerde eksponent is 0, die tekenbit is 0, dus moet ons die bisse net herinterpreteer.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Benader 'n bignum met 'n Fp.Rond binne 0.5 ULP af met half tot gelyk.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Ons sny alle stukkies voor die indeks `start` af, dws ons skuif effektief met 'n hoeveelheid `start`, dus dit is ook die eksponent wat ons benodig.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Rond (half-to-even), afhangende van die afgeknotte stukkies.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Vind die grootste drywingspuntgetal wat strenger kleiner is as die argument.
/// Hanteer nie subnormale, nul of eksponente ondervloei nie.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Vind die kleinste drywende punt nommer groter as die argument.
// Hierdie bewerking is versadigend, dws next_float(inf) ==inf.
// In teenstelling met die meeste kode in hierdie module, hanteer hierdie funksie nul, subnormale en oneindighede.
// Soos alle ander kode hier, handel dit egter nie oor NaN en negatiewe getalle nie.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Dit lyk te goed om waar te wees, maar dit werk.
        // 0.0 word gekodeer as die all-zero woord.Ondernormale is 0x000m ... m waar m die mantissa is.
        // In die besonder is die kleinste subnormaal 0x0 ... 01 en die grootste 0x000F ... F.
        // Die kleinste normale getal is 0x0010 ... 0, dus hierdie hoeksak werk ook.
        // As die inkrement die mantissa oorloop, verhoog die dra-bit die eksponent soos ons wil, en word die mantissabitse nul.
        // Vanweë die verborge bitkonvensie is dit ook presies wat ons wil hê!
        // Laastens, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}