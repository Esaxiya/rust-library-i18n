//! Die verskillende algoritmes uit die vraestel.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Aantal beduidende stukkies in Fp
const P: u32 = 64;

// Ons stoor eenvoudig die beste benadering vir *alle* eksponente, sodat die veranderlike "h" en die gepaardgaande toestande weggelaat kan word.
// Dit verruil prestasie vir 'n paar kilobytes spasie.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// In die meeste argitekture het drywende puntbewerkings 'n eksplisiete bietjie grootte, daarom word die akkuraatheid van die berekening op 'n operasiebasis bepaal.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Op x86 word die x87 FPU gebruik vir vlotterbedrywighede as die SSE/SSE2-uitbreidings nie beskikbaar is nie.
// Die x87 FPU werk standaard met 80 bis presisie, wat beteken dat bewerkings tot 80 bits sal afloop, wat veroorsaak dat dubbele afronding plaasvind wanneer waardes uiteindelik voorgestel word as
//
// 32/64 bietjie float waardes.Om dit te oorkom, kan die FPU-beheerwoord so gestel word dat die berekeninge in die gewenste presisie uitgevoer word.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// 'N Struktuur wat gebruik word om die oorspronklike waarde van die FPU-beheerwoord te bewaar, sodat dit herstel kan word wanneer die struktuur laat val word.
    ///
    ///
    /// Die x87 FPU is 'n 16-bis register waarvan die velde soos volg is:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Die dokumentasie vir al die velde is beskikbaar in die IA-32 Architectures Software Developer's Manual (Volume 1).
    ///
    /// Die enigste veld wat relevant is vir die volgende kode is PC, Precision Control.
    /// Hierdie veld bepaal die akkuraatheid van die bewerkings wat deur die FPU uitgevoer word.
    /// Dit kan ingestel word op:
    ///  - 0b00, enkele presisie, dws 32-bis
    ///  - 0b10, dubbele presisie, dws 64-bis
    ///  - 0b11, dubbele uitgebreide presisie, dws 80-bis (standaardtoestand) Die waarde 0b01 is voorbehou en moet nie gebruik word nie.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // VEILIGHEID: die `fldcw`-instruksie is geoudit om korrek mee te kan werk
        // enige `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Ons gebruik ATT-sintaksis om LLVM 8 en LLVM 9 te ondersteun.
                options(att_syntax, nostack),
            )
        }
    }

    /// Stel die presisieveld van die FPU in op `T` en gee 'n `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Bereken die waarde vir die Precision Control-veld wat geskik is vir `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bisse
            8 => 0x0200, // 64 bisse
            _ => 0x0300, // verstek, 80 bisse
        };

        // Kry die oorspronklike waarde van die kontrolewoord om dit later te herstel, wanneer die `FPUControlWord`-struktuur laat vaar word VEILIGHEID: die `fnstcw`-instruksie is geoudit om korrek met enige `u16` te kan werk
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Ons gebruik ATT-sintaksis om LLVM 8 en LLVM 9 te ondersteun.
                options(att_syntax, nostack),
            )
        }

        // Stel die kontrolewoord op die gewenste presisie.
        // Dit word bereik deur die ou presisie (stukkies 8 en 9, 0x300) weg te masker en te vervang deur die presisievlag hierbo bereken.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Die vinnige pad van Bellerophon met behulp van masjiengrootte heelgetalle en vlotte.
///
/// Dit word in 'n aparte funksie onttrek sodat dit gepoog kan word voordat u 'n bignum konstrueer.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Ons vergelyk die presiese waarde met MAX_SIG aan die einde, dit is net 'n vinnige, goedkoop verwerping (en maak die res van die kode ook vry van bekommernis oor onderstroom).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Die vinnige pad hang van die grootste belang af dat die rekenkunde tot die regte aantal bisse afgerond word sonder enige tussenafronding.
    // Op x86 (sonder SSE of SSE2) vereis dit dat die presisie van die x87 FPU-stapel verander word sodat dit direk tot 64/32-bietjie afgerond word.
    // Die `set_precision`-funksie sorg vir die akkuraatheid van argitekture wat dit moet instel deur die globale toestand te verander (soos die kontrolewoord van die x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Die saak e <0 kan nie in die ander tak gevou word nie.
    // Negatiewe kragte lei tot 'n herhalende breukdeel in binêre, wat afgerond is, wat werklike (en soms nogal beduidende!) Foute in die finale resultaat veroorsaak.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algoritme Bellerophon is triviale kode wat geregverdig word deur nie-triviale numeriese ontleding.
///
/// Dit rond 'f' na 'n vlotter met 64 bis-betekenis en vermenigvuldig dit met die beste benadering van `10^e` (in dieselfde drywingspuntformaat).Dit is dikwels genoeg om die regte resultaat te behaal.
/// As die resultaat egter byna halfpad tussen twee aangrensende (ordinary)-drywe is, beteken die saamgestelde afrondingsfout om twee benaderings te vermenigvuldig, die resultaat met 'n paar stukkies af.
/// As dit gebeur, maak die iteratiewe algoritme R dinge reg.
///
/// Die handgolwe "close to halfway" word presies gemaak deur die numeriese ontleding in die vraestel.
/// In die woorde van Clinger:
///
/// > Slop, uitgedruk in eenhede van die minste betekenisvolle bietjie, is 'n inklusiewe grens vir die fout
/// > opgehoop tydens die drywingsberekening van die benadering tot f * 10 ^ e.(Slop is
/// > nie gebind vir die ware fout nie, maar grens die verskil tussen die benadering z en
/// > die beste moontlike benadering wat p stukkies betekenis gebruik.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Die gevalle abs(e) <log5(2^N) is in fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Is die helling groot genoeg om 'n verskil te maak wanneer dit afgerond word tot n stukke?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// 'N Iteratiewe algoritme wat die benadering van die drywende punt van `f * 10^e` verbeter.
///
/// Elke iterasie kom in die laaste plek een eenheid nader, wat natuurlik verskriklik lank neem om te konvergeer as `z0` selfs effens af is.
/// Gelukkig, wanneer dit as 'n terugval vir Bellerophon gebruik word, is die beginbenadering hoogstens een ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Vind positiewe heelgetalle `x`, `y` sodat `x / y` presies `(f *10^e) / (m* 2^k)` is.
        // Dit vermy nie net die hantering van die tekens van `e` en `k` nie, maar ons skakel ook die krag uit van twee wat algemeen is vir `10^e` en `2^k` om die getalle kleiner te maak.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Dit word 'n bietjie ongemaklik geskryf omdat ons bignums nie negatiewe getalle ondersteun nie, dus gebruik ons die absolute waarde + tekeninligting.
        // Die vermenigvuldiging met m_digits kan nie oorloop nie.
        // As `x` of `y` groot genoeg is om ons oor oorloop te bekommer, is hulle ook groot genoeg dat `make_ratio` die breuk met 'n faktor van 2 ^ 64 of meer verminder het.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Het u nie meer x nodig nie, stoor 'n clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Het u nog nodig, maak 'n afskrif.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Gegewe `x = f` en `y = m` waar `f` die ingangs desimale syfers soos gewoonlik voorstel en `m` die betekenis is van 'n benadering van 'n drywende punt, maak die verhouding `x / y` gelyk aan `(f *10^e) / (m* 2^k)`, moontlik verminder deur 'n krag van twee, wat albei gemeen het.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, behalwe dat ons die breuk verminder met een of ander krag van twee.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Dit kan nie oorloop nie omdat dit positiewe `e` en negatiewe `k` benodig, wat slegs kan gebeur vir waardes wat baie naby aan 1 is, wat beteken dat `e` en `k` relatief klein sal wees.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Dit kan ook nie oorloop nie, sien hierbo.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), weer verminder met 'n gemeenskaplike krag van twee.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Konseptueel is Algoritme M die eenvoudigste manier om 'n desimaal na 'n vlotter om te skakel.
///
/// Ons vorm 'n verhouding wat gelyk is aan `f * 10^e` en gooi dan die kragte van twee in totdat dit 'n geldige vlot betekenis gee.
/// Die binêre eksponent `k` is die aantal kere wat ons teller of noemer met twee vermenigvuldig, dws `f *10^e` is altyd gelyk aan `(u / v)* 2^k`.
/// As ons betekenisvol agtergekom het, hoef ons slegs die res van die verdeling te ondersoek, wat verder in helperfunksies gedoen word.
///
///
/// Hierdie algoritme is baie stadig, selfs met die optimalisering wat in `quick_start()` beskryf word.
/// Dit is egter die eenvoudigste algoritme om aan te pas vir oorloop-, ondervloei-en subnormale resultate.
/// Hierdie implementering neem oor wanneer Bellerophon en Algorithm R oorweldig word.
/// Die opsporing van ondervloei en oorloop is maklik: die verhouding is nog steeds nie 'n belangrike betekenis nie, maar die minimum/maximum-eksponent is bereik.
/// In die geval van oorloop, keer ons eenvoudig die oneindigheid terug.
///
/// Die hantering van ondervloei en ondernormale is moeiliker.
/// Een groot probleem is dat die verhouding, met die minimum eksponent, moontlik nog te groot is vir 'n betekenisvolle.
/// Sien underflow() vir meer inligting.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME moontlike optimalisering: veralgemeen big_to_fp sodat ons die ekwivalent van fp_to_float(big_to_fp(u)) hier kan doen, slegs sonder die dubbele afronding.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Ons moet by die minimum eksponent stop, as ons wag tot `k < T::MIN_EXP_INT`, sal ons met 'n faktor van twee af wees.
            // Ongelukkig beteken dit dat ons normale getalle met die minimum eksponent moet spesialiseer.
            // FIXME vind 'n meer elegante formulering, maar voer die `tiny-pow10`-toets uit om seker te maak dat dit korrek is!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Slaan die meeste algoritme M-iterasies oor deur die bitlengte na te gaan.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Die bitlengte is 'n skatting van die basis twee logaritme, en log(u / v) = log(u), log(v).
    // Die skatting is hoogstens 1 af, maar altyd 'n onderskatting, dus die fout op log(u) en log(v) is dieselfde teken en kanselleer (as albei groot is).
    // Daarom is die fout vir log(u / v) ook hoogstens een.
    // Die teikenverhouding is een waar u/v binne-binne-betekenis is.Dus is ons beëindigingsvoorwaarde dat log2(u / v) die betekenisvolle stukkies is, plus/minus een.
    // FIXME As u na die tweede bietjie kyk, kan dit die skatting verbeter en nog meer afdelings vermy.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Ondervloei of subnormaal.Laat dit aan die hooffunksie oor.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Oorloop.Laat dit aan die hooffunksie oor.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Verhouding is nie 'n betekenis binne die bereik met die minimum eksponent nie, daarom moet ons oortollige stukkies afrond en die eksponent daarvolgens aanpas.
    // Die werklike waarde lyk nou so:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q afgesny.(voorgestel deur rem)
    //
    // Daarom, wanneer die afgeronde stukkies!= 0.5 ULP is, besluit hulle die afronding op hul eie.
    // As hulle gelyk is en die res nie-nul is, moet die waarde steeds afgerond word.
    // Slegs wanneer die afgeronde stukkies 1/2 is en die res nul, het ons 'n half-tot-egalige situasie.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Gewone rond-tot-gelyk, verduister deur die afronding gebaseer op die res van 'n afdeling.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}