//! Byna direkte (maar effens geoptimaliseerde) Rust-vertaling van figuur 3 van "Druk swaai-puntgetalle vinnig en akkuraat" [^ 1].
//!
//!
//! [^1]: Burger, RG en Dybvig, RK 1996. Die druk van drywingsgetalle
//!   vinnig en akkuraat.SIGPLAN Nie.31, 5 (Mei 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// voorafberekende skikkings van `Digit`s vir 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// slegs bruikbaar wanneer `x < 16 * scale`;`scaleN` moet `scale.mul_small(N)` wees
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Die kortste implementering vir Dragon.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // die nommer `v` om te formateer is bekend as:
    // - gelyk aan `mant * 2^exp`;
    // - voorafgegaan deur `(mant - 2 *minus)* 2^exp` in die oorspronklike tipe;en
    // - gevolg deur `(mant + 2 *plus)* 2^exp` in die oorspronklike tipe.
    //
    // `minus` en `plus` kan natuurlik nie nul wees nie.(vir oneindighede gebruik ons waardes buite die omvang.) Ons neem ook aan dat ten minste een syfer gegenereer word, dws `mant` kan ook nie nul wees nie.
    //
    // dit beteken ook dat enige getal tussen `low = (mant - minus)*2^exp` en `high = (mant + plus)* 2^exp` op hierdie presiese drywingspuntgetal sal plaasvind, met grense ingesluit toe die oorspronklike mantissa gelyk was (dws `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` is `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // skat `k_0` uit oorspronklike insette wat aan `10^(k_0-1) < high <= 10^(k_0+1)` voldoen.
    // die `k` wat aan `10^(k-1) < high <= 10^k` voldoen, word later bereken.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // omskep `{mant, plus, minus} * 2^exp` in die breukvorm sodat:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // deel `mant` deur `10^k`.nou `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // regstelling wanneer `mant + plus > scale` (of `>=`).
    // ons is nie besig om `scale` aan te pas nie, want ons kan eerder die aanvanklike vermenigvuldiging oorslaan.
    // nou `scale < mant + plus <= scale * 10` en ons is gereed om syfers te genereer.
    //
    // daarop dat `d[0]` * nul kan wees, wanneer `scale - plus < mant < scale`.
    // in hierdie geval sal afrondingstoestand (`up` hieronder) onmiddellik geaktiveer word.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // gelykstaande aan die skaal van `scale` met 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // kas `(2, 4, 8) * scale` vir generasie van syfers.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // invariërs, waar `d[0..n-1]` syfers is wat tot dusver gegenereer is:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (dus `mant / scale < 10`) waar `d[i..j]` 'n snelskrif is vir `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // genereer een syfer: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // dit is 'n vereenvoudigde beskrywing van die gewysigde Dragon-algoritme.
        // baie tussenafleidings en volledigheidsargumente word gerieflikheidshalwe weggelaat.
        //
        // begin met gewysigde invariërs, aangesien ons `n` opgedateer het:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // neem aan dat `d[0..n-1]` die kortste weergawe is tussen `low` en `high`, dws `d[0..n-1]` voldoen aan albei die volgende, maar `d[0..n-2]` nie:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (byektiwiteit: syfers rondom tot `v`);en
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (die laaste syfer is korrek).
        //
        // die tweede voorwaarde vereenvoudig tot `2 * mant <= scale`.
        // die oplossing van invariërs in terme van `mant`, `low` en `high` lewer 'n eenvoudiger weergawe van die eerste voorwaarde: `-plus < mant < minus`.
        // sedert `-plus < 0 <= mant`, het ons die korrekte voorstelling as `mant < minus` en `2 * mant <= scale`.
        // (eersgenoemde word `mant <= minus` as die oorspronklike mantissa gelyk is.)
        //
        // as die tweede nie hou nie (`2 * mant> skaal`), moet ons die laaste syfer verhoog.
        // dit is genoeg om die toestand te herstel: ons weet reeds dat die syferopwekking `0 <= v / 10^(k-n) - d[0..n-1] < 1` waarborg.
        // in hierdie geval word die eerste voorwaarde `-plus < mant - scale < minus`.
        // sedert `mant < scale` na die generasie, het ons `scale < mant + plus`.
        // (dit word weer `scale <= mant + plus` as die oorspronklike mantissa gelyk is.)
        //
        // in kort:
        // - stop en rond `down` (hou syfers soos dit is) wanneer `mant < minus` (of `<=`).
        // - stop en rond `up` (vermeerder die laaste syfer) wanneer `scale < mant + plus` (of `<=`).
        // - hou aan om anders te genereer.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // ons het die kortste voorstelling, gaan voort na die afronding

        // herstel die invariërs.
        // dit maak dat die algoritme altyd eindig: `minus` en `plus` neem altyd toe, maar `mant` word geknip modulo `scale` en `scale` is vas.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // afronding vind plaas wanneer i) slegs die afrondingsvoorwaarde geaktiveer is, of ii) albei toestande veroorsaak is en dasbinding verkies om af te rond.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // as afronding die lengte verander, moet die eksponent ook verander.
        // dit lyk asof dit baie moeilik is om aan hierdie voorwaarde te voldoen (moontlik onmoontlik), maar ons is net hier veilig en konsekwent.
        //
        // VEILIGHEID: ons het die geheue hierbo geïnitialiseer.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // VEILIGHEID: ons het die geheue hierbo geïnitialiseer.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Die presiese en vaste modus implementering vir Dragon.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // skat `k_0` uit oorspronklike insette wat aan `10^(k_0-1) < v <= 10^(k_0+1)` voldoen.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // deel `mant` deur `10^k`.nou `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // regstelling wanneer `mant + plus >= scale`, waar `plus / scale = 10^-buf.len() / 2`.
    // Om die bignum van vaste grootte te behou, gebruik ons eintlik `mant + floor(plus) >= scale`.
    // ons is nie besig om `scale` aan te pas nie, want ons kan eerder die aanvanklike vermenigvuldiging oorslaan.
    // weer met die kortste algoritme, kan `d[0]` nul wees, maar uiteindelik afgerond word.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // gelykstaande aan die skaal van `scale` met 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // as ons met die laaste-syfer-beperking werk, moet ons die buffer voor die werklike weergawe verkort om dubbele afronding te vermy.
    //
    // daarop dat ons die buffer weer moet vergroot as afronding plaasvind!
    let mut len = if k < limit {
        // oeps, ons kan nie eens *een* syfer produseer nie.
        // dit is moontlik as ons byvoorbeeld iets soos 9.5 het en dit word afgerond tot 10.
        // ons gee 'n leë buffer terug, met die uitsondering van die latere afrondingsaak wat plaasvind wanneer `k == limit` en presies een syfer moet lewer.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // kas `(2, 4, 8) * scale` vir generasie van syfers.
        // (dit kan duur wees, moet dit dus nie bereken as die buffer leeg is nie.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // volgende syfers is nulle, ons stop hier *probeer* nie afronding doen nie!vul eerder die oorblywende syfers in.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // VEILIGHEID: ons het die geheue hierbo geïnitialiseer.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // afronding as ons in die middel van die syfers stop as die volgende syfers presies 5000 is ... kyk na die vorige syfer en probeer om af te rond (dws vermy afronding as die vorige syfer gelyk is).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // VEILIGHEID: `buf[len-1]` is geïnisialiseer.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // as afronding die lengte verander, moet die eksponent ook verander.
        // maar ons het 'n vaste aantal syfers gevra, en moenie die buffer verander nie ...
        // VEILIGHEID: ons het die geheue hierbo geïnitialiseer.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... tensy daar eerder vir ons die vaste presisie gevra word.
            // ons moet ook seker maak dat, as die oorspronklike buffer leeg was, die addisionele syfer slegs bygevoeg kan word as `k == limit` (geval edge).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // VEILIGHEID: ons het die geheue hierbo geïnitialiseer.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}