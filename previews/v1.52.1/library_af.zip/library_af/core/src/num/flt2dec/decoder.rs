//! Dekodeer 'n drywende puntwaarde in individuele dele en foutreekse.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Onbepaalde eindige waarde is gedekodeer, sodat:
///
/// - Die oorspronklike waarde is gelyk aan `mant * 2^exp`.
///
/// - Enige getal van `(mant - minus)*2^exp` tot `(mant + plus)* 2^exp` sal tot die oorspronklike waarde afrond.
/// Die reeks is slegs ingesluit as `inclusive` `true` is.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Die afgeskaalde mantissa.
    pub mant: u64,
    /// Die onderste foutbereik.
    pub minus: u64,
    /// Die boonste foutreeks.
    pub plus: u64,
    /// Die gedeelde eksponent in basis 2.
    pub exp: i16,
    /// Waar as die foutbereik insluit.
    ///
    /// In IEEE 754 is dit waar toe die oorspronklike mantissa gelyk was.
    pub inclusive: bool,
}

/// Ongedekte waarde ongedekodeer.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Oneindighede, positief of negatief.
    Infinite,
    /// Nul, hetsy positief of negatief.
    Zero,
    /// Eindige getalle met verdere gedekodeerde velde.
    Finite(Decoded),
}

/// 'N Soort drywende punt wat' dekodeer 'kan word d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Die minimum positiewe genormaliseerde waarde.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Wys 'n teken (waar as negatief) en `FullDecoded`-waarde vanaf gegewe drywingsgetal.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // bure: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode bewaar altyd die eksponent, dus word die mantissa geskaal vir subnormale.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // bure: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // waar maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // bure: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}