//! Tipes wat data op hul plek in die geheue vaspen.
//!
//! Dit is soms handig om voorwerpe te hê wat gewaarborg word om nie te beweeg nie, in die sin dat die plasing daarvan in die geheue nie verander nie, en daarom kan vertrou word.
//! 'N Goeie voorbeeld van so 'n scenario is om selfverwysende strukture te bou, aangesien die verskuiwing van 'n voorwerp met rigtingwysers dit ongeldig kan maak, wat ongedefinieerde gedrag kan veroorsaak.
//!
//! Op 'n hoë vlak verseker 'n [`Pin<P>`] dat die wyser van enige aanwyser `P` 'n stabiele plek in die geheue het, wat beteken dat dit nie elders geskuif kan word nie en dat die geheue nie weer toegedeel kan word voordat dit val nie.Ons sê dat die aanwyser "pinned" is.Dinge word subtieler wanneer tipes bespreek word wat vasgemaak word met nie-vasgemaakte data;[see below](#projections-and-structural-pinning) vir meer besonderhede.
//!
//! Standaard is alle soorte in Rust verskuifbaar.
//! Met Rust kan alle soorte bywaardes oorgedra word, en gewone slimwysertipes soos [`Box<T>`] en `&mut T` laat toe om die waardes wat hulle bevat, te vervang en te skuif: u kan uit 'n [`Box<T>`] beweeg, of u kan [`mem::swap`] gebruik.
//! [`Pin<P>`] vou 'n aanwyser `P`, dus [`Pin`]`<`[`Box`] `<T>>`funksioneer baie soos 'n gewone
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Box`] `<T>> val weg, so ook die inhoud, en die geheue word
//!
//! gehandel is.Net so lyk [`Pin`]`<&mut T>`baie soos `&mut T`.[`Pin<P>`] laat kliënte egter nie werklik 'n [`Box<T>`] of `&mut T` toe aan vasgepen data nie, wat impliseer dat u nie bewerkings soos [`mem::swap`] kan gebruik nie:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` benodig `&mut T`, maar ons kan dit nie kry nie.
//!     // Ons sit vas en kan nie die inhoud van hierdie verwysings omruil nie.
//!     // Ons kan `Pin::get_unchecked_mut` gebruik, maar dit is om die rede onveilig:
//!     // ons mag dit nie gebruik om dinge uit die `Pin` te skuif nie.
//! }
//! ```
//!
//! Dit is die moeite werd om te herhaal dat [`Pin<P>`] nie die feit verander dat 'n Rust-samesteller alle soorte as beweeglik beskou nie.[`mem::swap`] bly oproepbaar vir enige `T`.In plaas daarvan verhoed [`Pin<P>`] dat sekere *waardes*(aangedui deur aanwysers wat in [`Pin<P>`] toegedraai is) beweeg word deur dit onmoontlik te maak om metodes op te roep wat `&mut T` benodig (soos [`mem::swap`]).
//!
//! [`Pin<P>`] kan gebruik word om enige wysertipe `P` te verpak, en as sodanig werk dit met [`Deref`] en [`DerefMut`].'N [`Pin<P>`] waar `P: Deref` moet beskou word as 'n "`P`-style pointer" op 'n vasgepen `P::Target`-dus 'n [`Pin`]`<`[`Box`] `<T>>`is 'n aanwyser in besit van 'n vasgepen `T`, en '[Pin']`<`[`Rc`] `<T>>`is 'n verwysingsgetel aanwyser na 'n vasgepen `T`.
//! Om korrek te wees, vertrou [`Pin<P>`] op die implementasies van [`Deref`] en [`DerefMut`] om nie uit hul `self`-parameter te beweeg nie, en slegs 'n wyser terug te plaas na vasgemaakte data wanneer hulle op 'n vasgepen gewys word.
//!
//! # `Unpin`
//!
//! Baie soorte is altyd vrylik verskuifbaar, selfs as dit vasgespeld is, omdat hulle nie daarop vertrou dat hulle 'n stabiele adres het nie.Dit sluit al die basistipes in (soos [`bool`], [`i32`] en verwysings) sowel as tipes wat slegs uit hierdie tipes bestaan.Tipes waaraan nie vasgehou word nie, implementeer die [`Unpin`] auto-trait, wat die effek van [`Pin<P>`] kanselleer.
//! Vir `T: Unpin`, [`Pin`]`<`[`Box`] `<T>>`en [`Box<T>`] funksioneer identies, net soos [`Pin`] `<&mut T>` en `&mut T`.
//!
//! Let daarop dat vaspen en [`Unpin`] slegs die aangeduide tipe `P::Target` beïnvloed, nie die wysertipe `P` self wat in [`Pin<P>`] toegedraai is nie.Of [`Box<T>`] [`Unpin`] is of nie, het geen invloed op die gedrag van [`Pin`]`<`[`Box`] `<T>> '(hier is `T` die gewysde tipe).
//!
//! # Voorbeeld: selfverwysende struktuur
//!
//! Voordat ons meer besonderhede gee om die waarborge en keuses verbonde aan `Pin<T>` te verduidelik, bespreek ons enkele voorbeelde vir hoe dit gebruik kan word.
//! Voel vry om [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Dit is 'n selfverwysende struktuur omdat die snyveld na die dataveld wys.
//! // Ons kan die samesteller nie hieroor met normale verwysing inlig nie, aangesien hierdie patroon nie met die gewone leenreëls beskryf kan word nie.
//! //
//! // In plaas daarvan gebruik ons 'n rou aanwyser, alhoewel dit bekend is dat dit nie nul is nie, want ons weet dat dit op die string wys.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Om te verseker dat die data nie beweeg as die funksie terugkeer nie, plaas ons dit op die hoop waar dit vir die leeftyd van die voorwerp sal bly, en die enigste manier om toegang daartoe te verkry, is deur middel van 'n aanwyser daarheen.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // ons maak die aanwyser slegs sodra die data op hul plek is, anders het dit al beweeg voordat ons eers begin het
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // ons weet dit is veilig omdat die verandering van 'n veld nie die hele struktuur beweeg nie
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Die aanwyser moet op die regte plek wys, solank die struktuur nie beweeg nie.
//! //
//! // Intussen staan ons vry om die wyser rond te skuif.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Aangesien ons tipe nie Unpin implementeer nie, kan dit nie saamstel nie:
//! // laat mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Voorbeeld: indringende dubbel gekoppelde lys
//!
//! In 'n indringende, dubbel gekoppelde lys, ken die versameling nie eintlik die geheue vir die elemente self toe nie.
//! Toekenning word deur kliënte beheer en elemente kan op 'n stapelraam leef wat korter leef as wat die versameling leef.
//!
//! Om dit te laat werk, het elke element verwysings na sy voorganger en opvolger in die lys.Elemente kan slegs bygevoeg word as dit vasgespeld is, want as u die elemente rondskuif, word die wysers ongeldig.Boonop sal die [`Drop`]-implementering van 'n gekoppelde lyselement die wysers van sy voorganger en opvolger pleister om homself van die lys te verwyder.
//!
//! Dit is belangrik dat ons kan staatmaak op die roeping van [`drop`].As 'n element herdeel of andersins ongeldig gemaak kan word sonder om [`drop`] te bel, sal die aanwysings daarin vanaf sy naburige elemente ongeldig word, wat die datastruktuur sal verbreek.
//!
//! Daarom is daar 'n waarborg wat verband hou met ['drop'] wat vasgepen is.
//!
//! # `Drop` guarantee
//!
//! Die doel van vasmaak is om te kan vertrou op die plasing van sommige data in die geheue.
//! Om dit te laat werk, is nie net die verskuiwing van die data beperk nie;die geheue wat gebruik word om die data te stoor, te herplaas, te hergebruik of andersins ongeldig te maak, is ook beperk.
//! Om vasgepen data vas te hou, moet u die onveranderlike volhou dat *die geheue nie ongeldig of hergebruik sal word vanaf die oomblik dat dit vasgepen word totdat [`drop`]* genoem word nie.Slegs sodra [`drop`] terugkeer of panics, kan die geheue hergebruik word.
//!
//! Geheue kan "invalidated" wees deur deallocation, maar ook deur 'n [`Some(v)`] te vervang deur [`None`], of deur [`Vec::set_len`] na "kill" te roep van 'n vector.Dit kan weer gebruik word deur [`ptr::write`] te gebruik om dit te oorskryf sonder om eers die vernietiger te skakel.Niks hiervan word toegelaat vir vasgepen data sonder om [`drop`] te skakel nie.
//!
//! Dit is presies die soort waarborg dat die indringende gekoppelde lys uit die vorige afdeling korrek moet funksioneer.
//!
//! Let op dat hierdie waarborg *nie* beteken dat geheue nie lek nie!Dit is nog steeds heeltemal goed om [`drop`] nooit op 'n vasgepen element te bel nie (bv. U kan nog steeds [`mem::forget`] op 'n [`Pin`]`<`[`Box`] `noem<T>>`).In die voorbeeld van die dubbel gekoppelde lys sou daardie element net in die lys bly.U mag die stoorplek egter nie vrymaak of hergebruik sonder om [`drop`] * te bel nie.
//!
//! # `Drop` implementation
//!
//! As u tipe vasmaak gebruik (soos die twee voorbeelde hierbo), moet u versigtig wees wanneer u [`Drop`] implementeer.Die [`drop`]-funksie neem `&mut self`, maar dit word *genoem, selfs al is u tipe voorheen vasgepen*!Dit is asof die samesteller outomaties [`Pin::get_unchecked_mut`] genoem word.
//!
//! Dit kan nooit 'n probleem in veilige kode veroorsaak nie, omdat die implementering van 'n tipe wat afhanklik is van 'n vasmaak, onveilige kode vereis, maar wees bewus daarvan dat u besluit om gebruik te maak van 'n vasmaak in u tipe (byvoorbeeld deur die bewerking op [`Pin`]`<&Self te implementeer>`of [`Pin`] `<&mut Self>`) het ook gevolge vir u [`Drop`]-implementering: as 'n element van u tipe vasgepen kon gewees het, moet u [`Drop`] behandel as implisiet die neem van [`Pin`]`<&mut Self>`.
//!
//!
//! U kan `Drop` byvoorbeeld soos volg implementeer:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` is goed, want ons weet dat hierdie waarde nooit weer gebruik word nie.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Werklike drop code hier.
//!         }
//!     }
//! }
//! ```
//!
//! Die funksie `inner_drop` het die tipe wat [`drop`]*moet* hê, dus sorg dat u nie per ongeluk `self`/`this` gebruik op 'n manier wat strydig is met vaspen nie.
//!
//! Verder, as u tipe `#[repr(packed)]` is, sal die samesteller outomaties velde skuif om dit te kan laat val.Dit kan selfs doen vir velde wat toevallig voldoende belyn is.As gevolg hiervan kan u nie vasmaak met 'n `#[repr(packed)]`-tipe gebruik nie.
//!
//! # Projeksies en strukturele vaspen
//!
//! As u met vasgepen strikte werk, ontstaan die vraag hoe u toegang tot die velde van daardie struktuur kan kry op 'n metode wat net [`Pin`]`<&mut Struct>`neem.
//! Die gewone benadering is om helpermetodes (sogenaamde *projeksies*) te skryf wat [`Pin`]`<&mut Struct> 'in 'n verwysing na die veld maak, maar watter tipe moet die verwysing hê?Is dit [`Pin`]` <&mut Field> `of `&mut Field`?
//! Dieselfde vraag ontstaan met die velde van 'n `enum`, en ook as u container/wrapper-tipes soos [`Vec<T>`], [`Box<T>`] of [`RefCell<T>`] oorweeg.
//! (Hierdie vraag is van toepassing op sowel veranderlike as gedeelde verwysings; ons gebruik slegs die meer algemene geval van veranderlike verwysings hier ter illustrasie.)
//!
//! Dit blyk dat dit eintlik aan die outeur van die datastruktuur is om te besluit of die vasgepen projeksie vir 'n bepaalde veld ['Pin'] '<&mut Struct>' in ['Pin'] '<&mut Field>' of `&mut Field`.Daar is wel enkele beperkings, en die belangrikste beperking is *konsekwentheid*:
//! elke veld kan *of* met 'n vasgepen verwysing geprojekteer word,*of* as 'n pinning as deel van die projeksie verwyder kan word.
//! As albei vir dieselfde veld gedoen word, sal dit waarskynlik nie gesond wees nie!
//!
//! As outeur van 'n datastruktuur kan u vir elke veld besluit of u "propagates" aan hierdie veld vasdruk of nie.
//! Vasspeld wat voortplant, word ook "structural" genoem, omdat dit die struktuur van die tipe volg.
//! In die volgende onderafdelings beskryf ons die oorwegings wat vir een van die twee keuses gemaak moet word.
//!
//! ## Vasspeld *is nie* struktureel vir `field` nie
//!
//! Dit lyk miskien kontra-intuïtief dat die veld van 'n vasgepen struktuur dalk nie vasgepen word nie, maar dit is eintlik die maklikste keuse: as 'n [`Pin`]` <&mut Field> 'nooit geskep word nie, kan niks verkeerd loop nie!As u dus besluit dat 'n veld nie 'n strukturele vaslegging het nie, hoef u net te verseker dat u nooit 'n vasgepen verwysing na daardie veld skep nie.
//!
//! Velde sonder strukturele vasstelling kan 'n projeksiemetode hê wat [`Pin`]` <&mut Struct> 'in `&mut Field` verander:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Dit is goed, want `field` word nooit as vasgepen beskou nie.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! U kan ook `impl Unpin for Struct`*, selfs as* die tipe `field` nie [`Unpin`] is nie.Wat die tipe oor vaspen dink, is nie relevant as daar nooit [`Pin`]`<&mut Field>`geskep word nie.
//!
//! ## Vastlegging *is* struktureel vir `field`
//!
//! Die ander opsie is om te besluit dat vasmaak "structural" is vir `field`, wat beteken dat as die struktuur vasgepen is, die veld ook so is.
//!
//! Hierdeur kan u 'n projeksie skryf wat 'n [`Pin`]` <&mut Field> 'skep, en sodoende getuig dat die veld vasgepen is:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Dit is goed, want `field` is vasgepen wanneer `self` is.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Strukturele vaslegging het egter 'n paar ekstra vereistes:
//!
//! 1. Die struktuur moet slegs [`Unpin`] wees as al die struktuurvelde [`Unpin`] is.Dit is die standaard, maar [`Unpin`] is 'n veilige trait, dus as die outeur van die struktuur is dit u verantwoordelikheid * om nie iets soos `impl<T> Unpin for Struct<T>` by te voeg nie.
//! (Let op dat die toevoeging van 'n projeksiebewerking onveilige kode vereis, dus die feit dat [`Unpin`] 'n veilige trait is, oortree nie die beginsel dat u slegs hieroor bekommerd moet wees as u 'onveilig' gebruik nie.)
//! 2. Die vernietiger van die struktuur mag nie strukturele velde uit sy argument skuif nie.Dit is die presiese punt wat in die [previous section][drop-impl] geopper is: `drop` neem `&mut self`, maar die struktuur (en dus sy velde) was moontlik al voorheen vasgepen.
//!     U moet waarborg dat u nie 'n veld binne u [`Drop`]-implementering skuif nie.
//!     In die besonder, soos vroeër verduidelik, beteken dit dat u struktuur *nie*`#[repr(packed)]` moet wees nie.
//!     Lees die gedeelte vir hoe u [`drop`] kan skryf sodat die samesteller u kan help om per ongeluk nie per ongeluk te breek nie.
//! 3. U moet seker maak dat u die [`Drop` guarantee][drop-guarantee] handhaaf:
//!     sodra u struktuur vasgepen is, word die geheue wat die inhoud bevat, nie oorskryf of geallokeer sonder om die vernietigers van die inhoud te noem nie.
//!     Dit kan lastig wees, soos getoon deur [`VecDeque<T>`]: die vernietiger van [`VecDeque<T>`] kan nie [`drop`] op alle elemente aanroep as een van die vernietigers panics is nie.Dit is in stryd met die [`Drop`]-waarborg, want dit kan daartoe lei dat elemente herdeel word sonder dat hul vernietiger ontbied word.([`VecDeque<T>`] het geen vassteekprojeksies nie, dus dit veroorsaak nie onsonde nie.)
//! 4. U mag geen ander bewerkings aanbied wat kan lei tot die verskuiwing van data uit die strukturele velde wanneer u tipe vasgepen is nie.As die struktuur byvoorbeeld 'n [`Option<T>`] bevat en 'n 'take'-agtige bewerking met tipe `fn(Pin<&mut Struct<T>>) -> Option<T>` is, kan die bewerking gebruik word om 'n `T` uit 'n vasgepen `Struct<T>` te skuif-wat beteken dat vaspen nie struktureel kan wees vir die veld wat hierdie data.
//!
//!     Vir 'n meer komplekse voorbeeld van die verskuiwing van data uit 'n vasgepen tipe, stel u voor of [`RefCell<T>`] 'n metode `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>` gehad het.
//!     Dan kan ons die volgende doen:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Dit is katastrofies, dit beteken dat ons eers die inhoud van die [`RefCell<T>`] (met behulp van `RefCell::get_pin_mut`) kan vassteek en dan die inhoud kan skuif met behulp van die veranderlike verwysing wat ons later gekry het.
//!
//! ## Examples
//!
//! Vir 'n tipe soos [`Vec<T>`] is albei moontlikhede (strukturele vasmaak of nie) sinvol.
//! 'N [`Vec<T>`] met strukturele vaslegging kan `get_pin`/`get_pin_mut`-metodes hê om vasgepen verwysings na elemente te kry.Dit kan egter *nie* toelaat dat [`pop`][Vec::pop] op 'n vasgepen [`Vec<T>`] gebel word nie, want dit sal die (struktureel vasgepen) inhoud skuif!Dit kan ook nie [`push`][Vec::push] toelaat nie, wat die inhoud kan her-toeken en sodoende ook skuif.
//!
//! 'N [`Vec<T>`] sonder strukturele vaslegging kan `impl<T> Unpin for Vec<T>` wees, want die inhoud word nooit vasgepen nie en die [`Vec<T>`] self kan ook geskuif word.
//! Op daardie stadium het vaspen net glad geen invloed op die vector nie.
//!
//! In die standaardbiblioteek het wysertipes gewoonlik nie strukturele vaslegging nie, en daarom bied dit nie vassteekprojeksies nie.Dit is die rede waarom `Box<T>: Unpin` vir alle `T` geld.
//! Dit is sinvol om dit vir wysertipes te doen, want die skuif van die `Box<T>` beweeg nie eintlik die `T` nie: die [`Box<T>`] kan vrylik beweegbaar wees (ook bekend as `Unpin`), selfs al is die `T` nie.In werklikheid, selfs [`Pin`]`<`[`Box`] `<T>> en [`Pin`]` <&mut T> `is altyd dieselfde [`Unpin`], om dieselfde rede: die inhoud daarvan (die `T`) word vasgepen, maar die aanwysers self kan geskuif word sonder om die vasgepen te skuif.
//! Vir beide [`Box<T>`] en [`Pin`]`<`[`Box`] `<T>>, of die inhoud vasgepen is, is heeltemal onafhanklik van die vraag of die wyser vasgepen is, wat beteken dat vas *nie* struktureel is nie.
//!
//! By die implementering van 'n [`Future`]-kombinator het u gewoonlik 'n strukturele vasstelling nodig vir die geneste futures, aangesien u vasgepen verwysings daarna moet kry om [`poll`] te noem.
//! Maar as u kombinator enige ander gegewens bevat wat nie vasgepen hoef te word nie, kan u die velde nie struktureel maak nie en dus vryelik toegang daartoe kry met 'n veranderlike verwysing, selfs as u net ["Pin"] <&mut Self> het (soos soos in u eie [`poll`]-implementering).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// 'N Gesteelde wyser.
///
/// Dit is 'n omhulsel rondom 'n soort aanwyser wat die wyser "pin" sy waarde op sy plek maak, en voorkom dat die waarde waarna die wyser verwys word verskuif word, tensy dit [`Unpin`] implementeer.
///
///
/// *Raadpleeg die [`pin` module]-dokumentasie vir 'n verduideliking van vaspen.*
///
/// [`pin` module]: self
///
// Note: die `Clone`-afleiding hieronder veroorsaak ongesondheid, aangesien dit moontlik is om dit te implementeer
// `Clone` vir veranderlike verwysings.
// Sien <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> vir meer besonderhede.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Die volgende implementasies word nie afgelei nie om probleme met 'n gesonde toestand te vermy.
// `&self.pointer` moet nie toeganklik wees vir onbetroubare trait-implementasies nie.
//
// Sien <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> vir meer besonderhede.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Konstrueer 'n nuwe `Pin<P>` rondom 'n aanwyser na data van 'n tipe wat [`Unpin`] implementeer.
    ///
    /// In teenstelling met `Pin::new_unchecked`, is hierdie metode veilig omdat die aanwyser `P` na 'n [`Unpin`]-tipe verwys, wat die vaswaarborge kanselleer.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // VEILIGHEID: die waarde waarna gewys word, is `Unpin` en het dus geen vereistes nie
        // rondom vaspen.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Pak hierdie `Pin<P>` uit om die onderliggende wyser terug te gee.
    ///
    /// Dit vereis dat die data binne hierdie `Pin` [`Unpin`] is, sodat ons die vasstaande invariërs kan ignoreer wanneer u dit uitpak.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Konstrueer 'n nuwe `Pin<P>` rondom 'n verwysing na sommige data van 'n tipe wat `Unpin` al dan nie implementeer.
    ///
    /// As `pointer` verwysings na 'n `Unpin`-tipe het, moet `Pin::new` eerder gebruik word.
    ///
    /// # Safety
    ///
    /// Hierdie konstrukteur is onveilig omdat ons nie kan waarborg dat die data waarop `pointer` verwys word vasgepen is nie, wat beteken dat die data nie geskuif sal word of dat die stoor daarvan ongeldig word totdat dit val nie.
    /// As die gekonstrueerde `Pin<P>` nie waarborg dat die data waarop `P` wys, vasgepen is nie, is dit 'n oortreding van die API-kontrak en kan dit lei tot ongedefinieerde gedrag in latere (safe)-bedrywighede.
    ///
    /// Deur hierdie metode te gebruik, maak u 'n promise oor die `P::Deref`-en `P::DerefMut`-implementasies, indien dit bestaan.
    /// Die belangrikste is dat hulle nie uit hul `self`-argumente moet beweeg nie: `Pin::as_mut` en `Pin::as_ref` sal `DerefMut::deref_mut` en `Deref::deref`*op die vasgemaakte wyser* noem en verwag dat hierdie metodes die vasstaande invariërs sal handhaaf.
    /// Verder, deur hierdie metode te noem, beloof u Z0 dat die verwysing `P`-verwysings na nie weer uitgeskuif sal word nie;In die besonder moet dit nie moontlik wees om 'n `&mut P::Target` te verkry en dan uit die verwysing te beweeg nie (met behulp van byvoorbeeld [`mem::swap`]).
    ///
    ///
    /// Om `Pin::new_unchecked` op 'n `&'a mut T` te roep, is byvoorbeeld onveilig, want hoewel u dit vir die gegewe leeftyd `'a` kan vaspen, het u geen beheer of dit vasgehou word sodra `'a` eindig nie:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Dit sou beteken dat die pointe `a` nooit weer kan beweeg nie.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Die adres van `a` verander na 'b' se stapelsleuf, sodat `a` beweeg het, alhoewel ons dit voorheen vasgepen het!Ons het die vasgestelde API-kontrak oortree.
    /////
    /// }
    /// ```
    ///
    /// Sodra 'n waarde vasgepen is, moet dit vir altyd vasgespeld bly (tensy die tipe `Unpin` implementeer).
    ///
    /// Net so is die oproep van `Pin::new_unchecked` na 'n `Rc<T>` onveilig, want daar kan aliasse wees vir dieselfde data wat nie aan die vasperkbeperkings onderhewig is nie:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Dit sou beteken dat die pointe nie weer kan beweeg nie.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // As `x` nou die enigste verwysing was, het ons 'n veranderlike verwysing na gegewens wat ons hierbo vasgepen het, wat ons kan gebruik om dit te skuif, soos ons in die vorige voorbeeld gesien het.
    ///     // Ons het die vasgestelde API-kontrak oortree.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Kry 'n vasgepen gedeelde verwysing vanaf hierdie vasgepen aanwyser.
    ///
    /// Dit is 'n generiese metode om van `&Pin<Pointer<T>>` na `Pin<&T>` te gaan.
    /// Dit is veilig, want as deel van die kontrak van `Pin::new_unchecked` kan die aanwyser nie beweeg nadat `Pin<Pointer<T>>` geskep is nie.
    ///
    /// "Malicious" implementasies van `Pointer::Deref` word ook uitgesluit deur die kontrak van `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // VEILIGHEID: sien dokumentasie oor hierdie funksie
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Pak hierdie `Pin<P>` uit om die onderliggende wyser terug te gee.
    ///
    /// # Safety
    ///
    /// Hierdie funksie is onveilig.U moet waarborg dat u die wyser `P` sal bly behandel soos vasgepen nadat u hierdie funksie genoem het, sodat die invariërs van die `Pin`-tipe gehandhaaf kan word.
    /// As die kode wat die resulterende `P` gebruik, nie die vasstaande invariërs onderhou nie, wat 'n oortreding van die API-kontrak is en kan lei tot ongedefinieerde gedrag in latere (safe)-bedrywighede.
    ///
    ///
    /// As die onderliggende data [`Unpin`] is, moet [`Pin::into_inner`] eerder gebruik word.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Kry 'n vasgestelde veranderlike verwysing vanaf hierdie vasgepen aanwyser.
    ///
    /// Dit is 'n generiese metode om van `&mut Pin<Pointer<T>>` na `Pin<&mut T>` te gaan.
    /// Dit is veilig, want as deel van die kontrak van `Pin::new_unchecked` kan die aanwyser nie beweeg nadat `Pin<Pointer<T>>` geskep is nie.
    ///
    /// "Malicious" implementasies van `Pointer::DerefMut` word ook uitgesluit deur die kontrak van `Pin::new_unchecked`.
    ///
    /// Hierdie metode is handig wanneer u verskeie oproepe doen na funksies wat die vasgepen tipe verbruik.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // doen iets
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` verbruik `self`, dus leen die `Pin<&mut Self>` via `as_mut` weer.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // VEILIGHEID: sien dokumentasie oor hierdie funksie
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Ken 'n nuwe waarde toe aan die geheue agter die vasgepen verwysing.
    ///
    /// Die vasgestelde data word oorskryf, maar dit is goed: die vernietiger daarvan word bestuur voordat dit oorskryf word, en dus word geen vaswaarborg oortree nie.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Konstrueer 'n nuwe pen deur die interieurwaarde te karteer.
    ///
    /// As u byvoorbeeld 'n `Pin` van 'n veld van iets wil kry, kan u dit gebruik om toegang tot daardie veld in een kode kode te kry.
    /// Daar is egter verskeie gotchas met hierdie "pinning projections";
    /// sien die [`pin` module]-dokumentasie vir nadere besonderhede oor die onderwerp.
    ///
    /// # Safety
    ///
    /// Hierdie funksie is onveilig.
    /// U moet waarborg dat die data wat u terugstuur nie sal beweeg nie solank die argumentwaarde nie beweeg nie (byvoorbeeld omdat dit een van die velde van die waarde is), en ook dat u nie uit die argument beweeg wat u ontvang nie. die interieurfunksie.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // VEILIGHEID: die veiligheidskontrak vir `new_unchecked` moet wees
        // deur die oproeper gehandhaaf word.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Kry 'n gedeelde verwysing uit 'n speld.
    ///
    /// Dit is veilig, want dit is nie moontlik om uit 'n gedeelde verwysing te beweeg nie.
    /// Dit kan lyk asof hier 'n probleem is met interieurveranderlikheid: dit is *moontlik* om 'n `T` uit 'n `&RefCell<T>` te skuif.
    /// Dit is egter nie 'n probleem nie, solank daar nie ook 'n `Pin<&T>` is wat na dieselfde data verwys nie, en `RefCell<T>` nie toelaat dat u 'n vasgepen verwysing na die inhoud daarvan skep nie.
    ///
    /// Kyk na die bespreking van ["pinning projections"] vir nadere besonderhede.
    ///
    /// Note: `Pin` implementeer ook `Deref` op die teiken, wat gebruik kan word om toegang tot die innerlike waarde te verkry.
    /// `Deref` bied egter net 'n verwysing wat so lank leef as die lening van die `Pin`, nie die leeftyd van die `Pin` self nie.
    /// Met hierdie metode kan u die `Pin` verander in 'n verwysing met dieselfde leeftyd as die oorspronklike `Pin`.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Verander hierdie `Pin<&mut T>` in 'n `Pin<&T>` met dieselfde leeftyd.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Kry 'n veranderlike verwysing na die data binne-in hierdie `Pin`.
    ///
    /// Dit vereis dat die data binne hierdie `Pin` `Unpin` is.
    ///
    /// Note: `Pin` implementeer ook `DerefMut` op die data, wat gebruik kan word om toegang tot die innerlike waarde te verkry.
    /// `DerefMut` bied egter net 'n verwysing wat so lank leef as die lening van die `Pin`, nie die leeftyd van die `Pin` self nie.
    ///
    /// Met hierdie metode kan u die `Pin` verander in 'n verwysing met dieselfde leeftyd as die oorspronklike `Pin`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Kry 'n veranderlike verwysing na die data binne-in hierdie `Pin`.
    ///
    /// # Safety
    ///
    /// Hierdie funksie is onveilig.
    /// U moet waarborg dat u die data nooit sal verwyder uit die veranderlike verwysing wat u ontvang wanneer u hierdie funksie noem nie, sodat die invariërs van die `Pin`-tipe gehandhaaf kan word.
    ///
    ///
    /// As die onderliggende data `Unpin` is, moet `Pin::get_mut` eerder gebruik word.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Konstrueer 'n nuwe pen deur die binnewaarde in kaart te bring.
    ///
    /// As u byvoorbeeld 'n `Pin` van 'n veld van iets wil kry, kan u dit gebruik om toegang tot daardie veld in een kode kode te kry.
    /// Daar is egter verskeie gotchas met hierdie "pinning projections";
    /// sien die [`pin` module]-dokumentasie vir nadere besonderhede oor die onderwerp.
    ///
    /// # Safety
    ///
    /// Hierdie funksie is onveilig.
    /// U moet waarborg dat die data wat u terugstuur nie sal beweeg nie solank die argumentwaarde nie beweeg nie (byvoorbeeld omdat dit een van die velde van die waarde is), en ook dat u nie uit die argument beweeg wat u ontvang nie. die interieurfunksie.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // VEILIGHEID: die oproeper is daarvoor verantwoordelik om nie die
        // waarde uit hierdie verwysing.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // VEILIGHEID: aangesien die waarde van `this` gewaarborg sal word
        // verwyder is, is hierdie oproep na `new_unchecked` veilig.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Kry 'n vasgestelde verwysing vanaf 'n statiese verwysing.
    ///
    /// Dit is veilig, want `T` word geleen vir die `'static`-leeftyd, wat nooit eindig nie.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // VEILIGHEID: Die 'statiese lening' waarborg dat die data nie sal wees nie
        // moved/invalidated totdat dit val (wat nooit is nie).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Kry 'n vasgestelde veranderlike verwysing uit 'n statiese veranderlike verwysing.
    ///
    /// Dit is veilig, want `T` word geleen vir die `'static`-leeftyd, wat nooit eindig nie.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // VEILIGHEID: Die 'statiese lening' waarborg dat die data nie sal wees nie
        // moved/invalidated totdat dit val (wat nooit is nie).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: dit beteken dat enige implantaat van `CoerceUnsized` wat dwang van kan toelaat
// 'n tipe wat `Deref<Target=impl !Unpin>` impls tot 'n tipe wat `Deref<Target=Unpin>` impls is onklank.
// Alhoewel sulke implikasies waarskynlik om ander redes ongesond sal wees, moet ons dus oppas dat sulke impls nie in std beland nie.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}