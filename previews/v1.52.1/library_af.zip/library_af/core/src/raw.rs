#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Bevat struktuurdefinisies vir die uitleg van ingeboude tipes samesteller.
//!
//! Dit kan gebruik word as teikens vir transmute in onveilige kode om die rou voorstellings direk te manipuleer.
//!
//!
//! Die definisie daarvan moet altyd ooreenstem met die ABI wat in `rustc_middle::ty::layout` gedefinieer is.
//!

/// Die voorstelling van 'n trait-voorwerp soos `&dyn SomeTrait`.
///
/// Hierdie struktuur het dieselfde uitleg as tipes soos `&dyn SomeTrait` en `Box<dyn AnotherTrait>`.
///
/// `TraitObject` Dit is gewaarborg dat dit ooreenstem met uitlegte, maar dit is nie die tipe trait-voorwerpe nie (bv. die velde is nie direk toeganklik op 'n `&dyn SomeTrait` nie) en beheer ook nie die uitleg nie (die verandering van die definisie sal nie die uitleg van 'n `&dyn SomeTrait` verander nie).
///
/// Dit is slegs ontwerp om gebruik te word deur onveilige kode wat die lae-vlak besonderhede moet manipuleer.
///
/// Daar is geen manier om generies na alle trait-voorwerpe te verwys nie, dus die enigste manier om waardes van hierdie tipe te skep, is met funksies soos [`std::mem::transmute`][transmute].
/// Net so is die enigste manier om 'n ware trait-voorwerp vanuit 'n `TraitObject`-waarde te skep, met `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Dit kan waarskynlik lei tot ongedefinieerde gedrag om 'n trait-voorwerp met nie-ooreenstemmende tipes te sintetiseer-een waar die vtabel nie ooreenstem met die tipe waarde waarop die datawyser wys nie.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // 'n voorbeeld trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // laat die samesteller 'n trait-voorwerp maak
/// let object: &dyn Foo = &value;
///
/// // kyk na die rou voorstelling
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // die datawyser is die adres van `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // konstrueer 'n nuwe voorwerp, wys na 'n ander `i32`, wees versigtig om die `i32`-tabel vanaf `object` te gebruik
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // dit moet werk asof ons 'n trait-voorwerp direk uit `other_value` gekonstrueer het
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}