//! Saamgestelde intrinsieke.
//!
//! Die ooreenstemmende definisies is in `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Die ooreenstemmende konst implementasies is in `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Konst. Intrinsieke
//!
//! Note: enige veranderinge aan die konstantheid van intrinsieke moet met die taalspan bespreek word.
//! Dit sluit veranderinge in die stabiliteit van die konstus in.
//!
//! Om 'n intrinsieke bruikbaar te maak tydens kompileringstyd, moet u die implementering van <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> na `compiler/rustc_mir/src/interpret/intrinsics.rs` kopieer en 'n `#[rustc_const_unstable(feature = "foo", issue = "01234")]` by die intrinsieke voeg.
//!
//!
//! As 'n intrinsieke veronderstel is om vanaf 'n `const fn` met 'n `rustc_const_stable`-eienskap te gebruik, moet die attribuut van die intrinsieke ook `rustc_const_stable` wees.
//! So 'n verandering moet nie sonder T-lang-raadpleging gedoen word nie, omdat dit 'n funksie in die taal bak wat nie in die gebruikerskode kan herhaal word sonder ondersteuning van die samesteller nie.
//!
//! # Volatiles
//!
//! Die vlugtige intrinsics bied bedrywighede wat bedoel is om op die I/O-geheue in te werk, wat verseker word dat die samesteller dit nie in ander vlugtige intrinsieke herbestel nie.Sien die LLVM-dokumentasie op [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Die atoomintrinsieke bied algemene atoombewerkings op masjienwoorde, met veelvuldige geheue-ordenings.Hulle hou dieselfde semantiek as C++ 11.Sien die LLVM-dokumentasie op [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! 'N Vinnige opknapping van geheuebestelling:
//!
//! * Verkry, 'n hindernis vir die verkryging van 'n slot.Daaropvolgende lees en skryf vind plaas na die versperring.
//! * Loslating, 'n versperring om 'n slot vry te laat.Voorafgaande lees en skryf vind voor die versperring plaas.
//! * Opeenvolgende konsekwente, opeenvolgende konsekwensies sal gewaarborg word in orde.Dit is die standaardmodus om met atoomtipes te werk en is gelykstaande aan Java se `volatile`.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Hierdie invoer word gebruik om intra-doc-skakels te vereenvoudig
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // VEILIGHEID: sien `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // Let wel: hierdie intrinsieke gebruik rou aanwysings omdat dit die geheue wat verander, wat nie geldig is vir `&` of `&mut`, muteer nie.
    //

    /// Stoor 'n waarde as die huidige waarde dieselfde is as die `old`-waarde.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `compare_exchange`-metode deur [`Ordering::SeqCst`] as die `success`-en `failure`-parameters deur te gee.
    ///
    /// Byvoorbeeld, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stoor 'n waarde as die huidige waarde dieselfde is as die `old`-waarde.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `compare_exchange`-metode deur [`Ordering::Acquire`] as die `success`-en `failure`-parameters deur te gee.
    ///
    /// Byvoorbeeld, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stoor 'n waarde as die huidige waarde dieselfde is as die `old`-waarde.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `compare_exchange`-metode deur [`Ordering::Release`] as die `success` en [`Ordering::Relaxed`] as die `failure`-parameters deur te gee.
    /// Byvoorbeeld, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stoor 'n waarde as die huidige waarde dieselfde is as die `old`-waarde.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `compare_exchange`-metode deur [`Ordering::AcqRel`] as die `success` en [`Ordering::Acquire`] as die `failure`-parameters deur te gee.
    /// Byvoorbeeld, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stoor 'n waarde as die huidige waarde dieselfde is as die `old`-waarde.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `compare_exchange`-metode deur [`Ordering::Relaxed`] as die `success`-en `failure`-parameters deur te gee.
    ///
    /// Byvoorbeeld, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stoor 'n waarde as die huidige waarde dieselfde is as die `old`-waarde.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `compare_exchange`-metode deur [`Ordering::SeqCst`] as die `success` en [`Ordering::Relaxed`] as die `failure`-parameters deur te gee.
    /// Byvoorbeeld, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stoor 'n waarde as die huidige waarde dieselfde is as die `old`-waarde.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `compare_exchange`-metode deur [`Ordering::SeqCst`] as die `success` en [`Ordering::Acquire`] as die `failure`-parameters deur te gee.
    /// Byvoorbeeld, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stoor 'n waarde as die huidige waarde dieselfde is as die `old`-waarde.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `compare_exchange`-metode deur [`Ordering::Acquire`] as die `success` en [`Ordering::Relaxed`] as die `failure`-parameters deur te gee.
    /// Byvoorbeeld, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stoor 'n waarde as die huidige waarde dieselfde is as die `old`-waarde.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `compare_exchange`-metode deur [`Ordering::AcqRel`] as die `success` en [`Ordering::Relaxed`] as die `failure`-parameters deur te gee.
    /// Byvoorbeeld, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Stoor 'n waarde as die huidige waarde dieselfde is as die `old`-waarde.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `compare_exchange_weak`-metode deur [`Ordering::SeqCst`] as die `success`-en `failure`-parameters deur te gee.
    ///
    /// Byvoorbeeld, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stoor 'n waarde as die huidige waarde dieselfde is as die `old`-waarde.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `compare_exchange_weak`-metode deur [`Ordering::Acquire`] as die `success`-en `failure`-parameters deur te gee.
    ///
    /// Byvoorbeeld, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stoor 'n waarde as die huidige waarde dieselfde is as die `old`-waarde.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `compare_exchange_weak`-metode deur [`Ordering::Release`] as die `success` en [`Ordering::Relaxed`] as die `failure`-parameters deur te gee.
    /// Byvoorbeeld, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stoor 'n waarde as die huidige waarde dieselfde is as die `old`-waarde.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `compare_exchange_weak`-metode deur [`Ordering::AcqRel`] as die `success` en [`Ordering::Acquire`] as die `failure`-parameters deur te gee.
    /// Byvoorbeeld, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stoor 'n waarde as die huidige waarde dieselfde is as die `old`-waarde.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `compare_exchange_weak`-metode deur [`Ordering::Relaxed`] as die `success`-en `failure`-parameters deur te gee.
    ///
    /// Byvoorbeeld, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stoor 'n waarde as die huidige waarde dieselfde is as die `old`-waarde.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `compare_exchange_weak`-metode deur [`Ordering::SeqCst`] as die `success` en [`Ordering::Relaxed`] as die `failure`-parameters deur te gee.
    /// Byvoorbeeld, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stoor 'n waarde as die huidige waarde dieselfde is as die `old`-waarde.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `compare_exchange_weak`-metode deur [`Ordering::SeqCst`] as die `success` en [`Ordering::Acquire`] as die `failure`-parameters deur te gee.
    /// Byvoorbeeld, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stoor 'n waarde as die huidige waarde dieselfde is as die `old`-waarde.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `compare_exchange_weak`-metode deur [`Ordering::Acquire`] as die `success` en [`Ordering::Relaxed`] as die `failure`-parameters deur te gee.
    /// Byvoorbeeld, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stoor 'n waarde as die huidige waarde dieselfde is as die `old`-waarde.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `compare_exchange_weak`-metode deur [`Ordering::AcqRel`] as die `success` en [`Ordering::Relaxed`] as die `failure`-parameters deur te gee.
    /// Byvoorbeeld, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Laai die huidige waarde van die wyser.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `load`-metode deur [`Ordering::SeqCst`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Laai die huidige waarde van die wyser.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `load`-metode deur [`Ordering::Acquire`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Laai die huidige waarde van die wyser.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `load`-metode deur [`Ordering::Relaxed`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Stoor die waarde op die gespesifiseerde geheueplek.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `store`-metode deur [`Ordering::SeqCst`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Stoor die waarde op die gespesifiseerde geheueplek.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `store`-metode deur [`Ordering::Release`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Stoor die waarde op die gespesifiseerde geheueplek.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `store`-metode deur [`Ordering::Relaxed`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Stoor die waarde op die gespesifiseerde geheueplek en gee die ou waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `swap`-metode deur [`Ordering::SeqCst`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Stoor die waarde op die gespesifiseerde geheueplek en gee die ou waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `swap`-metode deur [`Ordering::Acquire`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Stoor die waarde op die gespesifiseerde geheueplek en gee die ou waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `swap`-metode deur [`Ordering::Release`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Stoor die waarde op die gespesifiseerde geheueplek en gee die ou waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `swap`-metode deur [`Ordering::AcqRel`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Stoor die waarde op die gespesifiseerde geheueplek en gee die ou waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `swap`-metode deur [`Ordering::Relaxed`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Voeg by die huidige waarde en gee die vorige waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `fetch_add`-metode deur [`Ordering::SeqCst`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Voeg by die huidige waarde en gee die vorige waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `fetch_add`-metode deur [`Ordering::Acquire`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Voeg by die huidige waarde en gee die vorige waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `fetch_add`-metode deur [`Ordering::Release`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Voeg by die huidige waarde en gee die vorige waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `fetch_add`-metode deur [`Ordering::AcqRel`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Voeg by die huidige waarde en gee die vorige waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `fetch_add`-metode deur [`Ordering::Relaxed`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Trek van die huidige waarde af en gee die vorige waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `fetch_sub`-metode deur [`Ordering::SeqCst`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Trek van die huidige waarde af en gee die vorige waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `fetch_sub`-metode deur [`Ordering::Acquire`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Trek van die huidige waarde af en gee die vorige waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `fetch_sub`-metode deur [`Ordering::Release`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Trek van die huidige waarde af en gee die vorige waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `fetch_sub`-metode deur [`Ordering::AcqRel`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Trek van die huidige waarde af en gee die vorige waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `fetch_sub`-metode deur [`Ordering::Relaxed`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitgewys en met die huidige waarde, gee die vorige waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `fetch_and`-metode deur [`Ordering::SeqCst`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitgewys en met die huidige waarde, gee die vorige waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `fetch_and`-metode deur [`Ordering::Acquire`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitgewys en met die huidige waarde, gee die vorige waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `fetch_and`-metode deur [`Ordering::Release`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitgewys en met die huidige waarde, gee die vorige waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `fetch_and`-metode deur [`Ordering::AcqRel`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitgewys en met die huidige waarde, gee die vorige waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `fetch_and`-metode deur [`Ordering::Relaxed`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwys nand met die huidige waarde, en gee die vorige waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`AtomicBool`]-tipe via die `fetch_nand`-metode deur [`Ordering::SeqCst`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwys nand met die huidige waarde, en gee die vorige waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`AtomicBool`]-tipe via die `fetch_nand`-metode deur [`Ordering::Acquire`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwys nand met die huidige waarde, en gee die vorige waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`AtomicBool`]-tipe via die `fetch_nand`-metode deur [`Ordering::Release`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwys nand met die huidige waarde, en gee die vorige waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`AtomicBool`]-tipe via die `fetch_nand`-metode deur [`Ordering::AcqRel`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwys nand met die huidige waarde, en gee die vorige waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`AtomicBool`]-tipe via die `fetch_nand`-metode deur [`Ordering::Relaxed`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitvis of met die huidige waarde, en gee die vorige waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `fetch_or`-metode deur [`Ordering::SeqCst`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis of met die huidige waarde, en gee die vorige waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `fetch_or`-metode deur [`Ordering::Acquire`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis of met die huidige waarde, en gee die vorige waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `fetch_or`-metode deur [`Ordering::Release`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis of met die huidige waarde, en gee die vorige waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `fetch_or`-metode deur [`Ordering::AcqRel`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis of met die huidige waarde, en gee die vorige waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `fetch_or`-metode deur [`Ordering::Relaxed`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitvis x of met die huidige waarde, en gee die vorige waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `fetch_xor`-metode deur [`Ordering::SeqCst`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis x of met die huidige waarde, en gee die vorige waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `fetch_xor`-metode deur [`Ordering::Acquire`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis x of met die huidige waarde, en gee die vorige waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `fetch_xor`-metode deur [`Ordering::Release`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis x of met die huidige waarde, en gee die vorige waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `fetch_xor`-metode deur [`Ordering::AcqRel`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis x of met die huidige waarde, en gee die vorige waarde terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-tipes via die `fetch_xor`-metode deur [`Ordering::Relaxed`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maksimum met die huidige waarde met behulp van 'n getekende vergelyking.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-getalgetalgetalle via die `fetch_max`-metode deur [`Ordering::SeqCst`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum met die huidige waarde met behulp van 'n getekende vergelyking.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-getalgetalgetalle via die `fetch_max`-metode deur [`Ordering::Acquire`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum met die huidige waarde met behulp van 'n getekende vergelyking.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-getalgetalgetalle via die `fetch_max`-metode deur [`Ordering::Release`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum met die huidige waarde met behulp van 'n getekende vergelyking.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-getalgetalgetalle via die `fetch_max`-metode deur [`Ordering::AcqRel`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum met die huidige waarde.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-getalgetalgetalle via die `fetch_max`-metode deur [`Ordering::Relaxed`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum met die huidige waarde met behulp van 'n getekende vergelyking.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-getalgetalgetalle via die `fetch_min`-metode deur [`Ordering::SeqCst`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum met die huidige waarde met behulp van 'n getekende vergelyking.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-getalgetalgetalle via die `fetch_min`-metode deur [`Ordering::Acquire`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum met die huidige waarde met behulp van 'n getekende vergelyking.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-getalgetalgetalle via die `fetch_min`-metode deur [`Ordering::Release`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum met die huidige waarde met behulp van 'n getekende vergelyking.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-getalgetalgetalle via die `fetch_min`-metode deur [`Ordering::AcqRel`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum met die huidige waarde met behulp van 'n getekende vergelyking.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`]-getalgetalgetalle via die `fetch_min`-metode deur [`Ordering::Relaxed`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum met die huidige waarde met 'n ongetekende vergelyking.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`] ongetekende heelgetal-tipes via die `fetch_min`-metode deur [`Ordering::SeqCst`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum met die huidige waarde met 'n ongetekende vergelyking.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`] ongetekende heelgetal-tipes via die `fetch_min`-metode deur [`Ordering::Acquire`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum met die huidige waarde met 'n ongetekende vergelyking.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`] ongetekende heelgetal-tipes via die `fetch_min`-metode deur [`Ordering::Release`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum met die huidige waarde met 'n ongetekende vergelyking.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`] ongetekende heelgetal-tipes via die `fetch_min`-metode deur [`Ordering::AcqRel`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum met die huidige waarde met 'n ongetekende vergelyking.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`] ongetekende heelgetal-tipes via die `fetch_min`-metode deur [`Ordering::Relaxed`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maksimum met die huidige waarde met 'n ongetekende vergelyking.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`] ongetekende heelgetal-tipes via die `fetch_max`-metode deur [`Ordering::SeqCst`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum met die huidige waarde met 'n ongetekende vergelyking.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`] ongetekende heelgetal-tipes via die `fetch_max`-metode deur [`Ordering::Acquire`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum met die huidige waarde met 'n ongetekende vergelyking.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`] ongetekende heelgetal-tipes via die `fetch_max`-metode deur [`Ordering::Release`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum met die huidige waarde met 'n ongetekende vergelyking.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`] ongetekende heelgetal-tipes via die `fetch_max`-metode deur [`Ordering::AcqRel`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum met die huidige waarde met 'n ongetekende vergelyking.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar op die [`atomic`] ongetekende heelgetal-tipes via die `fetch_max`-metode deur [`Ordering::Relaxed`] as die `order` deur te gee.
    /// Byvoorbeeld, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Die `prefetch`-intrinsiek is 'n wenk vir die kodegenerator om 'n vooraf-ophaalinstruksie in te voeg indien dit ondersteun word;anders is dit 'n no-op.
    /// Voorafhalings het geen invloed op die gedrag van die program nie, maar kan die prestasie-eienskappe daarvan verander.
    ///
    /// Die `locality`-argument moet 'n konstante heelgetal wees en is 'n tydelike lokaliteitspesifiser wat wissel van (0), geen ligging, tot (3), uiters plaaslike bewaring.
    ///
    ///
    /// Hierdie intrinsieke het nie 'n stabiele eweknie nie.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Die `prefetch`-intrinsiek is 'n wenk vir die kodegenerator om 'n vooraf-ophaalinstruksie in te voeg indien dit ondersteun word;anders is dit 'n no-op.
    /// Voorafhalings het geen invloed op die gedrag van die program nie, maar kan die prestasie-eienskappe daarvan verander.
    ///
    /// Die `locality`-argument moet 'n konstante heelgetal wees en is 'n tydelike lokaliteitspesifiser wat wissel van (0), geen ligging, tot (3), uiters plaaslike bewaring.
    ///
    ///
    /// Hierdie intrinsieke het nie 'n stabiele eweknie nie.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Die `prefetch`-intrinsiek is 'n wenk vir die kodegenerator om 'n vooraf-ophaalinstruksie in te voeg indien dit ondersteun word;anders is dit 'n no-op.
    /// Voorafhalings het geen invloed op die gedrag van die program nie, maar kan die prestasie-eienskappe daarvan verander.
    ///
    /// Die `locality`-argument moet 'n konstante heelgetal wees en is 'n tydelike lokaliteitspesifiser wat wissel van (0), geen ligging, tot (3), uiters plaaslike bewaring.
    ///
    ///
    /// Hierdie intrinsieke het nie 'n stabiele eweknie nie.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Die `prefetch`-intrinsiek is 'n wenk vir die kodegenerator om 'n vooraf-ophaalinstruksie in te voeg indien dit ondersteun word;anders is dit 'n no-op.
    /// Voorafhalings het geen invloed op die gedrag van die program nie, maar kan die prestasie-eienskappe daarvan verander.
    ///
    /// Die `locality`-argument moet 'n konstante heelgetal wees en is 'n tydelike lokaliteitspesifiser wat wissel van (0), geen ligging, tot (3), uiters plaaslike bewaring.
    ///
    ///
    /// Hierdie intrinsieke het nie 'n stabiele eweknie nie.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// 'N Atoomheining.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar in [`atomic::fence`] deur [`Ordering::SeqCst`] as die `order` deur te gee.
    ///
    ///
    pub fn atomic_fence();
    /// 'N Atoomheining.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar in [`atomic::fence`] deur [`Ordering::Acquire`] as die `order` deur te gee.
    ///
    ///
    pub fn atomic_fence_acq();
    /// 'N Atoomheining.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar in [`atomic::fence`] deur [`Ordering::Release`] as die `order` deur te gee.
    ///
    ///
    pub fn atomic_fence_rel();
    /// 'N Atoomheining.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar in [`atomic::fence`] deur [`Ordering::AcqRel`] as die `order` oor te dra.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// 'N Geheueversperring wat slegs vir samesteller gebruik word.
    ///
    /// Die samesteller sal nooit toegang tot geheue-toegang oor hierdie versperring herorden nie, maar daar sal geen instruksies daarvoor uitgestuur word nie.
    /// Dit is geskik vir bedrywighede op dieselfde draad wat voorgesit kan word, soos wanneer u met seinhanteerders kommunikeer.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar in [`atomic::compiler_fence`] deur [`Ordering::SeqCst`] as die `order` deur te gee.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// 'N Geheueversperring wat slegs vir samesteller gebruik word.
    ///
    /// Die samesteller sal nooit toegang tot geheue-toegang oor hierdie versperring herorden nie, maar daar sal geen instruksies daarvoor uitgestuur word nie.
    /// Dit is geskik vir bedrywighede op dieselfde draad wat voorgesit kan word, soos wanneer u met seinhanteerders kommunikeer.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar in [`atomic::compiler_fence`] deur [`Ordering::Acquire`] as die `order` deur te gee.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// 'N Geheueversperring wat slegs vir samesteller gebruik word.
    ///
    /// Die samesteller sal nooit toegang tot geheue-toegang oor hierdie versperring herorden nie, maar daar sal geen instruksies daarvoor uitgestuur word nie.
    /// Dit is geskik vir bedrywighede op dieselfde draad wat voorgesit kan word, soos wanneer u met seinhanteerders kommunikeer.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar in [`atomic::compiler_fence`] deur [`Ordering::Release`] as die `order` oor te dra.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// 'N Geheueversperring wat slegs vir samesteller gebruik word.
    ///
    /// Die samesteller sal nooit toegang tot geheue-toegang oor hierdie versperring herorden nie, maar daar sal geen instruksies daarvoor uitgestuur word nie.
    /// Dit is geskik vir bedrywighede op dieselfde draad wat voorgesit kan word, soos wanneer u met seinhanteerders kommunikeer.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is beskikbaar in [`atomic::compiler_fence`] deur [`Ordering::AcqRel`] as die `order` deur te gee.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Magiese intrinsiek wat sy betekenis ontleen aan eienskappe verbonde aan die funksie.
    ///
    /// Dataflow gebruik dit byvoorbeeld om statiese bewerings in te spuit, sodat `rustc_peek(potentially_uninitialized)` eintlik sou kontroleer of die datavloei inderdaad bereken het dat dit op daardie stadium in die kontrolevloei nie geïnisialiseer is nie.
    ///
    ///
    /// Hierdie intrinsieke moet nie buite die samesteller gebruik word nie.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Staak die uitvoering van die proses.
    ///
    /// 'N Meer gebruikersvriendelike en stabiele weergawe van hierdie bewerking is [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Stel die optimaliseerder in kennis dat hierdie punt in die kode nie bereik kan word nie, wat verdere optimalisering moontlik maak.
    ///
    /// Let wel, dit verskil baie van die `unreachable!()`-makro: In teenstelling met die makro wat panics is wanneer dit uitgevoer word, is dit *ongedefinieerde gedrag* om die kode te bereik wat met hierdie funksie gemerk is.
    ///
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Stel die optimaliseerder in kennis dat 'n voorwaarde altyd waar is.
    /// As die toestand onwaar is, is die gedrag ongedefinieerd.
    ///
    /// Geen kode word vir hierdie intrinsieke gegenereer nie, maar die optimaliseerder sal probeer om dit (en die toestand daarvan) tussen passe te bewaar, wat die optimalisering van die omliggende kode kan beïnvloed en die prestasie kan verminder.
    /// Dit moet nie gebruik word as die invariant op sigself deur die optimizer ontdek kan word nie, of as dit geen beduidende optimalisering moontlik maak nie.
    ///
    /// Hierdie intrinsieke het nie 'n stabiele eweknie nie.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Wenke aan die samesteller dat die toestand van branch waarskynlik waar sal wees.
    /// Wys die waarde wat daaraan oorgedra is.
    ///
    /// Enige gebruik anders as met `if`-stellings sal waarskynlik nie 'n effek hê nie.
    ///
    /// Hierdie intrinsieke het nie 'n stabiele eweknie nie.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Wenke aan die samesteller dat die toestand van branch waarskynlik onwaar sal wees.
    /// Wys die waarde wat daaraan oorgedra is.
    ///
    /// Enige gebruik anders as met `if`-stellings sal waarskynlik nie 'n effek hê nie.
    ///
    /// Hierdie intrinsieke het nie 'n stabiele eweknie nie.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Voer 'n breekpuntval uit vir inspeksie deur 'n ontfouter.
    ///
    /// Hierdie intrinsieke het nie 'n stabiele eweknie nie.
    pub fn breakpoint();

    /// Die grootte van 'n tipe in grepe.
    ///
    /// Meer spesifiek, dit is die verrekening in grepe tussen opeenvolgende items van dieselfde tipe, insluitend die opstelling van die vulling.
    ///
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Die minimum belyning van 'n tipe.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Die voorkeurbelyning van 'n tipe.
    ///
    /// Hierdie intrinsieke het nie 'n stabiele eweknie nie.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Die grootte van die verwysde waarde in grepe.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Die vereiste belyning van die verwysde waarde.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Kry 'n statiese snysnit wat die naam van 'n tipe bevat.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Kry 'n identifiseerder wat wêreldwyd uniek is aan die gespesifiseerde tipe.
    /// Hierdie funksie sal dieselfde waarde vir 'n tipe oplewer, ongeag in watter crate dit gebruik word.
    ///
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// 'N Bewaker vir onveilige funksies wat nooit uitgevoer kan word as `T` onbewoon is nie:
    /// Dit sal staties óf panic óf niks doen nie.
    ///
    /// Hierdie intrinsieke het nie 'n stabiele eweknie nie.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// 'N Bewaker vir onveilige funksies wat nooit uitgevoer kan word as `T` nie nulinitialisering toelaat nie: dit sal staties óf panic óf niks doen nie.
    ///
    ///
    /// Hierdie intrinsieke het nie 'n stabiele eweknie nie.
    pub fn assert_zero_valid<T>();

    /// 'N Bewaker vir onveilige funksies wat nooit uitgevoer kan word as `T` ongeldige bispatrone het nie: dit sal staties panic, of niks doen nie.
    ///
    ///
    /// Hierdie intrinsieke het nie 'n stabiele eweknie nie.
    pub fn assert_uninit_valid<T>();

    /// Kry 'n verwysing na 'n statiese `Location` wat aandui waar dit genoem word.
    ///
    /// Oorweeg dit om [`core::panic::Location::caller`](crate::panic::Location::caller) eerder te gebruik.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Beweeg 'n waarde buite die omvang sonder om druppelgom te laat loop.
    ///
    /// Dit bestaan slegs vir [`mem::forget_unsized`];normale `forget` gebruik eerder `ManuallyDrop`.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Herinterpreteer die stukkies van 'n waarde van een tipe as 'n ander tipe.
    ///
    /// Albei soorte moet ewe groot wees.
    /// Nóg die oorspronklike, nóg die resultaat, mag 'n [invalid value](../../nomicon/what-unsafe-does.html) wees nie.
    ///
    /// `transmute` is semanties gelykstaande aan 'n bitwyse skuif van een tipe na 'n ander.Dit kopieer die stukkies van die bronwaarde na die bestemmingswaarde en vergeet dan die oorspronklike.
    /// Dit is gelykstaande aan C se `memcpy` onder die enjinkap, net soos `transmute_copy`.
    ///
    /// Aangesien `transmute` 'n bywaarde is, is die belyning van die *getransmuteerde waardes* ook geen probleem nie.
    /// Soos met enige ander funksie, verseker die samesteller dat beide `T` en `U` behoorlik in lyn is.
    /// Wanneer waardes wat *elders heen* verwys (soos aanwysers, verwysings, blokkies, ...), moet die beller egter sorg dat die gewysigde waardes behoorlik in lyn gebring word.
    ///
    /// `transmute` is **ongelooflik** onveilig.Daar is 'n groot aantal maniere om [undefined behavior][ub] met hierdie funksie te veroorsaak.`transmute` moet die absolute laaste uitweg wees.
    ///
    /// Die [nomicon](../../nomicon/transmutes.html) het addisionele dokumentasie.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Daar is 'n paar dinge waarvoor `transmute` baie nuttig is.
    ///
    /// Omskep van 'n wyser in 'n funksie-wyser.Dit is *nie* draagbaar vir masjiene waar funksiewysers en datawysers verskillende groottes het nie.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Die verlenging van 'n leeftyd, of die verkorting van 'n onveranderlike leeftyd.Dit is gevorderd, baie onveilig Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Moet nie wanhoop nie: baie gebruike van `transmute` kan op ander maniere bereik word.
    /// Hieronder is algemene toepassings van `transmute` wat met veiliger konstruksies vervang kan word.
    ///
    /// Verander rou bytes(`&[u8]`) na `u32`, `f64`, ens:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // gebruik eerder `u32::from_ne_bytes`
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // of gebruik `u32::from_le_bytes` of `u32::from_be_bytes` om die eindigheid te spesifiseer
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Om van 'n aanwyser 'n `usize` te maak:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Gebruik eerder 'n `as`-rolverdeling
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Om 'n `*mut T` in 'n `&mut T` te maak:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Gebruik eerder 'n herlaai
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Om 'n `&mut T` in 'n `&mut U` te maak:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Stel nou `as` bymekaar en herontlenend, let op dat die ketting van `as` `as` nie van oorgang is nie
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Om 'n `&str` in 'n `&[u8]` te maak:
    ///
    /// ```
    /// // dit is nie 'n goeie manier om dit te doen nie.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // U kan `str::as_bytes` gebruik
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Of gebruik net 'n byte-string as u beheer het oor die letterlike string
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Omskep 'n `Vec<&T>` in 'n `Vec<Option<&T>>`.
    ///
    /// Om die binneste tipe inhoud van 'n houer te transformeer, moet u seker maak dat u nie enige van die houers se invariërs oortree nie.
    /// Vir `Vec` beteken dit dat die grootte *en die belyning* van die binneste tipes moet ooreenstem.
    /// Ander houers kan afhang van die grootte van die tipe, die belyning of selfs die `TypeId`, in welke geval transmissie glad nie moontlik sou wees sonder om die houer-invariërs te oortree nie.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // kloon die vector aangesien ons dit later weer sal gebruik
    /// let v_clone = v_orig.clone();
    ///
    /// // Met behulp van transmute: dit berus op die ongespesifiseerde data-uitleg van `Vec`, wat 'n slegte idee is en wat ongedefinieerde gedrag kan veroorsaak.
    /////
    /// // Dit is egter geen kopie nie.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Dit is die voorgestelde, veilige manier.
    /// // Dit kopieer die hele vector egter in 'n nuwe skikking.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Dit is die regte kopie, onveilige manier van "transmuting" en `Vec`, sonder om op die data-uitleg te vertrou.
    /// // In plaas daarvan om `transmute` letterlik te noem, voer ons 'n pointer cast uit, maar in terme van die omskakeling van die oorspronklike binnetipe (`&i32`) na die nuwe (`Option<&i32>`), het dit dieselfde voorbehoud.
    /////
    /// // Behalwe die inligting hierbo, raadpleeg ook die [`from_raw_parts`]-dokumentasie.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Update dit wanneer vec_into_raw_parts gestabiliseer is.
    ///     // Verseker dat die oorspronklike vector nie val nie.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Implementering van `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Daar is verskeie maniere om dit te doen, en daar is verskeie probleme met die volgende (transmute)-manier.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // eerstens: transmute is nie tipe veilig nie;al wat dit nagaan, is dat T en
    ///         // U is dieselfde grootte.
    ///         // Tweedens, hier het u twee veranderlike verwysings wat op dieselfde geheue wys.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Dit raak ontslae van die tipe veiligheidsprobleme;`&mut *` gee u* slegs *'n `&mut T` vanaf 'n `&mut T` of `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // u het egter steeds twee veranderlike verwysings wat na dieselfde geheue verwys.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Dit is hoe die standaardbiblioteek dit doen.
    /// // Dit is die beste metode as u so iets moet doen
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Dit het nou drie veranderlike verwysings wat op dieselfde geheue wys.`slice`, die rwaarde ret.0, en die rvalue ret.1.
    ///         // `slice` word nooit na `let ptr = ...` gebruik nie, en daarom kan 'n mens dit as "dead" behandel, en daarom het jy net twee regte veranderlike snye.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Alhoewel dit die intrinsieke konst stabiel maak, het ons 'n paar persoonlike kode in const fn
    // tjeks wat die gebruik daarvan binne `const fn` voorkom.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Wys `true` as die werklike tipe wat as `T` aangegee is, druppellym benodig;gee `false` terug as die werklike tipe wat vir `T` voorsien word, `Copy` implementeer.
    ///
    ///
    /// As die werklike tipe nie drop gom benodig of `Copy` implementeer nie, is die terugkeerwaarde van hierdie funksie nie gespesifiseer nie.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Bereken die verrekening vanaf 'n wyser.
    ///
    /// Dit word geïmplementeer as 'n intrinsieke doel om te verhoed dat die omskakeling na en van 'n heelgetal, aangesien die omskakeling aliasing-inligting weggooi.
    ///
    /// # Safety
    ///
    /// Beide die begin-en resulterende wyser moet binne perke of een byte aan die einde van 'n toegekende voorwerp wees.
    /// As een van die wysers buite perke is of as rekenkundige oorloop voorkom, sal enige verdere gebruik van die teruggekeerde waarde lei tot ongedefinieerde gedrag.
    ///
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Bereken die verrekening vanaf 'n aanwyser, moontlik omwikkeling.
    ///
    /// Dit word geïmplementeer as 'n intrinsieke omskakeling na en van 'n heelgetal te vermy, aangesien die omskakeling sekere optimalisering belemmer.
    ///
    /// # Safety
    ///
    /// In teenstelling met die `offset`-intrinsieke, beperk hierdie intrinsieke nie die resulterende wyser om na die punt van 'n toegekende voorwerp in of een byte te wys nie, en dit word met die rekenkundige rekenkunde van twee toegedraai.
    /// Die resulterende waarde is nie noodwendig geldig om gebruik te word om toegang tot die geheue te verkry nie.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Ekwivalent aan die toepaslike `llvm.memcpy.p0i8.0i8.*`-intrinsieke, met 'n grootte van `count`*`size_of::<T>()` en 'n belyning van
    ///
    /// `min_align_of::<T>()`
    ///
    /// Die vlugtige parameter is ingestel op `true`, dus word dit nie geoptimaliseer nie, tensy die grootte gelyk is aan nul.
    ///
    /// Hierdie intrinsieke het nie 'n stabiele eweknie nie.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Ekwivalent aan die toepaslike `llvm.memmove.p0i8.0i8.*` intrinsieke, met 'n grootte van `count* size_of::<T>()` en 'n belyning van
    ///
    /// `min_align_of::<T>()`
    ///
    /// Die vlugtige parameter is ingestel op `true`, dus word dit nie geoptimaliseer nie, tensy die grootte gelyk is aan nul.
    ///
    /// Hierdie intrinsieke het nie 'n stabiele eweknie nie.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Ekwivalent aan die toepaslike `llvm.memset.p0i8.*`-intrinsieke, met 'n grootte van `count* size_of::<T>()` en 'n belyning van `min_align_of::<T>()`.
    ///
    ///
    /// Die vlugtige parameter is ingestel op `true`, dus word dit nie geoptimaliseer nie, tensy die grootte gelyk is aan nul.
    ///
    /// Hierdie intrinsieke het nie 'n stabiele eweknie nie.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Voer 'n vlugtige lading vanaf die `src`-wyser.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Voer 'n vlugtige winkel na die `dst`-wyser uit.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Voer 'n vlugtige las vanaf die `src`-wyser. Die wyser hoef nie in lyn te wees nie.
    ///
    ///
    /// Hierdie intrinsieke het nie 'n stabiele eweknie nie.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Voer 'n vlugtige winkel na die `dst`-wyser uit.
    /// Die wyser hoef nie in lyn te wees nie.
    ///
    /// Hierdie intrinsieke het nie 'n stabiele eweknie nie.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Wys die vierkantswortel van 'n `f32`
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Wys die vierkantswortel van 'n `f64`
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Verhoog 'n `f32` tot 'n heelgetal krag.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Verhoog 'n `f64` na 'n heelgetal krag.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Wys die sinus van 'n `f32`.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Wys die sinus van 'n `f64`.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Wys die kosinus van 'n `f32`.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Wys die kosinus van 'n `f64`.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Verhoog 'n `f32` na 'n `f32`-krag.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Verhoog 'n `f64` na 'n `f64`-krag.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Wys die eksponensiaal van 'n `f32`.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Wys die eksponensiaal van 'n `f64`.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Opbrengste 2 verhoog tot die krag van 'n `f32`.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Opbrengste 2 verhoog tot die krag van 'n `f64`.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Wys die natuurlike logaritme van 'n `f32`.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Wys die natuurlike logaritme van 'n `f64`.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Wys die basis 10 logaritme van 'n `f32`.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Wys die basis 10 logaritme van 'n `f64`.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Wys die basis 2-logaritme van 'n `f32`.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Wys die basis 2-logaritme van 'n `f64`.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Wys `a * b + c` vir `f32`-waardes.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Wys `a * b + c` vir `f64`-waardes.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Wys die absolute waarde van 'n `f32`.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Wys die absolute waarde van 'n `f64`.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Wys die minimum van twee `f32`-waardes.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Wys die minimum van twee `f64`-waardes.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Wys die maksimum van twee `f32`-waardes.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Wys die maksimum van twee `f64`-waardes.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Kopieer die teken van `y` na `x` vir `f32`-waardes.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Kopieer die teken van `y` na `x` vir `f64`-waardes.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Wys die grootste heelgetal kleiner as of gelyk aan 'n `f32`.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Wys die grootste heelgetal kleiner as of gelyk aan 'n `f64`.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Wys die kleinste heelgetal groter as of gelyk aan 'n `f32`.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Wys die kleinste heelgetal groter as of gelyk aan 'n `f64`.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Wys die heelgetal van 'n `f32`.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Wys die heelgetal van 'n `f64`.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Wys die naaste heelgetal van 'n `f32`.
    /// Kan 'n onakkurate uitsondering op drywingspunt maak as die argument nie 'n heelgetal is nie.
    pub fn rintf32(x: f32) -> f32;
    /// Wys die naaste heelgetal van 'n `f64`.
    /// Kan 'n onakkurate uitsondering op drywingspunt maak as die argument nie 'n heelgetal is nie.
    pub fn rintf64(x: f64) -> f64;

    /// Wys die naaste heelgetal van 'n `f32`.
    ///
    /// Hierdie intrinsieke het nie 'n stabiele eweknie nie.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Wys die naaste heelgetal van 'n `f64`.
    ///
    /// Hierdie intrinsieke het nie 'n stabiele eweknie nie.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Wys die naaste heelgetal van 'n `f32`.Rond halwe sake weg van nul af.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Wys die naaste heelgetal van 'n `f64`.Rond halwe sake weg van nul.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Float toevoeging wat optimasies moontlik maak op grond van algebraïese reëls.
    /// Kan aanvaar dat insette eindig is.
    ///
    /// Hierdie intrinsieke het nie 'n stabiele eweknie nie.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Dryf aftrek wat optimasies moontlik maak gebaseer op algebraïese reëls.
    /// Kan aanvaar dat insette eindig is.
    ///
    /// Hierdie intrinsieke het nie 'n stabiele eweknie nie.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Vlottervermenigvuldiging wat optimasies toelaat gebaseer op algebraïese reëls.
    /// Kan aanvaar dat insette eindig is.
    ///
    /// Hierdie intrinsieke het nie 'n stabiele eweknie nie.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Float-verdeling wat optimasies toelaat gebaseer op algebraïese reëls.
    /// Kan aanvaar dat insette eindig is.
    ///
    /// Hierdie intrinsieke het nie 'n stabiele eweknie nie.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Float restant wat optimering moontlik maak op grond van algebraïese reëls.
    /// Kan aanvaar dat insette eindig is.
    ///
    /// Hierdie intrinsieke het nie 'n stabiele eweknie nie.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Skakel om met LLVM se fptoui/fptosi, wat dalk onverdedig vir waardes buite die omvang
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Gestabiliseer as [`f32::to_int_unchecked`] en [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Wys die aantal stukkies wat in 'n heelgetal `T` gestel is
    ///
    /// Die gestabiliseerde weergawes van hierdie intrinsieke is op die heelgetal-primitiewe beskikbaar via die `count_ones`-metode.
    /// Byvoorbeeld,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Wys die aantal voorste unsetbits (zeroes) in 'n heelgetal `T`.
    ///
    /// Die gestabiliseerde weergawes van hierdie intrinsieke is op die heelgetal-primitiewe beskikbaar via die `leading_zeros`-metode.
    /// Byvoorbeeld,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// 'N `x` met waarde `0` gee die bitwydte van `T` terug.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Soos `ctlz`, maar ekstra onveilig omdat dit `undef` teruggee as 'n `x` met waarde `0` gegee word.
    ///
    ///
    /// Hierdie intrinsieke het nie 'n stabiele eweknie nie.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Wys die aantal agtergeblewe bis (zeroes) in 'n heelgetal `T`.
    ///
    /// Die gestabiliseerde weergawes van hierdie intrinsieke is op die heelgetal-primitiewe beskikbaar via die `trailing_zeros`-metode.
    /// Byvoorbeeld,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// 'N `x` met waarde `0` gee die bitwydte van `T` terug:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Soos `cttz`, maar ekstra onveilig omdat dit `undef` teruggee as 'n `x` met waarde `0` gegee word.
    ///
    ///
    /// Hierdie intrinsieke het nie 'n stabiele eweknie nie.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Omkeer die grepe in 'n heelgetal `T`.
    ///
    /// Die gestabiliseerde weergawes van hierdie intrinsieke is op die heelgetal-primitiewe beskikbaar via die `swap_bytes`-metode.
    /// Byvoorbeeld,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Keer die stukkies in 'n heelgetal `T` om.
    ///
    /// Die gestabiliseerde weergawes van hierdie intrinsieke is beskikbaar op die heelgetal-primitiewe via die `reverse_bits`-metode.
    /// Byvoorbeeld,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Voer gekontroleerde heelgetal-optelling uit.
    ///
    /// Die gestabiliseerde weergawes van hierdie intrinsieke is op die heelgetal-primitiewe beskikbaar via die `overflowing_add`-metode.
    /// Byvoorbeeld,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Voer gekontroleerde heelgetal-aftrekking uit
    ///
    /// Die gestabiliseerde weergawes van hierdie intrinsieke is op die heelgetal-primitiewe beskikbaar via die `overflowing_sub`-metode.
    /// Byvoorbeeld,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Voer gekontroleerde heelgetalvermenigvuldiging uit
    ///
    /// Die gestabiliseerde weergawes van hierdie intrinsieke is op die heelgetal-primitiewe beskikbaar via die `overflowing_mul`-metode.
    /// Byvoorbeeld,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Voer 'n presiese verdeling uit, wat lei tot ongedefinieerde gedrag waar `x % y != 0` of `y == 0` of `x == T::MIN && y == -1`
    ///
    ///
    /// Hierdie intrinsieke het nie 'n stabiele eweknie nie.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Voer 'n ongemerkte verdeling uit, wat lei tot ongedefinieerde gedrag waar `y == 0` of `x == T::MIN && y == -1`
    ///
    ///
    /// Veilige omhulsels vir hierdie intrinsieke is beskikbaar op die heelgetal-primitiewe via die `checked_div`-metode.
    /// Byvoorbeeld,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Wys die res van 'n ongekontroleerde afdeling, wat lei tot ongedefinieerde gedrag wanneer `y == 0` of `x == T::MIN && y == -1`
    ///
    ///
    /// Veilige omhulsels vir hierdie intrinsieke is beskikbaar op die heelgetal-primitiewe via die `checked_rem`-metode.
    /// Byvoorbeeld,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Voer 'n ongekontroleerde linksverskuiwing uit, wat lei tot ongedefinieerde gedrag wanneer `y < 0` of `y >= N`, waar N die breedte van T in bits is.
    ///
    ///
    /// Veilige omhulsels vir hierdie intrinsieke is beskikbaar op die heelgetal-primitiewe via die `checked_shl`-metode.
    /// Byvoorbeeld,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Voer 'n ongekontroleerde regsverskuiwing uit, wat lei tot ongedefinieerde gedrag as `y < 0` of `y >= N`, waar N die breedte van T in bits is.
    ///
    ///
    /// Veilige omhulsels vir hierdie intrinsieke is beskikbaar op die heelgetal-primitiewe via die `checked_shr`-metode.
    /// Byvoorbeeld,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Wys die resultaat van 'n ongekontroleerde toevoeging, wat lei tot ongedefinieerde gedrag as `x + y > T::MAX` of `x + y < T::MIN`.
    ///
    ///
    /// Hierdie intrinsieke het nie 'n stabiele eweknie nie.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Wys die resultaat van 'n ongekontroleerde aftrekking, wat lei tot ongedefinieerde gedrag wanneer `x - y > T::MAX` of `x - y < T::MIN`.
    ///
    ///
    /// Hierdie intrinsieke het nie 'n stabiele eweknie nie.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Wys die resultaat van 'n ongemerkte vermenigvuldiging, wat lei tot ongedefinieerde gedrag as `x *y > T::MAX` of `x* y < T::MIN`.
    ///
    ///
    /// Hierdie intrinsieke het nie 'n stabiele eweknie nie.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Draai links om te draai.
    ///
    /// Die gestabiliseerde weergawes van hierdie intrinsieke is op die heelgetal-primitiewe beskikbaar via die `rotate_left`-metode.
    /// Byvoorbeeld,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Voer draai regs uit.
    ///
    /// Die gestabiliseerde weergawes van hierdie intrinsieke is op die heelgetal-primitiewe beskikbaar via die `rotate_right`-metode.
    /// Byvoorbeeld,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Wys (a + b) mod 2 <sup>N</sup>, waar N die breedte van T in bits is.
    ///
    /// Die gestabiliseerde weergawes van hierdie intrinsieke is op die heelgetal-primitiewe beskikbaar via die `wrapping_add`-metode.
    /// Byvoorbeeld,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Wys (a, b) mod 2 <sup>N</sup>, waar N die breedte van T in bits is.
    ///
    /// Die gestabiliseerde weergawes van hierdie intrinsieke is op die heelgetal-primitiewe beskikbaar via die `wrapping_sub`-metode.
    /// Byvoorbeeld,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Wys (a * b) mod 2 <sup>N</sup>, waar N die breedte van T in bits is.
    ///
    /// Die gestabiliseerde weergawes van hierdie intrinsieke is op die heelgetal-primitiewe beskikbaar via die `wrapping_mul`-metode.
    /// Byvoorbeeld,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Bereken `a + b`, versadig aan numeriese grense.
    ///
    /// Die gestabiliseerde weergawes van hierdie intrinsieke is op die heelgetal-primitiewe beskikbaar via die `saturating_add`-metode.
    /// Byvoorbeeld,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Bereken `a - b`, versadig aan numeriese grense.
    ///
    /// Die gestabiliseerde weergawes van hierdie intrinsieke is op die heelgetal-primitiewe beskikbaar via die `saturating_sub`-metode.
    /// Byvoorbeeld,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Wys die waarde van die diskriminant vir die variant in 'v';
    /// as `T` geen diskriminant het nie, gee dit `0` terug.
    ///
    /// Die gestabiliseerde weergawe van hierdie intrinsieke is [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Wys die aantal variante van die tipe `T` wat gegiet word na 'n `usize`;
    /// as `T` geen variante het nie, gee dit `0` terug.Onbewoonde variante sal getel word.
    ///
    /// Die te stabiliseer weergawe van hierdie intrinsieke is [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust se "try catch"-konstruk wat die funksiewyser `try_fn` met die datawyser `data` oproep.
    ///
    /// Die derde argument is 'n funksie wat genoem word as 'n panic voorkom.
    /// Hierdie funksie neem die aanwyser en 'n wyser na die teikenspesifieke voorwerp wat gevang is.
    ///
    /// Vir meer inligting, sien die samesteller se bron sowel as die vangsimplementering van std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Stuur 'n `!nontemporal`-winkel volgens LLVM uit (sien hul dokumente).
    /// Sal waarskynlik nooit stabiel word nie.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Sien die dokumentasie van `<*const T>::offset_from` vir meer inligting.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Sien die dokumentasie van `<*const T>::guaranteed_eq` vir meer inligting.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Sien die dokumentasie van `<*const T>::guaranteed_ne` vir meer inligting.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Ken toe op kompileringstyd.Moet nie tydens looptyd geskakel word nie.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Sommige funksies word hier omskryf omdat dit per ongeluk in hierdie module op stal beskikbaar gestel is.
// Sien <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` val ook in hierdie kategorie, maar dit kan nie toegedraai word nie omdat daar seker is dat `T` en `U` dieselfde grootte het.)
//

/// Kontroleer of `ptr` behoorlik in lyn is met betrekking tot `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Kopieer `count *size_of::<T>()`-grepe van `src` na `dst`.Die bron en bestemming moet* nie * oorvleuel nie.
///
/// Gebruik eerder [`copy`] vir geheue-gebiede wat oorvleuel.
///
/// `copy_nonoverlapping` is semanties gelykstaande aan C se [`memcpy`], maar met die argumentvolgorde omgeruil.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Gedrag is ongedefinieerd as een van die volgende voorwaardes oortree word:
///
/// * `src` moet [valid] wees vir lees van `count * size_of::<T>()` grepe.
///
/// * `dst` moet [valid] wees vir skryf van `count * size_of::<T>()` grepe.
///
/// * Beide `src` en `dst` moet behoorlik in lyn wees.
///
/// * Die gebied van geheue wat begin by `src` met 'n grootte van 'tel *
///   grootte_van: :<T>() `bytes moet *nie* oorvleuel met die gebied van geheue wat begin by `dst` met dieselfde grootte nie.
///
/// Soos [`read`], skep `copy_nonoverlapping` 'n bitvisse kopie van `T`, ongeag of `T` [`Copy`] is.
/// As `T` nie [`Copy`] is nie, kan *beide* die waardes in die streek wat begin by `*src` en die gebied wat begin by `* dst` [violate memory safety][read-ownership] gebruik.
///
///
/// Let daarop dat selfs as die effektief gekopieerde grootte (`count * size_of: :<T>()`) is `0`, die aanwysers moet nie-NULL wees en behoorlik in lyn gebring word.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// [`Vec::append`] handmatig implementeer:
///
/// ```
/// use std::ptr;
///
/// /// Skuif al die elemente van `src` na `dst`, en laat `src` leeg.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Verseker dat `dst` genoeg kapasiteit het om die hele `src` te hou.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Die oproep om te verreken is altyd veilig omdat `Vec` nooit meer as `isize::MAX` byte sal toewys nie.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Knip `src` af sonder om die inhoud daarvan te laat val.
///         // Ons doen dit eers om probleme te voorkom in geval iets verder af in panics.
///         src.set_len(0);
///
///         // Die twee streke kan nie oorvleuel nie, want veranderlike verwysings is nie alias nie, en twee verskillende vektore kan nie dieselfde geheue besit nie.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Stel `dst` in kennis dat dit nou die inhoud van `src` bevat.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Voer hierdie kontrole slegs uit tydens gebruikstyd
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Moenie paniekerig raak om die impak van die kodegen kleiner te hou nie.
        abort();
    }*/

    // VEILIGHEID: die veiligheidskontrak vir `copy_nonoverlapping` moet wees
    // deur die oproeper gehandhaaf word.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Kopieer `count * size_of::<T>()`-grepe van `src` na `dst`.Die bron en bestemming kan mekaar oorvleuel.
///
/// As die bron en bestemming *nooit* sal oorvleuel nie, kan [`copy_nonoverlapping`] eerder gebruik word.
///
/// `copy` is semanties gelykstaande aan C se [`memmove`], maar met die argumentvolgorde omgeruil.
/// Kopiëring vind plaas asof die grepe van `src` na 'n tydelike skikking gekopieer is en dan van die skikking na `dst` gekopieër word.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Gedrag is ongedefinieerd as een van die volgende voorwaardes oortree word:
///
/// * `src` moet [valid] wees vir lees van `count * size_of::<T>()` grepe.
///
/// * `dst` moet [valid] wees vir skryf van `count * size_of::<T>()` grepe.
///
/// * Beide `src` en `dst` moet behoorlik in lyn wees.
///
/// Soos [`read`], skep `copy` 'n bitvisse kopie van `T`, ongeag of `T` [`Copy`] is.
/// As `T` nie [`Copy`] is nie, kan beide die waardes in die streek wat begin by `*src` en die gebied wat begin by `* dst` [violate memory safety][read-ownership] gebruik.
///
///
/// Let daarop dat selfs as die effektief gekopieerde grootte (`count * size_of: :<T>()`) is `0`, die aanwysers moet nie-NULL wees en behoorlik in lyn gebring word.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Skep 'n Rust vector doeltreffend vanuit 'n onveilige buffer:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` moet korrek in lyn gebring word vir die tipe en nie-nul.
/// /// * `ptr` moet geldig wees vir lees van `elts` aangrensende elemente van die tipe `T`.
/// /// * Hierdie elemente mag nie gebruik word nadat hierdie funksie aangeskakel is nie, tensy `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // VEILIGHEID: Ons voorwaarde verseker dat die bron belyn en geldig is,
///     // en `Vec::with_capacity` verseker dat ons bruikbare ruimte het om dit te skryf.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // VEILIGHEID: Ons het dit vroeër met soveel kapasiteit geskep,
///     // en die vorige `copy` het hierdie elemente geïnisialiseer.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Voer hierdie kontrole slegs uit tydens gebruikstyd
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Moenie paniekerig raak om die impak van die kodegen kleiner te hou nie.
        abort();
    }*/

    // VEILIGHEID: die veiligheidskontrak vir `copy` moet deur die oproeper gehandhaaf word.
    unsafe { copy(src, dst, count) }
}

/// Stel `count * size_of::<T>()` bytes geheue in vanaf `dst` tot `val`.
///
/// `write_bytes` is soortgelyk aan C se [`memset`], maar stel `count * size_of::<T>()` bytes op `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Gedrag is ongedefinieerd as een van die volgende voorwaardes oortree word:
///
/// * `dst` moet [valid] wees vir skryf van `count * size_of::<T>()` grepe.
///
/// * `dst` moet behoorlik in lyn gebring word.
///
/// Daarbenewens moet die oproeper toesien dat die skryf van `count * size_of::<T>()`-bytes na die gegewe gebied van geheue 'n geldige waarde van `T` tot gevolg het.
/// Die gebruik van 'n geheue-gebied getik as 'n `T` wat 'n ongeldige waarde van `T` bevat, is ongedefinieerde gedrag.
///
/// Let daarop dat selfs as die effektief gekopieerde grootte (`count * size_of: :<T>()`) is `0`, die aanwyser moet nie-NULL wees en behoorlik belyn wees.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Basiese gebruik:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Die skep van 'n ongeldige waarde:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Lek die waarde wat voorheen gehou is deur die `Box<T>` met 'n nulaanwyser te oorskryf.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Op hierdie stadium lei of gebruik `v` tot ongedefinieerde gedrag.
/// // drop(v); // ERROR
///
/// // Selfs lek `v` "uses" dit, en dus is ongedefinieerde gedrag.
/// // mem::forget(v); // ERROR
///
/// // In werklikheid is `v` ongeldig volgens basiese invoeraars van die tipe uitleg, dus *enige* bewerking wat daaraan raak, is ongedefinieerde gedrag.
/////
/// // laat v2 =v;//FOUT
///
/// unsafe {
///     // Laat ons eerder 'n geldige waarde invoeg
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Nou is die boks goed
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // VEILIGHEID: die veiligheidskontrak vir `write_bytes` moet deur die oproeper gehandhaaf word.
    unsafe { write_bytes(dst, val, count) }
}