#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// Met 'n `RawWaker` kan die implementeerder van 'n taakuitvoerder 'n [`Waker`] skep wat aangepaste wekgedrag bied.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Dit bestaan uit 'n datawyser en 'n [virtual function pointer table (vtable)][vtable] wat die gedrag van die `RawWaker` aanpas.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// 'N Dataanwyser, wat gebruik kan word om willekeurige data op te slaan soos deur die eksekuteur vereis.
    /// Dit kan bv
    /// 'n tipe uitgewisde wyser na 'n `Arc` wat aan die taak gekoppel is.
    /// Die waarde van hierdie veld word oorgedra aan alle funksies wat deel uitmaak van die tabel as die eerste parameter.
    ///
    data: *const (),
    /// Aanwysertabel vir virtuele funksies wat die gedrag van hierdie waker aanpas.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Skep 'n nuwe `RawWaker` vanaf die `data`-aanwyser en `vtable`.
    ///
    /// Die `data`-wyser kan gebruik word om willekeurige data op te slaan soos deur die eksekuteur vereis.Dit kan bv
    /// 'n tipe uitgewisde wyser na 'n `Arc` wat aan die taak gekoppel is.
    /// Die waarde van hierdie wyser word oorgedra aan alle funksies wat deel uitmaak van die `vtable` as die eerste parameter.
    ///
    /// Die `vtable` pas die gedrag van 'n `Waker` aan wat vanaf 'n `RawWaker` geskep word.
    /// Vir elke bewerking op die `Waker` word die geassosieerde funksie in die `vtable` van die onderliggende `RawWaker` genoem.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// 'N Virtuele funksie-aanwysertabel (vtable) wat die gedrag van 'n [`RawWaker`] spesifiseer.
///
/// Die aanwyser wat aan alle funksies in die vtabel oorgedra word, is die `data`-aanwyser vanaf die [`RawWaker`]-voorwerp.
///
/// Die funksies binne hierdie struktuur is slegs bedoel om op die `data`-aanwyser van 'n behoorlik gekonstrueerde [`RawWaker`]-voorwerp van binne die [`RawWaker`]-implementering gebruik te word.
/// Ongedefinieerde gedrag kan veroorsaak as u een van die funksies met enige ander `data`-wyser skakel.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Hierdie funksie word genoem wanneer die [`RawWaker`] gekloon word, byvoorbeeld wanneer die [`Waker`] waarin die [`RawWaker`] gestoor word gekloon word.
    ///
    /// Die implementering van hierdie funksie moet alle bronne behou wat benodig word vir hierdie addisionele geval van 'n [`RawWaker`] en gepaardgaande taak.
    /// As u `wake` op die resulterende [`RawWaker`] roep, moet u dieselfde taak wakker maak as wat die oorspronklike [`RawWaker`] wakker gemaak het.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Hierdie funksie word genoem wanneer `wake` op die [`Waker`] genoem word.
    /// Dit moet die taak wat met hierdie [`RawWaker`] geassosieer word, wakker maak.
    ///
    /// Die implementering van hierdie funksie moet sorg dat enige hulpbronne wat verband hou met hierdie geval van 'n [`RawWaker`] en gepaardgaande taak, vrygestel word.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Hierdie funksie word genoem wanneer `wake_by_ref` op die [`Waker`] genoem word.
    /// Dit moet die taak wat met hierdie [`RawWaker`] geassosieer word, wakker maak.
    ///
    /// Hierdie funksie is soortgelyk aan `wake`, maar moet nie die gegewe aanwyser gebruik nie.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Hierdie funksie word genoem wanneer 'n [`RawWaker`] laat vaar.
    ///
    /// Die implementering van hierdie funksie moet sorg dat enige hulpbronne wat verband hou met hierdie geval van 'n [`RawWaker`] en gepaardgaande taak, vrygestel word.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Skep 'n nuwe `RawWakerVTable` uit die verskafde funksies `clone`, `wake`, `wake_by_ref` en `drop`.
    ///
    /// # `clone`
    ///
    /// Hierdie funksie word genoem wanneer die [`RawWaker`] gekloon word, byvoorbeeld wanneer die [`Waker`] waarin die [`RawWaker`] gestoor word gekloon word.
    ///
    /// Die implementering van hierdie funksie moet alle bronne behou wat benodig word vir hierdie addisionele geval van 'n [`RawWaker`] en gepaardgaande taak.
    /// As u `wake` op die resulterende [`RawWaker`] roep, moet u dieselfde taak wakker maak as wat die oorspronklike [`RawWaker`] wakker gemaak het.
    ///
    /// # `wake`
    ///
    /// Hierdie funksie word genoem wanneer `wake` op die [`Waker`] genoem word.
    /// Dit moet die taak wat met hierdie [`RawWaker`] geassosieer word, wakker maak.
    ///
    /// Die implementering van hierdie funksie moet sorg dat enige hulpbronne wat verband hou met hierdie geval van 'n [`RawWaker`] en gepaardgaande taak, vrygestel word.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Hierdie funksie word genoem wanneer `wake_by_ref` op die [`Waker`] genoem word.
    /// Dit moet die taak wat met hierdie [`RawWaker`] geassosieer word, wakker maak.
    ///
    /// Hierdie funksie is soortgelyk aan `wake`, maar moet nie die gegewe aanwyser gebruik nie.
    ///
    /// # `drop`
    ///
    /// Hierdie funksie word genoem wanneer 'n [`RawWaker`] laat vaar.
    ///
    /// Die implementering van hierdie funksie moet sorg dat enige hulpbronne wat verband hou met hierdie geval van 'n [`RawWaker`] en gepaardgaande taak, vrygestel word.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// Die `Context` van 'n asynchrone taak.
///
/// Tans dien `Context` slegs om toegang te verleen tot 'n `&Waker` wat gebruik kan word om die huidige taak wakker te maak.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Verseker dat ons future-bestendig is teen afwykingsveranderings deur die lewensduur te dwing om onveranderlik te wees (die leeftyd van die argumentposisie is kontravariant, terwyl die terugkeerposisie-lewensduur covariant is).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Skep 'n nuwe `Context` vanaf 'n `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Wys 'n verwysing na die `Waker` vir die huidige taak.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// 'N `Waker` is 'n handvat om 'n taak wakker te maak deur die eksekuteur daarvan in kennis te stel dat dit gereed is om te bestuur.
///
/// Hierdie handvatsel bevat 'n [`RawWaker`]-instansie, wat die eksekuteurspesifieke wekgedrag definieer.
///
///
/// Implementeer [`Clone`], [`Send`] en [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Maak die taak wat met hierdie `Waker` geassosieer word, wakker.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Die werklike wekroep word deur 'n virtuele funksie-oproep gedelegeer na die implementering wat deur die eksekuteur gedefinieer word.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Moenie `drop` skakel nie-die waker sal deur `wake` verteer word.
        crate::mem::forget(self);

        // VEILIGHEID: dit is veilig, want `Waker::from_raw` is die enigste manier
        // om `wake` en `data` te initialiseer wat vereis dat die gebruiker moet erken dat die kontrak van `RawWaker` gehandhaaf word.
        //
        unsafe { (wake)(data) };
    }

    /// Maak die taak geassosieer met hierdie `Waker` wakker sonder om die `Waker` te verbruik.
    ///
    /// Dit is soortgelyk aan `wake`, maar kan effens minder doeltreffend wees as 'n `Waker` in besit is.
    /// Hierdie metode moet verkies word bo `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Die werklike wekroep word deur 'n virtuele funksie-oproep gedelegeer na die implementering wat deur die eksekuteur gedefinieer word.
        //

        // VEILIGHEID: sien `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Wys `true` as hierdie `Waker` en 'n ander `Waker` dieselfde taak wakker gemaak het.
    ///
    /// Hierdie funksie werk op 'n beste poging en kan onwaar wees, selfs as die Waker dieselfde taak sou ontwaak.
    /// As hierdie funksie egter `true` oplewer, is dit gewaarborg dat die 'Waker`s dieselfde taak sal wek.
    ///
    /// Hierdie funksie word hoofsaaklik gebruik vir optimaliseringsdoeleindes.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Skep 'n nuwe `Waker` vanaf [`RawWaker`].
    ///
    /// Die gedrag van die teruggestuurde `Waker` is ongedefinieerd as die kontrak wat in ['RawWaker'] en ['RawWakerVTable'] se dokumentasie omskryf word nie gehandhaaf word nie.
    ///
    /// Daarom is hierdie metode onveilig.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // VEILIGHEID: dit is veilig, want `Waker::from_raw` is die enigste manier
            // om `clone` en `data` te initialiseer wat vereis dat die gebruiker moet erken dat die kontrak van [`RawWaker`] gehandhaaf word.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // VEILIGHEID: dit is veilig, want `Waker::from_raw` is die enigste manier
        // om `drop` en `data` te initialiseer wat vereis dat die gebruiker moet erken dat die kontrak van `RawWaker` gehandhaaf word.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}