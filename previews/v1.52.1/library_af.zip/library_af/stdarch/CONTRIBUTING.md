# Bydra tot stdarch

Die `stdarch` crate is meer as bereid om bydraes te aanvaar!Eerstens wil u waarskynlik die bewaarplek gaan ondersoek en seker maak dat die toetse vir u slaag:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Waar `<your-target-arch>` die teikendrievoud is soos gebruik deur `rustup`, bv. `x86_x64-unknown-linux-gnu` (sonder enige voorafgaande `nightly-` of soortgelyk).
Onthou ook dat hierdie bewaarplek die nagkanaal van Rust benodig!
Bogenoemde toetse vereis in werklikheid dat rust die standaard op u stelsel moet wees om die gebruik van `rustup default nightly` (en `rustup default stable` om terug te stel) in te stel.

As een van die bogenoemde stappe nie werk nie, [please let us know][new]!

Vervolgens kan u [find an issue][issues] help, ons het 'n paar gekies met die [`help wanted`][help]-en [`impl-period`][impl]-etikette, wat veral hulp kan gebruik. 
U stel dalk die meeste in [#40][vendor] voor en implementeer alle intrinsieke verskaffers op x86.Die uitgawe het 'n paar goeie wenke oor waar om te begin!

As u algemene vrae het, kan u [join us on gitter][gitter] gerus vra en vra!Skakel gerus óf@BurntSushi óf@alexcrichton met vrae.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Hoe om voorbeelde vir stdarch-intrinsieke te skryf

Daar is 'n paar funksies wat geaktiveer moet word vir die gegewe intrinsieke om behoorlik te werk, en die voorbeeld moet slegs deur `cargo test --doc` uitgevoer word as die funksie deur die SVE ondersteun word.

As gevolg hiervan sal die standaard `fn main` wat deur `rustdoc` gegenereer word, nie werk nie (in die meeste gevalle).
Oorweeg dit om die volgende as 'n riglyn te gebruik om te verseker dat u voorbeeld werk soos verwag.

```rust
/// # // Ons het cfg_target_feature nodig om te verseker dat die voorbeeld slegs hiervan is
/// # // word bestuur deur `cargo test --doc` wanneer die SVE die funksie ondersteun
/// # #![feature(cfg_target_feature)]
/// # // Ons het doel_funksie nodig om die intrinsieke te laat werk
/// # #![feature(target_feature)]
/// #
/// # // Rustdoc gebruik standaard `extern crate stdarch`, maar ons het die
/// # // `#[macro_use]`
/// # # [makrogebruik] ekstern crate stdarch;
/// #
/// # // Die werklike hooffunksie
/// # fn main() {
/// #     // Begin dit slegs as `<target feature>` ondersteun word
/// #     as cfg_feature_enabled! ("<target feature>"){
/// #         // Skep 'n `worker`-funksie wat slegs uitgevoer kan word as die teikenfunksie is
/// #         // word ondersteun en sorg dat `target_feature` vir u werker geaktiveer is
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         onveilig fn worker() {
/// // Skryf u voorbeeld hier.Funksiespesifieke intrinsieke sal hier werk!Gaan wild!
///
/// #         }
///
/// #         onveilige { worker(); }
/// #     }
/// # }
```

As sommige van die bogenoemde sintaksis nie bekend lyk nie, beskryf die [Documentation as tests]-gedeelte van die [Rust Book] die `rustdoc`-sintaksis redelik goed.
Soos altyd, kan u gerus [join us on gitter][gitter] vra en ons vra of u 'n slag slaan, en dankie dat u die dokumentasie van `stdarch` help verbeter het!

# Alternatiewe toetsinstruksies

Dit word gewoonlik aanbeveel dat u `ci/run.sh` gebruik om die toetse uit te voer.
Dit kan egter nie vir u werk nie, byvoorbeeld as u op Windows is.

In daardie geval kan u terugkeer na die werking van `cargo +nightly test` en `cargo +nightly test --release -p core_arch` om die kodegenerasie te toets.
Let daarop dat dit nodig is om die naggereedskapsketting te installeer en dat `rustc` moet weet oor u teikendrievoud en die SVE.
U moet veral die `TARGET`-omgewingsveranderlike instel soos vir `ci/run.sh`.
Daarbenewens moet u `RUSTCFLAGS` (benodig die `C`) instel om die teikenfunksies aan te dui, bv `RUSTCFLAGS="-C -target-features=+avx2"`.
U kan ook `-C -target-cpu=native` instel as u "just" teen u huidige SVE ontwikkel.

Wees gewaarsku dat wanneer u hierdie alternatiewe instruksies gebruik, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], bv
toetse vir generasie van instruksies kan misluk omdat die demontageerder dit anders noem, bv
dit kan `vaesenc` in plaas van `aesenc`-instruksies genereer ten spyte daarvan dat hulle dieselfde optree.
Hierdie instruksies voer ook minder toetse uit as wat normaalweg gedoen sou word, dus moenie verbaas wees dat wanneer u uiteindelik 'n versoek aanvra nie, sommige foute kan verskyn vir toetse wat nie hier behandel word nie.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






