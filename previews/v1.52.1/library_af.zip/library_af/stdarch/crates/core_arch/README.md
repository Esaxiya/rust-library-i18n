`core::arch` - Rust se kernbiblioteek-argitektuur-spesifieke intrinsieke
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Die `core::arch`-module implementeer argitektuurafhanklike intrinsieke (bv. SIMD).

# Usage 

`core::arch` is beskikbaar as deel van `libcore` en dit word weer deur `libstd` uitgevoer.Gebruik dit liewer via `core::arch` of `std::arch` as via hierdie crate.
Onstabiele funksies is dikwels beskikbaar in die nag Rust via die `feature(stdsimd)`.

Om `core::arch` via hierdie crate te gebruik, benodig u Rust in die nag, en dit kan (en breek) gereeld.Die enigste gevalle waarin u dit met hierdie crate moet oorweeg, is:

* as u `core::arch` self moet saamstel, byvoorbeeld met spesifieke teikenfunksies geaktiveer wat nie vir `libcore`/`libstd` geaktiveer is nie.
Note: as u dit weer moet saamstel vir 'n nie-standaard teiken, gebruik dan `xargo` en gebruik `libcore`/`libstd` weer soos toepaslik in plaas van die crate.
  
* die gebruik van sommige funksies wat selfs agter onstabiele Rust-funksies nie beskikbaar is nie.Ons probeer dit beperk.
As u van hierdie funksies moet gebruik, maak asseblief 'n probleem oop sodat ons dit in die Rust in die nag kan blootstel en u dit van daar af kan gebruik.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` word hoofsaaklik versprei onder die bepalings van beide die MIT-lisensie en die Apache-lisensie (weergawe 2.0), met gedeeltes wat deur verskillende BSD-agtige lisensies gedek word.

Sien LICENSE-APACHE en LICENSE-MIT vir meer inligting.

# Contribution

Tensy u uitdruklik anders verklaar, sal enige bydrae wat u doelbewus ingedien het vir insluiting in `core_arch`, soos omskryf in die Apache-2.0-lisensie, soos hierbo gedubbel gelisensieer word, sonder enige bykomende bepalings of voorwaardes.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












