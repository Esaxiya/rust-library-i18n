# Die `rustc-std-workspace-core` crate

Hierdie crate is 'n leë en leë crate wat eenvoudig van `libcore` afhang en al sy inhoud weer uitvoer.
Die crate is die kern van die standaardbiblioteek om van crates.io afhanklik te wees van crates

Crates op crates.io waarvan die standaardbiblioteek afhanklik is, moet afhang van die `rustc-std-workspace-core` crate van crates.io, wat leeg is.

Ons gebruik `[patch]` om dit na hierdie crate in hierdie bewaarplek te vervang.
As gevolg hiervan sal crates op crates.io 'n afhanklikheid edge trek na `libcore`, die weergawe wat in hierdie bewaarplek gedefinieer word.
Dit moet al die afhanklikheidsrande trek om te verseker dat Cargo crates suksesvol bou!

Let daarop dat crates op crates.io van hierdie crate met die naam `core` moet afhang om alles reg te laat werk.Om dit te doen, kan hulle:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Deur die gebruik van die `package`-sleutel word die crate herdoop na `core`, wat beteken dat dit sal lyk

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

wanneer Cargo die samesteller oproep, voldoen dit aan die implisiete `extern crate core`-voorskrif wat deur die samesteller ingespuit is.




