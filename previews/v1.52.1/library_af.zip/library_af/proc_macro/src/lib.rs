//! 'N Ondersteuningsbiblioteek vir makro-outeurs wanneer nuwe makro's gedefinieer word.
//!
//! Hierdie biblioteek, voorsien deur die standaard verspreiding, bied die tipes wat verbruik word in die koppelvlakke van prosedure-gedefinieerde makro-definisies, soos funksie-agtige makro's `#[proc_macro]`, makro-eienskappe `#[proc_macro_attribute]` en persoonlike afgeleide eienskappe '#[proc_macro_derive] `.
//!
//!
//! Sien [the book] vir meer inligting.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Bepaal of proc_macro toeganklik gemaak is vir die huidige program.
///
/// Die proc_macro crate is slegs bedoel vir gebruik binne die implementering van prosedurele makro's.Al die funksies in hierdie crate panic indien dit van buite 'n proseduremakro aangewend word, soos uit 'n build-script of eenheidstoets of gewone Rust-binêre.
///
/// Met inagneming van Rust-biblioteke wat ontwerp is om makro-en nie-makro-gebruiksgevalle te ondersteun, bied `proc_macro::is_available()` 'n nie-paniekerige manier om op te spoor of die infrastruktuur wat benodig word om die API van proc_macro te gebruik, tans beskikbaar is.
/// Wys waar as dit vanaf die binnekant van 'n proseduremakro aangeroep word, vals indien dit van enige ander binêre gebruik word.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Die hooftipe wat deur hierdie crate aangebied word, wat 'n abstrakte stroom tokens voorstel, of meer spesifiek 'n reeks token-bome.
/// Die tipe bied koppelvlakke om oor die token-bome te herhaal en, omgekeerd, om 'n aantal token-bome in een stroom te versamel.
///
///
/// Dit is beide die invoer en afvoer van `#[proc_macro]`, `#[proc_macro_attribute]` en `#[proc_macro_derive]` definisies.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Fout teruggestuur vanaf `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Wys 'n leë `TokenStream` wat geen token-bome bevat nie.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Kontroleer of hierdie `TokenStream` leeg is.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Pogings om die tou in tokens op te breek en daardie tokens in 'n token-stroom te ontleed.
/// Kan om verskeie redes misluk, byvoorbeeld as die string ongebalanseerde afbakeninge of karakters bevat wat nie in die taal bestaan nie.
///
/// Alle tokens in die ontleedstroom kry `Span::call_site()`-spanwydte.
///
/// NOTE: sommige foute kan panics veroorsaak in plaas daarvan om `LexError` terug te stuur.Ons behou ons die reg voor om hierdie foute in 'LexError`s later te verander.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, die brug bied slegs `to_string`, implementeer `fmt::Display` op grond daarvan (die omgekeerde van die gewone verhouding tussen die twee).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Druk die token-stroom af as 'n string wat veronderstel is om verlosbaar omskakelbaar te wees in dieselfde token-stroom (modulo-spanwydte), behalwe vir moontlik 'TokenTree: : Group' s met `Delimiter::None`-afbakening en negatiewe syferletters.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Druk token af in 'n vorm wat maklik is om te ontfout.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Skep 'n token-stroom wat 'n enkele token-boom bevat.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Versamel 'n aantal token-bome in een stroom.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// 'N "flattening"-operasie op token-strome versamel token-bome uit verskeie token-strome in 'n enkele stroom.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Gebruik 'n optimale implementering if/when moontlik.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Openbare implementeringsbesonderhede vir die `TokenStream`-tipe, soos herhalers.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// 'N Iterator oor' TokenStream 'se' TokenTree`s.
    /// Die herhaling is "shallow", byvoorbeeld, die herhaling herhaal nie in afgebakende groepe nie en gee hele groepe weer as token-bome.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` aanvaar arbitrêre tokens en brei uit na 'n `TokenStream` wat die insette beskryf.
/// `quote!(a + b)` sal byvoorbeeld 'n uitdrukking lewer wat, wanneer dit geëvalueer word, die `TokenStream` `[Ident("a"), Punct('+', Alone) konstrueer, Ident("b")]`.
///
///
/// Unquoting word met `$` gedoen en werk deur die volgende identiteit as die ongenoteerde term te neem.
/// Gebruik `$$` om `$` self aan te haal.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// 'N Streek van bronkode, tesame met inligting oor makro-uitbreiding.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Skep 'n nuwe `Diagnostic` met die gegewe `message` tydens die span `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// 'N Spanwydte wat op die makrodefinisie-werf oplos.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Die omvang van die aanroep van die huidige prosedurele makro.
    /// Identifiseerders wat met hierdie span geskep word, word opgelos asof dit direk op die makro-oproeplokaal (oproep-higiëne) geskryf is, en ander kode op die makro-oproep-webwerf kan ook daarna verwys.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// 'N Spanwydte wat `macro_rules`-higiëne voorstel, en soms oplos by die makro-definisie-webwerf (plaaslike veranderlikes, etikette, `$crate`) en soms op die makro-oproep-webwerf (alles anders).
    ///
    /// Die spanlokaal word van die oproepwerf geneem.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Die oorspronklike bronlêer waarop hierdie span verwys.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// Die `Span` vir die tokens in die vorige makro-uitbreiding waaruit `self` gegenereer is, indien enige.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Die spanwydte vir die oorsprongbronkode waaruit `self` gegenereer is.
    /// As hierdie `Span` nie gegenereer is uit ander makro-uitbreidings nie, is die terugkeerwaarde dieselfde as `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Kry die begin-line/column in die bronlêer vir hierdie span.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Kry die einde line/column in die bronlêer vir hierdie span.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Skep 'n nuwe span wat `self` en `other` omvat.
    ///
    /// Wys `None` as `self` en `other` van verskillende lêers is.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Skep 'n nuwe spanwydte met dieselfde line/column-inligting as `self`, maar simbole word opgelos asof dit op `other` was.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Skep 'n nuwe span met dieselfde resolusie-gedrag as `self`, maar met die line/column-inligting van `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Vergelyk met spanwydte om te sien of hulle gelyk is.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Wys die bronteks agter 'n spanwydte.
    /// Dit bewaar die oorspronklike bronkode, insluitend spasies en opmerkings.
    /// Dit gee slegs 'n resultaat as die spanwydte ooreenstem met die regte bronkode.
    ///
    /// Note: Die waarneembare resultaat van 'n makro moet slegs op die tokens staatmaak en nie op hierdie bronteks nie.
    ///
    /// Die resultaat van hierdie funksie is die beste poging om slegs vir diagnostiek gebruik te word.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Druk 'n spanwydte in 'n vorm wat geskik is vir foutopsporing.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// 'N Lynkolompaar wat die begin of einde van 'n `Span` voorstel.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Die 1-geïndekseerde reël in die bronlêer waarop die span (inclusive) begin of eindig.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Die 0-geïndekseerde kolom (in UTF-8 karakters) in die bronlêer waarop die span (inclusive) begin of eindig.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Die bronlêer van 'n gegewe `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Kry die pad na hierdie bronlêer.
    ///
    /// ### Note
    /// As die kodespan wat met hierdie `SourceFile` geassosieer word, deur 'n eksterne makro gegenereer is, is hierdie makro miskien nie 'n werklike pad op die lêerstelsel nie.
    /// Gebruik [`is_real`] om na te gaan.
    ///
    /// Let ook daarop dat selfs as `is_real` `true` terugbesorg, en as `--remap-path-prefix` op die opdragreël geslaag is, die gegewe pad moontlik nie geldig is nie.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Wys `true` as hierdie bronlêer 'n regte bronlêer is en nie gegenereer word deur die uitbreiding van 'n eksterne makro nie.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Dit is 'n kap totdat intercrate-strek geïmplementeer word en ons werklike bronlêers kan hê vir strek wat in eksterne makros gegenereer word.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// 'N Enkele token of 'n afgebakende reeks token bome (bv. `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// 'N token-stroom omring deur hakies.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// 'N Identifiseerder.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// 'N Enkele leestekenkarakter (`+`, `,`, `$`, ens.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// 'N Letterlike karakter (`'a'`), string (`"hello"`), nommer (`2.3`), ens.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Wys die spanwydte van hierdie boom en delegeer dit na die `span`-metode van die vervat token of 'n afgebakende stroom.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Stel die spanwydte op vir *slegs hierdie token*.
    ///
    /// Let daarop dat as hierdie token 'n `Group` is, hierdie metode nie die spanwydte van elk van die interne tokens sal instel nie, dit sal eenvoudig na die `set_span`-metode van elke variant gedelegeer word.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Druk die token-boom in 'n vorm wat maklik is om te ontfout.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Elkeen hiervan het die naam in die struktuurtipe in die afgeleide ontfouting, dus moenie 'n ekstra laag indireksie doen nie
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, die brug bied slegs `to_string`, implementeer `fmt::Display` op grond daarvan (die omgekeerde van die gewone verhouding tussen die twee).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Druk die token-boom as 'n string wat veronderstel is om verliesloos omskepbaar te wees in dieselfde token-boom (modulo-spanwydte), behalwe vir moontlik 'TokenTree: : Group' s met `Delimiter::None`-afbakeners en negatiewe syferletters.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// 'N Afgebakende token-stroom.
///
/// 'N `Group` bevat intern 'n `TokenStream` wat omring word deur' Afgrensers '.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Beskryf hoe 'n reeks token-bome afgebaken word.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// 'N Implisiete afbakening, wat byvoorbeeld rondom tokens van 'n "macro variable" `$var` kan voorkom.
    /// Dit is belangrik om die prioriteite van die operateur te behou in gevalle soos `$var * 3` waar `$var` `1 + 2` is.
    /// Implisiete afbakeners kan die retour van 'n token-stroom nie deur 'n string oorleef nie.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Skep 'n nuwe `Group` met die gegewe skeidingsteken en token-stroom.
    ///
    /// Hierdie konstrukteur sal die spanwydte vir hierdie groep op `Span::call_site()` stel.
    /// Om die spanwydte te verander, kan u die `set_span`-metode hieronder gebruik.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Wys die afbakening van hierdie `Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Wys die `TokenStream` van tokens wat in hierdie `Group` afgebaken is.
    ///
    /// Let daarop dat die teruggekeerde token-stroom nie die skeidingsteken hierbo bevat nie.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Wys die spanwydte vir die afbakening van hierdie token-stroom, wat strek oor die hele `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Wys die spanwydte wat na die beginafbakening van hierdie groep wys.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Wys die spanwydte wat na die afgrensing van hierdie groep wys.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Stel die spanwydte op vir die afbakening van hierdie groep, maar nie die interne tokens nie.
    ///
    /// Hierdie metode sal **nie** die spanwydte van al die interne tokens wat deur hierdie groep bestrek word, instel nie, maar eerder die spanwydte van die afbakening tokens op die vlak van die `Group` stel.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, die brug bied slegs `to_string`, implementeer `fmt::Display` op grond daarvan (die omgekeerde van die gewone verhouding tussen die twee).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Druk die groep as 'n string wat verliesloos omskepbaar moet word in dieselfde groep (modulo-spanwydte), behalwe moontlik 'TokenTree: : Group' s met `Delimiter::None`-afbakening.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// 'N `Punct` is 'n enkele leestekenkarakter soos `+`, `-` of `#`.
///
/// Multikaraktereerders soos `+=` word voorgestel as twee gevalle van `Punct` met verskillende vorme van `Spacing`.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Of 'n `Punct` onmiddellik gevolg word deur 'n ander `Punct` of gevolg deur 'n ander token of witruimte.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// `+` is byvoorbeeld `Alone` in `+ =`, `+ident` of `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// `+` is byvoorbeeld `Joint` in `+=` of `'#`.
    /// Daarbenewens kan 'n enkele aanhaling `'` met identifikasies saamvoeg om lewenslange `'ident` te vorm.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Skep 'n nuwe `Punct` uit die gegewe karakter en spasiëring.
    /// Die `ch`-argument moet 'n geldige leesteken wees wat deur die taal toegelaat word, anders sal die funksie panic wees.
    ///
    /// Die teruggestuurde `Punct` het die standaardpaneel van `Span::call_site()` wat verder met die onderstaande `set_span`-metode ingestel kan word.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Wys die waarde van hierdie leestekenkarakter as `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Wys die spasiëring van hierdie leesteken, en dui aan of dit onmiddellik gevolg word deur 'n ander `Punct` in die token-stroom, sodat dit moontlik gekombineer kan word tot 'n multi-karakter-operateur (`Joint`), of dat dit gevolg word deur 'n ander token of witruimte (`Alone`), sodat die operateur beslis het geëindig het.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Wys die spanwydte vir hierdie leestekenkarakter.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Stel die spanwydte vir hierdie leestekenkarakter op.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, die brug bied slegs `to_string`, implementeer `fmt::Display` op grond daarvan (die omgekeerde van die gewone verhouding tussen die twee).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Druk die leesteken as 'n string wat verliesloos omskepbaar kan word in dieselfde karakter.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// 'N Identifiseerder (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Skep 'n nuwe `Ident` met die gegewe `string` sowel as die gespesifiseerde `span`.
    /// Die `string`-argument moet 'n geldige identifiseerder wees wat deur die taal toegelaat word (insluitend sleutelwoorde, bv. `self` of `fn`).Andersins sal die funksie panic wees.
    ///
    /// Let daarop dat `span`, tans in rustc, die higiëne-inligting vir hierdie identifiseerder opstel.
    ///
    /// Vanaf hierdie tyd gaan `Span::call_site()` eksplisiet in op "call-site"-higiëne, wat beteken dat identifiseerders wat met hierdie span geskep word, opgelos sal word asof dit direk op die plek van die makro-oproep geskryf is, en ander kode op die makro-oproepwerf kan verwys na hulle ook.
    ///
    ///
    /// Later spanwydte soos `Span::def_site()` laat toe om aan te sluit by "definition-site"-higiëne, wat beteken dat identifiseerders wat met hierdie span geskep word, op die plek van die makro-definisie opgelos sal word, en ander kode op die makro-oproepwerf kan nie daarna verwys nie.
    ///
    /// Vanweë die huidige belangrikheid van higiëne, vereis hierdie konstruktor, in teenstelling met ander tokens, dat 'n `Span` tydens konstruksie gespesifiseer moet word.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Dieselfde as `Ident::new`, maar skep 'n rou identifiseerder (`r#ident`).
    /// Die `string`-argument is 'n geldige identifiseerder wat deur die taal toegelaat word (insluitend sleutelwoorde, bv. `fn`).
    /// Sleutelwoorde wat in paadsegmente gebruik kan word (bv
    /// `self`, 'super') word nie ondersteun nie en sal 'n panic veroorsaak.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Wys die spanwydte van hierdie `Ident`, wat die hele string wat deur [`to_string`](Self::to_string) teruggestuur word, omvat.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Stel die omvang van hierdie `Ident` op, en verander die higiëne-konteks moontlik.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, die brug bied slegs `to_string`, implementeer `fmt::Display` op grond daarvan (die omgekeerde van die gewone verhouding tussen die twee).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Druk die identifiseerder af as 'n string wat verliesloos omskepbaar moet word in dieselfde identifiseerder.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// 'N Letterlike string (`"hello"`), byte-string (`b"hello"`), karakter (`'a'`), byte-karakter (`b'a'`), 'n heelgetal of drywende puntgetal met of sonder agtervoegsel (' 1 ', `1u8`, `2.3`, `2.3f32`).
///
/// Booleaanse letterkundes soos `true` en `false` hoort nie hier nie, dit is `Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Skep 'n nuwe agtervoeglike heelgetal letterlik met die gespesifiseerde waarde.
        ///
        /// Hierdie funksie skep 'n heelgetal soos `1u32` waar die gespesifiseerde heelgetal die eerste deel van die token is en die integraal ook aan die einde sal agtervoeg.
        /// Letters wat uit negatiewe getalle geskep word, kan nie retoere deur `TokenStream` of snare oorleef nie en kan in twee tokens (`-` en positiewe letterlike) opgebreek word.
        ///
        ///
        /// Literêre wat met hierdie metode geskep word, het standaard die `Span::call_site()`-spanwydte, wat opgestel kan word met die `set_span`-metode hieronder.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Skep 'n nuwe nie-aangehegte heelgetal letterlik met die gespesifiseerde waarde.
        ///
        /// Hierdie funksie skep 'n heelgetal soos `1` waar die gespesifiseerde heelgetal die eerste deel van die token is.
        /// Geen agtervoegsel word op hierdie token gespesifiseer nie, wat beteken dat aanroepe soos `Literal::i8_unsuffixed(1)` gelykstaande is aan `Literal::u32_unsuffixed(1)`.
        /// Letters wat met negatiewe getalle geskep word, sal moontlik nie rontrips deur `TokenStream` of snare oorleef nie en kan in twee tokens (`-` en positiewe letterlike) opgebreek word.
        ///
        ///
        /// Literêre wat met hierdie metode geskep word, het standaard die `Span::call_site()`-spanwydte, wat opgestel kan word met die `set_span`-metode hieronder.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Skep 'n nuwe letterlike drywende punt wat nie aanmekaar gesit is nie.
    ///
    /// Hierdie konstrukteur is soortgelyk aan dié soos `Literal::i8_unsuffixed`, waar die float se waarde direk in die token uitgestraal word, maar geen agtervoegsel word gebruik nie, dus kan afgelei word dat dit later 'n `f64` in die samesteller is.
    ///
    /// Letters wat met negatiewe getalle geskep word, sal moontlik nie rontrips deur `TokenStream` of snare oorleef nie en kan in twee tokens (`-` en positiewe letterlike) opgebreek word.
    ///
    /// # Panics
    ///
    /// Hierdie funksie vereis dat die gespesifiseerde vlotter eindig is, byvoorbeeld as dit oneindig is of NaN sal hierdie funksie panic wees.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Skep 'n nuwe letterlike drywende punt agtervoegsel.
    ///
    /// Hierdie konstrukteur sal 'n letterlike vorm skep soos `1.0f32`, waar die gespesifiseerde waarde die voorafgaande gedeelte van die token is en `f32` die agtervoegsel van die token is.
    /// Hierdie token sal altyd afgelei word as 'n `f32` in die samesteller.
    /// Letters wat met negatiewe getalle geskep word, sal moontlik nie rontrips deur `TokenStream` of snare oorleef nie en kan in twee tokens (`-` en positiewe letterlike) opgebreek word.
    ///
    ///
    /// # Panics
    ///
    /// Hierdie funksie vereis dat die gespesifiseerde vlotter eindig is, byvoorbeeld as dit oneindig is of NaN sal hierdie funksie panic wees.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Skep 'n nuwe letterlike drywende punt wat nie aanmekaar gesit is nie.
    ///
    /// Hierdie konstrukteur is soortgelyk aan dié soos `Literal::i8_unsuffixed`, waar die float se waarde direk in die token uitgestraal word, maar geen agtervoegsel word gebruik nie, dus kan afgelei word dat dit later 'n `f64` in die samesteller is.
    ///
    /// Letters wat met negatiewe getalle geskep word, sal moontlik nie rontrips deur `TokenStream` of snare oorleef nie en kan in twee tokens (`-` en positiewe letterlike) opgebreek word.
    ///
    /// # Panics
    ///
    /// Hierdie funksie vereis dat die gespesifiseerde vlotter eindig is, byvoorbeeld as dit oneindig is of NaN sal hierdie funksie panic wees.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Skep 'n nuwe letterlike drywende punt agtervoegsel.
    ///
    /// Hierdie konstrukteur sal 'n letterlike vorm skep soos `1.0f64`, waar die gespesifiseerde waarde die voorafgaande gedeelte van die token is en `f64` die agtervoegsel van die token is.
    /// Hierdie token sal altyd afgelei word as 'n `f64` in die samesteller.
    /// Letters wat met negatiewe getalle geskep word, sal moontlik nie rontrips deur `TokenStream` of snare oorleef nie en kan in twee tokens (`-` en positiewe letterlike) opgebreek word.
    ///
    ///
    /// # Panics
    ///
    /// Hierdie funksie vereis dat die gespesifiseerde vlotter eindig is, byvoorbeeld as dit oneindig is of NaN sal hierdie funksie panic wees.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// String letterlik.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Karakter letterlik.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Byte snaar letterlik.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Wys die spanwydte wat hierdie letterlike omvat.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Stel die spanwydte in vir hierdie letterlike.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Wys 'n `Span` wat 'n deelversameling van `self.span()` is wat slegs die brongrepe in die reeks `range` bevat.
    /// Wys `None` as die afgesnyde span buite die perke van `self` is.
    ///
    // FIXME(SergioBenitez): kyk of die byte-reeks begin en eindig by 'n UTF-8-grens van die bron.
    // anders is dit waarskynlik dat 'n panic elders voorkom wanneer die bronteks gedruk word.
    // FIXME(SergioBenitez): daar is geen manier vir die gebruiker om te weet waarna `self.span()` eintlik karteer nie, en hierdie metode kan tans slegs blindelings genoem word.
    // Byvoorbeeld, `to_string()` vir die karakter 'c' gee "'\u{63}'" terug;die gebruiker kan nie weet of die bronteks 'c' was en of dit '\u{63}' was nie.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) iets soortgelyk aan `Option::cloned`, maar vir `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, die brug bied slegs `to_string`, implementeer `fmt::Display` op grond daarvan (die omgekeerde van die gewone verhouding tussen die twee).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Druk die letterlike as 'n tou wat verliesloos omskepbaar moet word in dieselfde letterlike (behalwe vir moontlike afronding vir letterlike drywende punte).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Toegang tot n omgewingsveranderlikes.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Kry 'n omgewingsveranderlike en voeg dit by om inligting oor afhanklikheid te bou.
    /// Die bou-stelsel wat die samesteller uitvoer, sal weet dat die veranderlike tydens die samestelling verkry is, en sal die build kan herhaal wanneer die waarde van die veranderlike verander.
    ///
    /// Behalwe die afhanklikheidsporing, moet hierdie funksie gelykstaande wees aan `env::var` uit die standaardbiblioteek, behalwe dat die argument UTF-8 moet wees.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}