//! 'N Dinamiese aansig in 'n aaneenlopende volgorde, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Snye is 'n aansig in 'n blok geheue wat voorgestel word as 'n wyser en 'n lengte.
//!
//! ```
//! // sny 'n Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // dwing 'n skikking na 'n sny
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Snye is óf veranderlik óf gedeel.
//! Die gedeelde snytipe is `&[T]`, terwyl die veranderlike snytipe `&mut [T]` is, waar `T` die elementtipe voorstel.
//! U kan byvoorbeeld die blok geheue waarna 'n veranderlike deel wys wysig:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Hier is 'n paar dinge wat hierdie module bevat:
//!
//! ## Structs
//!
//! Daar is verskeie strukte wat nuttig is vir snye, soos [`Iter`], wat iterasie oor 'n sny voorstel.
//!
//! ## Trait Implementasies
//!
//! Daar is verskeie implementerings van algemene traits vir snye.Enkele voorbeelde sluit in:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], vir snye waarvan die elementtipe [`Eq`] of [`Ord`] is.
//! * [`Hash`] - vir snye waarvan die elementtipe [`Hash`] is.
//!
//! ## Iteration
//!
//! Die snye implementeer `IntoIterator`.Die iterator gee verwysings na die snyelemente.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Die veranderlike sny lewer veranderlike verwysings na die elemente:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Hierdie iterator lewer veranderlike verwysings na die elemente van die sny, dus hoewel die elementtipe van die sny `i32` is, is die elementtipe van die iterator `&mut i32`.
//!
//!
//! * [`.iter`] en [`.iter_mut`] is die eksplisiete metodes om die verstek iteratore terug te gee.
//! * Verdere metodes wat iteratore terugstuur, is [`.split`], [`.splitn`], [`.chunks`], [`.windows`] en meer.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Baie van die gebruik in hierdie module word slegs in die toetskonfigurasie gebruik.
// Dit is skoner om net die ongebruikte_invoer-waarskuwing uit te skakel as om dit reg te stel.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Basiese snyuitbreidingsmetodes
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) benodig vir die implementering van die `vec!`-makro tydens die toets NB, sien die `hack`-module in hierdie lêer vir meer besonderhede.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) benodig vir die implementering van `Vec::clone` tydens die toets NB, sien die `hack`-module in hierdie lêer vir meer besonderhede.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Met cfg(test) `impl [T]` is nie beskikbaar nie, hierdie drie funksies is eintlik metodes wat in `impl [T]` is, maar nie in `core::slice::SliceExt` nie, ons moet hierdie funksies verskaf vir die `test_permutations`-toets
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Ons moet nie 'n ingeboude kenmerk hierby voeg nie, aangesien dit meestal in `vec!`-makro's gebruik word en perf regressie veroorsaak.
    // Sien #71204 vir bespreking en resultate.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // items is gemerk geïnitialiseer in die onderstaande lus
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) is nodig vir LLVM om perke-tjeks te verwyder en het 'n beter kode as zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // die vec is toegeken en hierbo geïnitialiseer tot ten minste hierdie lengte.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // hierbo toegeken met die kapasiteit van `s`, en begin na `s.len()` in ptr::copy_to_non_overlapping hieronder.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Sorteer die sny.
    ///
    /// Hierdie soort is stabiel (dws herorden nie gelyke elemente nie) en *O*(*n*\*log(* n*)) in die ergste geval.
    ///
    /// Indien van toepassing, word onstabiele sorteer verkies, omdat dit gewoonlik vinniger is as stabiele sorteer en dit nie geheue toeken nie.
    /// Sien [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Huidige implementering
    ///
    /// Die huidige algoritme is 'n aanpasbare, iteratiewe samesmeltingsoort geïnspireer deur [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Dit is ontwerp om baie vinnig te wees in gevalle waar die snit byna gesorteer is, of uit twee of meer gesorteerde rye bestaan wat die een na die ander saamgevoeg word.
    ///
    ///
    /// Dit ken tydelike berging toe wat die helfte van die grootte van `self` is, maar vir kort snye word 'n nie-toewysende invoegsoort gebruik.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Sorteer die sny met 'n vergelykingsfunksie.
    ///
    /// Hierdie soort is stabiel (dws herorden nie gelyke elemente nie) en *O*(*n*\*log(* n*)) in die ergste geval.
    ///
    /// Die vergelykingsfunksie moet 'n totale volgorde vir die elemente in die snit definieer.As die bestelling nie totaal is nie, is die volgorde van die elemente nie gespesifiseer nie.
    /// 'N Bestelling is 'n totale bestelling as dit is (vir alle `a`, `b` en `c`):
    ///
    /// * totaal en antisimmetries: presies een van `a < b`, `a == b` of `a > b` is waar, en
    /// * oorgang, `a < b` en `b < c` impliseer `a < c`.Dieselfde moet geld vir beide `==` en `>`.
    ///
    /// Terwyl [`f64`] byvoorbeeld nie [`Ord`] implementeer nie omdat `NaN != NaN`, kan ons `partial_cmp` as ons sorteerfunksie gebruik as ons weet dat die sny geen `NaN` bevat nie.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Indien van toepassing, word onstabiele sorteer verkies, omdat dit gewoonlik vinniger is as stabiele sorteer en dit nie geheue toeken nie.
    /// Sien [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Huidige implementering
    ///
    /// Die huidige algoritme is 'n aanpasbare, iteratiewe samesmeltingsoort geïnspireer deur [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Dit is ontwerp om baie vinnig te wees in gevalle waar die snit byna gesorteer is, of uit twee of meer gesorteerde rye bestaan wat die een na die ander saamgevoeg word.
    ///
    /// Dit ken tydelike berging toe wat die helfte van die grootte van `self` is, maar vir kort snye word 'n nie-toewysende invoegsoort gebruik.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // omgekeerde sorteer
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Sorteer die sny met 'n belangrike uittrekselfunksie.
    ///
    /// Hierdie soort is stabiel (dws herorden nie gelyke elemente nie) en *O*(*m*\* * n *\* log(*n*)) in die ergste geval, waar die sleutelfunksie *O*(*m*) is.
    ///
    /// Vir duur sleutelfunksies (bv
    /// funksies wat nie eenvoudige toegang tot eiendomme of basiese bewerkings is nie), sal [`sort_by_cached_key`](slice::sort_by_cached_key) waarskynlik aansienlik vinniger wees, aangesien dit nie elementsleutels herreken nie.
    ///
    ///
    /// Indien van toepassing, word onstabiele sorteer verkies, omdat dit gewoonlik vinniger is as stabiele sorteer en dit nie geheue toeken nie.
    /// Sien [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Huidige implementering
    ///
    /// Die huidige algoritme is 'n aanpasbare, iteratiewe samesmeltingsoort geïnspireer deur [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Dit is ontwerp om baie vinnig te wees in gevalle waar die snit byna gesorteer is, of uit twee of meer gesorteerde rye bestaan wat die een na die ander saamgevoeg word.
    ///
    /// Dit ken tydelike berging toe wat die helfte van die grootte van `self` is, maar vir kort snye word 'n nie-toewysende invoegsoort gebruik.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Sorteer die sny met 'n belangrike uittrekselfunksie.
    ///
    /// Tydens sorteer word die sleutelfunksie slegs een keer per element genoem.
    ///
    /// Hierdie soort is stabiel (dws rangskik nie gelyke elemente nie) en *O*(*m*\* * n *+* n *\* log(*n*)) in die ergste geval, waar die sleutelfunksie *O*(*m*) is .
    ///
    /// Vir eenvoudige sleutelfunksies (bv. Funksies wat toegang tot eiendom of basiese bewerkings het), sal [`sort_by_key`](slice::sort_by_key) waarskynlik vinniger wees.
    ///
    /// # Huidige implementering
    ///
    /// Die huidige algoritme is gebaseer op [pattern-defeating quicksort][pdqsort] van Orson Peters, wat die vinnige gemiddelde geval van ewekansige kwiksort met die vinnigste slegste geval van hopsort kombineer, terwyl lineêre tyd op snye met sekere patrone behaal word.
    /// Dit gebruik 'n mate van randomisering om ontaarde gevalle te vermy, maar met 'n vaste seed om altyd deterministiese gedrag te bied.
    ///
    /// In die ergste geval ken die algoritme tydelike berging toe in 'n `Vec<(K, usize)>` die lengte van die sny.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Helper-makro vir die indeksering van ons vector volgens die kleinste moontlike tipe, om die toewysing te verminder.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Die elemente van `indices` is uniek, aangesien dit geïndekseer is, en daarom sal enige vorm stabiel wees ten opsigte van die oorspronklike sny.
                // Ons gebruik `sort_unstable` hier omdat dit minder geheue toewys.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Kopieer `self` na 'n nuwe `Vec`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Hier kan `s` en `x` onafhanklik gewysig word.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Kopieer `self` in 'n nuwe `Vec` met 'n toewyser.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Hier kan `s` en `x` onafhanklik gewysig word.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, sien die `hack`-module in hierdie lêer vir meer besonderhede.
        hack::to_vec(self, alloc)
    }

    /// Skakel `self` om in 'n vector sonder klone of toekenning.
    ///
    /// Die resulterende vector kan weer in 'n boks omgeskakel word via 'Vec<T>se `into_boxed_slice`-metode.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` kan nie meer gebruik word nie omdat dit in `x` omgeskakel is.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, sien die `hack`-module in hierdie lêer vir meer besonderhede.
        hack::into_vec(self)
    }

    /// Skep 'n vector deur 'n sny `n` keer te herhaal.
    ///
    /// # Panics
    ///
    /// Hierdie funksie sal panic as die kapasiteit sou oorloop.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// 'N panic by oorloop:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // As `n` groter as nul is, kan dit as `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)` verdeel word.
        // `2^expn` is die getal wat voorgestel word deur die '1'-bit van `n` links, en `rem` is die oorblywende deel van `n`.
        //
        //

        // Gebruik `Vec` om toegang tot `set_len()` te kry.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` herhaling word gedoen deur `buf` `expn`-tye te verdubbel.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // As `m > 0`, is daar oorblywende bisse tot aan die linkerkantste '1'.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` het 'n kapasiteit van `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) herhaling word gedoen deur eerste `rem`-herhalings van `buf` self te kopieer.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Dit is nie-oorvleuelend sedert `2^expn > rem` nie.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` gelyk aan `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Maak 'n stuk `T` plat in 'n enkele waarde `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Maak 'n stuk `T` plat in 'n enkele waarde `Self::Output`, en plaas 'n gegewe skeiding tussen elkeen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Maak 'n stuk `T` plat in 'n enkele waarde `Self::Output`, en plaas 'n gegewe skeiding tussen elkeen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Wys 'n vector wat 'n kopie van hierdie sny bevat waarin elke byte gekoppel is aan die ASCII-hoofletter-ekwivalent.
    ///
    ///
    /// ASCII-letters 'a' tot 'z' word gekoppel aan 'A' tot 'Z', maar nie-ASCII-letters is onveranderd.
    ///
    /// Gebruik [`make_ascii_uppercase`] om die waarde in plek te hoofletter.
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Wys 'n vector wat 'n kopie van hierdie sny bevat, waar elke byte gekoppel is aan die ASCII-kleinletter-ekwivalent.
    ///
    ///
    /// ASCII-letters 'A' tot 'Z' word gekoppel aan 'a' tot 'z', maar nie-ASCII-letters is onveranderd.
    ///
    /// Gebruik [`make_ascii_lowercase`] om die waarde klein te maak.
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Uitbreiding traits vir snye oor spesifieke soorte data
////////////////////////////////////////////////////////////////////////////////

/// Helper trait vir [`[T]: : concat`](sny::concat).
///
/// Note: die parameter `Item` word nie in hierdie trait gebruik nie, maar dit laat impls meer generies wees.
/// Daarsonder kry ons die volgende fout:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Dit is omdat daar `V`-tipes met veelvuldige `Borrow<[_]>`-impls kan bestaan, sodat meerdere `T`-tipes van toepassing is:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Die gevolglike tipe na aaneenskakeling
    type Output;

    /// Implementering van [`[T]: : concat`](sny::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Helper trait vir [`[T]: : join`](sny::join)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Die gevolglike tipe na aaneenskakeling
    type Output;

    /// Implementering van [`[T]: : join`](sny::join)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Standaard trait implementasies vir snye
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // laat val enigiets in die teiken wat nie oorskryf sal word nie
        target.truncate(self.len());

        // target.len <= self.len as gevolg van die afkapping hierbo, dus die snye hier is altyd binne-in-grense.
        //
        let (init, tail) = self.split_at(target.len());

        // hergebruik die vervat waardes allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Voeg `v[0]` in die vooraf gesorteerde reeks `v[1..]` sodat die hele `v[..]` gesorteer word.
///
/// Dit is die integrale subroetine van invoegingsoort.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Daar is drie maniere om invoeging hier te implementeer:
            //
            // 1. Ruil aangrensende elemente om totdat die eerste een by sy eindbestemming kom.
            //    Op hierdie manier kopieer ons data egter meer as wat nodig is.
            //    As elemente groot strukture is (duur om te kopieer), sal hierdie metode stadig wees.
            //
            // 2. Iterasie totdat die regte plek vir die eerste element gevind word.
            // Skuif dan die elemente wat daarop volg om plek daarvoor te maak en plaas dit uiteindelik in die oorblywende gat.
            // Dit is 'n goeie metode.
            //
            // 3. Kopieer die eerste element in 'n tydelike veranderlike.Iterasie totdat die regte plek daarvoor gevind word.
            // Terwyl ons aangaan, kopieer elke deurgetrekte element in die gleuf wat dit voorafgaan.
            // Laastens, kopieer data van die tydelike veranderlike na die oorblywende gat.
            // Hierdie metode is baie goed.
            // Die maatstawwe het effens beter prestasie getoon as met die 2de metode.
            //
            // Al die metodes is vergelyk, en die 3de het die beste resultate getoon.Ons het dus die een gekies.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Die intermediêre toestand van die invoegproses word altyd gevolg deur `hole`, wat twee doeleindes dien:
            // 1. Beskerm die integriteit van `v` teen panics in `is_less`.
            // 2. Vul uiteindelik die oorblywende gat in `v`.
            //
            // Panic veiligheid:
            //
            // As `is_less` panics op 'n stadium tydens die proses plaasvind, sal `hole` val en die gat in `v` met `tmp` vul en sodoende verseker dat `v` steeds elke voorwerp wat hy aanvanklik presies een keer gehou het, vashou.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` word laat val en kopieer dus `tmp` in die oorblywende gat in `v`.
        }
    }

    // Wanneer dit afgelaai word, kopieer dit van `src` na `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Voeg nie-afnemende lopies `v[..mid]` en `v[mid..]` saam met `buf` as tydelike berging en stoor die resultaat in `v[..]`.
///
/// # Safety
///
/// Die twee snye moet nie leeg wees nie en `mid` moet binne perke wees.
/// Buffer `buf` moet lank genoeg wees om 'n kopie van die korter plak te hou.
/// `T` mag ook nie 'n nul-grootte tipe wees nie.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Die samesmeltingsproses kopieer eers die korter lopie na `buf`.
    // Dan word die nuut gekopieerde lopie en die langer vorentoe (of agtertoe) opgespoor, die volgende onverbruikte elemente vergelyk en die mindere (of groter) een in `v` gekopieër.
    //
    // Sodra die korter lopie ten volle verbruik is, is die proses afgehandel.As die langer lopie eers verbruik word, moet ons alles wat oorbly van die korter lopie in die oorblywende gat in `v` kopieer.
    //
    // Die tussentydse toestand van die proses word altyd gevolg deur `hole`, wat twee doeleindes dien:
    // 1. Beskerm die integriteit van `v` teen panics in `is_less`.
    // 2. Vul die oorblywende gat in `v` as die langtermyn eers verbruik word.
    //
    // Panic veiligheid:
    //
    // As `is_less` panics op 'n stadium tydens die proses plaasvind, sal `hole` val en die gat in `v` vul met die onverbruikte reeks in `buf`, wat verseker dat `v` steeds elke voorwerp wat hy aanvanklik presies een keer gehou het, vashou.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Die linkerlopie is korter.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Aanvanklik wys hierdie wenke op die begin van hul skikkings.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Verbruik die mindere kant.
            // As u gelyk is, verkies om die linkerkant te hou om stabiliteit te behou.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Die regte lopie is korter.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Aanvanklik wys hierdie wenke aan die einde van hul skikkings.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Verbruik die groter kant.
            // Indien gelyk, verkies die regte lopie om stabiliteit te handhaaf.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Uiteindelik word `hole` laat val.
    // As die korter lopie nie ten volle verbruik is nie, sal die reste daarvan nou in die gat in `v` gekopieër word.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Kopieer die reeks `start..end` na `dest..` as dit val.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` is nie 'n nulgrootte tipe nie, dus dit is goed om deur die grootte daarvan te deel.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Hierdie samesmelting leen enkele (maar nie al nie) idees van TimSort, wat in detail [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt) beskryf word.
///
///
/// Die algoritme identifiseer streng dalende en nie-dalende volgordes, wat natuurlike lopies genoem word.Daar is nog 'n stapel lopende lopies wat saamgevoeg moet word.
/// Elke nuutgevonde lopie word op die stapel gedruk, en dan word 'n paar pare aangrensende lopies saamgevoeg totdat die twee invariërs tevrede is:
///
/// 1. vir elke `i` in `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. vir elke `i` in `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Die invariërs sorg dat die totale looptyd *O*(*n*\*log(* n*)) ergste geval is).
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Snye van tot hierdie lengte word gesorteer volgens invoegsorteer.
    const MAX_INSERTION: usize = 20;
    // Baie kort lopies word uitgebrei met behulp van invoegsorteer om ten minste soveel elemente te bevat.
    const MIN_RUN: usize = 10;

    // Sortering het geen betekenisvolle gedrag op soorte nulgrootte nie.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Kort skikkings word op die plek gesorteer via invoegsorteer om toekennings te vermy.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Ken 'n buffer toe om dit as skrapgeheue te gebruik.Ons hou die lengte 0 sodat ons vlak afskrifte van die inhoud van `v` daarin kan hou sonder dat die dokters op kopieë loop as `is_less` panics.
    //
    // Wanneer twee gesorteerde lopies saamgevoeg word, hou hierdie buffer 'n afskrif van die korter lopie, wat altyd 'n lengte van hoogstens `len / 2` sal hê.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Om natuurlike lopies in `v` te identifiseer, beweeg ons dit agteruit.
    // Dit kan na 'n vreemde besluit lyk, maar beskou die feit dat samesmeltings vaker in die teenoorgestelde rigting gaan as (forwards).
    // Volgens maatstawwe is die samesmelting effens vinniger as om saam te smelt.
    // Om af te sluit, verbeter die prestasie om lopies te identifiseer deur agteruit te beweeg.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Soek die volgende natuurlike lopie en keer dit om as dit streng afneem.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Voeg nog 'n paar elemente in die lopie as dit te kort is.
        // Invoegingsorteer is vinniger as samevoegingsorteer op kort rye, dus verbeter dit die prestasie aansienlik.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Druk hierdie lopie op die stapel.
        runs.push(Run { start, len: end - start });
        end = start;

        // Voeg 'n paar pare aangrensende lopies saam om die inwoners te bevredig.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Uiteindelik moet presies een lopie in die stapel bly.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Ondersoek die stapel lopies en identifiseer die volgende paar lopies om saam te smelt.
    // Meer spesifiek, as `Some(r)` teruggestuur word, beteken dit dat `runs[r]` en `runs[r + 1]` volgende moet saamgevoeg word.
    // As die algoritme eerder 'n nuwe lopie wil voortbou, word `None` teruggestuur.
    //
    // TimSort is berug vir sy buggy-implementerings, soos hier beskryf:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Die kern van die verhaal is: ons moet die invariërs op die vier beste lopies op die stapel afdwing.
    // Die afdwing daarvan op net die top drie is nie voldoende om te verseker dat die invariërs steeds vir *alle* lopies in die stapel sal hou nie.
    //
    // Hierdie funksie kontroleer invariërs korrek vir die top vier lopies.
    // As die boonste lopie by indeks 0 begin, sal dit altyd 'n samesmeltingsbewerking vereis totdat die stapel volledig ingevou is om die sorteer te voltooi.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}