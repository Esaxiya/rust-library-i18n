use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Voeg alle sleutelwaarde-pare by van die samevoeging van twee stygende iteratore, en voeg 'n `length`-veranderlike langs die pad toe.Laasgenoemde maak dit makliker vir die oproeper om lekkasies te vermy wanneer 'n valhanteerder in paniek raak.
    ///
    /// As albei iteratore dieselfde sleutel produseer, laat hierdie metode die paar van die linker iterator af en voeg dit die paar van die regte iterator.
    ///
    /// As u wil hê dat die boom in 'n streng stygende volgorde moet beland, soos vir 'n `BTreeMap`, moet albei iteratore sleutels in streng stygende volgorde produseer, elk groter as alle sleutels in die boom, insluitend alle sleutels wat alreeds in die boom is.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Ons berei ons voor om `left` en `right` in 'n gesorteerde volgorde in lineêre tyd saam te voeg.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Intussen bou ons 'n boom uit die gesorteerde volgorde in lineêre tyd.
        self.bulk_push(iter, length)
    }

    /// Stoot alle sleutelwaarde-pare aan die einde van die boom en verhoog 'n `length`-veranderlike langs die pad.
    /// Laasgenoemde maak dit makliker vir die oproeper om lekkasies te vermy wanneer die iterator in paniek raak.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Itereer deur alle sleutelwaarde-pare en druk dit op die regte vlak in nodusse.
        for (key, value) in iter {
            // Probeer om sleutelwaarde-paar in die huidige blaarknoop te druk.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Geen plek oor nie, gaan op en druk daarheen.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Het 'n knoop gevind met spasie oor, druk hier.
                                open_node = parent;
                                break;
                            } else {
                                // Gaan weer op.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Ons is bo, skep 'n nuwe wortelknoop en druk daarheen.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Druk sleutel-waarde paar en nuwe regter subboom.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Gaan weer af na die regterkantste blaar.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Verhoog die lengte van elke iterasie om seker te maak dat die kaart die bygevoegde elemente laat val, selfs al word die iterator paniekerig.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// 'N Iterator om twee gesorteerde rye in een saam te voeg
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// As twee sleutels gelyk is, gee u die sleutelwaarde van die regte bron terug.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}