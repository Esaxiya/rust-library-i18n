// Dit is 'n poging tot 'n implementering na aanleiding van die ideaal
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Aangesien Rust nie afhanklike soorte en polimorfe rekursie het nie, maak ons genoeg onveiligheid.
//

// 'N Belangrike doel van hierdie module is om kompleksiteit te vermy deur die boom as 'n generiese (indien vreemd gevormde) houer te behandel en om die meeste van die B-Tree invariërs nie te hanteer nie.
//
// As sodanig kan hierdie module nie saak maak of die inskrywings gesorteer is nie, watter knooppunte ondervol kan wees of selfs wat ondervol beteken nie.Ons vertrou egter op 'n paar invariërs:
//
// - Bome moet uniform depth/height hê.Dit beteken dat elke pad af na 'n blaar van 'n gegewe knoop presies dieselfde lengte het.
// - 'N Knoop van lengte `n` het `n`-sleutels, `n`-waardes en `n + 1`-rande.
//   Dit impliseer dat selfs 'n leë node ten minste een edge het.
//   Vir 'n blaarknoop beteken "having an edge" slegs dat ons 'n posisie in die knoop kan identifiseer, aangesien blaarrande leeg is en geen data-voorstelling nodig het nie.
// In 'n interne knoop identifiseer 'n edge beide 'n posisie en bevat dit 'n wyser na 'n kinderknoop.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Die onderliggende voorstelling van blaarknope en 'n gedeelte van die voorstelling van interne knope.
struct LeafNode<K, V> {
    /// Ons wil mede-wisselvallig wees in `K` en `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Die indeks van hierdie knoop in die `edges`-skikking van die ouerknoop.
    /// `*node.parent.edges[node.parent_idx]` moet dieselfde wees as `node`.
    /// Dit sal eers gewaarborg word as `parent` nie-nul is.
    parent_idx: MaybeUninit<u16>,

    /// Die aantal sleutels en waardes wat hierdie node stoor.
    len: u16,

    /// Die skikkings wat die werklike data van die nodus stoor.
    /// Slegs die eerste `len`-elemente van elke skikking is geïnisialiseer en geldig.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Initialiseer 'n nuwe `LeafNode` in plek.
    unsafe fn init(this: *mut Self) {
        // As 'n algemene beleid laat ons velde nie-geïnitialiseer as dit kan, aangesien dit in Valgrind effens vinniger en makliker moet wees om op te spoor.
        //
        unsafe {
            // parent_idx, sleutels en vals is almal MaybeUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Skep 'n nuwe boks `LeafNode`.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Die onderliggende voorstelling van interne nodusse.Soos met 'LeafNode', moet dit agter 'BoxedNode`s weggesteek word om te verhoed dat sleutels en waardes wat nie geïnisialiseer is nie, val.
/// Enige aanwyser na 'n `InternalNode` kan direk na 'n aanwyser na die onderliggende `LeafNode`-gedeelte van die knoop gegooi word, sodat die kode generies op blaar-en interne knope kan werk, sonder om eers na te gaan op watter een die wyser wys.
///
/// Hierdie eiendom word geaktiveer deur die gebruik van `repr(C)`.
///
#[repr(C)]
// gdb_providers.py gebruik hierdie tipe naam vir introspeksie.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Die wenke vir die kinders van hierdie node.
    /// `len + 1` hiervan word as geïnitialiseerd en geldig beskou, behalwe dat sommige van hierdie wenke aan die einde hou, terwyl die boom deur middel van leenvorm `Dying` gehou word.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Skep 'n nuwe boks `InternalNode`.
    ///
    /// # Safety
    /// 'N Bestaande interne knooppunt is dat hulle ten minste een geïnisialiseerde en geldige edge het.
    /// Hierdie funksie stel nie so 'n edge op nie.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Ons hoef slegs die data te initialiseer;die rande is MaybeUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// 'N Beheerde, nie-nul aanwyser na 'n knooppunt.Dit is óf 'n aanwyser na `LeafNode<K, V>`, óf 'n aanwyser na `InternalNode<K, V>`.
///
/// `BoxedNode` bevat egter geen inligting oor watter een van die twee soorte nodusse dit eintlik bevat nie, en, gedeeltelik as gevolg van hierdie gebrek aan inligting, is dit nie 'n aparte tipe nie en het geen vernietiger nie.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Die wortelknoop van 'n boom wat besit word.
///
/// Let daarop dat dit nie 'n vernietiger het nie, en dat dit met die hand skoongemaak moet word.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Wys 'n nuwe boom, met sy eie wortelknoop wat aanvanklik leeg is.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` moet nie nul wees nie.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Leen die wortelknoop wat besit word, onderling.
    /// Anders as `reborrow_mut`, is dit veilig omdat die terugkeerwaarde nie gebruik kan word om die wortel te vernietig nie, en daar nie ander verwysings na die boom kan wees nie.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Leen die wortelknoop wat besit word effens veranderlik.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Oorkombaar gaan oor na 'n verwysing wat deurdringing toelaat en vernietigende metodes en min anders bied.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Voeg 'n nuwe interne knoop by met 'n enkele edge wat na die vorige wortelknoop wys, maak die nuwe knooppunt die wortelknoop en stuur dit terug.
    /// Dit verhoog die hoogte met 1 en is die teenoorgestelde van `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, behalwe dat ons net vergeet het dat ons nou intern is:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Verwyder die interne wortelknoop en gebruik die eerste kind as die nuwe wortelknoop.
    /// Aangesien dit slegs bedoel is om genoem te word as die wortelknoop net een kind het, word daar nie op enige van die sleutels, waardes en ander kinders opgeruim nie.
    ///
    /// Dit verminder die hoogte met 1 en is die teenoorgestelde van `push_internal_level`.
    ///
    /// Vereis eksklusiewe toegang tot die `Root`-voorwerp, maar nie tot die wortelknoop nie;
    /// dit sal nie ander handvatsels of verwysings na die wortelknoop ongeldig maak nie.
    ///
    /// Panics as daar geen interne vlak is nie, dws as die wortelknoop 'n blaar is.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // VEILIGHEID: ons beweer dat ons intern is.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // VEILIGHEID: ons het `self` eksklusief geleen en die leentipe is eksklusief.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // VEILIGHEID: die eerste edge word altyd geïnisialiseer.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` is altyd gesamentlik in `K` en `V`, selfs as die `BorrowType` `Mut` is.
// Dit is tegnies verkeerd, maar kan nie tot onveiligheid lei as gevolg van interne gebruik van `NodeRef` nie, want ons bly heeltemal generies oor `K` en `V`.
//
// Wanneer 'n publieke tipe `NodeRef` omvou, moet u egter seker maak dat dit die regte afwyking het.
//
/// 'N Verwysing na 'n knoop.
///
/// Hierdie tipe het 'n aantal parameters wat bepaal hoe dit optree:
/// - `BorrowType`: 'N Dummy-tipe wat die soort lening beskryf en 'n leeftyd dra.
///    - As dit `Immut<'a>` is, tree die `NodeRef` ongeveer soos `&'a Node` op.
///    - As dit `ValMut<'a>` is, tree die `NodeRef` ongeveer op soos `&'a Node` met betrekking tot sleutels en boomstruktuur, maar laat ook baie veranderlike verwysings na waardes in die boom bestaan.
///    - As dit `Mut<'a>` is, tree die `NodeRef` ongeveer soos `&'a mut Node` op, hoewel invoegmetodes 'n veranderlike wyser na 'n waarde laat bestaan.
///    - As dit `Owned` is, tree die `NodeRef` ongeveer soos `Box<Node>` op, maar het geen vernietiger nie en moet dit met die hand skoongemaak word.
///    - As dit `Dying` is, tree die `NodeRef` steeds ongeveer op soos `Box<Node>`, maar het hy metodes om die boom stukkie vir stukkie te vernietig, en gewone metodes, hoewel dit nie as onveilig gemerk is nie, kan UB oproep as dit verkeerd genoem word.
///
///   Aangesien enige `NodeRef` deur die boom kan navigeer, is `BorrowType` effektief op die hele boom van toepassing, nie net op die nodus nie.
/// - `K` en `V`: Dit is die soorte sleutels en waardes wat in die nodusse gestoor word.
/// - `Type`: Dit kan `Leaf`, `Internal` of `LeafOrInternal` wees.
/// As dit `Leaf` is, wys die `NodeRef` na 'n blaarknoop, as dit `Internal` is, wys die `NodeRef` na 'n interne knoop, en as dit `LeafOrInternal` is, kan die `NodeRef` na enige tipe knoop wys.
///   `Type` word `NodeType` genoem as dit buite `NodeRef` gebruik word.
///
/// Beide `BorrowType` en `NodeType` beperk die metodes wat ons gebruik om statiese tipe veiligheid te benut.Daar is beperkings op die manier waarop ons sulke beperkings kan toepas:
/// - Vir elke tipe parameter kan ons slegs 'n metode of vir een spesifieke tipe definieer.
/// Ons kan byvoorbeeld nie 'n metode soos `into_kv` generies definieer vir alle `BorrowType`, of een keer vir alle soorte wat 'n leeftyd dra nie, omdat ons wil hê dat dit `&'a`-verwysings moet terugstuur.
///   Daarom definieer ons dit slegs vir die minste kragtige tipe `Immut<'a>`.
/// - Ons kan nie implisiete dwang kry van byvoorbeeld `Mut<'a>` tot `Immut<'a>` nie.
///   Daarom moet ons `reborrow` eksplisiet op 'n kragtiger `NodeRef` aanroep om 'n metode soos `into_kv` te bereik.
///
/// Alle metodes op `NodeRef` wat die een of ander verwysing weergee, hetsy:
/// - Neem `self` volgens waarde en lewer die lewensduur van `BorrowType` terug.
///   Soms, om so 'n metode aan te roep, moet ons `reborrow_mut` skakel.
/// - Neem `self` as verwysing, en (implicitly) gee die verwysingsleeftyd terug in plaas van die leeftyd wat `BorrowType` dra.
/// Op hierdie manier waarborg die leenkontroleerder dat die `NodeRef` geleen bly solank die teruggekeerde verwysing gebruik word.
///   Die metodes wat die invoeging ondersteun, buig hierdie reël deur 'n rou wyser terug te gee, dws 'n verwysing sonder enige leeftyd.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Die aantal vlakke wat die knoop en die vlak van die blare uitmekaar het, 'n konstante van die knoop wat nie volledig deur `Type` beskryf kan word nie, en wat die knoop self nie stoor nie.
    /// Ons hoef slegs die hoogte van die wortelknoop op te slaan en die hoogte van elke ander knoop daaruit af te lei.
    /// Moet nul wees as `Type` `Leaf` is en nie-nul as `Type` `Internal` is.
    ///
    ///
    height: usize,
    /// Die wyser na die blaar of interne knoop.
    /// Die definisie van `InternalNode` verseker dat die wyser in elk geval geldig is.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Pak 'n nodusverwysing uit wat as `NodeRef::parent` verpak is.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Stel die data van 'n interne knoop bloot.
    ///
    /// Wys 'n onbewerkte ptr om nie ander verwysings na hierdie node ongeldig te maak nie.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // VEILIGHEID: die statiese nodus is `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Leen eksklusiewe toegang tot die data van 'n interne node.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Bepaal die lengte van die knooppunt.Dit is die aantal sleutels of waardes.
    /// Die aantal rande is `len() + 1`.
    /// Let daarop dat, alhoewel dit veilig is, die oproep van hierdie funksie die newe-effek kan hê van veranderende verwysings wat onveilige kode geskep het, ongeldig.
    ///
    pub fn len(&self) -> usize {
        // Dit is belangrik dat ons slegs hier toegang tot die `len`-veld kry.
        // As BorrowType marker::ValMut is, kan daar uitstaande veranderlike verwysings na waardes wees wat ons nie mag ongeldig maak nie.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Wys die aantal vlakke wat die nodus en blare van mekaar is.
    /// Nulhoogte beteken dat die knoop self 'n blaar is.
    /// As u bome voorstel met die wortel bo-aan, dan sê die nommer op watter hoogte die knoop verskyn.
    /// As u bome met blare bo-op sien, sê die nommer hoe hoog die boom bo die knooppunt strek.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Haal tydelik 'n ander, onveranderlike verwysing na dieselfde knoop uit.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Stel die blaargedeelte van enige blaar of interne knoop bloot.
    ///
    /// Wys 'n onbewerkte ptr om nie ander verwysings na hierdie node ongeldig te maak nie.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Die knoop moet ten minste geldig wees vir die LeafNode-gedeelte.
        // Dit is nie 'n verwysing in die NodeRef-tipe nie, want ons weet nie of dit uniek of gedeel moet wees nie.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Soek die ouer van die huidige node.
    /// Wys `Ok(handle)` as die huidige node eintlik 'n ouer het, waar `handle` wys na die edge van die ouer wat na die huidige node wys.
    ///
    /// Wys `Err(self)` as die huidige node geen ouer het nie, en gee die oorspronklike `NodeRef` terug.
    ///
    /// Die metode se naam veronderstel dat u bome afbeeld met die wortelknoop bo-aan.
    ///
    /// `edge.descend().ascend().unwrap()` en `node.ascend().unwrap().descend()` moet albei, na sukses, niks doen nie.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Ons moet rou aanwysers na nodusse gebruik, want as BorrowType marker::ValMut is, kan daar uitstaande veranderlike verwysings wees na waardes wat ons nie mag ongeldig maak nie.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Let daarop dat `self` nie vrygestel moet wees nie.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Let daarop dat `self` nie vrygestel moet wees nie.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Stel die blaargedeelte van enige blaar of interne knoop in 'n onveranderlike boom bloot.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // VEILIGHEID: daar kan geen veranderlike verwysings in hierdie boom wees wat as `Immut` geleen is nie.
        unsafe { &*ptr }
    }

    /// Leen 'n aansig in die sleutels wat in die knooppunt gestoor is.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Soortgelyk aan `ascend`, kry 'n verwysing na die ouerknoop van 'n node, maar plaas ook die huidige node in die proses.
    /// Dit is onveilig, want die huidige node sal steeds toeganklik wees, ondanks die feit dat dit geallokeer is.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Stel die samesteller onveilig die statiese inligting dat hierdie node 'n `Leaf` is.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Bevestig die statiese inligting onveilig aan die samesteller dat hierdie knoop 'n `Internal` is.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Haal tydelik 'n ander, veranderlike verwysing na dieselfde knoop uit.Pasop, aangesien hierdie metode baie gevaarlik is, dubbel so omdat dit dalk nie onmiddellik gevaarlik lyk nie.
    ///
    /// Omdat veranderlike aanwysers oral in die boom kan rondloop, kan die teruggekeerde wyser maklik gebruik word om die oorspronklike wyser hangend, buite perke of ongeldig te maak onder die gestapelde leenreëls.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) oorweeg dit om nog 'n tipe parameter by `NodeRef` te voeg wat die gebruik van navigasiemetodes op hergelaaide aanwysers beperk, wat hierdie onveiligheid voorkom.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Leen eksklusiewe toegang tot die blaargedeelte van enige blaar of interne knoop.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // VEILIGHEID: ons het eksklusiewe toegang tot die hele node.
        unsafe { &mut *ptr }
    }

    /// Bied eksklusiewe toegang tot die blaargedeelte van enige blaar of interne knoop.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // VEILIGHEID: ons het eksklusiewe toegang tot die hele node.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Leen eksklusiewe toegang tot 'n element van die sleutelbergingsarea.
    ///
    /// # Safety
    /// `index` is binne perke van 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // VEILIGHEID: die inbeller kan nie self verdere metodes oproep nie
        // totdat die sleutelstukverwysing laat vaar word, aangesien ons unieke toegang het vir die leeftyd van die lening.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Leen eksklusiewe toegang tot 'n element of deel van die waarde-opbergarea van die knooppunt.
    ///
    /// # Safety
    /// `index` is binne perke van 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // VEILIGHEID: die inbeller kan nie self verdere metodes oproep nie
        // totdat die waarde-snyverwysing laat vaar word, aangesien ons unieke toegang het vir die leeftyd van die lening.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Leen eksklusiewe toegang tot 'n element of deel van die stoorplek van die node vir edge-inhoud.
    ///
    /// # Safety
    /// `index` is binne perke van 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // VEILIGHEID: die inbeller kan nie self verdere metodes oproep nie
        // totdat die edge-snyverwysing laat vaar, aangesien ons unieke toegang het vir die leeftyd van die lening.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Die knoop het meer as `idx`-geïnisialiseerde elemente.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Ons skep slegs 'n verwysing na die een element waarin ons belangstel, om te verhoed dat die verwysing na uitstaande verwysings na ander elemente, veral die wat in vroeëre herhalings aan die oproeper teruggestuur is.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Ons moet dwing om nie-groot skyfwysers te gebruik vanweë die Rust-uitgawe #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Leen eksklusiewe toegang tot die lengte van die nodus.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Stel die skakel van die nodus na sy ouer edge, sonder om ander verwysings na die node ongeldig te maak.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Vee die skakel van die wortel na die ouer edge uit.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Voeg 'n sleutelwaarde-paar by aan die einde van die knoop.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Elke item wat deur `range` teruggestuur word, is 'n geldige edge-indeks vir die nodus.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Voeg 'n sleutelwaarde-paar by en 'n edge om regs van die paar te gaan, aan die einde van die knoop.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Kontroleer of 'n knoop 'n `Internal`-knoop of 'n `Leaf`-knoop is.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// 'N Verwysing na 'n spesifieke sleutelwaarde-paar of edge binne 'n node.
/// Die `Node`-parameter moet 'n `NodeRef` wees, terwyl die `Type` óf `KV` kan wees (wat 'n handvatsel op 'n sleutelwaarde-paar beteken) óf `Edge` (wat 'n handvatsel op 'n edge beteken).
///
/// Let daarop dat selfs `Leaf`-nodes `Edge`-handvatsels kan hê.
/// In plaas daarvan om 'n wyser na 'n kindernode voor te stel, stel dit die spasies voor waar kinderwysers tussen die sleutelwaarde-pare sou gaan.
/// In 'n knoop met lengte 2 sal daar byvoorbeeld 3 moontlike edge-plekke wees, een links van die knoop, een tussen die twee pare en een regs van die knoop.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Ons het nie die volle algemeenheid van `#[derive(Clone)]` nodig nie, aangesien die enigste keer dat `Node` 'gekloon' kan word, is dit 'n onveranderlike verwysing en dus `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Haal die knoop op wat die edge of sleutelwaarde-paar bevat waarop hierdie handvatsel wys.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Wys die posisie van hierdie handvatsel in die knooppunt.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Skep 'n nuwe handvatsel vir 'n sleutelwaarde-paar in `node`.
    /// Onveilig, want die oproeper moet verseker dat `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Dit kan 'n openbare implementering van PartialEq wees, maar slegs in hierdie module gebruik.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Haal tydelik nog 'n onveranderlike handvatsel op dieselfde plek uit.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Ons kan nie Handle::new_kv of Handle::new_edge gebruik nie, want ons ken nie ons tipe nie
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Bevestig die statiese inligting onveilig dat die knoppie van die handvatsel 'n `Leaf` is.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Haal tydelik 'n ander, veranderlike handvatsel op dieselfde plek uit.
    /// Pasop, aangesien hierdie metode baie gevaarlik is, dubbel so omdat dit dalk nie onmiddellik gevaarlik lyk nie.
    ///
    ///
    /// Vir meer besonderhede, sien `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Ons kan nie Handle::new_kv of Handle::new_edge gebruik nie, want ons ken nie ons tipe nie
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Skep 'n nuwe handvatsel vir 'n edge in `node`.
    /// Onveilig, want die oproeper moet verseker dat `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Gegewe 'n edge-indeks waar ons wil invoeg in 'n nodus wat gevul is, bereken 'n sinvolle KV-indeks van 'n splitpunt en waar om die invoeging uit te voer.
///
/// Die doel van die splitpunt is dat die sleutel en waarde daarvan in 'n ouerknoop beland;
/// die sleutels, waardes en kante links van die splitpunt word die linkerkind;
/// die sleutels, waardes en kante regs van die splitpunt word die regte kind.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust-uitgawe #74834 probeer om hierdie simmetriese reëls te verduidelik.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Voeg 'n nuwe sleutelwaarde-paar in tussen die sleutelwaarde-pare regs en links van hierdie edge.
    /// Hierdie metode gaan van die veronderstelling uit dat daar genoeg ruimte in die nodus is om die nuwe paar in te pas.
    ///
    /// Die teruggekeerde wyser wys na die ingevoegde waarde.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Voeg 'n nuwe sleutelwaarde-paar in tussen die sleutelwaarde-pare regs en links van hierdie edge.
    /// Hierdie metode verdeel die knoop as daar nie genoeg plek is nie.
    ///
    /// Die teruggekeerde wyser wys na die ingevoegde waarde.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Stel die ouerwyser en indeks in die kinderknoop reg waarna hierdie edge skakel.
    /// Dit is handig as die volgorde van rande verander is,
    fn correct_parent_link(self) {
        // Skep backpointer sonder om ander verwysings na die node ongeldig te maak.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Voeg 'n nuwe sleutelwaarde-paar in en 'n edge wat regs van die nuwe paar tussen hierdie edge en die sleutelwaarde-paar regs van hierdie edge gaan.
    /// Hierdie metode gaan van die veronderstelling uit dat daar genoeg ruimte in die nodus is om die nuwe paar in te pas.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Voeg 'n nuwe sleutelwaarde-paar in en 'n edge wat regs van die nuwe paar tussen hierdie edge en die sleutelwaarde-paar regs van hierdie edge gaan.
    /// Hierdie metode verdeel die knoop as daar nie genoeg plek is nie.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Voeg 'n nuwe sleutelwaarde-paar in tussen die sleutelwaarde-pare regs en links van hierdie edge.
    /// Hierdie metode verdeel die knoop as daar nie genoeg ruimte is nie en probeer om die afgesplitste gedeelte rekursief in die ouerknoop in te voeg totdat die wortel bereik is.
    ///
    ///
    /// As die teruggekeerde resultaat 'n `Fit` is, kan die knoppie van die handvatsel die edge-knoop of 'n voorouer wees.
    /// As die resultaat `Split` is, is die `left`-veld die wortelknoop.
    /// Die teruggekeerde wyser wys na die ingevoegde waarde.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Vind die knooppunt waarop hierdie edge wys.
    ///
    /// Die metode se naam veronderstel dat u bome afbeeld met die wortelknoop bo-aan.
    ///
    /// `edge.descend().ascend().unwrap()` en `node.ascend().unwrap().descend()` moet albei, na sukses, niks doen nie.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Ons moet rou aanwysers na nodusse gebruik, want as BorrowType marker::ValMut is, kan daar uitstaande veranderlike verwysings wees na waardes wat ons nie mag ongeldig maak nie.
        // U hoef nie toegang tot die hoogteveld te kry nie, want die waarde word gekopieër.
        // Pas op dat, sodra die knooppuntwyser herverwys word, ons toegang kry tot die rande-skikking met 'n verwysing (Rust-uitgawe #73987) en enige ander verwysings na of binne-in die skikking ongeldig word, sou dit voorkom.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Ons kan nie aparte sleutel-en waardemetodes noem nie, omdat die oproep na die tweede een die verwysing wat deur die eerste teruggestuur word, ongeldig maak.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Vervang die sleutel en waarde waarna die KV-handvatsel verwys.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Help die implementasies van `split` vir 'n bepaalde `NodeType`, deur die versorging van blaardata.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Verdeel die onderliggende knoop in drie dele:
    ///
    /// - Die knoop is afgekap om slegs die sleutelwaarde-pare links van hierdie handvatsel te bevat.
    /// - Die sleutel en waarde waarop hierdie handvatsel wys, word onttrek.
    /// - Al die sleutelwaarde-pare regs van hierdie handvatsel word in 'n pas toegekende knoop geplaas.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Verwyder die sleutelwaarde-paar waarop hierdie handvatsel verwys en stuur dit terug, tesame met die edge waarin die sleutelwaarde-paar ineengestort het.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Verdeel die onderliggende knoop in drie dele:
    ///
    /// - Die knoop is afgekap om slegs die rande en sleutelwaarde-pare links van hierdie handvatsel te bevat.
    /// - Die sleutel en waarde waarop hierdie handvatsel wys, word onttrek.
    /// - Al die rande en sleutelwaarde-pare regs van hierdie handvatsel word in 'n pas toegekende knoop geplaas.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Verteenwoordig 'n sessie vir die evaluering en uitvoering van 'n balanseringsoperasie rondom 'n interne sleutelwaarde-paar.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Kies 'n balanserende konteks wat die knoop as kind betrek, dus tussen die KV onmiddellik na links of regs in die ouerknoop.
    /// Wys 'n `Err` as daar geen ouer is nie.
    /// Panics as die ouer leeg is.
    ///
    /// Verkies die linkerkant om optimaal te wees as die gegewe knoop op die een of ander manier ondervol is, wat hier slegs beteken dat dit minder elemente het as sy linker broer of suster as dit reg is.
    /// In daardie geval is die samesmelting met die linker broer of suster vinniger, omdat ons slegs die N-elemente van die knoop hoef te skuif in plaas daarvan om dit na regs te skuif en meer as N-elemente voor te skuif.
    /// Die steel van die linker broer of suster is gewoonlik ook vinniger, want ons hoef slegs die N-elemente van die knoop na regs te skuif in plaas daarvan om ten minste N van die broer of suster se elemente na links te skuif.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Wys of samesmelting moontlik is, dws of daar genoeg ruimte in 'n knoop is om die sentrale KV met albei aangrensende kindernodusse te kombineer.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Voer 'n samesmelting uit en laat 'n sluiting besluit wat om terug te stuur.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // VEILIGHEID: die hoogte van die nodusse wat saamgevoeg word, is een onder die hoogte
                // van die knoop van hierdie edge, dus bo nul, sodat hulle intern is.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Voeg die sleutelwaarde-paar van die ouer en albei aangrensende kindernodes saam in die linker kinderknoop en gee die gekrimpte ouerknoop terug.
    ///
    ///
    /// Panics tensy ons `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Voeg die ouer se sleutel-waarde-paar en albei aangrensende kindernodes saam in die linker-kinderknoop en gee die kinderknoop terug.
    ///
    ///
    /// Panics tensy ons `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Voeg die ouer se sleutel-waardepaar en albei aangrensende kindernodes saam in die linker kinderknoop en gee die edge-handvatsel terug in die kinderknoop waar die nagespoorde kind edge beland het,
    ///
    ///
    /// Panics tensy ons `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Verwyder 'n sleutelwaarde-paar van die linkerkind en plaas dit in die sleutelwaarde-opberging van die ouer, terwyl die ou ouer-sleutelwaarde-paar in die regte kind gedruk word.
    ///
    /// Stuur 'n handvatsel terug na die edge in die regte kind wat ooreenstem met die oorspronklike edge wat deur `track_right_edge_idx` gespesifiseer is.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Verwyder 'n sleutelwaarde-paar van die regte kind en plaas dit in die sleutelwaarde-opberging van die ouer, terwyl die ou ouer-sleutelwaarde-paar op die linker kind gedruk word.
    ///
    /// Stuur 'n handvatsel terug na die edge in die linkerkind soos aangedui deur `track_left_edge_idx`, wat nie beweeg het nie.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Dit steel wel soos `steal_left`, maar steel verskeie elemente tegelyk.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Sorg dat ons veilig kan steel.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Skuif blaardata.
            {
                // Maak plek vir gesteelde elemente by die regte kind.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Skuif elemente van die linker kind na die regte een.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Skuif die gesteelde paar links na die ouer.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Skuif ouer se sleutelwaarde-paar na die regte kind.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Maak plek vir gesteelde kante.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Steel kante.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Die simmetriese kloon van `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Sorg dat ons veilig kan steel.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Skuif blaardata.
            {
                // Skuif die paar wat die regs gesteel is, na die ouer.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Skuif ouer se sleutelwaarde-paar na die linkerkant.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Skuif elemente van die regterkind na die linkerkant.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Vul die gaping waar vroeër gesteelde elemente was.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Steel kante.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Vul die gaping in die plek waar gesteelde rante was.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Verwyder alle statiese inligting wat beweer dat hierdie node 'n `Leaf`-node is.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Verwyder alle statiese inligting wat beweer dat hierdie node 'n `Internal`-node is.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Kontroleer of die onderliggende knoop 'n `Internal`-knoop of 'n `Leaf`-knoop is.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Skuif die agtervoegsel na `self` van een node na 'n ander.`right` moet leeg wees.
    /// Die eerste edge van `right` bly onveranderd.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Resultaat van invoeging, wanneer 'n nodus buite sy vermoë moes uitbrei.
pub struct SplitResult<'a, K, V, NodeType> {
    // Veranderde knoop in bestaande boom met elemente en kante wat aan die linkerkant van `kv` behoort.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Sommige sleutel en waarde word verdeel om elders ingevoeg te word.
    pub kv: (K, V),
    // Besit, onaangebind, nuwe knooppunt met elemente en kante wat regs van `kv` behoort.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Of knooppuntverwysings van hierdie leen-tipe dit moontlik maak om na ander nodusse in die boom te beweeg.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversering is nie nodig nie, dit gebeur met behulp van die resultaat van `borrow_mut`.
        // Deur traversering uit te skakel en slegs nuwe verwysings na wortels te skep, weet ons dat elke verwysing van die `Owned`-tipe na 'n wortelknoop is.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Voeg 'n waarde in 'n gedeelte geïnitialiseerde elemente, gevolg deur een ongeïnisialiseerde element.
///
/// # Safety
/// Die sny het meer as `idx`-elemente.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Verwyder en gee 'n waarde terug uit 'n deel van alle geïnisialiseerde elemente, en laat een agtergeblewe ongeïnitialiseerde element agter.
///
///
/// # Safety
/// Die sny het meer as `idx`-elemente.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Skuif die elemente in 'n sny `distance` posisies na links.
///
/// # Safety
/// Die sny bevat ten minste `distance` elemente.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Skuif die elemente in 'n sny `distance`-posisies na regs.
///
/// # Safety
/// Die sny bevat ten minste `distance` elemente.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Skuif alle waardes van 'n deel geïnitialiseerde elemente na 'n deel van nie-geïnitialiseerde elemente, en laat `src` agter as alle ongeïnisialiseerde.
///
/// Werk soos `dst.copy_from_slice(src)`, maar vereis nie dat `T` `Copy` is nie.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;