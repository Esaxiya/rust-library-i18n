use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Haal tydelik 'n ander, onveranderlike ekwivalent van dieselfde reeks uit.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Bepaal die onderskeie blaarrande wat 'n bepaalde reeks in 'n boom afbaken.
    /// Wys 'n paar verskillende handvatsels in dieselfde boom of 'n paar leë opsies.
    ///
    /// # Safety
    ///
    /// Tensy `BorrowType` `Immut` is, moet u nie die dubbele handvatsels gebruik om dieselfde KV twee keer te besoek nie.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Ekwivalent aan `(root1.first_leaf_edge(), root2.last_leaf_edge())`, maar meer doeltreffend.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Vind die paar blaarrande wat 'n spesifieke reeks in 'n boom afbaken.
    ///
    /// Die resultaat is slegs betekenisvol as die boom volgens sleutel bestel word, soos die boom in 'n `BTreeMap` is.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // VEILIGHEID: ons leentipe is onveranderlik.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Vind die paar blaarrande wat 'n hele boom afbaken.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Verdeel 'n unieke verwysing in 'n paar blaarrande wat 'n bepaalde reeks afbaken.
    /// Die resultaat is nie-unieke verwysings wat (some)-mutasie toelaat, wat versigtig gebruik moet word.
    ///
    /// Die resultaat is slegs betekenisvol as die boom volgens sleutel bestel word, soos die boom in 'n `BTreeMap` is.
    ///
    ///
    /// # Safety
    /// Moenie die dubbele handvatsels gebruik om dieselfde KV twee keer te besoek nie.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Verdeel 'n unieke verwysing in 'n paar blaarrande wat die volle omvang van die boom afbaken.
    /// Die resultate is nie-unieke verwysings wat mutasie toelaat (slegs van waardes), en moet dus met omsigtigheid gebruik word.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Ons dupliseer die wortel NodeRef hier-ons sal nooit dieselfde KV twee keer besoek nie en nooit met oorvleuelende waardeverwysings beland nie.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Verdeel 'n unieke verwysing in 'n paar blaarrande wat die volle omvang van die boom afbaken.
    /// Die resultate is nie-unieke verwysings wat massiewe vernietigende mutasie toelaat, en moet dus met die grootste sorg gebruik word.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Ons dupliseer die wortel NodeRef hier-ons sal nooit toegang daartoe verkry op 'n manier wat verwysings verkry vanaf die wortel oorvleuel nie.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Gegee 'n blaar edge-handvatsel, gee [`Result::Ok`] met 'n handvatsel terug na die naburige KV aan die regterkant, wat óf in dieselfde blaarknoop is óf in 'n voorvaderknoop.
    ///
    /// As die blaar edge die laaste in die boom is, gee [`Result::Err`] terug met die wortelknoop.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Gegee 'n blad edge-handvatsel, gee [`Result::Ok`] met 'n handvatsel terug na die naburige KV aan die linkerkant, wat óf in dieselfde blaarknoop is óf in 'n voorvaderknoop.
    ///
    /// As die blaar edge die eerste in die boom is, gee dit [`Result::Err`] met die wortelknoop.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Gegewe 'n interne edge-handvatsel, gee [`Result::Ok`] met 'n handvatsel terug na die naburige KV aan die regterkant, wat óf in dieselfde interne node is, óf in 'n voorvader-node.
    ///
    /// As die interne edge die laaste een in die boom is, gee u [`Result::Err`] terug met die wortelknoop.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Gegee 'n blaar edge-handvatsel in 'n sterwende boom, gee die volgende blaar edge aan die regterkant terug, en die sleutelwaarde-paar tussenin, wat óf in dieselfde blaarknoop is, in 'n voorvaderknoop of nie bestaan nie.
    ///
    ///
    /// Hierdie metode handel ook oor enige node(s) waarna dit aan die einde kom.
    /// Dit impliseer dat as daar nie meer 'n sleutelwaarde-paar bestaan nie, die hele restant van die boom herdeel is en daar niks meer is om terug te keer nie.
    ///
    /// # Safety
    /// Die gegewe edge mag nie voorheen deur die eweknie `deallocating_next_back` teruggestuur word nie.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Gegee 'n blaar edge-handvatsel in 'n sterwende boom, gee die volgende blaar edge aan die linkerkant terug, en die sleutelwaarde-paar tussenin, wat óf in dieselfde blaarknoop is, in 'n voorvaderknoop, of nie bestaan nie.
    ///
    ///
    /// Hierdie metode handel ook oor enige node(s) waarna dit aan die einde kom.
    /// Dit impliseer dat as daar nie meer 'n sleutelwaarde-paar bestaan nie, die hele restant van die boom herdeel is en daar niks meer is om terug te keer nie.
    ///
    /// # Safety
    /// Die gegewe edge mag nie voorheen deur die eweknie `deallocating_next` teruggestuur word nie.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Verdeling van 'n stapel knope vanaf die blaar tot by die wortel.
    /// Dit is die enigste manier om die res van 'n boom te herplaas nadat `deallocating_next` en `deallocating_next_back` aan albei kante van die boom geknibbel het en dieselfde edge getref het.
    /// Aangesien dit slegs bedoel is om gebel te word wanneer alle sleutels en waardes teruggestuur is, word geen skoonmaak van een van die sleutels of waardes gedoen nie.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Skuif die blaar edge-handvatsel na die volgende blaar edge en gee verwysings na die sleutel en waarde tussenin.
    ///
    ///
    /// # Safety
    /// Daar moet nog 'n KV in die rigting wees.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Beweeg die blaar edge-handvatsel na die vorige blaar edge en gee verwysings na die sleutel en waarde tussenin.
    ///
    ///
    /// # Safety
    /// Daar moet nog 'n KV in die rigting wees.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Skuif die blaar edge-handvatsel na die volgende blaar edge en gee verwysings na die sleutel en waarde tussenin.
    ///
    ///
    /// # Safety
    /// Daar moet nog 'n KV in die rigting wees.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Dit is volgens maatstawwe vinniger om dit laaste te doen.
        kv.into_kv_valmut()
    }

    /// Beweeg die blaar edge-handvatsel na die vorige blaar en gee verwysings na die sleutel en waarde tussenin.
    ///
    ///
    /// # Safety
    /// Daar moet nog 'n KV in die rigting wees.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Dit is volgens maatstawwe vinniger om dit laaste te doen.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Skuif die blaar edge-handvatsel na die volgende blaar edge en gee die sleutel en waarde tussenin terug, en plaas die nodige knooppunt op terwyl die ooreenstemmende edge in sy ouerknoop hang.
    ///
    /// # Safety
    /// - Daar moet nog 'n KV in die rigting wees.
    /// - Die KV is nie voorheen deur die eweknie `next_back_unchecked` teruggestuur op enige kopie van die handvatsels wat deur die boom gebruik is nie.
    ///
    /// Die enigste veilige manier om met die opgedateerde handvatsel voort te gaan, is om dit te vergelyk, te laat val, hierdie metode weer op te roep onderhewig aan sy veiligheidsvoorwaardes, of om eweknie `next_back_unchecked` te skakel onderhewig aan die veiligheidsvoorwaardes.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Beweeg die blaar edge-handvatsel na die vorige blaar edge en gee die sleutel en waarde tussenin terug, en plaas die nodige knooppunt terug terwyl die ooreenstemmende edge in sy ouerknoop hang.
    ///
    /// # Safety
    /// - Daar moet nog 'n KV in die rigting wees.
    /// - Die blad edge is nie voorheen deur die eweknie `next_unchecked` teruggestuur op enige kopie van die handvatsels wat gebruik is om deur die boom te beweeg nie.
    ///
    /// Die enigste veilige manier om met die opgedateerde handvatsel voort te gaan, is om dit te vergelyk, te laat val, hierdie metode weer op te roep onderhewig aan die veiligheidsvoorwaardes daarvan, of om die eweknie `next_unchecked` te skakel onderhewig aan die veiligheidsvoorwaardes.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Wys die linkerblad edge in of onder 'n knoop, met ander woorde die edge wat u eers benodig as u vorentoe navigeer (of laaste as u agtertoe navigeer).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Wys die regterkantste blad edge in of onder 'n knoop, met ander woorde die edge wat u die laaste keer benodig wanneer u vorentoe navigeer (of eers as u agtertoe navigeer).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Besoek bladknope en interne KV's in volgorde van stygende sleutels, en besoek ook interne knope as geheel in 'n diepte eerste orde, wat beteken dat interne knope hul individuele KV's en hul kindernodusse voorafgaan.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Bereken die aantal elemente in 'n (sub) boom.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Wys die blad edge wat die naaste aan 'n KV is vir voorwaartse navigasie.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Wys die blad edge wat die naaste aan 'n KV is vir terugwaartse navigasie.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}