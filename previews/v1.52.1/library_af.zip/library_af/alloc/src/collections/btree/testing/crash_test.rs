use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// 'N Bloudruk vir ongelukstoestandgevalle wat spesifieke gebeure monitor.
/// Sommige gevalle kan op 'n sekere tyd op panic ingestel wees.
/// Gebeurtenisse is `clone`, `drop` of 'n anonieme `query`.
///
/// Botsingstoets-dummies word geïdentifiseer en deur 'n ID georden, sodat dit as sleutels in 'n BTreeMap gebruik kan word.
/// Die implementering wat doelbewus gebruik word, berus nie op enigiets wat in die crate gedefinieer word nie, behalwe die `Debug` trait.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// Skep 'n botsingstoets-ontwerp-ontwerp.Die `id` bepaal die orde en gelykheid van gevalle.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// Skep 'n instansie van 'n botsingstoets-dummy wat opneem watter gebeure dit ervaar en opsioneel panics.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// Wys hoeveel keer gevalle van die dummy gekloon is.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// Wys hoeveel keer gevalle van die dummy laat val is.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// Wys terug hoeveel keer hul `query`-lid die gevalle van die dummy aangeroep het.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// Sommige anonieme navrae waarvan die resultaat reeds gegee word.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}