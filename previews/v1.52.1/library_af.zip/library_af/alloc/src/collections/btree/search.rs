use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// 'N Inklusiewe keuse, net soos `Bound::Included(T)`.
    Included(T),
    /// 'N Eksklusiewe keuse, net soos `Bound::Excluded(T)`.
    Excluded(T),
    /// 'N Onvoorwaardelike inklusiewe verband, net soos `Bound::Unbounded`.
    AllIncluded,
    /// 'N Onvoorwaardelike eksklusiewe band.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Soek rekursief 'n gegewe sleutel in 'n (sub) boom wat deur die knooppunt gelei word.
    /// Lewer 'n `Found` met die handvatsel van die bypassende KV, indien enige.
    /// Andersins, stuur 'n `GoDown` terug met die handvatsel van die blad edge waar die sleutel hoort.
    ///
    /// Die resultaat is slegs betekenisvol as die boom volgens sleutel bestel word, soos die boom in 'n `BTreeMap` is.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// Daal af na die naaste knooppunt waar die edge wat ooreenstem met die onderste grens van die reeks, verskil van die edge wat ooreenstem met die boonste grens, dws die naaste node wat ten minste een sleutel in die reeks bevat.
    ///
    ///
    /// As dit gevind word, word 'n `Ok` met die nodus teruggestuur, die paar edge-indekse daarin wat die reeks afbaken en die ooreenstemmende paar perke om die soektog in die kindernodusse voort te sit, in geval die node intern is.
    ///
    /// As dit nie gevind word nie, word 'n `Err` teruggestuur met die blad edge wat ooreenstem met die hele reeks.
    ///
    /// Die resultaat is slegs betekenisvol as die boom per sleutel bestel word.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Dit moet vermy word om hierdie veranderlikes in te lig.
        // Ons neem aan dat die perke wat deur `range` gerapporteer is, dieselfde bly, maar 'n kontrasimplementering kan verander tussen oproepe (#81138).
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// Vind 'n edge in die knoop wat die onderste grens van 'n reeks afbaken.
    /// Retourneer ook die onderste grens wat gebruik moet word om die soektog in die bypassende kinderknoop voort te sit, as `self` 'n interne knoop is.
    ///
    ///
    /// Die resultaat is slegs betekenisvol as die boom per sleutel bestel word.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// Kloon van `find_lower_bound_edge` vir die boonste grens.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Soek 'n gegewe sleutel in die node sonder rekursie.
    /// Lewer 'n `Found` met die handvatsel van die bypassende KV, indien enige.
    /// Andersins, stuur 'n `GoDown` terug met die handvatsel van die edge waar die sleutel gevind kan word (as die knoop intern is) of waar die sleutel ingevoeg kan word.
    ///
    ///
    /// Die resultaat is slegs betekenisvol as die boom volgens sleutel bestel word, soos die boom in 'n `BTreeMap` is.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// Wys die KV-indeks in die knoop waarop die sleutel (of 'n ekwivalent) bestaan, of die edge-indeks waar die sleutel behoort.
    ///
    ///
    /// Die resultaat is slegs betekenisvol as die boom volgens sleutel bestel word, soos die boom in 'n `BTreeMap` is.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// Vind 'n edge-indeks in die knooppunt wat die onderste grens van 'n reeks afbaken.
    /// Retourneer ook die onderste grens wat gebruik moet word om die soektog in die bypassende kinderknoop voort te sit, as `self` 'n interne knoop is.
    ///
    ///
    /// Die resultaat is slegs betekenisvol as die boom per sleutel bestel word.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// Kloon van `find_lower_bound_index` vir die boonste grens.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}