use core::marker::PhantomData;
use core::ptr::NonNull;

/// Modelleer 'n herlaai van een of ander unieke verwysing as u weet dat die herlaai en al sy nasate (dws alle wenke en verwysings daaruit afgelei) nie op 'n stadium meer gebruik sal word nie, waarna u die oorspronklike unieke verwysing weer wil gebruik .
///
///
/// Die leningkontrole hanteer gewoonlik hierdie stapel van lenings vir u, maar sommige beheervloeie wat hierdie stapeling bewerkstellig, is te ingewikkeld om die samesteller te volg.
/// Met 'n `DormantMutRef` kan u die lenings self nagaan, terwyl u die gestapelde aard daarvan uitdruk, en die rou kode-kode wat u nodig het om dit te doen, omsluit sonder ongedefinieerde gedrag.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Vang 'n unieke lening en herlaai dit onmiddellik.
    /// Vir die samesteller is die lewensduur van die nuwe verwysing dieselfde as die leeftyd van die oorspronklike verwysing, maar u promise om dit vir 'n korter tydperk te gebruik.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // VEILIGHEID: ons hou die lening regdeur 'a via `_marker`, en ons stel dit bloot
        // slegs hierdie verwysing, so dit is uniek.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Gaan terug na die unieke lening wat aanvanklik vasgelê is.
    ///
    /// # Safety
    ///
    /// Die herlaai moet geëindig het, dws die verwysing wat deur `new` teruggestuur word en alle aanwysings en verwysings daaruit, mag nie meer gebruik word nie.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // VEILIGHEID: ons eie veiligheidsvoorwaardes impliseer dat hierdie verwysing weer uniek is.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;