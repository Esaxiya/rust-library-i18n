/// Skep 'n [`Vec`] wat die argumente bevat.
///
/// `vec!` kan 'Vec`s gedefinieer word met dieselfde sintaksis as skikkinguitdrukkings.
/// Daar is twee vorme van hierdie makro:
///
/// - Skep 'n [`Vec`] met 'n gegewe lys elemente:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Skep 'n [`Vec`] uit 'n gegewe element en grootte:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Let daarop dat hierdie sintaksis, in teenstelling met skikkinguitdrukkings, alle elemente ondersteun wat [`Clone`] implementeer en dat die aantal elemente nie konstant hoef te wees nie.
///
/// Dit sal `clone` gebruik om 'n uitdrukking te dupliseer, dus moet u versigtig wees om dit te gebruik met tipes wat 'n nie-standaard `Clone`-implementering het.
/// Byvoorbeeld, `vec![Rc::new(1);5] `sal 'n vector skep van vyf verwysings na dieselfde boksgetalwaarde, nie vyf verwysings wat na onafhanklike boksgetalle verwys nie.
///
///
/// Let ook daarop dat `vec![expr; 0]` toegelaat is en 'n leë vector produseer.
/// Dit sal `expr` egter steeds evalueer en die resulterende waarde onmiddellik laat val, dus let op newe-effekte.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): met cfg(test) is die inherente `[T]::into_vec`-metode, wat nodig is vir hierdie makro-definisie, nie beskikbaar nie.
// Gebruik eerder die `slice::into_vec`-funksie wat slegs beskikbaar is met cfg(test) LET WEL, kyk na die slice::hack-module in slice.rs vir meer inligting
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Skep 'n `String` met behulp van interpolasie van runtime-uitdrukkings.
///
/// Die eerste argument wat `format!` ontvang, is 'n formaatreeks.Dit moet letterlik streng wees.Die krag van die opmaakstring is in die '{}' s vervat.
///
/// Bykomende parameters wat aan `format!` oorgedra word, vervang die '{}' s in die opmaakstring in die gegewe volgorde, tensy benoemde of posisionele parameters gebruik word;sien [`std::fmt`] vir meer inligting.
///
///
/// 'N Algemene gebruik vir `format!` is aaneenskakeling en interpolasie van snare.
/// Dieselfde konvensie word gebruik met [`print!`]-en [`write!`]-makro's, afhangende van die beoogde bestemming van die string.
///
/// Gebruik die [`to_string`]-metode om 'n enkele waarde in 'n string om te skakel.Dit sal die [`Display`]-opmaak trait gebruik.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics as 'n formatering van die implementering van trait 'n fout oplewer.
/// Dit dui op 'n verkeerde implementering, aangesien `fmt::Write for String` nooit self 'n fout teruggee nie.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Dwing die AST-knoop na 'n uitdrukking om die diagnose in patroonposisie te verbeter.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}