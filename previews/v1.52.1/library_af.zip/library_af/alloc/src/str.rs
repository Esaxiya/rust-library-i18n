//! Unicode-snytjies.
//!
//! *[See also the `str` primitive type](str).*
//!
//! Die `&str`-tipe is een van die twee hoofstryktipes, die ander is `String`.
//! In teenstelling met die `String`-eweknie, word die inhoud geleen.
//!
//! # Basiese gebruik
//!
//! 'N Basiese stringverklaring van die `&str`-tipe:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! Hier het ons 'n string letterlik verklaar, ook bekend as 'n string sny.
//! String letterkundiges het 'n statiese leeftyd, wat beteken dat die string `hello_world` gewaarborg is vir die duur van die hele program.
//!
//! Ons kan ook die uitdrukking van 'hallo_wêreld' spesifiseer:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// Baie van die gebruik in hierdie module word slegs in die toetskonfigurasie gebruik.
// Dit is skoner om net die ongebruikte_invoer-waarskuwing uit te skakel as om dit reg te stel.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `str` in `Concat<str>` is hier nie betekenisvol nie.
/// Hierdie tipe parameter van die trait bestaan slegs om 'n ander impl.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // lusse met hardgekodeerde groottes loop baie vinniger, spesialiseer die tasse met klein skeidingslengtes
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // arbitrêre terugval van nie-nul grootte
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Geoptimaliseerde aansluitimplementering wat vir beide Vec werk<T>(T: Copy) en String se binneste vec Tans is daar (2018-05-13) 'n fout met tipe afleiding en spesialisasie (sien uitgawe #36262) Om hierdie rede SliceConcat<T>is nie gespesialiseerd vir T: Copy en SliceConcat nie<str>is die enigste gebruiker van hierdie funksie.
// Dit word gelaat vir die tyd wanneer dit reggestel word.
//
// die perke vir String-join is S: Borrow<str>en vir Vec-join Leen <[T]> [T] en str albei impl AsRef <[T]> vir sommige T
// => s.borrow().as_ref() en ons het altyd snye
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // die eerste sny is die enigste sonder 'n skeier wat voorafgaan
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // bereken die presiese totale lengte van die saamgevoegde Vec as die `len`-berekening oorloop, sal ons panic ons geheue in elk geval sou opraak, en die res van die funksie vereis dat die hele Vec vooraf toegeken is vir veiligheid
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // berei 'n ongeïnisialiseerde buffer voor
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // kopie skeier en snye sonder grense kontrole genereer lusse met hardgekodeerde verrekenings vir klein skeiers groot verbeterings moontlik (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // 'N Vreemde leningimplementering kan verskillende snye vir die lengteberekening en die werklike kopie oplewer.
        //
        // Maak seker dat ons nie geïnitialiseerde grepe aan die oproeper blootstel nie.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// Metodes vir sny skywe.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// Skakel 'n `Box<str>` om in 'n `Box<[u8]>` sonder om dit te kopieer of toe te ken.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// Vervang alle wedstryde van 'n patroon deur 'n ander string.
    ///
    /// `replace` skep 'n nuwe [`String`], en kopieer die data van hierdie snysnit daarin.
    /// Terwyl dit gedoen word, probeer dit om ooreenkomste met 'n patroon te vind.
    /// As dit gevind word, vervang dit hulle deur die vervangende snysnit.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// As die patroon nie ooreenstem nie:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Vervang eerste N-wedstryde van 'n patroon deur 'n ander string.
    ///
    /// `replacen` skep 'n nuwe [`String`], en kopieer die data van hierdie snysnit daarin.
    /// Terwyl dit gedoen word, probeer dit om ooreenkomste met 'n patroon te vind.
    /// As dit gevind word, vervang dit hulle hoogstens `count` keer met die vervangende snysnit.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// As die patroon nie ooreenstem nie:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // Hoop om die tye van herverdeling te verminder
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Wys die klein ekwivalent van hierdie snysnit as 'n nuwe [`String`].
    ///
    /// 'Lowercase' word gedefinieer volgens die bepalings van die Unicode Afgeleide kern-eiendom `Lowercase`.
    ///
    /// Aangesien sommige karakters in verskeie karakters kan uitbrei wanneer die hoofletter verander word, gee hierdie funksie 'n [`String`] terug in plaas van die parameter in plek te wysig.
    ///
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// 'N lastige voorbeeld, met sigma:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // maar aan die einde van 'n woord is dit ς, nie σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// Tale sonder hoofletters word nie verander nie:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ karteer na σ, behalwe aan die einde van 'n woord waar dit gekarteer word op ς.
                // Dit is die enigste voorwaardelike (contextual) maar taalonafhanklike kartering in `SpecialCasing.txt`, so hard-code dit eerder as om 'n generiese "condition"-meganisme te hê.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // vir die definisie van `Final_Sigma`.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// Wys die hoofletter-ekwivalent van hierdie snysnit as 'n nuwe [`String`].
    ///
    /// 'Uppercase' word gedefinieer volgens die bepalings van die Unicode Afgeleide kern-eiendom `Uppercase`.
    ///
    /// Aangesien sommige karakters in verskeie karakters kan uitbrei wanneer die hoofletter verander word, gee hierdie funksie 'n [`String`] terug in plaas van die parameter in plek te wysig.
    ///
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// Skripte sonder omslag word nie verander nie:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// Een karakter kan veelvuldig word:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// Skakel 'n [`Box<str>`] om in 'n [`String`] sonder om dit te kopieer of toe te ken.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// Skep 'n nuwe [`String`] deur 'n string `n` keer te herhaal.
    ///
    /// # Panics
    ///
    /// Hierdie funksie sal panic as die kapasiteit sou oorloop.
    ///
    /// # Examples
    ///
    /// Basiese gebruik:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// 'N panic by oorloop:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// Lewer 'n kopie van hierdie string waar elke karakter gekoppel word aan die ASCII-hoofletter-ekwivalent.
    ///
    ///
    /// ASCII-letters 'a' tot 'z' word gekoppel aan 'A' tot 'Z', maar nie-ASCII-letters is onveranderd.
    ///
    /// Gebruik [`make_ascii_uppercase`] om die waarde in plek te hoofletter.
    ///
    /// Gebruik [`to_uppercase`] om ASCII-karakters in hoofletters te benewens nie-ASCII-karakters.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() bewaar die UTF-8-invariant.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// Lewer 'n kopie van hierdie string waar elke karakter gekoppel is aan die ASCII-kleinletter-ekwivalent.
    ///
    ///
    /// ASCII-letters 'A' tot 'Z' word gekoppel aan 'a' tot 'z', maar nie-ASCII-letters is onveranderd.
    ///
    /// Gebruik [`make_ascii_lowercase`] om die waarde klein te maak.
    ///
    /// Gebruik [`to_lowercase`] om ASCII-karakters in kleinletters te benewens nie-ASCII-karakters.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() bewaar die UTF-8-invariant.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// Skakel 'n stuk bytes in 'n boks in 'n boks sonder om te kyk of die string geldige UTF-8 bevat.
///
///
/// # Examples
///
/// Basiese gebruik:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}