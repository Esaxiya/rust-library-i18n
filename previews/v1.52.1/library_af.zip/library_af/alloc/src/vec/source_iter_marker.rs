use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Spesialiseringsmerker vir die insameling van 'n iteratorpyplyn in 'n Vec terwyl die brontoewysing hergebruik word, dws
/// die uitvoering van die pypleiding in plek.
///
/// Die SourceIter-ouer trait is nodig vir die spesialiseringsfunksie om toegang te verkry tot die toekenning wat hergebruik moet word.
/// Maar dit is nie voldoende dat die spesialisering geldig is nie.
/// Sien addisionele perke op die impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// Die std-interne SourceIter/InPlaceIterable traits word slegs deur kettings van Adapter geïmplementeer <Adapter<Adapter<IntoIter>>> (almal besit deur core/std).
// Bykomende perke vir die adapter-implementasies (verder as `impl<I: Trait> Trait for Adapter<I>`) hang slegs af van ander traits wat al gemerk is as spesialisering traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. die merker hang nie af van die lewensduur van tipes wat deur die gebruiker voorsien word nie.Modulo the Copy-gat, waarvan verskeie ander spesialiserings al afhanklik is.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Bykomende vereistes wat nie via trait bounds uitgedruk kan word nie.Ons vertrou eerder op konstaliteit:
        // a) geen ZST's nie, aangesien daar geen toekenning vir hergebruik is nie en wyserrekening sou panic b) grootte pas soos vereis deur Alloc-kontrak c) belyning ooreenstem soos vereis deur Alloc-kontrak
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // terugval na meer generiese implementasies
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // gebruik probeer vou sedert
        // - dit vektor beter vir sommige iteratore-adapters
        // - in teenstelling met die meeste interne iterasiemetodes, is dit slegs 'n &mut-self
        // - dit laat ons die skryfwyser deur sy binnegoed ryg en dit uiteindelik weer terugkry
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // iterasie het geslaag, moenie kop laat sak nie
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // kyk of SourceIter-kontrak voorbehou is: as dit nie die geval was nie, kan ons nie eers tot hiertoe kom nie
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // check InPlaceIterable kontrak.Dit is slegs moontlik as die iterator die bronwyser enigsins voorskiet.
        // As dit ongemerkte toegang via TrustedRandomAccess gebruik, sal die bronwyser in sy oorspronklike posisie bly en kan ons dit nie as verwysing gebruik nie
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // laat val die oorblywende waardes aan die stert van die bron, maar voorkom dat die toewysing val sodra IntoIter buite die omvang gaan as die druppel panics dan lek ons ook alle elemente wat versamel is in dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // die InPlaceIterable-kontrak kan nie juis hier geverifieer word nie, want try_fold het 'n eksklusiewe verwysing na die bronwyser, maar ons kan net kyk of dit nog binne die bereik is
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}