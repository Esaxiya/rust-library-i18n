use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Spesialisasie trait gebruik vir Vec::from_iter
///
/// ## Die afvaardigingsgrafiek:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // 'N Algemene saak is om 'n vector oor te gee in 'n funksie wat onmiddellik weer in 'n vector versamel word.
        // Ons kan dit kortsluit as die IntoIter glad nie gevorder is nie.
        // As dit gevorder is, kan ons die geheue ook hergebruik en die data na voor skuif.
        // Maar ons doen dit slegs as die resulterende Vec nie meer onbenutte kapasiteit sou hê as om dit te skep deur die generiese FromIterator-implementering nie.
        //
        // Hierdie beperking is nie streng nodig nie, aangesien Vec se toewysingsgedrag opsetlik ongespesifiseer is.
        // Maar dit is 'n konserwatiewe keuse.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // moet delegeer na spec_extend() aangesien extend() self delegeer na spec_from vir leë Vecs
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Dit maak gebruik van `iterator.as_slice().to_vec()`, aangesien spec_extend meer stappe moet neem om te redeneer oor die finale kapasiteit + lengte en dus meer werk moet doen.
// `to_vec()` gee die korrekte bedrag direk toe en vul dit presies in.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): met cfg(test) is die inherente `[T]::to_vec`-metode, wat benodig word vir hierdie definisie van die metode, nie beskikbaar nie.
    // Gebruik eerder die `slice::to_vec`-funksie wat slegs beskikbaar is met cfg(test) LET WEL, kyk na die slice::hack-module in slice.rs vir meer inligting
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}