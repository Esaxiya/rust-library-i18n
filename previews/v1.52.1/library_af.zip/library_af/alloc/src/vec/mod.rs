//! 'N Aangrensende kweekbare skikkingstipe met inhoud wat op hope toegeken is, geskryf `Vec<T>`.
//!
//! Vectors het `O(1)`-indeksering, geamortiseerde `O(1)`-druk (tot die einde) en `O(1)` pop (van die einde af).
//!
//!
//! Vectors verseker dat hulle nooit meer as `isize::MAX` bytes toewys nie.
//!
//! # Examples
//!
//! U kan eksplisiet 'n [`Vec`] met [`Vec::new`] skep:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... of deur die [`vec!`]-makro te gebruik:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // tien nulle
//! ```
//!
//! U kan [`push`]-waardes aan die einde van 'n vector (wat die vector sal laat groei, benodig):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Om waardes te popel, werk op dieselfde manier:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors ondersteun ook indeksering (deur die [`Index`] en [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// 'N Aangrensende kweekbare skikkingstipe, geskryf as `Vec<T>` en uitgespreek 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// Die [`vec!`]-makro word voorsien om die initialisering gemakliker te maak:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Dit kan ook elke element van 'n `Vec<T>` met 'n gegewe waarde inisialiseer.
/// Dit kan doeltreffender wees as om toewysing en inisialisering in aparte stappe uit te voer, veral wanneer 'n vector van nulle geïnisialiseer word:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Die volgende is gelykstaande, maar moontlik stadiger:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Vir meer inligting, sien [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Gebruik 'n `Vec<T>` as 'n doeltreffende stapel:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Druk 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Die `Vec`-tipe maak toegang tot waardes per indeks, omdat dit die [`Index`] trait implementeer.'N Voorbeeld sal meer eksplisiet wees:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // dit sal '2' vertoon
/// ```
///
/// Wees egter versigtig: as u probeer om toegang te verkry tot 'n indeks wat nie in die `Vec` is nie, sal u sagteware panic!U kan dit nie doen nie:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Gebruik [`get`] en [`get_mut`] as u wil kyk of die indeks in die `Vec` is.
///
/// # Slicing
///
/// 'N `Vec` kan veranderlik wees.Aan die ander kant is snye leesalleen voorwerpe.
/// Gebruik [`&`] om 'n [slice][prim@slice] te kry.Voorbeeld:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... en dit is al!
/// // jy kan dit ook so doen:
/// let u: &[usize] = &v;
/// // of so:
/// let u: &[_] = &v;
/// ```
///
/// In Rust is dit meer algemeen om snye as argumente deur te gee eerder as vectors as u net leestoegang wil bied.Dieselfde geld vir [`String`] en [`&str`].
///
/// # Kapasiteit en hertoewysing
///
/// Die kapasiteit van 'n vector is die hoeveelheid ruimte wat toegeken word vir enige future-elemente wat by die vector gevoeg sal word.Dit moet nie verwar word met die *lengte* van 'n vector nie, wat die aantal werklike elemente in die vector spesifiseer.
/// As die lengte van 'n vector sy kapasiteit oorskry, sal die kapasiteit daarvan outomaties vergroot word, maar die elemente moet weer toegedeel word.
///
/// Byvoorbeeld, 'n vector met kapasiteit 10 en lengte 0 sou 'n leë vector wees met ruimte vir nog 10 elemente.As u 10 of minder elemente op die vector druk, kan dit nie die kapasiteit verander of herverdeling plaasvind nie.
/// As die lengte van die vector egter verhoog word na 11, moet dit herbenoem word, wat stadig kan wees.Om hierdie rede word aanbeveel om [`Vec::with_capacity`], indien moontlik, te gebruik om aan te dui hoe groot die vector verwag word.
///
/// # Guarantees
///
/// Vanweë sy ongelooflike fundamentele aard, bied `Vec` baie waarborge oor die ontwerp daarvan.Dit verseker dat dit in die algemeen so laag as moontlik is, en dat dit op primitiewe maniere korrek gemanipuleer kan word deur onveilige kode.Let daarop dat hierdie waarborge verwys na 'n ongekwalifiseerde `Vec<T>`.
/// As addisionele soortparameters bygevoeg word (bv. Om persoonlike toewysers te ondersteun), kan die gedrag daarvan verander word as dit hul standaardinstellings oorheers.
///
/// Die fundamenteelste is dat `Vec` 'n (aanwyser, kapasiteit, lengte) drieling is en altyd sal wees.Nie meer nie, nie minder nie.Die volgorde van hierdie velde is heeltemal nie gespesifiseer nie, en gebruik die toepaslike metodes om dit te verander.
/// Die aanwyser sal nooit nul wees nie, dus is hierdie tipe geoptimaliseer met nul-wyser.
///
/// Die wyser kan egter nie eintlik na die toegewysde geheue wys nie.
/// In die besonder, as u 'n `Vec` met kapasiteit 0 konstrueer via [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], of deur [`shrink_to_fit`] op 'n leë Vec aan te roep, sal dit nie geheue toewys nie.Net so, as u nulgrootte soorte in 'n `Vec` berg, sal dit nie ruimte daarvoor toeken nie.
/// *Let daarop dat die `Vec` in hierdie geval nie 'n [`capacity`] van 0* sal rapporteer nie.
/// `Vec` sal toewys as en slegs as [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Oor die algemeen is die toekenningsbesonderhede van 'Vec' baie subtiel-as u van plan is om geheue met 'n `Vec` toe te ken en dit vir iets anders te gebruik (óf om na 'n onveilige kode deur te gee, óf om u eie geheue-gesteunde versameling op te stel), moet u seker wees om hierdie geheue te herplaas deur `from_raw_parts` te gebruik om die `Vec` te herwin en dan te laat val.
///
/// As 'n `Vec`*geheue* toegeken het, is die geheue waarna dit wys op die hoop (soos gedefinieer deur die toewyser Rust is ingestel om dit standaard te gebruik), en die wyser wys op [`len`] geïnitialiseerde, aangrensende elemente in volgorde (wat u sou wou kyk of u dit tot 'n sny gedwing het), gevolg deur ['capaciteit'] ', `[` len`] logies ongeïnitialiseerde, aangrensende elemente.
///
///
/// 'N vector wat die elemente `'a'` en `'b'` met kapasiteit 4 bevat, kan soos hieronder gevisualiseer word.Die boonste gedeelte is die `Vec` struct, dit bevat 'n aanwyser na die hoof van die toewysing in die hoop, lengte en kapasiteit.
/// Die onderste gedeelte is die toewysing op die hoop, 'n aangrensende geheue-blok.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** stel geheue voor wat nie geïnisialiseer is nie, sien [`MaybeUninit`].
/// - Note: die ABI is nie stabiel nie en `Vec` bied geen waarborge ten opsigte van die geheue-uitleg nie (insluitend die volgorde van velde).
///
/// `Vec` sal nooit om twee redes 'n "small optimization" uitvoer waar elemente op die stapel gestoor word nie:
///
/// * Dit sal die onveilige kode moeiliker maak om 'n `Vec` korrek te manipuleer.Die inhoud van 'n `Vec` sou nie 'n stabiele adres hê as dit net geskuif word nie, en dit sou moeiliker wees om te bepaal of 'n `Vec` geheue toegeken het.
///
/// * Dit sal die algemene saak boet en 'n addisionele-tak met elke toegang tot gevolg hê.
///
/// `Vec` sal homself nooit outomaties krimp nie, selfs al is dit heeltemal leeg.Dit verseker dat geen onnodige toekennings of transaksies plaasvind nie.As u 'n `Vec` leegmaak en dan weer tot dieselfde [`len`] invul, moet die toewyser geen oproepe hê nie.Gebruik [`shrink_to_fit`] of [`shrink_to`] as u ongebruikte geheue wil vrystel.
///
/// [`push`] en [`insert`] sal nooit (her) toeken as die gerapporteerde kapasiteit voldoende is nie.[`push`] en [`insert`]*sal*(her) toeken as [`len`]`==`[`capacity`].Dit wil sê, die gerapporteerde kapasiteit is heeltemal akkuraat en daarop kan vertrou word.Dit kan selfs gebruik word om die geheue wat deur 'n `Vec` toegeken is, handmatig te bevry.
/// Grootmaatinvoegingsmetodes *kan* hertoewys, selfs wanneer dit nie nodig is nie.
///
/// `Vec` waarborg nie 'n spesifieke groeistrategie by die hertoewysing wanneer dit vol is nie, en ook nie wanneer [`reserve`] genoem word nie.Die huidige strategie is basies en dit kan wenslik wees om 'n nie-konstante groeifaktor te gebruik.Watter strategie ook al gebruik word, sal natuurlik *O*(1) geamortiseerde [`push`] waarborg.
///
/// `vec![x; n]`, `vec![a, b, c, d]`, en [`Vec::with_capacity(n)`][`Vec::with_capacity`], sal almal 'n `Vec` vervaardig met presies die gevraagde kapasiteit.
/// As [`len`]`==`[`capaciteit`], (soos die geval is met die [`vec!`]-makro), kan 'n `Vec<T>` omgeskakel word na en van 'n [`Box<[T]>`][owned slice] sonder om die elemente te her-toeken of te skuif.
///
/// `Vec` sal nie data wat daaruit verwyder word, spesifiek oorskryf nie, maar ook nie spesifiek bewaar nie.Die geheue wat nie geïnisialiseer is nie, is krapruimte wat hy mag gebruik soos hy wil.Dit sal gewoonlik net doen wat die doeltreffendste of andersins maklik is om te implementeer.Moenie vertrou dat verwyderde data vir veiligheidsdoeleindes uitgewis moet word nie.
/// Selfs as u 'n `Vec` laat val, kan die buffer daarvan eenvoudig deur 'n ander `Vec` hergebruik word.
/// Selfs as u eers 'Vec' se geheue nul, kan dit dalk nie gebeur nie, want die optimizer beskou dit nie as 'n newe-effek wat behoue moet bly nie.
/// Daar is egter een geval wat ons nie sal breek nie: die gebruik van `unsafe`-kode om die oortollige kapasiteit te skryf, en dan die verlenging om te pas, is altyd geldig.
///
/// Tans waarborg `Vec` nie die volgorde waarin elemente laat val word nie.
/// Die volgorde het in die verlede verander en kan weer verander.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Inherente metodes
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Konstrueer 'n nuwe, leë `Vec<T>`.
    ///
    /// Die vector word nie toegeken voordat elemente daarop gedruk word nie.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Konstrueer 'n nuwe, leë `Vec<T>` met die gespesifiseerde kapasiteit.
    ///
    /// Die vector sal presies `capacity`-elemente kan hou sonder om dit weer toe te ken.
    /// As `capacity` 0 is, sal die vector nie toeken nie.
    ///
    /// Dit is belangrik om daarop te let dat hoewel die teruggekeerde vector die *kapasiteit* het, die vector 'n nul *lengte* sal hê.
    ///
    /// Vir 'n uiteensetting van die verskil tussen lengte en kapasiteit, sien *[Kapasiteit en hertoewysing]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // Die vector bevat geen items nie, alhoewel dit kapasiteit het vir meer
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Dit word alles gedoen sonder om weer te her ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... maar dit kan die vector weer toewys
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Skep 'n `Vec<T>` direk uit die onbewerkte komponente van 'n ander vector.
    ///
    /// # Safety
    ///
    /// Dit is baie onveilig as gevolg van die aantal invariërs wat nie gekontroleer word nie:
    ///
    /// * `ptr` moet voorheen toegeken word via [`String`]/` Vec<T>'(ten minste sal dit waarskynlik verkeerd wees as dit nie was nie).
    /// * `T` moet dieselfde grootte en belyning hê as waarmee `ptr` toegeken is.
    ///   (As `T` met 'n minder streng belyning nie voldoende is nie, moet die belyning regtig gelyk wees om aan die [`dealloc`]-vereiste te voldoen dat geheue toegeken moet word en met dieselfde uitleg geplaas moet word.)
    ///
    /// * `length` moet kleiner as of gelyk wees aan `capacity`.
    /// * `capacity` moet die kapasiteit wees waarmee die wyser toegeken is.
    ///
    /// Oortreding hiervan kan probleme veroorsaak soos om die interne datastrukture van die toewyser te beskadig.Dit is byvoorbeeld **nie** veilig om 'n `Vec<u8>` van 'n aanwyser na 'n C `char`-skikking met die lengte `size_t` te bou nie.
    /// Dit is ook nie veilig om een uit 'n `Vec<u16>` en sy lengte te bou nie, want die toewyser gee om vir die belyning, en hierdie twee soorte het verskillende belynings.
    /// Die buffer is toegeken met belyning 2 (vir `u16`), maar nadat dit in 'n `Vec<u8>` verander is, sal dit met belyning 1 gekoppel word.
    ///
    /// Die eienaarskap van `ptr` word effektief na die `Vec<T>` oorgedra, wat dan die inhoud van die geheue waarna die wyser na willekeur wys, kan herplaas, herdeel of verander.
    /// Verseker dat niks anders die wyser gebruik nadat u hierdie funksie aangeskakel het nie.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Update dit wanneer vec_into_raw_parts gestabiliseer is.
    ///     // Voorkom dat u die vernietiger van 'v' bestuur, sodat ons die volle toekenning het.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Haal die verskillende belangrike inligting oor `v` uit
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Skryf geheue oor met 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Sit alles weer saam in 'n Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Konstrueer 'n nuwe, leë `Vec<T, A>`.
    ///
    /// Die vector word nie toegeken voordat elemente daarop gedruk word nie.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Konstrueer 'n nuwe, leë `Vec<T, A>` met die gespesifiseerde kapasiteit met die verskafde toewyser.
    ///
    /// Die vector sal presies `capacity`-elemente kan hou sonder om dit weer toe te ken.
    /// As `capacity` 0 is, sal die vector nie toeken nie.
    ///
    /// Dit is belangrik om daarop te let dat hoewel die teruggekeerde vector die *kapasiteit* het, die vector 'n nul *lengte* sal hê.
    ///
    /// Vir 'n uiteensetting van die verskil tussen lengte en kapasiteit, sien *[Kapasiteit en hertoewysing]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // Die vector bevat geen items nie, alhoewel dit kapasiteit het vir meer
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Dit word alles gedoen sonder om weer te her ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... maar dit kan die vector weer toewys
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Skep 'n `Vec<T, A>` direk uit die onbewerkte komponente van 'n ander vector.
    ///
    /// # Safety
    ///
    /// Dit is baie onveilig as gevolg van die aantal invariërs wat nie gekontroleer word nie:
    ///
    /// * `ptr` moet voorheen toegeken word via [`String`]/` Vec<T>'(ten minste sal dit waarskynlik verkeerd wees as dit nie was nie).
    /// * `T` moet dieselfde grootte en belyning hê as waarmee `ptr` toegeken is.
    ///   (As `T` met 'n minder streng belyning nie voldoende is nie, moet die belyning regtig gelyk wees om aan die [`dealloc`]-vereiste te voldoen dat geheue toegeken moet word en met dieselfde uitleg geplaas moet word.)
    ///
    /// * `length` moet kleiner as of gelyk wees aan `capacity`.
    /// * `capacity` moet die kapasiteit wees waarmee die wyser toegeken is.
    ///
    /// Oortreding hiervan kan probleme veroorsaak soos om die interne datastrukture van die toewyser te beskadig.Dit is byvoorbeeld **nie** veilig om 'n `Vec<u8>` van 'n aanwyser na 'n C `char`-skikking met die lengte `size_t` te bou nie.
    /// Dit is ook nie veilig om een uit 'n `Vec<u16>` en sy lengte te bou nie, want die toewyser gee om vir die belyning, en hierdie twee soorte het verskillende belynings.
    /// Die buffer is toegeken met belyning 2 (vir `u16`), maar nadat dit in 'n `Vec<u8>` verander is, sal dit met belyning 1 gekoppel word.
    ///
    /// Die eienaarskap van `ptr` word effektief na die `Vec<T>` oorgedra, wat dan die inhoud van die geheue waarna die wyser na willekeur wys, kan herplaas, herdeel of verander.
    /// Verseker dat niks anders die wyser gebruik nadat u hierdie funksie aangeskakel het nie.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Update dit wanneer vec_into_raw_parts gestabiliseer is.
    ///     // Voorkom dat u die vernietiger van 'v' bestuur, sodat ons die volle toekenning het.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Haal die verskillende belangrike inligting oor `v` uit
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Skryf geheue oor met 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Sit alles weer saam in 'n Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Ontbind 'n `Vec<T>` in sy onbewerkte komponente.
    ///
    /// Wys die rou wyser na die onderliggende data, die lengte van die vector (in elemente) en die toegekende kapasiteit van die data (in elemente).
    /// Dit is dieselfde argumente in dieselfde volgorde as die argumente vir [`from_raw_parts`].
    ///
    /// Nadat hierdie funksie gebel is, is die oproeper verantwoordelik vir die geheue wat voorheen deur die `Vec` bestuur is.
    /// Die enigste manier om dit te doen is om die onbewerkte wyser, lengte en kapasiteit weer in 'n `Vec` met die [`from_raw_parts`]-funksie om te sit, sodat die vernietiger die opruiming kan uitvoer.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Ons kan nou veranderings aan die komponente aanbring, soos om die rou wyser na 'n versoenbare tipe oor te plaas.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Ontbind 'n `Vec<T>` in sy onbewerkte komponente.
    ///
    /// Wys die rou wyser na die onderliggende data, die lengte van die vector (in elemente), die toegekende kapasiteit van die data (in elemente) en die toewyser.
    /// Dit is dieselfde argumente in dieselfde volgorde as die argumente vir [`from_raw_parts_in`].
    ///
    /// Nadat hierdie funksie gebel is, is die oproeper verantwoordelik vir die geheue wat voorheen deur die `Vec` bestuur is.
    /// Die enigste manier om dit te doen is om die onbewerkte wyser, lengte en kapasiteit weer in 'n `Vec` met die [`from_raw_parts_in`]-funksie om te sit, sodat die vernietiger die opruiming kan uitvoer.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Ons kan nou veranderings aan die komponente aanbring, soos om die rou wyser na 'n versoenbare tipe oor te plaas.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Wys die aantal elemente wat die vector kan bevat sonder om dit weer toe te ken.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Bespreek kapasiteit vir ten minste `additional` meer elemente om in die gegewe `Vec<T>` in te voeg.
    /// Die versameling kan meer ruimte bespaar om gereelde toewysings te voorkom.
    /// Nadat u `reserve` gebel het, is die kapasiteit groter as of gelyk aan `self.len() + additional`.
    /// Doen niks as kapasiteit reeds voldoende is nie.
    ///
    /// # Panics
    ///
    /// Panics as die nuwe kapasiteit `isize::MAX` bytes oorskry.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Bespreek die minimum kapasiteit om presies meer `additional` elemente in die gegewe `Vec<T>` in te voeg.
    ///
    /// Nadat u `reserve_exact` gebel het, is die kapasiteit groter as of gelyk aan `self.len() + additional`.
    /// Doen niks as die kapasiteit reeds voldoende is nie.
    ///
    /// Let daarop dat die toewyser die versameling moontlik meer ruimte gee as wat dit gevra word.
    /// Daarom kan daar nie op kapasiteit gesteun word om presies minimaal te wees nie.
    /// Verkies `reserve` as invoegings van future verwag word.
    ///
    /// # Panics
    ///
    /// Panics as die nuwe kapasiteit oorloop van `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Probeer om kapasiteit te behou vir ten minste `additional` meer elemente om in die gegewe `Vec<T>` in te voeg.
    /// Die versameling kan meer ruimte bespaar om gereelde toewysings te voorkom.
    /// Nadat u `try_reserve` gebel het, is die kapasiteit groter as of gelyk aan `self.len() + additional`.
    /// Doen niks as kapasiteit reeds voldoende is nie.
    ///
    /// # Errors
    ///
    /// As die kapasiteit oorloop, of die toewyser 'n mislukking rapporteer, word 'n fout teruggestuur.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Reserveer die geheue vooraf en verlaat dit as ons nie kan nie
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Nou weet ons dat dit nie OOM te midde van ons ingewikkelde werk kan wees nie
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // baie ingewikkeld
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Probeer om die minimum kapasiteit te behou vir presies `additional`-elemente wat in die gegewe `Vec<T>` ingevoeg moet word.
    /// Nadat u `try_reserve_exact` gebel het, is die kapasiteit groter as of gelyk aan `self.len() + additional` as dit `Ok(())` oplewer.
    ///
    /// Doen niks as die kapasiteit reeds voldoende is nie.
    ///
    /// Let daarop dat die toewyser die versameling moontlik meer ruimte gee as wat dit gevra word.
    /// Daarom kan daar nie op kapasiteit gesteun word om presies minimaal te wees nie.
    /// Verkies `reserve` as invoegings van future verwag word.
    ///
    /// # Errors
    ///
    /// As die kapasiteit oorloop, of die toewyser 'n mislukking rapporteer, word 'n fout teruggestuur.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Reserveer die geheue vooraf en verlaat dit as ons nie kan nie
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Nou weet ons dat dit nie OOM te midde van ons ingewikkelde werk kan wees nie
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // baie ingewikkeld
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Verklein die kapasiteit van die vector soveel as moontlik.
    ///
    /// Dit sal so na as moontlik aan die lengte val, maar die toewyser kan die vector steeds in kennis stel dat daar ruimte is vir nog 'n paar elemente.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Die kapasiteit is nooit minder as die lengte nie, en daar is niks om te doen as dit gelyk is nie, dus kan ons die panic-geval in `RawVec::shrink_to_fit` vermy deur dit net met 'n groter kapasiteit te noem.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Verklein die kapasiteit van die vector met 'n onderste grens.
    ///
    /// Die kapasiteit sal minstens so groot bly as die lengte en die verskafde waarde.
    ///
    ///
    /// As die huidige kapasiteit minder is as die onderste limiet, is dit 'n no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Skakel die vector om in [`Box<[T]>`][owned slice].
    ///
    /// Let daarop dat dit enige oortollige kapasiteit sal laat daal.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Enige oortollige kapasiteit word verwyder:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Verkort die vector, hou die eerste `len`-elemente en laat die res val.
    ///
    /// As `len` groter is as die huidige lengte van die vector, het dit geen effek nie.
    ///
    /// Die [`drain`]-metode kan `truncate` naboots, maar veroorsaak dat die oortollige elemente teruggestuur word in plaas van laat val.
    ///
    ///
    /// Let daarop dat hierdie metode geen invloed het op die toegekende kapasiteit van die vector nie.
    ///
    /// # Examples
    ///
    /// Afkorting van 'n vyf element vector tot twee elemente:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Geen afkapping vind plaas as `len` groter is as die huidige lengte van die vector:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Afkorting as `len == 0` gelykstaande is aan die oproep van die [`clear`]-metode.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Dit is veilig omdat:
        //
        // * die plak wat na `drop_in_place` oorgedra word, is geldig;die `len > self.len`-saak vermy die skep van 'n ongeldige sny, en
        // * die `len` van die vector word gekrimp voordat hy `drop_in_place` bel, sodat geen waarde twee keer sal val as `drop_in_place` een keer panic sou wees nie (as dit twee keer panics is, dan staak die program).
        //
        //
        //
        unsafe {
            // Note: Dit is opsetlik dat dit `>` is en nie `>=` nie.
            //       Om dit na `>=` te verander, het in sommige gevalle negatiewe gevolge vir die prestasie.
            //       Sien #78884 vir meer inligting.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Haal 'n sny uit wat die hele vector bevat.
    ///
    /// Ekwivalent aan `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Onttrek 'n veranderlike deel van die hele vector.
    ///
    /// Ekwivalent aan `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Wys 'n rou wyser na die buffer van die vector.
    ///
    /// Die beller moet toesien dat die vector die aanwyser oorleef wat hierdie funksie weergee, anders sal dit uiteindelik na vullis wys.
    /// As u die vector verander, kan die buffer herverdeel word, wat ook enige aanwysings daarop ongeldig sal maak.
    ///
    /// Die beller moet ook toesien dat die geheue waarna die aanwyser (non-transitively) wys, nooit geskryf word nie (behalwe in 'n `UnsafeCell`) met behulp van hierdie aanwyser of enige wyser wat daaruit afgelei word.
    /// Gebruik [`as_mut_ptr`] as u die inhoud van die sny moet verander.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Ons skaduwee die snymetode met dieselfde naam om te verhoed dat ons deur `deref` gaan, wat 'n tussentydse verwysing skep.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Wys 'n onveilige veranderlike wyser na die buffer van die vector.
    ///
    /// Die beller moet toesien dat die vector die aanwyser oorleef wat hierdie funksie weergee, anders sal dit uiteindelik na vullis wys.
    ///
    /// As u die vector verander, kan die buffer herverdeel word, wat ook enige aanwysings daarop ongeldig sal maak.
    ///
    /// # Examples
    ///
    /// ```
    /// // Ken vector groot genoeg toe vir 4 elemente.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Initialiseer elemente via 'n rou aanwyser en stel dan die lengte in.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Ons skaduwee die snymetode met dieselfde naam om te verhoed dat ons deur `deref_mut` gaan, wat 'n tussentydse verwysing skep.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Wys 'n verwysing na die onderliggende toewyser.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Dwing die lengte van die vector tot `new_len`.
    ///
    /// Dit is 'n lae-vlak operasie wat geen normale invariërs van die tipe onderhou nie.
    /// Gewoonlik word die verandering van die lengte van 'n vector in plaas van een van die veilige bewerkings gedoen, soos [`truncate`], [`resize`], [`extend`] of [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` moet kleiner as of gelyk wees aan [`capacity()`].
    /// - Die elemente by `old_len..new_len` moet geïnisialiseer word.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Hierdie metode kan nuttig wees vir situasies waarin die vector dien as buffer vir ander kode, veral vir FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Dit is slegs 'n minimale skelet vir die voorbeeld van die dokument;
    /// # // gebruik dit nie as 'n beginpunt vir 'n regte biblioteek nie.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Volgens die dokumente van die FFI-metode, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // VEILIGHEID: Wanneer `deflateGetDictionary` `Z_OK` terugbesorg, geld dit:
    ///     // 1. `dict_length` elemente is geïnisialiseer.
    ///     // 2.
    ///     // `dict_length` <=die kapasiteit (32_768) wat `set_len` veilig maak om te skakel.
    ///     unsafe {
    ///         // Bel die FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... en werk die lengte op na wat geïnisialiseer is.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Alhoewel die volgende voorbeeld gesond is, is daar geheue lek omdat die binneste vectors nie voor die `set_len`-oproep vrygestel is nie:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` is leeg, dus hoef geen elemente geïnisialiseer te word nie.
    /// // 2. `0 <= capacity` hou altyd wat `capacity` ook al is.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Normaalweg sou 'n mens [`clear`] eerder gebruik om die inhoud korrek te laat val en sodoende nie geheue te laat lek nie.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Verwyder 'n element uit die vector en gee dit terug.
    ///
    /// Die verwyderde element word vervang deur die laaste element van die vector.
    ///
    /// Dit behou nie die bestelling nie, maar is O(1).
    ///
    /// # Panics
    ///
    /// Panics as `index` buite perke is.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Ons vervang self [indeks] met die laaste element.
            // Let daarop dat as die grensperk hierbo slaag, daar 'n laaste element moet wees (wat self kan wees [indeks]).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Plaas 'n element op posisie `index` in die vector, en skuif alle elemente daarna na regs.
    ///
    ///
    /// # Panics
    ///
    /// Panics as `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // ruimte vir die nuwe element
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // onfeilbaar Die plek om die nuwe waarde te plaas
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Skuif alles oor om plek te maak.
                // (Dupliseer die 'indeks'de element op twee agtereenvolgende plekke.)
                ptr::copy(p, p.offset(1), len - index);
                // Skryf dit in, en skryf die eerste kopie van die element `index` oor.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Verwyder en retourneer die element op posisie `index` binne die vector, en skuif alle elemente daarna na links.
    ///
    ///
    /// # Panics
    ///
    /// Panics as `index` buite perke is.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // die plek wat ons inneem.
                let ptr = self.as_mut_ptr().add(index);
                // kopieer dit, met 'n kopie van die waarde op die stapel en terselfdertyd in die vector.
                //
                ret = ptr::read(ptr);

                // Skuif alles af om die plek in te vul.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Behou slegs die elemente wat deur die predikaat gespesifiseer word.
    ///
    /// Met ander woorde, verwyder alle elemente `e` sodat `f(&e)` `false` teruggee.
    /// Hierdie metode werk in plek en besoek elke element presies een keer in die oorspronklike volgorde en bewaar die volgorde van die behoue elemente.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Omdat die elemente presies een keer in die oorspronklike volgorde besoek word, kan eksterne toestande gebruik word om te besluit watter elemente bewaar moet word.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Vermy dubbele val as die valbeschermer nie uitgevoer word nie, aangesien ons gedurende die proses gate kan maak.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-verwerk len-> |^-langs om na te gaan
        //                  | <-geskrap cnt-> |
        //      | <-oorspronklike_len-> |Bewaar: elemente wat predikaat lewer, waar op.
        //
        // Gat: gleuf beweeg of laat val.
        // Ongemerk: ongekontroleerde geldige elemente.
        //
        // Hierdie valbeschermer word aangeroep wanneer die predikaat of `drop` van die element paniekerig raak.
        // Dit skuif ongemerkte elemente om gate en `set_len` na die regte lengte te bedek.
        // In gevalle waar predikaat en `drop` nooit paniekerig raak nie, word dit geoptimaliseer.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // VEILIGHEID: sleep ongemerkte items moet geldig wees, aangesien ons nooit daaraan raak nie.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // VEILIGHEID: Nadat gate gevul is, is al die items in 'n aaneenlopende geheue.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // VEILIGHEID: Ongemerkte element moet geldig wees.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Gaan vroegtydig aan om dubbele val te voorkom as `drop_in_place` paniekerig raak.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // VEILIGHEID: Ons raak nooit weer aan hierdie element nadat ons gedaal het nie.
                unsafe { ptr::drop_in_place(cur) };
                // Ons het die toonbank al gevorder.
                continue;
            }
            if g.deleted_cnt > 0 {
                // VEILIGHEID: `deleted_cnt`> 0, dus moet die gate nie met die huidige element oorvleuel nie.
                // Ons gebruik copy vir skuif en raak nooit weer aan hierdie element nie.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Alle items word verwerk.Dit kan deur LLVM tot `set_len` geoptimaliseer word.
        drop(g);
    }

    /// Verwyder alle elemente behalwe die eerste opeenvolgende in die vector wat dieselfde sleutel oplos.
    ///
    ///
    /// As die vector gesorteer is, word alle duplikate verwyder.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Verwyder alle behalwe die eerste opeenvolgende elemente in die vector wat aan 'n gegewe gelykheidsverhouding voldoen.
    ///
    /// Die `same_bucket`-funksie word verwysings na twee elemente van die vector deurgegee en moet bepaal of die elemente gelyk is.
    /// Die elemente word in teenoorgestelde volgorde deurgegee van hul volgorde in die sny, dus as `same_bucket(a, b)` `true` terugbesorg, word `a` verwyder.
    ///
    ///
    /// As die vector gesorteer is, word alle duplikate verwyder.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Voeg 'n element agter in 'n versameling.
    ///
    /// # Panics
    ///
    /// Panics as die nuwe kapasiteit `isize::MAX` bytes oorskry.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Dit sal panic of afbreek as ons> isize::MAX bytes toewys of as die lengteverhoging oorloop vir soorte nulgrootte.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Verwyder die laaste element van 'n vector en gee dit terug, of [`None`] as dit leeg is.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Skuif al die elemente van `other` na `Self`, en laat `other` leeg.
    ///
    /// # Panics
    ///
    /// Panics as die aantal elemente in die vector 'n `usize` oorloop.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Voeg elemente by `Self` vanaf ander buffer.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Skep 'n drainerende iterator wat die gespesifiseerde reeks in die vector verwyder en die verwyderde items oplewer.
    ///
    /// As die iterator ** laat val word, word alle elemente in die reeks van die vector verwyder, selfs al is die iterator nie heeltemal verbruik nie.
    /// As die iterator **nie** val nie (byvoorbeeld met [`mem::forget`]), is dit ongespesifiseer hoeveel elemente verwyder word.
    ///
    /// # Panics
    ///
    /// Panics as die beginpunt groter is as die eindpunt of as die eindpunt groter is as die lengte van die vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Die volledige reeks maak die vector skoon
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Geheueveiligheid
        //
        // Wanneer die Drain vir die eerste keer geskep word, verkort dit die lengte van die bron vector om seker te maak dat geen geïnitialiseerde of verskuifde elemente toeganklik is as die vernietiger van die Drain nooit kan hardloop nie.
        //
        //
        // Drain sal die waardes wat u moet verwyder ptr::read uitskakel.
        // As u klaar is, word die oorblywende stert van die vec teruggekopieër om die gat te bedek, en die vector-lengte word weer in die nuwe lengte herstel.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // stel die self.vec-lengte in om te begin, om veilig te wees in geval Drain lek
            self.set_len(start);
            // Gebruik die lening in die IterMut om die leningsgedrag van die hele Drain-iterator aan te dui (soos &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Maak die vector skoon, en verwyder alle waardes.
    ///
    /// Let daarop dat hierdie metode geen invloed het op die toegekende kapasiteit van die vector nie.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Wys die aantal elemente in die vector, ook bekend as die 'length'.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Wys `true` as die vector geen elemente bevat nie.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Verdeel die versameling in twee by die gegewe indeks.
    ///
    /// Wys 'n pas toegekende vector wat die elemente in die reeks `[at, len)` bevat.
    /// Na die oproep sal die oorspronklike vector gelaat word met die elemente `[0, at)` met sy vorige kapasiteit onveranderd.
    ///
    ///
    /// # Panics
    ///
    /// Panics as `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // die nuwe vector kan die oorspronklike buffer oorneem en die kopie vermy
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Onveilig `set_len` en kopieer items na `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Verander die grootte van die `Vec` op sy plek sodat `len` gelyk is aan `new_len`.
    ///
    /// As `new_len` groter is as `len`, word die `Vec` met die verskil verleng, met elke bykomende gleuf gevul met die resultaat van die noem van die sluiting `f`.
    ///
    /// Die retourwaardes van `f` sal in die `Vec` beland in die volgorde wat dit gegenereer is.
    ///
    /// As `new_len` minder as `len` is, word die `Vec` eenvoudig afgekap.
    ///
    /// Hierdie metode gebruik 'n sluiting om nuwe waardes te skep by elke druk.Gebruik [`Vec::resize`] as u [`Clone`] 'n gegewe waarde verkies.
    /// As u die [`Default`] trait wil gebruik om waardes te genereer, kan u [`Default::default`] as die tweede argument deurgee.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Verbruik en lek die `Vec`, en gee 'n veranderlike verwysing na die inhoud, `&'a mut [T]`.
    /// Let daarop dat die tipe `T` die gekose leeftyd `'a` moet oorleef.
    /// As die tipe slegs statiese verwysings het, of glad nie, kan dit gekies word om `'static` te wees.
    ///
    /// Hierdie funksie is soortgelyk aan die [`leak`][Box::leak]-funksie op [`Box`], behalwe dat daar geen manier is om die gelekte geheue te herstel nie.
    ///
    ///
    /// Hierdie funksie is veral nuttig vir data wat die res van die program se lewe leef.
    /// As u die verwysing terugstuur, kan dit geheue lek.
    ///
    /// # Examples
    ///
    /// Eenvoudige gebruik:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Wys die oorblywende vrye kapasiteit van die vector as 'n deel van `MaybeUninit<T>`.
    ///
    /// Die teruggestuurde sny kan gebruik word om die vector met data te vul (bv
    /// deur uit 'n lêer te lees) voordat u die data gemerk as geïnitialiseer volgens die [`set_len`]-metode.
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Ken vector groot genoeg toe vir 10 elemente.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Vul die eerste 3 elemente in.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Merk die eerste 3 elemente van die vector as geïnisialiseer.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Hierdie metode word nie in terme van `split_at_spare_mut` geïmplementeer nie, om die aanwysings van die buffer ongeldig te maak.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Wys vector-inhoud as 'n sny van `T`, tesame met die oorblywende vrye kapasiteit van die vector as 'n sny van `MaybeUninit<T>`.
    ///
    /// Die teruggedeelde vrye kapasiteit-stuk kan gebruik word om die vector met data te vul (bv. Deur uit 'n lêer te lees) voordat u die data merk as geïnitialiseer volgens die [`set_len`]-metode.
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Let daarop dat dit 'n lae-vlak API is, wat versigtig gebruik moet word vir optimaliseringsdoeleindes.
    /// As u data by 'n `Vec` moet voeg, kan u [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] of [`resize_with`] gebruik, afhangende van u presiese behoeftes.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Bespreek ekstra ruimte wat groot genoeg is vir tien elemente.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Vul die volgende 4 elemente in.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Merk die vier elemente van die vector as geïnisialiseer.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len word geïgnoreer en dus nooit verander nie
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Veiligheid: verandering van teruggekeerde .2 (&mut-grootte) word beskou as dieselfde as om `.set_len(_)` te skakel.
    ///
    /// Hierdie metode word gebruik om unieke toegang tot alle onderdele in een keer in `extend_from_within` te hê.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` is gewaarborg om geldig te wees vir `len`-elemente
        // - `spare_ptr` wys een element verby die buffer, sodat dit nie met `initialized` oorvleuel nie
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Verander die grootte van die `Vec` op sy plek sodat `len` gelyk is aan `new_len`.
    ///
    /// As `new_len` groter is as `len`, word die `Vec` met die verskil uitgebrei, met elke bykomende gleuf gevul met `value`.
    ///
    /// As `new_len` minder as `len` is, word die `Vec` eenvoudig afgekap.
    ///
    /// Hierdie metode vereis dat `T` [`Clone`] moet implementeer om die geslaagde waarde te kan kloon.
    /// Gebruik [`Vec::resize_with`] as u meer buigsaamheid benodig (of u op [`Default`] in plaas van [`Clone`] wil vertrou).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Kloon en voeg alle elemente in 'n sny by die `Vec`.
    ///
    /// Itereer oor die sny `other`, klone elke element en voeg dit dan by hierdie `Vec`.
    /// Die `other` vector word in volgorde deurkruis.
    ///
    /// Let op dat hierdie funksie dieselfde is as [`extend`], behalwe dat dit gespesialiseerd is om eerder met snye te werk.
    ///
    /// As en wanneer Rust spesialisasie kry, sal hierdie funksie waarskynlik verouderd wees (maar steeds beskikbaar).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Kopieer elemente van die `src`-reeks na die einde van die vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` waarborg dat die gegewe reeks geldig is vir die indeksering van die self
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Hierdie kode veralgemeen `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Brei die vector met `n`-waardes uit met die gegewe kragopwekker.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Gebruik SetLenOnDrop om foute te omseil, waar samesteller dalk nie die winkel besef deur `ptr` tot self.set_len() nie alias is nie.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Skryf alle elemente behalwe die laaste een
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Verhoog die lengte in elke stap in geval next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Ons kan die laaste element direk skryf sonder om onnodig te kloon
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len gestel deur omvangwag
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Verwyder opeenvolgende herhaalde elemente in die vector volgens die [`PartialEq`] trait implementering.
    ///
    ///
    /// As die vector gesorteer is, word alle duplikate verwyder.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Interne metodes en funksies
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` geldige indeks moet wees
    /// - `self.capacity() - self.len()` moet `>= src.len()` wees
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len word eers verhoog nadat elemente geïnisialiseer is
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - oproeper waarborg dat src 'n geldige indeks is
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Element is pas met `MaybeUninit::write` geïnisialiseer, dus dit is goed om lenings te vergroot
            // - len word verhoog na elke element om lekkasies te voorkom (sien uitgawe #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - beller waarborg dat `src` 'n geldige indeks is
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Albei aanwysers word gemaak uit unieke snyverwysings (`&mut [_]`), sodat dit geldig is en nie oorvleuel nie.
            //
            // - Elemente is: Kopieer dit, dus is dit OK om dit te kopieer, sonder om iets met die oorspronklike waardes te doen
            // - `count` is gelyk aan die len van `source`, dus is die bron geldig vir die lees van `count`
            // - `.reserve(count)` waarborg dat `spare.len() >= count` so reserve geldig is vir `count` skryf
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Die elemente is pas deur `copy_nonoverlapping` geïnisialiseer
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Algemene trait-implementasies vir Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): met cfg(test) is die inherente `[T]::to_vec`-metode, wat benodig word vir hierdie definisie van die metode, nie beskikbaar nie.
    // Gebruik eerder die `slice::to_vec`-funksie wat slegs beskikbaar is met cfg(test) LET WEL, kyk na die slice::hack-module in slice.rs vir meer inligting
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // laat val alles wat nie oorskryf sal word nie
        self.truncate(other.len());

        // self.len <= other.len as gevolg van die afkapping hierbo, dus die snye hier is altyd binne-in-grense.
        //
        let (init, tail) = other.split_at(self.len());

        // hergebruik die vervat waardes allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Skep 'n verterende iterator, dit wil sê een wat elke waarde uit die vector skuif (van begin tot einde).
    /// Die vector kan nie gebruik word nadat u dit gebel het nie.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s het tipe String, nie &String nie
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // blaarmetode waaraan verskillende SpecFrom/SpecExtend-implementerings deelneem as daar geen verdere optimalisasies is nie
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Dit is die geval vir 'n algemene iterator.
        //
        // Hierdie funksie moet die morele ekwivalent wees van:
        //
        //      vir item in iterator {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB kan nie oorloop nie, want ons sou die adresruimte moes toeken
                self.set_len(len + 1);
            }
        }
    }

    /// Skep 'n splicer-iterator wat die gespesifiseerde reeks in die vector vervang met die gegewe `replace_with`-iterator en die verwyderde items lewer.
    ///
    /// `replace_with` hoef nie dieselfde lengte as `range` te hê nie.
    ///
    /// `range` word verwyder, selfs al word die iterator nie tot die einde verteer nie.
    ///
    /// Dit is ongespesifiseer hoeveel elemente uit die vector verwyder word as die `Splice`-waarde uitlek.
    ///
    /// Die invoer-iterator `replace_with` word slegs verbruik as die `Splice`-waarde laat val word.
    ///
    /// Dit is optimaal as:
    ///
    /// * Die stert (elemente in die vector na `range`) is leeg,
    /// * of `replace_with` lewer minder of gelyke elemente as die lengte van 'bereik'
    /// * of die ondergrens van sy `size_hint()` is presies.
    ///
    /// Andersins word 'n tydelike vector toegeken en die stert twee keer beweeg.
    ///
    /// # Panics
    ///
    /// Panics as die beginpunt groter is as die eindpunt of as die eindpunt groter is as die lengte van die vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Skep 'n iterator wat 'n sluiting gebruik om te bepaal of 'n element verwyder moet word.
    ///
    /// As die sluiting waar is, word die element verwyder en opgelewer.
    /// As die sluiting onwaar is, sal die element in die vector bly en nie deur die iterator opgelewer word nie.
    ///
    /// Die gebruik van hierdie metode is gelykstaande aan die volgende kode:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // u kode hier
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Maar `drain_filter` is makliker om te gebruik.
    /// `drain_filter` is ook doeltreffender omdat dit die elemente van die skikking in groot mate kan terugskakel.
    ///
    /// Let op dat u met `drain_filter` ook elke element in die filtersluiting kan verander, ongeag of u dit wil behou of verwyder.
    ///
    ///
    /// # Examples
    ///
    /// Om 'n skikking in ewe en kanse te verdeel deur die oorspronklike toekenning te hergebruik:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Waak daarteen dat ons uitlek (lekversterking)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Brei implementering uit wat elemente uit verwysings kopieer voordat dit op die Vec gedruk word.
///
/// Hierdie implementering is gespesialiseerd vir sny-iterators, waar dit [`copy_from_slice`] gebruik om die hele sny gelyktydig by te voeg.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Implementeer die vergelyking van vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Implementeer die bestel van vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // gebruik drop vir [T] gebruik 'n rou sny om na die elemente van die vector as swakste nodige tipe te verwys;
            //
            // kon geldigheidsvrae in sekere gevalle vermy
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec hanteer handelings
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Skep 'n leë `Vec<T>`.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: toets trek in libstd, wat hier foute veroorsaak
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: toets trek in libstd, wat hier foute veroorsaak
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Kry die hele inhoud van die `Vec<T>` as 'n skikking, as die grootte presies ooreenstem met die van die versoekte skikking.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// As die lengte nie ooreenstem nie, kom die invoer terug in `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// As u goed is met net 'n voorvoegsel van die `Vec<T>`, kan u eers [`.truncate(N)`](Vec::truncate) skakel.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // VEILIGHEID: `.set_len(0)` is altyd gesond.
        unsafe { vec.set_len(0) };

        // VEILIGHEID: Die wyser van 'n Vec is altyd behoorlik gerig, en
        // die belyning wat die skikking benodig is dieselfde as die items.
        // Ons het vroeër gekontroleer of daar voldoende items is.
        // Die items sal nie verdubbel nie, aangesien die `set_len` vir die `Vec` sê om dit nie ook te laat val nie.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}