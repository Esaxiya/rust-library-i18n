//! Aanwysings vir enkele verwysings tel.'Rc' staan vir 'Reference'
//! Counted'.
//!
//! Die tipe [`Rc<T>`][`Rc`] bied gedeelde eienaarskap van 'n waarde van die tipe `T`, toegeken in die hoop.
//! Deur [`clone`][clone] op [`Rc`] aan te roep, word 'n nuwe wyser op dieselfde toewysing in die hoop vervaardig.
//! Wanneer die laaste [`Rc`]-aanwyser na 'n gegewe toekenning vernietig word, word die waarde wat in die toekenning gestoor word (dikwels "inner value" genoem) ook laat val.
//!
//! Gedeelde verwysings in Rust laat mutasies nie toe nie, en [`Rc`] is geen uitsondering nie: u kan gewoonlik nie 'n veranderlike verwysing na iets in 'n [`Rc`] verkry nie.
//! As u veranderlikes benodig, plaas 'n [`Cell`] of [`RefCell`] in die [`Rc`];sien [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] gebruik nie-atoom verwysingstelling.
//! Dit beteken dat die bokoste baie laag is, maar 'n [`Rc`] kan nie tussen die drade gestuur word nie, en gevolglik implementeer [`Rc`] nie [`Send`][send] nie.
//! As gevolg hiervan sal die Rust-samesteller *op kompileringstyd** seker maak dat u nie [`Rc`] tussen die drade stuur nie.
//! Gebruik [`sync::Arc`][arc] as u 'n atoomverwysingtelling met meer skroefdraad benodig.
//!
//! Die [`downgrade`][downgrade]-metode kan gebruik word om 'n nie-besit [`Weak`]-wyser te skep.
//! 'N [`Weak`]-aanwyser kan [' upgrade '][upgrade] d na 'n [`Rc`] wees, maar dit sal [`None`] teruggee as die waarde wat in die toekenning gestoor is, reeds laat val is.
//! Met ander woorde, `Weak`-wysers hou nie die waarde binne die toekenning lewend nie;hulle hou die toewysing (die agtergrondwinkel vir die innerlike waarde) egter lewendig.
//!
//! 'N Siklus tussen [`Rc`]-aanwysers sal nooit herdeel word nie.
//! Om hierdie rede word [`Weak`] gebruik om siklusse te breek.
//! Byvoorbeeld, 'n boom kan sterk [`Rc`]-aanwysers hê van ouernodusse tot kinders, en [`Weak`]-aanwysers van kinders terug na hul ouers.
//!
//! `Rc<T>` Verwys outomaties na `T` (via die [`Deref`] trait), sodat u 'T'-metodes kan noem op 'n waarde van die tipe [`Rc<T>`][`Rc`].
//! Om naambotsings met 'T'-metodes te voorkom, is die metodes van [`Rc<T>`][`Rc`] self geassosieerde funksies, wat [fully qualified syntax] gebruik:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>Die implementering van traits soos `Clone` kan ook genoem word met behulp van volledig gekwalifiseerde sintaksis.
//! Sommige mense verkies om ten volle gekwalifiseerde sintaksis te gebruik, terwyl ander verkies om sintaks vir metode-oproepe te gebruik.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Metaks-oproep sintaksis
//! let rc2 = rc.clone();
//! // Ten volle gekwalifiseerde sintaksis
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] verwys nie outomaties na `T` nie, omdat die innerlike waarde dalk reeds laat val is.
//!
//! # Kloning van verwysings
//!
//! Die skep van 'n nuwe verwysing na dieselfde toewysing as 'n bestaande verwysingsgetelde wyser word gedoen met behulp van die `Clone` trait wat geïmplementeer is vir [`Rc<T>`][`Rc`] en [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Die twee sintaksis hieronder is ekwivalent.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a en b wys albei op dieselfde geheueplek as foo.
//! ```
//!
//! Die `Rc::clone(&from)`-sintaksis is die idiomatiesste omdat dit die betekenis van die kode meer eksplisiet oordra.
//! In die voorbeeld hierbo maak hierdie sintaksis dit makliker om te sien dat hierdie kode 'n nuwe verwysing skep, eerder as om die hele inhoud van foo te kopieer.
//!
//! # Examples
//!
//! Beskou 'n scenario waarin 'n stel 'Gadget's' besit word deur 'n gegewe `Owner`.
//! Ons wil hê dat ons 'Gadget' s hul `Owner` moet wys.Ons kan dit nie met unieke eienaarskap doen nie, want meer as een apparaat kan tot dieselfde `Owner` behoort.
//! [`Rc`] stel ons in staat om 'n `Owner` tussen veelvuldige 'Gadget`s te deel en die `Owner` te laat toeken, solank enige `Gadget`-punte daarop is.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... ander velde
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... ander velde
//! }
//!
//! fn main() {
//!     // Skep 'n `Owner` wat deur die verwysing getel word.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Skep 'Gadget' s wat aan `gadget_owner` behoort.
//!     // Kloning van die `Rc<Owner>` gee ons 'n nuwe aanwyser vir dieselfde `Owner`-toekenning, wat die verwysingstelling in die proses verhoog.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Gooi ons plaaslike veranderlike `gadget_owner` weg.
//!     drop(gadget_owner);
//!
//!     // Ondanks die val van `gadget_owner`, is ons steeds in staat om die naam van die `Owner` van die 'Gadget's' uit te druk.
//!     // Dit is omdat ons slegs een enkele `Rc<Owner>` laat val het, nie die `Owner` waarop dit wys nie.
//!     // Solank daar ander `Rc<Owner>` is wat op dieselfde `Owner`-toekenning wys, sal dit lewendig bly.
//!     // Die veldprojeksie `gadget1.owner.name` werk omdat `Rc<Owner>` outomaties na `Owner` verwys.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Aan die einde van die funksie word `gadget1` en `gadget2` vernietig, en daarmee saam die laaste getelde verwysings na ons `Owner`.
//!     // Gadget Man word ook nou vernietig.
//!     //
//! }
//! ```
//!
//! As ons vereistes verander en ons ook van `Owner` na `Gadget` moet kan deurtrek, sal ons probleme ondervind.
//! 'N [`Rc`]-aanwyser van `Owner` tot `Gadget` stel 'n siklus bekend.
//! Dit beteken dat hul verwysingstellings nooit 0 kan bereik nie, en dat die toekenning nooit vernietig sal word nie:
//! 'n geheue lek.Om dit te vermy, kan ons [`Weak`]-aanwysers gebruik.
//!
//! Rust maak dit in die eerste plek moeilik om hierdie lus te produseer.Om met twee waardes wat op mekaar wys, te eindig, moet een daarvan veranderlik wees.
//! Dit is moeilik omdat [`Rc`] geheueveiligheid handhaaf deur slegs gedeelde verwysings na die waarde wat dit omhul, uit te gee, en dit laat nie direkte mutasie toe nie.
//! Ons moet die deel van die waarde wat ons wil muteer, in 'n [`RefCell`] toedraai, wat *interieurveranderlikheid* bied: 'n metode om veranderlikheid te bewerkstellig deur middel van 'n gedeelde verwysing.
//! [`RefCell`] handhaaf Rust se leenreëls tydens looptyd.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... ander velde
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... ander velde
//! }
//!
//! fn main() {
//!     // Skep 'n `Owner` wat deur die verwysing getel word.
//!     // Let daarop dat ons die 'Eienaar' se vector van 'Gadget' in 'n `RefCell` geplaas het sodat ons dit kan muteer deur middel van 'n gedeelde verwysing.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Skep 'Gadget' s wat aan `gadget_owner` behoort, soos voorheen.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Voeg die 'Gadget' s by hul `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` dinamiese lening eindig hier.
//!     }
//!
//!     // Raak oor ons 'Gadget' s en druk hul besonderhede uit.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` is 'n `Weak<Gadget>`.
//!         // Aangesien `Weak`-aanwysers nie kan waarborg dat die toekenning steeds bestaan nie, moet ons `upgrade` skakel, wat 'n `Option<Rc<Gadget>>` oplewer.
//!         //
//!         //
//!         // In hierdie geval weet ons dat die toekenning nog bestaan, dus `unwrap` die `Option`.
//!         // In 'n ingewikkelder program het u dalk grasieuse fouthantering nodig vir 'n `None`-resultaat.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Aan die einde van die funksie word `gadget_owner`, `gadget1` en `gadget2` vernietig.
//!     // Daar is nou geen sterk (`Rc`)-aanwysers vir die toestelle nie, dus word dit vernietig.
//!     // Dit laat die verwysing op Gadget Man nul, sodat hy ook vernietig word.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Dit is repr(C) tot future-bestendig teen moontlike veldherrangskikking, wat die andersins veilige [into|from]_raw() van oordraagbare binnetipes sal belemmer.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// 'N Enkele draad verwysing-telwyser.'Rc' staan vir 'Reference'
/// Counted'.
///
/// Raadpleeg die [module-level documentation](./index.html) vir meer besonderhede.
///
/// Die inherente metodes van `Rc` is almal geassosieerde funksies, wat beteken dat u dit moet noem as bv. [`Rc::get_mut(&mut value)`][get_mut] in plaas van `value.get_mut()`.
/// Dit vermy konflik met metodes van die binneste tipe `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Hierdie onveiligheid is in orde, want terwyl hierdie RC leef, is ons gewaarborg dat die binnewyser geldig is.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Konstrueer 'n nuwe `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Daar is 'n implisiete swak aanwyser wat deur al die sterk aanwysers besit word, wat verseker dat die swak vernietiger nooit die toewysing bevry terwyl die sterk vernietiger aan die gang is nie, selfs al word die swak wyser in die sterk een gestoor.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Konstrueer 'n nuwe `Rc<T>` met 'n swak verwysing na homself.
    /// As u die swak verwysing probeer opgradeer voordat hierdie funksie terugkeer, sal dit 'n `None`-waarde hê.
    ///
    /// Die swak verwysing kan egter vrylik gekloon word en later gestoor word.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... meer velde
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Konstrueer die binnekant in die "uninitialized"-toestand met 'n enkele swak verwysing.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Dit is belangrik dat ons nie die eienaarskap van die swak aanwyser prysgee nie, anders kan die geheue vrygestel word wanneer `data_fn` terugkom.
        // As ons regtig eienaarskap wil deurgee, kan ons 'n bykomende swak aanwyser vir onsself skep, maar dit sal lei tot bykomende opdaterings van die swak verwysingstelling wat andersins nie nodig is nie.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Sterk verwysings moet gesamentlik 'n gedeelde swak verwysing besit, dus moenie die vernietiger gebruik vir ons ou swak verwysing nie.
        //
        mem::forget(weak);
        strong
    }

    /// Konstrueer 'n nuwe `Rc` met nie-geïnitialiseerde inhoud.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Uitgestelde initialisering:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstrueer 'n nuwe `Rc` met nie-geïnitialiseerde inhoud, met die geheue gevul met `0` bytes.
    ///
    ///
    /// Kyk na [`MaybeUninit::zeroed`][zeroed] vir voorbeelde van die korrekte en verkeerde gebruik van hierdie metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstrueer 'n nuwe `Rc<T>` en gee 'n fout terug as die toewysing misluk
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Daar is 'n implisiete swak aanwyser wat deur al die sterk aanwysers besit word, wat verseker dat die swak vernietiger nooit die toewysing bevry terwyl die sterk vernietiger aan die gang is nie, selfs al word die swak wyser in die sterk een gestoor.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Konstrueer 'n nuwe `Rc` met nie-geïnitialiseerde inhoud en gee 'n fout terug as die toewysing misluk
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Uitgestelde initialisering:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Konstrueer 'n nuwe `Rc` met nie-geïnitialiseerde inhoud, met die geheue gevul met `0` bytes, wat 'n fout weergee as die toewysing misluk
    ///
    ///
    /// Kyk na [`MaybeUninit::zeroed`][zeroed] vir voorbeelde van die korrekte en verkeerde gebruik van hierdie metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Konstrueer 'n nuwe `Pin<Rc<T>>`.
    /// As `T` nie `Unpin` implementeer nie, sal `value` in die geheue vasgepen word en kan dit nie geskuif word nie.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Wys die innerlike waarde as die `Rc` presies een sterk verwysing het.
    ///
    /// Andersins word 'n [`Err`] teruggestuur met dieselfde `Rc` wat ingedien is.
    ///
    ///
    /// Dit sal slaag, selfs al is daar uitstekende swak verwysings.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // kopieer die vervat voorwerp

                // Dui vir Weaks aan dat dit nie bevorder kan word deur die sterk telling te verminder nie, en verwyder dan die implisiete "strong weak"-wyser terwyl u ook druppelogika hanteer deur net 'n valse Swak te skep.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Konstrueer 'n nuwe sny met verwysingsgetel met ongeïnisialiseerde inhoud.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Uitgestelde initialisering:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Konstrueer 'n nuwe verwysingsgetel stuk met ongeïnisialiseerde inhoud, met die geheue gevul met `0` bytes.
    ///
    ///
    /// Kyk na [`MaybeUninit::zeroed`][zeroed] vir voorbeelde van die korrekte en verkeerde gebruik van hierdie metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Skakel oor na `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Soos met [`MaybeUninit::assume_init`], is dit die oproeper om te waarborg dat die innerlike waarde regtig in 'n geïnitialiseerde toestand is.
    ///
    /// Om dit te noem as die inhoud nog nie volledig geïnisialiseer is nie, veroorsaak onmiddellike ongedefinieerde gedrag.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Uitgestelde initialisering:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Skakel oor na `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Soos met [`MaybeUninit::assume_init`], is dit die oproeper om te waarborg dat die innerlike waarde regtig in 'n geïnitialiseerde toestand is.
    ///
    /// Om dit te noem as die inhoud nog nie volledig geïnisialiseer is nie, veroorsaak onmiddellike ongedefinieerde gedrag.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Uitgestelde initialisering:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Verbruik die `Rc` en gee die toegepaste wyser terug.
    ///
    /// Om 'n geheue-lek te voorkom, moet die wyser weer met 'n [`Rc::from_raw`][from_raw] na 'n `Rc` omgeskakel word.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Voorsien 'n rou wyser van die data.
    ///
    /// Die tellings word geensins beïnvloed nie en die `Rc` word nie verbruik nie.
    /// Die aanwyser is geldig solank daar sterk tellings in die `Rc` is.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // VEILIGHEID: Dit kan nie deur Deref::deref of Rc::inner gaan nie omdat
        // dit is nodig om die raw/mut herkoms so te behou dat bv
        // `get_mut` kan deur die wyser skryf nadat die Rc deur `from_raw` herwin is.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Konstrueer 'n `Rc<T>` vanaf 'n rou aanwyser.
    ///
    /// Die rou aanwyser moet voorheen teruggestuur word deur 'n oproep na [`Rc<U>::into_raw`][into_raw], waar `U` dieselfde grootte en belyning as `T` moet hê.
    /// Dit is triviaal waar as `U` `T` is.
    /// Let daarop dat as `U` nie `T` is nie, maar dieselfde grootte en belyning het, is dit basies soos die verwysing van verskillende soorte.
    /// Raadpleeg [`mem::transmute`][transmute] vir meer inligting oor watter beperkings in hierdie geval geld.
    ///
    /// Die gebruiker van `from_raw` moet sorg dat 'n spesifieke waarde van `T` net een keer val.
    ///
    /// Hierdie funksie is onveilig, want verkeerde gebruik kan lei tot geheime onveiligheid, selfs al is die toegang tot die `Rc<T>` nooit beskikbaar nie.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Skakel terug na 'n `Rc` om lek te voorkom.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Verdere oproepe na `Rc::from_raw(x_ptr)` sal geheue-onveilig wees.
    /// }
    ///
    /// // Die geheue is bevry toe `x` buite die bestek hierbo gekom het, en dus hang `x_ptr` nou!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Keer die offset om die oorspronklike RcBox te vind.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Skep 'n nuwe [`Weak`]-wyser vir hierdie toekenning.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Sorg dat ons nie 'n hangende Swak skep nie
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Kry die aantal [`Weak`]-wysers vir hierdie toekenning.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Kry die aantal sterk (`Rc`)-aanwysers vir hierdie toekenning.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Wys `true` as daar geen ander `Rc`-of [`Weak`]-aanwysers vir hierdie toekenning is nie.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Wys 'n veranderlike verwysing na die gegewe `Rc` as daar geen ander `Rc`-of [`Weak`]-aanwysers vir dieselfde toekenning is nie.
    ///
    ///
    /// Wys [`None`] anders, want dit is nie veilig om 'n gedeelde waarde te verander nie.
    ///
    /// Kyk ook na [`make_mut`][make_mut], wat die innerlike waarde [`clone`][clone] sal maak as daar ander wysers is.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Wys 'n veranderlike verwysing na die gegewe `Rc`, sonder enige tjek.
    ///
    /// Kyk ook na [`get_mut`], wat veilig is en toepaslike kontrole doen.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Enige ander `Rc`-of [`Weak`]-aanwysers vir dieselfde toekenning mag nie vir die duur van die terugbetaalde lening verwys word nie.
    ///
    /// Dit is triviaal die geval as daar nie sulke aanwysings bestaan nie, byvoorbeeld onmiddellik na `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Ons is versigtig om *nie*'n verwysing te skep wat die "count"-velde dek nie, want dit sou bots met toegang tot die verwysingstellings (bv.
        // deur `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Wys `true` as die twee 'Rc'e op dieselfde toewysing dui (in 'n soortgelyk aan [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Maak 'n veranderlike verwysing na die gegewe `Rc`.
    ///
    /// As daar ander `Rc`-aanwysers vir dieselfde toekenning is, sal `make_mut` die innerlike waarde van 'n nuwe toekenning [`clone`] om unieke eienaarskap te verseker.
    /// Dit word ook kloon-aan-skryf genoem.
    ///
    /// As daar geen ander `Rc`-aanwysers vir hierdie toekenning is nie, word [`Weak`]-aanwysers vir hierdie toekenning ontkoppel.
    ///
    /// Kyk ook na [`get_mut`], wat sal misluk eerder as kloning.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Sal niks kloon nie
    /// let mut other_data = Rc::clone(&data);    // Sal nie innerlike data kloon nie
    /// *Rc::make_mut(&mut data) += 1;        // Klone innerlike data
    /// *Rc::make_mut(&mut data) += 1;        // Sal niks kloon nie
    /// *Rc::make_mut(&mut other_data) *= 2;  // Sal niks kloon nie
    ///
    /// // Nou wys `data` en `other_data` op verskillende toekennings.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] wenke sal gedisassosieer word:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Moet die data kloon, daar is ander RC's.
            // Ken vooraf geheue toe om die gekloonde waarde direk te kan skryf.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Kan net die data steel, al wat oorbly is Swak
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Verwyder implisiete sterk-swak ref (dit is nie nodig om 'n valse Swak hier te maak nie-ons weet dat ander Swakke vir ons kan opruim)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Hierdie onveiligheid is goed, want ons is gewaarborg dat die wyser wat teruggestuur word, die *enigste* aanwyser is wat ooit na T sal teruggestuur word.
        // Ons verwysingtelling is op hierdie stadium gewaarborg, en ons het vereis dat die `Rc<T>` self `mut` is, dus stuur ons die enigste moontlike verwysing na die toekenning terug.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Probeer om die `Rc<dyn Any>` tot 'n konkrete tipe te laat val.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Ken 'n `RcBox<T>` toe met voldoende ruimte vir 'n moontlik nie-grootte binnewaarde waar die waarde die uitleg bied.
    ///
    /// Die funksie `mem_to_rcbox` word met die datawyser geroep en moet 'n (potensieel vet)-wyser vir die `RcBox<T>` terugbesorg.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Bereken die uitleg met behulp van die gegewe waarde-uitleg.
        // Voorheen is die uitleg op die uitdrukking `&*(ptr as* const RcBox<T>)` bereken, maar dit het 'n foutiewe verwysing geskep (sien #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Ken 'n `RcBox<T>` toe met voldoende ruimte vir 'n moontlik nie-grootte binnewaarde waar die waarde van die uitleg voorsien is, en gee 'n fout terug as die toewysing misluk.
    ///
    ///
    /// Die funksie `mem_to_rcbox` word met die datawyser geroep en moet 'n (potensieel vet)-wyser vir die `RcBox<T>` terugbesorg.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Bereken die uitleg met behulp van die gegewe waarde-uitleg.
        // Voorheen is die uitleg op die uitdrukking `&*(ptr as* const RcBox<T>)` bereken, maar dit het 'n foutiewe verwysing geskep (sien #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Ken die uitleg toe.
        let ptr = allocate(layout)?;

        // Initialiseer die RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Ken 'n `RcBox<T>` toe met voldoende ruimte vir 'n ongroot grootte innerlike waarde
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Ken die `RcBox<T>` toe met behulp van die gegewe waarde.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopieer waarde as grepe
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Bevry die toekenning sonder om die inhoud daarvan te laat vaar
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Ken 'n `RcBox<[T]>` toe met die gegewe lengte.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Kopieer elemente van die sny in die nuut toegewysde Rc <\[T\]>
    ///
    /// Onveilig, want die oproeper moet eienaarskap neem of `T: Copy` bind
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Konstrueer 'n `Rc<[T]>` van 'n iterator waarvan bekend is dat dit van 'n sekere grootte is.
    ///
    /// Gedrag is ongedefinieerd as die grootte verkeerd is.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic beskerm terwyl T-elemente gekloon word.
        // In die geval van 'n panic, sal elemente wat in die nuwe RcBox geskryf is, weggeval word, dan word die geheue vrygestel.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Aanwyser na eerste element
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Alles duidelik.Vergeet die wag sodat dit nie die nuwe RcBox bevry nie.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Spesialisasie trait gebruik vir `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Laat val die `Rc`.
    ///
    /// Dit sal die sterk verwysingstelling verminder.
    /// As die sterk verwysingstelling nul bereik, is die enigste ander verwysings (indien enige) [`Weak`], dus is `drop` die innerlike waarde.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Druk niks nie
    /// drop(foo2);   // Druk "dropped!" af
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // vernietig die ingeslote voorwerp
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // verwyder die implisiete "strong weak"-wyser noudat ons die inhoud vernietig het.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Maak 'n kloon van die `Rc`-wyser.
    ///
    /// Dit skep 'n ander wyser vir dieselfde toekenning, wat die sterk verwysingstelling verhoog.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Skep 'n nuwe `Rc<T>` met die `Default`-waarde vir `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack om spesialisering op `Eq` toe te laat, alhoewel `Eq` 'n metode het.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Ons doen hierdie spesialisasie hier, en nie as 'n meer algemene optimalisering op `&T` nie, omdat dit andersins 'n koste sal toevoeg aan alle gelykheidskontroles op refs.
/// Ons neem aan dat 'RC's gebruik word om groot waardes op te slaan, wat stadig gekloon word, maar ook moeilik is om te kyk of dit gelyk is, wat die koste makliker laat betaal.
///
/// Dit is ook meer geneig om twee `Rc`-klone te hê, wat op dieselfde waarde dui, as twee '&T'e.
///
/// Ons kan dit net doen as `T: Eq` as `PartialEq` doelbewus irrefleksief is.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Gelykheid vir twee `Rc`s.
    ///
    /// Twee 'RC'e is gelyk as hul innerlike waardes gelyk is, selfs al word dit in verskillende toekennings gestoor.
    ///
    /// As `T` ook `Eq` implementeer (wat refleksiwiteit van gelykheid impliseer), is twee 'Rc'e wat op dieselfde toewysing dui altyd gelyk.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Ongelykheid vir twee 'RC'e.
    ///
    /// Twee 'RC'e is ongelyk as hul innerlike waardes nie gelyk is nie.
    ///
    /// As `T` ook `Eq` implementeer (wat refleksiwiteit van gelykheid impliseer), is twee RC's wat op dieselfde toewysing dui nooit ongelyk nie.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Gedeeltelike vergelyking vir twee `Rc`s.
    ///
    /// Die twee word vergelyk deur `partial_cmp()` op hul innerlike waardes te noem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Minder as vergelyking vir twee 'RC'e.
    ///
    /// Die twee word vergelyk deur `<` op hul innerlike waardes te noem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// 'Minder as of gelyk aan' vergelyking vir twee 'RC's.
    ///
    /// Die twee word vergelyk deur `<=` op hul innerlike waardes te noem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Groter-as-vergelyking vir twee 'RC'e.
    ///
    /// Die twee word vergelyk deur `>` op hul innerlike waardes te noem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 'Groter as of gelyk aan' vergelyking vir twee 'RC's.
    ///
    /// Die twee word vergelyk deur `>=` op hul innerlike waardes te noem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Vergelyking vir twee `Rc`s.
    ///
    /// Die twee word vergelyk deur `cmp()` op hul innerlike waardes te noem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Ken 'n sny met verwysings toe en vul dit deur 'v'-items te kloon.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Ken 'n snyplaat wat deur die verwysing getel is, toe en kopieer `v` daarin.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Ken 'n snyplaat wat deur die verwysing getel is, toe en kopieer `v` daarin.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Skuif 'n voorwerp in 'n boks na 'n nuwe toekenning, verwysing getel.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Ken 'n sny met verwysing toe en skuif 'v'-items daarin.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Laat die Vec sy geheue vry, maar nie die inhoud daarvan vernietig nie
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Neem elke element in die `Iterator` en versamel dit in 'n `Rc<[T]>`.
    ///
    /// # Prestasie-eienskappe
    ///
    /// ## Die algemene saak
    ///
    /// In die algemeen word versameling in `Rc<[T]>` gedoen deur eers in 'n `Vec<T>` te versamel.Dit wil sê wanneer u die volgende skryf:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// dit tree op asof ons geskryf het:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Die eerste stel toekennings vind hier plaas.
    ///     .into(); // Hier vind 'n tweede toekenning vir `Rc<[T]>` plaas.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Dit sal soveel keer toewys as wat nodig is vir die konstruksie van die `Vec<T>`, en dan sal dit een keer toewys vir die omskakeling van die `Vec<T>` in die `Rc<[T]>`.
    ///
    ///
    /// ## Iterators van bekende lengte
    ///
    /// Wanneer u `Iterator` `TrustedLen` implementeer en van 'n presiese grootte is, sal 'n enkele toekenning vir die `Rc<[T]>` gemaak word.Byvoorbeeld:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Hier vind net 'n enkele toekenning plaas.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Spesialisasie trait word gebruik om `Rc<[T]>` in te samel.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Dit is die geval vir 'n `TrustedLen`-iterator.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // VEILIGHEID: Ons moet toesien dat die iterator 'n presiese lengte het en ons het.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Daal terug na normale implementering.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` is 'n weergawe van [`Rc`] wat 'n nie-besit-verwysing na die bestuurde toekenning bevat.U kan toegang tot die toewysing verkry deur [`upgrade`] op die `Weak`-aanwyser aan te roep, wat 'n [`Opsie`]`<`[`Rc`] `oplewer<T>>`.
///
/// Aangesien 'n `Weak`-verwysing nie tot eienaarskap tel nie, sal dit nie verhoed dat die waarde wat in die toekenning gestoor word, val nie, en `Weak` self gee geen waarborge daarvoor dat die waarde steeds beskikbaar is nie.
/// Dit kan dus [`None`] teruggee wanneer ['upgrade'] d.
/// Let egter daarop dat 'n `Weak`-verwysing * voorkom dat die toekenning self (die agtergrondwinkel) herdeel word.
///
/// 'N `Weak`-aanwyser is handig om 'n tydelike verwysing na die toewysing wat deur [`Rc`] bestuur word te hou sonder om te verhoed dat die innerlike waarde daarvan val.
/// Dit word ook gebruik om sirkulêre verwysings tussen [`Rc`]-aanwysers te voorkom, aangesien verwysings deur onderlinge besit nooit toelaat dat die [`Rc`] laat vaar nie.
/// Byvoorbeeld, 'n boom kan sterk [`Rc`]-aanwysers hê, van ouer nodusse tot kinders, en `Weak`-aanwysers van kinders terug na hul ouers.
///
/// Die tipiese manier om 'n `Weak`-wyser te bekom, is om [`Rc::downgrade`] te skakel.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Dit is 'n `NonNull` om die grootte van hierdie tipe in enums te optimaliseer, maar dit is nie noodwendig 'n geldige wyser nie.
    //
    // `Weak::new` stel dit op `usize::MAX` sodat dit nie ruimte op die hoop hoef toe te ken nie.
    // Dit is nie 'n waarde wat 'n regte wyser ooit sal hê nie, want RcBox het ten minste 2 belyning.
    // Dit is slegs moontlik wanneer `T: Sized`;ongroot `T` hang nooit.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Konstrueer 'n nuwe `Weak<T>`, sonder om geheue toe te ken.
    /// Om [`upgrade`] op die retourwaarde te noem, gee altyd [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Helper-tipe om toegang te verkry tot die verwysingstellings sonder om enige bewerings oor die dataveld te maak.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Wys 'n rou wyser na die voorwerp `T` waarop hierdie `Weak<T>` wys.
    ///
    /// Die aanwyser is slegs geldig as daar sterk verwysings is.
    /// Die aanwyser kan anders hang, hang nie of selfs [`null`] nie.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Albei wys op dieselfde voorwerp
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Die sterk hier hou dit lewendig, sodat ons steeds toegang tot die voorwerp kan kry.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Maar nie meer nie.
    /// // Ons kan weak.as_ptr() doen, maar toegang tot die wyser kan lei tot ongedefinieerde gedrag.
    /// // assert_eq! ("hallo", onveilig {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // As die wyser hang, stuur ons die sentinel direk terug.
            // Dit kan nie 'n geldige loonadres wees nie, aangesien die loonvrag minstens net so ooreenstem as RcBox (usize).
            ptr as *const T
        } else {
            // VEILIGHEID: as is_dangling vals is, dan kan die wyser herverwysbaar wees.
            // Die loonvrag kan op hierdie stadium laat val word, en ons moet die herkoms behou, dus gebruik rou wysermanipulasie.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Verbruik die `Weak<T>` en verander dit in 'n rou aanwyser.
    ///
    /// Dit omskep die swak aanwyser in 'n rou aanwyser, terwyl u steeds die eienaarskap van een swak verwysing behou (die swak telling word nie deur hierdie bewerking verander nie).
    /// Dit kan weer in die `Weak<T>` met [`from_raw`] verander word.
    ///
    /// Dieselfde beperkings vir toegang tot die teiken van die wyser geld as met [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Skakel 'n rou wyser wat voorheen deur [`into_raw`] geskep is, terug in `Weak<T>`.
    ///
    /// Dit kan gebruik word om veilig 'n sterk verwysing te kry (deur later [`upgrade`] te skakel) of om die swak telling te herplaas deur die `Weak<T>` te laat val.
    ///
    /// Dit neem eienaarskap van een swak verwysing (met die uitsondering van aanwysings wat deur [`new`] geskep is, aangesien dit niks besit nie; die metode werk nog steeds daarop).
    ///
    /// # Safety
    ///
    /// Die wyser moet van die [`into_raw`] afkomstig wees en moet steeds die potensiële swak verwysing besit.
    ///
    /// Dit is toegelaat dat die sterk telling 0 is wanneer u dit noem.
    /// Dit neem nietemin eienaarskap van een swak verwysing wat tans as 'n rou aanwyser voorgestel word (die swak telling word nie deur hierdie bewerking aangepas nie) en daarom moet dit gekoppel word aan 'n vorige oproep na [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Verminder die laaste swak telling.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Sien Weak::as_ptr vir konteks oor hoe die invoerwyser afgelei word.

        let ptr = if is_dangling(ptr as *mut T) {
            // Dit is 'n hangende swak.
            ptr as *mut RcBox<T>
        } else {
            // Anders word ons gewaarborg dat die aanwyser afkomstig is van 'n nie-hangende Swak.
            // VEILIGHEID: data_offset is veilig om te bel, aangesien ptr verwys na 'n regte (potensieel laat val) T.
            let offset = unsafe { data_offset(ptr) };
            // Dus keer ons die verrekening om die hele RcBox te kry.
            // VEILIGHEID: die aanwyser het sy oorsprong in 'n swak punt, dus hierdie verrekening is veilig.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // VEILIGHEID: ons het nou die oorspronklike Swak wyser herwin, sodat ons die Swak kan skep.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Pogings om die `Weak`-wyser na 'n [`Rc`] op te gradeer, laat val van die innerlike waarde as dit suksesvol is.
    ///
    ///
    /// Wys [`None`] as die innerlike waarde intussen gedaal het.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Vernietig alle sterk wenke.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Kry die aantal sterk (`Rc`)-aanwysers wat op hierdie toekenning dui.
    ///
    /// As `self` met [`Weak::new`] geskep is, sal dit 0 lewer.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Kry die aantal `Weak`-wysers wat op hierdie toekenning dui.
    ///
    /// As daar geen sterk wenke oorbly nie, sal dit nul wees.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // trek die implisiete swak ptr af
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Wys `None` as die wyser hang en daar geen `RcBox` toegeken is nie (dws wanneer hierdie `Weak` deur `Weak::new` geskep is).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Ons is versigtig om *nie*'n verwysing te maak wat die "data"-veld dek nie, aangesien die veld gelyktydig gemuteer kan word (as die laaste `Rc` byvoorbeeld laat val word, sal die dataveld op sy plek val).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Wys `true` as die twee 'Swak'e op dieselfde toewysing dui (soortgelyk aan [`ptr::eq`]), of as albei nie op enige toewysing dui nie (omdat dit met `Weak::new()`) geskep is.
    ///
    ///
    /// # Notes
    ///
    /// Aangesien hierdie wenke vergelyk word, beteken dit dat `Weak::new()` mekaar sal ewenaar, alhoewel dit nie op enige toekenning dui nie.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Vergelyk `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Laat val die `Weak`-wyser.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Druk niks nie
    /// drop(foo);        // Druk "dropped!" af
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // die swak telling begin by 1 en sal slegs na nul gaan as al die sterk wysers verdwyn het.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Maak 'n kloon van die `Weak`-wyser wat op dieselfde toewysing dui.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Konstrueer 'n nuwe `Weak<T>`, wat geheue aan `T` toewys sonder om dit te initialiseer.
    /// Om [`upgrade`] op die retourwaarde te noem, gee altyd [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Ons het hier gekyk om mem::forget veilig te hanteer.In die besonder
// as u mem::forget Rcs (of Weaks) het, kan die ref-count oorloop, en dan kan u die toekenning bevry terwyl daar nog Rcs (of Weaks) bestaan.
//
// Ons staak omdat dit so 'n ontaarde scenario is dat ons nie omgee vir wat gebeur nie-geen werklike program sal dit ooit ervaar nie.
//
// Dit moet 'n onbeduidende oorhoofse bedrag hê, aangesien u dit nie regtig in Rust hoef te kloon nie, danksy eienaarskap en verskuiwingsemantiek.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Ons wil by oorloop staak in plaas van om die waarde te laat val.
        // Die verwysingstelling sal nooit nul wees as dit genoem word nie;
        // nietemin voeg ons hier 'n staking in om LLVM op 'n andersins gemiste optimalisering te laat deurskemer.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Ons wil by oorloop staak in plaas van om die waarde te laat val.
        // Die verwysingstelling sal nooit nul wees as dit genoem word nie;
        // nietemin voeg ons hier 'n staking in om LLVM op 'n andersins gemiste optimalisering te laat deurskemer.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Kry die verrekening binne 'n `RcBox` vir die loonvrag agter 'n aanwyser.
///
/// # Safety
///
/// Die aanwyser moet wys op (en geldige metadata hê) vir 'n voorheen geldige instansie van T, maar die T mag toegelaat word om te val.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Rig die ongepaste waarde aan die einde van die RcBox.
    // Omdat RcBox repr(C) is, sal dit altyd die laaste veld in die geheue wees.
    // VEILIGHEID: aangesien snitte, trait-voorwerpe, die enigste ongrootte soorte moontlik is,
    // en eksterne tipes, is die invoerveiligheidsvereiste tans voldoende om aan die vereistes van align_of_val_raw te voldoen;dit is 'n implementeringsdetail van die taal waarop nie buite std staatgemaak kan word nie.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}