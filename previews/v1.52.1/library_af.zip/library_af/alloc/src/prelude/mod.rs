//! Die toekenning Prelude
//!
//! Die doel van hierdie module is om die invoer van algemeen gebruikte items van die `alloc` crate te verlig deur 'n globale invoer aan die bokant van die modules toe te voeg:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;