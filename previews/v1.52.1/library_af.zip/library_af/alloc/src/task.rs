#![stable(feature = "wake_trait", since = "1.51.0")]
//! Tipes en Traits om met asynchrone take te werk.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Die implementering van die wek van 'n taak op 'n eksekuteur.
///
/// Hierdie trait kan gebruik word om 'n [`Waker`] te skep.
/// 'N Eksekuteur kan die implementering van hierdie trait definieer en dit gebruik om 'n Waker te konstrueer om na die take wat aan die eksekuteur uitgevoer word, deur te gee.
///
/// Hierdie trait is 'n geheue-veilige en ergonomiese alternatief vir die konstruksie van 'n [`RawWaker`].
/// Dit ondersteun die algemene uitvoerende ontwerp waarin die data wat gebruik word om 'n taak wakker te maak, in 'n [`Arc`] gestoor word.
/// Sommige uitvoerders (veral dié vir ingeboude stelsels) kan nie hierdie API gebruik nie, en daarom bestaan [`RawWaker`] as alternatief vir daardie stelsels.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// 'N Basiese `block_on`-funksie wat 'n future neem en dit op die huidige draad voltooi.
///
/// **Note:** Hierdie voorbeeld verhandel korrektheid vir eenvoud.
/// Om dooiepunte te voorkom, moet implementerings van produksiegraad ook tussenoproepe na `thread::unpark` sowel as geneste aanroepe hanteer.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// 'N Wakker wat die huidige draad wakker maak as dit gebel word.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Voer 'n future uit op die huidige draad.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Speld die future vas sodat dit gepols kan word.
///     let mut fut = Box::pin(fut);
///
///     // Skep 'n nuwe konteks wat na die future oorgedra moet word.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Begin die future tot voltooiing.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Maak hierdie taak wakker.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Maak hierdie taak wakker sonder om die wakker te verteer.
    ///
    /// As 'n eksekuteur 'n goedkoper manier om wakker te word ondersteun sonder om die waker te verbruik, moet dit hierdie metode oorheers.
    /// Dit kloon die [`Arc`] standaard en roep [`wake`] op die kloon.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // VEILIGHEID: Dit is veilig omdat raw_waker veilig konstrueer
        // 'n RawWaker van Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Hierdie private funksie vir die konstruksie van 'n RawWaker word eerder as gebruik
// om dit in die `From<Arc<W>> for RawWaker`-impl in te stel, om te verseker dat die veiligheid van `From<Arc<W>> for Waker` nie afhang van die regte trait-versending nie, maar albei noem hierdie funksie direk en eksplisiet.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Verhoog die verwysingstelling van die boog om dit te kloon.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Word wakker volgens waarde en beweeg die Arc na die Wake::wake-funksie
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Word wakker deur verwysing, draai die wakker in ManuallyDrop om dit te laat val
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Verminder die verwysingstelling van die Arc on drop
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}