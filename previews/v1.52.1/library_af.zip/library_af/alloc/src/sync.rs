#![stable(feature = "rust1", since = "1.0.0")]

//! Draadveilige verwysings-telwysers.
//!
//! Raadpleeg die [`Arc<T>`][Arc]-dokumentasie vir meer besonderhede.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// 'N Sagte beperking op die hoeveelheid verwysings wat na 'n `Arc` verwys kan word.
///
/// As u hierdie limiet oorskry, word u program (hoewel nie noodwendig nie) met _exactly_ `MAX_REFCOUNT + 1`-verwysings beëindig.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer ondersteun nie geheueheinings nie.
// Gebruik eerder atoomlading vir sinkronisasie om vals positiewe verslae in die boog/swak implementering te voorkom.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// 'N Draadveilige verwysings-aanwyser.'Arc' staan vir 'Atomically Reference Counted'.
///
/// Die tipe `Arc<T>` bied gedeelde eienaarskap van 'n waarde van die tipe `T`, toegeken in die hoop.Om [`clone`][clone] op `Arc` aan te roep, lewer 'n nuwe `Arc`-instansie wat op dieselfde toewysing as die bron `Arc` dui, terwyl die verwysingstelling verhoog word.
/// Wanneer die laaste `Arc`-aanwyser na 'n gegewe toekenning vernietig word, word die waarde wat in die toekenning gestoor word (dikwels "inner value" genoem) ook laat val.
///
/// Gedeelde verwysings in Rust laat mutasies by verstek nie toe nie, en `Arc` is geen uitsondering nie: u kan gewoonlik nie 'n veranderlike verwysing na iets in 'n `Arc` kry nie.As u deur 'n `Arc` moet muteer, gebruik [`Mutex`][mutex], [`RwLock`][rwlock] of een van die [`Atomic`][atomic]-tipes.
///
/// ## Draadveiligheid
///
/// Anders as [`Rc<T>`], gebruik `Arc<T>` atoombewerkings om sy verwysing te tel.Dit beteken dat dit draadvas is.Die nadeel is dat atoombewerkings duurder is as gewone geheue-toegang.As u nie verwysingstoekennings tussen drade deel nie, oorweeg dit om [`Rc<T>`] vir laer bokoste te gebruik.
/// [`Rc<T>`] is 'n veilige standaard, omdat die samesteller enige poging om 'n [`Rc<T>`] tussen drade te stuur, sal vang.
/// 'N Biblioteek kan egter `Arc<T>` kies om biblioteekverbruikers meer buigsaamheid te gee.
///
/// `Arc<T>` sal [`Send`] en [`Sync`] implementeer solank die `T` [`Send`] en [`Sync`] implementeer.
/// Waarom kan u nie 'n draadvrye tipe `T` in 'n `Arc<T>` plaas om dit draadveilig te maak nie?Dit kan aanvanklik 'n bietjie kontra-intuïtief wees: is dit nie die punt van `Arc<T>`-draadveiligheid nie?Die sleutel is die volgende: `Arc<T>` maak dit draad veilig om meervoudige eienaarskap van dieselfde data te hê, maar dit voeg nie draadveiligheid by sy data nie.
///
/// Oorweeg `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] is nie [`Sync`] nie, en as `Arc<T>` altyd [`Send`] was, is 'Arc <`[` RefCell<T>`]`> `sou ook wees.
/// Maar dan sou ons 'n probleem hê:
/// [`RefCell<T>`] is nie draad veilig nie;dit hou die leentelling by deur middel van nie-atoombewerkings.
///
/// Uiteindelik beteken dit dat u `Arc<T>` dalk met 'n soort [`std::sync`]-tipe, gewoonlik [`Mutex<T>`][mutex], moet koppel.
///
/// ## Breek siklusse met `Weak`
///
/// Die [`downgrade`][downgrade]-metode kan gebruik word om 'n nie-besitende [`Weak`]-wyser te skep.'N [`Weak`]-aanwyser kan [' upgrade '][upgrade] d wees na 'n `Arc`, maar dit sal [`None`] teruggee as die waarde wat in die toekenning gestoor is, reeds laat val is.
/// Met ander woorde, `Weak`-wysers hou nie die waarde binne die toekenning lewend nie;hulle hou die toewysing (die agtergrondwinkel vir die waarde) egter lewendig.
///
/// 'N Siklus tussen `Arc`-aanwysers sal nooit herdeel word nie.
/// Om hierdie rede word [`Weak`] gebruik om siklusse te breek.Byvoorbeeld, 'n boom kan sterk `Arc`-aanwysers hê van ouernodusse tot kinders, en [`Weak`]-aanwysers van kinders terug na hul ouers.
///
/// # Kloning van verwysings
///
/// Die skep van 'n nuwe verwysing vanaf 'n bestaande verwysingsgetelde aanwyser word gedoen met behulp van die `Clone` trait wat geïmplementeer is vir [`Arc<T>`][Arc] en [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Die twee sintaksis hieronder is ekwivalent.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b en foo is almal Boë wat op dieselfde geheueplek dui
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` Verwys outomaties na `T` (via die [`Deref`][deref] trait), sodat u 'T'-metodes kan noem op 'n waarde van die tipe `Arc<T>`.Om naambotsings met 'T'-metodes te voorkom, is die metodes van `Arc<T>` self geassosieerde funksies, wat [fully qualified syntax] genoem word:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Boog<T>Die implementering van traits soos `Clone` kan ook genoem word met behulp van volledig gekwalifiseerde sintaksis.
/// Sommige mense verkies om ten volle gekwalifiseerde sintaksis te gebruik, terwyl ander verkies om sintaks vir metode-oproepe te gebruik.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Metaks-oproep sintaksis
/// let arc2 = arc.clone();
/// // Ten volle gekwalifiseerde sintaksis
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] verwys nie outomaties na `T` nie, omdat die innerlike waarde dalk reeds laat val is.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Deel 'n paar onveranderlike data tussen drade:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Let daarop dat ons **nie** hierdie toetse hier uitvoer nie.
// Die windows-bouers word baie ongelukkig as 'n draad die hoofdraad oorleef en dan terselfdertyd verlaat (iets wat vas is), dus vermy ons dit heeltemal deur nie hierdie toetse uit te voer nie.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Deel 'n veranderlike [`AtomicUsize`]:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Raadpleeg die [`rc` documentation][rc_examples] vir meer voorbeelde van verwysingtelling in die algemeen.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` is 'n weergawe van [`Arc`] wat 'n nie-besit-verwysing na die bestuurde toekenning bevat.
/// Toegang tot die toewysing is deur [`upgrade`] op die `Weak`-aanwyser te skakel, wat 'n [`Opsie`]`<`[`Boog`] `oplewer<T>>`.
///
/// Aangesien 'n `Weak`-verwysing nie tot eienaarskap tel nie, sal dit nie verhoed dat die waarde wat in die toekenning gestoor word, val nie, en `Weak` self gee geen waarborge daarvoor dat die waarde steeds beskikbaar is nie.
///
/// Dit kan dus [`None`] teruggee wanneer ['upgrade'] d.
/// Let egter daarop dat 'n `Weak`-verwysing * voorkom dat die toekenning self (die agtergrondwinkel) herdeel word.
///
/// 'N `Weak`-aanwyser is handig om 'n tydelike verwysing na die toewysing wat deur [`Arc`] bestuur word te hou sonder om te verhoed dat die innerlike waarde daarvan val.
/// Dit word ook gebruik om sirkulêre verwysings tussen [`Arc`]-aanwysers te voorkom, aangesien verwysings deur onderlinge besit nooit toelaat dat die [`Arc`] laat vaar nie.
/// Byvoorbeeld, 'n boom kan sterk [`Arc`]-aanwysers hê van ouernodusse tot kinders, en `Weak`-aanwysers van kinders terug na hul ouers.
///
/// Die tipiese manier om 'n `Weak`-wyser te bekom, is om [`Arc::downgrade`] te skakel.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Dit is 'n `NonNull` om die grootte van hierdie tipe in enums te optimaliseer, maar dit is nie noodwendig 'n geldige wyser nie.
    //
    // `Weak::new` stel dit op `usize::MAX` sodat dit nie ruimte op die hoop hoef toe te ken nie.
    // Dit is nie 'n waarde wat 'n regte wyser ooit sal hê nie, want RcBox het ten minste 2 belyning.
    // Dit is slegs moontlik wanneer `T: Sized`;ongroot `T` hang nooit.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Dit is repr(C) tot future-bestendig teen moontlike veldherrangskikking, wat die andersins veilige [into|from]_raw() van oordraagbare binnetipes sal belemmer.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // die waarde usize::MAX dien as 'n wagter vir die tydelike "locking" om die vermoë om swak wysers op te gradeer of sterk punte af te gradeer;dit word gebruik om wedrenne in `make_mut` en `get_mut` te vermy.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Konstrueer 'n nuwe `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Begin die swak wysertelling as 1, dit is die swak wyser wat deur al die sterk wysers (kinda) gehou word, sien std/rc.rs vir meer inligting
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Konstrueer 'n nuwe `Arc<T>` met 'n swak verwysing na homself.
    /// As u die swak verwysing probeer opgradeer voordat hierdie funksie terugkeer, sal dit 'n `None`-waarde hê.
    /// Die swak verwysing kan egter vrylik gekloon word en later gestoor word.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Konstrueer die binnekant in die "uninitialized"-toestand met 'n enkele swak verwysing.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Dit is belangrik dat ons nie die eienaarskap van die swak aanwyser prysgee nie, anders kan die geheue vrygestel word wanneer `data_fn` terugkom.
        // As ons regtig eienaarskap wil deurgee, kan ons 'n bykomende swak aanwyser vir onsself skep, maar dit sal lei tot bykomende opdaterings van die swak verwysingstelling wat andersins nie nodig is nie.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Nou kan ons die innerlike waarde behoorlik inisialiseer en ons swak verwysing in 'n sterk verwysing verander.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Bogenoemde skryf na die dataveld moet sigbaar wees vir drade wat 'n sterk telling van nie-nul waarneem.
            // Daarom het ons ten minste "Release"-bestelling nodig om met die `compare_exchange_weak` in `Weak::upgrade` te sinkroniseer.
            //
            // "Acquire" bestel is nie nodig nie.
            // As ons die moontlike gedrag van `data_fn` oorweeg, hoef ons net te kyk wat dit kan doen met verwysing na 'n nie-opgradeerbare `Weak`:
            //
            // - Dit kan die `Weak` * kloon, wat die swak verwysingtelling verhoog.
            // - Dit kan daardie klone laat val, wat die swak verwysingstelling verminder (maar nooit tot nul nie).
            //
            // Hierdie newe-effekte beïnvloed ons geensins nie, en met veilige kode alleen is geen ander newe-effekte moontlik nie.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Sterk verwysings moet gesamentlik 'n gedeelde swak verwysing besit, dus moenie die vernietiger gebruik vir ons ou swak verwysing nie.
        //
        mem::forget(weak);
        strong
    }

    /// Konstrueer 'n nuwe `Arc` met nie-geïnitialiseerde inhoud.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Uitgestelde initialisering:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstrueer 'n nuwe `Arc` met ongeïnitialiseerde inhoud, met die geheue gevul met `0` grepe.
    ///
    ///
    /// Kyk na [`MaybeUninit::zeroed`][zeroed] vir voorbeelde van die korrekte en verkeerde gebruik van hierdie metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstrueer 'n nuwe `Pin<Arc<T>>`.
    /// As `T` nie `Unpin` implementeer nie, sal `data` in die geheue vasgepen word en kan dit nie geskuif word nie.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Konstrueer 'n nuwe `Arc<T>` en gee 'n fout terug as die toewysing misluk.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Begin die swak wysertelling as 1, dit is die swak wyser wat deur al die sterk wysers (kinda) gehou word, sien std/rc.rs vir meer inligting
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Konstrueer 'n nuwe `Arc` met ongeïnitialiseerde inhoud, en gee 'n fout terug as die toewysing misluk.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Uitgestelde initialisering:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Konstrueer 'n nuwe `Arc` met nie-geïnitialiseerde inhoud, terwyl die geheue gevul is met `0` bytes, wat 'n fout weergee as die toewysing misluk.
    ///
    ///
    /// Kyk na [`MaybeUninit::zeroed`][zeroed] vir voorbeelde van die korrekte en verkeerde gebruik van hierdie metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Wys die innerlike waarde as die `Arc` presies een sterk verwysing het.
    ///
    /// Andersins word 'n [`Err`] teruggestuur met dieselfde `Arc` wat ingedien is.
    ///
    ///
    /// Dit sal slaag, selfs al is daar uitstekende swak verwysings.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Maak 'n swak aanwyser om die implisiete verwysing na sterk-swak op te ruim
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Konstrueer 'n nuwe atoomverwysingsgetel sny met nie-geïnitialiseerde inhoud.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Uitgestelde initialisering:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Konstrueer 'n nuwe atoomverwysingsgetelde stuk met nie-geïnitialiseerde inhoud, met die geheue gevul met `0` bytes.
    ///
    ///
    /// Kyk na [`MaybeUninit::zeroed`][zeroed] vir voorbeelde van die korrekte en verkeerde gebruik van hierdie metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Skakel oor na `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Soos met [`MaybeUninit::assume_init`], is dit die oproeper om te waarborg dat die innerlike waarde regtig in 'n geïnitialiseerde toestand is.
    ///
    /// Om dit te noem as die inhoud nog nie volledig geïnisialiseer is nie, veroorsaak onmiddellike ongedefinieerde gedrag.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Uitgestelde initialisering:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Skakel oor na `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Soos met [`MaybeUninit::assume_init`], is dit die oproeper om te waarborg dat die innerlike waarde regtig in 'n geïnitialiseerde toestand is.
    ///
    /// Om dit te noem as die inhoud nog nie volledig geïnisialiseer is nie, veroorsaak onmiddellike ongedefinieerde gedrag.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Uitgestelde initialisering:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Verbruik die `Arc` en gee die toegepaste wyser terug.
    ///
    /// Om 'n geheue-lek te voorkom, moet die wyser weer met 'n [`Arc::from_raw`] na 'n `Arc` omgeskakel word.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Voorsien 'n rou wyser van die data.
    ///
    /// Die tellings word geensins beïnvloed nie en die `Arc` word nie verbruik nie.
    /// Die aanwyser is geldig solank as wat daar sterk tellings in die `Arc` is.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // VEILIGHEID: Dit kan nie deur Deref::deref of RcBoxPtr::inner gaan nie omdat
        // dit is nodig om die raw/mut herkoms so te behou dat bv
        // `get_mut` kan deur die wyser skryf nadat die Rc deur `from_raw` herwin is.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Konstrueer 'n `Arc<T>` vanaf 'n rou aanwyser.
    ///
    /// Die rou aanwyser moet voorheen teruggestuur word deur 'n oproep na [`Arc<U>::into_raw`][into_raw], waar `U` dieselfde grootte en belyning as `T` moet hê.
    /// Dit is triviaal waar as `U` `T` is.
    /// Let daarop dat as `U` nie `T` is nie, maar dieselfde grootte en belyning het, is dit basies soos die verwysing van verskillende soorte.
    /// Raadpleeg [`mem::transmute`][transmute] vir meer inligting oor watter beperkings in hierdie geval geld.
    ///
    /// Die gebruiker van `from_raw` moet sorg dat 'n spesifieke waarde van `T` net een keer val.
    ///
    /// Hierdie funksie is onveilig, want verkeerde gebruik kan lei tot geheime onveiligheid, selfs al is die toegang tot die `Arc<T>` nooit beskikbaar nie.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Skakel terug na 'n `Arc` om lek te voorkom.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Verdere oproepe na `Arc::from_raw(x_ptr)` sal geheue-onveilig wees.
    /// }
    ///
    /// // Die geheue is bevry toe `x` buite die bestek hierbo gekom het, en dus hang `x_ptr` nou!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Draai die offset om om die oorspronklike ArcInner te vind.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Skep 'n nuwe [`Weak`]-wyser vir hierdie toekenning.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Dit Ontspanne is OK, want ons kyk na die waarde in die CAS hieronder.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // kyk of die swak toonbank tans "locked" is;so ja, draai.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: hierdie kode ignoreer tans die moontlikheid van oorloop
            // in usize::MAX;in die algemeen moet beide RC en Arc aangepas word om oorloop te hanteer.
            //

            // Anders as met Clone(), is dit nodig dat dit 'n leesstuk is om te sinkroniseer met die skryfwerk wat van `is_unique` afkomstig is, sodat die gebeure voor die skryfwerk voor hierdie leeswerk plaasvind.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Sorg dat ons nie 'n hangende Swak skep nie
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Kry die aantal [`Weak`]-wysers vir hierdie toekenning.
    ///
    /// # Safety
    ///
    /// Hierdie metode is op sigself veilig, maar om dit korrek te gebruik, verg ekstra sorg.
    /// 'N Ander draad kan die swak telling te eniger tyd verander, insluitend die gebruik van hierdie metode tot die resultaat.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Hierdie bewering is deterministies omdat ons die `Arc` of `Weak` nie tussen drade gedeel het nie.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // As die swak telling tans gesluit is, was die waarde van die telling 0 net voordat u die slot geneem het.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Kry die aantal sterk (`Arc`)-aanwysers vir hierdie toekenning.
    ///
    /// # Safety
    ///
    /// Hierdie metode is op sigself veilig, maar om dit korrek te gebruik, verg ekstra sorg.
    /// 'N Ander draad kan die sterk telling te eniger tyd verander, insluitend die gebruik van hierdie metode en die reaksie op die resultaat.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Hierdie bewering is deterministies omdat ons die `Arc` nog nie tussen drade gedeel het nie.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Verhoog die sterk verwysingstelling op die `Arc<T>` wat verband hou met die aangeduide wyser, een.
    ///
    /// # Safety
    ///
    /// Die wyser moet verkry word deur `Arc::into_raw`, en die gepaardgaande `Arc`-instansie moet geldig wees (dws
    /// die sterk telling moet ten minste 1) wees vir die duur van hierdie metode.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Hierdie bewering is deterministies omdat ons die `Arc` nog nie tussen drade gedeel het nie.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Behou Arc, maar raak nie refcount aan deur dit in ManuallyDrop toe te draai nie
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Verhoog nou die heraantal, maar moet ook nie die nuwe heraantal aftrek nie
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Verlaag die sterk verwysingstelling op die `Arc<T>` wat met die aangeduide wyser een geassosieer word.
    ///
    /// # Safety
    ///
    /// Die wyser moet verkry word deur `Arc::into_raw`, en die gepaardgaande `Arc`-instansie moet geldig wees (dws
    /// die sterk telling moet ten minste 1) wees wanneer u hierdie metode gebruik.
    /// Hierdie metode kan gebruik word om die finale `Arc` en backing-berging vry te stel, maar **moet nie** genoem word nadat die finale `Arc` vrygestel is nie.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Hierdie bewerings is deterministies omdat ons die `Arc` nog nie tussen drade gedeel het nie.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Hierdie onveiligheid is in orde, want hoewel hierdie boog lewendig is, is ons gewaarborg dat die binnewyser geldig is.
        // Verder weet ons dat die `ArcInner`-struktuur self `Sync` is omdat die binnegegewens ook `Sync` is, en dit is dus goed om 'n onveranderlike aanwyser na hierdie inhoud uit te leen.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Nie-ingevoerde deel van `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Vernietig die data op hierdie tydstip, alhoewel ons dalk nie die kassetoekenning self kan bevry nie (daar kan nog steeds swak wenke lê).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Laat val die swak ref gesamentlik deur alle sterk verwysings
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Wys `true` as die twee boë op dieselfde toekenning dui (in 'n soortgelyke trant as [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Ken 'n `ArcInner<T>` toe met voldoende ruimte vir 'n moontlik nie-grootte binnewaarde waar die waarde die uitleg bied.
    ///
    /// Die funksie `mem_to_arcinner` word met die datawyser geroep en moet 'n (potensieel vet)-wyser vir die `ArcInner<T>` terugbesorg.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Bereken die uitleg met behulp van die gegewe waarde-uitleg.
        // Voorheen is die uitleg op die uitdrukking `&*(ptr as* const ArcInner<T>)` bereken, maar dit het 'n foutiewe verwysing geskep (sien #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Ken 'n `ArcInner<T>` toe met voldoende ruimte vir 'n moontlik nie-grootte binnewaarde waar die waarde van die uitleg voorsien is, en gee 'n fout terug as die toewysing misluk.
    ///
    ///
    /// Die funksie `mem_to_arcinner` word met die datawyser geroep en moet 'n (potensieel vet)-wyser vir die `ArcInner<T>` terugbesorg.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Bereken die uitleg met behulp van die gegewe waarde-uitleg.
        // Voorheen is die uitleg op die uitdrukking `&*(ptr as* const ArcInner<T>)` bereken, maar dit het 'n foutiewe verwysing geskep (sien #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Initialiseer die ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Ken 'n `ArcInner<T>` toe met voldoende ruimte vir 'n ongroot grootte innerlike waarde.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Ken die `ArcInner<T>` toe met behulp van die gegewe waarde.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopieer waarde as grepe
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Bevry die toekenning sonder om die inhoud daarvan te laat vaar
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Ken 'n `ArcInner<[T]>` toe met die gegewe lengte.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Kopieer elemente van die sny in die nuut toegewysde Arc <\[T\]>
    ///
    /// Onveilig, want die oproeper moet eienaarskap neem of `T: Copy` bind.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Konstrueer 'n `Arc<[T]>` van 'n iterator waarvan bekend is dat dit van 'n sekere grootte is.
    ///
    /// Gedrag is ongedefinieerd as die grootte verkeerd is.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic beskerm terwyl T-elemente gekloon word.
        // In die geval van 'n panic, sal elemente wat in die nuwe ArcInner geskryf is, weggeval word, dan word die geheue vrygestel.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Aanwyser na eerste element
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Alles duidelik.Vergeet die wag sodat dit nie die nuwe ArcInner bevry nie.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Spesialisasie trait gebruik vir `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Maak 'n kloon van die `Arc`-wyser.
    ///
    /// Dit skep 'n ander wyser vir dieselfde toekenning, wat die sterk verwysingstelling verhoog.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Die gebruik van 'n ontspanne ordening is hier in orde, aangesien kennis van die oorspronklike verwysing voorkom dat ander drade die voorwerp verkeerdelik verwyder.
        //
        // Soos in die [Boost documentation][1] uiteengesit, kan die verhoging van die verwysingsteller altyd gedoen word met memory_order_relaxed: Nuwe verwysings na 'n voorwerp kan slegs gevorm word uit 'n bestaande verwysing, en 'n bestaande verwysing van een draad na 'n ander moet oorgedra word, moet al die vereiste sinkronisering bied.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Ons moet egter waak teen massiewe terugbetalings as iemand die Arcs onthou: vergeet.
        // As ons dit nie doen nie, kan die telling oorloop en sal gebruikers dit gratis gebruik.
        // Ons word tot `isize::MAX` versadig met die aanname dat daar nie ~2 miljard drade gelyktydig die referentietelling vermeerder nie.
        //
        // Hierdie branch sal nooit in 'n realistiese program geneem word nie.
        //
        // Ons staak omdat so 'n program ongelooflik ontaard is, en ons gee nie om dit te ondersteun nie.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Maak 'n veranderlike verwysing na die gegewe `Arc`.
    ///
    /// As daar ander `Arc`-of [`Weak`]-aanwysers vir dieselfde toekenning is, sal `make_mut` 'n nuwe toekenning skep en [`clone`][clone] op die innerlike waarde beroep om unieke eienaarskap te verseker.
    /// Dit word ook kloon-aan-skryf genoem.
    ///
    /// Let daarop dat dit verskil van die gedrag van [`Rc::make_mut`] wat alle oorblywende `Weak`-wysers van mekaar losmaak.
    ///
    /// Kyk ook na [`get_mut`][get_mut], wat sal misluk eerder as kloning.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Sal niks kloon nie
    /// let mut other_data = Arc::clone(&data); // Sal nie innerlike data kloon nie
    /// *Arc::make_mut(&mut data) += 1;         // Klone innerlike data
    /// *Arc::make_mut(&mut data) += 1;         // Sal niks kloon nie
    /// *Arc::make_mut(&mut other_data) *= 2;   // Sal niks kloon nie
    ///
    /// // Nou wys `data` en `other_data` op verskillende toekennings.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Let daarop dat ons 'n sterk en 'n swak verwysing het.
        // Die vrylating van ons sterk verwysing sal dus op sigself nie veroorsaak dat die geheue herdeel word nie.
        //
        // Gebruik Aanwin om te verseker dat enige skrywes na `weak` voorkom voordat dit vrygestel word (dws afname) na `strong`.
        // Aangesien ons 'n swak telling het, is daar geen kans dat ArcInner self toegewys kan word nie.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Daar is nog 'n sterk aanwyser, dus moet ons kloon.
            // Ken vooraf geheue toe om die gekloonde waarde direk te kan skryf.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Ontspanne is voldoende in bogenoemde, want dit is fundamenteel 'n optimalisering: ons jaag altyd met swak wenke wat val.
            // Die ergste geval is dat ons uiteindelik 'n nuwe Arc onnodig toegeken het.
            //

            // Ons het die laaste sterk ref verwyder, maar daar is nog swak ref ref.
            // Ons sal die inhoud na 'n nuwe boog skuif en die ander swak verwysings ongeldig maak.
            //

            // Let daarop dat die lees van `weak` nie moontlik is om usize::MAX op te lewer nie (dit wil sê, gesluit), aangesien die swak telling slegs deur 'n draad met 'n sterk verwysing gesluit kan word.
            //
            //

            // Materialiseer ons eie implisiete swak wyser sodat dit die ArcInner kan opruim soos nodig.
            //
            let _weak = Weak { ptr: this.ptr };

            // Kan net die data steel, al wat oorbly is Swak
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Ons was die enigste verwysing van albei soorte;ondersteun die sterk ref-telling.
            //
            this.inner().strong.store(1, Release);
        }

        // Soos met `get_mut()`, is die onveiligheid ok, want ons verwysing was aanvanklik uniek, of het een geword toe ons die inhoud gekloon het.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Wys 'n veranderlike verwysing na die gegewe `Arc` as daar geen ander `Arc`-of [`Weak`]-aanwysers vir dieselfde toekenning is nie.
    ///
    ///
    /// Wys [`None`] anders, want dit is nie veilig om 'n gedeelde waarde te verander nie.
    ///
    /// Kyk ook na [`make_mut`][make_mut], wat die innerlike waarde [`clone`][clone] sal maak as daar ander wysers is.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Hierdie onveiligheid is goed, want ons is gewaarborg dat die wyser wat teruggestuur word, die *enigste* aanwyser is wat ooit na T sal teruggestuur word.
            // Ons verwysingtelling is op hierdie stadium gewaarborg, en ons vereis dat die Arc self `mut` moet wees, daarom gee ons die enigste moontlike verwysing na die innerlike data terug.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Wys 'n veranderlike verwysing na die gegewe `Arc`, sonder enige tjek.
    ///
    /// Kyk ook na [`get_mut`], wat veilig is en toepaslike kontrole doen.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Enige ander `Arc`-of [`Weak`]-aanwysers vir dieselfde toekenning mag nie vir die duur van die terugbetaalde lening verwys word nie.
    ///
    /// Dit is triviaal die geval as daar nie sulke aanwysings bestaan nie, byvoorbeeld onmiddellik na `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Ons is versigtig om *nie*'n verwysing te maak wat die "count"-velde dek nie, aangesien dit alias is met gelyktydige toegang tot die verwysingstellings (bv.
        // deur `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Bepaal of dit die unieke verwysing (insluitend swak verwysings) na die onderliggende data is.
    ///
    ///
    /// Let daarop dat dit nodig is om die swak ref-telling te sluit.
    fn is_unique(&mut self) -> bool {
        // sluit die telling van die swak wyser as dit lyk asof ons die enigste swak wyserhouer is.
        //
        // Die verkrygingsetiket hier verseker dat 'n verhouding voor die tyd plaasvind met enige skryfwerk aan `strong` (in die besonder in `Weak::upgrade`) voordat die `weak`-telling verminder (via `Weak::drop`, wat gebruik maak van vrystelling).
        // As die opgegradeerde swak ref nooit laat vaar is nie, sal die CAS hier misluk, dus ons gee nie om te sinkroniseer nie.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Dit moet 'n `Acquire` wees om te sinkroniseer met die verlaging van die `strong`-teller in `drop`-die enigste toegang wat plaasvind as die verwysing nie behalwe die laaste verwysing word nie.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Die vrystelling skryf hier gesinkroniseer met 'n lees in `downgrade`, wat effektief voorkom dat die lees hiervan van `strong` na die skryf plaasvind.
            //
            //
            self.inner().weak.store(1, Release); // los die slot
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Laat val die `Arc`.
    ///
    /// Dit sal die sterk verwysingstelling verminder.
    /// As die sterk verwysingstelling nul bereik, is die enigste ander verwysings (indien enige) [`Weak`], dus is `drop` die innerlike waarde.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Druk niks nie
    /// drop(foo2);   // Druk "dropped!" af
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Omdat `fetch_sub` al atomies is, hoef ons nie met ander drade te sinkroniseer nie, tensy ons die voorwerp gaan verwyder.
        // Dieselfde logika is van toepassing op die onderstaande `fetch_sub` vir die `weak`-telling.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Hierdie heining is nodig om die herbestelling van die gebruik van die data en die verwydering van die data te voorkom.
        // Omdat dit `Release` gemerk is, word die afname in die verwysingstelling met hierdie `Acquire`-heining gesinkroniseer.
        // Dit beteken dat die gebruik van die data plaasvind voordat die verwysingstelling verminder word, wat voor hierdie heining plaasvind, wat gebeur voordat die data verwyder word.
        //
        // Soos in die [Boost documentation][1] verduidelik,
        //
        // > Dit is belangrik om alle moontlike toegang tot die voorwerp in een af te dwing
        // > draad (deur 'n bestaande verwysing) om *te gebeur voordat* verwyder word
        // > die voorwerp in 'n ander draad.Dit word bereik deur 'n "release"
        // > bewerking nadat 'n verwysing neergesit is (enige toegang tot die voorwerp
        // > deur hierdie verwysing moet dit natuurlik voorheen gebeur het), en 'n
        // > "acquire" bewerking voordat die voorwerp uitgevee word.
        //
        // In die besonder, hoewel die inhoud van 'n boog gewoonlik onveranderlik is, is dit moontlik om binne-in iets soos 'n Mutex te skryf<T>.
        // Aangesien 'n Mutex nie verkry word wanneer dit verwyder word nie, kan ons nie op die sinchronisasie-logika daarvan vertrou om skrywe in draad A sigbaar te maak vir 'n vernietiger wat in draad B loop nie.
        //
        //
        // Let ook daarop dat die Acquire-heining hier waarskynlik met 'n las kan vervang word, wat die prestasie in hoogs aangewese situasies kan verbeter.Sien [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Probeer om die `Arc<dyn Any + Send + Sync>` tot 'n konkrete tipe te laat val.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Konstrueer 'n nuwe `Weak<T>`, sonder om geheue toe te ken.
    /// Om [`upgrade`] op die retourwaarde te noem, gee altyd [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Helper-tipe om toegang te verkry tot die verwysingstellings sonder om enige bewerings oor die dataveld te maak.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Wys 'n rou wyser na die voorwerp `T` waarop hierdie `Weak<T>` wys.
    ///
    /// Die aanwyser is slegs geldig as daar sterk verwysings is.
    /// Die aanwyser kan anders hang, hang nie of selfs [`null`] nie.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Albei wys op dieselfde voorwerp
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Die sterk hier hou dit lewendig, sodat ons steeds toegang tot die voorwerp kan kry.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Maar nie meer nie.
    /// // Ons kan weak.as_ptr() doen, maar toegang tot die wyser kan lei tot ongedefinieerde gedrag.
    /// // assert_eq! ("hallo", onveilig {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // As die wyser hang, stuur ons die sentinel direk terug.
            // Dit kan nie 'n geldige loonadres wees nie, aangesien die loonvrag minstens so gelyk is aan ArcInner (usize).
            ptr as *const T
        } else {
            // VEILIGHEID: as is_dangling vals is, dan kan die wyser herverwysbaar wees.
            // Die loonvrag kan op hierdie stadium laat val word, en ons moet die herkoms behou, dus gebruik rou wysermanipulasie.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Verbruik die `Weak<T>` en verander dit in 'n rou aanwyser.
    ///
    /// Dit omskep die swak aanwyser in 'n rou aanwyser, terwyl u steeds die eienaarskap van een swak verwysing behou (die swak telling word nie deur hierdie bewerking verander nie).
    /// Dit kan weer in die `Weak<T>` met [`from_raw`] verander word.
    ///
    /// Dieselfde beperkings vir toegang tot die teiken van die wyser geld as met [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Skakel 'n rou wyser wat voorheen deur [`into_raw`] geskep is, terug in `Weak<T>`.
    ///
    /// Dit kan gebruik word om veilig 'n sterk verwysing te kry (deur later [`upgrade`] te skakel) of om die swak telling te herplaas deur die `Weak<T>` te laat val.
    ///
    /// Dit neem eienaarskap van een swak verwysing (met die uitsondering van aanwysings wat deur [`new`] geskep is, aangesien dit niks besit nie; die metode werk nog steeds daarop).
    ///
    /// # Safety
    ///
    /// Die wyser moet van die [`into_raw`] afkomstig wees en moet steeds die potensiële swak verwysing besit.
    ///
    /// Dit is toegelaat dat die sterk telling 0 is wanneer u dit noem.
    /// Dit neem nietemin eienaarskap van een swak verwysing wat tans as 'n rou aanwyser voorgestel word (die swak telling word nie deur hierdie bewerking aangepas nie) en daarom moet dit gekoppel word aan 'n vorige oproep na [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Verminder die laaste swak telling.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Sien Weak::as_ptr vir konteks oor hoe die invoerwyser afgelei word.

        let ptr = if is_dangling(ptr as *mut T) {
            // Dit is 'n hangende swak.
            ptr as *mut ArcInner<T>
        } else {
            // Anders word ons gewaarborg dat die aanwyser afkomstig is van 'n nie-hangende Swak.
            // VEILIGHEID: data_offset is veilig om te bel, aangesien ptr verwys na 'n regte (potensieel laat val) T.
            let offset = unsafe { data_offset(ptr) };
            // Dus keer ons die verrekening om die hele RcBox te kry.
            // VEILIGHEID: die aanwyser het sy oorsprong in 'n swak punt, dus hierdie verrekening is veilig.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // VEILIGHEID: ons het nou die oorspronklike Swak wyser herwin, sodat ons die Swak kan skep.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Pogings om die `Weak`-wyser na 'n [`Arc`] op te gradeer, laat val van die innerlike waarde as dit suksesvol is.
    ///
    ///
    /// Wys [`None`] as die innerlike waarde intussen gedaal het.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Vernietig alle sterk wenke.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Ons gebruik 'n CAS-lus om die sterk telling te verhoog in plaas van 'n fetch_add, aangesien hierdie funksie nooit die verwysingstelling van nul tot een moet neem nie.
        //
        //
        let inner = self.inner()?;

        // Ontspanne lading omdat enige skryf van 0 wat ons kan waarneem, die veld in 'n permanente toestand laat (dus is 'n "stale"-lees van 0 goed), en enige ander waarde word bevestig deur die CAS hieronder.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Kyk na opmerkings in `Arc::clone` waarom ons dit doen (vir `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Ontspan is goed vir die mislukking, want ons het geen verwagtinge oor die nuwe staat nie.
            // Verkryging is nodig vir die suksesgeval om met `Arc::new_cyclic` te sinkroniseer, wanneer die innerlike waarde geïnisialiseer kan word nadat `Weak`-verwysings reeds geskep is.
            // In daardie geval verwag ons om die volledig geïnitialiseerde waarde in ag te neem.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // nul hierbo nagegaan
                Err(old) => n = old,
            }
        }
    }

    /// Kry die aantal sterk (`Arc`)-aanwysers wat op hierdie toekenning dui.
    ///
    /// As `self` met [`Weak::new`] geskep is, sal dit 0 lewer.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Kry 'n benadering van die aantal `Weak`-aanwysers wat op hierdie toekenning dui.
    ///
    /// As `self` met [`Weak::new`] geskep is, of as daar geen oorblywende sterk wysers is nie, sal dit 0 lewer.
    ///
    /// # Accuracy
    ///
    /// As gevolg van implementeringsbesonderhede, kan die teruggestuurde waarde met 1 in beide rigtings afgeskakel word as ander drade enige 'Boë' of 'Swak' manipuleer wat op dieselfde toewysing dui.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Aangesien ons opgemerk het dat daar ten minste een sterk aanwyser was nadat ons die swak telling gelees het, weet ons dat die implisiete swak verwysing (teenwoordig wanneer daar sterk verwysings is) nog steeds bestaan toe ons die swak telling waargeneem het, en daarom veilig kan aftrek.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Wys `None` as die wyser hang en daar geen `ArcInner` toegeken is nie (dws wanneer hierdie `Weak` deur `Weak::new` geskep is).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Ons is versigtig om *nie*'n verwysing te maak wat die "data"-veld dek nie, aangesien die veld gelyktydig gemuteer kan word (as die laaste `Arc` byvoorbeeld laat val word, sal die dataveld op sy plek val).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Wys `true` as die twee 'Swak'e op dieselfde toewysing dui (soortgelyk aan [`ptr::eq`]), of as albei nie op enige toewysing dui nie (omdat dit met `Weak::new()`) geskep is.
    ///
    ///
    /// # Notes
    ///
    /// Aangesien hierdie wenke vergelyk word, beteken dit dat `Weak::new()` mekaar sal ewenaar, alhoewel dit nie op enige toekenning dui nie.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Vergelyk `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Maak 'n kloon van die `Weak`-wyser wat op dieselfde toewysing dui.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Kyk na opmerkings in Arc::clone() waarom dit ontspanne is.
        // Dit kan 'n fetch_add gebruik (om die slot te ignoreer) omdat die swak telling slegs gesluit is waar *geen ander* swak wenke bestaan nie.
        //
        // (Ons kan dus in hierdie geval nie hierdie kode gebruik nie).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Kyk na opmerkings in Arc::clone() waarom ons dit doen (vir mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Konstrueer 'n nuwe `Weak<T>`, sonder om geheue toe te ken.
    /// Om [`upgrade`] op die retourwaarde te noem, gee altyd [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Laat val die `Weak`-wyser.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Druk niks nie
    /// drop(foo);        // Druk "dropped!" af
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // As ons agterkom dat ons die laaste swak aanwyser was, is dit tyd om die data heeltemal te herplaas.Kyk na die bespreking in Arc::drop() oor die geheuebestellings
        //
        // Dit is nie nodig om hier na die vergrendelde toestand te kyk nie, want die swak telling kan slegs geblokkeer word as daar presies een swak ref was, wat beteken dat die val eers later op die oorblywende swak ref sou kon loop, wat eers kan gebeur nadat die slot vrygestel is.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Ons doen hierdie spesialisasie hier, en nie as 'n meer algemene optimalisering op `&T` nie, omdat dit andersins 'n koste sal toevoeg aan alle gelykheidskontroles op refs.
/// Ons neem aan dat 'Boë' gebruik word om groot waardes op te slaan, wat stadig gekloon word, maar ook swaar om na te gaan of dit gelyk is, wat die koste makliker laat betaal.
///
/// Dit is ook meer geneig om twee `Arc`-klone te hê, wat op dieselfde waarde dui, as twee '&T'e.
///
/// Ons kan dit net doen as `T: Eq` as `PartialEq` doelbewus irrefleksief is.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Gelykheid vir twee `Arc`s.
    ///
    /// Twee `Boë` is gelyk as hul innerlike waardes gelyk is, selfs al word dit in verskillende toekennings gestoor.
    ///
    /// As `T` ook `Eq` implementeer (wat refleksiwiteit van gelykheid impliseer), is twee `Boë` wat op dieselfde toewysing dui altyd gelyk.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Ongelykheid vir twee `Arc`s.
    ///
    /// Twee boë is nie gelyk as hul innerlike waardes nie gelyk is nie.
    ///
    /// As `T` ook `Eq` implementeer (wat die refleksiwiteit van gelykheid impliseer), is twee Arc's wat op dieselfde waarde dui nooit ongelyk nie.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Gedeeltelike vergelyking vir twee `Arc`s.
    ///
    /// Die twee word vergelyk deur `partial_cmp()` op hul innerlike waardes te noem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Minder as vergelyking vir twee `Arc`s.
    ///
    /// Die twee word vergelyk deur `<` op hul innerlike waardes te noem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'Minder as of gelyk aan' vergelyking vir twee 'Boë'.
    ///
    /// Die twee word vergelyk deur `<=` op hul innerlike waardes te noem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Groter vergelyking vir twee `Arc`s.
    ///
    /// Die twee word vergelyk deur `>` op hul innerlike waardes te noem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'Groter as of gelyk aan' vergelyking vir twee 'Boë'.
    ///
    /// Die twee word vergelyk deur `>=` op hul innerlike waardes te noem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Vergelyking vir twee `Arc`s.
    ///
    /// Die twee word vergelyk deur `cmp()` op hul innerlike waardes te noem.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Skep 'n nuwe `Arc<T>` met die `Default`-waarde vir `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Ken 'n sny met verwysings toe en vul dit deur 'v'-items te kloon.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Ken 'n `str` met verwysing toe en kopieer `v` daarin.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Ken 'n `str` met verwysing toe en kopieer `v` daarin.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Skuif 'n voorwerp in 'n boks na 'n nuwe toekenning wat deur verwysings getel word.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Ken 'n sny met verwysing toe en skuif 'v'-items daarin.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Laat die Vec sy geheue vry, maar nie die inhoud daarvan vernietig nie
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Neem elke element in die `Iterator` en versamel dit in 'n `Arc<[T]>`.
    ///
    /// # Prestasie-eienskappe
    ///
    /// ## Die algemene saak
    ///
    /// In die algemeen word versameling in `Arc<[T]>` gedoen deur eers in 'n `Vec<T>` te versamel.Dit wil sê wanneer u die volgende skryf:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// dit tree op asof ons geskryf het:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Die eerste stel toekennings vind hier plaas.
    ///     .into(); // Hier vind 'n tweede toekenning vir `Arc<[T]>` plaas.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Dit sal soveel keer toewys as wat nodig is vir die konstruksie van die `Vec<T>`, en dan sal dit een keer toewys vir die omskakeling van die `Vec<T>` in die `Arc<[T]>`.
    ///
    ///
    /// ## Iterators van bekende lengte
    ///
    /// Wanneer u `Iterator` `TrustedLen` implementeer en van 'n presiese grootte is, sal 'n enkele toekenning vir die `Arc<[T]>` gemaak word.Byvoorbeeld:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Hier vind net 'n enkele toekenning plaas.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Spesialisasie trait word gebruik om `Arc<[T]>` in te samel.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Dit is die geval vir 'n `TrustedLen`-iterator.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // VEILIGHEID: Ons moet toesien dat die iterator 'n presiese lengte het en ons het.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Daal terug na normale implementering.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Kry die verrekening binne 'n `ArcInner` vir die loonvrag agter 'n aanwyser.
///
/// # Safety
///
/// Die aanwyser moet wys op (en geldige metadata hê) vir 'n voorheen geldige instansie van T, maar die T mag toegelaat word om te val.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Rig die ongepaste waarde aan die einde van die ArcInner.
    // Omdat RcBox repr(C) is, sal dit altyd die laaste veld in die geheue wees.
    // VEILIGHEID: aangesien snitte, trait-voorwerpe, die enigste ongrootte soorte moontlik is,
    // en eksterne tipes, is die invoerveiligheidsvereiste tans voldoende om aan die vereistes van align_of_val_raw te voldoen;dit is 'n implementeringsdetail van die taal waarop nie buite std staatgemaak kan word nie.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}