#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Die inhoud van die nuwe geheue word nie geïnisialiseer nie.
    Uninitialized,
    /// Die nuwe geheue sal gewaarborg word.
    Zeroed,
}

/// 'N Hulpprogramma vir die ergonomiese toewysing, herallokering en herlokalisering van 'n buffer geheue op die hoop, sonder om bekommerd te wees oor al die betrokke hoeksake.
///
/// Hierdie tipe is uitstekend om u eie datastrukture soos Vec en VecDeque te bou.
/// In die besonder:
///
/// * Produseer `Unique::dangling()` op soorte nulgrootte.
/// * Produseer `Unique::dangling()` vir nullengtetoekennings.
/// * Vermy die vrystelling van `Unique::dangling()`.
/// * Vang alle oorstromings in kapasiteitsberekeninge (bevorder dit tot "capacity overflow" panics).
/// * Beskerm teen 32-bis stelsels wat meer as isize::MAX bytes toeken.
/// * Waak daarteen om jou lengte te oorstroom.
/// * Bel `handle_alloc_error` vir feilbare toekennings.
/// * Bevat 'n `ptr::Unique` en gee sodoende die gebruiker alle voordele daaraan verbonde.
/// * Gebruik die oorskot wat van die toewyser teruggestuur word om die grootste beskikbare kapasiteit te gebruik.
///
/// Hierdie tipe inspekteer in elk geval nie die geheue wat dit bestuur nie.As dit neergesit word, sal dit *die geheue* bevry, maar dit *nie* probeer om die inhoud daarvan te laat val nie.
/// Dit is aan die gebruiker van `RawVec` om die werklike dinge *gestoor* in 'n `RawVec` te hanteer.
///
/// Let daarop dat die oormaat van nul-grootte soorte altyd oneindig is, dus `capacity()` gee altyd `usize::MAX` terug.
/// Dit beteken dat u versigtig moet wees wanneer u hierdie tipe met 'n `Box<[T]>` afrond, omdat `capacity()` nie die lengte sal lewer nie.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Dit bestaan omdat `#[unstable]` `const fn`s nie aan `min_const_fn` hoef te voldoen nie en daarom kan hulle ook nie in`min_const_fn`s genoem word nie.
    ///
    /// As u `RawVec<T>::new` of afhanklikes verander, moet u daarop let dat u niks bekendstel wat `min_const_fn` werklik oortree nie.
    ///
    /// NOTE: Ons kan hierdie hack vermy en die ooreenstemming met 'n `#[rustc_force_min_const_fn]`-eienskap nagaan, wat ooreenstemming met `min_const_fn` vereis, maar dit nie noodwendig toelaat dat dit in `stable(...) const fn`/gebruikerskode genoem word nie, wat `foo` nie moontlik maak as `#[rustc_const_unstable(feature = "foo", issue = "01234")]` teenwoordig is nie.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Skep die grootste moontlike `RawVec` (op die stelselhoop) sonder om dit toe te ken.
    /// As `T` 'n positiewe grootte het, is dit 'n `RawVec` met 'n kapasiteit `0`.
    /// As `T` nulgrootte is, maak dit 'n `RawVec` met kapasiteit `usize::MAX`.
    /// Nuttig vir die implementering van vertraagde toekenning.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Skep 'n `RawVec` (op die stelselhoop) met presies die kapasiteits-en belyningsvereistes vir 'n `[T; capacity]`.
    /// Dit is gelykstaande aan die oproep van `RawVec::new` wanneer `capacity` `0` is of `T` nulgrootte is.
    /// Let daarop dat as `T` nulgrootte is, dit beteken dat u *nie*'n `RawVec` met die aangevraagde kapasiteit sal kry nie.
    ///
    /// # Panics
    ///
    /// Panics as die gevraagde kapasiteit `isize::MAX` bytes oorskry.
    ///
    /// # Aborts
    ///
    /// Aborteer op OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Soos `with_capacity`, maar waarborg dat die buffer nul is.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Herstel 'n `RawVec` vanaf 'n wyser en kapasiteit.
    ///
    /// # Safety
    ///
    /// Die `ptr` moet toegeken word (op die stelselhoop) en met die gegewe `capacity`.
    /// Die `capacity` mag nie `isize::MAX` oorskry vir groot tipes nie.(slegs 'n probleem op 32-bis-stelsels).
    /// ZST vektore kan 'n kapasiteit hê tot `usize::MAX`.
    /// As die `ptr` en `capacity` van 'n `RawVec` afkomstig is, is dit gewaarborg.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Tiny Vecs is stom.Slaan oor na:
    // - 8 as die elementgrootte 1 is, omdat enige hopetoekennings waarskynlik 'n versoek van minder as 8 bytes tot minstens 8 bytes sal afrond.
    //
    // - 4 as elemente matig groot is (<=1 KiB).
    // - 1 andersins, om te vermy om te veel ruimte vir baie kort Vecs te vermors.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Soos `new`, maar geparametreer oor die keuse van toewyser vir die teruggestuurde `RawVec`.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` beteken "unallocated".nulgrootte tipes word geïgnoreer.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Soos `with_capacity`, maar geparametreer oor die keuse van toewyser vir die teruggestuurde `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Soos `with_capacity_zeroed`, maar geparametreer oor die keuse van toewyser vir die teruggestuurde `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Skakel 'n `Box<[T]>` om in 'n `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Skakel die hele buffer om in `Box<[MaybeUninit<T>]>` met die gespesifiseerde `len`.
    ///
    /// Let daarop dat die `cap`-veranderinge wat uitgevoer is, korrek sal herstel.(Sien die beskrywing van die tipe vir besonderhede.)
    ///
    /// # Safety
    ///
    /// * `len` moet groter as of gelyk wees aan die kapasiteit wat die laaste keer aangevra is, en
    /// * `len` moet kleiner as of gelyk wees aan `self.capacity()`.
    ///
    /// Let daarop dat die aangevraagde kapasiteit en `self.capacity()` kan verskil, aangesien 'n toewyser 'n groter geheue-blok kan opstel en teruggee as wat gevra is.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Saniteit gaan die helfte van die veiligheidsvereiste na (ons kan nie die ander helfte nagaan nie).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Ons vermy `unwrap_or_else` hier omdat dit die hoeveelheid gegenereerde LLVM IR opblaas.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Herstel 'n `RawVec` vanaf 'n aanwyser, kapasiteit en toewyser.
    ///
    /// # Safety
    ///
    /// Die `ptr` moet toegeken word (via die gegewe toewyser `alloc`) en met die gegewe `capacity`.
    /// Die `capacity` mag nie `isize::MAX` oorskry vir groot tipes nie.
    /// (slegs 'n probleem op 32-bis-stelsels).
    /// ZST vektore kan 'n kapasiteit hê tot `usize::MAX`.
    /// As die `ptr` en `capacity` afkomstig is van 'n `RawVec` wat via `alloc` gemaak is, is dit gewaarborg.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Kry 'n rou aanwyser na die begin van die toekenning.
    /// Let daarop dat dit `Unique::dangling()` is as `capacity == 0` of `T` nulgrootte is.
    /// In eersgenoemde geval moet u versigtig wees.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Kry die kapasiteit van die toekenning.
    ///
    /// Dit sal altyd `usize::MAX` wees as `T` nulgrootte is.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Wys 'n gedeelde verwysing na die toewyser wat hierdie `RawVec` steun.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Ons het 'n toegewysde hoeveelheid geheue, sodat ons looptydkontroles kan omseil om ons huidige uitleg te kry.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Verseker dat die buffer ten minste genoeg spasie bevat om `len + additional`-elemente te bevat.
    /// As dit nog nie genoeg kapasiteit het nie, sal u genoeg ruimte plus gemaklike slap ruimte toewys om geamortiseerde *O*(1) gedrag te kry.
    ///
    /// Beperk hierdie gedrag as dit onnodig tot panic sou lei.
    ///
    /// As `len` `self.capacity()` oorskry, kan dit daartoe lei dat die gewenste ruimte nie werklik toegeken word nie.
    /// Dit is nie regtig onveilig nie, maar die onveilige kode * wat u skryf wat afhanklik is van die gedrag van hierdie funksie, kan breek.
    ///
    /// Dit is ideaal vir die implementering van 'n bulk-push-operasie soos `extend`.
    ///
    /// # Panics
    ///
    /// Panics as die nuwe kapasiteit `isize::MAX` bytes oorskry.
    ///
    /// # Aborts
    ///
    /// Aborteer op OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // reserwe sou geaborteer of paniekerig geraak het as die len `isize::MAX` oorskry het, so dit is veilig om nou ongemerk te word.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Dieselfde as `reserve`, maar keer terug na foute in plaas van om paniekerig te raak of te aborteer.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Verseker dat die buffer ten minste genoeg spasie bevat om `len + additional`-elemente te bevat.
    /// As dit nog nie gebeur nie, sal die minimum moontlike hoeveelheid geheue wat nodig is, weer toegedeel word.
    /// Oor die algemeen is dit presies die hoeveelheid geheue wat nodig is, maar in beginsel staan die toewyser vry om meer terug te gee as wat ons gevra het.
    ///
    ///
    /// As `len` `self.capacity()` oorskry, kan dit daartoe lei dat die gewenste ruimte nie werklik toegeken word nie.
    /// Dit is nie regtig onveilig nie, maar die onveilige kode * wat u skryf wat afhanklik is van die gedrag van hierdie funksie, kan breek.
    ///
    /// # Panics
    ///
    /// Panics as die nuwe kapasiteit `isize::MAX` bytes oorskry.
    ///
    /// # Aborts
    ///
    /// Aborteer op OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Dieselfde as `reserve_exact`, maar keer terug na foute in plaas van om paniekerig te raak of te aborteer.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Verklein die toekenning tot die gespesifiseerde bedrag.
    /// As die gegewe bedrag 0 is, word die deallocaties heeltemal gehanteer.
    ///
    /// # Panics
    ///
    /// Panics as die gegewe bedrag *groter* is as die huidige kapasiteit.
    ///
    /// # Aborts
    ///
    /// Aborteer op OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Wys terug as die buffer moet groei om aan die benodigde ekstra kapasiteit te voldoen.
    /// Word hoofsaaklik gebruik om inlywingsreserwe-oproepe moontlik te maak sonder om `grow` in te voer.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Hierdie metode word gewoonlik baie keer geïnstalleer.Ons wil dus hê dat dit so klein as moontlik moet wees om die samestellingstye te verbeter.
    // Maar ons wil ook hê dat soveel as moontlik van die inhoud staties berekenbaar is om die gegenereerde kode vinniger te laat werk.
    // Daarom word hierdie metode noukeurig geskryf sodat al die kode wat van `T` afhang, daarin is, terwyl soveel as moontlik van die kode wat nie van `T` afhang nie, funksies bevat wat nie meer as `T` is nie.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Dit word verseker deur die roepingskontekste.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Aangesien ons 'n kapasiteit van `usize::MAX` oplewer as `elem_size` is
            // 0, om hierheen te kom, beteken noodwendig dat die `RawVec` oorvol is.
            return Err(CapacityOverflow);
        }

        // Helaas kan ons niks aan hierdie tjeks doen nie.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Dit waarborg eksponensiële groei.
        // Die verdubbeling kan nie oorloop nie, want `cap <= isize::MAX` en die tipe `cap` is `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` is nie-generies meer as `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Die beperkinge op hierdie metode is baie dieselfde as die op `grow_amortized`, maar hierdie metode word gewoonlik minder gereeld geïnstalleer sodat dit minder krities is.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Aangesien ons 'n kapasiteit van `usize::MAX` teruggee as die tipe grootte is
            // 0, om hierheen te kom, beteken noodwendig dat die `RawVec` oorvol is.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` is nie-generies meer as `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Hierdie funksie is buite `RawVec` om kompileringstye te verminder.Sien die kommentaar hierbo `RawVec::grow_amortized` vir besonderhede.
// (Die `A`-parameter is nie beduidend nie, omdat die aantal verskillende `A`-tipes in die praktyk baie kleiner is as die aantal `T`-tipes.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Kyk hier na die fout om die grootte van `RawVec::grow_*` te verminder.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Die toewyser kontroleer of die belyning gelyk is
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Maak die geheue van die `RawVec` * vry sonder om die inhoud daarvan te probeer laat val.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Sentrale funksie vir die hantering van reserwefoute.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Ons moet die volgende waarborg:
// * Ons ken nooit `> isize::MAX`-byte-grootte voorwerpe toe nie.
// * Ons loop nie oor `usize::MAX` nie en ken eintlik te min toe.
//
// Op 64-bit hoef ons net na oorloop te kyk, want dit sal beslis misluk om `> isize::MAX`-bytes toe te ken.
// Op 32-bit en 16-bit moet ons 'n ekstra beskerming hiervoor byvoeg as ons op 'n platform hardloop wat al 4 GB in die gebruikersruimte kan gebruik, byvoorbeeld PAE of x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Een sentrale funksie wat verantwoordelik is vir die oorsig van kapasiteit.
// Dit sal verseker dat die kodegenerering wat verband hou met hierdie panics minimaal is, aangesien daar net een plek is wat panics in plaas van 'n klomp dwarsdeur die module.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}