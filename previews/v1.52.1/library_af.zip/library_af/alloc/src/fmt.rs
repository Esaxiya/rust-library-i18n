//! Hulpprogramme vir die opmaak en druk van 'String'.
//!
//! Hierdie module bevat die runtime-ondersteuning vir die [`format!`]-sintaksisuitbreiding.
//! Hierdie makro word in die samesteller geïmplementeer om oproepe na hierdie module uit te stuur om argumente tydens looptyd in snare te formateer.
//!
//! # Usage
//!
//! Die [`format!`]-makro is bedoel om bekend te wees met diegene wat van C se `printf`/`fprintf`-funksies of Python se `str.format`-funksie kom.
//!
//! Enkele voorbeelde van die [`format!`]-uitbreiding is:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" met voorste nulle
//! ```
//!
//! Hieruit kan u sien dat die eerste argument 'n formaatreeks is.Dit word deur die samesteller vereis dat dit letterlik letterlik moet wees;dit kan nie 'n veranderlike wees wat deurgegee word nie (om geldigheidskontrole uit te voer).
//! Die samesteller sal dan die formaatreeks ontleed en bepaal of die lys met argumente wat verskaf word, geskik is om na hierdie formaatreeks oor te dra.
//!
//! Gebruik die [`to_string`]-metode om 'n enkele waarde in 'n string om te skakel.Dit sal die [`Display`]-opmaak trait gebruik.
//!
//! ## Posisionele parameters
//!
//! Elke formateringsargument mag bepaal watter waarde-argument dit verwys, en as dit veronderstel word "the next argument" te wees.
//! Die formaatreeks `{} {} {}` het byvoorbeeld drie parameters, en hulle sal in dieselfde volgorde geformateer word as wat hulle gegee word.
//! Die formaatreeks `{2} {1} {0}` sou egter argumente in omgekeerde volgorde formateer.
//!
//! Dinge kan 'n bietjie lastig raak as u die twee soorte posisioneringsspesifieke met mekaar meng.Die "next argument"-spesifikasie kan beskou word as 'n herhaling van die argument.
//! Elke keer as 'n "next argument"-spesifikasie gesien word, vorder die iterator.Dit lei tot gedrag soos hierdie:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Die interne iterator oor die argument is nog nie gevorder toe die eerste `{}` gesien is nie, en dit druk dus die eerste argument af.Nadat die iterator die tweede `{}` bereik het, het hy na die tweede argument gevorder.
//! In wese beïnvloed parameters wat hul argument eksplisiet benoem nie parameters wat nie 'n argument benoem in terme van posisiespesifiseerders nie.
//!
//! 'N Formaatreeks is nodig om al sy argumente te gebruik, anders is dit 'n kompileringstydfout.U kan dieselfde argument meer as een keer in die formaatreeks verwys.
//!
//! ## Benoemde parameters
//!
//! Rust self het nie 'n Python-ekwivalent van genoemde parameters vir 'n funksie nie, maar die [`format!`]-makro is 'n sintaksuitbreiding wat dit moontlik maak om benoemde parameters te benut.
//! Benoemde parameters word aan die einde van die argumentlys gelys en het die sintaksis:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Die volgende [`format!`]-uitdrukkings gebruik byvoorbeeld almal die benoemde argument:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Dit is nie geldig om posisionele parameters (dié sonder name) na argumente met name te plaas nie.Soos met posisionele parameters, is dit nie geldig om genoemde parameters te verskaf wat nie deur die formaatreeks gebruik word nie.
//!
//! # Formatering van parameters
//!
//! Elke argument wat geformateer word, kan getransformeer word deur 'n aantal opmaakparameters (wat ooreenstem met `format_spec` in [the syntax](#syntax)). Hierdie parameters beïnvloed die stringvoorstelling van wat geformateer word.
//!
//! ## Width
//!
//! ```
//! // Al hierdie druk "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Dit is 'n parameter vir die "minimum width" wat die formaat moet gebruik.
//! As die waarde van die waarde nie soveel karakters invul nie, sal die vulling wat deur fill/alignment gespesifiseer word, gebruik word om die vereiste spasie op te neem (sien hieronder).
//!
//! Die waarde vir die breedte kan ook as 'n [`usize`] in die lys van parameters verskaf word deur 'n postfix `$` by te voeg, wat aandui dat die tweede argument 'n [`usize`] is wat die breedte spesifiseer.
//!
//! As u na 'n argument met die dollar-sintaksis verwys, raak dit nie die "next argument"-toonbank nie, daarom is dit gewoonlik 'n goeie idee om na argumente per posisie te verwys of die benoemde argumente te gebruik.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Die opsionele vulkarakter en-belyning word normaalweg saam met die [`width`](#width)-parameter verskaf.Dit moet voor `width`, direk na die `:`, gedefinieer word.
//! Dit dui aan dat as die waarde wat geformateer word kleiner is as `width`, ekstra karakters daaromheen gedruk sal word.
//! Vul is beskikbaar in die volgende variante vir verskillende belynings:
//!
//! * `[fill]<` - die argument is linksbelyn in `width`-kolomme
//! * `[fill]^` - die argument is in die middel van die `width`-kolomme
//! * `[fill]>` - die argument is regsbelyn in `width`-kolomme
//!
//! Die standaard [fill/alignment](#fillalignment) vir nie-numeries is 'n spasie en linksbelyn.Die standaard vir numeriese formateerders is ook 'n spasie-karakter, maar met regsbelyning.
//! As die `0`-vlag (sien hieronder) vir numeriek gespesifiseer word, is die implisiete vulkarakter `0`.
//!
//! Let daarop dat belyning nie deur sommige soorte geïmplementeer kan word nie.In die besonder word dit gewoonlik nie vir die `Debug` trait geïmplementeer nie.
//! 'N Goeie manier om te verseker dat opvulling toegepas word, is om u invoer te formateer en dan die resulterende string te plak om u uitset te verkry:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Hallo Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Dit is alles vlae wat die gedrag van die formater verander.
//!
//! * `+` - Dit is bedoel vir numeriese tipes en dui aan dat die teken altyd gedruk moet word.Positiewe tekens word nooit standaard gedruk nie, en die negatiewe teken word standaard slegs vir die `Signed` trait gedruk.
//! Hierdie vlag dui aan dat die regte teken (`+` of `-`) altyd gedruk moet word.
//! * `-` - Tans nie gebruik nie
//! * `#` - Hierdie vlag dui aan dat die "alternate"-vorm gebruik moet word.Die alternatiewe vorms is:
//!     * `#?` - druk die [`Debug`]-opmaak mooi uit
//!     * `#x` - gaan die argument met 'n `0x` vooraf
//!     * `#X` - gaan die argument met 'n `0x` vooraf
//!     * `#b` - gaan die argument met 'n `0b` vooraf
//!     * `#o` - gaan die argument met 'n `0o` vooraf
//! * `0` - Dit word gebruik om vir heelgetalformate aan te dui dat die opvulling na `width` met 'n `0`-karakter gedoen moet word, sowel as tekenbewus moet wees.
//! 'N Formaat soos `{:08}` sou `00000001` vir die heelgetal `1` lewer, terwyl dieselfde formaat `-0000001` vir die heelgetal `-1` sou oplewer.
//! Let daarop dat die negatiewe weergawe een minder as die positiewe weergawe het.
//!         Let op dat opvullings-nulle altyd agter die teken (indien enige) en voor die syfers geplaas word.Wanneer dit saam met die `#`-vlag gebruik word, geld 'n soortgelyke reël: opvullings-nulle word agter die voorvoegsel ingevoeg, maar voor die syfers.
//!         Die voorvoegsel is by die totale breedte ingesluit.
//!
//! ## Precision
//!
//! Vir nie-numeriese tipes kan dit as 'n "maximum width" beskou word.
//! As die resulterende string langer is as hierdie breedte, word dit afgekap tot soveel karakters en word die afgeknotte waarde met die regte `fill`, `alignment` en `width` uitgestraal as die parameters gestel word.
//!
//! Vir integrale tipes word dit geïgnoreer.
//!
//! Vir soorte drywende punte dui dit aan hoeveel syfers na die desimale punt gedruk moet word.
//!
//! Daar is drie moontlike maniere om die gewenste `precision` te spesifiseer:
//!
//! 1. 'N Heelgetal `.N`:
//!
//!    die heelgetal `N` self is die presisie.
//!
//! 2. 'N Heelgetal of naam gevolg deur dollarteken `.N$`:
//!
//!    gebruik formaat *argument*`N` (wat 'n `usize` moet wees) as die presisie.
//!
//! 3. 'N Sterretjie `.*`:
//!
//!    `.*` beteken dat hierdie `{...}` geassosieer word met *twee* formaat insette eerder as een: die eerste invoer het die `usize` presisie, en die tweede hou die waarde om af te druk.
//!    Let op: in hierdie geval, as 'n mens die formaatstring `{<arg>:<spec>.*}` gebruik, dan verwys die `<arg>`-gedeelte na die* waarde * om af te druk, en die `precision` moet in die invoer voor `<arg>` verskyn.
//!
//! Die volgende oproepe druk byvoorbeeld almal dieselfde ding `Hello x is 0.01000`:
//!
//! ```
//! // Hallo {arg 0 ("x")} is {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Hallo {arg 1 ("x")} is {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Hallo {arg 0 ("x")} is {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Hallo {next arg ("x")} is {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Hallo {next arg ("x")} is {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Hallo {next arg ("x")} is {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Terwyl dit:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! druk drie aansienlik verskillende dinge uit:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! In sommige programmeertale hang die gedrag van snaaropmaakfunksies af van die plaaslike instelling van die bedryfstelsel.
//! Die formaatfunksies wat deur die standaardbiblioteek van Rust aangebied word, het geen lokaalkonsep nie en lewer dieselfde resultate op alle stelsels ongeag die konfigurasie van die gebruiker.
//!
//! Die volgende kode sal byvoorbeeld altyd `1.5` afdruk, selfs al gebruik die stelsel 'n ander desimale skeiding as 'n punt.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Die letterlike karakters `{` en `}` kan in 'n tou opgeneem word deur dieselfde karakter vooraf te gee.Die `{`-karakter word byvoorbeeld ontsnap met `{{` en die `}`-karakter is ontsnap met `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Om op te som, hier kan u die volledige grammatika van formaat snare vind.
//! Die sintaksis vir die gebruikte opmaaktaal is afkomstig van ander tale, dus dit moet nie te vreemd wees nie.Argumente word geformateer met Python-sintaksis, wat beteken dat argumente omring word deur `{}` in plaas van die C-agtige `%`.
//! Die werklike grammatika vir die opbou van sintaksis is:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! In die grammatika hierbo mag `text` geen `'{'`-of `'}'`-karakters bevat nie.
//!
//! # Formatering van traits
//!
//! Wanneer u vra dat 'n argument met 'n bepaalde tipe geformateer word, vra u eintlik dat 'n argument aan 'n bepaalde trait toegeskryf word.
//! Hiermee kan verskeie werklike soorte geformateer word via `{:x}` (soos [`i8`] sowel as [`isize`]).Die huidige kartering van soorte aan traits is:
//!
//! * *niks* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] met kleinletters heksadesimale heelgetalle
//! * `X?` ⇒ [`Debug`] met hoofletters heksadesimale heelgetalle
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Wat dit beteken, is dat enige soort argument wat die [`fmt::Binary`][`Binary`] trait implementeer, dan met `{:b}` geformateer kan word.Die standaardbiblioteek bied ook implementerings vir hierdie traits vir 'n aantal primitiewe tipes.
//!
//! As geen formaat gespesifiseer word nie (soos in `{}` of `{:6}`), is die formaat trait die [`Display`] trait.
//!
//! Wanneer u 'n formaat trait vir u eie tipe implementeer, moet u 'n metode van die handtekening implementeer:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // ons pasgemaakte tipe
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! U tipe word as `self`-verwysing deurgegee, en dan moet die funksie uitvoer na die `f.buf`-stroom uitstraal.Dit is aan elke formaat van die implementering van die trait om die gevraagde opmaakparameters korrek na te kom.
//! Die waardes van hierdie parameters sal in die velde van die [`Formatter`]-struktuur gelys word.Om hiermee te help, bied die [`Formatter`] struct ook 'n paar helpermetodes.
//!
//! Boonop is die terugkeerwaarde van hierdie funksie [`fmt::Result`], wat 'n tipe alias is van [`Resultaat`]`<(),`[`std: : fmt::Fout`]>>.
//! Die implementering van die formatering moet verseker dat dit foute vanaf die [`Formatter`] versprei (bv. Wanneer u [`write!`] skakel).
//! Hulle moet egter nooit foute foutief terugstuur nie.
//! Dit wil sê, 'n opmaakimplementering moet en mag slegs 'n fout oplewer as die ingediende [`Formatter`] 'n fout oplewer.
//! Dit is omdat, anders as wat die funksie-handtekening kan voorstel, snaaropmaak 'n onfeilbare bewerking is.
//! Hierdie funksie lewer slegs 'n resultaat omdat skryf na die onderliggende stroom kan misluk en dit moet 'n manier bied om die feit dat 'n fout in die stapel voorgekom het, te versprei.
//!
//! 'N Voorbeeld van die implementering van die opmaak van traits sal lyk soos volg:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Die `f`-waarde implementeer die `Write` trait, wat skryf!makro verwag.
//!         // Let daarop dat hierdie opmaak die verskillende vlae wat verskaf word om snare te formateer, ignoreer.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Verskillende traits laat verskillende vorms van uitvoer van 'n tipe toe.
//! // Die betekenis van hierdie formaat is om die grootte van 'n vector af te druk.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Respekteer die formateringsvlae deur die helpermetode `pad_integral` op die Formatter-voorwerp te gebruik.
//!         // Raadpleeg die metodedokumentasie vir meer inligting, en die funksie `pad` kan gebruik word om snare te kussing.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` teenoor `fmt::Debug`
//!
//! Hierdie twee formatering van traits het verskillende doeleindes:
//!
//! - [`fmt::Display`][`Display`] implementasies beweer dat die tipe te alle tye getrou as 'n UTF-8-string voorgestel kan word.Daar word **nie** verwag dat alle soorte die [`Display`] trait implementeer nie.
//! - [`fmt::Debug`][`Debug`] implementerings moet vir **alle** openbare tipes geïmplementeer word.
//!   Uitset sal die interne toestand tipies so getrou moontlik voorstel.
//!   Die doel van die [`Debug`] trait is om ontfouting van die Rust-kode te vergemaklik.In die meeste gevalle is die gebruik van `#[derive(Debug)]` voldoende en word dit aanbeveel.
//!
//! Enkele voorbeelde van die uitvoer van beide traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Verwante makro's
//!
//! Daar is 'n aantal verwante makro's in die [`format!`]-familie.Diegene wat tans geïmplementeer word, is:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Dit en [`writeln!`] is twee makro's wat gebruik word om die formaatreeks na 'n bepaalde stroom uit te stuur.Dit word gebruik om tussentoewysing van formaatstringe te voorkom en eerder die uitvoer direk te skryf.
//! Onder die kap gebruik hierdie funksie eintlik die [`write_fmt`]-funksie wat op die [`std::io::Write`] trait gedefinieër is.
//! Voorbeeldgebruik is:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Dit en [`println!`] stuur hul produksie na stdout uit.Net soos met die [`write!`]-makro, is die doel van hierdie makro's om tussentydse toekennings te vermy tydens die druk van die uitvoer.Voorbeeldgebruik is:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Die [`eprint!`]-en [`eprintln!`]-makro's is identies aan onderskeidelik [`print!`] en [`println!`], behalwe dat hulle hul uitvoer na stderr uitstuur.
//!
//! ### `format_args!`
//!
//! Dit is 'n nuuskierige makro wat gebruik word om 'n ondeursigtige voorwerp veilig deur die formaatreeks te beskryf.Hierdie objek benodig geen hooptoekennings om te skep nie, en dit verwys slegs na inligting op die stapel.
//! Onder die enjinkap word al die verwante makro's in terme hiervan geïmplementeer.
//! Eerstens, 'n paar voorbeelde is:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Die resultaat van die [`format_args!`]-makro is 'n waarde van die tipe [`fmt::Arguments`].
//! Hierdie struktuur kan dan na die [`write`]-en [`format`]-funksies in hierdie module oorgedra word om die formaatreeks te verwerk.
//! Die doel van hierdie makro is om die toekenning van tussentydse toekennings nog verder te voorkom.
//!
//! Byvoorbeeld, 'n logboekbiblioteek kan die standaardformatering-sintaksis gebruik, maar dit sal intern deur hierdie struktuur beweeg totdat daar bepaal is waarheen die uitvoer moet gaan.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Die `format`-funksie het 'n [`Arguments`]-structuur en gee die resulterende geformatteerde string terug.
///
///
/// Die [`Arguments`]-instansie kan met die [`format_args!`]-makro geskep word.
///
/// # Examples
///
/// Basiese gebruik:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Let daarop dat die gebruik van [`format!`] verkieslik kan wees.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}