//! Geheuetoekenning-API's

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Dit is die towersimbole om die wêreldwye toekenning te noem.rustc genereer hulle om `__rg_alloc` ens.
    // as daar 'n `#[global_allocator]`-kenmerk is (die kode wat die kenmerkmakro uitbrei, genereer die funksies), of om die standaardimplementasies in libstd (`__rdl_alloc`, ens.) te noem
    //
    // in `library/std/src/alloc.rs`) anders.
    // Die rustc fork van LLVM spesialiseer ook hierdie funksiename om dit soos onderskeidelik `malloc`, `realloc` en `free` te optimaliseer.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// Die wêreldwye geheue-toekenning.
///
/// Hierdie tipe implementeer die [`Allocator`] trait deur oproepe deur te stuur na die toewyser wat geregistreer is met die `#[global_allocator]`-kenmerk as daar een is, of die standaard `std` crate.
///
///
/// Note: hoewel hierdie tipe onstabiel is, kan die funksies wat dit bied deur die [free functions in `alloc`](self#functions) verkry word.
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Ken geheue toe aan die globale toewyser.
///
/// Hierdie funksie stuur oproepe na die [`GlobalAlloc::alloc`]-metode van die toewyser wat by die `#[global_allocator]`-kenmerk geregistreer is, as daar een is, of die standaard van die `std` crate.
///
///
/// Die funksie sal na verwagting afgekeur word ten gunste van die `alloc`-metode van die [`Global`]-tipe wanneer dit en die [`Allocator`] trait stabiel word.
///
/// # Safety
///
/// Sien [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Hanteer geheue met die wêreldwye toewyser.
///
/// Hierdie funksie stuur oproepe na die [`GlobalAlloc::dealloc`]-metode van die toewyser wat by die `#[global_allocator]`-kenmerk geregistreer is, as daar een is, of die standaard van die `std` crate.
///
///
/// Die funksie sal na verwagting afgekeur word ten gunste van die `dealloc`-metode van die [`Global`]-tipe wanneer dit en die [`Allocator`] trait stabiel word.
///
/// # Safety
///
/// Sien [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Herplaats die geheue met die globale toewyser.
///
/// Hierdie funksie stuur oproepe na die [`GlobalAlloc::realloc`]-metode van die toewyser wat by die `#[global_allocator]`-kenmerk geregistreer is, as daar een is, of die standaard van die `std` crate.
///
///
/// Die funksie sal na verwagting afgekeur word ten gunste van die `realloc`-metode van die [`Global`]-tipe wanneer dit en die [`Allocator`] trait stabiel word.
///
/// # Safety
///
/// Sien [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Ken nul-geïnisialiseerde geheue toe aan die globale toewyser.
///
/// Hierdie funksie stuur oproepe na die [`GlobalAlloc::alloc_zeroed`]-metode van die toewyser wat by die `#[global_allocator]`-kenmerk geregistreer is, as daar een is, of die standaard van die `std` crate.
///
///
/// Die funksie sal na verwagting afgekeur word ten gunste van die `alloc_zeroed`-metode van die [`Global`]-tipe wanneer dit en die [`Allocator`] trait stabiel word.
///
/// # Safety
///
/// Sien [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // VEILIGHEID: `layout` is nie nul in grootte,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // VEILIGHEID: Dieselfde as `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // VEILIGHEID: `new_size` is nie-nul, want `old_size` is groter as of gelyk aan `new_size`
            // soos vereis deur veiligheidsvoorwaardes.Ander voorwaardes moet deur die oproeper gehandhaaf word
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` gaan waarskynlik na `new_size >= old_layout.size()` of iets soortgelyks.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // VEILIGHEID: omdat `new_layout.size()` groter of gelyk aan `old_size` moet wees,
            // sowel die ou as die nuwe geheuetoekenning is geldig vir lees en skryf vir `old_size`-grepe.
            // Omdat die ou toekenning nog nie geallokeer is nie, kan dit nie `new_ptr` oorvleuel nie.
            // Die oproep na `copy_nonoverlapping` is dus veilig.
            // Die oproeper moet die veiligheidskontrak vir `dealloc` nakom.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // VEILIGHEID: `layout` is nie nul in grootte,
            // ander voorwaardes moet deur die oproeper gehandhaaf word
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // VEILIGHEID: alle voorwaardes moet deur die oproeper gehandhaaf word
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // VEILIGHEID: alle voorwaardes moet deur die oproeper gehandhaaf word
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // VEILIGHEID: voorwaardes moet deur die oproeper gehandhaaf word
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // VEILIGHEID: `new_size` is nie-nul.Ander voorwaardes moet deur die oproeper gehandhaaf word
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` gaan waarskynlik na `new_size <= old_layout.size()` of iets soortgelyks.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // VEILIGHEID: omdat `new_size` kleiner as of gelyk aan `old_layout.size()` moet wees,
            // sowel die ou as die nuwe geheuetoekenning is geldig vir lees en skryf vir `new_size`-grepe.
            // Omdat die ou toekenning nog nie geallokeer is nie, kan dit nie `new_ptr` oorvleuel nie.
            // Die oproep na `copy_nonoverlapping` is dus veilig.
            // Die oproeper moet die veiligheidskontrak vir `dealloc` nakom.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// Die toewyser vir unieke wenke.
// Hierdie funksie moet nie ontspan nie.As dit wel gebeur, sal MIR codegen misluk.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Hierdie handtekening moet dieselfde wees as `Box`, anders sal 'n ICE plaasvind.
// Wanneer 'n addisionele parameter by `Box` gevoeg word (soos `A: Allocator`), moet dit ook hier bygevoeg word.
// As `Box` byvoorbeeld na `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)` verander word, moet hierdie funksie ook na `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` verander word.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Toekenningsfouthanteerder

extern "Rust" {
    // Dit is die towersimbool om die globale toewysingsfouthanteerder te noem.
    // rustc genereer dit om `__rg_oom` te skakel as daar 'n `#[alloc_error_handler]` is, of andersins die standaardimplementasies hieronder (`__rdl_oom`) te noem.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Staak die fout of die mislukking van geheue-toekenning.
///
/// Bellers van geheue-toekenning-API's wat berekening wil staak as gevolg van 'n toewysingsfout, word aangemoedig om hierdie funksie te skakel, eerder as om `panic!` of soortgelyke direkte aan te roep.
///
///
/// Die standaardgedrag van hierdie funksie is om 'n boodskap na standaardfoute te druk en die proses te staak.
/// Dit kan vervang word met [`set_alloc_error_hook`] en [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Vir toekenningstoets kan `std::alloc::handle_alloc_error` direk gebruik word.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // geskakel via gegenereerde `__rust_alloc_error_handler`

    // as daar geen `#[alloc_error_handler]` is nie
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // as daar 'n `#[alloc_error_handler]` is
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Spesifiseer klone in vooraf toegewysde, ongeïnisialiseerde geheue.
/// Gebruik deur `Box::clone` en `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // As u *eerste* toegeken het, kan die optimaliseerder die gekloonde waarde in die plek skep, die plaaslike oorslaan en beweeg.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Ons kan altyd in plek kopieer, sonder om ooit 'n plaaslike waarde te betrek.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}