use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Om 'n toets van integrasie tussen derdepartytoewysers en `RawVec` te skryf, is 'n bietjie lastig omdat die `RawVec` API nie feilbare toewysingsmetodes blootlê nie, dus kan ons nie kyk wat gebeur as die toewyser uitgeput is nie (behalwe om 'n panic op te spoor).
    //
    //
    // In plaas daarvan gaan dit net na of die `RawVec`-metodes ten minste deur die Allocator API gaan as dit berging behou.
    //
    //
    //
    //
    //

    // 'N Stomme toewyser wat 'n vaste hoeveelheid brandstof verbruik voordat die toewysingspogings misluk.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (veroorsaak 'n reëling, en gebruik dus 50 + 150=200 eenhede brandstof)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Eerstens ken `reserve` toe soos `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 is meer as die dubbele van 7, dus `reserve` moet soos `reserve_exact` werk.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 is minder as die helfte van 12, dus moet `reserve` eksponensieel groei.
        // Op die oomblik dat hierdie toets geskryf is, is die groeifaktor 2, dus die nuwe kapasiteit is 24, maar die groeifaktor van 1.5 is ook OK.
        //
        // Daarom `>= 18` in beweer.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}