#![feature(no_core)]
#![no_core]

// Kyk na rustc-std-werkruimte-kern waarom hierdie crate nodig is.

// Herbenoem die naam van die crate om te verhoed dat dit met die toekenningsmodule in liballoc bots.
extern crate alloc as foo;

pub use foo::*;