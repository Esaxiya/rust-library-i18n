use backtrace::Backtrace;

// Hierdie toets werk slegs op platforms met 'n werkende `symbol_address`-funksie vir rame wat die beginadres van 'n simbool rapporteer.
// As gevolg hiervan word dit slegs op enkele platforms geaktiveer.
//
const ENABLED: bool = cfg!(all(
    // Windows is nie regtig getoets nie, en OSX ondersteun nie om 'n omringende raamwerk te vind nie, dus skakel dit uit
    //
    target_os = "linux",
    // As u die ARM vind, is die omsluitende funksie eenvoudig om die ip self terug te gee.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}