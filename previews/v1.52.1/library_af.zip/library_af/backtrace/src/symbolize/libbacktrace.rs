//! Simboliseringstrategie met behulp van die DWARF-ontledingskode in libbacktrace.
//!
//! Die libbacktrace C-biblioteek, wat gewoonlik met gcc versprei word, ondersteun nie net die opwekking van 'n terugspoor nie (wat ons nie eintlik gebruik nie), maar ook die terugspoor en die hantering van dwergfout-inligting oor dinge soos ingelyste rame en wat nog.
//!
//!
//! Dit is relatief ingewikkeld as gevolg van baie probleme hier, maar die basiese idee is:
//!
//! * Eers noem ons `backtrace_syminfo`.Dit kry simboolinligting uit die dinamiese simbooltabel as ons kan.
//! * Vervolgens noem ons `backtrace_pcinfo`.Dit sal debuginfo-tabelle ontleed as dit beskikbaar is en ons in staat stel om inligting oor ingeboude rame, lêername, reynommers, ens.
//!
//! Daar is baie lastighede om die dwergtafels in libbacktrace te kry, maar dit is hopelik nie die einde van die wêreld nie en is duidelik genoeg as u hieronder lees.
//!
//! Dit is die standaard simboliseringstrategie vir nie-MSVC-en nie-OSX-platforms.In libstd is dit egter die standaardstrategie vir OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Indien moontlik verkies u die `function`-naam wat van debuginfo afkomstig is en gewoonlik akkurater kan wees vir byvoorbeeld inlyste rame.
                // As dit nie aanwesig is nie, val dan terug na die simbooltabelnaam wat in `symname` gespesifiseer is.
                //
                // Let daarop dat `function` soms ietwat minder akkuraat kan voel, byvoorbeeld as `try<i32,closure>` nie `std::panicking::try::do_call` is nie.
                //
                // Dit is nie regtig duidelik waarom nie, maar oor die algemeen lyk die `function`-naam akkurater.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // doen vir eers niks
}

/// Tipe `data`-wyser wat in `syminfo_cb` oorgedra word
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Sodra hierdie terugbel vanaf `backtrace_syminfo` aangeroep word wanneer ons begin oplos, gaan ons verder na `backtrace_pcinfo`.
    // Die `backtrace_pcinfo`-funksie sal foutopsporingsinligting raadpleeg en probeer om dinge te doen soos die herstel van file/line-inligting sowel as inlynrame.
    // Let daarop dat `backtrace_pcinfo` kan misluk of nie veel kan doen as daar nie inligting oor foutopsporing is nie, dus as ons dit doen, bel ons seker dat ons met minstens een simbool van die `syminfo_cb` die terugbel skakel.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Tipe `data`-wyser wat in `pcinfo_cb` oorgedra word
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Die libbacktrace API ondersteun die skep van 'n staat, maar dit ondersteun nie die vernietiging van 'n staat nie.
// Ek neem dit persoonlik aan dat 'n staat bedoel is om geskep te word en dan vir ewig te lewe.
//
// Ek wil graag 'n at_exit()-hanteerder registreer wat hierdie toestand opruim, maar libbacktrace bied geen manier om dit te doen nie.
//
// Met hierdie beperkings het hierdie funksie 'n statiese kas-toestand wat bereken word die eerste keer wat dit aangevra word.
//
// Onthou dat terugspoor alles in serie plaasvind (een globale slot).
//
// Let op dat die gebrek aan sinkronisering hier te wyte is aan die vereiste dat `resolve` ekstern gesinchroniseer moet word.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Moenie threadsafe-vermoëns van libbacktrace uitoefen nie, want ons noem dit altyd op 'n gesinchroniseerde manier.
        //
        0,
        error_cb,
        ptr::null_mut(), // geen ekstra data nie
    );

    return STATE;

    // Let daarop dat libbacktrace hoegenaamd die DWARF-foutopsporingsinligting vir die huidige uitvoerbare program moet vind.Dit word gewoonlik gedoen deur middel van 'n aantal meganismes, insluitend, maar nie beperk nie tot:
    //
    // * /proc/self/exe op ondersteunde platforms
    // * Die lêernaam is eksplisiet deurgegee tydens die skep van die staat
    //
    // Die libbacktrace-biblioteek is 'n groot hoeveelheid C-kode.Dit beteken natuurlik dat dit geheueveiligheidsprobleme het, veral as u misvormde debuginfo hanteer.
    // Libstd het histories baie hiervan raakgeloop.
    //
    // As /proc/self/exe gebruik word, kan ons dit gewoonlik ignoreer, aangesien ons aanvaar dat libbacktrace "mostly correct" is en anders nie vreemde dinge doen met "attempted to be correct"-dwergfout-inligting nie.
    //
    //
    // As ons egter 'n lêernaam verstuur, is dit op sommige platforms (soos BSD's) moontlik waar 'n kwaadwillige akteur kan veroorsaak dat 'n arbitrêre lêer op die plek geplaas word.
    // Dit beteken dat as ons libbacktrace van 'n lêernaam vertel, dit moontlik 'n arbitrêre lêer gebruik wat sigfoute kan veroorsaak.
    // As ons egter niks van libbacktrace vertel nie, sal dit niks doen op platforms wat nie paaie soos /proc/self/exe ondersteun nie!
    //
    // Gegewe dit alles probeer ons so hard as moontlik om 'n lêernaam *nie* in te gee nie, maar ons moet op platforms wat glad nie /proc/self/exe ondersteun nie.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Let daarop dat ons ideaal gesproke `std::env::current_exe` sal gebruik, maar dat ons nie `std` hier benodig nie.
            //
            // Gebruik `_NSGetExecutablePath` om die huidige uitvoerbare pad in 'n statiese gebied te laai (wat as dit te klein is, gee net op).
            //
            //
            // Let daarop dat ons libbacktrace hier ernstig vertrou om nie aan korrupte uitvoerbare programme te sterf nie, maar dit doen beslis ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows het 'n modus om lêers oop te maak waar dit nie verwyder kan word nadat dit oopgemaak is nie.
            // Dit is oor die algemeen wat ons hier wil hê, omdat ons wil verseker dat ons uitvoerbare program nie onder ons verander nie, nadat ons dit aan libbacktrace oorgedra het, hopelik die vermoë om arbitrêre data in libbacktrace (wat verkeerd hanteer kan word) in te gee.
            //
            //
            // Aangesien ons hier 'n bietjie dans om te probeer om 'n soort slot op ons eie beeld te kry:
            //
            // * Kry die huidige proses hanteer, laai die lêernaam daarvan.
            // * Open 'n lêer vir die lêernaam met die regte vlae.
            // * Herlaai die lêernaam van die huidige proses en maak seker dat dit dieselfde is
            //
            // As dit alles slaag, het ons in teorie inderdaad ons proses se lêer geopen en ons is gewaarborg dat dit nie sal verander nie.FWIW 'n klomp hiervan word histories van libstd gekopieer, so dit is my beste interpretasie van wat gebeur het.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Dit leef in 'n statiese geheue sodat ons dit kan teruggee ..
                static mut BUF: [i8; N] = [0; N];
                // ... en dit leef op die stapel omdat dit tydelik is
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // lek `handle` doelbewus hier, want as ons dit oopmaak, moet ons die slot op hierdie lêernaam behou.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Ons wil 'n snytjie met nulbeëindiging teruggee, dus as alles ingevul is en dit gelyk is aan die totale lengte, vergelyk dit dan met mislukking.
                //
                //
                // Andersins, as u sukses behaal, moet u seker maak dat die nulbyte in die sny ingesluit is.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // terugspoorfoute word tans onder die mat ingevee
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Bel die `backtrace_syminfo` API wat (vanaf die lees van die kode) `syminfo_cb` presies een keer moet skakel (of miskien met 'n fout).
    // Ons hanteer dan meer binne die `syminfo_cb`.
    //
    // Let daarop dat ons dit doen, aangesien `syminfo` die simbooltabel sal raadpleeg en simbole se name vind, selfs al is daar geen foutopsporingsinligting in die binêre nie.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}