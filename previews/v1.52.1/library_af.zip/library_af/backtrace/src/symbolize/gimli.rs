//! Ondersteuning vir simbolisering met behulp van die `gimli` crate op crates.io
//!
//! Dit is die standaardimplementering vir Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'statiese leeftyd is 'n leuen om 'n gebrek aan ondersteuning vir selfverwysende strukture te maak.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Skakel om na 'statiese leeftyd', aangesien die simbole slegs `map` en `stash` moet leen en ons bewaar dit hieronder.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Vir die laai van inheemse biblioteke op Windows, kyk na die bespreking op rust-lang/rust#71060 vir die verskillende strategieë hier.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW-biblioteke ondersteun tans nie ASLR (rust-lang/rust#16514) nie, maar DLL's kan steeds in die adresruimte verskuif word.
            // Dit blyk dat adresse in foutopsporingsinligting almal lyk asof hierdie biblioteek op die "image base" gelaai is, wat 'n veld in sy COFF-lêeropskrifte is.
            // Aangesien dit blyk dat debuginfo 'n lys het, ontleed ons die simbooltabel en slaan ons adresse op asof die biblioteek ook op "image base" gelaai is.
            //
            // Die biblioteek mag egter nie op "image base" gelaai word nie.
            // (vermoedelik kan daar nog iets gelaai word?) Dit is hier waar die `bias`-veld ter sprake kom, en ons moet die waarde van `bias` hier uitvind.Helaas is dit egter nie duidelik hoe dit van 'n gelaaide module verkry kan word nie.
            // Wat ons wel het, is die werklike laadadres (`modBaseAddr`).
            //
            // As 'n bietjie cop-out tot nou toe, mmap ons die lêer, lees die lêerkopinligting en laat val dan die mmap.Dit is verkwistend omdat ons die mmap waarskynlik later weer sal oopmaak, maar dit behoort voorlopig goed te werk.
            //
            // Sodra ons die `image_base` (gewenste laaiplek) en die `base_addr` (werklike laaiplek) het, kan ons die `bias` invul (verskil tussen die werklike en gewenste) en dan is die opgegeven adres van elke segment die `image_base`, want dit is wat die lêer sê.
            //
            //
            // Voorlopig blyk dit dat ons in teenstelling met ELF/MachO met een segment per biblioteek kan klaarkom en `modBaseSize` as die totale grootte gebruik.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS gebruik die Mach-O-lêerformaat en gebruik DYLD-spesifieke API's om 'n lys van inheemse biblioteke wat deel van die toepassing is, te laai.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Haal die naam van hierdie biblioteek wat ooreenstem met die pad waarheen u dit ook moet laai.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Laai die beeldkopkop van hierdie biblioteek en delegeer na `object` om al die laai-opdragte te ontleed sodat ons al die betrokke segmente kan uitvind.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Iterasie oor die segmente en registreer bekende streke vir segmente wat ons vind.
            // Neem ook inligting oor tekssegmente op vir later verwerking, sien opmerkings hieronder.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Bepaal die "slide" vir hierdie biblioteek, wat uiteindelik die vooroordeel is wat ons gebruik om uit te vind waar in die geheue voorwerpe gelaai is.
            // Dit is egter 'n bietjie vreemde berekening en is die resultaat van die probeer van 'n paar dinge in die natuur en om te sien wat bybly.
            //
            // Die algemene idee is dat die `bias` plus die `stated_virtual_memory_address` van 'n segment sal wees waar die segment in die werklike adresruimte is.
            // Die ander ding waarop ons egter vertrou, is dat 'n regte adres minus die `bias` die indeks is om na te kyk in die simbooltabel en debuginfo.
            //
            // Dit blyk egter dat die berekeninge vir stelselbelaaide biblioteke nie korrek is nie.Vir oorspronklike uitvoerbare programme lyk dit egter korrek.
            // As u 'n bietjie logika uit die bron van LLDB haal, het dit 'n spesiale omhulsel vir die eerste `__TEXT`-gedeelte wat vanaf lêerversetting 0 met 'n nie-nul-grootte gelaai word.
            // Om watter rede ook al, wanneer dit teenwoordig is, blyk dit dat die simbooltabel relatief is tot net die vmaddr-skyfie vir die biblioteek.
            // As dit *nie* is nie, is die simbooltabel relatief tot die vmaddr-skyfie plus die adres van die segment.
            //
            // Om hierdie situasie te hanteer as ons *nie*'n teksgedeelte vind by lêerversetting nul nie, verhoog ons die vooroordeel met die adres van die eerste teksgedeeltes en verminder u ook al die genoemde adresse met die bedrag.
            //
            // Op die manier verskyn die simbooltabel altyd in verhouding tot die vooroordeel van die biblioteek.
            // Dit lyk asof dit die regte resultate het om te simboliseer via die simbooltabel.
            //
            // Eerlik gesê, ek is nie heeltemal seker of dit reg is en of daar iets anders is wat moet aandui hoe om dit te doen nie.
            // Vir nou lyk dit egter goed genoeg (?) en ons moet dit altyd mettertyd kan aanpas indien nodig.
            //
            // Vir meer inligting, sien #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Ander Unix (bv
        // Linux)-platforms gebruik ELF as 'n objeklêerformaat en implementeer gewoonlik 'n API genaamd `dl_iterate_phdr` om inheemse biblioteke te laai.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` moet 'n geldige aanwyser wees.
        // `vec` moet 'n geldige aanwyser vir 'n `std::Vec` wees.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 ondersteun nie foutopsporingsinligting nie, maar die opstelstelsel plaas foutopsporingsinligting op die pad `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Al die ander moet ELF gebruik, maar weet nie hoe om inheemse biblioteke te laai nie.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Alle bekende gedeelde biblioteke wat gelaai is.
    libraries: Vec<Library>,

    /// Toewysings lê in die kas waar ons ontleed-dwerginligting bewaar.
    ///
    /// Hierdie lys het 'n vaste kapasiteit vir sy hele tydsduur wat nooit toeneem nie.
    /// Die `usize`-element van elke paar is 'n indeks in `libraries` hierbo, waar `usize::max_value()` die huidige uitvoerbare weergawe voorstel.
    ///
    /// Die `Mapping` is ooreenstemmende geparseerde dwerginligting.
    ///
    /// Let daarop dat dit basies 'n LRU-kas is en dat ons dinge hierin sal skuif soos ons adresse simboliseer.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Segmente van hierdie biblioteek is in die geheue gelaai en waar dit gelaai word.
    segments: Vec<LibrarySegment>,
    /// Die "bias" van hierdie biblioteek, gewoonlik waar dit in die geheue gelaai is.
    /// Hierdie waarde word by die opgegeven adres van elke segment gevoeg om die werklike virtuele geheue-adres te kry waarin die segment gelaai is.
    /// Boonop word hierdie vooroordeel van regte virtuele geheue-adresse afgetrek om in debuginfo en die simbooltabel te indekseer.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Die genoemde adres van hierdie segment in die objeklêer.
    /// Dit is nie waar die segment gelaai is nie, maar eerder hierdie adres plus die `bias`-biblioteek wat dit bevat, is waar dit gevind kan word.
    ///
    stated_virtual_memory_address: usize,
    /// Die grootte van hierdie segment in die geheue.
    len: usize,
}

// onveilig, want dit moet ekstern gesinchroniseer word
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // onveilig, want dit moet ekstern gesinchroniseer word
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // 'N Baie klein, baie eenvoudige LRU-kas vir die foutopsporing van inligting.
        //
        // Die slaagsyfer moet baie hoog wees, aangesien die tipiese stapel nie tussen baie gedeelde biblioteke kruis nie.
        //
        // Die `addr2line::Context`-strukture is redelik duur om te skep.
        // Die koste daarvan sal na verwagting geamortiseer word deur daaropvolgende `locate`-navrae, wat gebruik maak van die strukture wat gebou is by die bou van 'addr2line: : Context' om goeie versnellings te kry.
        //
        // As ons nie hierdie kas gehad het nie, sou die amortisasie nooit plaasvind nie, en sou dit simboliese terugspore wees ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Eerstens, toets of hierdie `lib` 'n segment het wat die `addr` bevat (hantering van hervestiging).As hierdie tjek slaag, kan ons hieronder voortgaan en die adres eintlik vertaal.
                //
                // Let daarop dat ons `wrapping_add` hier gebruik om oorloopkontroles te voorkom.Daar is in die natuur gesien dat die SVMA+- vooroordeelberekening oorloop.
                // Dit lyk 'n bietjie vreemd dat dit sou gebeur, maar ons kan nie veel daaraan doen nie, behalwe om daardie segmente waarskynlik net te ignoreer, aangesien dit waarskynlik na die ruimte wys.
                //
                // Dit het oorspronklik in rust-lang/backtrace-rs#329 verskyn.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Noudat ons weet dat `lib` `addr` bevat, kan ons die vooroordeel verreken om die genoemde virutale geheue-adres te vind.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Afwisselend: na hierdie voorwaardelike voltooiing sonder vroeë terugkeer
        // na 'n fout, is die kasinvoer vir hierdie pad by indeks 0.

        if let Some(idx) = idx {
            // As die kartering reeds in die kas is, skuif dit na voor.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // As die kartering nie in die kas is nie, skep 'n nuwe kartering, plaas dit voor in die kas en sit die oudste kasinvoer uit indien nodig.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // Moenie die `'static`-leeftyd lek nie, maak seker dat dit net vir onsself gerig is
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Verleng die lewensduur van `sym` tot `'static`, want ons moet ongelukkig hierheen gaan, maar dit gaan altyd as verwysing uit, dus daar moet in elk geval geen verwysing daarna wees nie.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Uiteindelik, kry 'n kas-kartering of skep 'n nuwe kartering vir hierdie lêer, en evalueer die DWARF-inligting om die file/line/name vir hierdie adres te vind.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Ons kon raaminligting vir hierdie simbool opspoor, en die raamwerk van 'addr2line' bevat al die fyn details.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Kon nie foutopsporingsinligting vind nie, maar ons het dit gevind in die simbooltabel van die uitvoerbare elf.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}