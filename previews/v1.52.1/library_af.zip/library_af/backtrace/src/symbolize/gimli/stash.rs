// word nou net op Linux gebruik, dus laat dooie kode elders toe
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// 'N Eenvoudige arena-toekenning vir byte-buffers.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Ken 'n buffer van die gespesifiseerde grootte toe en gee 'n veranderlike verwysing daarna.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // VEILIGHEID: dit is die enigste funksie wat ooit 'n veranderlike konstrueer
        // verwysing na `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // VEILIGHEID: ons verwyder nooit elemente van `self.buffers` nie, dus 'n verwysing
        // die data binne-in enige buffer sal leef so lank as wat `self` dit doen.
        &mut buffers[i]
    }
}