use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Los 'n adres op na 'n simbool en gee die simbool na die gespesifiseerde sluiting.
///
/// Hierdie funksie sal die gegewe adres in gebiede soos die plaaslike simbooltabel, dinamiese simbooltabel of DWARF-foutopsporingsinligting opsoek (afhangende van die geaktiveerde implementering) om simbole te vind om op te lewer.
///
///
/// Die sluiting kan nie genoem word as resolusie nie kon uitgevoer word nie, en dit kan ook meer as een keer genoem word in geval van ingelyste funksies.
///
/// Die simbole wat aangebied word, verteenwoordig die uitvoering op die gespesifiseerde `addr`, wat file/line-pare vir daardie adres (as beskikbaar) terugbesorg.
///
/// Let daarop dat as u 'n `Frame` het, word dit aanbeveel om die `resolve_frame`-funksie te gebruik in plaas van hierdie.
///
/// # Vereiste funksies
///
/// Hierdie funksie vereis dat die `std`-funksie van die `backtrace` crate geaktiveer is, en die `std`-funksie is standaard geaktiveer.
///
/// # Panics
///
/// Hierdie funksie streef daarna om nooit panic nie, maar as die `cb` panics verskaf, sal sommige platforms 'n dubbele panic dwing om die proses te staak.
/// Sommige platforms gebruik 'n C-biblioteek wat interne terugbels gebruik wat nie deurgedraai kan word nie, dus kan paniek vanaf `cb` 'n proses staak.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // kyk net na die boonste raam
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Los 'n raam wat voorheen vasgelê is op na 'n simbool en gee die simbool na die gespesifiseerde sluiting.
///
/// Hierdie funksie voer dieselfde funksie uit as `resolve`, behalwe dat dit 'n `Frame` as argument neem in plaas van 'n adres.
/// Dit kan sommige platformimplementasies van terugsporing toelaat om meer akkurate simboolinligting of inligting oor byvoorbeeld inlyframe te bied.
///
/// Dit word aanbeveel om dit te gebruik as u kan.
///
/// # Vereiste funksies
///
/// Hierdie funksie vereis dat die `std`-funksie van die `backtrace` crate geaktiveer is, en die `std`-funksie is standaard geaktiveer.
///
/// # Panics
///
/// Hierdie funksie streef daarna om nooit panic nie, maar as die `cb` panics verskaf, sal sommige platforms 'n dubbele panic dwing om die proses te staak.
/// Sommige platforms gebruik 'n C-biblioteek wat interne terugbels gebruik wat nie deurgedraai kan word nie, dus kan paniek vanaf `cb` 'n proses staak.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // kyk net na die boonste raam
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// IP-waardes van stapelraamwerke is gewoonlik die (always?)-instruksie *na* die oproep wat die werklike stapelspoor is.
// Deur dit te simboliseer, is die filename/line-nommer een voor en miskien in die niet as dit naby die einde van die funksie is.
//
// Dit blyk basies altyd die geval te wees op alle platforms, dus trek ons altyd een van 'n opgeloste ip af om dit op te los na die vorige oproepinstruksie in plaas van waarna die instruksie teruggestuur word.
//
//
// Ideaal gesproke sou ons dit nie doen nie.
// Die ideaal is dat ons die bellers van die `resolve` API's hier benodig om die -1 handmatig te doen en in ag te neem dat hulle liggingsinligting vir die *vorige* instruksie wil hê, nie die huidige nie.
// Die ideaal is dat ons ook aan `Frame` blootstel as ons inderdaad die adres van die volgende instruksie of die huidige is.
//
// Vir nou is dit egter 'n redelike nisbelang, dus trek ons net een intern altyd af.
// Verbruikers moet aanhou werk en behoorlik goeie resultate behaal, dus moet ons goed genoeg wees.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Dieselfde as `resolve`, net onveilig aangesien dit nie gesinkroniseer is nie.
///
/// Hierdie funksie het nie sinkronisasie-waarborge nie, maar is beskikbaar as die `std`-funksie van hierdie crate nie saamgestel is nie.
/// Raadpleeg die `resolve`-funksie vir meer dokumentasie en voorbeelde.
///
/// # Panics
///
/// Sien inligting op `resolve` vir voorbehoud by `cb`-paniek.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Dieselfde as `resolve_frame`, net onveilig aangesien dit nie gesinkroniseer is nie.
///
/// Hierdie funksie het nie sinkronisasie-waarborge nie, maar is beskikbaar as die `std`-funksie van hierdie crate nie saamgestel is nie.
/// Raadpleeg die `resolve_frame`-funksie vir meer dokumentasie en voorbeelde.
///
/// # Panics
///
/// Sien inligting op `resolve_frame` vir voorbehoud by `cb`-paniek.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// 'N trait wat die resolusie van 'n simbool in 'n lêer voorstel.
///
/// Hierdie trait word aangebied as 'n trait-voorwerp vir die sluiting van die `backtrace::resolve`-funksie, en dit word feitlik versend, aangesien dit onbekend is watter implementering daaragter is.
///
///
/// 'N Simbool kan kontekstuele inligting oor 'n funksie gee, byvoorbeeld die naam, lêernaam, reëlnommer, presiese adres, ens.
/// Nie alle inligting is altyd in 'n simbool beskikbaar nie, dus gee alle metodes 'n `Option`.
///
///
pub struct Symbol {
    // TODO: hierdie lewenslange verbintenis moet uiteindelik tot `Symbol` volgehou word,
    // maar dit is tans 'n breekende verandering.
    // Dit is op die oomblik veilig, want `Symbol` word slegs per verwysing uitgedeel en kan nie gekloon word nie.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Wys die naam van hierdie funksie.
    ///
    /// Die teruggestuurde struktuur kan gebruik word om verskillende eienskappe oor die simboolnaam te bevraagteken:
    ///
    ///
    /// * Die `Display`-implementering sal die ontmantelde simbool druk.
    /// * Die rou `str`-waarde van die simbool is verkrygbaar (as dit geldig is utf-8).
    /// * Die rou grepe vir die simboolnaam kan verkry word.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Wys die beginadres van hierdie funksie.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Wys die rou lêernaam as 'n stuk.
    /// Dit is veral nuttig vir `no_std`-omgewings.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Wys die kolomnommer vir waar hierdie simbool tans uitgevoer word.
    ///
    /// Slegs gimli bied tans 'n waarde hier en selfs dan net as `filename` `Some` teruggee, en daarom is dit gevolglik onderworpe aan soortgelyke voorbehoude.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Wys die reëlnommer vir waar hierdie simbool tans uitgevoer word.
    ///
    /// Hierdie terugkeerwaarde is gewoonlik `Some` as `filename` `Some` oplewer, en is gevolglik onderworpe aan soortgelyke voorbehoude.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Wys die lêernaam waar hierdie funksie gedefinieer is.
    ///
    /// Dit is tans slegs beskikbaar wanneer libbacktrace of gimli gebruik word (bv
    /// unix ander platforms) en wanneer 'n binêre met debuginfo saamgestel word.
    /// As aan geen van hierdie voorwaardes voldoen word nie, sal dit waarskynlik `None` oplewer.
    ///
    /// # Vereiste funksies
    ///
    /// Hierdie funksie vereis dat die `std`-funksie van die `backtrace` crate geaktiveer is, en die `std`-funksie is standaard geaktiveer.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Miskien 'n ontleed C++ -simbool as die ontbrekende simbool as Rust nie kon ontleed nie.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Maak seker dat u hierdie grootte van nul hou, sodat die `cpp_demangle`-funksie geen koste het as dit gedeaktiveer is nie.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// 'N Omslag om 'n simboolnaam om ergonomiese toegang tot die ontmantelde naam, die rou grepe, die rou string, ens.
///
// Laat dead code toe vir wanneer die `cpp_demangle`-funksie nie geaktiveer is nie.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Skep 'n nuwe simboolnaam uit die rou onderliggende grepe.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Wys die rou (mangled)-simboolnaam as 'n `str` as die simbool geldig utf-8 is.
    ///
    /// Gebruik die `Display`-implementering as u die ontmantelde weergawe wil hê.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Wys die rou simboolnaam as 'n lys van grepe
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Dit kan afgedruk word as die ontmantelde simbool nie eintlik geldig is nie. Hanteer die fout hier grasieus deur dit nie na buite te propageer nie.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Probeer om die geheue in die geheue te gebruik om adresse te simboliseer.
///
/// Met hierdie metode word gepoog om enige globale datastrukture wat andersins wêreldwyd of in die draad geberg is, vry te stel wat gewoonlik ontleed-DWARF-inligting of soortgelyk voorstel.
///
///
/// # Caveats
///
/// Alhoewel hierdie funksie altyd beskikbaar is, doen dit eintlik niks op die meeste implementasies nie.
/// Biblioteke soos dbghelp of libbacktrace bied nie fasiliteite om die toestand te herlok en die toegewysde geheue te bestuur nie.
/// Op die oomblik is die `gimli-symbolize`-funksie van hierdie crate die enigste kenmerk waar hierdie funksie enige effek het.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}