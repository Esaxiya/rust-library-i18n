use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr neem 'n terugbel wat 'n dl_phdr_info-aanwyser ontvang vir elke DSO wat aan die proses gekoppel is.
    // dl_iterate_phdr verseker ook dat die dinamiese skakel van begin tot einde van die iterasie gesluit is.
    // As die terugbel 'n nie-nul-waarde gee, word die iterasie vroeg beëindig.
    // 'data' sal as die derde argument vir die terugbel by elke oproep oorgedra word.
    // 'size' gee die grootte van die dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Ons moet die bou-ID en 'n paar basiese programkopdata ontleed, wat beteken dat ons ook 'n bietjie dinge nodig het van die ELF-spesifikasie.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Nou moet ons die struktuur van die tipe dl_phdr_info wat deur die huidige dinamiese skakel van fuchsia gebruik word, bietjie vir bietjie herhaal.
// Chromium het ook hierdie ABI-grens sowel as crashpad.
// Uiteindelik wil ons hierdie sake skuif na die elf-search, maar ons moet dit in die SDK verskaf en dit is nog nie gedoen nie.
//
// Ons (en hulle) moet dus hierdie metode gebruik wat 'n noue koppeling met die fuchsia libc het.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Ons kan nie weet of e_phoff en e_phnum geldig is nie.
    // libc moet dit egter vir ons verseker, dus is dit veilig om 'n stuk hier te vorm.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr stel 'n 64-bis ELF-programkop voor in die einde van die teikenargitektuur.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr stel 'n geldige ELF-programkop en die inhoud daarvan voor.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Ons kan nie kyk of p_addr of p_memsz geldig is nie.
    // Fuchsia se libc ontleed die aantekeninge eers, maar op grond van die feit dat hulle hier is, moet hierdie opskrifte geldig wees.
    //
    // OpmerkingIter vereis nie dat die onderliggende data geldig is nie, maar wel dat die perke geldig moet wees.
    // Ons vertrou dat libc verseker het dat dit hier vir ons die geval is.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Die tipe noot vir build-ID's.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr stel 'n ELF-nootkop voor in die eindigheid van die teiken.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Noot stel 'n ELF-noot voor (kop + inhoud).
// Die naam word as 'n u8-stuk gelaat, want dit word nie altyd beëindig nie en rust maak dit maklik genoeg om te kontroleer of die grepe in elk geval ooreenstem.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// Met NoteIter kan u veilig oor 'n nootsegment herhaal.
// Dit eindig sodra 'n fout voorkom of daar nie meer notas is nie.
// As u oor ongeldige data herhaal, sal dit funksioneer asof geen aantekeninge gevind is nie.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Dit is 'n onveranderlike funksie dat die aangeduide wyser en grootte 'n geldige reeks grepe aandui wat almal gelees kan word.
    // Die inhoud van hierdie grepe kan alles behalwe wees, maar die reeks moet geldig wees om veilig te wees.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to pas 'x' op 'to'-byte-belyning uit, veronderstel dat 'to' 'n krag van 2 is.
// Dit volg op 'n standaardpatroon in C/C ++ ELF-ontledingskode waar (x + tot, 1) en -to gebruik word.
// Rust laat u nie toe om die gebruik te ontken nie, so ek gebruik dit
// 2-komplement-omskakeling om dit te herskep.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 verbruik aantal grepe uit die sny (indien teenwoordig) en verseker ook dat die finale sny behoorlik in lyn is.
// As óf die aantal bytes wat gevra word, te groot is, óf die plak daarna nie kan heraangesit word nie omdat daar nog nie genoeg bytes bestaan nie, word None teruggestuur en word die segment nie gewysig nie.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Hierdie funksie het geen werklike invariërs wat die oproeper moet handhaaf nie, behalwe dat 'bytes' in lyn moet wees vir prestasie (en volgens sommige korrektheid van die argitektuur).
// Die waardes in die Elf_Nhdr-velde is miskien onsin, maar hierdie funksie verseker nie so iets nie.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Dit is veilig, solank daar genoeg ruimte is en ons het net bevestig dat dit in die if-verklaring hierbo nie onveilig mag wees nie.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Let op dat sice_of: :<Elf_Nhdr>() is altyd 4-byte gerig.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Kyk of ons die einde bereik het.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Ons transformeer 'n nhdr maar kyk noukeurig na die gevolglike struktuur.
        // Ons vertrou nie die namesz of descsz nie en ons neem geen onveilige besluite op grond van die tipe nie.
        //
        // Dus, selfs as ons volledige vullis uittrek, moet ons steeds veilig wees.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Dui aan dat 'n segment uitvoerbaar is.
const PERM_X: u32 = 0b00000001;
/// Dui aan dat 'n segment skryfbaar is.
const PERM_W: u32 = 0b00000010;
/// Dui aan dat 'n segment leesbaar is.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Verteenwoordig 'n ELF-segment tydens looptyd.
struct Segment {
    /// Lewer die virtuele adres van die segment van die inhoud van hierdie segment.
    addr: usize,
    /// Gee die geheuegrootte van die inhoud van hierdie segment.
    size: usize,
    /// Gee die module virtuele adres van hierdie segment saam met die ELF-lêer.
    mod_rel_addr: usize,
    /// Verleen die regte wat in die ELF-lêer gevind word.
    /// Hierdie toestemmings is egter nie noodwendig die toestemmings wat tydens aanloop beskikbaar is nie.
    flags: Perm,
}

/// Laat een oor Segmente van 'n DSO herhaal.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Verteenwoordig 'n ELF DSO (Dynamic Shared Object).
/// Hierdie tipe verwys na die data wat in die werklike DSO gestoor is, eerder as om 'n eie kopie te maak.
struct Dso<'a> {
    /// Die dinamiese skakel gee ons altyd 'n naam, selfs al is die naam leeg.
    /// In die geval van die hoof uitvoerbare program sal hierdie naam leeg wees.
    /// In die geval van 'n gedeelde voorwerp is dit die naam (sien DT_SONAME).
    name: &'a str,
    /// Op Fuchsia het feitlik alle binaries ID's, maar dit is nie 'n streng vereiste nie.
    /// Daar is geen manier om daarna DSO-inligting met 'n regte ELF-lêer te laat ooreenstem as daar geen build_id is nie, dus benodig ons dat elke DSO een hier het.
    ///
    /// DSO's sonder 'n build-id word geïgnoreer.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Wys 'n iterator oor segmente in hierdie DSO.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Hierdie foute dekodeer probleme wat ontstaan tydens die ontleding van inligting oor elke DSO.
///
enum Error {
    /// NameError beteken dat daar 'n fout voorgekom het tydens die omskakeling van 'n C-styl string in 'n rust string.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError beteken dat ons geen bou-ID gevind het nie.
    /// Dit kan wees omdat die DSO geen bou-ID gehad het nie, of omdat die segment met die bou-ID verkeerd was.
    ///
    BuildIDError,
}

/// Bel 'dso' of 'error' vir elke DSO wat deur die dinamiese skakel aan die proses gekoppel is.
///
///
/// # Arguments
///
/// * `visitor` - 'N DsoPrinter met een van die eetmetodes wat genoem word vir elke DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr verseker dat info.name na 'n geldige plek sal wys.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Hierdie funksie druk die Fuchsia-simboliseerder op vir alle inligting in 'n DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}