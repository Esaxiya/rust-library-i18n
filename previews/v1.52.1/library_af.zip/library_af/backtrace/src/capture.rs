use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Voorstelling van 'n eie en selfstandige terugspoor.
///
/// Hierdie struktuur kan gebruik word om 'n terugspoor op verskillende punte in 'n program vas te lê en later te inspekteer wat die terugspoor destyds was.
///
///
/// `Backtrace` ondersteun mooi-druk van backtraces deur die `Debug`-implementering daarvan.
///
/// # Vereiste funksies
///
/// Hierdie funksie vereis dat die `std`-funksie van die `backtrace` crate geaktiveer is, en die `std`-funksie is standaard geaktiveer.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Rame hier word van bo tot onder in die stapel gelys
    frames: Vec<BacktraceFrame>,
    // Die indeks wat ons glo, is die werklike begin van die terugspoor, sonder om rame soos `Backtrace::new` en `backtrace::trace` uit te laat.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Vasgestelde weergawe van 'n raam in 'n terugspoor.
///
/// Hierdie tipe word as 'n lys van `Backtrace::frames` teruggestuur en verteenwoordig een stapelraam in 'n vasgestelde agterspoor.
///
/// # Vereiste funksies
///
/// Hierdie funksie vereis dat die `std`-funksie van die `backtrace` crate geaktiveer is, en die `std`-funksie is standaard geaktiveer.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Vaste weergawe van 'n simbool in 'n terugspoor.
///
/// Hierdie tipe word as 'n lys van `BacktraceFrame::symbols` teruggestuur en verteenwoordig die metadata vir 'n simbool in 'n terugspoor.
///
/// # Vereiste funksies
///
/// Hierdie funksie vereis dat die `std`-funksie van die `backtrace` crate geaktiveer is, en die `std`-funksie is standaard geaktiveer.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Neem 'n terugspoor op die oproepterrein van hierdie funksie en gee 'n verteenwoordiging in besit.
    ///
    /// Hierdie funksie is handig om 'n terugspoor as voorwerp in Rust voor te stel.Hierdie teruggestuurde waarde kan oor die drade gestuur word en elders gedruk word, en die doel van hierdie waarde is om heeltemal selfstandig te wees.
    ///
    /// Let op dat die verkryging van 'n volledige terugspoor op sommige platforms uiters duur kan wees.
    /// As die koste te veel vir u aansoek is, word dit aanbeveel om eerder `Backtrace::new_unresolved()` te gebruik, wat die stap van die simbooloplossing vermy (wat gewoonlik die langste duur) en dit moontlik maak om dit later uit te stel.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Vereiste funksies
    ///
    /// Hierdie funksie vereis dat die `std`-funksie van die `backtrace` crate geaktiveer is, en die `std`-funksie is standaard geaktiveer.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // wil seker maak dat hier 'n raam is om te verwyder
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Soortgelyk aan `new`, behalwe dat hierdie simbole nie opgelos word nie, word dit net die terugspoor opgevat as 'n lys van adresse.
    ///
    /// Op 'n later tydstip kan die `resolve`-funksie geroep word om die simbole van hierdie terugspoor in leesbare name op te los.
    /// Hierdie funksie bestaan omdat die resolusieproses soms baie tyd kan neem, terwyl enige terugspoor slegs selde gedruk kan word.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // geen simboolname nie
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // simboolname wat nou teenwoordig is
    /// ```
    ///
    /// # Vereiste funksies
    ///
    /// Hierdie funksie vereis dat die `std`-funksie van die `backtrace` crate geaktiveer is, en die `std`-funksie is standaard geaktiveer.
    ///
    ///
    ///
    #[inline(never)] // wil seker maak dat hier 'n raam is om te verwyder
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Wys die rame van toe hierdie terugspoor vasgelê is.
    ///
    /// Die eerste invoer van hierdie plak is waarskynlik die funksie `Backtrace::new`, en die laaste raam is waarskynlik iets oor hoe hierdie draad of die hooffunksie begin het.
    ///
    ///
    /// # Vereiste funksies
    ///
    /// Hierdie funksie vereis dat die `std`-funksie van die `backtrace` crate geaktiveer is, en die `std`-funksie is standaard geaktiveer.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// As hierdie terugspoor vanaf `new_unresolved` geskep is, sal hierdie funksie alle adresse in die terugspoor na hul simboliese name oplos.
    ///
    ///
    /// As hierdie terugspoor voorheen opgelos is of deur `new` geskep is, doen hierdie funksie niks.
    ///
    /// # Vereiste funksies
    ///
    /// Hierdie funksie vereis dat die `std`-funksie van die `backtrace` crate geaktiveer is, en die `std`-funksie is standaard geaktiveer.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Dieselfde as `Frame::ip`
    ///
    /// # Vereiste funksies
    ///
    /// Hierdie funksie vereis dat die `std`-funksie van die `backtrace` crate geaktiveer is, en die `std`-funksie is standaard geaktiveer.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Dieselfde as `Frame::symbol_address`
    ///
    /// # Vereiste funksies
    ///
    /// Hierdie funksie vereis dat die `std`-funksie van die `backtrace` crate geaktiveer is, en die `std`-funksie is standaard geaktiveer.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Dieselfde as `Frame::module_base_address`
    ///
    /// # Vereiste funksies
    ///
    /// Hierdie funksie vereis dat die `std`-funksie van die `backtrace` crate geaktiveer is, en die `std`-funksie is standaard geaktiveer.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Wys die lys simbole waarmee hierdie raam ooreenstem.
    ///
    /// Normaalweg is daar net een simbool per raam, maar soms, as 'n aantal funksies in een raamwerk toegevoeg word, word daar meer simbole teruggestuur.
    /// Die eerste gelysde simbool is die "innermost function", terwyl die laaste simbool die buitenste (laaste oproeper) is.
    ///
    /// Let daarop dat as hierdie raam afkomstig is van 'n onopgeloste terugspoor, dit 'n leë lys sal oplewer.
    ///
    /// # Vereiste funksies
    ///
    /// Hierdie funksie vereis dat die `std`-funksie van die `backtrace` crate geaktiveer is, en die `std`-funksie is standaard geaktiveer.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Dieselfde as `Symbol::name`
    ///
    /// # Vereiste funksies
    ///
    /// Hierdie funksie vereis dat die `std`-funksie van die `backtrace` crate geaktiveer is, en die `std`-funksie is standaard geaktiveer.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Dieselfde as `Symbol::addr`
    ///
    /// # Vereiste funksies
    ///
    /// Hierdie funksie vereis dat die `std`-funksie van die `backtrace` crate geaktiveer is, en die `std`-funksie is standaard geaktiveer.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Dieselfde as `Symbol::filename`
    ///
    /// # Vereiste funksies
    ///
    /// Hierdie funksie vereis dat die `std`-funksie van die `backtrace` crate geaktiveer is, en die `std`-funksie is standaard geaktiveer.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Dieselfde as `Symbol::lineno`
    ///
    /// # Vereiste funksies
    ///
    /// Hierdie funksie vereis dat die `std`-funksie van die `backtrace` crate geaktiveer is, en die `std`-funksie is standaard geaktiveer.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Dieselfde as `Symbol::colno`
    ///
    /// # Vereiste funksies
    ///
    /// Hierdie funksie vereis dat die `std`-funksie van die `backtrace` crate geaktiveer is, en die `std`-funksie is standaard geaktiveer.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // As u paaie afdruk, probeer ons die cwd te stroop as dit bestaan, anders druk ons die pad net soos dit is.
        // Let daarop dat ons dit ook net vir die kort formaat doen, want as dit vol is, wil ons vermoedelik alles druk.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}