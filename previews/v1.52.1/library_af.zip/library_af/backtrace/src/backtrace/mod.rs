use core::ffi::c_void;
use core::fmt;

/// Inspekteer die huidige oproepstapel en gee alle aktiewe rame in die beskikking om 'n stapelspoor te bereken.
///
/// Hierdie funksie is die werkesel van hierdie biblioteek om die stapelspore vir 'n program te bereken.Die gegewe sluiting `cb` is voorbeelde van 'n `Frame` wat inligting oor die oproepraam op die stapel voorstel.
/// Die sluiting word van bo-na onder-rame gelewer (die mees onlangse funksie word eers genoem).
///
/// Die terugkeerwaarde van die sluiting is 'n aanduiding of die terugspoor moet voortgaan.'N Terugkeerwaarde van `false` beëindig die terugspoor en keer onmiddellik terug.
///
/// Sodra 'n `Frame` aangeskaf is, sal u waarskynlik `backtrace::resolve` wil skakel om die `ip` (instruksiewyser) of simbooladres om te skakel na 'n `Symbol` waardeur die naam en/of lêernaam/reëlnommer geleer kan word.
///
///
/// Let daarop dat dit 'n relatief lae vlak is en dat u byvoorbeeld 'n terugspoor wil opneem om later te ondersoek, dan is die `Backtrace`-tipe meer geskik.
///
/// # Vereiste funksies
///
/// Hierdie funksie vereis dat die `std`-funksie van die `backtrace` crate geaktiveer is, en die `std`-funksie is standaard geaktiveer.
///
/// # Panics
///
/// Hierdie funksie streef daarna om nooit panic nie, maar as die `cb` panics verskaf, sal sommige platforms 'n dubbele panic dwing om die proses te staak.
/// Sommige platforms gebruik 'n C-biblioteek wat interne terugbels gebruik wat nie deurgedraai kan word nie, dus kan paniek vanaf `cb` 'n proses staak.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // gaan die terugspoor voort
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Dieselfde as `trace`, net onveilig aangesien dit nie gesinkroniseer is nie.
///
/// Hierdie funksie het nie sinkronisasie-waarborge nie, maar is beskikbaar as die `std`-funksie van hierdie crate nie saamgestel is nie.
/// Raadpleeg die `trace`-funksie vir meer dokumentasie en voorbeelde.
///
/// # Panics
///
/// Sien inligting op `trace` vir voorbehoud by `cb`-paniek.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// 'N trait wat een raam van 'n terugspoor voorstel, het toegegee aan die `trace`-funksie van hierdie crate.
///
/// Die sluiting van die opsporingsfunksie sal rame oplewer en die raamwerk word feitlik versend, aangesien die onderliggende implementering nie altyd bekend is gedurende die lopietyd nie.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Wys die huidige instruksiewyser van hierdie raam.
    ///
    /// Dit is normaalweg die volgende instruksie wat in die raamwerk uitgevoer moet word, maar nie alle implementasies bevat 'n 100% akkuraatheid nie (maar dit is oor die algemeen redelik naby).
    ///
    ///
    /// Dit word aanbeveel om hierdie waarde aan `backtrace::resolve` deur te gee om dit in 'n simboolnaam te verander.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Wys die huidige stapelwyser van hierdie raam.
    ///
    /// In die geval dat 'n backend nie die stapelwyser vir hierdie raam kan herstel nie, word 'n null-wyser teruggestuur.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Wys die beginsimbooladres van die raam van hierdie funksie.
    ///
    /// Dit sal probeer om die instruksiewyser wat deur `ip` teruggestuur is, terug te draai na die begin van die funksie, en sodoende die waarde terug te gee.
    ///
    /// In sommige gevalle sal agterstewes egter net `ip` vanaf hierdie funksie teruggee.
    ///
    /// Die teruggestuurde waarde kan soms gebruik word as `backtrace::resolve` misluk het op die `ip` hierbo gegee.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Wys die basisadres van die module waartoe die raam behoort.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Dit moet eerste kom om te verseker dat Miri voorkeur geniet bo die gasheerplatform
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // slegs gebruik in dbghelp simboliseer
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}