# backtrace-rs

[Documentation](https://docs.rs/backtrace)

'N Biblioteek vir die verkryging van terugspore tydens looptyd vir Rust.
Hierdie biblioteek is daarop gemik om die ondersteuning van die standaardbiblioteek te verbeter deur 'n programmatiese koppelvlak te bied om mee te werk, maar dit ondersteun ook eenvoudig om die huidige terugspoor soos Libstd se panics te druk.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Om eenvoudig 'n terugspoor vas te vang en dit later uit te stel, kan u die `Backtrace`-tipe op die hoogste vlak gebruik.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

As u egter meer rou toegang tot die werklike opsporingsfunksie wil hê, kan u die `trace`-en `resolve`-funksies direk gebruik.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Los hierdie aanwysingswyser op na 'n simboolnaam
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // gaan voort na die volgende raam
    });
}
```

# License

Hierdie projek is gelisensieer onder een van die twee

 * Apache-lisensie, weergawe 2.0, ([LICENSE-APACHE](LICENSE-APACHE) of http://www.apache.org/licenses/LICENSE-2.0)
 * MIT lisensie ([LICENSE-MIT](LICENSE-MIT) of http://opensource.org/licenses/MIT)

na u keuse.

### Contribution

Tensy u uitdruklik anders verklaar, sal 'n bydrae wat u doelbewus ingedien het vir opname in 'n terugsoek-rs, soos gedefinieer in die Apache-2.0-lisensie, dubbeld gelisensieer word soos hierbo, sonder enige bykomende bepalings of voorwaardes.







