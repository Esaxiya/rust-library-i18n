//! Windows SEH
//!
//! Op Windows (tans slegs op MSVC) is die verstekmeganisme vir uitsonderingshantering die Gestructureerde uitsonderingshantering (SEH).
//! Dit is heeltemal anders as die hantering van uitsonderings op Dwerg (byvoorbeeld wat ander unix-platforms gebruik) in terme van die samestelling van intern, dus daar word van LLVM verwag om heelwat ekstra ondersteuning vir SEH te hê.
//!
//! In 'n neutedop, wat hier gebeur, is:
//!
//! 1. Die `panic`-funksie noem die standaard Windows-funksie `_CxxThrowException` om 'n C++ -agtige uitsondering te gee, wat die afwikkelingsproses veroorsaak.
//! 2.
//! Alle landingskussings wat deur die samesteller gegenereer word, gebruik die persoonlikheidsfunksie `__CxxFrameHandler3`, 'n funksie in die CRT, en die afwikkelingskode in Windows sal hierdie persoonlikheidsfunksie gebruik om alle opruimingskode op die stapel uit te voer.
//!
//! 3. Alle oproepe wat deur samesteller gegenereer word na `invoke`, het 'n landingstrook as 'n `cleanuppad` LLVM-opdrag wat die begin van die opruimingsroetine aandui.
//! Die persoonlikheid (in stap 2, omskryf in die CRT) is verantwoordelik vir die opruimingsroetines.
//! 4. Uiteindelik word die "catch"-kode in die `try`-intrinsiek (gegenereer deur die samesteller) uitgevoer en dui aan dat die beheer na Rust moet terugkeer.
//! Dit word gedoen deur middel van 'n `catchswitch` plus 'n `catchpad`-instruksie in LLVM IR-terme, wat uiteindelik normale beheer met 'n `catchret`-instruksie na die program terugbring.
//!
//! Enkele spesifieke verskille van die gcc-gebaseerde uitsonderingshantering is:
//!
//! * Rust het geen persoonlike persoonlikheidsfunksie nie, maar is altyd *altyd*`__CxxFrameHandler3`.Daarbenewens word geen ekstra filter uitgevoer nie, en dus vang ons C++ -uitsonderings op wat lyk soos die soort wat ons gooi.
//! Let daarop dat dit in elk geval ongedefinieerde gedrag is om 'n uitsondering in Rust te gooi, dus dit moet goed wees.
//! * Ons het 'n paar data om oor die afgrensingsgrens te stuur, spesifiek 'n `Box<dyn Any + Send>`.Soos met Dwarf-uitsonderings, word hierdie twee wenke in die uitsondering self as 'n loonvrag gestoor.
//! Op MSVC is daar egter geen ekstra toewysing van hope nodig nie, want die oproepstapel word bewaar terwyl filterfunksies uitgevoer word.
//! Dit beteken dat die wysers direk na `_CxxThrowException` gestuur word, wat dan in die filterfunksie herwin word om na die stapelraam van die `try` intrinsiek te skryf.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Dit moet 'n opsie wees omdat ons die uitsondering opmerk deur verwysing en die vernietiger daarvan word uitgevoer deur die C++ runtime.
    // As ons die vak buite die uitsondering haal, moet ons die uitsondering in 'n geldige toestand laat sodat die vernietiger kan werk sonder om die vak dubbel te laat val.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Eerstens, 'n hele klomp tipe definisies.Hier is 'n paar platformspesifieke eienaardighede en baie wat net blatant van LLVM gekopieer word.Die doel van dit alles is om die onderstaande `panic`-funksie te implementeer deur 'n oproep na `_CxxThrowException`.
//
// Hierdie funksie neem twee argumente.Die eerste is 'n aanwyser na die gegewens wat ons deurgegee het, wat in hierdie geval ons trait-voorwerp is.Redelik maklik om te vind!Die volgende is egter ingewikkelder.
// Dit is 'n aanwyser vir 'n `_ThrowInfo`-struktuur, en is gewoonlik net bedoel om die uitsondering wat beskryf word, te beskryf.
//
// Tans is die definisie van hierdie tipe [1] 'n bietjie harig, en die belangrikste vreemdheid (en verskil van die aanlynartikel) is dat die wysers op 32-bit wysers is, maar op 64-bit word die wysers uitgedruk as 32-bit-verskuiwings vanaf die `__ImageBase` simbool.
//
// Die `ptr_t`-en `ptr!`-makro in die onderstaande modules word gebruik om dit uit te druk.
//
// Die doolhof van tipe definisies volg ook noukeurig wat LLVM vir hierdie soort bewerking uitstraal.As u byvoorbeeld hierdie C++ -kode op MSVC saamstel en die LLVM IR uitstraal:
//
//      #include <stdint.h>
//
//      struct roes_paniek {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      nietig foo() { rust_panic a = {0, 1};
//          gooi 'n;}
//
// Dit is eintlik wat ons probeer navolg.Die meeste van die konstante waardes hieronder is net vanaf LLVM gekopieër,
//
// In elk geval, hierdie strukture is almal op 'n soortgelyke manier gebou, en dit is vir ons net 'n bietjie uitgebreid.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Let daarop dat ons hier met opset nie die reëls vir naambemiddeling ignoreer nie: ons wil nie hê dat C++ Rust panics kan vang deur bloot 'n `struct rust_panic` te verklaar nie.
//
//
// As u wysig, moet u seker maak dat die tipe naamreeks presies ooreenstem met die wat in `compiler/rustc_codegen_llvm/src/intrinsic.rs` gebruik word.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Die toonaangewende `\x01`-byte hier is eintlik 'n magiese sein aan LLVM om *geen* ander mangels soos voorvoegsel met 'n `_`-karakter toe te pas nie.
    //
    //
    // Hierdie simbool is die tabel wat deur C++ se `std::type_info` gebruik word.
    // Voorwerpe van die tipe `std::type_info`, tipe beskrywers, het 'n wyser na hierdie tabel.
    // Tipe beskrywers word verwys deur die C++ EH strukture wat hierbo gedefinieer word en wat ons hieronder konstrueer.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Hierdie tipe beskrywer word slegs gebruik as u 'n uitsondering gooi.
// Die vanggedeelte word hanteer deur die try intrinsic, wat sy eie TypeDescriptor genereer.
//
// Dit is goed, aangesien die MSVC-runtime stringvergelyking op die tipe naam gebruik om ooreen te kom met TypeDescriptors eerder as die wyser gelykheid.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Vernietiger word gebruik as die C++ -kode besluit om die uitsondering vas te lê en te laat val sonder om dit te versprei.
// Die vanggedeelte van die probeer intrinsiek stel die eerste woord van die uitsonderingsvoorwerp op 0 sodat dit deur die vernietiger oorgeslaan word.
//
// Let daarop dat x86 Windows die "thiscall"-roepkonvensie gebruik vir C++ -lidfunksies in plaas van die standaard "C"-roepkonvensie.
//
// Die exception_copy-funksie is hier 'n bietjie spesiaal: dit word aangeroep deur die MSVC-runtime onder 'n try/catch-blok en die panic wat ons hier genereer, sal gebruik word as resultaat van die uitsonderingskopie.
//
// Dit word deur die C++ runtime gebruik om uitsonderings met std::exception_ptr vas te lê, wat ons nie kan ondersteun nie omdat Box<dyn Any>is nie kloonbaar nie.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException word volledig op hierdie stapelraamwerk uitgevoer, dus dit is nie nodig om `data` anders na die hoop oor te dra nie.
    // Ons gee net 'n stapelwyser na hierdie funksie.
    //
    // Die ManuallyDrop is hier nodig, want ons wil nie hê dat Uitsondering gedeponeer moet word nie.
    // In plaas daarvan word dit laat vaar deur exception_cleanup wat deur die C++ runtime ingeroep word.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Dit ... mag dalk verbasend lyk, en met reg.Op 32-bis MSVC is die aanwysings tussen hierdie struktuur net dit, aanwysings.
    // Op 64-bis MSVC word die aanwysings tussen strukture egter eerder uitgedruk as 32-bit offset van `__ImageBase`.
    //
    // Gevolglik kan ons op 32-bis MSVC al hierdie aanwysings in die 'statiese' hierbo verklaar.
    // Op 64-bis MSVC moet ons die aftrek van die aanwysers in die statika uitdruk, wat Rust tans nie toelaat nie, dus kan ons dit nie doen nie.
    //
    // Die volgende beste ding is dan om hierdie strukture tydens looptyd in te vul (paniek is in elk geval alreeds die "slow path").
    // Hier interpreteer ons al hierdie wyservelde weer as 32-bis heelgetalle en stoor dan die relevante waarde daarin (atomies, aangesien gelyktydige panics kan plaasvind).
    //
    // Tegnies sal die runtime waarskynlik nie-atomiese lees van hierdie velde doen, maar in teorie lees hulle nooit die *verkeerde* waarde nie, dus dit moet nie sleg wees nie ...
    //
    // In elk geval moet ons basies so iets doen totdat ons meer bewerkings in statics kan uitdruk (en ons sal dit miskien nooit kan nie).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // 'N NUL-loonvrag hier beteken dat ons hierheen is vanaf die vangs (...) van __rust_try.
    // Dit gebeur as 'n buitelandse uitsondering wat nie Rust is nie, betrap word.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Dit is nodig deur die samesteller om te bestaan (bv. Dit is 'n lang item), maar dit word nooit deur die samesteller genoem nie omdat __C_specific_handler of_except_handler3 die persoonlikheidsfunksie is wat altyd gebruik word.
//
// Daarom is dit net 'n abortusstomp.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}