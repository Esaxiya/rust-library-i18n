//! Ontwikkel panics vir Miri.
use alloc::boxed::Box;
use core::any::Any;

// Die soort loonvrag wat die Miri-enjin versprei deur vir ons af te rol.
// Moet wyser-grootte wees.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Miri-eksterne funksie om af te skakel.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Die loonvrag wat ons aan `miri_start_panic` deurgee, is presies die argument wat ons hieronder in `cleanup` kry.
    // Ons hou dit dus net een keer op om iets wyser te kry.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Herstel die onderliggende `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}