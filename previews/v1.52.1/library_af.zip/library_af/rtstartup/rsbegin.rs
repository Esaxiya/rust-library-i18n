// rsbegin.o en rsend.o is die sogenaamde "compiler runtime startup objects".
// Dit bevat die kode wat benodig word om die opsteltyd van die samesteller korrek te begin.
//
// As 'n uitvoerbare of dylib-prent gekoppel word, is alle gebruikerskode en biblioteke "sandwiched" tussen hierdie twee objeklêers, dus word kode of data van rsbegin.o eerste in die onderskeie dele van die prent, terwyl kode en data van rsend.o die laaste word.
// Hierdie effek kan gebruik word om simbole aan die begin of aan die einde van 'n gedeelte te plaas, sowel as om die nodige kop-of voettekste in te voeg.
//
// Let daarop dat die werklike module-ingangspunt in die C-opstartvoorwerp C (gewoonlik `crtX.o` genoem) geleë is, wat dan 'n terugroep van inisialisering van ander runtime-komponente oproep (geregistreer via nog 'n spesiale beeldafdeling).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Merk die begin van die stapelraam om die inligtingafdeling te ontspan
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Skraap ruimte vir die interne boekhouding van die afwikkelaar.
    // Dit word gedefinieer as `struct object` in $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Ontspan inligting registration/deregistration-roetines.
    // Kyk na die dokumente van libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // registreer ontspanningsinligting tydens die opstart van die module
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // registreer by afsluiting
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-spesifieke init/uninit-roetine-registrasie
    pub mod mingw_init {
        // MinGW se opstartvoorwerpe (crt0.o/dllcrt0.o) sal globale konstrukteurs in die .ctors-en .dtors-afdelings oproep tydens die opstart en uitgang.
        // In die geval van DLL's word dit gedoen wanneer die DLL gelaai en afgelaai word.
        //
        // Die linker sal die afdelings sorteer, wat verseker dat ons terugbel aan die einde van die lys geleë is.
        // Aangesien konstrukteurs in omgekeerde volgorde uitgevoer word, verseker dit dat ons die eerste en laaste uitgevoer word.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: Terugbels van C-inisialisering
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C beëindiging van die beëindiging
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}