//! Stuðningsbókasafn fyrir þjóðhöfunda við skilgreiningu nýrra fjölva.
//!
//! Þetta bókasafn, útvegað með stöðluðu dreifingu, veitir þær tegundir sem neytt er í viðmóti skilgreindra þjóðhagsskilgreininga á málsmeðferð eins og virka-eins og fjölva `#[proc_macro]`, þjóðareiginleika `#[proc_macro_attribute]` og sérsniðinna afleitaeigna " #[proc_macro_derive]`.
//!
//!
//! Sjá [the book] fyrir meira.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Ákvarðar hvort proc_macro hefur verið gert aðgengilegt fyrir það forrit sem nú er í gangi.
///
/// Proc_macro crate er aðeins ætlað til notkunar í framkvæmd málsmeðla fjölva.Allar aðgerðir í þessu crate panic ef kallað er utan frá málsmeðferðartæki, svo sem frá smíðahandriti eða einingaprófi eða venjulegu Rust tvöföldu.
///
/// Með hliðsjón af Rust bókasöfnum sem eru hönnuð til að styðja við bæði þjóðhagsleg og ekki þjóðhagsleg notkunartilvik veitir `proc_macro::is_available()` leið sem ekki er læti til að greina hvort uppbyggingin sem krafist er til að nota forritaskil proc_macro sé nú til staðar.
/// Skilar sönnu ef kölluð er að innan úr málsmeðferðarmakkó, röng ef kölluð er frá einhverju öðru tvöfaldri.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Helsta tegundin sem þessi crate býður upp á, táknar óhlutbundinn straum tokens, eða nánar tiltekið röð token trjáa.
/// Tegundin veitir viðmót til að endurtekna yfir þessi token tré og öfugt, safna fjölda token trjáa í einn straum.
///
///
/// Þetta er bæði inntak og úttak `#[proc_macro]`, `#[proc_macro_attribute]` og `#[proc_macro_derive]` skilgreiningar.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Villa kom frá `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Skilar auðu `TokenStream` sem inniheldur engin token tré.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Athugar hvort þessi `TokenStream` sé tómur.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Reynir að brjóta strenginn í tokens og flokka þá tokens í token straum.
/// Getur mistekist af ýmsum ástæðum, til dæmis ef strengurinn inniheldur ójafnvægi eða stafi sem ekki eru til á tungumálinu.
///
/// Allir tokens í þáttuðu straumnum fá `Span::call_site()` spann.
///
/// NOTE: sumar villur geta valdið panics í stað þess að skila `LexError`.Við áskiljum okkur rétt til að breyta þessum villum í " LexError` síðar.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, brúin veitir aðeins `to_string`, útfærðu `fmt::Display` byggt á henni (hið gagnstæða venjulega sambandsins á milli).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Prentar token strauminn sem streng sem á að vera taplaust breytanlegur aftur í sama token strauminn (modulo spann), nema hugsanlega 'TokenTree: : Group`s með `Delimiter::None` afmörkun og neikvæðum tölustöfum.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Prentar token á þægilegu formi til kembiforrit.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Býr til token straum sem inniheldur eitt token tré.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Safnar fjölda token trjáa í einn straum.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// "flattening" aðgerð á token lækjum, safnar token trjám úr mörgum token lækjum í einn straum.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Notaðu fínstillta útfærslu if/when mögulega.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Upplýsingar um opinberar framkvæmdir fyrir `TokenStream` gerðina, svo sem endurtekningar.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Ítórator yfir " TokenStream`er " TokenTree`s.
    /// Ítrekunin er "shallow", td endurtekningin fellur ekki niður í afmarkaða hópa og skilar heilum hópum sem token trjám.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` samþykkir handahófskennda tokens og stækkar í `TokenStream` sem lýsir inntakinu.
/// Til dæmis mun `quote!(a + b)` framleiða tjáningu sem, þegar hún er metin, smíðar `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Afpöntun er gerð með `$` og virkar með því að taka næsta næsta auðkenni sem ótilvitnað hugtak.
/// Til að vitna í `$` sjálft, notaðu `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Svæði frumkóða ásamt upplýsingum um stækkun þjóðhags.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Býr til nýjan `Diagnostic` með gefnu `message` á bilinu `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Spennu sem leysist á makróskilgreiningarsíðunni.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Spennan í ákalli núverandi málsmeðferðarmakro.
    /// Auðkenni sem búin eru til með þessu tímabili verður leyst eins og þau væru skrifuð beint á fjölsímastað (hreinlæti símtala) og annar kóði á fjölsímasíðunni getur einnig vísað til þeirra.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Spennu sem táknar `macro_rules` hreinlæti og leysist stundum á makró skilgreiningarsvæðinu (staðbundnar breytur, merkimiðar, `$crate`) og stundum á símtalasíðunni (allt annað).
    ///
    /// Spönnin er tekin af símtalinu.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Upprunalega heimildaskráin sem þetta spann bendir á.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span` fyrir tokens í fyrri fjölþenslu sem `self` var myndaður úr, ef einhver.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Tímabil upprunakóðans sem `self` var búið til úr.
    /// Ef þessi `Span` var ekki myndaður úr öðrum stækkunum þjóðhags, þá er skilagildið það sama og `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Fær upphafs line/column í upprunaskránni fyrir þetta tímabil.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Fær lok line/column í heimildaskránni fyrir þetta tímabil.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Býr til nýtt svið sem nær yfir `self` og `other`.
    ///
    /// Skilar `None` ef `self` og `other` eru úr mismunandi skrám.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Býr til nýtt span með sömu line/column upplýsingum og `self` en það leysir tákn eins og það væri í `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Býr til nýtt svið með sömu nafnaupplausnarhegðun og `self` en með line/column upplýsingum `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Samanborið við svið til að sjá hvort þeir séu jafnir.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Skilar frumtextanum á eftir sviðinu.
    /// Þetta varðveitir upprunalega kóðann, þar á meðal bil og athugasemdir.
    /// Það skilar eingöngu niðurstöðu ef sviðið samsvarar raunverulegum frumkóða.
    ///
    /// Note: Athuganleg niðurstaða fjölva ætti aðeins að reiða sig á tokens en ekki á þennan frumtexta.
    ///
    /// Niðurstaðan af þessari aðgerð er best að nota til greiningar.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Prentar svið á formi sem hentar til kembiforrit.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Línudálkapar sem táknar upphaf eða lok `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// 1-verðtryggða línan í upprunaskránni sem spannið byrjar eða endar (inclusive) á.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// 0-verðtryggði dálkurinn (í UTF-8 stöfum) í upprunaskránni sem spannið byrjar eða endar á (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Upprunaskrá tiltekins `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Fær leið að þessari heimildaskrá.
    ///
    /// ### Note
    /// Ef kóðasviðið sem tengt er þessum `SourceFile` var búið til af utanaðkomandi makró, þessu makró, þá er þetta kannski ekki raunveruleg leið á skráarkerfinu.
    /// Notaðu [`is_real`] til að athuga.
    ///
    /// Athugaðu einnig að jafnvel þó `is_real` skili `true`, ef `--remap-path-prefix` var framhjá skipanalínunni, þá gæti leiðin eins og hún er gefin ekki raunverulega gild.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Skilar `true` ef þessi heimildaskrá er raunveruleg heimildaskrá og ekki mynduð af stækkun utanaðkomandi fjölva.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Þetta er reiðhestur þangað til millidreifingarsvið eru útfærð og við getum haft raunverulegar heimildaskrár fyrir svið sem myndast í ytri fjölva.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Eitt token eða afmörkuð röð token trjáa (td `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// token straumur umkringdur sviga afmörkun.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Auðkenni.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Stakur greinarmerki (`+`, `,`, `$`, osfrv.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Bókstaflegur karakter (`'a'`), strengur (`"hello"`), tala (`2.3`) o.s.frv.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Skilar sviðinu á þessu tré, framseld til `span` aðferðar token eða afmarkaðs straums.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Stillir sviðið fyrir *aðeins þetta token*.
    ///
    /// Athugaðu að ef þetta token er `Group` þá mun þessi aðferð ekki stilla umfang hvers innri tokens, þetta mun einfaldlega framselja til `set_span` aðferðar hvers afbrigðis.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Prentar token tré á formi sem er þægilegt til villuleitar.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Hver þessara hefur nafnið í gerð gerð í afleiddu kembiforritinu, svo ekki nenna að auka lag af innleiðingu
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, brúin veitir aðeins `to_string`, útfærðu `fmt::Display` byggt á henni (hið gagnstæða venjulega sambandsins á milli).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Prentar token tréð sem streng sem á að vera taplaust breytanlegt aftur í sama token tré (modulo spann), nema hugsanlega " TokenTree: : Group`s með `Delimiter::None` afmörkun og neikvæðum tölustöfum.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Afmarkað token straumur.
///
/// `Group` inniheldur innra `TokenStream` sem er umkringdur 'afmörkun'.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Lýsir hvernig röð token trjáa er afmörkuð.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Óbein afmörkun, sem getur til dæmis komið fram í kringum tokens sem kemur frá "macro variable" `$var`.
    /// Það er mikilvægt að varðveita forgangsröð rekstraraðila í tilfellum eins og `$var * 3` þar sem `$var` er `1 + 2`.
    /// Óbein afmörkun gæti ekki lifað hringferð token straums um streng.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Býr til nýjan `Group` með tilgreindum afmörkun og token straumi.
    ///
    /// Þessi smiður mun stilla sviðið fyrir þennan hóp á `Span::call_site()`.
    /// Til að breyta umfanginu er hægt að nota `set_span` aðferðina hér að neðan.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Skilar afmörkun þessa `Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Skilar `TokenStream` af tokens sem eru afmarkaðir í þessum `Group`.
    ///
    /// Athugaðu að skilað token straumur inniheldur ekki afmörkunina sem skilað var hér að ofan.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Skilar sviðinu fyrir afmörkun þessa token streymis, sem spannar allan `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Skilar sviðinu sem vísar til upphafsafmörkunar þessa hóps.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Skilar sviðinu sem vísar til lokaafmörkunar þessa hóps.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Stillir sviðið fyrir afmörkun þessa " hóps` en ekki innri tokens.
    ///
    /// Þessi aðferð mun **ekki** stilla spönn allra innri tokens sem þessi hópur spannar, heldur mun hún aðeins stilla svið afmörkunar tokens á stigi `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, brúin veitir aðeins `to_string`, útfærðu `fmt::Display` byggt á henni (hið gagnstæða venjulega sambandsins á milli).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Prentar hópinn sem streng sem ætti að vera taplaust breytanlegur aftur í sama hóp (modulo spann), nema hugsanlega `TokenTree: : Group`s með `Delimiter::None` afmörkun.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` er ein greinarmerki eins og `+`, `-` eða `#`.
///
/// Margskipt stjórnendur eins og `+=` eru táknaðir sem tvö dæmi um `Punct` með mismunandi gerðum af `Spacing` skilað.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Hvort sem `Punct` fylgir strax eftir annar `Punct` eða fylgir annar token eða hvítt svæði.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// td, `+` er `Alone` í `+ =`, `+ident` eða `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// td, `+` er `Joint` í `+=` eða `'#`.
    /// Að auki getur eitt tilboð `'` tengst auðkennum og myndað ævilangt `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Býr til nýjan `Punct` úr gefnum karakter og bili.
    /// `ch` rökin verða að vera gild greinarmerki sem tungumálið leyfir, annars mun aðgerðin panic.
    ///
    /// `Punct` sem skilað er mun hafa sjálfgefið span `Span::call_site()` sem hægt er að stilla frekar með `set_span` aðferðinni hér að neðan.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Skilar gildi þessarar greinarmerks sem `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Skilar bilinu á þessum greinarmerkjum og gefur til kynna hvort það fylgi strax annar `Punct` í token straumnum, svo mögulega sé hægt að sameina þá í fjöl stafafyrirtæki (`Joint`), eða það fylgir einhverjum öðrum token eða hvítu rými (`Alone`) svo rekstraraðilinn hefur vissulega lauk.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Skilar sviðinu fyrir þessa greinarmerki.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Stilltu sviðið fyrir þessa greinarmerki.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, brúin veitir aðeins `to_string`, útfærðu `fmt::Display` byggt á henni (hið gagnstæða venjulega sambandsins á milli).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Prentar greinarmerki sem streng sem ætti að vera taplaust hægt að breyta aftur í sömu staf.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Auðkenni (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Býr til nýjan `Ident` með gefnu `string` sem og tilgreindum `span`.
    /// `string` rökin verða að vera gild auðkenni sem tungumálið leyfir (þ.m.t. leitarorð, td `self` eða `fn`).Annars mun aðgerðin panic.
    ///
    /// Athugaðu að `span`, sem nú er í rustc, stillir hreinlætisupplýsingar fyrir þetta auðkenni.
    ///
    /// Frá og með þessum tíma velur `Span::call_site()` beinlínis til hreinlætis "call-site" sem þýðir að auðkenni sem búið er til með þessu bili verður leyst eins og þau væru skrifuð beint á staðnum fyrir þjóðhringisímtalið og annar kóði á símhringjasíðunni mun geta vísað til þá líka.
    ///
    ///
    /// Seinna spönn eins og `Span::def_site()` gerir kleift að taka þátt í "definition-site" hreinlæti sem þýðir að auðkenni sem búið er til með þessu spennutímabili verður leyst á staðnum fyrir þjóðhagsskilgreininguna og annar kóði á símtalasíðunni getur ekki vísað til þeirra.
    ///
    /// Vegna núverandi mikilvægis hreinlætis krefst þessi smiður, ólíkt öðrum tokens, að `Span` sé tilgreindur við smíði.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Sama og `Ident::new`, en býr til hrár auðkenni (`r#ident`).
    /// `string` rökin eru gild auðkenni sem tungumálið leyfir (þ.m.t. leitarorð, td `fn`).
    /// Lykilorð sem eru nothæf í slóðahluta (td
    /// `self`, " frábær`) eru ekki studd og munu valda panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Skilar umfangi þessa `Ident` og nær yfir allan strenginn sem [`to_string`](Self::to_string) skilar.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Stillir umfang þessa `Ident` og hugsanlega breytt hreinlætissamhengi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, brúin veitir aðeins `to_string`, útfærðu `fmt::Display` byggt á henni (hið gagnstæða venjulega sambandsins á milli).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Prentar auðkennið sem streng sem ætti að vera taplaust hægt að breyta aftur í sama auðkenni.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Bókstaflegur strengur (`"hello"`), bæti strengur (`b"hello"`), stafur (`'a'`), bæti stafur (`b'a'`), heiltala eða flotpunktanúmer með eða án viðskeytis (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// Booleskir bókstafir eins og `true` og `false` eiga ekki heima hér, þeir eru `Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Býr til nýja viðskeyti heiltölu bókstaflega með tilgreindu gildi.
        ///
        /// Þessi aðgerð mun búa til heiltölu eins og `1u32` þar sem heiltölugildið sem tilgreint er er fyrsti hluti token og heildin er einnig viðskeyti í lokin.
        /// Bókstafir sem búnir eru til úr neikvæðum tölum lifa kannski ekki hringferðir í gegnum `TokenStream` eða strengi og þær geta verið brotnar niður í tvo tokens (`-` og jákvæða bókstaf).
        ///
        ///
        /// Bókmenntir sem eru búnar til með þessari aðferð hafa `Span::call_site()` sviðið sjálfgefið, sem hægt er að stilla með `set_span` aðferðinni hér að neðan.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Býr til nýja ótengda heiltölu bókstaflega með tilgreindu gildi.
        ///
        /// Þessi aðgerð mun búa til heiltölu eins og `1` þar sem heiltölugildið sem tilgreint er er fyrsti hluti token.
        /// Ekkert viðskeyti er tilgreint á þessu token, sem þýðir að ákall eins og `Literal::i8_unsuffixed(1)` jafngildir `Literal::u32_unsuffixed(1)`.
        /// Bókstafir sem búnir eru til úr neikvæðum tölum lifa kannski ekki rountrips í gegnum `TokenStream` eða strengi og geta verið brotnir í tvo tokens (`-` og jákvæða bókstaflega).
        ///
        ///
        /// Bókmenntir sem eru búnar til með þessari aðferð hafa `Span::call_site()` sviðið sjálfgefið, sem hægt er að stilla með `set_span` aðferðinni hér að neðan.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Býr til nýjan óbundinn flotpunkt bókstaflegan.
    ///
    /// Þessi smiður er svipaður þeim eins og `Literal::i8_unsuffixed` þar sem gildi flotans er sent beint út í token en ekkert viðskeyti er notað, svo það má álykta að það verði `f64` seinna í þýðandanum.
    ///
    /// Bókstafir sem búnir eru til úr neikvæðum tölum lifa kannski ekki rountrips í gegnum `TokenStream` eða strengi og geta verið brotnir í tvo tokens (`-` og jákvæða bókstaflega).
    ///
    /// # Panics
    ///
    /// Þessi aðgerð krefst þess að tilgreind flot sé endanleg, til dæmis ef það er óendanlegt eða NaN mun þessi aðgerð panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Býr til nýtt viðskeyti flotpunktur bókstaflega.
    ///
    /// Þessi smiður mun búa til bókstaflega eins og `1.0f32` þar sem gildið sem tilgreint er er fyrri hluti token og `f32` er viðskeyti token.
    /// Þessum token verður alltaf ráðið að vera `f32` í þýðandanum.
    /// Bókstafir sem búnir eru til úr neikvæðum tölum lifa kannski ekki rountrips í gegnum `TokenStream` eða strengi og geta verið brotnir í tvo tokens (`-` og jákvæða bókstaflega).
    ///
    ///
    /// # Panics
    ///
    /// Þessi aðgerð krefst þess að tilgreind flot sé endanleg, til dæmis ef það er óendanlegt eða NaN mun þessi aðgerð panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Býr til nýjan óbundinn flotpunkt bókstaflegan.
    ///
    /// Þessi smiður er svipaður þeim eins og `Literal::i8_unsuffixed` þar sem gildi flotans er sent beint út í token en ekkert viðskeyti er notað, svo það má álykta að það verði `f64` seinna í þýðandanum.
    ///
    /// Bókstafir sem búnir eru til úr neikvæðum tölum lifa kannski ekki rountrips í gegnum `TokenStream` eða strengi og geta verið brotnir í tvo tokens (`-` og jákvæða bókstaflega).
    ///
    /// # Panics
    ///
    /// Þessi aðgerð krefst þess að tilgreind flot sé endanleg, til dæmis ef það er óendanlegt eða NaN mun þessi aðgerð panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Býr til nýtt viðskeyti flotpunktur bókstaflega.
    ///
    /// Þessi smiður mun búa til bókstaflega eins og `1.0f64` þar sem gildið sem tilgreint er er fyrri hluti token og `f64` er viðskeyti token.
    /// Þessum token verður alltaf ráðið að vera `f64` í þýðandanum.
    /// Bókstafir sem búnir eru til úr neikvæðum tölum lifa kannski ekki rountrips í gegnum `TokenStream` eða strengi og geta verið brotnir í tvo tokens (`-` og jákvæða bókstaflega).
    ///
    ///
    /// # Panics
    ///
    /// Þessi aðgerð krefst þess að tilgreind flot sé endanleg, til dæmis ef það er óendanlegt eða NaN mun þessi aðgerð panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Strengur bókstaflegur.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Persóna bókstafleg.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Byte strengur bókstaflegur.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Skilar sviðinu sem nær yfir þessa bókstaflegu.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Stillir spennuna sem tengist þessari bókstaflegu.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Skilar `Span` sem er undirmengi `self.span()` sem inniheldur aðeins uppsprettubæti á bilinu `range`.
    /// Skilar `None` ef spennt spennusvið er utan marka `self`.
    ///
    // FIXME(SergioBenitez): gakktu úr skugga um að bætissviðið byrji og endi við UTF-8 mörk upprunans.
    // annars er líklegt að panic muni eiga sér stað annars staðar þegar frumtextinn er prentaður.
    // FIXME(SergioBenitez): það er engin leið fyrir notandann að vita hvað `self.span()` kortleggur í raun, svo að þessa aðferð er eins og er aðeins hægt að kalla í blindni.
    // Til dæmis, `to_string()` fyrir stafinn 'c' skilar "'\u{63}'";það er engin leið fyrir notandann að vita hvort frumtextinn var 'c' eða hvort hann var '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) eitthvað í ætt við `Option::cloned`, en fyrir `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, brúin veitir aðeins `to_string`, útfærðu `fmt::Display` byggt á henni (hið gagnstæða venjulega sambandsins á milli).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Prentar bókstafinn sem streng sem ætti að vera taplausan breytanlegan aftur í sömu bókstafinn (nema möguleg hringmyndun fyrir bókstafstrengi með fljótandi punktum).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Rakinn aðgangur að umhverfisbreytum.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Náðu í umhverfisbreytu og bættu henni við til að byggja upp ósjálfstæði.
    /// Byggja kerfi sem keyrir þýðandann mun vita að breytan var opnuð meðan á samsetningu stóð og mun geta endurbyggt bygginguna þegar gildi þeirrar breytu breytist.
    ///
    /// Að auki háð mælingu á þessu skal þessi aðgerð jafngilda `env::var` frá venjulegu bókasafninu, nema að rökin verða að vera UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}