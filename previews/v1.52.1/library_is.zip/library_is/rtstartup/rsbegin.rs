// rsbegin.o og rsend.o eru svokölluð "compiler runtime startup objects".
// Þeir innihalda kóða sem þarf til að frumstilla keyrslutíma þýðanda.
//
// Þegar keyranleg eða dylib mynd er tengd eru allir notendakóðar og bókasöfn "sandwiched" á milli þessara tveggja hlutaskrár, þannig að kóði eða gögn frá rsbegin.o verða fyrst í viðkomandi hlutum myndarinnar, en kóða og gögn frá rsend.o verða þau síðustu.
// Þessi áhrif er hægt að nota til að setja tákn í upphafi eða í lok kafla, svo og til að setja inn nauðsynlegan haus eða fót.
//
// Athugaðu að raunverulegur inngangsstaður einingarinnar er staðsettur í C ræsitíma hlut (venjulega kallaður `crtX.o`), sem kallar síðan á upphafsuppköllun á öðrum keyrsluþáttum (skráðir með enn einum sérstökum myndhluta).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Merkir upphaf stafla ramma slaka á upplýsingakafla
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Klóra pláss fyrir innri bókhaldsgögn.
    // Þetta er skilgreint sem `struct object` í $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Slakaðu á upplýsingum registration/deregistration venja.
    // Sjá skjöl libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // skráðu upplýsingar um slökun á gangi mát
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // afskrá þig við lokun
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-sérstök init/uninit venjubundin skráning
    pub mod mingw_init {
        // Upphafshlutir MinGW (crt0.o/dllcrt0.o) munu kalla til alþjóðlega smíði í .ctors og .dtors hlutunum við ræsingu og útgöngu.
        // Þegar um DLL er að ræða er þetta gert þegar DLL er hlaðið og losað.
        //
        // Hlekkurinn mun raða köflunum, sem tryggir að uppköllun okkar er staðsett í lok listans.
        // Þar sem smiðirnir eru keyrðir í öfugri röð tryggir þetta að hringtöl okkar eru fyrstu og síðustu framkvæmdar.
        //
        //

        #[link_section = ".ctors.65535"] // .skiltir. *: C upphafsstilla upphringingar
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: Uppköllun á uppsögn C
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}