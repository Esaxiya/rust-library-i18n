`core::arch` - Kjarni bókasafns arkitektúrsértækra Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch` einingin útfærir innri byggingarháðar (td SIMD).

# Usage 

`core::arch` er fáanlegur sem hluti af `libcore` og það er flutt út aftur af `libstd`.Helst að nota það í gegnum `core::arch` eða `std::arch` en í gegnum þetta crate.
Óstöðugir eiginleikar eru oft fáanlegir í Rust á nóttunni í gegnum `feature(stdsimd)`.

Að nota `core::arch` í gegnum þetta crate krefst Rust á kvöldin og það getur (og gerir) brotnað oft.Einu tilfellin þar sem þú ættir að íhuga að nota það í gegnum þetta crate eru:

* ef þú þarft að endurreisa `core::arch` sjálfur, td með sérstökum markaðgerðum virkum sem eru ekki virkir fyrir `libcore`/`libstd`.
Note: ef þú þarft að taka aftur saman fyrir óstöðluð skotmark, vinsamlegast notaðu `xargo` og settu aftur saman `libcore`/`libstd` eftir því sem við á í stað þess að nota þetta crate.
  
* með því að nota einhverja eiginleika sem gætu ekki verið í boði jafnvel á bak við óstöðuga Rust eiginleika.Við reynum að halda þessu í lágmarki.
Ef þú þarft að nota suma af þessum eiginleikum skaltu opna mál svo að við getum afhjúpað þá í Rust á kvöldin og þú getur notað þá þaðan.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` er aðallega dreift samkvæmt skilmálum bæði MIT leyfisins og Apache leyfisins (útgáfa 2.0), með hluta sem falla undir ýmis BSD-eins leyfi.

Sjá LICENSE-APACHE og LICENSE-MIT fyrir frekari upplýsingar.

# Contribution

Nema þú takir sérstaklega fram, skal framlag, sem þú hefur vísvitandi lagt fram til að vera með í `core_arch`, eins og það er skilgreint í Apache-2.0 leyfinu, vera með tvöfalt leyfi eins og að ofan, án frekari skilmála eða skilyrða.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












