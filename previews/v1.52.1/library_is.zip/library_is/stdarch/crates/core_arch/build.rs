use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Notað til að segja frá `#[assert_instr]` skýringum okkar um að öll innri eðlisfræði séu fáanleg til að prófa kóðaþáttinn sinn, þar sem sumir eru hliðaðir á bak við auka `-Ctarget-feature=+unimplemented-simd128` sem hefur ekki samsvarandi í `#[target_feature]` núna.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}