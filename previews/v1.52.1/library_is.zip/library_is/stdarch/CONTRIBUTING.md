# Stuðlar að stdarch

`stdarch` crate er meira en til í að taka við framlögum!Fyrst viltu líklega skoða geymsluna og ganga úr skugga um að próf standist fyrir þig:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Þar sem `<your-target-arch>` er markþrefaldið eins og það er notað af `rustup`, td `x86_x64-unknown-linux-gnu` (án nokkurra fyrri `nightly-` eða álíka).
Mundu líka að þessi geymsla krefst næturrásar Rust!
Ofangreindar prófanir krefjast þess í raun að rust á nóttunni sé sjálfgefið í kerfinu þínu, til að stilla notkun `rustup default nightly` (og `rustup default stable` til að snúa aftur).

Ef eitthvað af ofangreindum skrefum virkar ekki, [please let us know][new]!

Næst geturðu [find an issue][issues] til að hjálpa þér, við höfum valið nokkra með [`help wanted`][help] og [`impl-period`][impl] merkjum sem gætu sérstaklega notað einhverja hjálp. 
Þú gætir haft mestan áhuga á [#40][vendor], innleiðir alla innri seljanda á x86.Það mál hefur góð ábending um hvar á að byrja!

Ef þú hefur almennar spurningar skaltu ekki hika við að [join us on gitter][gitter] og spyrja um!Ekki hika við að pinga annað hvort@BurntSushi eða@alexcrichton með spurningum.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Hvernig á að skrifa dæmi um innri eðlisfræði

Það eru nokkrar aðgerðir sem verða að vera virkar til að viðkomandi innri virki rétt og dæmið verður aðeins að vera keyrt af `cargo test --doc` þegar aðgerðin er studd af örgjörvanum.

Fyrir vikið mun sjálfgefið `fn main` sem er búið til af `rustdoc` ekki virka (í flestum tilfellum).
Íhugaðu að nota eftirfarandi sem leiðbeiningar til að tryggja að dæmi þitt virki eins og búist var við.

```rust
/// # // Við þurfum cfg_target_feature til að tryggja að dæmið sé aðeins
/// # // keyrt af `cargo test --doc` þegar örgjörvinn styður aðgerðina
/// # #![feature(cfg_target_feature)]
/// # // Við þurfum target_feature til að innri virki
/// # #![feature(target_feature)]
/// #
/// # // Rustdoc notar sjálfgefið `extern crate stdarch`, en við þurfum
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // Raunveruleg aðalaðgerð
/// # fn main() {
/// #     // Keyrðu þetta aðeins ef `<target feature>` er studdur
/// #     ef cfg_feature_enabled! ("<target feature>"){
/// #         // Búðu til `worker` aðgerð sem verður aðeins keyrð ef miða lögun
/// #         // er studd og vertu viss um að `target_feature` sé virkt fyrir starfsmann þinn
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         óöruggur fn worker() {
/// // Skrifaðu dæmið þitt hér.Aðgerðir sértækra eiginleika munu virka hér!Vertu villtur!
///
/// #         }
///
/// #         óöruggur { worker(); }
/// #     }
/// # }
```

Ef sum ofangreind setningafræði lítur ekki út fyrir að vera kunnugleg lýsir [Documentation as tests] hluti [Rust Book] `rustdoc` setningafræði nokkuð vel.
Eins og alltaf, ekki hika við að [join us on gitter][gitter] og spyrja okkur hvort þú lendir í einhverjum hængum og þakka þér fyrir að hjálpa til við að bæta skjölun `stdarch`!

# Aðrar leiðbeiningar um prófanir

Almennt er mælt með því að þú notir `ci/run.sh` til að keyra prófin.
Hins vegar gæti þetta ekki virkað fyrir þig, td ef þú ert á Windows.

Í því tilfelli geturðu fallið aftur að því að keyra `cargo +nightly test` og `cargo +nightly test --release -p core_arch` til að prófa kóðagerðina.
Athugaðu að þetta þarf að setja upp verkfærakeðjuna á kvöldin og að `rustc` viti um þrefaldan miða og örgjörva hans.
Sérstaklega þarftu að stilla umhverfisbreytuna `TARGET` eins og þú myndir gera fyrir `ci/run.sh`.
Að auki þarftu að stilla `RUSTCFLAGS` (þarf `C`) til að gefa til kynna aðgerðir, t.d. `RUSTCFLAGS="-C -target-features=+avx2"`.
Þú getur líka stillt `-C -target-cpu=native` ef þú ert "just" að þróa á móti núverandi örgjörva.

Vertu varaður við því að þegar þú notar þessar aðrar leiðbeiningar, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], td
kennsluframleiðslupróf geta mistekist vegna þess að upplausnarmaðurinn nefndi þau á annan hátt, td
það getur búið til `vaesenc` í stað `aesenc` leiðbeininga þrátt fyrir að þeir hegði sér eins.
Þessar leiðbeiningar framkvæma einnig færri próf en venjulega væri gert, svo ekki vera hissa á því að þegar þú loks dregur-beiðni geta einhverjar villur komið fram við próf sem ekki er fjallað um hér.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






