# `rustc-std-workspace-std` crate

Sjá skjöl fyrir `rustc-std-workspace-core` crate.