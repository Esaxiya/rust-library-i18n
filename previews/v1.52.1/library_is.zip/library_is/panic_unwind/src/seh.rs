//! Windows SEH
//!
//! Á Windows (eins og er aðeins á MSVC) er sjálfgefið fyrirkomulag meðhöndlunar undantekninga Structured Exception Handling (SEH).
//! Þetta er allt öðruvísi en meðhöndlun undantekninga sem byggir á dvergum (td hvað aðrir unix pallar nota) hvað varðar innri þýðanda, svo LLVM er krafist þess að hafa heilmikinn aukastuðning við SEH.
//!
//! Í hnotskurn er það sem gerist hér:
//!
//! 1. `panic` aðgerð kallar venjulegu Windows aðgerðina `_CxxThrowException` til að henda C++ -eins og undantekningu, sem kallar á slökunarferlið.
//! 2.
//! Allir lendingarpúðar sem myndavélin býr til nota persónuleikaaðgerðina `__CxxFrameHandler3`, aðgerð í CRT og afpóðunarkóðinn í Windows mun nota þessa persónuleikaaðgerð til að framkvæma allan hreinsunarkóða í staflinum.
//!
//! 3. Í öllum símtölum sem eru myndaðar til `invoke` er lendingarbúnaður stilltur sem leiðbeining um `cleanuppad` LLVM, sem gefur til kynna upphaf hreinsunarferlisins.
//! Persónuleikinn (í skrefi 2, skilgreindur í CRT) ber ábyrgð á rekstri hreinsunarreglnanna.
//! 4. Að lokum er "catch" kóðinn í `try` innra (myndaður af þýðandanum) keyrður og gefur til kynna að stjórn ætti að koma aftur til Rust.
//! Þetta er gert með `catchswitch` auk `catchpad` leiðbeiningar í LLVM IR skilmálum, og loks skilar eðlileg stjórn á forritið með `catchret` leiðbeiningum.
//!
//! Nokkur sérstakur munur frá gcc-undantekningartilvikum er:
//!
//! * Rust hefur enga sérsniðna persónuleika, það er í staðinn *alltaf*`__CxxFrameHandler3`.Að auki er engin auka síun gerð, þannig að við náum í allar C++ undantekningar sem virðast líta út eins og þær tegundir sem við erum að henda.
//! Athugið að það að henda undantekningu í Rust er óskilgreind hegðun hvort eð er, svo þetta ætti að vera í lagi.
//! * Við höfum nokkur gögn til að senda yfir slökunarmörkin, sérstaklega `Box<dyn Any + Send>`.Eins og með Dwarf undantekningar eru þessar tvær vísbendingar geymdar sem farmur í undantekningunni sjálfri.
//! Á MSVC er hins vegar engin þörf á úthlutun hrúga því símtalastafli er varðveittur meðan síuaðgerðir eru framkvæmdar.
//! Þetta þýðir að ábendingarnar eru sendar beint á `_CxxThrowException` sem eru síðan endurheimtar í síuaðgerðinni til að skrifa í stafla ramma `try` innra.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Þetta þarf að vera valkostur vegna þess að við náum undantekningunni með tilvísun og eyðileggjandi hennar er keyrður af C++ keyrslutíma.
    // Þegar við tökum kassann utan undantekningarinnar, verðum við að láta undantekninguna vera í gildu ástandi til að eyðileggja hana án þess að tvöfalda kassann.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Í fyrsta lagi, fullt af tegundaskilgreiningum.Það eru nokkur einkennileg einkenni hér á vettvangi og margt sem er einfaldlega afritað af LLVM.Tilgangurinn með þessu öllu er að innleiða `panic` aðgerðina hér að neðan með símtali til `_CxxThrowException`.
//
// Þessi aðgerð tekur tvö rök.Sá fyrsti er bendill á gögnin sem við erum að senda í, sem í þessu tilfelli er trait hluturinn okkar.Nokkuð auðvelt að finna!Það næsta er þó flóknara.
// Þetta er vísir að `_ThrowInfo` uppbyggingu og er almennt bara ætlað að lýsa undantekningunni sem kastað er.
//
// Eins og er er skilgreiningin á þessari gerð [1] svolítið loðin og aðal einkennið (og munurinn frá greininni á netinu) er að á 32-bita eru ábendingar vísbendingar en á 64-bita eru bendin gefin upp sem 32-bita móti frá `__ImageBase` tákn.
//
// `ptr_t` og `ptr!` fjölvi í einingum hér að neðan eru notaðir til að tjá þetta.
//
// Völundarhús tegundarskilgreininga fylgir einnig náið því sem LLVM gefur frá sér fyrir þessa tegund aðgerða.Til dæmis, ef þú tekur saman þennan C++ kóða á MSVC og sendir frá þér LLVM IR:
//
//      #include <stdint.h>
//
//      struct ryðrænt {panic
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      ógilt foo() { rust_panic a = {0, 1};
//          kasta a;}
//
// Það er í raun það sem við erum að reyna að líkja eftir.Flest stöðugu gildin hér að neðan voru bara afrituð úr LLVM,
//
// Í öllum tilvikum eru þessi mannvirki öll smíðuð á svipaðan hátt og það er bara nokkuð orðrétt fyrir okkur.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Athugaðu að við hunsum viljandi reglur um nafngiftir hér: við viljum ekki að C++ geti náð Rust panics með því einfaldlega að lýsa yfir `struct rust_panic`.
//
//
// Þegar þú ert að breyta skaltu ganga úr skugga um að tegundarheiti strengurinn passi nákvæmlega við þann sem notaður er í `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Leiðandi `\x01` bæti hér er í raun töfrandi merki til LLVM um að *ekki* beita neinum öðrum manglingum eins og forskeyti með `_` staf.
    //
    //
    // Þetta tákn er töflan sem notuð er af `std::type_info` C++ .
    // Hlutir af gerðinni `std::type_info`, tegundarlýsingar, hafa vísir að þessari töflu.
    // Tegundalýsendur eru vísaðir til með C++ EH mannvirkjum sem skilgreind eru hér að ofan og sem við smíðuðum hér að neðan.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Þessi tegund lýsingar er aðeins notaður þegar undantekning er hent.
// Aflahlutinn er meðhöndlaður af try intrinsic, sem býr til sinn eigin TypeDescriptor.
//
// Þetta er fínt þar sem MSVC keyrslutími notar strengjasamanburð á heiti gerðarinnar til að passa við TypeDescriptors frekar en jafnrétti bendla.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destructor notað ef C++ kóðinn ákveður að fanga undantekninguna og sleppa henni án þess að fjölga henni.
// Grípahluti innri prufunnar mun setja fyrsta orðið undantekningarhlutarins á 0 þannig að eyðileggjandanum sleppir því.
//
// Athugaðu að x86 Windows notar "thiscall" starfssamninginn fyrir C++ meðlimaaðgerðir í stað sjálfgefinna "C" starfssamninga.
//
// Aðgerðin exception_copy er svolítið sérstök hér: hún er kölluð fram af MSVC keyrslutíma undir try/catch blokk og panic sem við myndum hér verður notaður sem afleiðing af undantekningartakritinu.
//
// Þetta er notað af C++ keyrslutíma til að styðja við að ná undantekningum með std::exception_ptr, sem við getum ekki stutt vegna Box<dyn Any>er ekki klónanlegt.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException keyrir að öllu leyti á þessum stafla ramma, svo það er engin þörf á að flytja `data` annars í hrúguna.
    // Við sendum bara stafla bendi á þessa aðgerð.
    //
    // Hér þarf ManuallyDrop þar sem við viljum ekki að undantekning verði látin falla niður.
    // Þess í stað verður það sleppt með exception_cleanup sem kallað er á C++ keyrslutíma.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Þetta ... kann að virðast koma á óvart og með réttu.Á 32-bita MSVC eru ábendingar á milli þessarar uppbyggingar einmitt þær, ábendingar.
    // Á 64-bita MSVC eru vísbendingar milli mannvirkja þó frekar gefnar upp sem 32-bita móti frá `__ImageBase`.
    //
    // Þess vegna getum við á 32-bita MSVC lýst yfir öllum þessum ábendingum í " truflunum` hér að ofan.
    // Á 64-bita MSVC þyrftum við að tjá ábendingu í kyrrstöðu, sem Rust leyfir ekki eins og er, svo við getum í raun ekki gert það.
    //
    // Næstbesti hluturinn er þá að fylla út þessar mannvirki á keyrslutíma (læti er nú þegar "slow path" samt).
    // Svo hér túlkum við alla þessa bendisreiti sem 32-bita heiltölur og geymum síðan gildið inn í það (í lotukerfinu, þar sem samhliða panics getur verið að gerast).
    //
    // Tæknilega mun keyrslutíminn líklega lesa óeðlisfræðilega af þessum sviðum, en í orði lesa þeir aldrei *rangt* gildi svo það ætti ekki að vera of slæmt ...
    //
    // Í öllum tilvikum þurfum við í grundvallaratriðum að gera eitthvað slíkt þangað til við getum tjáð meiri aðgerðir með kyrrstöðu (og við getum kannski aldrei gert það).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // NÚLL farmur þýðir að við komumst hingað úr (...) af __rust_try.
    // Þetta gerist þegar erlend undantekning er utan Rust.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Þetta er krafist af þýðandanum til að vera til (td það er lang hlutur), en það er aldrei kallað af þýðandanum vegna þess að __C_specific_handler eða_except_handler3 er persónuleikafallið sem alltaf er notað.
//
// Þess vegna er þetta bara fóstureyðing.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}