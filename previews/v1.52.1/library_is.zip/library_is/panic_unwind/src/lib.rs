//! Framkvæmd panics með því að vinda ofan af stafla
//!
//! Þetta crate er útfærsla á panics í Rust með því að nota "most native" stafla til að vinda ofan af pallinum sem þetta er unnið fyrir.
//! Þetta er í raun flokkað í þrjár fötur eins og er:
//!
//! 1. MSVC skotmörk nota SEH í `seh.rs` skránni.
//! 2. Emscripten notar C++ undantekningar í `emcc.rs` skránni.
//! 3. Öll önnur skotmörk nota libunwind/libgcc í `gcc.rs` skránni.
//!
//! Nánari skjöl um hverja útfærslu er að finna í viðkomandi einingu.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` er ónotaður með Miri, svo þögn viðvaranir.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Uppsetningarhlutir Rust keyrslutíma eru háðir þessum táknum, svo gerðu þá opinbera.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Markmið sem styðja ekki slökun.
        // - arch=wasm32
        // - os=ekkert ("bare metal" skotmörk)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Notaðu keyrslutíma Miri.
        // Við verðum samt að hlaða venjulegum keyrslutíma hér að ofan, þar sem rustc gerir ráð fyrir að ákveðin lang atriði þaðan verði skilgreind.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Notaðu raunverulegan keyrslutíma.
        use real_imp as imp;
    }
}

extern "C" {
    /// Meðhöndlari í libstd hringdi þegar panic hlutur er látinn falla fyrir utan `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Meðhöndlari í libstd hringdi þegar erlend undantekning er veidd.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Aðgangsstaður til að vekja upp undantekningu, bara sendifulltrúar í framkvæmd pallsins.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}