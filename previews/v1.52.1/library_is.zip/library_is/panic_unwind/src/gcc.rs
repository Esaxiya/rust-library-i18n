//! Framkvæmd panics studd af libgcc/libunwind (í einhverri mynd).
//!
//! Fyrir bakgrunn um undantekningarmeðhöndlun og staflaafslátt, sjá "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) og skjöl sem tengd eru frá honum.
//! Þetta eru líka góð les:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## Stutt samantekt
//!
//! Undantekning meðhöndlun gerist í tveimur áföngum: leitarstig og hreinsunarstig.
//!
//! Í báðum áföngum gengur afpakkinn stafla ramma frá toppi til botns með því að nota upplýsingar úr stafla ramma til að vinda ofan af einingum núverandi ferils ("module" vísar hér til OS-einingar, þ.e. keyrslu eða öflugs bókasafns).
//!
//!
//! Fyrir hvern stafla ramma kallar það tilheyrandi "personality routine", en heimilisfang hans er einnig geymt í hlutanum til að slaka á.
//!
//! Í leitarstiginu er hlutverk persónuleikarútins að kanna undantekningarhlut sem kastað er og ákveða hvort það eigi að grípa í staflarammann.Þegar búið er að bera kennsl á umgjörðaraðila hefst hreinsunarstig.
//!
//! Í hreinsunarstiginu kallar aflindin aftur fram hverja persónuleika.
//! Að þessu sinni ákveður það hvaða (ef einhver) hreinsunarkóða þarf að keyra fyrir núverandi stafla ramma.Ef svo er færist stjórnin yfir á sérstaka branch í aðgerðalíkamanum, "landing pad", sem kallar á eyðileggjendur, losar um minni o.s.frv.
//! Í lok lendingarpallsins er stjórnin færð aftur í vinduna og afléttingin hefst á ný.
//!
//! Þegar búið er að vinda upp stafla niður á rammastig meðhöndlara stöðvast aflétting og síðasta persónuleikaferðin færir stjórn á aflablokk.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Auðkenningarflokkur auðkennis Rust.
// Þetta er notað af venjubundnum persónuleika til að ákvarða hvort undantekningin hafi verið hent vegna eigin keyrslutíma þeirra.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-söluaðili, tungumál
    0x4d4f5a_00_52555354
}

// Skráarauðkennum var aflétt af TargetLowering::getExceptionPointerRegister() og TargetLowering::getExceptionSelectorRegister() LLVM fyrir hvern arkitektúr og síðan kortlagt í DWARF-skráarnúmer með skilgreiningartöflum (venjulega<arch>RegisterInfo.td, leitaðu að "DwarfRegNum").
//
// Sjá einnig http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// Eftirfarandi kóði er byggður á C og C++ persónuleikum GCC.Til hliðsjónar, sjá:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM EHABI persónuleika venja.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS notar sjálfgefna rútínu í staðinn þar sem hún notar SjLj afplánun.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // Bakslag á ARM mun kalla persónuleiðina með ástandinu==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // Í þeim tilfellum viljum við halda áfram að vinda ofan af staflinum, annars myndu öll bakspor okkar enda á __rust_try
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // DWARF afnámsins gerir ráð fyrir að _Unwind_Context geymi hluti eins og aðgerðina og LSDA vísbendingar, þó að ARM EHABI setji þá í undantekningarhlutinn.
            // Til að varðveita undirskriftir aðgerða eins og _Unwind_GetLanguageSpecificData(), sem taka aðeins samhengisbendilinn, setja GCC persónuleiðir vísir til undantekninga_object í samhenginu, með því að nota staðsetningu áskilin fyrir "scratch register" (r12) frá ARM.
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... A meginreglulegri nálgun væri að veita fulla skilgreiningu á _Unwind_Context ARM í libunwind bindingum okkar og sækja nauðsynleg gögn þaðan beint, framhjá DWARF samhæfðaraðgerðum.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI krefst persónulegrar venju til að uppfæra SP gildi í hindrunarskyndiminni undantekninga hlutarins.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // Í ARM EHABI er persónuleikarútgáfan ábyrg fyrir því að vinda ofan af einum stafla ramma áður en hann snýr aftur (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // skilgreint í libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // Sjálfgefin persónuleika venja, sem er notuð beint á flest skotmörk og óbeint á Windows x86_64 um SEH.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // Á x86_64 MinGW skotmörkum er slökunarbúnaðurinn SEH en gögn um afgreiðsluhöndlun (aka LSDA) nota GCC-samhæfða kóðun.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // Persónuleiðin fyrir flest markmið okkar.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // Heimilisfangið bendir 1 bæti framhjá símtalaleiðbeiningunni, sem gæti verið á næsta IP svið í LSDA sviðstöflu.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// Rammaðu niður skráningu upplýsinga
//
// Mynd hverrar einingar inniheldur upplýsingahluta ramma til að vinda ofan af (venjulega ".eh_frame").Þegar eining er loaded/unloaded í ferlinu, verður að upplýsa afvikarann um staðsetningu þessa kafla í minni.Aðferðirnar til að ná fram eru mismunandi eftir vettvangi.
// Á sumum (td Linux) getur afvikarinn uppgötvað aflíðandi upplýsingahluta á eigin spýtur (með því að telja upp virkar einingar sem nú eru hlaðnar í gegnum dl_iterate_phdr() API and finding their ".eh_frame" sections); aðrir, eins og Windows, þurfa einingar til að skrá virkan hlutana sína til að vinda upp í gegnum API.
//
//
// Þessi eining skilgreinir tvö tákn sem vísað er til og kallað frá rsbegin.rs til að skrá upplýsingar okkar með GCC keyrslutíma.
// Framkvæmd staflaafsláttar er (í bili) frestað til libgcc_eh, þó nota Rust crates þessa Rust-sérstöku inngangsstaði til að forðast mögulega árekstur við hvaða GCC keyrslutíma.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}