//! Að vinda upp panics fyrir Miri.
use alloc::boxed::Box;
use core::any::Any;

// Tegundin af farminum sem Miri vélin breiðir út með því að vinda ofan af fyrir okkur.
// Verður að vera með bendilstærð.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Miri-kveðið utanaðkomandi aðgerð til að byrja að vinda ofan af.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Notunarálagið sem við sendum til `miri_start_panic` verður nákvæmlega rökin sem við fáum í `cleanup` hér að neðan.
    // Svo við kassum það bara upp einu sinni, til að fá eitthvað bendistærð.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Batna undirliggjandi `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}