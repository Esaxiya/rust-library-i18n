# `rustc-std-workspace-core` crate

Þetta crate er shim og tómt crate sem er einfaldlega háð `libcore` og endurútflutur allt innihald þess.
crate er kjarni þess að styrkja venjulega bókasafnið til að vera háð crates frá crates.io

Crates á crates.io sem venjulegt bókasafn er háð þarf að vera háð `rustc-std-workspace-core` crate frá crates.io, sem er autt.

Við notum `[patch]` til að hnekkja því við þetta crate í þessari geymslu.
Fyrir vikið mun crates á crates.io draga ósjálfstæði edge til `libcore`, útgáfan sem skilgreind er í þessari geymslu.
Það ætti að draga alla ósjálfstæðu brúnir til að tryggja að Cargo byggi crates með góðum árangri!

Athugaðu að crates á crates.io þarf að vera háð þessu crate með nafninu `core` til að allt vinni rétt.Til að gera það geta þeir notað:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Með því að nota `package` lykilinn er crate endurnefnt í `core`, sem þýðir að það mun líta út eins og

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

þegar Cargo kallar á þýðandann og fullnægir óbeinu `extern crate core` tilskipuninni sem þýðandinn hefur sprautað.




