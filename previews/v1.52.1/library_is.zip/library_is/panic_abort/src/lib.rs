//! Framkvæmd Rust panics í gegnum ferlið
//!
//! Þegar miðað er við framkvæmdina með því að vinda ofan af er þetta crate *miklu* einfaldara!Sem sagt, það er ekki alveg eins fjölhæft, en hér fer!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" álagið og shimið við viðkomandi fóstureyðingu á umræddum palli.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // hringdu í std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Notaðu örgjörva-sérstakt __fastfail kerfi á Windows.Í Windows 8 og síðar mun þessu ljúka ferlinu strax án þess að keyra neina undantekningaraðila í vinnslu.
            // Í fyrri útgáfum af Windows verður farið með þessa röð leiðbeininga sem aðgangsbrot, með því að ljúka ferlinu en án þess að fara framhjá öllum undantekningartækjum.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: þetta er sama útfærsla og í `abort_internal` hjá libstd
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Þetta ... er dálítið einkennilegt.The tl; dr;er að þetta sé krafist til að tengja rétt, lengri skýringin er hér að neðan.
//
// Núna eru tvíþættir libcore/libstd sem við sendum allir saman með `-C panic=unwind`.Þetta er gert til að tryggja að tvíundirnar séu sem mest samhæfar við eins margar aðstæður og mögulegt er.
// Þýðandinn þarf hins vegar "personality function" fyrir allar aðgerðir sem teknar eru saman með `-C panic=unwind`.Þessi persónuleikaaðgerð er harðkóðuð í táknið `rust_eh_personality` og er skilgreint með `eh_personality` lang hlutnum.
//
// So...
// af hverju skilgreinirðu ekki bara langan hlutinn hér?Góð spurning!Leiðin sem panic keyrslutími er tengdur við er í raun svolítið lúmskur að því leyti að þeir eru "sort of" í crate verslun þýðandans, en aðeins raunverulega tengdir ef annar er ekki raunverulega tengdur.
//
// Þetta endar með því að þýða að bæði þetta crate og panic_unwind crate geta birst í crate verslun þýðandans, og ef báðir skilgreina `eh_personality` lang hlutinn þá lendir það í villu.
//
// Til að takast á við þetta þarf þýðandinn aðeins að `eh_personality` sé skilgreindur ef panic keyrslutími sem tengdur er er aflotningartíminn og annars er ekki krafist að hann sé skilgreindur (með réttu).
// Í þessu tilfelli skilgreinir þetta bókasafn þó bara þetta tákn svo það er að minnsta kosti einhver persónuleiki einhvers staðar.
//
// Í grundvallaratriðum er þetta tákn aðeins skilgreint til að tengja allt að libcore/libstd tvíundir, en það ætti aldrei að kalla það þar sem við tengjum ekki saman í afplánunartíma.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // Á x86_64-pc-windows-gnu notum við okkar eigin persónuleikaaðgerð sem þarf að skila `ExceptionContinueSearch` þegar við erum að senda alla ramma okkar áfram.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Svipað og hér að ofan, samsvarar þetta `eh_catch_typeinfo` lang atriðinu sem er aðeins notað á Emscripten eins og er.
    //
    // Þar sem panics býr ekki til undantekningar og erlendar undantekningar eru nú UB með -C panic=brottfall (þó að þetta geti breyst), munu allir catch_unwind símtöl aldrei nota þessa tegund upplýsingar.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Þessir tveir eru kallaðir af start hlutum okkar á i686-pc-windows-gnu, en þeir þurfa ekki að gera neitt svo líkin eru nops.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}