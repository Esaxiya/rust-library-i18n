//! Mát til að aðstoða við stjórnun dbghelp bindinga á Windows
//!
//! Bakslag á Windows (að minnsta kosti fyrir MSVC) er að mestu leyti knúið í gegnum `dbghelp.dll` og ýmsar aðgerðir sem það inniheldur.
//! Þessar aðgerðir eru eins og er hlaðnar *kraftmiklar* frekar en að tengjast `dbghelp.dll` á statískan hátt.
//! Þetta er nú gert af venjulegu bókasafninu (og er fræðilega krafist þar), en er viðleitni til að draga úr kyrrstöðu dll ósjálfstæði bókasafns þar sem bakslag er venjulega frekar valfrjálst.
//!
//! Sem sagt, `dbghelp.dll` hlaðast næstum alltaf vel á Windows.
//!
//! Athugaðu þó að þar sem við erum að hlaða allan þennan stuðning á virkan hátt getum við í raun ekki notað hráar skilgreiningar í `winapi`, heldur verðum við að skilgreina tegundir aðgerðar bendilsins sjálfar og nota það.
//! Við viljum í raun ekki vera í því að afrita winapi, þannig að við höfum Cargo lögun `verify-winapi` sem fullyrðir að allar bindingar passi við þær sem eru í winapi og þessi eiginleiki er virkur á CI.
//!
//! Að lokum, þú munt taka eftir hér að dll fyrir `dbghelp.dll` er aldrei affermt og það er eins og er viljandi.
//! Hugsunin er sú að við getum skyndiminni það á heimsvísu og notað það á milli símtala í API og forðast dýr loads/unloads.
//! Ef þetta er vandamál fyrir lekaskynjara eða eitthvað slíkt getum við farið yfir brúna þegar við komum þangað.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Vinna í kringum `SymGetOptions` og `SymSetOptions` að vera ekki til staðar í winapi sjálfum.
// Annars er þetta aðeins notað þegar við erum að tvöfalda tegundir gegn winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Ekki skilgreint í winapi ennþá
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Þetta er skilgreint í winapi, en það er rangt (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Ekki skilgreint í winapi ennþá
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Þetta fjölvi er notað til að skilgreina `Dbghelp` uppbyggingu sem inniheldur innri allar aðgerðirnar sem við gætum hlaðið.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// The hlaðinn DLL fyrir `dbghelp.dll`
            dll: HMODULE,

            // Hver aðgerðabendill fyrir hverja aðgerð sem við gætum notað
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Upphaflega höfum við ekki hlaðið DLL
            dll: 0 as *mut _,
            // Byrjaðu á að allar aðgerðir séu stilltar á núll til að segja að það þurfi að hlaða þær kraftmikið.
            //
            $($name: 0,)*
        };

        // Þægindi typedef fyrir hverja aðgerðategund.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Tilraunir til að opna `dbghelp.dll`.
            /// Skilar árangri ef það virkar eða villa ef `LoadLibraryW` mistakast.
            ///
            /// Panics ef bókasafn er þegar hlaðið.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Virka fyrir hverja aðferð sem við viljum nota.
            // Þegar það er kallað mun það annaðhvort lesa bendilinn fyrir skyndiminni eða hlaða honum og skila hlaðnu gildi.
            // Fullyrt er að árangur náist.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Þægindi umboð til að nota hreinsunarlásana til að vísa til aðgerða dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Byrjaðu á öllum stuðningi sem nauðsynlegur er til að fá aðgang að `dbghelp` API aðgerðum frá þessu crate.
///
///
/// Athugið að þessi aðgerð er **örugg**, hún hefur innri samstillingu sína að innan.
/// Athugaðu einnig að það er óhætt að hringja í þessa aðgerð margfalt endurkvæmanlega.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Það fyrsta sem við þurfum að gera er að samstilla þessa aðgerð.Þetta er hægt að kalla samtímis frá öðrum þráðum eða endurtekið innan eins þráðar.
        // Athugið að það er erfiðara en það vegna þess að það sem við erum að nota hér, `dbghelp`, * þarf líka að samstilla við alla aðra sem hringja í `dbghelp` í þessu ferli.
        //
        // Venjulega eru ekki eins mörg símtöl til `dbghelp` innan sama ferils og við getum líklega áreiðanlega gengið út frá því að við séum einir að fá aðgang að því.
        // Það er þó einn aðal notandi sem við verðum að hafa áhyggjur af sem er kaldhæðnislega við sjálfir, en í venjulegu bókasafninu.
        // Rust staðalbókasafnið er háð þessu crate til að styðja við bakslag og þetta crate er einnig til á crates.io.
        // Þetta þýðir að ef staðlaða bókasafnið er að prenta panic bakslag getur það keppt við þetta crate sem kemur frá crates.io og veldur villubreytingum.
        //
        // Til að hjálpa við að leysa þetta samstillingarvandamál notum við Windows-sérstakt bragð hér (það er jú Windows-sérstök takmörkun varðandi samstillingu).
        // Við búum til *session-local* sem heitir mutex til að vernda þetta símtal.
        // Ætlunin hér er að staðlaða bókasafnið og þetta crate þurfi ekki að deila forritaskilum á Rust-stigi til að samstilla hér en geti í staðinn unnið á bak við tjöldin til að ganga úr skugga um að þau séu samstillt hvert við annað.
        //
        // Þannig þegar þessi aðgerð er kölluð í gegnum venjulega bókasafnið eða í gegnum crates.io getum við verið viss um að sama mutex sé að eignast.
        //
        // Svo að allt þetta er að segja að það fyrsta sem við gerum hér er að við búum til atómískt `HANDLE` sem er nefnt mutex á Windows.
        // Við samstillum svolítið við aðra þræði sem deila þessari aðgerð sérstaklega og tryggjum að aðeins eitt handfang sé búið til í hverju tilviki af þessari aðgerð.
        // Athugaðu að handfangið er aldrei lokað þegar það er geymt í heiminum.
        //
        // Eftir að við höfum farið í lás eigum við einfaldlega hann og `Init` handfangið sem við afhendum mun bera ábyrgð á því að láta það falla að lokum.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Allt í lagi, pæling!Nú þegar við erum öll örugg samstillt skulum við byrja að vinna úr öllu.
        // Í fyrsta lagi verðum við að tryggja að `dbghelp.dll` sé raunverulega hlaðið í þessu ferli.
        // Við gerum þetta á kraftmikinn hátt til að forðast truflanir.
        // Þetta hefur sögulega verið gert til að vinna í kringum undarleg tengingarmálefni og er ætlað að gera tvíþætta hluti færanlegri þar sem þetta er að mestu leyti kembiforrit.
        //
        //
        // Þegar við höfum opnað `dbghelp.dll` þurfum við að hringja í nokkrar frumstillingaraðgerðir í því og það er nánar hér að neðan.
        // Við gerum þetta aðeins einu sinni, þannig að við höfum alþjóðlegt boolean sem gefur til kynna hvort við séum búin enn eða ekki.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Gakktu úr skugga um að `SYMOPT_DEFERRED_LOADS` fáninn sé stilltur, því samkvæmt skjölum MSVC sjálfs um þetta: "This is the fastest, most efficient way to use the symbol handler.", svo við skulum gera það!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Ræsið raunverulega tákn með MSVC.Athugaðu að þetta getur mistekist en við hunsum það.
        // Það er ekki mikið af fyrri list fyrir þetta í sjálfu sér, en LLVM virðist innra hundsa ávöxtunargildið hér og eitt af hreinsiefnisbókasöfnunum í LLVM prentar skelfilega viðvörun ef þetta mistekst en hunsar það í grundvallaratriðum til lengri tíma litið.
        //
        //
        // Eitt tilfelli þetta kemur mikið upp fyrir Rust er að venjulegt bókasafn og þetta crate á crates.io vilja báðir keppa um `SymInitializeW`.
        // Hefðbundna bókasafnið vildi sögulega frumstilla þá hreinsun oftast, en nú þegar það notar þetta crate þýðir það að einhver muni byrja á frumstillingu og hinn muni taka þá upphafningu.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}