use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr tekur svarhringingu sem fær dl_phdr_info bendi fyrir hvern DSO sem hefur verið tengdur við ferlið.
    // dl_iterate_phdr tryggir einnig að kraftmikill hlekkur sé læstur frá upphafi til enda endurtekningarinnar.
    // Ef svarhringing skilar gildi sem er ekki núll er endurtekningunni hætt snemma.
    // 'data' verða send sem þriðju rökin fyrir símtalinu í hverju símtali.
    // 'size' gefur stærð dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Við þurfum að greina út byggingarauðkenni og nokkur grunnforrit fyrir hausgögn sem þýðir að við þurfum líka svolítið af efni frá ELF-tækninni.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Nú verðum við að endurtaka, hluti fyrir hluti, uppbyggingu dl_phdr_info gerðarinnar sem er notaður af núverandi kraftmiklum krækjum fuchsia.
// Chromium hefur einnig þessi ABI mörk auk crashpad.
// Að lokum viljum við færa þessi mál til að nota álfaleit en við þyrftum að láta það í SDK og það hefur ekki enn verið gert.
//
// Þannig erum við (og þeir) fastir að þurfa að nota þessa aðferð sem verður fyrir þéttri tengingu við fuchsia libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Við höfum enga leið til að vita hvort e_phoff og e_phnum eru gild.
    // libc ætti að tryggja þetta fyrir okkur samt svo það er óhætt að mynda sneið hér.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr táknar 64-bita ELF forrithaus í endanlegu markhópnum.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr táknar gildan haus ELF forrits og innihald þess.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Við höfum enga leið til að athuga hvort p_addr eða p_memsz séu gild.
    // Libc Fuchsia fléttar minnispunktana fyrst, svo í krafti þess að vera hér verða þessir hausar að vera gildir.
    //
    // AthugasemdIter krefst ekki að undirliggjandi gögn séu gild en það krefst þess að mörkin séu gild.
    // Við treystum því að libc hafi tryggt að þetta sé raunin fyrir okkur hér.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Athugasemdargerð fyrir auðkenni byggingar.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr táknar haus ELF seðla í endi marksins.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Athugasemd táknar ELF seðil (haus + innihald).
// Nafnið er skilið sem u8 sneið vegna þess að því er ekki alltaf lokið og rust gerir það auðvelt að athuga hvort bætin passi hvort sem er.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter gerir þér kleift að endurtekna örugglega yfir nótuhluta.
// Henni lýkur um leið og villa kemur upp eða engar athugasemdir eru til.
// Ef þú endurtekur ógild gögn mun það virka eins og engar athugasemdir hafi fundist.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Það er óbreyttur aðgerð að bendillinn og stærðin sem gefin er tákni gild svið af bæti sem allir geta verið lesnir.
    // Innihald þessara bæti getur verið hvað sem er en sviðið verður að vera gilt til að þetta sé öruggt.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to stillir 'x' saman við 'to'-byte röðun að því gefnu að 'to' sé máttur 2.
// Þetta fylgir venjulegu mynstri í C/C ++ ELF þáttunarkóða þar sem (x + til, 1)&-to er notað.
// Rust leyfir þér ekki að nota notkun svo að ég noti
// 2's viðbót viðskipta til að endurskapa það.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 neytir num bæti úr sneiðinni (ef hún er til staðar) og tryggir auk þess að endanleg sneið er rétt stillt.
// Ef annaðhvort fjöldi bæti sem beðið er um er of mikill eða ekki er hægt að endurskipuleggja sneiðina vegna þess að ekki er nóg af bætum sem til eru, er engu skilað og sneiðinni er ekki breytt.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Þessi aðgerð hefur enga raunverulega innflytjendur sem kallinn verður að viðhalda öðruvísi en að 'bytes' ætti að vera samstilltur til frammistöðu (og á sumum arkitektúrum réttleika).
// Gildin í reitunum Elf_Nhdr gætu verið bull en þessi aðgerð tryggir ekkert slíkt.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Þetta er öruggt svo framarlega sem nóg pláss er og við staðfestum bara að í ef yfirlýsingunni hér að ofan svo þetta ætti ekki að vera óöruggt.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Athugaðu að sice_of: :<Elf_Nhdr>() er alltaf með 4 bæti.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Athugaðu hvort við höfum náð endanum.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Við sendum út nhdr en við íhugum vandlega uppbygginguna sem myndast.
        // Við treystum ekki namesz eða descsz og tökum engar ótryggar ákvarðanir út frá gerðinni.
        //
        // Þannig að jafnvel þó að við förum út með fullkomið sorp ættum við samt að vera örugg.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Sýnir að hluti er keyranlegur.
const PERM_X: u32 = 0b00000001;
/// Gefur til kynna að hluti sé skrifanlegur.
const PERM_W: u32 = 0b00000010;
/// Gefur til kynna að hluti sé læsilegur.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Táknar ELF hluti á keyrslutíma.
struct Segment {
    /// Gefur upp sýndarnetfang keyrslu á innihaldi þessa hluta.
    addr: usize,
    /// Gefur minni stærð á innihaldi þessa hluta.
    size: usize,
    /// Gefur sýndarnetfangi einingar þessa hluta með ELF skránni.
    mod_rel_addr: usize,
    /// Gefur heimildir sem finnast í ELF skránni.
    /// Þessar heimildir eru þó ekki endilega þær heimildir sem eru til staðar á keyrslutíma.
    flags: Perm,
}

/// Leyfir einum að endurtekna hluti af DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Táknar ELF DSO (Dynamic Shared Object).
/// Þessi tegund vísar til gagna sem eru geymd í raunverulegu DSO frekar en að búa til sitt eigið afrit.
struct Dso<'a> {
    /// Hinn kraftmikli hlekkur gefur okkur alltaf nafn, jafnvel þó nafnið sé autt.
    /// Í tilviki aðalútfærslunnar verður nafnið autt.
    /// Ef um sameiginlegan hlut er að ræða mun það vera nafnið (sjá DT_SONAME).
    name: &'a str,
    /// Á Fuchsia hafa nánast allar tvöföldunarheimildir byggt skilríki en þetta er ekki ströng krafa.
    /// Það er engin leið til að samræma DSO upplýsingar við raunverulega ELF skrá á eftir ef það er engin build_id svo við krefjumst þess að hver DSO hafi einn hérna.
    ///
    /// DSO án build_id eru hunsaðir.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Skilar endurtekningu yfir hluti í þessu DSO.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Þessar villur umrita vandamál sem koma upp við þáttun upplýsinga um hvert DSO.
///
enum Error {
    /// NameError þýðir að villa kom upp við að breyta C stíl streng í rust streng.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError þýðir að við fundum ekki auðkenni byggingar.
    /// Þetta gæti annaðhvort verið vegna þess að DSO hafði ekkert byggingarauðkenni eða vegna þess að hluti sem innihélt byggingarauðkenni var vanskapaður.
    ///
    BuildIDError,
}

/// Hringir annaðhvort í 'dso' eða 'error' fyrir hvern DSO sem er tengdur í ferlið af kraftmikla hlekknum.
///
///
/// # Arguments
///
/// * `visitor` - A DsoPrinter sem mun hafa einn af borðaaðferðum sem kallast foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr tryggir að info.name muni benda á gildan stað.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Þessi aðgerð prentar Fuchsia táknmyndamerkingu fyrir allar upplýsingar sem eru í DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}