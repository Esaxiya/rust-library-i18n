use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Leystu heimilisfang að tákni og sendu táknið til tilgreindrar lokunar.
///
/// Þessi aðgerð mun fletta upp tilteknu heimilisfangi á svæðum eins og staðbundnu táknatöflu, kraftmiklu táknaborði eða DWARF villuleitarupplýsingum (fer eftir virkjaðri útfærslu) til að finna tákn sem skila.
///
///
/// Ekki er víst að hringt sé í lokunina ef ekki væri hægt að framkvæma upplausn og einnig er hægt að hringja í hana oftar en einu sinni þegar um er að ræða línurit.
///
/// Tákn sem gefin eru tákna framkvæmdina á tilgreindum `addr` og skila file/line pörum fyrir það heimilisfang (ef það er tiltækt).
///
/// Athugaðu að ef þú ert með `Frame` þá er mælt með því að nota `resolve_frame` aðgerðina í stað þessarar.
///
/// # Nauðsynlegir eiginleikar
///
/// Þessi aðgerð krefst þess að `std` eiginleiki `backtrace` crate sé virkur og `std` eiginleiki er virkt sjálfgefið.
///
/// # Panics
///
/// Þessi aðgerð leitast við að panic verði aldrei, en ef `cb` veitti panics þá neyða sumir pallar tvöfalt panic til að hætta við ferlið.
/// Sumir vettvangar nota C bókasafn sem notar innhringingu sem ekki er hægt að vinda ofan af og því getur læti frá `cb` komið af stað ferlinu.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // horfðu aðeins á efstu grindina
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Leystu áður myndaða ramma yfir í tákn og sendu táknið á tilgreinda lokun.
///
/// Þessi aðgerð framkvæmir sömu aðgerð og `resolve` nema að hún tekur `Frame` sem rök í stað heimilisfangs.
/// Þetta getur leyft sumum útfærslum á baksporum að veita nákvæmari táknupplýsingar eða upplýsingar um innbyggða ramma til dæmis.
///
/// Það er mælt með því að nota þetta ef þú getur.
///
/// # Nauðsynlegir eiginleikar
///
/// Þessi aðgerð krefst þess að `std` eiginleiki `backtrace` crate sé virkur og `std` eiginleiki er virkt sjálfgefið.
///
/// # Panics
///
/// Þessi aðgerð leitast við að panic verði aldrei, en ef `cb` veitti panics þá neyða sumir pallar tvöfalt panic til að hætta við ferlið.
/// Sumir vettvangar nota C bókasafn sem notar innhringingu sem ekki er hægt að vinda ofan af og því getur læti frá `cb` komið af stað ferlinu.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // horfðu aðeins á efstu grindina
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// IP gildi frá stafla ramma eru venjulega (always?) leiðbeiningin *eftir* símtalið sem er raunveruleg stafla ummerki.
// Að tákna þetta kveikir á því að filename/line númerið er á undan og kannski í tómarúmið ef það er undir lok aðgerðarinnar.
//
// Þetta virðist í rauninni alltaf vera raunin á öllum kerfum, þannig að við drögum alltaf einn frá leystri ip til að leysa hann af fyrri símtalakennslu í stað þess að kennslunni sé skilað til.
//
//
// Helst myndum við ekki gera þetta.
// Helst ættum við að hringja í `resolve` API hérna til að gera -1 handvirkt og gera grein fyrir að þeir vilji staðsetningarupplýsingar fyrir *fyrri* kennslu, ekki núverandi.
// Helst myndum við einnig fletta ofan af `Frame` ef við erum örugglega heimilisfang næstu kennslu eða núverandi.
//
// Í bili, þó að þetta sé ansi sess áhyggjuefni, svo að við drögum bara inn frá okkur alltaf einn.
// Neytendur ættu að halda áfram að vinna og ná nokkuð góðum árangri, svo við ættum að vera nógu góðir.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Sama og `resolve`, aðeins óöruggt þar sem það er ósamstillt.
///
/// Þessi aðgerð hefur ekki samstillingarábyrgð en er fáanleg þegar `std`-eiginleiki þessa crate er ekki tekinn saman.
/// Sjá `resolve` aðgerðina til að fá frekari skjöl og dæmi.
///
/// # Panics
///
/// Sjá upplýsingar um `resolve` varðandi fyrirvara við `cb` læti.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Sama og `resolve_frame`, aðeins óöruggt þar sem það er ósamstillt.
///
/// Þessi aðgerð hefur ekki samstillingarábyrgð en er fáanleg þegar `std`-eiginleiki þessa crate er ekki tekinn saman.
/// Sjá `resolve_frame` aðgerðina til að fá frekari skjöl og dæmi.
///
/// # Panics
///
/// Sjá upplýsingar um `resolve_frame` varðandi fyrirvara við `cb` læti.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// A trait sem táknar upplausn tákn í skrá.
///
/// Þessi trait er gefinn sem trait hlutur gegn lokuninni sem gefinn er fyrir `backtrace::resolve` aðgerðina og það er nánast sent þar sem ekki er vitað hvaða framkvæmd er á bak við það.
///
///
/// Tákn getur gefið samhengisupplýsingar um aðgerð, til dæmis nafn, skráarnafn, línanúmer, nákvæm heimilisfang osfrv.
/// Ekki eru allar upplýsingar alltaf tiltækar með tákni, þannig að allar aðferðir skila `Option`.
///
///
pub struct Symbol {
    // TODO: þetta ævilangt þarf að vera viðvarandi að lokum til `Symbol`,
    // en það er um þessar mundir brotin breyting.
    // Sem stendur er þetta öruggt þar sem `Symbol` er aðeins alltaf afhent með tilvísun og ekki er hægt að klóna það.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Skilar heiti þessarar aðgerðar.
    ///
    /// Uppbygginguna sem er skilað er hægt að nota til að spyrja um ýmsa eiginleika um táknheitið:
    ///
    ///
    /// * `Display` útfærslan prentar út sundraða táknið.
    /// * Hráa `str` gildi táknsins er hægt að nálgast (ef það er gilt utf-8).
    /// * Hráa bætin fyrir táknheitið er hægt að nálgast.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Skilar upphafsnetfangi þessarar aðgerðar.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Skilar hráa skráarnafninu sem sneið.
    /// Þetta er aðallega gagnlegt fyrir `no_std` umhverfi.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Skilar dálknúmerinu þar sem þetta tákn er nú keyrt.
    ///
    /// Aðeins gimli veitir nú gildi hér og jafnvel þá aðeins ef `filename` skilar `Some`, og því er það þar af leiðandi háð svipuðum fyrirvörum.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Skilar línu númerinu þar sem þetta tákn er núna að keyra.
    ///
    /// Þetta skilagildi er venjulega `Some` ef `filename` skilar `Some` og er þar af leiðandi háð svipuðum fyrirvörum.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Skilar skráarheitinu þar sem þessi aðgerð var skilgreind.
    ///
    /// Þetta er eins og er aðeins í boði þegar libbacktrace eða gimli er notað (td
    /// unix vettvangi öðrum) og þegar tvöfaldur er tekinn saman með debuginfo.
    /// Ef hvorugt þessara skilyrða er uppfyllt mun þetta líklega skila `None`.
    ///
    /// # Nauðsynlegir eiginleikar
    ///
    /// Þessi aðgerð krefst þess að `std` eiginleiki `backtrace` crate sé virkur og `std` eiginleiki er virkt sjálfgefið.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Kannski túlkað C++ tákn, ef þáttun á mangled tákninu sem Rust mistókst.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Vertu viss um að hafa þennan núllstærð, svo að `cpp_demangle`-eiginleikinn hafi engan kostnað þegar hann er óvirkur.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Umbúðir utan um táknheiti til að veita vinnuvistfræðilegan aðgang að niðurnefnu nafni, hráu bætunum, hráa strengnum osfrv.
///
// Leyfa dauða kóða þegar `cpp_demangle` eiginleiki er ekki virkur.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Býr til nýtt táknheiti úr hráu undirliggjandi bætunum.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Skilar hráa (mangled) táknheitinu sem `str` ef táknið er gilt utf-8.
    ///
    /// Notaðu `Display` útfærsluna ef þú vilt fá útrýmda útgáfu.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Skilar hráa táknheitinu sem lista yfir bæti
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Þetta gæti verið prentað ef afminnta táknið er í raun ekki rétt, þannig að meðhöndla villuna hér með tignarlegum hætti með því að breiða hana ekki út.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Reyndu að endurheimta að skyndiminni var notað til að tákna heimilisföng.
///
/// Þessi aðferð mun reyna að losa um hnattræna gagnaskipulag sem annars hefur verið skyndiminni á heimsvísu eða í þræðinum sem táknar venjulega þáttaðar DWARF upplýsingar eða þess háttar.
///
///
/// # Caveats
///
/// Þó að þessi aðgerð sé alltaf í boði gerir hún í raun ekki neitt í flestum útfærslum.
/// Bókasöfn eins og dbghelp eða libbacktrace bjóða ekki upp á aðstöðu til að takast að staðsetja og stjórna úthlutuðu minni.
/// Sem stendur er `gimli-symbolize` eiginleiki þessarar crate eini eiginleiki þar sem þessi aðgerð hefur einhver áhrif.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}