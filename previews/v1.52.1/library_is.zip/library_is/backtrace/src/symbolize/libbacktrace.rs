//! Táknunarstefna með DWARF-þáttunarkóða í libbacktrace.
//!
//! Libbacktrace C bókasafnið, venjulega dreift með gcc, styður ekki aðeins að búa til bakslag (sem við notum í raun ekki) heldur einnig að tákna bakslag og meðhöndla upplýsingar um dverg kembiforrit um hluti eins og innfellda ramma og hvaðeina.
//!
//!
//! Þetta er tiltölulega flókið vegna mikilla ýmissa áhyggna hér, en grunnhugmyndin er:
//!
//! * Fyrst köllum við `backtrace_syminfo`.Þetta fær upplýsingar um tákn úr kraftmiklu táknatöflu ef við getum.
//! * Næst köllum við `backtrace_pcinfo`.Þetta mun flokka aflúsunarupplýsingatöflur ef þær eru tiltækar og leyfa okkur að endurheimta upplýsingar um innbyggða ramma, skráarnafn, línanúmer o.s.frv.
//!
//! Það er fullt af brögðum við að koma dvergborðunum í libbacktrace, en vonandi er það ekki heimsendi og er nógu skýrt þegar lesið er hér að neðan.
//!
//! Þetta er sjálfgefin táknunarstefna fyrir ekki MSVC og OSX kerfi.Í libstd er þetta þó sjálfgefna stefnan fyrir OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Ef mögulegt er, viltu frekar `function` nafnið sem kemur frá debuginfo og getur td verið nákvæmara fyrir ramma til dæmis.
                // Ef það er ekki til staðar, felldu þá aftur að táknheitinu sem tilgreint er í `symname`.
                //
                // Athugaðu að stundum getur `function` fundist eitthvað minna rétt, til dæmis að vera skráð sem `try<i32,closure>` er ekki `std::panicking::try::do_call`.
                //
                // Það er ekki alveg ljóst hvers vegna, en almennt virðist `function` nafnið vera nákvæmara.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // gerðu ekkert í bili
}

/// Gerð `data` bendilsins sem send er í `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Þegar hringt er í þessa símhringingu frá `backtrace_syminfo` þegar við byrjum að leysa förum við lengra í að hringja í `backtrace_pcinfo`.
    // `backtrace_pcinfo` aðgerðin mun hafa samráð við upplýsingar um kembiforrit og reyna að gera hluti eins og að endurheimta file/line upplýsingar sem og ramma.
    // Athugaðu þó að `backtrace_pcinfo` getur mistekist eða ekki gert mikið ef það eru ekki upplýsingar um kembiforrit, svo ef það gerist erum við viss um að hringja aftur með að minnsta kosti einu tákni frá `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Gerð `data` bendilsins sem send er í `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Forritaskil libbacktrace styður að búa til ríki en það styður ekki að eyðileggja ríki.
// Ég persónulega tel þetta meina að ríki sé ætlað að verða til og lifa síðan að eilífu.
//
// Ég myndi elska að skrá at_exit() meðhöndlun sem hreinsar þetta ástand, en libbacktrace veitir enga leið til þess.
//
// Með þessum takmörkunum hefur þessi aðgerð stöðugt skyndiminni sem reiknað er í fyrsta skipti sem þess er óskað.
//
// Mundu að bakslag allt gerist í röð (einn alheimslás).
//
// Athugaðu að skortur á samstillingu hér stafar af kröfunni um að `resolve` sé samstillt að utan.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Ekki nota þráðlausa getu libbacktrace þar sem við erum alltaf að kalla það á samstilltan hátt.
        //
        0,
        error_cb,
        ptr::null_mut(), // engin aukagögn
    );

    return STATE;

    // Athugaðu að til að libbacktrace starfi yfirleitt þarf það að finna DWARF kembiforrit fyrir núverandi keyrslu.Það gerir það venjulega með fjölda aðferða, þar á meðal, en ekki takmarkað við:
    //
    // * /proc/self/exe á studdum pöllum
    // * Skráarheitið var gefið sérstaklega fram þegar ástand var stofnað
    //
    // Libbacktrace bókasafnið er mikið C-kóða.Þetta þýðir náttúrulega að það hefur minni öryggisveiki, sérstaklega þegar meðhöndlað er vanrækt villuleiðbeiningar.
    // Libstd hefur lent í nóg af þessu sögulega.
    //
    // Ef /proc/self/exe er notað þá getum við venjulega hunsað þetta þar sem við gefum okkur að libbacktrace sé "mostly correct" og geri annars ekki skrýtna hluti með "attempted to be correct" dverg villuleitarupplýsingum.
    //
    //
    // Ef við sendum inn skjalanafn, þá er það mögulegt á sumum kerfum (eins og BSD) þar sem illgjarn leikari getur valdið því að handahófskenndri skrá er komið fyrir á þeim stað.
    // Þetta þýðir að ef við segjum libbacktrace um skráarnafn gæti það verið að nota handahófskennda skrá, sem hugsanlega veldur aðgreiningum.
    // Ef við segjum ekki libbacktrace neitt þó það muni ekki gera neitt á kerfum sem styðja ekki slóðir eins og /proc/self/exe!
    //
    // Miðað við allt það sem við reynum eins mikið og mögulegt er að *ekki* skila inn skráarheiti, en verðum við á kerfum sem styðja alls ekki /proc/self/exe.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Athugaðu að helst myndum við nota `std::env::current_exe`, en við getum ekki krafist `std` hér.
            //
            // Notaðu `_NSGetExecutablePath` til að hlaða núverandi keyrsluleið inn á kyrrstætt svæði (sem ef það er of lítið gefst bara upp).
            //
            //
            // Athugaðu að við treystum libbacktrace hér alvarlega til að deyja ekki af spilltum rekstrarforritum, en það gerir það örugglega ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows hefur hátt til að opna skrár þar sem ekki er hægt að eyða því eftir að það er opnað.
            // Það er almennt það sem við viljum hér vegna þess að við viljum tryggja að keyrslan okkar breytist ekki undir okkur eftir að við höfum afhent það í libbacktrace og vonandi dregið úr möguleikanum á að senda handahófskennd gögn í libbacktrace (sem kann að vera misþyrmt).
            //
            //
            // Í ljósi þess að við gerum smá dans hér til að reyna að fá eins konar lás á eigin mynd:
            //
            // * Náðu tökum á núverandi ferli, hlaðið skráarheiti þess.
            // * Opnaðu skrá í því skráarheiti með réttum fánum.
            // * Endurhladdu skráarheiti núverandi ferils og vertu viss um að það sé það sama
            //
            // Ef allt gengur eftir höfum við í orði opnað skjal ferlisins og okkur er tryggt að það breytist ekki.FWIW fullt af þessu er afritað úr libstd sögulega séð, svo þetta er besta túlkun mín á því sem var að gerast.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Þetta lifir í kyrrstöðu minni svo við getum skilað því ..
                static mut BUF: [i8; N] = [0; N];
                // ... og þetta lifir á staflanum þar sem það er tímabundið
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // leka viljandi `handle` hingað því að hafa það opið ætti að varðveita lás okkar á þessu skráarheiti.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Við viljum skila sneið sem er hætt við núll, þannig að ef allt var fyllt út og það jafngildir heildarlengdinni, jafngiltu það við bilun.
                //
                //
                // Annars þegar þú skilar árangri skaltu ganga úr skugga um að núllbætið sé með í sneiðinni.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // baksporunarvillur eru sem stendur sópaðar undir teppið
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Hringdu í `backtrace_syminfo` API sem (frá lestri kóðans) ætti að hringja nákvæmlega einu sinni í `syminfo_cb` (eða mistakast með villu væntanlega).
    // Við meðhöndlum síðan meira innan `syminfo_cb`.
    //
    // Athugaðu að við gerum þetta þar sem `syminfo` mun hafa samráð við táknatöflu og finna táknheiti jafnvel þó að það séu engar villuleiðbeiningar í tvöföldunni.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}