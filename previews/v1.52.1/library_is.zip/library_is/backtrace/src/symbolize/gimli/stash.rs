// aðeins notað á Linux núna, svo leyfðu dauða kóða annars staðar
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Einfaldur vettvangsúthlutun fyrir bætubuffara.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Úthlutar biðminni af tilgreindri stærð og skilar breytilegri tilvísun í hann.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // ÖRYGGI: þetta er eina aðgerðin sem nokkru sinni smíðar breytanlegt
        // tilvísun í `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // ÖRYGGI: við fjarlægjum aldrei þætti úr `self.buffers`, svo viðmiðun
        // að gögnum inni í hvaða biðminni sem er mun lifa svo lengi sem `self` gerir.
        &mut buffers[i]
    }
}