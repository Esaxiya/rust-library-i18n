//! Stuðningur við tákn með `gimli` crate á crates.io
//!
//! Þetta er sjálfgefin útfærsla táknmynda fyrir Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // kyrrstæð ævi er lygi til að hakka í kringum skort á stuðningi við sjálfsvísa.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Breyttu í " kyrrstæðan líftíma þar sem táknin ættu aðeins að fá `map` og `stash` lánuð og við varðveitum þau hér að neðan.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Til að hlaða innfæddum bókasöfnum á Windows, sjáðu nokkrar umræður um rust-lang/rust#71060 varðandi ýmsar aðferðir hér.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW bókasöfn styðja sem stendur ekki ASLR (rust-lang/rust#16514), en samt er hægt að færa DLL-skjöl í netfangssvæðinu.
            // Svo virðist sem heimilisföng í kembiforritum séu öll eins og ef þetta bókasafn var hlaðið í "image base", sem er reitur í hausnum á COFF skránni.
            // Þar sem þetta er það sem debuginfo virðist skrá, tálum við táknatöfluna og geymum netföng eins og bókasafnið væri líka hlaðið á "image base".
            //
            // Ekki er víst að hlaða bókasafninu í "image base".
            // (væntanlega getur eitthvað annað verið hlaðið þar?) Þetta er þar sem `bias` reiturinn kemur við sögu og við verðum að reikna út gildi `bias` hér.Því miður er ekki ljóst hvernig á að eignast þetta úr hlaðinni einingu.
            // Það sem við höfum er hins vegar raunverulegt heimilisfang heimilisfang (`modBaseAddr`).
            //
            // Sem smá afritun í bili, myndum við skrána, lesum upplýsingar um skráarhaus og sleppum síðan mmapinu.Þetta er sóun vegna þess að við munum líklega opna aftur mmap seinna, en þetta ætti að virka nógu vel í bili.
            //
            // Þegar við höfum `image_base` (óskaðan hleðslustað) og `base_addr` (raunverulegan hleðslustað) getum við fyllt út `bias` (mismunur á raunverulegri og óskaðri) og þá er uppgefið heimilisfang hvers hluta `image_base` þar sem það er það sem skjalið segir.
            //
            //
            // Sem stendur virðist sem að ólíkt ELF/MachO getum við látið okkur nægja einn þátt á bókasafni og notað `modBaseSize` sem heildarstærð.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS notar Mach-O skráarsniðið og notar DYLD-sértæk forritaskil til að hlaða lista yfir innfædd bókasöfn sem eru hluti af forritinu.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Náðu í heiti þessa bókasafns sem samsvarar slóðinni hvar á að hlaða það líka.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Hladdu myndhaus þessarar bókasafns og sendu til `object` til að flokka allar álagsskipanir svo við getum fundið út alla þá hluti sem hér eiga hlut að máli.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Veltu yfir hlutunum og skráðu þekkt svæði fyrir hluti sem við finnum.
            // Að auki skráðu upplýsingar um textahluta til úrvinnslu seinna, sjá athugasemdir hér að neðan.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Ákveðið "slide" fyrir þetta bókasafn sem á endanum er hlutdrægni sem við notum til að reikna út hvar í minni eru hlutir hlaðnir.
            // Þetta er þó svolítið skrýtin útreikningur og er afleiðing af því að prófa nokkra hluti í náttúrunni og sjá hvað festist.
            //
            // Almenna hugmyndin er sú að `bias` auk `stated_virtual_memory_address` hluta er að fara að vera þar sem í raunverulegu heimilisfangssvæðinu er búnaðurinn.
            // Hitt sem við treystum á er þó að raunverulegt heimilisfang að frádregnum `bias` sé vísitalan til að fletta upp í táknatöflu og villuleiðbeiningu.
            //
            // Það kemur þó í ljós að fyrir kerfishlaðnar bókasöfn eru þessir útreikningar rangir.Fyrir innfæddra rekstraraðila virðist það hins vegar rétt.
            // Með því að lyfta einhverjum rökum frá upptökum LLDB er það með sérstakt hlíf fyrir fyrsta `__TEXT` hlutann sem hlaðinn er frá skjaljafsetningu 0 með stærð sem ekki er núll.
            // Af hvaða ástæðum sem er þegar þetta er til staðar virðist það þýða að táknataflan sé miðað við vmaddr glæruna fyrir bókasafnið.
            // Ef það er *ekki* til staðar þá er táknataflan miðað við vmaddr skyggnuna auk uppgefins heimilisfangs hlutans.
            //
            // Til að takast á við þessar aðstæður ef við * finnum ekki textahluta við skrárjöfnun núll þá aukum við hlutdrægni með uppgefnu heimilisfangi fyrstu textahlutanna og lækkum öll tilgreind heimilisföng um þá upphæð líka.
            //
            // Þannig birtist táknataflan alltaf miðað við hlutdrægni upphæð bókasafnsins.
            // Þetta virðist hafa réttar niðurstöður til að tákna með táknmyndatöflunni.
            //
            // Satt að segja er ég ekki alveg viss um hvort þetta sé rétt eða hvort það sé eitthvað annað sem ætti að gefa til kynna hvernig á að gera þetta.
            // Í bili virðist þetta virka nógu vel (?) og við ættum alltaf að geta lagfært þetta með tímanum ef þörf krefur.
            //
            // Nánari upplýsingar eru í #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Annað Unix (td
        // Linux) umhverfi nota ELF sem hlutaskráarsnið og innleiða venjulega API sem kallast `dl_iterate_phdr` til að hlaða innfæddar bókasöfn.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` ætti að vera gild ábending.
        // `vec` ætti að vera gildur bendill á `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 styður ekki innfæddar upplýsingar um kembiforrit, en byggingarkerfið mun setja villuleitarupplýsingar á slóðina `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Allt annað ætti að nota ELF en veit ekki hvernig á að hlaða innfæddum bókasöfnum.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Öll þekkt samnýtt bókasöfn sem hafa verið hlaðin.
    libraries: Vec<Library>,

    /// Kortaferðir skyndiminni þar sem við geymum upplýsingar um dverg.
    ///
    /// Þessi listi hefur fasta getu allan sinn tíma sem eykst aldrei.
    /// `usize` þáttur hvers pars er vísitala í `libraries` fyrir ofan þar sem `usize::max_value()` táknar núverandi keyrslu.
    ///
    /// `Mapping` eru samsvarandi þáttaðar dvergupplýsingar.
    ///
    /// Athugaðu að þetta er í grundvallaratriðum LRU skyndiminni og við munum færa hlutina hérna um leið og við táknum heimilisföng.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Hlutar þessa bókasafns hlaðnir í minni og hvar þeir eru hlaðnir.
    segments: Vec<LibrarySegment>,
    /// "bias" þessa bókasafns, venjulega þar sem það er hlaðið í minni.
    /// Þessu gildi er bætt við uppgefið heimilisfang hvers hluta til að fá raunverulegt raunverulegt minnisfang sem hluti er hlaðinn inn í.
    /// Að auki er þessi hlutdrægni dregin frá raunverulegum sýndarminniföngum til að vísa í aflúsunarupplýsingar og táknatöfluna.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Uppgefið heimilisfang þessa hluta í hlutaskránni.
    /// Þetta er í raun ekki þar sem hluti er hlaðinn, heldur er þetta heimilisfang auk `bias` sem inniheldur bókasafnið það sem þú finnur.
    ///
    stated_virtual_memory_address: usize,
    /// Stærð þessa hluta í minni.
    len: usize,
}

// óörugg vegna þess að þess er krafist að hann sé samstilltur að utan
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // óörugg vegna þess að þess er krafist að hann sé samstilltur að utan
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Mjög lítið, mjög einfalt LRU skyndiminni til að kortleggja villuleitarupplýsingar.
        //
        // Högghlutfallið ætti að vera mjög hátt þar sem dæmigerður stafli fer ekki á milli margra sameiginlegra bókasafna.
        //
        // `addr2line::Context` mannvirkin eru ansi dýr í gerð.
        // Reiknað er með að kostnaður þess verði afskrifaður af síðari `locate` fyrirspurnum, sem nýta mannvirkin sem eru byggð þegar smíðað er " addr2line: : Context`s til að fá ágætar hraðaupphlaup.
        //
        // Ef við værum ekki með þetta skyndiminni, þá myndi þessi afskriftir aldrei gerast og táknræn bakspor væri ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Fyrst og fremst, prófaðu hvort þessi `lib` er með einhverja hluti sem innihalda `addr` (meðhöndlun flutnings).Ef þessi athugun stenst getum við haldið áfram hér að neðan og í raun þýtt heimilisfangið.
                //
                // Athugaðu að við erum að nota `wrapping_add` hér til að koma í veg fyrir flæðiskannanir.Það hefur sést í náttúrunni að SVMA + hlutdrægniútreikningur flæðir yfir.
                // Það virðist svolítið skrýtið að það myndi gerast en það er ekki mikið magn sem við getum gert í því annað en líklega bara hunsa þessa hluti þar sem þeir eru líklega að benda í geiminn.
                //
                // Þetta kom upphaflega upp í rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Nú þegar við vitum að `lib` inniheldur `addr` getum við vegið upp á móti hlutdrægni til að finna uppgefið veiruminni.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Óvarandi: eftir að þessu skilyrta lýkur án þess að koma snemma aftur
        // frá villu er skyndiminnifærsla fyrir þessa slóð við vísitölu 0.

        if let Some(idx) = idx {
            // Þegar kortlagningin er þegar í skyndiminni skaltu færa hana að framan.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Þegar kortlagningin er ekki í skyndiminni skaltu búa til nýja kortlagningu, setja hana framan í skyndiminnið og fjarlægja elstu skyndiminnifærsluna ef þörf krefur.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // ekki leka `'static` líftímanum, vertu viss um að það nái til okkar sjálfra
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Lengdu líftíma `sym` til `'static` þar sem okkur er því miður krafist hingað, en það er alltaf að fara út sem tilvísun svo engar tilvísanir í það ættu að vera viðvarandi út fyrir þennan ramma engu að síður.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Að lokum, fáðu vistaða kortagerð eða búðu til nýja kortlagningu fyrir þessa skrá og metðu DWARF upplýsingarnar til að finna file/line/name fyrir þetta heimilisfang.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Við gátum fundið rammaupplýsingar fyrir þetta tákn og rammi " addr2line` innra með öllum snörugum smáatriðum.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Gat ekki fundið villuleiðbeiningar en við fundum þær í táknatöflu álfunnar.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}