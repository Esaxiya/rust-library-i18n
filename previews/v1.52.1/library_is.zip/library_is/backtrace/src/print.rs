#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Mótari fyrir bakslag.
///
/// Þessa gerð er hægt að nota til að prenta bakslag hvort sem bakslagið sjálft kemur.
/// Ef þú ert með `Backtrace` gerð þá notar `Debug` útfærsla þess nú þegar þetta prentform.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Stíl prentunar sem við getum prentað
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Prentar terser bakslag sem helst aðeins inniheldur viðeigandi upplýsingar
    Short,
    /// Prentar bakslag sem inniheldur allar mögulegar upplýsingar
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Búðu til nýjan `BacktraceFmt` sem mun skrifa framleiðslu á `fmt` sem fylgir.
    ///
    /// `format` rökin stjórna stílnum sem bakslagið er prentað í og `print_path` rökin verða notuð til að prenta `BytesOrWideString` tilvik skjalanafna.
    /// Þessi tegund sjálf gerir enga prentun á skráarnafnum, en það er krafist til að hringja aftur.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Prentar inngangsorð fyrir baksporið sem á að prenta.
    ///
    /// Þetta er krafist á sumum vettvangi til að bakslag verði táknuð að fullu seinna og annars ætti þetta bara að vera fyrsta aðferðin sem þú kallar eftir að búið er til `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Bætir ramma við bakslagið.
    ///
    /// Þessi skuldbinding skilar RAII tilviki af `BacktraceFrameFmt` sem hægt er að nota til að prenta raunverulega ramma og við eyðingu hækkar það rammateljara.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Lokar framleiðslu bakslagsins.
    ///
    /// Þetta er eins og er neitun-op en er bætt við fyrir future eindrægni með bakslag snið.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Sem stendur er ekki gert ráð fyrir-þar með talið hook til að gera kleift að bæta við future.
        Ok(())
    }
}

/// Sniðsmaður fyrir aðeins einn ramma af bakslagi.
///
/// Þessi tegund er búin til af `BacktraceFmt::frame` aðgerðinni.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Prentar `BacktraceFrame` með þessum rammagerðarmanni.
    ///
    /// Þetta mun endurkomu prenta öll `BacktraceSymbol` tilvik innan `BacktraceFrame`.
    ///
    /// # Nauðsynlegir eiginleikar
    ///
    /// Þessi aðgerð krefst þess að `std` eiginleiki `backtrace` crate sé virkur og `std` eiginleiki er virkt sjálfgefið.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Prentar `BacktraceSymbol` innan `BacktraceFrame`.
    ///
    /// # Nauðsynlegir eiginleikar
    ///
    /// Þessi aðgerð krefst þess að `std` eiginleiki `backtrace` crate sé virkur og `std` eiginleiki er virkt sjálfgefið.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: þetta er ekki frábært að við endum ekki með að prenta neitt
            // með skráarheitum sem ekki eru utf8.
            // Sem betur fer er næstum allt utf8 svo þetta ætti ekki að vera of slæmt.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Prentar hráan rekinn `Frame` og `Symbol`, venjulega innan úr hrárri afturköllun þessarar crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Bætir hráum ramma við bakslagið.
    ///
    /// Þessi aðferð, ólíkt fyrri, tekur hrá rök ef þau eru að koma frá mismunandi stöðum.
    /// Athugaðu að þetta getur verið kallað mörgum sinnum fyrir einn ramma.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Bætir hráum ramma við framleiðslu bakslagsins, þ.m.t.
    ///
    /// Þessi aðferð, eins og hin fyrri, tekur hráum rökum ef þeir eru að koma frá mismunandi stöðum.
    /// Athugaðu að þetta getur verið kallað mörgum sinnum fyrir einn ramma.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia er ekki táknrænt innan ferils svo það er með sérstakt snið sem hægt er að nota til að tákna seinna.
        // Prentaðu það í stað þess að prenta heimilisföng á okkar eigin sniði hér.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Engin þörf á að prenta "null" ramma, það þýðir í grundvallaratriðum bara að kerfi bakslag var svolítið fús til að rekja aftur ofarlega langt.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Til að draga úr stærð TCB í Sgx hylki viljum við ekki framkvæma virkni táknupplausnar.
        // Frekar getum við prentað offset heimilisfangsins hér, sem síðar gæti verið kortlagt til að rétta aðgerðina.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Prentaðu vísitölu rammans sem og valfrjálsan leiðbeiningarbendil rammans.
        // Ef við erum handan við fyrsta tákn þessa ramma, þá prentum við bara viðeigandi hvít svæði.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Næst skaltu skrifa út táknheitið með því að nota varasniðið til að fá frekari upplýsingar ef við erum í fullri afturábak.
        // Hér meðhöndlum við einnig tákn sem ekki bera nafn,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Og síðast, prentaðu út filename/line númerið ef það er tiltækt.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line eru prentaðar á línur undir táknheitinu, svo prentaðu eitthvað viðeigandi hvítt bil til að rétta okkur við.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Vertu með í innanhúss svarhringingu okkar til að prenta skráarheitið og prenta síðan út línanúmerið.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Bættu við dálknúmeri, ef það er í boði.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Okkur er aðeins sama um fyrsta tákn rammans
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}