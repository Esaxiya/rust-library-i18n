use core::ffi::c_void;
use core::fmt;

/// Skoðar núverandi símtalastafla og sendir alla virka ramma inn í lokunina sem fylgir til að reikna stafla ummerki.
///
/// Þessi aðgerð er vinnuhestur þessa bókasafns við útreikning stafla ummerkja fyrir forrit.Uppgefin lokun `cb` er gefin dæmi um `Frame` sem tákna upplýsingar um þann hringjaramma á staflinum.
/// Lokunin er gefin rammar frá toppi og niður (síðast kallaðir aðgerðir fyrst).
///
/// Skilagildi lokunarinnar er vísbending um hvort halda eigi afturábak.Skilagildið `false` mun ljúka bakslaginu og skila strax.
///
/// Þegar `Frame` er keyptur viltu líklega hringja í `backtrace::resolve` til að umbreyta `ip` (leiðbeiningarbendill) eða táknfangi í `Symbol` þar sem hægt er að læra nafn og/eða skráarnafn/línanúmer.
///
///
/// Athugaðu að þetta er tiltölulega lágt stig virka og ef þú vilt til dæmis fanga bakslag til að skoða síðar, þá gæti `Backtrace` gerðin verið heppilegri.
///
/// # Nauðsynlegir eiginleikar
///
/// Þessi aðgerð krefst þess að `std` eiginleiki `backtrace` crate sé virkur og `std` eiginleiki er virkt sjálfgefið.
///
/// # Panics
///
/// Þessi aðgerð leitast við að panic verði aldrei, en ef `cb` veitti panics þá neyða sumir pallar tvöfalt panic til að hætta við ferlið.
/// Sumir vettvangar nota C bókasafn sem notar innhringingu sem ekki er hægt að vinda ofan af og því getur læti frá `cb` komið af stað ferlinu.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // haltu áfram bakslaginu
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Sama og `trace`, aðeins óöruggt þar sem það er ósamstillt.
///
/// Þessi aðgerð hefur ekki samstillingarábyrgð en er fáanleg þegar `std`-eiginleiki þessa crate er ekki tekinn saman.
/// Sjá `trace` aðgerðina til að fá frekari skjöl og dæmi.
///
/// # Panics
///
/// Sjá upplýsingar um `trace` varðandi fyrirvara við `cb` læti.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// A trait táknar einn ramma af bakslagi, skilaði `trace` aðgerð þessarar crate.
///
/// Lokun rekingaraðgerðarinnar mun skila ramma og ramminn er nánast sendur þar sem undirliggjandi framkvæmd er ekki alltaf þekkt fyrr en keyrslutími.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Skilar núverandi leiðbeiningarbendli þessa ramma.
    ///
    /// Þetta er venjulega næsta leiðbeining sem á að framkvæma í rammanum, en ekki allar útfærslur telja þetta upp með 100% nákvæmni (en það er almennt nokkuð nálægt).
    ///
    ///
    /// Mælt er með því að velta þessu gildi yfir á `backtrace::resolve` til að breyta því í táknheiti.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Skilar núverandi stafla bendi þessa ramma.
    ///
    /// Í tilfelli að bakendi getur ekki endurheimt stafla bendilinn fyrir þennan ramma er núll bendi skilað.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Skilar upphafstákn heimilisfangi ramma þessarar aðgerðar.
    ///
    /// Þetta mun reyna að spóla aftur leiðbeiningarbendilinn sem `ip` skilaði til upphafs aðgerðarinnar og skila því gildi.
    ///
    /// Í sumum tilfellum mun afturenda hins vegar bara skila `ip` frá þessari aðgerð.
    ///
    /// Skilað gildi er stundum hægt að nota ef `backtrace::resolve` mistókst á `ip` sem gefin er hér að ofan.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Skilar grunnnetfangi einingarinnar sem ramminn tilheyrir.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Þetta þarf að koma fyrst, til að tryggja að Miri hafi forgang yfir vettvang vélarinnar
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // aðeins notað í dbghelp tákn
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}