use backtrace::Backtrace;

// Þetta próf virkar aðeins á pöllum sem hafa virka `symbol_address` aðgerð fyrir ramma sem tilkynnir upphafsfang táknsins.
// Þess vegna er það aðeins virkt á nokkrum kerfum.
//
const ENABLED: bool = cfg!(all(
    // Windows hefur í raun ekki verið prófað og OSX styður ekki raunverulega að finna lokandi ramma, svo slökktu á þessu
    //
    target_os = "linux",
    // Þegar ARM er að finna aðliggjandi aðgerð er einfaldlega að skila ip sjálfum sér.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}