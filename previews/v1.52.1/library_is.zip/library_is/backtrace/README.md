# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Bókasafn til að afla bakrásar á keyrslu fyrir Rust.
Þetta bókasafn miðar að því að auka stuðning venjulegu bókasafnsins með því að bjóða upp á forritatengi til að vinna með, en það styður einnig einfaldlega prentun núverandi bakslags eins og panics frá libstd.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Til að einfaldlega fanga bakslag og fresta því að takast á við það seinna, geturðu notað `Backtrace` tegundina á toppnum.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Ef þú vilt hins vegar fá meiri hráan aðgang að raunverulegum rekjaaðgerðum geturðu notað `trace` og `resolve` aðgerðirnar beint.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Leyfðu þessum leiðbeiningarbendli að táknheiti
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // haltu áfram að næsta ramma
    });
}
```

# License

Þetta verkefni er með leyfi undir hvoru tveggja

 * Apache leyfi, útgáfa 2.0, ([LICENSE-APACHE](LICENSE-APACHE) eða http://www.apache.org/licenses/LICENSE-2.0)
 * MIT leyfi ([LICENSE-MIT](LICENSE-MIT) eða http://opensource.org/licenses/MIT)

að eigin vali.

### Contribution

Nema þú takir sérstaklega fram annað, skal framlag, sem þú hefur viljandi lagt fram til baka í bakrásum af þér, eins og það er skilgreint í Apache-2.0 leyfinu, hafa tvöfalt leyfi eins og að ofan, án nokkurra viðbótarskilmála eða skilyrða.







