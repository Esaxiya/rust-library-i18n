//! Forritaskil fyrir úthlutun minni

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Þetta eru töfratáknin til að kalla alþjóðlega úthlutarann.rustc býr þá til að hringja í `__rg_alloc` o.fl.
    // ef það er til `#[global_allocator]` eiginleiki (kóðinn sem stækkar þessi eiginleiki fjölvi býr til þessar aðgerðir), eða að kalla sjálfgefnar útfærslur í libstd (`__rdl_alloc` o.fl.
    //
    // í `library/std/src/alloc.rs`) annars.
    // rustc fork af LLVM eru einnig sérstök tilvik fyrir þessi aðgerðarheiti til að geta hagrætt þeim eins og `malloc`, `realloc` og `free`, í sömu röð.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// Alheims minniúthlutarinn.
///
/// Þessi tegund útfærir [`Allocator`] trait með því að framsenda símtöl til úthlutunaraðilans sem skráður er með `#[global_allocator]` eiginleikanum ef það er til eða sjálfgefið `std` crate.
///
///
/// Note: á meðan þessi tegund er óstöðug er hægt að nálgast virkni sem hún veitir í gegnum [free functions in `alloc`](self#functions).
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Úthluta minni með alheimsúthlutaranum.
///
/// Þessi aðgerð framsendir símtöl í [`GlobalAlloc::alloc`] aðferð úthlutunaraðilans sem skráður er með `#[global_allocator]` eiginleikanum ef það er til, eða sjálfgefið `std` crate.
///
///
/// Reiknað er með að þessi aðgerð verði úrelt í þágu `alloc` aðferðarinnar af gerðinni [`Global`] þegar hún og [`Allocator`] trait verða stöðug.
///
/// # Safety
///
/// Sjá [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Dreifðu minni með alþjóðlega úthlutaranum.
///
/// Þessi aðgerð framsendir símtöl í [`GlobalAlloc::dealloc`] aðferð úthlutunaraðilans sem skráður er með `#[global_allocator]` eiginleikanum ef það er til, eða sjálfgefið `std` crate.
///
///
/// Reiknað er með að þessi aðgerð verði úrelt í þágu `dealloc` aðferðarinnar af gerðinni [`Global`] þegar hún og [`Allocator`] trait verða stöðug.
///
/// # Safety
///
/// Sjá [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Endurúthluta minni með alheimsúthlutaranum.
///
/// Þessi aðgerð framsendir símtöl í [`GlobalAlloc::realloc`] aðferð úthlutunaraðilans sem skráður er með `#[global_allocator]` eiginleikanum ef það er til, eða sjálfgefið `std` crate.
///
///
/// Reiknað er með að þessi aðgerð verði úrelt í þágu `realloc` aðferðarinnar af gerðinni [`Global`] þegar hún og [`Allocator`] trait verða stöðug.
///
/// # Safety
///
/// Sjá [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Úthluta núllstilltu minni með alheimsúthlutaranum.
///
/// Þessi aðgerð framsendir símtöl í [`GlobalAlloc::alloc_zeroed`] aðferð úthlutunaraðilans sem skráður er með `#[global_allocator]` eiginleikanum ef það er til, eða sjálfgefið `std` crate.
///
///
/// Reiknað er með að þessi aðgerð verði úrelt í þágu `alloc_zeroed` aðferðarinnar af gerðinni [`Global`] þegar hún og [`Allocator`] trait verða stöðug.
///
/// # Safety
///
/// Sjá [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // ÖRYGGI: `layout` er ekki núll að stærð,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // ÖRYGGI: Sama og `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // ÖRYGGI: `new_size` er ekki núll þar sem `old_size` er stærra en eða jafnt og `new_size`
            // eins og krafist er af öryggisskilyrðum.Önnur skilyrði verður að vera staðfest af þeim sem hringir
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` athugar líklega `new_size >= old_layout.size()` eða eitthvað álíka.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // ÖRYGGI: vegna þess að `new_layout.size()` verður að vera meira en eða jafnt og `old_size`,
            // bæði gamla og nýja minniúthlutunin gildir fyrir lestur og ritun fyrir `old_size` bæti.
            // Einnig, vegna þess að gamla úthlutunin var ekki enn úthlutað, getur hún ekki skarast `new_ptr`.
            // Þannig er símtalið við `copy_nonoverlapping` öruggt.
            // Sá sem hringir þarf að standa við öryggissamninginn fyrir `dealloc`.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // ÖRYGGI: `layout` er ekki núll að stærð,
            // önnur skilyrði verður að vera staðfest af þeim sem hringir
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ÖRYGGIS: Allir skilyrði verða að vera staðfestir af þeim sem hringir
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ÖRYGGIS: Allir skilyrði verða að vera staðfestir af þeim sem hringir
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // ÖRYGGI: kallinn verður að uppfylla skilyrðin
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // ÖRYGGI: `new_size` er ekki núll.Önnur skilyrði verður að vera staðfest af þeim sem hringir
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` athugar líklega `new_size <= old_layout.size()` eða eitthvað álíka.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // ÖRYGGI: vegna þess að `new_size` verður að vera minna en eða jafnt og `old_layout.size()`,
            // bæði gamla og nýja minniúthlutunin gildir fyrir lestur og ritun fyrir `new_size` bæti.
            // Einnig, vegna þess að gamla úthlutunin var ekki enn úthlutað, getur hún ekki skarast `new_ptr`.
            // Þannig er símtalið við `copy_nonoverlapping` öruggt.
            // Sá sem hringir þarf að standa við öryggissamninginn fyrir `dealloc`.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// Úthlutunaraðili fyrir einstaka ábendingar.
// Þessi aðgerð má ekki vinda ofan af.Ef það gerist mun MIR codegen mistakast.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Þessi undirskrift verður að vera sú sama og `Box`, annars gerist ICE.
// Þegar viðbótarfæribreytu við `Box` er bætt við (eins og `A: Allocator`), verður að bæta þessu við hér líka.
// Til dæmis ef `Box` er breytt í `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, þá verður að breyta þessari aðgerð einnig í `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)`.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Úthlutunarvilla meðhöndlun

extern "Rust" {
    // Þetta er töfratáknið til að hringja í alþjóðlega villuaðilann.
    // rustc býr það til að hringja í `__rg_oom` ef það er `#[alloc_error_handler]`, eða að kalla sjálfgefna útfærslur fyrir neðan (`__rdl_oom`) annars.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Brottfall vegna villu um úthlutun minni eða bilun.
///
/// Hringjendur minnisúthlutunar-forritaskila sem vilja hætta við útreikning til að bregðast við úthlutunarvillu eru hvattir til að hringja í þessa aðgerð frekar en að kalla beint á `panic!` eða álíka.
///
///
/// Sjálfgefin hegðun þessarar aðgerðar er að prenta skilaboð með venjulegum villum og hætta ferlinu.
/// Það er hægt að skipta um það með [`set_alloc_error_hook`] og [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Fyrir úthlutunarpróf er hægt að nota `std::alloc::handle_alloc_error` beint.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // kallað í gegnum myndaða `__rust_alloc_error_handler`

    // ef það er enginn `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // ef það er til `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Sérhæfðu klóna í fyrirfram úthlutað, einingalaust minni.
/// Notað af `Box::clone` og `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Að hafa úthlutað *fyrst* getur leyft hagræðingarmanninum að búa til klóna gildi á sínum stað, sleppa staðnum og hreyfa sig.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Við getum alltaf afritað á staðnum án þess að hafa nokkurn tíma staðbundið gildi.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}