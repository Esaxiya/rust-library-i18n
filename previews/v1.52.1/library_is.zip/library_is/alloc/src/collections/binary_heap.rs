//! Forgangsröð útfærð með tvöfaldri hrúgu.
//!
//! Innsetning og popping stærsta frumefnisins hefur *O*(log(*n*)) tíma flókið.
//! Athugaðu stærsta frumefnið er *O*(1).Að breyta vector í tvöfaldan hrúga er hægt að gera á staðnum og hefur *O*(*n*) flókið.
//! Einnig er hægt að breyta tvöföldum hrúga í flokkaðan vector á staðnum, sem gerir kleift að nota hann fyrir *O*(*n*\*log(* n*)) hrúga af stað.
//!
//! # Examples
//!
//! Þetta er stærra dæmi sem útfærir [Dijkstra's algorithm][dijkstra] til að leysa [shortest path problem][sssp] á [directed graph][dir_graph].
//!
//! Það sýnir hvernig á að nota [`BinaryHeap`] með sérsniðnum gerðum.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // Forgangsröðin er háð `Ord`.
//! // Framkvæmdu trait beinlínis þannig að biðröðin verði mín-hrúga í stað hámarks-hrúgu.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Takið eftir því að við flettum kostnaðinum við pöntunina.
//!         // Ef jafntefli er borið saman við stöðu er þetta skref nauðsynlegt til að gera útfærslur á `PartialEq` og `Ord` í samræmi.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` þarf að útfæra líka.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Hver hnútur er táknaður sem `usize`, til styttri útfærslu.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Stykki algrím Dijkstra.
//!
//! // Byrjaðu á `start` og notaðu `dist` til að rekja núverandi stystu vegalengd að hverjum hnút.Þessi útfærsla er ekki sparneytin þar sem hún getur skilið eftir afrit hnúta í biðröðinni.
//! //
//! // Það notar einnig `usize::MAX` sem sentinel gildi, til einfaldari útfærslu.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [node]=núverandi stysta fjarlægð frá `start` til `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Við erum á `start`, með engan kostnað
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Athugaðu landamærin með lægri kostnaðarhnútum fyrst (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Að öðrum kosti hefðum við getað haldið áfram að finna allar stystu leiðir
//!         if position == goal { return Some(cost); }
//!
//!         // Mikilvægt þar sem við höfum kannski þegar fundið betri leið
//!         if cost > dist[position] { continue; }
//!
//!         // Fyrir hvern hnút sem við getum náð, sjáðu hvort við getum fundið leið með lægri kostnaði sem fer í gegnum þennan hnút
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Ef svo er skaltu bæta því við landamærin og halda áfram
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Slökun, við höfum nú fundið betri leið
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Markmiði er ekki náð
//!     None
//! }
//!
//! fn main() {
//!     // Þetta er beina línuritið sem við ætlum að nota.
//!     // Hnúttölur samsvara mismunandi ríkjum og edge lóðin tákna kostnað við að flytja frá einum hnút í annan.
//!     //
//!     // Athugið að brúnirnar eru einstefna.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // Línuritið er táknað sem aðliggjandi listi þar sem hver vísitala, sem samsvarar hnútgildi, hefur lista yfir útbrúnir.
//!     // Valið fyrir skilvirkni þess.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Hnútur 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Hnútur 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Hnútur 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Hnútur 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Hnútur 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Forgangsröð útfærð með tvöfaldri hrúgu.
///
/// Þetta verður hámark-hrúga.
///
/// Það er rökvilla að hlut sé breytt á þann hátt að pöntun hlutar miðað við önnur hlut, eins og `Ord` trait ákvarðar, breytist meðan hann er í hrúgunni.
///
/// Þetta er venjulega aðeins mögulegt í gegnum `Cell`, `RefCell`, alþjóðlegt ástand, I/O eða óöruggan kóða.
/// Hegðunin sem stafar af slíkri rökvillu er ekki tilgreind en mun ekki leiða til óskilgreindrar hegðunar.
/// Þetta gæti falið í sér panics, rangar niðurstöður, brottfall, minnisleka og lokun.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Tegundarleiðsla leyfir okkur að sleppa skýrri undirskrift (sem væri `BinaryHeap<i32>` í þessu dæmi).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Við getum notað kíki til að skoða næsta atriði í hrúgunni.
/// // Í þessu tilfelli eru engir hlutir þarna inni ennþá svo við fáum Enginn.
/// assert_eq!(heap.peek(), None);
///
/// // Bætum við nokkrum stigum ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Nú gægjast sýnir mikilvægasta hlutinn í hrúgunni.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Við getum athugað lengd hrúgu.
/// assert_eq!(heap.len(), 3);
///
/// // Við getum endurtekið hlutina í hrúgunni, þó að þeim sé skilað í handahófskenndri röð.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Ef við poppum í staðinn þessi stig, ættu þau að koma aftur í röð.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Við getum hreinsað hrúguna af öllum hlutum sem eftir eru.
/// heap.clear();
///
/// // Hrúgurinn ætti nú að vera tómur.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Annaðhvort `std::cmp::Reverse` eða sérsniðin `Ord` útfærsla er hægt að nota til að gera `BinaryHeap` að minni hrúgu.
/// Þetta gerir `heap.pop()` að skila minnsta gildi í stað þess mesta.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Vefjaðu gildi í `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Ef við pöppum þessi stig núna ættu þau að koma aftur í öfugri röð.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Tímaflækjustig
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// Gildið fyrir `push` er væntanlegur kostnaður;aðferðagögnin gefa nánari greiningu.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Uppbygging sem sveipar umbreytanlega tilvísun í stærsta hlutinn á `BinaryHeap`.
///
///
/// Þessi `struct` er búinn til með [`peek_mut`] aðferðinni á [`BinaryHeap`].
/// Sjá skjöl hennar til að fá frekari upplýsingar.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // ÖRYGGI: PeekMut er aðeins komið í stað fyrir hrúga sem ekki eru tómir.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // ÖRYGGI: PeekMut er aðeins komið í stað fyrir hrúga sem ekki eru tómir
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // ÖRYGGI: PeekMut er aðeins komið í stað fyrir hrúga sem ekki eru tómir
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Fjarlægir kíkt gildi úr hrúgunni og skilar því.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Býr til tómt `BinaryHeap<T>`.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Býr til tóman `BinaryHeap` sem hámarkshaug.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Býr til tómt `BinaryHeap` með tiltekna getu.
    /// Þetta úthlutar fyrirfram nægu minni fyrir `capacity` þætti, svo að `BinaryHeap` þarf ekki að endurúthluta fyrr en það inniheldur að minnsta kosti svo mörg gildi.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Skilar breyttri tilvísun í stærsta hlutinn í tvöföldu hrúgunni, eða `None` ef hún er tóm.
    ///
    /// Note: Ef `PeekMut` gildi er lekið gæti hrúgan verið í ósamræmi.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Tímaflækjustig
    ///
    /// Ef hlutnum er breytt þá er tímaflækjan í versta falli *O*(log(*n*)), annars er það *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Fjarlægir stærsta hlutinn úr tvöföldu hrúgunni og skilar henni, eða `None` ef hún er tóm.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Tímaflækjustig
    ///
    /// Versta tilfelli kostnaður `pop` á hrúgu sem inniheldur *n* þætti er *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // ÖRYGGI: !self.is_empty() þýðir að self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Ýtir hlut á tvöfalda hrúguna.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Tímaflækjustig
    ///
    /// Væntanlegur kostnaður við `push`, að meðaltali yfir hverja mögulega röðun á þeim þáttum sem ýtt er á, og yfir nægilega miklum fjölda ýta, er *O*(1).
    ///
    /// Þetta er þýðingarmesti kostnaðarmælikvarðinn þegar ýtt er á þætti sem eru *ekki* þegar í neinu raðaðri mynstri.
    ///
    /// Tímaflækjan rýrnar ef frumefnum er ýtt í aðallega hækkandi röð.
    /// Í versta falli eru þættir ýttir í hækkandi raðaðri röð og afskrifaður kostnaður á ýta er *O*(log(*n*)) á móti hrúgu sem inniheldur *n* þætti.
    ///
    /// Versta tilfelli kostnaður við *eitt* símtal til `push` er *O*(*n*).Versta tilfellið á sér stað þegar getu er uppurin og þarfnast stærðar.
    /// Stærðarkostnaðurinn hefur verið afskrifaður í fyrri tölum.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // ÖRYGGI: Þar sem við ýttum á nýjan hlut þýðir það að
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Eyðir `BinaryHeap` og skilar vector í raðaðri (ascending) röð.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // ÖRYGGI: `end` fer úr `self.len() - 1` í 1 (bæði innifalin),
            //  svo það er alltaf gild vísitala til að fá aðgang.
            //  Það er óhætt að nálgast vísitölu 0 (þ.e. `ptr`), vegna þess að
            //  1 <=enda <self.len(), sem þýðir self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // ÖRYGGI: `end` fer úr `self.len() - 1` í 1 (bæði innifalin) svo:
            //  0 <1 <=enda <= self.len(), 1 <self.len() Sem þýðir 0 <endir og endir <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Útfærslurnar á sift_up og sift_down nota óörugga blokkir til að færa frumefni úr vector (skilur eftir sig gat), færast meðfram hinum og færa fjarlægða þáttinn aftur í vector á lokastaðsetningu holunnar.
    //
    // `Hole` gerðin er notuð til að tákna þetta og vertu viss um að gatið sé fyllt aftur í lok umfangsins, jafnvel á panic.
    // Notkun gat dregur úr stöðugum stuðli miðað við notkun skiptasamninga, sem felur í sér tvöfalt fleiri hreyfingar.
    //
    //
    //
    //

    /// # Safety
    ///
    /// Sá sem hringir verður að ábyrgjast að `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Taktu verðmæti `pos` út og búðu til gat.
        // ÖRYGGI: Sá sem hringir tryggir að pos <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // ÖRYGGI: hole.pos()> start>=0, sem þýðir hole.pos()> 0
            //  og svo getur hole.pos(), 1 ekki undirflæði.
            //  Þetta tryggir foreldri <hole.pos() svo það er gild vísitala og líka!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // ÖRYGGI: Sama og að ofan
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Taktu frumefni í `pos` og færðu það niður hrúguna á meðan börn hennar eru stærri.
    ///
    ///
    /// # Safety
    ///
    /// Sá sem hringir verður að ábyrgjast að `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // ÖRYGGI: Sá sem hringir tryggir að pos <end <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loop invariant: barn==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // bera saman við stærri tveggja barna ÖRYGGI: barn <endir, 1 <self.len() og barn + 1 <end <= self.len(), svo þau eru gildar vísitölur.
            //
            //  barn==2 *hole.pos() + 1!= hole.pos() og barn + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 eða 2* hole.pos() + 2 gæti flætt yfir ef T er ZST
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // ef við erum þegar í lagi, hættu.
            // ÖRYGGI: barn er nú annað hvort gamla barnið eða gamla barnið + 1
            //  Við höfum þegar sannað að báðir eru <self.len() og!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // ÖRYGGI: sama og að ofan.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // ÖRYGGI: &&skammhlaup, sem þýðir að í
        //  annað skilyrði það er þegar satt að barn==enda, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // ÖRYGGI: barn er þegar sannað að það er gild vísitala og
            //  barn==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// Sá sem hringir verður að ábyrgjast að `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // ÖRYGGI: pos <len er tryggður af þeim sem hringir og
        //  augljóslega len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Taktu frumefni á `pos` og færðu það alla leið niður hrúguna og sigtaðu það síðan upp að stöðu.
    ///
    ///
    /// Note: Þetta er hraðara þegar vitað er að frumefnið er stórt/ætti að vera nær botninum.
    ///
    /// # Safety
    ///
    /// Sá sem hringir verður að ábyrgjast að `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // ÖRYGGI: Sá sem hringir tryggir að pos <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loop invariant: barn==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // ÖRYGGI: barn <enda, 1 <self.len() og
            //  barn + 1 <end <= self.len(), þannig að þeir eru gildir vísitölur.
            //  barn==2 *hole.pos() + 1!= hole.pos() og barn + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 eða 2* hole.pos() + 2 gæti flætt yfir ef T er ZST
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // ÖRYGGI: Sama og að ofan
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // ÖRYGGI: barn==enda, 1 <self.len(), svo það er gild vísitala
            //  og barn==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // ÖRYGGI: pos er staðan í holunni og var þegar sannað
        //  að vera gild vísitala.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // ÖRYGGI: n byrjar frá self.len()/2 og fer niður í 0.
            //  Eina tilvikið þegar! (N <self.len()) er ef self.len() ==0, en það er útilokað af lykkjuskilyrðinu.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Færir alla þætti `other` yfir í `self` og skilur `other` eftir tómt.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` tekur O(len1 + len2) aðgerðir og um 2 *(len1 + len2) samanburð í versta falli á meðan `extend` tekur O(len2* log(len1)) aðgerðir og um 1 *len2* log_2(len1) samanburður í versta falli, miðað við að len1>= len2.
        // Fyrir stærri hrúga fylgir krosspunkturinn ekki lengur þessum rökum og var ákvarðaður með reynslu.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Skilar endurtekningu sem sækir þætti í hrúgu röð.
    /// Sóttu þættirnir eru fjarlægðir af upprunalega hrúgunni.
    /// Hinir þættirnir verða fjarlægðir þegar fallið er í hrúgupöntun.
    ///
    /// Note:
    /// * `.drain_sorted()` er *O*(*n*\*log(* n*)); miklu hægar en `.drain()`.
    ///   Þú ættir að nota það síðastnefnda í flestum tilfellum.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // fjarlægir alla þætti í hrúgu röð
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Heldur aðeins þeim þáttum sem tilgreindir eru í forsendunni.
    ///
    /// Með öðrum orðum, fjarlægðu alla þætti `e` þannig að `f(&e)` skili `false`.
    /// Þættirnir eru heimsóttir í óflokkaðri (og ótilgreindri) röð.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // haltu aðeins jöfnum tölum
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Skilar endurtekningu sem heimsækir öll gildi í undirliggjandi vector, í handahófskenndri röð.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Prentaðu 1, 2, 3, 4 í handahófskenndri röð
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Skilar endurtekningu sem sækir þætti í hrúgu röð.
    /// Þessi aðferð eyðir upprunalega hrúgunni.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Skilar stærsta hlutnum í tvöföldu hrúgunni, eða `None` ef hann er tómur.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Tímaflækjustig
    ///
    /// Kostnaður er *O*(1) í versta falli.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Skilar fjölda þátta sem tvöfaldur hrúga getur geymt án endurúthlutunar.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Áskilur lágmarksgetu fyrir nákvæmlega `additional` fleiri þætti til að setja inn í tiltekna `BinaryHeap`.
    /// Gerir ekkert ef afkastagetan er þegar næg.
    ///
    /// Athugið að úthlutarinn gæti gefið safninu meira pláss en það biður um.
    /// Þess vegna er ekki hægt að treysta á getu til að vera nákvæmlega í lágmarki.
    /// Kjósa [`reserve`] ef búast er við future innsetningum.
    ///
    /// # Panics
    ///
    /// Panics ef nýja afkastið flæðir yfir `usize`.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Pantar getu fyrir að minnsta kosti `additional` fleiri þætti til að setja í `BinaryHeap`.
    /// Söfnunin gæti áskilið sér meira pláss til að forðast tíð endurúthlutun.
    ///
    /// # Panics
    ///
    /// Panics ef nýja afkastið flæðir yfir `usize`.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Fleygir eins mikilli viðbótargetu og mögulegt er.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Brottkast getu með lægri mörk.
    ///
    /// Getan verður áfram að minnsta kosti jafn stór og bæði lengdin og verðið sem fylgir.
    ///
    ///
    /// Ef núverandi afkastageta er minni en neðri mörkin, er þetta neitunarleysi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Eyðir `BinaryHeap` og skilar undirliggjandi vector í handahófskenndri röð.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Mun prenta í einhverri röð
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Skilar lengd tvöfaldar hrúgunnar.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Athugar hvort tvöfaldar hrúga sé tóm.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Hreinsar tvöfalda hrúguna og skilar endurtekningu yfir þætti sem fjarlægðir eru.
    ///
    /// Þættirnir eru fjarlægðir í geðþótta röð.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Sleppir öllum hlutum úr tvöföldum hrúga.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Gat táknar gat í sneið, þ.e. vísitölu án gilds gildi (vegna þess að það var flutt frá eða afritað).
///
/// Í falli mun `Hole` endurheimta sneiðina með því að fylla holustöðuna með gildinu sem upphaflega var fjarlægt.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Búðu til nýjan `Hole` við `pos` vísitölu.
    ///
    /// Óörugg vegna þess að staða verður að vera innan gagnasneiðarinnar.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // ÖRYGGI: pos ætti að vera inni í sneiðinni
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Skilar tilvísun í frumefnið sem er fjarlægt.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Skilar tilvísun í frumefnið í `index`.
    ///
    /// Óörugg vegna þess að vísitalan verður að vera innan gagnasneiðarinnar og ekki jöfn pos.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Færa holu á nýjan stað
    ///
    /// Óörugg vegna þess að vísitalan verður að vera innan gagnasneiðarinnar og ekki jöfn pos.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // fyllið gatið aftur
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// Íterator yfir þætti `BinaryHeap`.
///
/// Þessi `struct` er búinn til af [`BinaryHeap::iter()`].
/// Sjá skjöl hennar til að fá frekari upplýsingar.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Fjarlægðu `#[derive(Clone)]` í þágu
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// Eigandi endurtekningartæki yfir þætti `BinaryHeap`.
///
/// Þessi `struct` er búinn til af [`BinaryHeap::into_iter()`] (útvegaður af `IntoIterator` trait).
/// Sjá skjöl hennar til að fá frekari upplýsingar.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// Tæmandi endurtekningartæki yfir þætti `BinaryHeap`.
///
/// Þessi `struct` er búinn til af [`BinaryHeap::drain()`].
/// Sjá skjöl hennar til að fá frekari upplýsingar.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// Tæmandi endurtekningartæki yfir þætti `BinaryHeap`.
///
/// Þessi `struct` er búinn til af [`BinaryHeap::drain_sorted()`].
/// Sjá skjöl hennar til að fá frekari upplýsingar.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Fjarlægir hrúgaþætti í hrúgunaröð.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Breytir `Vec<T>` í `BinaryHeap<T>`.
    ///
    /// Þessi umbreyting gerist á staðnum og hefur *O*(*n*) flækjustig.
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Breytir `BinaryHeap<T>` í `Vec<T>`.
    ///
    /// Þessi umbreyting krefst hvorki gagnaflutninga né úthlutunar og hefur stöðugan flækjustig.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Býr til neyslulegan endurtekning, það er, sem færir hvert gildi út úr tvöfalda hrúgunni í handahófskenndri röð.
    /// Ekki er hægt að nota tvöfalda hrúguna eftir að hafa hringt í þetta.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Prentaðu 1, 2, 3, 4 í handahófskenndri röð
    /// for x in heap.into_iter() {
    ///     // x er með gerð i32, ekki &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}