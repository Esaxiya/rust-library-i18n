use core::marker::PhantomData;
use core::ptr::NonNull;

/// Líkar endurláni af einhverri einstöku tilvísun, þegar þú veist að endurlífgunin og allir afkomendur hennar (þ.e. allir ábendingar og tilvísanir frá henni) verða ekki notaðar lengur á einhverjum tímapunkti og eftir það viltu nota upprunalegu einstöku tilvísunina aftur .
///
///
/// Lánatékkar annast venjulega þessa uppstillingu lána fyrir þig, en sum stjórnunarflæði sem ná þessum stöflun eru of flókin til að þýðandinn geti fylgt eftir.
/// A `DormantMutRef` gerir þér kleift að athuga lántökur sjálfur, meðan þú tjáir enn staflað eðli hennar, og hylja hráan bendilakóða sem þarf til að gera þetta án óskilgreindrar hegðunar.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Taktu einstaka lán og lánið hana strax aftur.
    /// Fyrir þýðandann er líftími nýju tilvísunarinnar sá sami og líftími upphaflegu tilvísunarinnar, en þú promise til að nota það í skemmri tíma.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // ÖRYGGI: við höldum láninu allan 'a gegnum `_marker`, og við afhjúpum
        // aðeins þessi tilvísun, svo hún er einstök.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Fara aftur í einstaka lán sem upphaflega var tekin.
    ///
    /// # Safety
    ///
    /// Endurlánið hlýtur að hafa lokið, það er að segja, tilvísunin sem `new` skilaði og allar ábendingar og tilvísanir sem fengnar eru frá henni, má ekki nota lengur.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // ÖRYGGI: okkar eigin öryggisskilyrði fela í sér að þessi tilvísun er aftur einstök.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;