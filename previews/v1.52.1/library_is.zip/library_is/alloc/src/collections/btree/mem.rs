use core::intrinsics;
use core::mem;
use core::ptr;

/// Þetta kemur í stað gildisins á bak við `v` einstaka tilvísunina með því að hringja í viðkomandi aðgerð.
///
///
/// Ef panic á sér stað í `change` lokuninni verður öllu ferlinu eytt.
#[allow(dead_code)] // geymið sem mynd og til notkunar future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Þetta kemur í stað gildisins á bak við `v` einstaka tilvísunina með því að hringja í viðkomandi aðgerð og skilar niðurstöðu sem fæst í leiðinni.
///
///
/// Ef panic á sér stað í `change` lokuninni verður öllu ferlinu eytt.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}