use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Bætir við öllum lykilgildispörum frá sameiningu tveggja uppreiknandi ítara og hækkar `length` breytu á leiðinni.Hið síðarnefnda auðveldar þeim sem hringir í að forðast leka þegar dropastjórnandi lendir í læti.
    ///
    /// Ef báðir ítórarnir framleiða sama lykilinn fellur þessi aðferð parið frá vinstri ítóranum og bætir parinu frá hægri endurtekningunni.
    ///
    /// Ef þú vilt að tréð endi í stranglega hækkandi röð, eins og fyrir `BTreeMap`, ættu báðir endurtekningarnir að framleiða lykla í strangri uppleið, hver stærri en allir lyklar í trénu, þar á meðal allir lyklar sem þegar eru í trénu við inngöngu.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Við búum okkur undir að sameina `left` og `right` í raðaða röð á línulegum tíma.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Á meðan byggjum við tré úr raðaðri röð á línulegum tíma.
        self.bulk_push(iter, length)
    }

    /// Ýtir öllum lykilgildispörum að enda trésins og hækkar `length` breytu á leiðinni.
    /// Hið síðarnefnda auðveldar þeim sem hringir í að forðast leka þegar endurtekningurinn lendir í læti.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Veltið í gegnum öll lykilgildispör og ýttu þeim í hnúta á réttu stigi.
        for (key, value) in iter {
            // Reyndu að ýta lykilgildispari í núverandi blaðhnút.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Ekkert pláss eftir, farðu upp og ýttu þangað.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Fann hnút með plássi eftir, ýttu hér.
                                open_node = parent;
                                break;
                            } else {
                                // Farðu upp aftur.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Við erum efst, búum til nýjan rótarhnút og ýtum þangað.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Ýttu á lykilgildispör og nýtt hægra undirtré.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Farðu aftur til hægri blaðsins aftur.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Stækkaðu lengdina í hverri endurtekningu, til að tryggja að kortið sleppi viðbættum þáttum, jafnvel þó að endurtekningin fari í læti.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Ítórator til að sameina tvær flokkaðar raðir í eina
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Ef tveir lyklar eru jafnir skilar lykilgildaparinu frá réttum uppruna.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}