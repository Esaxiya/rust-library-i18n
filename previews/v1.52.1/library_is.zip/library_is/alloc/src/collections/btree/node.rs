// Þetta er tilraun til framkvæmda í kjölfar hugsjónarinnar
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Þar sem Rust hefur í raun ekki háðar gerðir og fjölbreytileika endurkomu, þá nægjum við miklu óöryggi.
//

// Meginmarkmið þessarar einingar er að forðast flækjustig með því að meðhöndla tréð sem almennan (ef undarlega lagaðan) ílát og forðast að takast á við flesta B-Tree innflytjendur.
//
// Sem slíkum er þessari einingu sama hvort færslurnar eru flokkaðar, hvaða hnútar geta verið undirfullir, eða jafnvel hvað undirfullur þýðir.Hins vegar treystum við á nokkra innflytjendur:
//
// - Tré verða að hafa samræmda depth/height.Þetta þýðir að hver leið niður að laufi frá tilteknum hnút hefur nákvæmlega sömu lengd.
// - Hnútur að lengd `n` hefur `n` lykla, `n` gildi og `n + 1` brúnir.
//   Þetta felur í sér að jafnvel tómur hnútur hefur að minnsta kosti einn edge.
//   Fyrir laufhnút þýðir "having an edge" aðeins að við getum borið kennsl á stöðu í hnútnum, þar sem blaðjaðar eru tómir og þurfa enga gagnatengingu.
// Í innri hnút skilgreinir edge bæði stöðu og inniheldur bendi á barnhnút.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Undirliggjandi framsetning laufhnúta og hluti af framsetningu innri hnúta.
struct LeafNode<K, V> {
    /// Við viljum vera meðbreytanleg í `K` og `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Vísitala þessa hnúts í `edges` fylki móðurhnútsins.
    /// `*node.parent.edges[node.parent_idx]` ætti að vera það sama og `node`.
    /// Þetta er aðeins tryggt að frumstilla þegar `parent` er ekki núll.
    parent_idx: MaybeUninit<u16>,

    /// Fjöldi lykla og gildi sem þessi hnút geymir.
    len: u16,

    /// Fylkin sem geyma raunveruleg gögn hnútsins.
    /// Aðeins fyrstu `len` þættir hvers fylkis eru frumstilltir og gildir.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Ræsir nýjan `LeafNode` á stað.
    unsafe fn init(this: *mut Self) {
        // Sem almenn stefna skiljum við svið eftir óafgreidda ef þau geta verið, þar sem þetta ætti að vera bæði ört fljótlegra og auðveldara að rekja í Valgrind.
        //
        unsafe {
            // parent_idx, lyklar og vals eru allt MaybeUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Býr til nýjan kassa `LeafNode`.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Undirliggjandi framsetning innri hnúta.Eins og með 'LeafNode' ættu þessir að vera falnir á bak við 'BoxedNode' til að koma í veg fyrir að lyklar og gildi sem ekki eru frumstillt falli niður.
/// Hægt er að steypa beint hvaða bendi sem er við `InternalNode` í bendi á undirliggjandi `LeafNode` hluta hnútsins og leyfa kóða að starfa á laufblöðum og innri hnútum almennt án þess að þurfa jafnvel að athuga hvor tveggja vísirinn bendir á.
///
/// Þessi eiginleiki er virkur með því að nota `repr(C)`.
///
#[repr(C)]
// gdb_providers.py notar þetta tegundarheiti til sjálfsskoðunar.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Ábendingar til barna þessa hnúts.
    /// `len + 1` af þessum eru talin upphafleg og gild, nema að undir lokin, meðan trénu er haldið í gegnum lántöku af gerðinni `Dying`, hanga sumar af þessum ábendingum.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Býr til nýjan kassa `InternalNode`.
    ///
    /// # Safety
    /// Undanþága innri hnúta er að þeir hafa að minnsta kosti einn upphaflegan og gildan edge.
    /// Þessi aðgerð setur ekki upp slíka edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Við þurfum aðeins að frumstilla gögnin;brúnirnar eru MaybeUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Stýrður bendill sem er ekki núll að hnút.Þetta er annaðhvort í eigu bendils við `LeafNode<K, V>` eða í eigu bendis á `InternalNode<K, V>`.
///
/// Hins vegar inniheldur `BoxedNode` engar upplýsingar um hverja af tvenns konar hnútum hún raunverulega inniheldur, og að hluta til vegna þessa skorts á upplýsingum, er hún ekki sérstök tegund og hefur engan eyðileggjanda.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Rótarhnútur í eignu tré.
///
/// Athugaðu að þetta hefur ekki eyðileggjandi og verður að hreinsa það handvirkt.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Skilar nýju tré í eigu, með eigin rótarhnút sem er tómur í upphafi.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` má ekki vera núll.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Lánast rótarhnútinn sem er í eigu.
    /// Ólíkt `reborrow_mut` er þetta öruggt vegna þess að ekki er hægt að nota skilagildið til að eyðileggja rótina og það geta ekki verið aðrar tilvísanir í tréð.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Nokkuð breytanlegt lánar eigna rótarhnútinn.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Breytist óafturkræft yfir í tilvísun sem heimilar leið og býður upp á eyðileggjandi aðferðir og lítið annað.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Bætir við nýjum innri hnút með einum edge sem vísar á fyrri rótarhnút, gerðu þennan nýja hnút að rótarhnút og skila honum.
    /// Þetta eykur hæðina um 1 og er andstæða `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, nema að við gleymdum bara að við erum innvortis núna:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Fjarlægir innri rótarhnútinn og notar fyrsta barnið sem nýja rótarhnútinn.
    /// Þar sem aðeins er ætlunin að hringja í það þegar rótarhnútinn á aðeins eitt barn, er engin hreinsun gerð á neinum lyklum, gildum og öðrum börnum.
    ///
    /// Þetta lækkar hæðina um 1 og er andstæða `push_internal_level`.
    ///
    /// Krefst einkaaðgangs að `Root` hlutnum en ekki að rótarhnútnum;
    /// það ógildir ekki önnur handföng eða tilvísanir í rótarhnútinn.
    ///
    /// Panics ef það er ekkert innra stig, þ.e. ef rótarhnúturinn er lauf.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // ÖRYGGI: við fullyrðum að við séum innri.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // ÖRYGGI: við fengum `self` eingöngu að láni og lántegund hans er einkarétt.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // ÖRYGGI: fyrsta edge er alltaf frumstillt.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` er alltaf samhljóða í `K` og `V`, jafnvel þegar `BorrowType` er `Mut`.
// Þetta er tæknilega rangt en getur ekki haft í för með sér óöryggi vegna innri notkunar á `NodeRef` vegna þess að við höldum okkur fullkomlega almenn yfir `K` og `V`.
//
// Hins vegar, hvenær sem opinber tegund hylur `NodeRef`, vertu viss um að það hafi réttan dreifni.
//
/// Tilvísun í hnút.
///
/// Þessi tegund hefur fjölda breytna sem stjórna því hvernig hún virkar:
/// - `BorrowType`: Dummy tegund sem lýsir tegund lántöku og ber alla ævi.
///    - Þegar þetta er `Immut<'a>` virkar `NodeRef` um það bil eins og `&'a Node`.
///    - Þegar þetta er `ValMut<'a>` virkar `NodeRef` u.þ.b. eins og `&'a Node` með tilliti til lykla og trjábyggingar, en gerir einnig kleift að breyta mörgum breytanlegum tilvísunum í gildi í öllu trénu.
///    - Þegar þetta er `Mut<'a>` virkar `NodeRef` nokkurn veginn eins og `&'a mut Node`, þó að innsetningaraðferðir leyfi breytanlegum bendi að gildi að vera saman.
///    - Þegar þetta er `Owned` virkar `NodeRef` u.þ.b. eins og `Box<Node>` en hefur ekki eyðileggjandi og þarf að þrífa hann handvirkt.
///    - Þegar þetta er `Dying` virkar `NodeRef` samt nokkurn veginn eins og `Box<Node>`, en hefur aðferðir til að eyðileggja tréð smátt og smátt og venjulegar aðferðir, þó að þær séu ekki merktar sem óöruggar að hringja í, geta kallað á UB ef þær eru kallaðar á rangan hátt.
///
///   Þar sem allir `NodeRef` leyfa siglingar í gegnum tréð, gildir `BorrowType` í raun um allt tréð, ekki bara um hnútinn sjálfan.
/// - `K` og `V`: Þetta eru tegundir lykla og gildi sem eru geymd í hnútunum.
/// - `Type`: Þetta getur verið `Leaf`, `Internal` eða `LeafOrInternal`.
/// Þegar þetta er `Leaf` bendir `NodeRef` á blaðhnút, þegar þetta er `Internal` bendir `NodeRef` á innri hnút og þegar þetta er `LeafOrInternal` gæti `NodeRef` verið að benda á aðra hvora gerð hnútsins.
///   `Type` heitir `NodeType` þegar það er notað utan `NodeRef`.
///
/// Bæði `BorrowType` og `NodeType` takmarka hvaða aðferðir við innleiðum, til að nýta kyrrstöðuöryggi.Það eru takmarkanir á því hvernig við getum beitt slíkum takmörkunum:
/// - Fyrir hverja gerðarfæribreytu getum við aðeins skilgreint aðferð annað hvort almenn eða fyrir eina tiltekna gerð.
/// Við getum til dæmis ekki skilgreint aðferð eins og `into_kv` almennt fyrir allar `BorrowType`, eða einu sinni fyrir allar gerðir sem bera ævina, því við viljum að hún skili `&'a` tilvísunum.
///   Þess vegna skilgreinum við það aðeins fyrir minnstu öflugu gerðina `Immut<'a>`.
/// - Við getum ekki fengið óbeina þvingun frá segja `Mut<'a>` til `Immut<'a>`.
///   Þess vegna verðum við að hringja sérstaklega í `reborrow` á öflugri `NodeRef` til að ná aðferð eins og `into_kv`.
///
/// Allar aðferðir á `NodeRef` sem skila einhvers konar tilvísun, annað hvort:
/// - Taktu `self` eftir gildi og skilaðu því líftíma sem `BorrowType` ber.
///   Stundum, til að kalla fram slíka aðferð, þurfum við að hringja í `reborrow_mut`.
/// - Taktu `self` með tilvísun og (implicitly) skilar líftíma tilvísunarinnar í stað þess sem `BorrowType` hefur með sér.
/// Þannig tryggir lántækjandinn að `NodeRef` haldist að láni svo framarlega sem skilað tilvísun er notuð.
///   Aðferðirnar sem styðja innsetningu beygja þessa reglu með því að skila hráum bendli, þ.e. tilvísun án nokkurrar ævi.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Fjöldi stiga sem hnúturinn og stig laufanna eru í sundur, fasti hnútsins sem ekki er hægt að lýsa að fullu með `Type` og sem hnútinn sjálfur geymir ekki.
    /// Við þurfum aðeins að geyma hæð rótarhnútsins og leiða hæð allra annarra hnúta af honum.
    /// Verður að vera núll ef `Type` er `Leaf` og ekki núll ef `Type` er `Internal`.
    ///
    ///
    height: usize,
    /// Bendillinn að laufinu eða innri hnútnum.
    /// Skilgreiningin á `InternalNode` tryggir að bendillinn sé gildur hvort sem er.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Pakkaðu út hnútaviðmiðun sem var pakkað sem `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Birtir gögn innri hnúts.
    ///
    /// Skilar hráu ptr til að forðast ógildingu annarra tilvísana í þennan hnút.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // ÖRYGGI: kyrrstæða gerð hnútsins er `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Lánar einkaaðgang að gögnum innri hnúts.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Finnur lengd hnútsins.Þetta er fjöldi lykla eða gildi.
    /// Fjöldi brúna er `len() + 1`.
    /// Athugaðu að þrátt fyrir að vera öruggt getur hringing á þessari aðgerð haft þá aukaverkun að ógilda breyttar tilvísanir sem óöruggur kóði hefur búið til.
    ///
    pub fn len(&self) -> usize {
        // Afgerandi, við fáum aðeins aðgang að `len` reitnum hér.
        // Ef BorrowType er marker::ValMut gætu verið framúrskarandi breytilegar tilvísanir í gildi sem við megum ekki ógilda.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Skilar fjölda stiga sem hnúturinn og laufin eru í sundur.
    /// Núllhæð þýðir að hnúturinn er lauf sjálft.
    /// Ef þú sérð tré með rótinni efst segir tölan við hvaða hæð hnúturinn birtist.
    /// Ef þú sérð tré með laufum efst segir tölan hversu hátt tréð teygir sig yfir hnútinn.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Tekur út tímabundið aðra, óbreytanlega tilvísun í sama hnút.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Birtir blaðhluta hvers blaðs eða innri hnút.
    ///
    /// Skilar hráu ptr til að forðast ógildingu annarra tilvísana í þennan hnút.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Hnútinn verður að vera gildur í að minnsta kosti LeafNode hluta.
        // Þetta er ekki tilvísun í NodeRef gerð vegna þess að við vitum ekki hvort hún ætti að vera einstök eða deilt.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Finnur foreldri núverandi hnúts.
    /// Skilar `Ok(handle)` ef núverandi hnútur á í raun foreldri, þar sem `handle` bendir á edge foreldrisins sem bendir á núverandi hnút.
    ///
    /// Skilar `Err(self)` ef núverandi hnútur á ekkert foreldri og gefur upprunalega `NodeRef`.
    ///
    /// Aðferðanafnið gerir ráð fyrir að þú sjáir tré með rótarhnútinn efst.
    ///
    /// `edge.descend().ascend().unwrap()` og `node.ascend().unwrap().descend()` ættu bæði, þegar vel gengur, að gera ekki neitt.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Við verðum að nota hráar ábendingar við hnúta vegna þess að ef BorrowType er marker::ValMut gætu verið framúrskarandi breytilegar tilvísanir í gildi sem við megum ekki ógilda.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Athugaðu að `self` verður að vera ófrávíkjanlegt.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Athugaðu að `self` verður að vera ófrávíkjanlegt.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Sýnir laufhluta hvers blaðs eða innri hnút í óbreytanlegu tré.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // ÖRYGGI: það geta ekki verið neinar breytilegar tilvísanir í þetta tré lánað sem `Immut`.
        unsafe { &*ptr }
    }

    /// Lánar útsýni í lyklana sem eru geymdir í hnútnum.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Svipað og `ascend`, fær tilvísun í móðurhnút hnútsins, en deilir einnig núverandi hnút í því ferli.
    /// Þetta er óöruggt vegna þess að núverandi hnútur verður áfram aðgengilegur þrátt fyrir að vera úthlutað.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Fullyrðir óviðeigandi við þýðandann stöðugar upplýsingar um að þessi hnútur sé `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Fullyrðir óviðeigandi við þýðandann stöðugu upplýsingarnar um að þessi hnút sé `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Tekur út tímabundið aðra, breytanlega tilvísun í sama hnút.Varist, þar sem þessi aðferð er mjög hættuleg, tvöfalt svo þar sem hún virðist kannski ekki strax hættuleg.
    ///
    /// Vegna þess að breytilegir ábendingar geta flakkað hvar sem er í kringum tréð, þá er auðveldlega hægt að nota til baka bendilinn til að láta upprunalega bendilinn hanga, utan marka eða vera ógildur samkvæmt staflaðri lánareglum.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) íhugaðu að bæta enn einni gerð breytu við `NodeRef` sem takmarkar notkun leiðsöguaðferða á endurbætta ábendinga og kemur í veg fyrir þessa óöryggi.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Lánar einkaaðgang að laufhluta hvers blaðs eða innri hnút.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // ÖRYGGI: við höfum einkaaðgang að öllum hnútnum.
        unsafe { &mut *ptr }
    }

    /// Býður upp á einkaaðgang að laufhluta hvaða blaðs sem er eða innri hnút.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // ÖRYGGI: við höfum einkaaðgang að öllum hnútnum.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Láni einkaaðgang að hluta af lykilgeymslusvæðinu.
    ///
    /// # Safety
    /// `index` er innan marka 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // ÖRYGGI: sá sem hringir getur ekki kallað frekari aðferðir á sjálfan sig
        // þar til lykilsneiðatilvísuninni er sleppt, þar sem við höfum einstakan aðgang allan líftímann.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Lánar einkaaðgang að frumefni eða sneið af geymslusvæði hnútsins.
    ///
    /// # Safety
    /// `index` er innan marka 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // ÖRYGGI: sá sem hringir getur ekki kallað frekari aðferðir á sjálfan sig
        // þangað til gildi sneiðaviðmiðuninni er sleppt, þar sem við höfum einstakan aðgang allan líftímann.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Lánar einkaaðgang að frumefni eða sneið af geymslusvæði hnútsins fyrir innihald edge.
    ///
    /// # Safety
    /// `index` er innan marka 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // ÖRYGGI: sá sem hringir getur ekki kallað frekari aðferðir á sjálfan sig
        // þangað til edge sneiðatilvísunin er felld, þar sem við höfum einstakan aðgang allan líftímann.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Hnúturinn hefur fleiri en `idx` frumstillta þætti.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Við búum aðeins til tilvísun í þann þátt sem við höfum áhuga á, til að forðast samnefni með framúrskarandi tilvísunum í aðra þætti, einkum þá sem skilað var til hringjandans í fyrri endurtekningum.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Við verðum að þvinga til óstærðra fylkisbenda vegna Rust útgáfu #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Láni einkaaðgang að lengd hnútsins.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Stillir tengil hnútsins við móður edge, án þess að aðrar tilvísanir í hnútinn séu ógildar.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Hreinsar hlekk rótarinnar við foreldri sitt edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Bætir lykilgildispari við enda hnútsins.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Sérhver hlutur sem skilað er með `range` er gild edge vísitala fyrir hnútinn.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Bætir við lykilgildispari og edge til að fara til hægri við það par, við enda hnútsins.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Athugar hvort hnútur sé `Internal` hnútur eða `Leaf` hnútur.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Tilvísun í tiltekið lykilgildispar eða edge innan hnút.
/// `Node` breytan verður að vera `NodeRef` en `Type` getur annað hvort verið `KV` (táknar handfang á lykilgildispari) eða `Edge` (táknar handfang á edge).
///
/// Athugaðu að jafnvel `Leaf` hnútar geta haft `Edge` handföng.
/// Í stað þess að tákna bendi við barnshnút tákna þetta rýmið þar sem barnabendir myndu fara á milli lykilgildispöranna.
/// Til dæmis, í hnút með lengd 2 væru 3 mögulegir edge staðir, einn til vinstri við hnútinn, einn á milli tveggja para og einn til hægri við hnútinn.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Við þurfum ekki alhliða `#[derive(Clone)]`, þar sem eini tíminn sem `Node` verður " klónaður` er þegar það er óbreytanlegt tilvísun og því `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Sækir hnútinn sem inniheldur edge eða lykilgildisparið sem þetta handfang bendir á.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Skilar stöðu þessa handfangs í hnútnum.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Býr til nýtt handfang við lykilgildi par í `node`.
    /// Óörugg vegna þess að sá sem hringir þarf að tryggja að `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Gæti verið opinber framkvæmd PartialEq, en aðeins notuð í þessari einingu.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Tekur út tímabundið annað, óbreytanlegt handfang á sama stað.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Við getum ekki notað Handle::new_kv eða Handle::new_edge vegna þess að við þekkjum ekki tegund okkar
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Fullyrðir óviðeigandi við þýðandann stöðugar upplýsingar um að hnútur handfangsins sé `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Tekur út tímabundið annað, breytilegt handfang á sama stað.
    /// Varist, þar sem þessi aðferð er mjög hættuleg, tvöfalt svo þar sem hún virðist kannski ekki strax hættuleg.
    ///
    ///
    /// Nánari upplýsingar eru í `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Við getum ekki notað Handle::new_kv eða Handle::new_edge vegna þess að við þekkjum ekki tegund okkar
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Býr til nýtt handfang við edge í `node`.
    /// Óörugg vegna þess að sá sem hringir þarf að tryggja að `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Gefið edge vísitölu þar sem við viljum setja í hnút fylltan að getu, reiknar skynsamlega KV vísitölu skiptipunktar og hvar á að framkvæma innsetninguna.
///
/// Markmiðið með skiptipunktinum er að lykill hans og gildi endi í foreldrahnút;
/// lyklar, gildi og brúnir vinstra megin við skiptipunktinn verða vinstra barnið;
/// lyklar, gildi og brúnir til hægri við skiptipunktinn verða rétta barnið.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust útgáfa #74834 reynir að útskýra þessar samhverfar reglur.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Setur inn nýtt lykilgildispar milli lykilgildisparanna til hægri og vinstri við þetta edge.
    /// Þessi aðferð gerir ráð fyrir að nóg pláss sé í hnútnum til að nýja parið passi.
    ///
    /// Bendillinn sem skilað er bendir á gildið sem sett var inn.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Setur inn nýtt lykilgildispar milli lykilgildisparanna til hægri og vinstri við þetta edge.
    /// Þessi aðferð kljúfur hnútinn ef ekki er nóg pláss.
    ///
    /// Bendillinn sem skilað er bendir á gildið sem sett var inn.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Lagar foreldrabendilinn og vísitöluna í barnshnútnum sem þessi edge tengir við.
    /// Þetta er gagnlegt þegar röðun brúna hefur verið breytt,
    fn correct_parent_link(self) {
        // Búðu til bakpunkt án þess að ógilda aðrar tilvísanir í hnútinn.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Setur inn nýtt lykilgildispar og edge sem fara til hægri við þetta nýja par milli þessa edge og lykilgildisparið til hægri við þetta edge.
    /// Þessi aðferð gerir ráð fyrir að nóg pláss sé í hnútnum til að nýja parið passi.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Setur inn nýtt lykilgildispar og edge sem fara til hægri við þetta nýja par milli þessa edge og lykilgildisparið til hægri við þetta edge.
    /// Þessi aðferð kljúfur hnútinn ef ekki er nóg pláss.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Setur inn nýtt lykilgildispar milli lykilgildisparanna til hægri og vinstri við þetta edge.
    /// Þessi aðferð kljúfur hnútinn ef ekki er nægilegt pláss og reynir að setja deiliskipta hlutann í móðurhnútinn rekursívert, þar til rótinni er náð.
    ///
    ///
    /// Ef niðurstaðan sem skilað er er `Fit` getur hnútinn á handfanginu verið þessi edge hnútur eða forfaðir.
    /// Ef niðurstaðan sem skilað er er `Split` verður `left` reiturinn rótarhnúturinn.
    /// Bendillinn sem skilað er bendir á gildið sem sett var inn.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Finnur hnútinn sem bent er á af þessum edge.
    ///
    /// Aðferðanafnið gerir ráð fyrir að þú sjáir tré með rótarhnútinn efst.
    ///
    /// `edge.descend().ascend().unwrap()` og `node.ascend().unwrap().descend()` ættu bæði, þegar vel gengur, að gera ekki neitt.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Við verðum að nota hráar ábendingar við hnúta vegna þess að ef BorrowType er marker::ValMut gætu verið framúrskarandi breytilegar tilvísanir í gildi sem við megum ekki ógilda.
        // Engar áhyggjur hafa af því að fá aðgang að hæðarsviðinu vegna þess að það gildi er afritað.
        // Varist að þegar hnútabendillinn hefur verið vísað til annars höfum við aðgang að brúnarmörkum með tilvísun (Rust útgáfa #73987) og ógildir allar aðrar tilvísanir í eða innan fylkisins, ættu einhverjar að vera til.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Við getum ekki hringt í aðskildar lykil-og gildisaðferðir, því að hringja í þann síðari ógildir tilvísunina sem sú fyrri skilaði.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Skiptu um lykilinn og gildi sem KV handfangið vísar til.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Hjálpar til við útfærslur á `split` fyrir tiltekinn `NodeType`, með því að sjá um laufgögn.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Skiptir undirliggjandi hnút í þrjá hluta:
    ///
    /// - Hnútinn er styttur til að innihalda aðeins lykilgildispörin vinstra megin við þetta handfang.
    /// - Lykillinn og gildið sem bent er á með þessu handfangi eru dregin út.
    /// - Öll lykilgildispörin til hægri við þetta handfang eru sett í nýlega úthlutaðan hnút.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Fjarlægir lykilgildisparið sem þetta handfang bendir á og skilar því ásamt edge sem lykilgildisparið hrundi í.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Skiptir undirliggjandi hnút í þrjá hluta:
    ///
    /// - Hnútinn er styttur til að innihalda aðeins brúnirnar og lykilgildispörin vinstra megin við þetta handfang.
    /// - Lykillinn og gildið sem bent er á með þessu handfangi eru dregin út.
    /// - Allar brúnir og lykilgildispör til hægri við þetta handfang eru sett í nýlega úthlutaðan hnút.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Táknar lotu til að meta og framkvæma jafnvægisaðgerð í kringum innra lykilgildispar.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Velur jafnvægissamhengi sem felur í sér hnútinn sem barn, þannig milli KV strax til vinstri eða til hægri í foreldrahnútnum.
    /// Skilar `Err` ef það er ekkert foreldri.
    /// Panics ef foreldri er tómt.
    ///
    /// Kýs frekar vinstri hliðina, til að vera ákjósanlegur ef tiltekinn hnútur er einhvern veginn undirfullur, sem þýðir hér aðeins að hann hefur færri þætti en vinstra systkini sitt og en hægra systkini hans, ef þeir eru til.
    /// Í því tilfelli er sameining við vinstra systkini hraðari, þar sem við þurfum aðeins að færa N frumefni hnútsins í stað þess að færa þau til hægri og færa meira en N frumefni fyrir framan.
    /// Að stela frá vinstra systkini er líka venjulega hraðara, þar sem við þurfum aðeins að færa N þætti hnútsins til hægri, í stað þess að færa að minnsta kosti N af þætti systkinanna til vinstri.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Skilar hvort sameining er möguleg, þ.e hvort það er nóg pláss í hnút til að sameina miðlæga KV með báðum aðliggjandi barnanótum.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Framkvæmir sameiningu og lætur lokun ákveða hvað skal skila.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // ÖRYGGI: hæð hnútanna sem sameinaðir eru er undir hæðinni
                // hnútsins á þessum edge, þannig yfir núllinu, svo þeir eru innri.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Sameinar lykilgildi par foreldrisins og báðir aðliggjandi barnahnútar í vinstri barnshnútinn og skilar minnkuðum foreldrahnút.
    ///
    ///
    /// Panics nema við `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Sameinar lykilgildapar foreldrisins og báðir aðliggjandi barnahnútar í vinstri barnahnútinn og skilar því barnahnoð.
    ///
    ///
    /// Panics nema við `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Sameinar lykilgildi par foreldrisins og báðir aðliggjandi barnshnúður í vinstri barnaknútinn og skilar edge handfanginu í því barnaknút þar sem rakið barn edge endaði,
    ///
    ///
    /// Panics nema við `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Fjarlægir lykilgildispar frá vinstra barni og setur það í lykilgildi geymslu foreldrisins, en ýta gamla foreldra lykilgildisparinu í rétt barn.
    ///
    /// Skilar handfangi við edge í hægra barni sem samsvarar þar sem upprunalega edge sem tilgreind var af `track_right_edge_idx` endaði.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Fjarlægir lykilgildispar frá hægra barni og setur það í lykilgildi geymslu foreldrisins, en ýta gamla lykilgildispar foreldris á vinstra barn.
    ///
    /// Skilar handfangi við edge í vinstra barninu sem tilgreint er af `track_left_edge_idx`, sem hreyfðist ekki.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Þetta stelur svipað og `steal_left` en stelur mörgum þáttum í einu.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Gakktu úr skugga um að við getum stolið örugglega.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Færa blaðgögn.
            {
                // Gerðu pláss fyrir stolna þætti í rétta barni.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Færðu þætti frá vinstra barninu í það hægra.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Færðu parið sem stolið er vinstra megin til foreldrisins.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Færðu lykilgildapar foreldris til hægri barns.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Gerðu pláss fyrir stolna brúnir.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Stela brúnum.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Samhverf klón `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Gakktu úr skugga um að við getum stolið örugglega.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Færa blaðgögn.
            {
                // Færðu parið sem stolið er til hægri til foreldrisins.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Færðu lykilgildi par foreldris til vinstri barnsins.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Færðu þætti frá hægra barninu til vinstri.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Fylltu skarð þar sem stolnir þættir voru áður.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Stela brúnum.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Fylltu skarð þar sem áður var stolið brún.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Fjarlægir allar truflanir sem fullyrða að þessi hnútur sé `Leaf` hnútur.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Fjarlægir allar truflanir sem fullyrða að þessi hnútur sé `Internal` hnútur.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Athugar hvort undirliggjandi hnútur er `Internal` hnútur eða `Leaf` hnútur.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Færðu viðskeytið á eftir `self` frá einum hnút í annan.`right` verður að vera autt.
    /// Fyrsta edge `right` er óbreytt.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Niðurstaða innsetningar, þegar hnútur þurfti að stækka umfram getu sína.
pub struct SplitResult<'a, K, V, NodeType> {
    // Breyttur hnútur í núverandi tré með frumefni og brúnir sem tilheyra vinstra megin við `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Einhver lykill og gildi klofna, til að setja inn annars staðar.
    pub kv: (K, V),
    // Eigið, ótengdur, nýr hnútur með þætti og brúnir sem tilheyra hægri `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Hvort hnútatilvísanir af þessari lántegund leyfa leið til annarra hnúta í trénu.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Ferðalag er ekki þörf heldur gerist það með niðurstöðu `borrow_mut`.
        // Með því að slökkva á yfirferð og búa aðeins til nýjar tilvísanir í rætur vitum við að sérhver tilvísun af gerðinni `Owned` er til rótarhnúta.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Setur gildi inn í sneið af frumstöfuðum þáttum sem fylgt er eftir með einum frumstýringu.
///
/// # Safety
/// Sneiðin hefur meira en `idx` þætti.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Fjarlægir og skilar gildi úr sneið af öllum upphafsþáttum og skilur eftir sig einn eftir óinnrunaðan þátt.
///
///
/// # Safety
/// Sneiðin hefur meira en `idx` þætti.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Færir þættina í sneið `distance` stöðum til vinstri.
///
/// # Safety
/// Sneiðin hefur að minnsta kosti `distance` þætti.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Færir þættina í sneið `distance` stöðum til hægri.
///
/// # Safety
/// Sneiðin hefur að minnsta kosti `distance` þætti.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Færir öll gildi frá sneið af frumstýrðum þáttum í sneið af frumlausum þáttum og skilur eftir `src` eins og öll ófrumgerð.
///
/// Virkar eins og `dst.copy_from_slice(src)` en þarf ekki `T` til að vera `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;