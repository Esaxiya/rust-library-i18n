//! Unicode strengjasneiðar.
//!
//! *[See also the `str` primitive type](str).*
//!
//! `&str` gerðin er ein af tveimur megin strengjategundunum, hin er `String`.
//! Ólíkt `String` hliðstæðu sinni er innihald hennar tekið að láni.
//!
//! # Grunnnotkun
//!
//! Grunnstrengjayfirlýsing af gerðinni `&str`:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! Hér höfum við lýst strengjabókstaf, einnig þekkt sem strengjasneið.
//! Strengjabókstafir hafa kyrrstæðan líftíma, sem þýðir að strengurinn `hello_world` er öruggur gildur meðan á öllu forritinu stendur.
//!
//! Við getum einnig tilgreint ævi " halló_heima` líka:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// Margar af notkununum í þessari einingu eru eingöngu notaðar í prófunarstillingum.
// Það er hreinna að slökkva bara á viðvöruninni unused_imports en að laga þau.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `str` í `Concat<str>` hefur ekki þýðingu hér.
/// Þessi breytu af gerðinni trait er aðeins til til að gera aðra ígr.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // lykkjur með harðkóðuðri stærð hlaupa mun hraðar sérhæfa málin með litlum skiljulengdum
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // handahófskenndur ekki-núll stærð fallback
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Bjartsýni tengja framkvæmd sem virkar fyrir bæði Vec<T>(T: Afrita) og innri tækið í String Eins og (2018-05-13) er galla með gerð ályktun og sérhæfingu (sjá tölublað #36262) Af þessum sökum SliceConcat<T>er ekki sérhæft fyrir T: Copy og SliceConcat<str>er eini notandinn í þessari aðgerð.
// Það er látið liggja fyrir þann tíma þegar það er lagað.
//
// mörk String-join eru S: Lána<str>og fyrir Vec-join Lána <[T]> [T] og str bæði impl AsRef <[T]> fyrir suma T
// => s.borrow().as_ref() og við höfum alltaf sneiðar
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // fyrsta sneiðin er sú eina án skilju á undan henni
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // reiknið nákvæma heildarlengd sameinaðs Vec ef `len` útreikningurinn flæðir yfir, við munum panic við myndum engan veginn verða minnislaus og restin af aðgerðinni krefst þess að allt Vec sé úthlutað til öryggis
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // útbúið óinnrunaðan biðminni
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // afrita aðskilnað og sneiðar yfir án marka eftirlit mynda lykkjur með harðkóðuðu móti fyrir litla skiljur miklu endurbætur mögulegar (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // Skrítin útfærsla lána getur skilað mismunandi sneiðum fyrir lengdarútreikninginn og raunverulegt afrit.
        //
        // Gakktu úr skugga um að við setjum ekki óbiflýst bæti fyrir hringingarmanninn.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// Aðferðir við strengjasneiðar.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// Breytir `Box<str>` í `Box<[u8]>` án þess að afrita eða úthluta.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// Skiptir um allar samsvaranir mynsturs með öðrum streng.
    ///
    /// `replace` býr til nýjan [`String`] og afritar gögnin úr þessari strengsneið í hana.
    /// Meðan það er gert reynir það að finna samsvaranir í mynstri.
    /// Ef það finnur einhverja, kemur það í staðinn fyrir skiptistrengsneiðina.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// Þegar mynstrið passar ekki:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Skiptir um fyrstu N eldspýtur mynstur með öðrum streng.
    ///
    /// `replacen` býr til nýjan [`String`] og afritar gögnin úr þessari strengsneið í hana.
    /// Meðan það er gert reynir það að finna samsvaranir í mynstri.
    /// Ef það finnur eitthvað kemur það þeim í stað `count` sinnum í staðinn fyrir skiptistrenginn.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// Þegar mynstrið passar ekki:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // Vona að fækka tímum endurúthlutunar
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Skilar litlu jafngildi þessarar strengjasneiðar, sem ný [`String`].
    ///
    /// 'Lowercase' er skilgreint samkvæmt skilmálum Unicode afleiddra kjarnaeigna `Lowercase`.
    ///
    /// Þar sem sumar persónur geta stækkað í marga stafi þegar málinu er breytt, skilar þessi aðgerð [`String`] í stað þess að breyta breytunni á sínum stað.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// Erfitt dæmi, með sigma:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // en í lok orðs er það ς, ekki σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// Tungumál án máls er ekki breytt:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ kortar til σ, nema í lok orðs þar sem það er kortlagt til ς.
                // Þetta er eina skilyrta (contextual) en tungumál óháð kortlagning í `SpecialCasing.txt`, svo erfitt að kóða það frekar en að hafa almenna "condition" vélbúnað.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // til skilgreiningar á `Final_Sigma`.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// Skilar hágildi þessarar strengjasneiðar, sem ný [`String`].
    ///
    /// 'Uppercase' er skilgreint samkvæmt skilmálum Unicode afleiddra kjarnaeigna `Uppercase`.
    ///
    /// Þar sem sumar persónur geta stækkað í marga stafi þegar málinu er breytt, skilar þessi aðgerð [`String`] í stað þess að breyta breytunni á sínum stað.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// Handrit án máls er ekki breytt:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// Ein persóna getur orðið margföld:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// Breytir [`Box<str>`] í [`String`] án þess að afrita eða úthluta.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// Býr til nýjan [`String`] með því að endurtaka streng `n` sinnum.
    ///
    /// # Panics
    ///
    /// Þessi aðgerð mun panic ef afkastagetan myndi flæða yfir.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// A panic við flæði:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// Skilar afriti af þessum streng þar sem hver stafur er kortlagður jafngildi ASCII.
    ///
    ///
    /// ASCII stafir 'a' til 'z' eru kortlagðir við 'A' til 'Z', en stafir sem ekki eru ASCII eru óbreyttir.
    ///
    /// Notaðu [`make_ascii_uppercase`] til að hástafa gildinu á sínum stað.
    ///
    /// Notaðu [`to_uppercase`] til að hástafir á ASCII stöfum til viðbótar við ekki ASCII stafi.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() varðveitir UTF-8 óbreyttan.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// Skilar afriti af þessum streng þar sem hver stafur er kortlagður í jafngildi ASCII.
    ///
    ///
    /// ASCII stafir 'A' til 'Z' eru kortlagðir við 'a' til 'z', en stafir sem ekki eru ASCII eru óbreyttir.
    ///
    /// Notaðu [`make_ascii_lowercase`] til að lágmarka gildi á staðnum.
    ///
    /// Notaðu [`to_lowercase`] til að lágstafir ASCII stafi til viðbótar við ekki ASCII stafi.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() varðveitir UTF-8 óbreyttan.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// Breytir hnefahögg af bæti í reitasneið án þess að athuga hvort strengurinn innihaldi gildan UTF-8.
///
///
/// # Examples
///
/// Grunn notkun:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}