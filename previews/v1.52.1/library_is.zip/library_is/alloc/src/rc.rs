//! Ábendingar með einum þræði tilvísunartalningu.'Rc' stendur fyrir 'Tilvísun
//! Counted'.
//!
//! Tegundin [`Rc<T>`][`Rc`] veitir sameiginlegt eignarhald á gildi af gerðinni `T`, úthlutað í hrúgunni.
//! Að kalla á [`clone`][clone] á [`Rc`] framleiðir nýjan mús til sömu úthlutunar í hrúgunni.
//! Þegar síðasti [`Rc`] bendillinn að tiltekinni úthlutun er eyðilagður, fellur einnig úr gildi sem geymt er í þeirri úthlutun (oft nefnt "inner value").
//!
//! Sameiginlegar tilvísanir í Rust leyfa sjálfgefið stökkbreytingu og [`Rc`] er engin undantekning: Þú getur almennt ekki fengið breytanlega tilvísun í eitthvað inni í [`Rc`].
//! Ef þú þarft breytileika skaltu setja [`Cell`] eða [`RefCell`] inni í [`Rc`];sjá [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] notar tilvísunartalningu sem ekki er atóm.
//! Þetta þýðir að kostnaður er mjög lágur en ekki er hægt að senda [`Rc`] milli þráða og þar af leiðandi framkvæmir [`Rc`] ekki [`Send`][send].
//! Fyrir vikið mun Rust þýðandinn athuga *á samantektartíma* að þú ert ekki að senda [`Rc`] milli þráðanna.
//! Ef þú þarft fjölþráðan atóm tilvísun talningu, notaðu [`sync::Arc`][arc].
//!
//! [`downgrade`][downgrade] aðferðina er hægt að nota til að búa til [`Weak`] bendi sem ekki er í eigu.
//! [`Weak`] bendill getur verið ["uppfærsla"][uppfærsla] d í [`Rc`], en það skilar [`None`] ef gildið sem er geymt í úthlutuninni hefur þegar verið lækkað.
//! Með öðrum orðum, `Weak` ábendingar halda ekki gildi inni í úthlutuninni;þó *þeir* halda úthlutuninni (bakversluninni fyrir hið innra gildi) á lofti.
//!
//! Hringrás milli [`Rc`] ábendinga verður aldrei úthlutað.
//! Af þessum sökum er [`Weak`] notað til að brjóta hringrásir.
//! Til dæmis gæti tré haft sterka [`Rc`] vísbendingar frá foreldrahnútum til barna og [`Weak`] vísbendingar frá börnum aftur til foreldra sinna.
//!
//! `Rc<T>` sjálfkrafa að vísa til `T` (í gegnum [`Deref`] trait), svo þú getir hringt í aðferðir " T` á gildi af gerðinni [`Rc<T>`][`Rc`].
//! Til að forðast nafnárekstur með aðferðum " T` eru aðferðir [`Rc<T>`][`Rc`] sjálfs tengdar aðgerðir, kallaðar með [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! " Rc<T>Útfærslur á traits eins og `Clone` má einnig kalla með fullgildri setningafræði.
//! Sumir kjósa að nota fullgilda setningafræði en aðrir kjósa að nota setningafræði aðferða.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Setningafræði aðferðarsímtala
//! let rc2 = rc.clone();
//! // Fullgild setningafræði
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] breytir ekki sjálfkrafa `T` vegna þess að innra gildi gæti hafa þegar verið lækkað.
//!
//! # Einræktun tilvísana
//!
//! Að búa til nýja tilvísun í sömu úthlutun og núverandi tilvísunartalaður bendill er gerður með því að nota `Clone` trait sem er útfærður fyrir [`Rc<T>`][`Rc`] og [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Setningafræði tvö hér að neðan eru jafngild.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a og b benda báðir á sömu minnisstað og foo.
//! ```
//!
//! `Rc::clone(&from)` setningafræðin er sú málvenja vegna þess að hún miðlar nánar merkingu kóðans.
//! Í dæminu hér að ofan gerir þessi setningafræði auðveldara að sjá að þessi kóði er að búa til nýja tilvísun frekar en að afrita allt innihald foo.
//!
//! # Examples
//!
//! Hugleiddu atburðarás þar sem mengi af 'græjum' er í eigu tiltekins `Owner`.
//! Við viljum láta græjuna benda á `Owner` þeirra.Við getum ekki gert þetta með sérstöku eignarhaldi, vegna þess að fleiri en ein græja gæti tilheyrt sama `Owner`.
//! [`Rc`] gerir okkur kleift að deila `Owner` á milli margra " græja` og láta `Owner` vera úthlutað svo framarlega sem einhver `Gadget` stig við það.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... önnur svið
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... önnur svið
//! }
//!
//! fn main() {
//!     // Búðu til tilvísunartalaða `Owner`.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Búðu til 'græju' sem tilheyrir `gadget_owner`.
//!     // Klónun á `Rc<Owner>` gefur okkur nýjan mús á sömu `Owner` úthlutun og eykur viðmiðunartalningu í ferlinu.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Fargaðu staðbundnu breytunni okkar `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Þrátt fyrir að hafa sleppt `gadget_owner` getum við samt prentað út nafnið á `Owner` á 'græjunni'.
//!     // Þetta er vegna þess að við höfum aðeins sleppt einum `Rc<Owner>`, ekki `Owner` sem hann bendir á.
//!     // Svo lengi sem önnur `Rc<Owner>` benda á sömu `Owner` úthlutun verður hún áfram í beinni.
//!     // Vettvangsvörpunin `gadget1.owner.name` virkar vegna þess að `Rc<Owner>` vísar sjálfkrafa til `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Í lok aðgerðanna eyðileggst `gadget1` og `gadget2` og með þeim síðustu töluðu tilvísanir í `Owner` okkar.
//!     // Gadget Man eyðileggist nú líka.
//!     //
//! }
//! ```
//!
//! Ef kröfur okkar breytast og við þurfum líka að geta farið frá `Owner` til `Gadget`, lendum við í vandræðum.
//! [`Rc`] bendill frá `Owner` til `Gadget` kynnir hringrás.
//! Þetta þýðir að viðmiðunartalningar þeirra geta aldrei náð 0 og úthlutuninni verður aldrei eytt:
//! minnisleka.Til að komast í kringum þetta getum við notað [`Weak`] ábendingar.
//!
//! Rust gerir það í rauninni nokkuð erfitt að framleiða þessa lykkju í fyrsta lagi.Til þess að lenda í tveimur gildum sem vísa hvort á annað þarf annað þeirra að vera breytilegt.
//! Þetta er erfitt vegna þess að [`Rc`] framfylgir öryggi í minni með því að gefa aðeins upp sameiginlegar tilvísanir í gildið sem það umlykur og þær leyfa ekki beina stökkbreytingu.
//! Við verðum að vefja þann hluta gildisins sem við viljum breyta í [`RefCell`], sem veitir *innri breytileika*: aðferð til að ná breytileika með sameiginlegri tilvísun.
//! [`RefCell`] framfylgir lántökureglum Rust á keyrslutíma.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... önnur svið
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... önnur svið
//! }
//!
//! fn main() {
//!     // Búðu til tilvísunartalaða `Owner`.
//!     // Athugaðu að við höfum sett vector 'eiganda' af 'græju' inni í `RefCell` svo að við getum breytt því með sameiginlegri tilvísun.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Búðu til 'græju sem tilheyrir `gadget_owner`, eins og áður.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Bættu " græjunni` við `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` öflugri lántöku lýkur hér.
//!     }
//!
//!     // Snerist yfir " græjuna` okkar og prentar upplýsingar þeirra út.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` er `Weak<Gadget>`.
//!         // Þar sem `Weak` ábendingar geta ekki ábyrgst að úthlutunin sé enn til staðar, verðum við að hringja í `upgrade`, sem skilar `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // Í þessu tilfelli vitum við að úthlutunin er ennþá til, þannig að við `unwrap` einfaldlega `Option`.
//!         // Í flóknara forriti gætirðu þurft tignarleg villumeðhöndlun fyrir `None` niðurstöðu.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Í lok aðgerðanna eyðileggst `gadget_owner`, `gadget1` og `gadget2`.
//!     // Það eru nú engin sterk (`Rc`) vísbendingar um græjurnar, svo þær eru eyðilagðar.
//!     // Þetta núllar viðmiðunartalningu á Gadget Man, svo hann eyðileggst líka.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Þetta er repr(C) til future-sönnun gegn mögulegri svæðisskipulagningu, sem myndi trufla annars öruggan [into|from]_raw() af breytanlegum innri gerðum.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Bendill með einum þræði tilvísunartalningu.'Rc' stendur fyrir 'Tilvísun
/// Counted'.
///
/// Sjá [module-level documentation](./index.html) fyrir frekari upplýsingar.
///
/// Innbyggðu aðferðirnar við `Rc` eru allar tengdar aðgerðir, sem þýðir að þú verður að kalla þær eins og td [`Rc::get_mut(&mut value)`][get_mut] í stað `value.get_mut()`.
/// Þetta forðast átök við aðferðir af innri gerð `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Þessi óöryggi er í lagi vegna þess að meðan þessi Rc er á lífi er okkur tryggt að innri bendillinn sé gildur.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Smíðar nýjan `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Það er óbeinn veikur bendill í eigu allra sterku ábendinganna, sem tryggir að veiki eyðileggjandinn losar aldrei úthlutunina meðan sterki eyðileggjandinn er í gangi, jafnvel þó að veiki bendillinn sé geymdur inni í þeim sterka.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Smíðar nýjan `Rc<T>` með veikri tilvísun í sjálfan sig.
    /// Tilraun til að uppfæra veiku viðmiðunina áður en þessi aðgerð snýr aftur mun leiða til `None` gildi.
    ///
    /// Hins vegar er hægt að klóna veiku viðmiðunina að vild og geyma til notkunar seinna.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... fleiri reiti
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Byggðu innri í "uninitialized" ástandi með einni veikri tilvísun.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Það er mikilvægt að við gefum ekki upp eignarhald á veikum músinni, annars gæti minnið losnað þegar `data_fn` kemur aftur.
        // Ef við vildum virkilega fara framhjá eignarhaldi gætum við búið til viðbótar veikan bendi fyrir okkur, en þetta myndi leiða til viðbótar uppfærslna á veiku viðmiðunartalningu sem annars gæti ekki verið nauðsynleg.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Sterkar tilvísanir ættu sameiginlega að eiga sameiginlega veika tilvísun, svo ekki keyra tortímandann fyrir gömlu veiku tilvísunina okkar.
        //
        mem::forget(weak);
        strong
    }

    /// Smíðar nýjan `Rc` með frumlausu innihaldi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Frestað frumstilling:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Smíðar nýjan `Rc` með frumlausu innihaldi, þar sem minnið er fyllt með `0` bæti.
    ///
    ///
    /// Sjá [`MaybeUninit::zeroed`][zeroed] fyrir dæmi um rétta og ranga notkun á þessari aðferð.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Smíðar nýjan `Rc<T>` og skilar villu ef úthlutun mistekst
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Það er óbeinn veikur bendill í eigu allra sterku ábendinganna, sem tryggir að veiki eyðileggjandinn losar aldrei úthlutunina meðan sterki eyðileggjandinn er í gangi, jafnvel þó að veiki bendillinn sé geymdur inni í þeim sterka.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Smíðar nýjan `Rc` með frumlausu innihaldi og skilar villu ef úthlutun mistekst
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Frestað frumstilling:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Smíðar nýjan `Rc` með óinnblásnu innihaldi, þar sem minnið er fyllt með `0` bæti og skilar villu ef úthlutun mistekst
    ///
    ///
    /// Sjá [`MaybeUninit::zeroed`][zeroed] fyrir dæmi um rétta og ranga notkun á þessari aðferð.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Smíðar nýjan `Pin<Rc<T>>`.
    /// Ef `T` innleiðir ekki `Unpin`, þá verður `value` fest í minni og ekki hægt að færa það.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Skilar innra gildi ef `Rc` hefur nákvæmlega eina sterka tilvísun.
    ///
    /// Annars er [`Err`] skilað með sama `Rc` og var sent inn.
    ///
    ///
    /// Þetta mun ná árangri, jafnvel þó það séu framúrskarandi veikar tilvísanir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // afritaðu innihaldið sem er að finna

                // Tilgreindu fyrir Weaks að ekki er hægt að koma þeim á framfæri með því að minnka sterka talningu og fjarlægðu síðan óbeina "strong weak" bendilinn meðan þú heldur einnig utan um drop rökfræði með því að búa til falsa veikleika.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Smíðar nýja tilvísunartölu sneið með innihaldsefninu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Frestað frumstilling:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Býr til nýja tilvísunartölu sneið með frumlausu innihaldi, þar sem minnið er fyllt með `0` bæti.
    ///
    ///
    /// Sjá [`MaybeUninit::zeroed`][zeroed] fyrir dæmi um rétta og ranga notkun á þessari aðferð.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Breytir í `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Eins og með [`MaybeUninit::assume_init`], er það hringjandi að ábyrgjast að innra gildi sé raunverulega í frumstilltu ástandi.
    ///
    /// Að hringja í þetta þegar innihaldið er ekki enn frumstillt veldur óskilgreindri hegðun strax.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Frestað frumstilling:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Breytir í `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Eins og með [`MaybeUninit::assume_init`], er það hringjandi að ábyrgjast að innra gildi sé raunverulega í frumstilltu ástandi.
    ///
    /// Að hringja í þetta þegar innihaldið er ekki enn frumstillt veldur óskilgreindri hegðun strax.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Frestað frumstilling:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Eyðir `Rc` og skilar vafinn bendi.
    ///
    /// Til að koma í veg fyrir minnisleka verður að breyta bendlinum aftur í `Rc` með því að nota [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Býður upp á hráan bendil á gögnin.
    ///
    /// Talningin hefur ekki áhrif á neinn hátt og `Rc` er ekki neytt.
    /// Bendillinn gildir svo lengi sem það eru sterkar talningar í `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // ÖRYGGI: Þetta getur ekki farið í gegnum Deref::deref eða Rc::inner vegna þess
        // þetta er krafist til að halda raw/mut uppruna þannig að td
        // `get_mut` getur skrifað í gegnum bendilinn eftir að Rc er endurheimtur í gegnum `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Smíðar `Rc<T>` úr hráum bendli.
    ///
    /// Hráa bendlinum verður að hafa verið skilað áður með símtali í [`Rc<U>::into_raw`][into_raw] þar sem `U` verður að hafa sömu stærð og röðun og `T`.
    /// Þetta er léttvægt ef `U` er `T`.
    /// Athugaðu að ef `U` er ekki `T` en hefur sömu stærð og aðlögun, þá er þetta í grundvallaratriðum eins og að vísa tilvísunum af mismunandi gerðum.
    /// Sjá [`mem::transmute`][transmute] til að fá frekari upplýsingar um hvaða takmarkanir eiga við í þessu tilfelli.
    ///
    /// Notandi `from_raw` þarf að ganga úr skugga um að tilteknu gildi `T` sé aðeins sleppt einu sinni.
    ///
    /// Þessi aðgerð er óörugg þar sem óviðeigandi notkun getur leitt til óöryggis í minni, jafnvel þótt aldrei sé farið í `Rc<T>` sem skilað er.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Breyttu aftur í `Rc` til að koma í veg fyrir leka.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Frekari símtöl til `Rc::from_raw(x_ptr)` væru minni en ekki örugg.
    /// }
    ///
    /// // Minningin var leyst þegar `x` fór úr gildissviðinu hér að ofan, svo `x_ptr` dinglar nú!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Snúðu móti til að finna upprunalegu RcBox.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Býr til nýjan [`Weak`] bendil við þessa úthlutun.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Gakktu úr skugga um að við búum ekki til dinglandi veika
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Fær fjölda [`Weak`] ábendinga við þessa úthlutun.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Fær fjölda sterkra (`Rc`) vísbendinga við þessa úthlutun.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Skilar `true` ef það eru engin önnur `Rc` eða [`Weak`] vísbendingar við þessa úthlutun.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Skilar breytilegri tilvísun í tiltekna `Rc`, ef engir aðrir `Rc` eða [`Weak`] vísar eru að sömu úthlutun.
    ///
    ///
    /// Skilar [`None`] annars, vegna þess að það er ekki öruggt að stökkbreyta sameiginlegu gildi.
    ///
    /// Sjá einnig [`make_mut`][make_mut], sem mun [`clone`][clone] innra gildi þegar það eru aðrar vísbendingar.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Skilar breytilegri tilvísun í tiltekna `Rc`, án nokkurrar athugunar.
    ///
    /// Sjá einnig [`get_mut`], sem er öruggt og gerir viðeigandi eftirlit.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Ekki má vísa til annarra `Rc` eða [`Weak`] vísbendinga um sömu úthlutun meðan lánið er skilað.
    ///
    /// Þetta er léttvægt ef engar slíkar ábendingar eru til, til dæmis strax eftir `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Við erum varkár að *ekki* búa til tilvísun sem nær yfir "count" reitina, þar sem þetta stangast á við aðgang að tilvísunartölunum (t.d.
        // eftir `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Skilar `true` ef tveir `Rc`s vísa til sömu úthlutunar (í svipuðum dúr og [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Gerir breytanlega tilvísun í tiltekna `Rc`.
    ///
    /// Ef aðrir `Rc` vísar eru að sömu úthlutun þá mun `make_mut` [`clone`] innra gildi í nýja úthlutun til að tryggja einstakt eignarhald.
    /// Þetta er einnig kallað klón við skrif.
    ///
    /// Ef það eru engin önnur `Rc` vísbendingar við þessa úthlutun, þá verða [`Weak`] vísar að þessari úthlutun aftengdir.
    ///
    /// Sjá einnig [`get_mut`], sem mun mistakast frekar en einræktun.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Mun ekki klóna neitt
    /// let mut other_data = Rc::clone(&data);    // Mun ekki klóna innri gögn
    /// *Rc::make_mut(&mut data) += 1;        // Klónar innri gögn
    /// *Rc::make_mut(&mut data) += 1;        // Mun ekki klóna neitt
    /// *Rc::make_mut(&mut other_data) *= 2;  // Mun ekki klóna neitt
    ///
    /// // Nú benda `data` og `other_data` á mismunandi úthlutanir.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] vísbendingar verða aðgreindar:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Verð að klóna gögnin, það eru önnur RC.
            // Úthlutaðu minni til að leyfa að skrifa klóna gildi beint.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Getur bara stolið gögnunum, það eina sem eftir er Weaks
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Fjarlægðu óbeina sterk-veika dómara (engin þörf á að búa til fölsuð veikburða hér-við vitum að aðrir veikir geta hreinsað fyrir okkur)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Þessi óöryggi er í lagi vegna þess að okkur er tryggt að bendillinn sem er skilað er *eini* bendillinn sem einhvern tíma verður skilað til T.
        // Viðmiðunartalning okkar er örugglega 1 á þessum tímapunkti og við gerðum kröfu um að `Rc<T>` sjálft væri `mut`, þannig að við erum að skila einu mögulega tilvísuninni í úthlutunina.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Reyndu að fella `Rc<dyn Any>` niður í steypu gerð.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Úthlutar `RcBox<T>` með nægu rými fyrir hugsanlega óstærð innra gildi þar sem gildið er með uppsetningunni.
    ///
    /// Aðgerðin `mem_to_rcbox` er kölluð með gagnabendlinum og verður að skila aftur (hugsanlega fitu) vísi fyrir `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Reiknið útlitið með því að nota uppgefið gildi.
        // Áður var útlit reiknað á tjáningu `&*(ptr as* const RcBox<T>)`, en þetta skapaði ranga tilvísun (sjá #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Úthlutar `RcBox<T>` með nægu rými fyrir hugsanlega óstærð innra gildi þar sem gildið hefur uppsetninguna, og skilar villu ef úthlutun mistekst.
    ///
    ///
    /// Aðgerðin `mem_to_rcbox` er kölluð með gagnabendlinum og verður að skila aftur (hugsanlega fitu) vísi fyrir `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Reiknið útlitið með því að nota uppgefið gildi.
        // Áður var útlit reiknað á tjáningu `&*(ptr as* const RcBox<T>)`, en þetta skapaði ranga tilvísun (sjá #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Úthluta fyrir skipulag.
        let ptr = allocate(layout)?;

        // Ræsið RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Úthlutar `RcBox<T>` með nægu rými fyrir óstærð innra gildi
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Úthlutaðu fyrir `RcBox<T>` með því að gefa upp gildi.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Afritaðu gildi sem bæti
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Frelsaðu úthlutunina án þess að sleppa innihaldi hennar
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Úthlutar `RcBox<[T]>` með gefinni lengd.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Afritaðu þætti úr sneiðinni í nýúthlutað Rc <\[T\]>
    ///
    /// Óörugg vegna þess að sá sem hringir verður annað hvort að taka eignarhald eða binda `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Smíðar `Rc<[T]>` úr endurtekningu sem vitað er að er af ákveðinni stærð.
    ///
    /// Hegðun er óskilgreind ef stærðin væri röng.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic vörður meðan verið er að klóna T-þætti.
        // Komi til panic falla þættir sem hafa verið skrifaðir í nýju RcBox, þá losnar minnið.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Bendir á fyrsta þáttinn
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Allt á hreinu.Gleymdu vörðunni svo hún losi ekki nýja RcBox.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Sérhæfing trait notuð fyrir `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Sleppir `Rc`.
    ///
    /// Þetta mun lækka sterka viðmiðunartalningu.
    /// Ef sterk viðmiðunartala nær núlli þá eru einu tilvísanirnar (ef einhverjar) [`Weak`], þannig að við `drop` innra gildi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Prentar ekki neitt
    /// drop(foo2);   // Prentar "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // eyðileggja hlutinn sem er að finna
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // fjarlægðu óbeina "strong weak" bendilinn núna þegar við höfum eyðilagt innihaldið.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Gerir klón af `Rc` bendlinum.
    ///
    /// Þetta skapar annan vísi að sömu úthlutun og eykur sterka viðmiðunartalningu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Býr til nýjan `Rc<T>`, með `Default` gildi fyrir `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Reiðhestur til að leyfa sérhæfingu á `Eq` þó að `Eq` sé með aðferð.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Við erum að gera þessa sérhæfingu hér, og ekki sem almennari hagræðing á `&T`, því það myndi annars bæta kostnaði við alla jafnréttisathuganir á dómstólum.
/// Við gerum ráð fyrir að 'Rc' séu notaðir til að geyma stór gildi, sem eru sein til að klóna, en einnig þung til að kanna hvort jafnræði sé, sem veldur því að þessi kostnaður borgar sig auðveldara.
///
/// Það er líka líklegra að hafa tvö `Rc` einrækt, sem benda á sama gildi, en tvö `&T`.
///
/// Við getum aðeins gert þetta þegar `T: Eq` sem `PartialEq` gæti verið vísvitandi óbragð.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Jöfnuður fyrir tvö " Rc`.
    ///
    /// Tvö 'Rc' eru jöfn ef innri gildi þeirra eru jöfn, jafnvel þó að þau séu geymd í mismunandi úthlutun.
    ///
    /// Ef `T` útfærir einnig `Eq` (sem gefur í skyn viðbrögð við jafnrétti) eru tvö " Rc` sem vísa til sömu úthlutunar alltaf jöfn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Ójöfnuður fyrir tvö " RC`.
    ///
    /// Tvö " Rc` eru misjöfn ef innri gildi þeirra eru ójöfn.
    ///
    /// Ef `T` útfærir einnig `Eq` (sem gefur í skyn viðbrögð við jafnrétti) eru tvö " Rc` sem benda til sömu úthlutunar aldrei misjöfn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Hlutaburður fyrir tvo " Rc`.
    ///
    /// Þessir tveir eru bornir saman með því að hringja í `partial_cmp()` á innri gildi þeirra.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Minna en samanburður fyrir tvö " Rc`.
    ///
    /// Þessir tveir eru bornir saman með því að kalla `<` á innri gildi þeirra.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// " Minna en eða jafnt og`samanburður fyrir tvo " Rc`.
    ///
    /// Þessir tveir eru bornir saman með því að hringja í `<=` á innri gildi þeirra.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Meiri en samanburður fyrir tvö " Rc`.
    ///
    /// Þessir tveir eru bornir saman með því að hringja í `>` á innri gildi þeirra.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 'Meiri en eða jafnt og' samanburður fyrir tvo 'Rc'.
    ///
    /// Þessir tveir eru bornir saman með því að hringja í `>=` á innri gildi þeirra.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Samanburður á tveimur " Rc`.
    ///
    /// Þessir tveir eru bornir saman með því að hringja í `cmp()` á innri gildi þeirra.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Úthlutaðu tilvísunartölu sneið og fylltu hana með því að klóna hlutina " v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Úthluta tilvísunartöldum strengjasneið og afrita `v` í hana.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Úthluta tilvísunartöldum strengjasneið og afrita `v` í hana.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Færðu hlut í reit í nýtt, tilvísun talin, úthlutun.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Úthluta tilvísunartölu sneið og færa hluti 'v' inn í hana.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Leyfðu Vec að losa minni sitt en eyðileggja ekki innihald þess
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Tekur hvert frumefni í `Iterator` og safnar því í `Rc<[T]>`.
    ///
    /// # Frammistaðaeinkenni
    ///
    /// ## Almenna málið
    ///
    /// Almennt er söfnun í `Rc<[T]>` gerð með því að safna fyrst í `Vec<T>`.Það er þegar skrifað er eftirfarandi:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// þetta hagar sér eins og við skrifuðum:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Fyrsta úthlutunin gerist hér.
    ///     .into(); // Önnur úthlutun fyrir `Rc<[T]>` gerist hér.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Þetta mun úthluta eins oft og þarf til að smíða `Vec<T>` og þá mun það úthluta einu sinni til að breyta `Vec<T>` í `Rc<[T]>`.
    ///
    ///
    /// ## Iterators af þekktri lengd
    ///
    /// Þegar `Iterator` innleiðir `TrustedLen` og er af nákvæmri stærð, verður úthlutað einni úthlutun fyrir `Rc<[T]>`.Til dæmis:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Hér gerist bara ein úthlutun.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Sérhæfing trait notað til að safna í `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Þetta á við um `TrustedLen` endurtekningu.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // ÖRYGGI: Við verðum að tryggja að endurtekningartækið hafi nákvæma lengd og það höfum við.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Falla aftur að eðlilegri framkvæmd.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` er útgáfa af [`Rc`] sem hefur tilvísun sem ekki er í eigu úthlutunarinnar.Úthlutunin er aðgengileg með því að hringja í [`upgrade`] í `Weak` bendilinn, sem skilar [`Valkost`]`<`[`Rc`] `<T>>`.
///
/// Þar sem `Weak` tilvísun telst ekki til eignarhalds mun það ekki koma í veg fyrir að verðmæti sem eru geymd í úthlutuninni falli niður og `Weak` sjálft gefur engar ábyrgðir fyrir því að verðmæti sé enn til staðar.
/// Þannig getur það skilað [`None`] þegar ["uppfærsla"] d.
/// Athugaðu þó að `Weak` tilvísun * kemur í veg fyrir að úthlutunin sjálf (bakverslunin) verði framseld.
///
/// `Weak` bendill er gagnlegur til að halda tímabundinni tilvísun í úthlutunina sem [`Rc`] stýrir án þess að koma í veg fyrir að innra gildi hans falli niður.
/// Það er einnig notað til að koma í veg fyrir hringlaga tilvísanir á milli [`Rc`] ábendinga, þar sem gagnkvæmar tilvísanir eiga aldrei að leyfa neinum að falla frá [`Rc`].
/// Til dæmis gæti tré haft sterka [`Rc`] vísbendingar frá foreldrahnútum til barna og `Weak` vísbendingar frá börnum aftur til foreldra sinna.
///
/// Dæmigerð leið til að fá `Weak` bendi er að hringja í [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Þetta er `NonNull` til að leyfa fínstillingu á stærð þessarar tegundar í enums, en það er ekki endilega gildur bendill.
    //
    // `Weak::new` stillir þetta á `usize::MAX` þannig að það þarf ekki að úthluta plássi á hrúgunni.
    // Það er ekki gildi sem raunverulegur bendill mun nokkru sinni hafa því RcBox er með jöfnun að minnsta kosti 2.
    // Þetta er aðeins mögulegt þegar `T: Sized`;óstærð `T` dingla aldrei.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Smíðar nýjan `Weak<T>`, án þess að úthluta minni.
    /// Að hringja í [`upgrade`] á skilagildinu gefur alltaf [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Hjálpargerð til að leyfa aðgang að tilvísunartölunum án þess að fullyrða um gagnareitinn.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Skilar hráum bendli á hlutinn `T` sem þessi `Weak<T>` bendir á.
    ///
    /// Bendillinn er aðeins gildur ef það eru nokkrar sterkar tilvísanir.
    /// Bendillinn getur verið dinglandi, ósamstilltur eða jafnvel [`null`] annars.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Báðir benda á sama hlutinn
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Hinn sterki hér heldur því lifandi, svo við getum enn nálgast hlutinn.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // En ekki meira.
    /// // Við getum gert weak.as_ptr() en aðgangur að bendlinum myndi leiða til óskilgreindrar hegðunar.
    /// // assert_eq! (" halló`, óöruggur {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Ef bendillinn er dinglandi skilar við sentinel beint.
            // Þetta getur ekki verið gilt álagsföng, þar sem álagið er að minnsta kosti jafnast á við RcBox (usize).
            ptr as *const T
        } else {
            // ÖRYGGI: ef is_dangling skilar fölsku, þá er hægt að vísa bendilinn.
            // Notkunarálagið gæti fallið niður á þessum tímapunkti og við verðum að halda uppruna, svo notaðu hráan bendilinn.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Eyðir `Weak<T>` og breytir því í hráan bendil.
    ///
    /// Þetta breytir veikum músinni í hráan bendilinn, en samt sem áður varðveitir eignarhald einnar veikrar tilvísunar (veiku talningunni er ekki breytt með þessari aðgerð).
    /// Það er hægt að breyta því aftur í `Weak<T>` með [`from_raw`].
    ///
    /// Sömu takmarkanir á aðgangi að marki bendilsins og við [`as_ptr`] eiga við.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Breytir hráum bendli sem áður var búinn til af [`into_raw`] aftur í `Weak<T>`.
    ///
    /// Þetta er hægt að nota til að fá sterka tilvísun á öruggan hátt (með því að hringja í [`upgrade`] seinna) eða til að samræma veikan fjölda með því að sleppa `Weak<T>`.
    ///
    /// Það tekur eignarhald á einni veikri tilvísun (að undanskildum ábendingum búin til af [`new`], þar sem þessir eiga ekki neitt; aðferðin virkar ennþá á þeim).
    ///
    /// # Safety
    ///
    /// Bendillinn hlýtur að vera upprunninn frá [`into_raw`] og verður samt að eiga mögulega veikan tilvísun.
    ///
    /// Það er leyfilegt að sterka talningin sé 0 þegar hringt er í þetta.
    /// Engu að síður tekur þetta eignarhald á einni veikri tilvísun sem nú er táknað sem hrá bendill (veiku talningunni er ekki breytt með þessari aðgerð) og því verður að para hana við fyrra símtal í [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Lækkaðu síðustu veiku talninguna.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Sjá Weak::as_ptr fyrir samhengi um hvernig innsláttarbendillinn er fenginn.

        let ptr = if is_dangling(ptr as *mut T) {
            // Þetta er dinglandi veikt.
            ptr as *mut RcBox<T>
        } else {
            // Annars er okkur tryggt að bendillinn kom frá ótengdum veikleika.
            // ÖRYGGI: óhætt er að hringja í data_offset, þar sem ptr vísar til raunverulegs (hugsanlega lækkaðs) T.
            let offset = unsafe { data_offset(ptr) };
            // Þannig snúum við mótinu við til að fá alla RcBox.
            // ÖRYGGI: bendillinn er upprunninn frá veiku, svo þessi offset er örugg.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // ÖRYGGI: við höfum nú endurheimt upprunalega Veika bendilinn, svo við getum búið til Veika.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Reynir að uppfæra `Weak` bendilinn í [`Rc`] og seinka lækkun á innra gildi ef vel tekst til.
    ///
    ///
    /// Skilar [`None`] ef innra gildi hefur síðan verið lækkað.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Eyðileggja allar sterkar ábendingar.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Fær fjölda sterkra (`Rc`) ábendinga sem benda á þessa úthlutun.
    ///
    /// Ef `self` var búið til með því að nota [`Weak::new`] mun það skila 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Fær fjölda `Weak` ábendinga sem benda á þessa úthlutun.
    ///
    /// Ef engar sterkar vísbendingar eru eftir skilar þetta núllinu.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // draga frá óbeina veiku ptr
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Skilar `None` þegar bendillinn hangir og enginn `RcBox` er úthlutað (þ.e. þegar þessi `Weak` var búinn til af `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Við erum varkár að *ekki* búa til tilvísun sem nær yfir "data" reitinn, þar sem mögulega er breytt stöður á svæðinu (til dæmis, ef síðasti `Rc` er sleppt, verður gagnareitnum sleppt á sínum stað).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Skilar `true` ef hinir " veiku` benda til sömu úthlutunar (svipað og [`ptr::eq`]), eða ef báðir benda ekki á neina úthlutun (vegna þess að þeir voru stofnaðir með `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Þar sem þetta ber saman ábendingar þýðir það að `Weak::new()` muni jafna hvort annað, jafnvel þó að þeir bendi ekki á neina úthlutun.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Samanburður á `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Sleppir `Weak` bendlinum.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Prentar ekki neitt
    /// drop(foo);        // Prentar "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // veika talningin byrjar á 1 og fer aðeins í núll ef allir sterku ábendingarnar eru horfnar.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Býr til klón af `Weak` bendlinum sem vísar til sömu úthlutunar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Smíðar nýjan `Weak<T>` og úthlutar minni fyrir `T` án þess að frumstilla það.
    /// Að hringja í [`upgrade`] á skilagildinu gefur alltaf [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Við athuguðum_bættu hér til að takast á við mem::forget á öruggan hátt.Sérstaklega
// ef þú mem::forget Rcs (eða Weaks), getur talningin endurnýjað og þá geturðu losað úthlutunina meðan framúrskarandi Rcs (eða Weaks) eru til.
//
// Við hættir vegna þess að þetta er svo úrkynjuð atburðarás að okkur er sama um hvað gerist-ekkert raunverulegt forrit ætti nokkru sinni að upplifa þetta.
//
// Þetta ætti að hafa hverfandi kostnað þar sem þú þarft í raun ekki að klóna þetta mikið í Rust þökk sé eignarhaldi og merkingarfræði.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Við viljum hætta við flæði í stað þess að sleppa gildinu.
        // Viðmiðunartalningin verður aldrei núll þegar þetta er kallað;
        // engu að síður setjum við inn fóstureyðingu hér til að gefa vísbendingu um LLVM um annars misst af hagræðingu.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Við viljum hætta við flæði í stað þess að sleppa gildinu.
        // Viðmiðunartalningin verður aldrei núll þegar þetta er kallað;
        // engu að síður setjum við inn fóstureyðingu hér til að gefa vísbendingu um LLVM um annars misst af hagræðingu.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Fáðu offset innan `RcBox` fyrir álagið á bak við bendi.
///
/// # Safety
///
/// Bendillinn verður að benda á (og hafa gild lýsigögn fyrir) áður gilt dæmi um T, en leyfa að sleppa T.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Stilltu óstærða gildið að lokum RcBox.
    // Þar sem RcBox er repr(C) verður það alltaf síðasti reiturinn í minni.
    // ÖRYGGI: þar sem einu óstærðu gerðirnar mögulegar eru sneiðar, trait hlutir,
    // og utanaðkomandi gerðir, kröfur um inntak öryggis nægja sem stendur til að fullnægja kröfum align_of_val_raw;þetta er útfærsluatriði tungumálsins sem ekki er hægt að reiða sig á utan std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}