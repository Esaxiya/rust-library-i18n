//! Hjálpartæki til að forsníða og prenta " String`.
//!
//! Þessi eining inniheldur stuðning við keyrslutíma [`format!`] setningafræðilegrar viðbótar.
//! Þetta fjölvi er útfært í þýðandanum til að senda frá sér símtöl í þessa einingu til að sníða rök í keyrslu í strengi.
//!
//! # Usage
//!
//! [`format!`] fjölvi er ætlað að vera kunnugur þeim sem koma frá `printf`/`fprintf` aðgerðum C eða `str.format` aðgerð Python.
//!
//! Nokkur dæmi um [`format!`] viðbótina eru:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" með leiðandi núllum
//! ```
//!
//! Af þessum geturðu séð að fyrstu rökin eru sniðstrengur.Það er krafist af þýðandanum að þetta sé strengjabókstafur;það getur ekki verið breyta sem send er inn (til þess að framkvæma gildi athugun).
//! Þáttaraðili mun síðan flokka sniðstrenginn og ákvarða hvort listinn yfir rökin sem gefin eru henti til að fara í þennan sniðstreng.
//!
//! Notaðu [`to_string`] aðferðina til að breyta einu gildi í streng.Þetta mun nota [`Display`] sniðið trait.
//!
//! ## Stöðufæribreytur
//!
//! Hvert sniðröksemd er leyft að tilgreina hvaða gildisröksemdir það vísar til og ef þeim er sleppt er talið að það sé "the next argument".
//! Til dæmis myndi sniðstrengurinn `{} {} {}` taka þrjár breytur og þær yrðu forsniðnar í sömu röð og þeim var gefin.
//! Sniðstrengurinn `{2} {1} {0}` myndi hins vegar sníða rök í öfugri röð.
//!
//! Hlutirnir geta orðið svolítið erfiðar þegar þú byrjar að blanda saman tvenns konar stöðutilgreiningum.Hægt er að hugsa um "next argument" skilgreininguna sem endurtekningu á rökunum.
//! Í hvert skipti sem "next argument" skilgreiningarmaður sést, gengur endurtekningin áfram.Þetta leiðir til svona hegðunar:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Innri endurtekningunni vegna rökræðunnar hefur ekki verið komið fram þegar fyrsti `{}` sést, þannig að það prentar fyrstu rökin.Þegar endurtekningunni hefur verið náð í seinni `{}` hefur hún farið fram á síðari rökin.
//! Í meginatriðum hafa breytur sem nefna rök þeirra gagngert ekki áhrif á breytur sem nefna ekki rök hvað varðar staðsetningarskilgreiningar.
//!
//! Sniðstrengur er nauðsynlegur til að nota öll rök þess, annars er það villa um samantekt.Þú getur vísað til sömu rök oftar en einu sinni í sniðstrengnum.
//!
//! ## Nafngreindar breytur
//!
//! Rust sjálft hefur ekki Python-ígildi nafngreindra breytna við aðgerð, en [`format!`] fjölvi er setningafræðileg viðbót sem gerir það kleift að nýta nafngreindar breytur.
//! Nafngreindar breytur eru taldar upp í lok röklistans og hafa setningafræði:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Til dæmis nota eftirfarandi [`format!`] orðasambönd öll nafngreind rök:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Það er ekki rétt að setja staðsetningarfæribreytur (þær án nafna) á eftir rökum sem hafa nöfn.Eins og með staðsetningarfæribreytur, er það ekki gilt að leggja fram nafngreinda breytur sem eru ónotaðar af sniðstrengnum.
//!
//! # Sniðfæribreytur
//!
//! Hægt er að breyta hverri röksemdafærslu með fjölda sniðfæribreytna (sem svara til `format_spec` í [the syntax](#syntax)). Þessar breytur hafa áhrif á framsetningu strengsins á því sem verið er að forsníða.
//!
//! ## Width
//!
//! ```
//! // Allir þessir prenta "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Þetta er breytu fyrir "minimum width" sem sniðið ætti að taka upp.
//! Ef strengur gildisins fyllir ekki upp þessa miklu stafi, þá verður padding sem tilgreint er af fill/alignment notað til að taka upp það pláss sem þarf (sjá hér að neðan).
//!
//! Gildið fyrir breiddina er einnig hægt að veita sem [`usize`] í breytalistanum með því að bæta við postfix `$`, sem gefur til kynna að seinni rökin séu [`usize`] sem tilgreinir breiddina.
//!
//! Að vísa til rök með setningafræði dollarans hefur ekki áhrif á "next argument" teljarann, svo það er venjulega góð hugmynd að vísa í rök eftir stöðu eða nota nafngreind rök.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Valfrjáls fyllingarpersóna og uppröðun er venjulega gefin í tengslum við [`width`](#width) breytuna.Það verður að skilgreina fyrir `width`, rétt á eftir `:`.
//! Þetta gefur til kynna að ef gildið sem verið er að forsníða er minna en `width` verði einhverjir auka stafir prentaðir utan um það.
//! Fylling kemur í eftirfarandi afbrigðum fyrir mismunandi uppröðun:
//!
//! * `[fill]<` - rökin eru vinstri stillt í `width` dálkum
//! * `[fill]^` - rökin eru miðjuð í `width` dálkum
//! * `[fill]>` - röksemdafærslan er í réttri röð í `width` dálkum
//!
//! Sjálfgefið [fill/alignment](#fillalignment) fyrir ekki tölur er bil og vinstri.Sjálfgefið fyrir tölusniðara er einnig bilstafur en með hægri jöfnun.
//! Ef `0` fáninn (sjá hér að neðan) er tilgreindur fyrir tölur, þá er óbeina fyllingarstafinn `0`.
//!
//! Athugaðu að ekki er víst að útfærsla sé af einhverjum gerðum.Sérstaklega er það almennt ekki útfært fyrir `Debug` trait.
//! Góð leið til að tryggja að padding sé notuð er að forsníða innsláttinn og púða síðan strenginn sem myndast til að fá framleiðsluna:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Halló Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Þetta eru allt fánar sem breyta hegðun sniðsmannsins.
//!
//! * `+` - Þetta er ætlað fyrir tölulegar gerðir og gefur til kynna að merkið eigi alltaf að vera prentað.Jákvæð skilti eru aldrei prentuð sjálfgefið og neikvæða skiltið er aðeins prentað sjálfgefið fyrir `Signed` trait.
//! Þessi fáni gefur til kynna að alltaf eigi að prenta rétt skilti (`+` eða `-`).
//! * `-` - Eins og er ekki notað
//! * `#` - Þessi fáni gefur til kynna að nota eigi "alternate" form prentunar.Varamyndirnar eru:
//!     * `#?` - prentaðu [`Debug`] sniðið fallega
//!     * `#x` - á undan rökunum með `0x`
//!     * `#X` - á undan rökunum með `0x`
//!     * `#b` - á undan rökunum með `0b`
//!     * `#o` - á undan rökunum með `0o`
//! * `0` - Þetta er notað til að gefa til kynna fyrir heiltölusnið að bólstrunin að `width` ætti bæði að vera með `0` staf auk þess að vera meðvituð um tákn.
//! Snið eins og `{:08}` myndi skila `00000001` fyrir heiltöluna `1`, en sama snið myndi skila `-0000001` fyrir heiltöluna `-1`.
//! Takið eftir að neikvæða útgáfan er með færri núll en jákvæða útgáfan.
//!         Athugið að núll með bólstrun er alltaf sett á eftir skiltinu (ef það er) og fyrir tölustafina.Þegar það er notað ásamt `#` fánanum gildir svipuð regla: bólstrun núll er sett inn á eftir forskeytinu en á undan tölustöfunum.
//!         Forskeytið er innifalið í heildarbreiddinni.
//!
//! ## Precision
//!
//! Fyrir tegundir sem ekki eru tölulegar getur þetta talist "maximum width".
//! Ef strengurinn sem myndast er lengri en þessi breidd, þá er hann styttur niður í þessa miklu stafi og það stytta gildi er gefið út með réttum `fill`, `alignment` og `width` ef þessar breytur eru stilltar.
//!
//! Fyrir óaðskiljanlegar gerðir er þetta hunsað.
//!
//! Fyrir tegundir fljótandi punkta gefur það til kynna hversu marga tölustafi á eftir aukastafnum ætti að vera prentaður.
//!
//! Það eru þrjár leiðir til að tilgreina viðkomandi `precision`:
//!
//! 1. Heiltala `.N`:
//!
//!    heiltalan `N` sjálft er nákvæmnin.
//!
//! 2. Heiltala eða nafn á eftir dollaramerki `.N$`:
//!
//!    notaðu snið *rök*`N` (sem verður að vera `usize`) sem nákvæmni.
//!
//! 3. Stjarna `.*`:
//!
//!    `.*` þýðir að þessi `{...}` er tengdur við *tvö* snið inntak frekar en eitt: fyrsta inntakið hefur `usize` nákvæmni, og annað heldur gildi til að prenta.
//!    Athugaðu að í þessu tilfelli, ef maður notar sniðstrenginn `{<arg>:<spec>.*}`, þá vísar `<arg>` hlutinn til* gildisins * til að prenta og `precision` verður að koma í inntakinu á undan `<arg>`.
//!
//! Til dæmis prenta eftirfarandi símtöl öll það sama `Hello x is 0.01000`:
//!
//! ```
//! // Halló {arg 0 ("x")} er {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Halló {arg 1 ("x")} er {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Halló {arg 0 ("x")} er {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Halló {next arg ("x")} er {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Halló {next arg ("x")} er {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Halló {next arg ("x")} er {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Þó að þessi:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! prentaðu þrjá verulega mismunandi hluti:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Í sumum forritunarmálum fer hegðun sniðiaðgerða eftir staðsetningar stýrikerfisins.
//! Sniðaðgerðirnar sem eru veittar af venjulegu bókasafni Rust hafa ekki neina hugmynd um landsvæði og munu skila sömu niðurstöðum á öllum kerfum óháð notendastillingum.
//!
//! Til dæmis mun eftirfarandi kóði alltaf prenta `1.5`, jafnvel þó að landsvæði kerfisins noti annan aukastaf aðskilnað en punkt.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Bókstafirnir `{` og `}` geta verið með í streng með því að fara á undan þeim með sama staf.Til dæmis sleppur `{` stafurinn með `{{` og `}` stafurinn slapp með `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Til samanburðar má finna hér málfræði sniðstrengja í heild sinni.
//! Setningafræði sniðmálsins sem notað er er dregið af öðrum tungumálum, svo það ætti ekki að vera of framandi.Rök eru sniðin með Python-eins setningafræði, sem þýðir að rök eru umkringd `{}` í stað C-eins `%`.
//! Raunveruleg málfræði fyrir setningafræði sniðsins er:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Í ofangreindum málfræði, `text` má ekki innihalda neina `'{'` eða `'}'` stafi.
//!
//! # Snið traits
//!
//! Þegar þú ert að biðja um að rök verði sniðin með tiltekinni gerð, þá ertu í raun að biðja um að rök séu rakin til ákveðinnar trait.
//! Þetta gerir kleift að forsníða margar raunverulegar gerðir í gegnum `{:x}` (eins og [`i8`] sem og [`isize`]).Núverandi kortagerð gerða við traits er:
//!
//! * *ekkert* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] með lágstöfum hexadecimal heiltölum
//! * `X?` ⇒ [`Debug`] með stærri sex-og sextölum
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Hvað þetta þýðir er að hvers konar rök sem útfæra [`fmt::Binary`][`Binary`] trait er síðan hægt að forsníða með `{:b}`.Útfærsla er veitt fyrir þessa traits fyrir fjölda frumstæðra gerða af venjulegu bókasafninu.
//!
//! Ef ekkert snið er tilgreint (eins og í `{}` eða `{:6}`), þá er sniðið trait sem notað er [`Display`] trait.
//!
//! Þegar þú innleiðir snið trait fyrir þína eigin gerð verður þú að innleiða aðferð við undirskriftina:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // sérsniðna gerð okkar
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Tegundin þín verður send sem `self` tilvísun og þá ætti aðgerðin að senda frá sér framleiðslu í `f.buf` strauminn.Það er í hverju sniði trait útfærslu að fylgja rétt umbeðnum sniðbreytum.
//! Gildi þessara breytna verða skráð í reitina í [`Formatter`] uppbyggingu.Til þess að hjálpa við þetta veitir [`Formatter`] struct einnig nokkrar hjálparaðferðir.
//!
//! Að auki er skilagildi þessarar aðgerðar [`fmt::Result`] sem er gerð alias [`Result`]`<(),`[`std: : fmt::Error`] `>`.
//! Snið útfærslna ætti að tryggja að þær fjölgi villum frá [`Formatter`] (td þegar hringt er í [`write!`]).
//! Hins vegar ættu þeir aldrei að skila villum með ósannindum.
//! Það er að innleiða snið verður aðeins að skila villu ef [`Formatter`] sem er sent inn skilar villu.
//! Þetta er vegna þess að öfugt við það sem undirskrift virkninnar gæti bent til, er sniðssnið óskeikul aðgerð.
//! Þessi aðgerð skilar eingöngu niðurstöðu vegna þess að skrif í undirliggjandi straum gæti mistekist og það verður að veita leið til að fjölga þeirri staðreynd að villa hefur komið upp aftur upp í stafla.
//!
//! Dæmi um útfærslu á formun traits myndi líta út eins og:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // `f` gildi útfærir `Write` trait, sem er það sem skrifað er!þjóðhagslegur er að vænta.
//!         // Athugið að þetta snið hunsar hina ýmsu fána sem gefnir eru til að sníða strengi.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Mismunandi traits leyfa mismunandi framleiðslu af gerðinni.
//! // Merking þessa sniðs er að prenta stærð vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Virðið sniðfánana með því að nota hjálparaðferðina `pad_integral` á Formatter hlutnum.
//!         // Sjá leiðbeiningar um aðferðir til að fá frekari upplýsingar og hægt er að nota aðgerðina `pad` til að binda strengi.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` á móti `fmt::Debug`
//!
//! Þessi tvö snið traits hafa sérstakan tilgang:
//!
//! - [`fmt::Display`][`Display`] útfærslur fullyrða að hægt sé að tákna tegundina dyggilega sem UTF-8 streng á öllum tímum.Það er **ekki** búist við að allar gerðir innleiði [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] útfærslur ættu að vera framkvæmdar fyrir **allar** opinberar gerðir.
//!   Framleiðsla mun venjulega tákna innra ástandið eins dyggilega og mögulegt er.
//!   Tilgangur [`Debug`] trait er að auðvelda kembiforrit Rust kóða.Í flestum tilfellum er fullnægjandi og mælt með notkun `#[derive(Debug)]`.
//!
//! Nokkur dæmi um framleiðsluna frá báðum traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Tengt fjölva
//!
//! Það eru fjöldi tengdra fjölva í [`format!`] fjölskyldunni.Þau sem nú eru framkvæmd eru:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Þetta og [`writeln!`] eru tveir fjölvi sem notaðir eru til að senda frá sér sniðstrenginn í tiltekinn straum.Þetta er notað til að koma í veg fyrir milliflutninga sniðstrengja og í staðinn skrifa framleiðsluna beint.
//! Undir hettunni kallar þessi aðgerð í raun á [`write_fmt`] aðgerðina sem skilgreind er á [`std::io::Write`] trait.
//! Dæmi um notkun er:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Þetta og [`println!`] senda frá sér framleiðsluna til stdout.Á svipaðan hátt og [`write!`] fjölvi er markmið þessara fjölva að forðast milliflutninga þegar prentað er.Dæmi um notkun er:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! [`eprint!`] og [`eprintln!`] fjölvi eru eins og [`print!`] og [`println!`], hvort um sig, nema þeir senda frá sér framleiðsluna til stderr.
//!
//! ### `format_args!`
//!
//! Þetta er forvitnilegt makró sem notað er til að fara örugglega um ógegnsæjan hlut sem lýsir sniðstrengnum.Þessi hlutur þarf ekki neina hrúgaúthlutun til að búa til og hann vísar aðeins til upplýsinga á staflinum.
//! Undir hettunni eru allir tengdir fjölvi útfærðir með tilliti til þessa.
//! Í fyrsta lagi er nokkur dæmi um notkun:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Niðurstaðan af [`format_args!`] fjölvi er gildi af gerðinni [`fmt::Arguments`].
//! Þessa uppbyggingu er síðan hægt að fara í [`write`] og [`format`] virka inni í þessari einingu til að vinna úr sniðstrengnum.
//! Markmið þessa fjölva er að koma enn frekar í veg fyrir milliliðadreifingar þegar verið er að sníða strengi.
//!
//! Til dæmis gæti skógarhöggssafn notað hefðbundna setningafræði, en það myndi fara innan um þessa uppbyggingu þar til búið er að ákvarða hvert framleiðsla ætti að fara.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Aðgerðin `format` tekur [`Arguments`] strúktúr og skilar sniðinu sem myndast.
///
///
/// [`Arguments`] tilvikið er hægt að búa til með [`format_args!`] fjölvi.
///
/// # Examples
///
/// Grunn notkun:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Athugaðu að það gæti verið æskilegt að nota [`format!`].
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}