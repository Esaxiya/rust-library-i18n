//! UTF-8 kóðuð, ræktanlegur strengur.
//!
//! Þessi eining inniheldur [`String`] gerðina, [`ToString`] trait til að umbreyta í strengi og nokkrar villutegundir sem geta stafað af því að vinna með [`String`] s.
//!
//!
//! # Examples
//!
//! Það eru margar leiðir til að búa til nýjan [`String`] úr strengjabókstaf:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Þú getur búið til nýjan [`String`] úr núverandi með því að tengja við
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Ef þú ert með vector með gild UTF-8 bæti geturðu búið til [`String`] úr því.Þú getur líka gert öfugt.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Við vitum að þessi bæti eru gild, svo við munum nota `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// UTF-8 kóðuð, ræktanlegur strengur.
///
/// `String` tegundin er algengasta strengategundin sem hefur eignarhald yfir innihaldi strengsins.Það hefur náið samband við lánaðan hliðstæðu sinn, frumstæðan [`str`].
///
/// # Examples
///
/// Þú getur búið til `String` úr [a literal string][`str`] með [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Þú getur bætt [`char`] við `String` með [`push`] aðferðinni og bætt [`&str`] með [`push_str`] aðferðinni:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Ef þú ert með vector af UTF-8 bæti geturðu búið til `String` úr henni með [`from_utf8`] aðferðinni:
///
/// ```
/// // nokkur bæti, í vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Við vitum að þessi bæti eru gild, svo við munum nota `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// " Strengir` eru alltaf gildir UTF-8.Þetta hefur nokkrar afleiðingar og sú fyrsta er sú að ef þú þarft ekki UTF-8 streng, þá skaltu íhuga [`OsString`].Það er svipað en án UTF-8 þvingunar.Önnur afleiðingin er sú að þú getur ekki verðtryggt í `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Verðtrygging er ætlað að vera stöðug aðgerð, en UTF-8 kóðun leyfir okkur ekki að gera þetta.Ennfremur er ekki ljóst hvers konar hlutur vísitalan ætti að skila: bæti, kóðapunkt eða grafemþyrping.
/// [`bytes`] og [`chars`] aðferðirnar skila endurtekningum yfir fyrstu tvær, hver um sig.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// " String`s implement [` Deref`]`<Target=str>`, og erfa svo allar [[str`] aðferðir.Að auki þýðir þetta að þú getur sent `String` yfir í aðgerð sem tekur [`&str`] með því að nota stafsand (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Þetta mun búa til [`&str`] úr `String` og senda það inn. Þessi umbreyting er mjög ódýr, og svo almennt munu aðgerðir samþykkja [`&str`] sem rök nema þær þurfi `String` af einhverjum sérstökum ástæðum.
///
/// Í vissum tilvikum hefur Rust ekki nægar upplýsingar til að gera þessa umbreytingu, þekkt sem [`Deref`] þvingun.Í eftirfarandi dæmi útfærir strengsneið [`&'a str`][`&str`] trait `TraitExample` og fallið `example_func` tekur allt sem útfærir trait.
/// Í þessu tilfelli þarf Rust að gera tvær óbeinar umbreytingar, sem Rust hefur ekki burði til að gera.
/// Af þeim sökum verður ekki tekið saman eftirfarandi dæmi.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Það eru tveir möguleikar sem myndu virka í staðinn.Sú fyrsta væri að breyta línunni `example_func(&example_string);` í `example_func(example_string.as_str());` og nota aðferðina [`as_str()`] til að draga sérstaklega fram strengjasneiðina sem inniheldur strenginn.
/// Önnur leiðin breytir `example_func(&example_string);` í `example_func(&*example_string);`.
/// Í þessu tilfelli erum við að vísa `String` til [`str`][`&str`] og vísa síðan til [`str`][`&str`] aftur í [`&str`].
/// Önnur leiðin er máltækari, en bæði vinna að því að gera umbreytinguna gagngert frekar en að treysta á óbeina ummyndunina.
///
/// # Representation
///
/// `String` samanstendur af þremur hlutum: bendi á nokkur bæti, lengd og getu.Bendillinn bendir á innri biðminni sem `String` notar til að geyma gögn sín.Lengdin er fjöldi bæti sem nú er geymdur í biðminni og afkastagetan er stærð biðminni í bæti.
///
/// Sem slík verður lengdin alltaf minni en eða jöfn getu.
///
/// Þessi biðminni er alltaf geymdur á hrúgunni.
///
/// Þú getur skoðað þetta með [`as_ptr`], [`len`] og [`capacity`] aðferðum:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Uppfærðu þetta þegar vec_into_raw_parts er stöðugt.
/// // Koma í veg fyrir að gögn strengsins falli sjálfkrafa niður
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // sagan hefur nítján bæti
/// assert_eq!(19, len);
///
/// // Við getum endurbyggt streng úr ptr, len og getu.
/// // Þetta er allt óöruggt vegna þess að við erum ábyrg fyrir því að íhlutirnir séu gildir:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Ef `String` hefur næga afkastagetu, mun úthlutun þætti við það ekki endurúthluta.Til dæmis, íhugaðu þetta forrit:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Þetta skilar eftirfarandi:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Í fyrstu höfum við engu minni úthlutað yfirleitt, en þegar við bætum við strenginn eykur það getu hans á viðeigandi hátt.Ef við notum þess í stað [`with_capacity`] aðferðina til að úthluta réttri getu fyrst:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Við endum með aðra framleiðslu:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Hér er engin þörf á að úthluta meira minni innan lykkjunnar.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Mögulegt villugildi þegar `String` er breytt úr UTF-8 bæti vector.
///
/// Þessi tegund er villutegund fyrir [`from_utf8`] aðferðina á [`String`].
/// Það er hannað á þann hátt að forðast vandlega endurúthlutanir: [`into_bytes`] aðferðin mun skila aftur bætunni vector sem notuð var í breytingartilrauninni.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// [`Utf8Error`] tegundin sem [`std::str`] býður upp á táknar villu sem kann að eiga sér stað þegar breyta á sneið af [`u8`] í [`&str`].
/// Að þessu leyti er það hliðstætt `FromUtf8Error` og þú getur fengið einn frá `FromUtf8Error` með [`utf8_error`] aðferðinni.
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Grunn notkun:
///
/// ```
/// // nokkur ógild bæti, í vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Mögulegt villugildi þegar `String` er breytt úr UTF-16 bæti sneið.
///
/// Þessi tegund er villutegund fyrir [`from_utf16`] aðferðina á [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Grunn notkun:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Býr til nýjan tóman `String`.
    ///
    /// Í ljósi þess að `String` er tómur úthlutar þetta engum upphaflegum biðminni.Þó að það þýði að þessi upphafsaðgerð sé mjög ódýr, getur það valdið óhóflegri úthlutun síðar þegar þú bætir við gögnum.
    ///
    /// Ef þú hefur hugmynd um hversu mikið gögn `String` mun geyma skaltu íhuga [`with_capacity`] aðferðina til að koma í veg fyrir of mikla endurúthlutun.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Býr til nýjan tóman `String` með tiltekna getu.
    ///
    /// Strengir hafa innri biðminni til að geyma gögnin sín.
    /// Getan er lengd þess biðminni og hægt er að spyrja hana með [`capacity`] aðferðinni.
    /// Þessi aðferð býr til tómt `String`, en eitt með upphaflegu biðminni sem getur geymt `capacity` bæti.
    /// Þetta er gagnlegt þegar þú gætir verið að bæta fullt af gögnum við `String` og fækka endurúthlutunum sem það þarf að gera.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Ef gefin getu er `0`, mun engin úthlutun eiga sér stað og þessi aðferð er eins og [`new`] aðferðin.
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // Strengurinn inniheldur engar bleikjur, jafnvel þó að það hafi getu til meira
    /// assert_eq!(s.len(), 0);
    ///
    /// // Þetta er allt gert án þess að endurúthluta ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... en þetta getur gert strenginn endurúthlutað
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): með cfg(test) er ekki tiltæk innbyggð `[T]::to_vec` aðferð, sem krafist er fyrir þessa skilgreiningu aðferðar.
    // Þar sem við þurfum ekki þessa aðferð í prófunarskyni mun ég bara stúta henni. NB sjá slice::hack mát í slice.rs til að fá frekari upplýsingar
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Breytir vector af bæti í `String`.
    ///
    /// Strengur ([`String`]) er búinn til úr bæti ([`u8`]) og vector af bæti ([`Vec<u8>`]) er úr bæti, þannig að þessi aðgerð breytist á milli þessara tveggja.
    /// Ekki eru allar byte sneiðar gildar 'Strengir', þó: `String` krefst þess að það sé gilt UTF-8.
    /// `from_utf8()` athugar til að tryggja að bætin séu gild UTF-8, og gerir þá umbreytinguna.
    ///
    /// Ef þú ert viss um að byte sneiðin sé gild UTF-8 og þú vilt ekki verða fyrir kostnaði við gildisathugunina, þá er til óörugg útgáfa af þessari aðgerð, [`from_utf8_unchecked`], sem hefur sömu hegðun en sleppir athuguninni.
    ///
    ///
    /// Þessi aðferð mun gæta þess að afrita ekki vector, til hagræðingar.
    ///
    /// Ef þú þarft [`&str`] í stað `String` skaltu íhuga [`str::from_utf8`].
    ///
    /// Andhverfa þessarar aðferðar er [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Skilar [`Err`] ef sneiðin er ekki UTF-8 með lýsingu á því hvers vegna bætin eru ekki UTF-8.vector sem þú fluttir inn er einnig með.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// // nokkur bæti, í vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Við vitum að þessi bæti eru gild, svo við munum nota `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Rangt bæti:
    ///
    /// ```
    /// // nokkur ógild bæti, í vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Sjá skjöl fyrir [`FromUtf8Error`] til að fá frekari upplýsingar um hvað þú getur gert við þessa villu.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Breytir stykki af bæti í streng, þar á meðal ógilda stafi.
    ///
    /// Strengir eru gerðir úr bæti ([`u8`]) og hluti af bæti ([`&[u8]`][byteslice]) er úr bæti, þannig að þessi aðgerð breytist á milli þessara tveggja.Ekki eru allar bítasneiðar gildar strengir, þó: strengir þurfa að vera gildir UTF-8.
    /// Við þessa umbreytingu kemur `from_utf8_lossy()` í stað allra ógildra UTF-8 raða fyrir [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], sem lítur svona út:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Ef þú ert viss um að byte sneiðin sé gild UTF-8, og þú vilt ekki stofna til kostnaðar við viðskiptin, þá er til óörugg útgáfa af þessari aðgerð, [`from_utf8_unchecked`], sem hefur sömu hegðun en sleppir tékkunum.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Þessi aðgerð skilar [`Cow<'a, str>`].Ef byte sneiðin okkar er ógild UTF-8, þá verðum við að setja inn skiptitáknin, sem munu breyta stærð strengsins og þurfa þess vegna `String`.
    /// En ef það er þegar í gildi UTF-8, þurfum við ekki nýja úthlutun.
    /// Þessi skilagrein gerir okkur kleift að sinna báðum málum.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// // nokkur bæti, í vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Rangt bæti:
    ///
    /// ```
    /// // nokkur ógild bæti
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Afkóða UTF-16 kóðuð vector `v` í `String` og skila [`Err`] ef `v` inniheldur ógild gögn.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Þetta er ekki gert með því að safna: : <Result<_, _>> () af frammistöðuástæðum.
        // FIXME: hægt er að einfalda aðgerðina aftur þegar #48994 er lokað.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Afkóða UTF-16 kóðuð sneið `v` í `String` og skipta um ógild gögn fyrir [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// Ólíkt [`from_utf8_lossy`] sem skilar [`Cow<'a, str>`], skilar `from_utf16_lossy` `String` þar sem UTF-16 til UTF-8 umbreyting krefst minni úthlutunar.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Niðurbrot `String` í hráefni þess.
    ///
    /// Skilar hráa bendlinum til undirliggjandi gagna, lengdar strengsins (í bæti) og úthlutað getu gagnanna (í bæti).
    /// Þetta eru sömu rökin í sömu röð og rökin við [`from_raw_parts`].
    ///
    /// Eftir að hringt hefur verið í þessa aðgerð ber gesturinn ábyrgð á minni sem `String` hafði áður stjórnað.
    /// Eina leiðin til að gera þetta er að umbreyta hráa bendlinum, lengd og getu aftur í `String` með [`from_raw_parts`] aðgerðinni, sem gerir eyðileggjandanum kleift að framkvæma hreinsunina.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Býr til nýjan `String` úr lengd, getu og bendi.
    ///
    /// # Safety
    ///
    /// Þetta er mjög óöruggt vegna fjölda innflytjenda sem ekki er merktur við:
    ///
    /// * Minni á `buf` þarf að hafa verið úthlutað áður af sama úthlutara og venjulegt bókasafn notar, með nauðsynlegri röðun nákvæmlega 1.
    /// * `length` þarf að vera minna en eða jafnt og `capacity`.
    /// * `capacity` þarf að vera rétt gildi.
    /// * Fyrstu `length` bætin í `buf` þurfa að vera gild UTF-8.
    ///
    /// Brot gegn þessu getur valdið vandamálum eins og að spilla innri gagnaskipan úthlutunaraðilans.
    ///
    /// Eignarhald `buf` færist í raun yfir á `String` sem getur þá framselt, endurúthlutað eða breytt innihaldi minni sem bendillinn bendir á að vild.
    /// Gakktu úr skugga um að ekkert annað noti bendilinn eftir að þú kallar á þessa aðgerð.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Uppfærðu þetta þegar vec_into_raw_parts er stöðugt.
    ///     // Koma í veg fyrir að gögn strengsins falli sjálfkrafa niður
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Breytir vector af bæti í `String` án þess að athuga hvort strengurinn innihaldi gildan UTF-8.
    ///
    /// Sjá örugga útgáfuna, [`from_utf8`], til að fá frekari upplýsingar.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Þessi aðgerð er óörugg vegna þess að hún athugar ekki að bætin sem send eru til hennar séu gild UTF-8.
    /// Ef þessi þvingun er brotin getur það valdið óöryggisvandamálum hjá future notendum `String` þar sem restin af venjulegu bókasafninu gerir ráð fyrir að " Strengir` séu gildir UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// // nokkur bæti, í vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Breytir `String` í bæti vector.
    ///
    /// Þetta eyðir `String` og því þurfum við ekki að afrita innihald hennar.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Útdráttur strengsneið sem inniheldur allan `String`.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Breytir `String` í breytanlega strengjasneið.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Bætir ákveðinni strengjasneið við enda `String`.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Skilar getu "String" í bætum.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Tryggir að afkastageta þessa " strengs` sé að minnsta kosti `additional` bæti stærri en lengd þess.
    ///
    /// Getan aukist um meira en `additional` bæti ef það kýs, til að koma í veg fyrir tíð endurúthlutun.
    ///
    ///
    /// Ef þú vilt ekki þessa "at least" hegðun, sjáðu [`reserve_exact`] aðferðina.
    ///
    /// # Panics
    ///
    /// Panics ef nýja afkastið flæðir yfir [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Þetta eykur í raun ekki getu:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s hefur nú lengdina 2 og getu 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Þar sem við höfum nú þegar aukalega 8 getu, kallum við þetta ...
    /// s.reserve(8);
    ///
    /// // ... eykst reyndar ekki.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Tryggir að afkastageta þessa " strengs` sé `additional` bæti stærri en lengd þess.
    ///
    /// Íhugaðu að nota [`reserve`] aðferðina nema þú vitir alveg betur en úthlutarinn.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics ef nýja afkastið flæðir yfir `usize`.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Þetta eykur í raun ekki getu:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s hefur nú lengdina 2 og getu 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Þar sem við höfum nú þegar aukalega 8 getu, kallum við þetta ...
    /// s.reserve_exact(8);
    ///
    /// // ... eykst reyndar ekki.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Reynir að panta afköst fyrir að minnsta kosti `additional` fleiri þætti til að setja inn í tiltekna `String`.
    /// Söfnunin gæti áskilið sér meira pláss til að forðast tíð endurúthlutun.
    /// Eftir að hafa hringt í `reserve` verður afkastageta meiri en eða jöfn `self.len() + additional`.
    /// Gerir ekkert ef getu er þegar næg.
    ///
    /// # Errors
    ///
    /// Ef afköstin flæða yfir, eða úthlutarinn tilkynnir um bilun, þá er villu skilað.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Pantaðu minnið fyrirfram og farðu ef við getum það ekki
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Nú vitum við að þetta getur ekki OOM í miðri flóknu vinnu okkar
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Reynir að áskilja lágmarksgetu fyrir nákvæmlega `additional` fleiri þætti til að setja inn í tiltekna `String`.
    ///
    /// Eftir að hafa hringt í `reserve_exact` verður afkastageta meiri en eða jöfn `self.len() + additional`.
    /// Gerir ekkert ef afkastagetan er þegar næg.
    ///
    /// Athugið að úthlutarinn gæti gefið safninu meira pláss en það biður um.
    /// Þess vegna er ekki hægt að treysta á getu til að vera nákvæmlega í lágmarki.
    /// Kjósa `reserve` ef búast er við future innsetningum.
    ///
    /// # Errors
    ///
    /// Ef afköstin flæða yfir, eða úthlutarinn tilkynnir um bilun, þá er villu skilað.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Pantaðu minnið fyrirfram og farðu ef við getum það ekki
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Nú vitum við að þetta getur ekki OOM í miðri flóknu vinnu okkar
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Minnkar getu `String` til að passa við lengd hans.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Minnkar getu `String` með lægri mörkum.
    ///
    /// Getan verður áfram að minnsta kosti jafn stór og bæði lengdin og verðið sem fylgir.
    ///
    ///
    /// Ef núverandi afkastageta er minni en neðri mörkin, er þetta neitunarleysi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Bætir við gefnu [`char`] við lok þessa `String`.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Skilar bæti sneið af innihaldi þessarar " strengs`.
    ///
    /// Andhverfa þessarar aðferðar er [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Styttir þennan `String` í tilgreinda lengd.
    ///
    /// Ef `new_len` er meiri en núverandi lengd strengsins hefur þetta engin áhrif.
    ///
    ///
    /// Athugið að þessi aðferð hefur engin áhrif á úthlutaða getu strengsins
    ///
    /// # Panics
    ///
    /// Panics ef `new_len` liggur ekki á [`char`] mörkum.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Fjarlægir síðasta stafinn úr strengjabuffaranum og skilar því.
    ///
    /// Skilar [`None`] ef þessi `String` er tómur.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Fjarlægir [`char`] frá þessum `String` í bæti stöðu og skilar henni.
    ///
    /// Þetta er *O*(*n*) aðgerð, þar sem það þarf að afrita alla þætti í biðminni.
    ///
    /// # Panics
    ///
    /// Panics ef `idx` er stærri eða jafn lengd " strengsins` eða ef það liggur ekki á [`char`] mörkum.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Fjarlægðu allar eldspýtur í mynstri `pat` í `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Samsvörun verður greind og fjarlægð ítrekað, þannig að í tilfellum þar sem mynstur skarast verður aðeins fyrsta mynstrið fjarlægt:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // ÖRYGGI: upphaf og endir verða á utf8 bæti mörkum á
        // the Searcher kennir
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Heldur eingöngu stöfunum sem tilgreindar eru í forvörunni.
    ///
    /// Með öðrum orðum, fjarlægðu alla stafi `c` þannig að `f(c)` skili `false`.
    /// Þessi aðferð starfar á sínum stað, heimsækir hverja persónu nákvæmlega einu sinni í upphaflegri röð og varðveitir röð þeirra persóna sem eftir eru.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Nákvæm röð getur verið gagnleg til að rekja utanaðkomandi ástand, eins og vísitölu.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Bendi idx á næstu bleikju
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Setur staf inn í þennan `String` í bæti stöðu.
    ///
    /// Þetta er *O*(*n*) aðgerð þar sem það þarf að afrita alla þætti í biðminni.
    ///
    /// # Panics
    ///
    /// Panics ef `idx` er stærri en lengd " strengsins` eða ef hún liggur ekki á [`char`] mörkum.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Setur strengjasneið í þennan `String` í bæti stöðu.
    ///
    /// Þetta er *O*(*n*) aðgerð þar sem það þarf að afrita alla þætti í biðminni.
    ///
    /// # Panics
    ///
    /// Panics ef `idx` er stærri en lengd " strengsins` eða ef hún liggur ekki á [`char`] mörkum.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Skilar breytilegri tilvísun í innihald þessa `String`.
    ///
    /// # Safety
    ///
    /// Þessi aðgerð er óörugg vegna þess að hún athugar ekki að bætin sem send eru til hennar séu gild UTF-8.
    /// Ef þessi þvingun er brotin getur það valdið óöryggisvandamálum hjá future notendum `String` þar sem restin af venjulegu bókasafninu gerir ráð fyrir að " Strengir` séu gildir UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Skilar lengd þessa `String`, í bæti, ekki [`char`] eða grafíum.
    /// Með öðrum orðum, það er kannski ekki það sem manneskja telur lengd strengsins.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Skilar `true` ef þessi `String` hefur lengdina núll og `false` annars.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Skiptir strengnum í tvennt við tiltekna bæti vísitölu.
    ///
    /// Skilar nýúthlutuðu `String`.
    /// `self` inniheldur bæti `[0, at)` og skilað `String` inniheldur bæti `[at, len)`.
    /// `at` verður að vera á mörkum UTF-8 kóða punkta.
    ///
    /// Athugið að afkastageta `self` breytist ekki.
    ///
    /// # Panics
    ///
    /// Panics ef `at` er ekki á `UTF-8` kóða punktamörkum, eða ef það er umfram síðasta kóðapunkt strengsins.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Styttir þennan `String` og fjarlægir allt innihald.
    ///
    /// Þó að þetta þýði að `String` hafi lengdina núll snertir það ekki getu sína.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Býr til tæmandi endurtekningu sem fjarlægir tilgreint svið í `String` og skilar `chars` sem fjarlægður var.
    ///
    ///
    /// Note: Þáttasviðið er fjarlægt jafnvel þó endurtekningin sé ekki neytt fyrr en í lokin.
    ///
    /// # Panics
    ///
    /// Panics ef upphafspunktur eða endapunktur liggur ekki á [`char`] mörkum, eða ef þeir eru utan marka.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Fjarlægðu sviðið þar til β úr strengnum
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Allt svið hreinsar strenginn
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Minniöryggi
        //
        // Strengjaútgáfan af Drain hefur ekki minni öryggisvandamál vector útgáfunnar.
        // Gögnin eru bara venjuleg bæti.
        // Vegna þess að fjarlægð sviðs gerist í Drop, ef Drain endurtekningin er lekin, mun fjarlægingin ekki eiga sér stað.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Taktu tvö samtímis lán.
        // Ekki verður farið í &mut strenginn fyrr en endurtekningu er lokið, í Drop.
        let self_ptr = self as *mut _;
        // ÖRYGGI: `slice::range` og `is_char_boundary` gera viðeigandi mörk.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Fjarlægir tilgreint svið í strengnum og kemur í staðinn fyrir viðkomandi streng.
    /// Uppgefinn strengur þarf ekki að vera jafnlangur og sviðið.
    ///
    /// # Panics
    ///
    /// Panics ef upphafspunktur eða endapunktur liggur ekki á [`char`] mörkum, eða ef þeir eru utan marka.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Skiptu um bil upp þar til β frá strengnum
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Minniöryggi
        //
        // Replace_range hefur ekki minni öryggisvandamál vector Splice.
        // af vector útgáfunni.Gögnin eru bara venjuleg bæti.

        // VIÐVÖRUN: Að fella þessa breytu væri ekki hljóð (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // VIÐVÖRUN: Að fella þessa breytu væri ekki hljóð (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Notkun `range` aftur væri óhljóð (#81138) Við gerum ráð fyrir að mörkin sem `range` greindi frá séu þau sömu, en andstæð útfærsla gæti breyst milli símtala
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Breytir þessum `String` í [`Box`]`<`[`str`] `>`.
    ///
    /// Þetta mun fella niður umfram getu.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Skilar sneið af [`u8`] s bæti sem reynt var að breyta í `String`.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// // nokkur ógild bæti, í vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Skilar bætunum sem reynt var að breyta í `String`.
    ///
    /// Þessi aðferð er vandlega smíðuð til að forðast úthlutun.
    /// Það eyðir villunni og færir bætin út svo að ekki þarf að gera afrit af bætunum.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// // nokkur ógild bæti, í vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Náðu í `Utf8Error` til að fá frekari upplýsingar um viðskiptabrest.
    ///
    /// [`Utf8Error`] tegundin sem [`std::str`] býður upp á táknar villu sem kann að eiga sér stað þegar breyta á sneið af [`u8`] í [`&str`].
    /// Að þessu leyti er það hliðstætt `FromUtf8Error`.
    /// Sjá skjöl hennar til að fá frekari upplýsingar um notkun þess.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// // nokkur ógild bæti, í vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // fyrsta bætið er ógilt hér
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Vegna þess að við erum að endurtekna yfir " strengi` getum við forðast að minnsta kosti eina úthlutun með því að fá fyrsta strenginn frá endurtekningunni og bæta við hana öllum síðari strengjum.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Vegna þess að við erum að kljást yfir CoWs getum við (potentially) forðast að minnsta kosti eina úthlutun með því að fá fyrsta hlutinn og bæta við það öllum síðari hlutum.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// A þægindi impl sem sendir til impl fyrir `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Býr til tómt `String`.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Útfærir `+` símafyrirtækið til að sameina tvo strengi.
///
/// Þetta eyðir `String` vinstra megin og notar aftur biðminni hans (ræktar hann ef þörf krefur).
/// Þetta er gert til að forðast að úthluta nýjum `String` og afrita allt innihaldið í hverri aðgerð, sem myndi leiða til þess að *O*(*n*^ 2) gangi þegar verið er að byggja upp *n*-bita streng með endurtekinni samtengingu.
///
///
/// Strengurinn hægra megin er aðeins fenginn að láni;innihald þess er afritað í skilað `String`.
///
/// # Examples
///
/// Að sameina tvo " strengi` tekur það fyrsta eftir gildi og fær það annað lánað:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` er flutt og er ekki lengur hægt að nota hér.
/// ```
///
/// Ef þú vilt halda áfram að nota fyrsta `String` geturðu klónað það og bætt við klónið í staðinn:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` gildir enn hér.
/// ```
///
/// Að sameina `&str` sneiðar er hægt að gera með því að breyta fyrstu í `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Útfærir `+=` símafyrirtækið til að bæta við `String`.
///
/// Þetta hefur sömu hegðun og [`push_str`][String::push_str] aðferðin.
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Tegund alias fyrir [`Infallible`].
///
/// Þetta samheiti er til fyrir afturvirkni og gæti að lokum verið úrelt.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// A trait til að breyta gildi í `String`.
///
/// Þessi trait er sjálfkrafa útfærður fyrir allar gerðir sem útfærir [`Display`] trait.
/// Sem slík ætti `ToString` ekki að vera útfært beint:
/// [`Display`] ætti að innleiða í staðinn og þú færð `ToString` útfærsluna ókeypis.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Breytir gefnu gildi í `String`.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// Í þessari útfærslu, `to_string` aðferðin panics ef `Display` útfærslan skilar villu.
/// Þetta gefur til kynna ranga `Display` útfærslu þar sem `fmt::Write for String` skilar aldrei villu sjálf.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Algeng viðmiðunarregla er að fella ekki inn almennar aðgerðir.
    // Hins vegar, að fjarlægja `#[inline]` úr þessari aðferð veldur óverulegri afturför.
    // Sjá <https://github.com/rust-lang/rust/pull/74852>, síðustu tilraun til að reyna að fjarlægja það.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Breytir `&mut str` í `String`.
    ///
    /// Niðurstöðunni er úthlutað á hrúgunni.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: próf dregur í libstd, sem veldur villum hér
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Breytir uppgefinni `str` sneið í `String`.
    /// Það er athyglisvert að `str` sneiðin er í eigu.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Breytir gefnu `String` í kassa `str` sneið sem er í eigu.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Breytir strengsneið í lánað afbrigði.
    /// Engin hrúgaúthlutun er framkvæmd og strengurinn er ekki afritaður.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Breytir streng í eigið afbrigði.
    /// Engin hrúgaúthlutun er framkvæmd og strengurinn er ekki afritaður.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Breytir strengjatilvísun í lánað afbrigði.
    /// Engin hrúgaúthlutun er framkvæmd og strengurinn er ekki afritaður.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Breytir gefnu `String` í vector `Vec` sem geymir gildi af gerðinni `u8`.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Tæmandi endurtekning fyrir `String`.
///
/// Þessi uppbygging er búin til með [`drain`] aðferðinni á [`String`].
/// Sjá skjöl hennar til að fá frekari upplýsingar.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Verður notað sem&'a mutter strengur í tortímandanum
    string: *mut String,
    /// Upphaf hluta til að fjarlægja
    start: usize,
    /// Lok hluta til að fjarlægja
    end: usize,
    /// Núverandi svið sem eftir er til að fjarlægja
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Notaðu Vec::drain.
            // "Reaffirm" mörkin athuga til að koma í veg fyrir að panic kóði sé settur inn aftur.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Skilar eftirstandandi (undir) streng þessarar endurtekningar sem sneið.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: athugasemdir AsRef fylgir hér að neðan þegar stöðugleiki er náð.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Óþægindi við stöðugleika á `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>fyrir Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> fyrir Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}