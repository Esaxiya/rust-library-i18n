#![stable(feature = "wake_trait", since = "1.51.0")]
//! Tegundir og Traits til að vinna með ósamstillt verkefni.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Framkvæmd þess að vekja verkefni á framkvæmdastjóra.
///
/// Þessi trait er hægt að nota til að búa til [`Waker`].
/// Framkvæmdastjóri getur skilgreint útfærslu á þessari trait og notað það til að smíða Waker til að fara til verkefna sem eru framkvæmd á þeim framkvæmdarstjóra.
///
/// Þessi trait er öruggt minni og vinnuvistfræðilegur valkostur við smíði [`RawWaker`].
/// Það styður sameiginlega framkvæmdastjóra hönnun þar sem gögnin sem notuð eru til að vekja verkefni eru geymd í [`Arc`].
/// Sumir framkvæmdarstjórar (sérstaklega þeir sem eru fyrir innbyggð kerfi) geta ekki notað þetta API og þess vegna er [`RawWaker`] til sem valkostur fyrir þessi kerfi.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Grunn `block_on` aðgerð sem tekur future og keyrir hana til fullnaðar á núverandi þræði.
///
/// **Note:** Þetta dæmi verslar réttmæti til einföldunar.
/// Í því skyni að koma í veg fyrir stöðvun verður útfærsla á framleiðslustigi einnig að sjá um milliköll í `thread::unpark` sem og hreiðurköll.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Vakandi sem vekur upp núverandi þráð þegar kallað er á hann.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Keyrðu future til loka á núverandi þræði.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Pinna future svo hægt sé að pæla í því.
///     let mut fut = Box::pin(fut);
///
///     // Búðu til nýtt samhengi sem á að fara til future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Keyrðu future til loka.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Vakna þetta verkefni.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Vakna þetta verkefni án þess að neyta vakarans.
    ///
    /// Ef framkvæmdastjóri styður ódýrari leið til að vakna án þess að neyta vekjandans ætti það að ganga framhjá þessari aðferð.
    /// Sjálfgefið, það einræktir [`Arc`] og kallar [`wake`] á klóninn.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // ÖRYGGI: Þetta er öruggt vegna þess að raw_waker smíðar á öruggan hátt
        // RawWaker frá Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Þessi einkaaðgerð til að smíða RawWaker er notuð frekar en
// að fella þetta inn í `From<Arc<W>> for RawWaker` impl, til að tryggja að öryggi `From<Arc<W>> for Waker` sé ekki háð réttri trait sendingu, heldur kalla báðir impls þessa aðgerð beint og skýrt.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Aukið viðmiðunartölu boga til að klóna hana.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Vakna eftir gildi og færa Arc í Wake::wake aðgerðina
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Vakna með tilvísun, pakkaðu vakaranum í ManuallyDrop til að forðast að láta hann falla
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Lækkaðu viðmiðunartalningu Bogans við fall
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}