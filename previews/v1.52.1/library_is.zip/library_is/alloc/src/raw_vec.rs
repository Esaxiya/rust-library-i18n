#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Innihald nýja minnisins er einblínt.
    Uninitialized,
    /// Nýtt minni er tryggt að núllast.
    Zeroed,
}

/// Lítil gagnsemi til að úthluta vinnuvistfræðilegri, endurúthlutun og deilifæra minni biðminni á hrúgunni án þess að þurfa að hafa áhyggjur af öllum hornatilfellunum.
///
/// Þessi tegund er frábært til að byggja upp eigin gagnamannvirki eins og Vec og VecDeque.
/// Sérstaklega:
///
/// * Framleiðir `Unique::dangling()` á núllstærðum gerðum.
/// * Framleiðir `Unique::dangling()` við úthlutun á núlllengd.
/// * Forðast að losa `Unique::dangling()`.
/// * Grípur allt yfirfall í getuútreikningum (stuðlar að "capacity overflow" panics).
/// * Vernd gegn 32 bita kerfum sem úthluta meira en isize::MAX bæti.
/// * Verndar gegn ofgnótt lengdar þinnar.
/// * Hringir í `handle_alloc_error` vegna rangra úthlutana.
/// * Inniheldur `ptr::Unique` og veitir þannig notandanum alla tengda kosti.
/// * Notar það umfram sem skilað er frá úthlutunaraðilanum til að nota stærstu lausu getu.
///
/// Þessi tegund skoðar ekki hvort eð er minni sem hún hefur umsjón með.Þegar það er sleppt *mun það* losa minni sitt en það *mun ekki* reyna að sleppa innihaldi þess.
/// Það er notanda `RawVec` að sjá um raunverulega hluti *geymda* inni í `RawVec`.
///
/// Athugið að umfram núllstærðar gerðir er alltaf óendanlegt, þannig að `capacity()` skilar alltaf `usize::MAX`.
/// Þetta þýðir að þú verður að vera varkár þegar þú hringir þessa tegund með `Box<[T]>` þar sem `capacity()` skilar ekki lengdinni.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Þetta er til vegna þess að `#[unstable]` `const fn`s þurfa ekki að vera í samræmi við `min_const_fn` og því er ekki hægt að hringja í þá í`min_const_fn`s heldur.
    ///
    /// Ef þú breytir `RawVec<T>::new` eða ósjálfstæði skaltu gæta þess að kynna ekki neitt sem sannarlega brýtur í bága við `min_const_fn`.
    ///
    /// NOTE: Við gætum forðast þetta hakk og kannað samræmi við einhvern `#[rustc_force_min_const_fn]` eiginleika sem krefst samræmis við `min_const_fn` en leyfir ekki endilega að kalla það í `stable(...) const fn`/notendakóða sem gerir K04X ekki kleift þegar `#[rustc_const_unstable(feature = "foo", issue = "01234")]` er til staðar.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Býr til stærsta mögulega `RawVec` (á kerfishaugnum) án þess að úthluta.
    /// Ef `T` hefur jákvæða stærð, þá gerir þetta `RawVec` með getu `0`.
    /// Ef `T` er núllstórt, þá gerir það `RawVec` með getu `usize::MAX`.
    /// Gagnlegt til að hrinda í framkvæmd seinkaðri úthlutun.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Býr til `RawVec` (á kerfishaugnum) með nákvæmlega kröfur um getu og aðlögun fyrir `[T; capacity]`.
    /// Þetta jafngildir því að hringja í `RawVec::new` þegar `capacity` er `0` eða `T` er núllstærð.
    /// Athugaðu að ef `T` er núllstór þýðir þetta að þú munt *ekki* fá `RawVec` með umbeðinni getu.
    ///
    /// # Panics
    ///
    /// Panics ef umbeðin getu fer yfir `isize::MAX` bæti.
    ///
    /// # Aborts
    ///
    /// Brottfall á OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Eins og `with_capacity`, en ábyrgist að biðminni sé núllsett.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Endurskiptir `RawVec` úr bendli og getu.
    ///
    /// # Safety
    ///
    /// `ptr` verður að fá úthlutað (á kerfishaugnum) og með gefnu `capacity`.
    /// `capacity` má ekki fara yfir `isize::MAX` fyrir stórar gerðir.(aðeins áhyggjuefni í 32 bita kerfum).
    /// ZST vectors geta haft allt að `usize::MAX` getu.
    /// Ef `ptr` og `capacity` koma frá `RawVec`, þá er þetta tryggt.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Tiny Vecs eru heimsk.Hoppa til:
    // - 8 ef stærð frumefnis er 1, vegna þess að allir hrúgaúthlutarar eru líklegir til að ná saman beiðni sem er minni en 8 bæti í að minnsta kosti 8 bæti.
    //
    // - 4 ef þættir eru í meðallagi stórir (<=1 KiB).
    // - 1 annars, til að forðast að eyða of miklu plássi fyrir mjög stutt Vecs.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Eins og `new`, en breytist yfir val á úthlutunaraðila fyrir skilað `RawVec`.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` þýðir "unallocated".núllstærðar gerðir eru hunsaðar.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Eins og `with_capacity`, en breytist yfir val á úthlutunaraðila fyrir skilað `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Eins og `with_capacity_zeroed`, en breytist yfir val á úthlutunaraðila fyrir skilað `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Breytir `Box<[T]>` í `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Breytir öllu biðminni í `Box<[MaybeUninit<T>]>` með tilgreindum `len`.
    ///
    /// Athugaðu að þetta mun rétta upp allar `cap` breytingar sem hafa verið gerðar.(Sjá nánar lýsingu á gerð.)
    ///
    /// # Safety
    ///
    /// * `len` verður að vera meiri en eða jafnt og síðast er beðið um getu, og
    /// * `len` verður að vera minna en eða jafnt og `self.capacity()`.
    ///
    /// Athugaðu að umbeðin getu og `self.capacity()` gætu verið mismunandi, þar sem úthlutarinn gæti samstillt og skilað meiri minnisblokk en beðið var um.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Heilbrigðiseftirlit með helming öryggiskröfunnar (við getum ekki athugað hinn helminginn).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Við forðumst `unwrap_or_else` hér vegna þess að það þenst upp magn LLVM IR sem myndast.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Skiptir upp `RawVec` úr bendi, getu og úthlutara.
    ///
    /// # Safety
    ///
    /// Úthluta verður `ptr` (í gegnum tiltekinn úthlutunaraðila `alloc`) og með gefnum `capacity`.
    /// `capacity` má ekki fara yfir `isize::MAX` fyrir stórar gerðir.
    /// (aðeins áhyggjuefni í 32 bita kerfum).
    /// ZST vectors geta haft allt að `usize::MAX` getu.
    /// Ef `ptr` og `capacity` koma frá `RawVec` sem búið er til með `alloc`, þá er þetta tryggt.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Fær hráan bendil við upphaf úthlutunar.
    /// Athugið að þetta er `Unique::dangling()` ef `capacity == 0` eða `T` er núllstærð.
    /// Í fyrra tilvikinu verður þú að vera varkár.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Fær getu úthlutunar.
    ///
    /// Þetta verður alltaf `usize::MAX` ef `T` er núllstórt.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Skilar sameiginlegri tilvísun í úthlutarann sem styður þennan `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Við höfum úthlutað minni hluta, svo við getum framhjá keyrslutímatékkum til að fá núverandi skipulag.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Tryggir að biðminni inniheldur að minnsta kosti nægilegt pláss til að geyma `len + additional` þætti.
    /// Ef það hefur ekki þegar næga afkastagetu mun það endurúthluta nægu plássi ásamt þægilegu slöku rými til að afskrifa *O*(1) hegðun.
    ///
    /// Mun takmarka þessa hegðun ef það myndi valda sjálfum sér panic.
    ///
    /// Ef `len` fer yfir `self.capacity()` gæti það ekki tekist að úthluta raunverulegu plássi.
    /// Þetta er í raun ekki ótryggt, en óöruggi kóðinn *sem þú skrifar* sem reiðir sig á hegðun þessarar aðgerðar getur brotnað.
    ///
    /// Þetta er tilvalið til að hrinda í framkvæmd magnþrýstingsaðgerð eins og `extend`.
    ///
    /// # Panics
    ///
    /// Panics ef nýja afkastagetan fer yfir `isize::MAX` bæti.
    ///
    /// # Aborts
    ///
    /// Brottfall á OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // varasjóður hefði eytt eða læti ef len fór yfir `isize::MAX` svo þetta er óhætt að gera ómerkt núna.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Sama og `reserve`, en skilar aftur við villum í stað þess að fara í læti eða hætta á.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Tryggir að biðminni inniheldur að minnsta kosti nægilegt pláss til að geyma `len + additional` þætti.
    /// Ef það er ekki þegar gert mun það endurúthluta lágmarks mögulegu minni sem nauðsynlegt er.
    /// Almennt mun þetta vera nákvæmlega það minni sem nauðsynlegt er, en í grundvallaratriðum er úthlutaranum frjálst að gefa meira til baka en við báðum um.
    ///
    ///
    /// Ef `len` fer yfir `self.capacity()` gæti það ekki tekist að úthluta raunverulegu plássi.
    /// Þetta er í raun ekki ótryggt, en óöruggi kóðinn *sem þú skrifar* sem reiðir sig á hegðun þessarar aðgerðar getur brotnað.
    ///
    /// # Panics
    ///
    /// Panics ef nýja afkastagetan fer yfir `isize::MAX` bæti.
    ///
    /// # Aborts
    ///
    /// Brottfall á OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Sama og `reserve_exact`, en skilar aftur við villum í stað þess að fara í læti eða hætta á.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Minnkar úthlutunina niður í tilgreinda upphæð.
    /// Ef gefin upphæð er 0, deilist raunverulega alveg.
    ///
    /// # Panics
    ///
    /// Panics ef gefin upphæð er *stærri* en núverandi getu.
    ///
    /// # Aborts
    ///
    /// Brottfall á OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Skilar sér ef biðminni þarf að vaxa til að uppfylla nauðsynlega auka getu.
    /// Aðallega notað til að gera innlimun varasímtala möguleg án þess að fella `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Þessi aðferð er venjulega instatt mörgum sinnum.Þannig að við viljum að það sé eins lítið og mögulegt er, að bæta samsetningu tíma.
    // En við viljum líka að eins mikið af innihaldi þess sé tölfræðilega útreiknanlegt og mögulegt er, til að mynda kóðann gangi hraðar.
    // Þess vegna er þessi aðferð vandlega skrifuð þannig að allur kóðinn sem veltur á `T` er innan hans, en eins mikið af kóðanum sem ekki er háð `T` og mögulegt er í aðgerðum sem eru ekki almennar yfir `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Þetta er tryggt með hringjasamhenginu.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Þar sem við skilum afkastagetu `usize::MAX` þegar `elem_size` er
            // 0, að komast hingað þýðir endilega að `RawVec` er of fullur.
            return Err(CapacityOverflow);
        }

        // Ekkert sem við getum raunverulega gert við þessar athuganir, því miður.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Þetta tryggir veldisvöxt.
        // Tvöföldunin getur ekki flætt yfir vegna þess að `cap <= isize::MAX` og gerð `cap` er `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` er ekki samheitalyf yfir `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Takmarkanir á þessari aðferð eru mikið þær sömu og á `grow_amortized`, en þessi aðferð er venjulega tafarlaus sjaldnar svo hún er minna mikilvæg.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Þar sem við skilum afkastagetu `usize::MAX` þegar tegundarstærðin er
            // 0, að komast hingað þýðir endilega að `RawVec` er of fullur.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` er ekki samheitalyf yfir `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Þessi aðgerð er utan `RawVec` til að lágmarka samsetningu tíma.Sjá athugasemd hér að ofan `RawVec::grow_amortized` til að fá frekari upplýsingar.
// (`A` breytan er ekki marktæk vegna þess að fjöldi mismunandi `A` gerða sem sést í reynd er mun minni en fjöldi `T` gerða.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Athugaðu hvort villan sé hér til að lágmarka stærð `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Úthlutarinn kannar hvort jafnvægi sé á jöfnuninni
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Losar um minni í eigu `RawVec`*án þess að* reyna að sleppa innihaldi þess.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Aðalaðgerð fyrir meðhöndlun villuvilla.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Við verðum að tryggja eftirfarandi:
// * Við úthlutum aldrei `> isize::MAX` hlutum í bæti-stærð.
// * Við flæðum ekki yfir `usize::MAX` og úthlutum í raun of lítið.
//
// Á 64-bita þurfum við bara að athuga hvort það flæðir yfir því að reyna að úthluta `> isize::MAX` bæti mun örugglega mistakast.
// Á 32-bita og 16 bita þurfum við að bæta við auka vörn fyrir þetta ef við erum að keyra á vettvang sem getur notað allt 4GB í notendaplássi, td PAE eða x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Ein aðalaðgerð sem ber ábyrgð á skýrslugetu flæðir yfir.
// Þetta mun tryggja að kóða kynslóðin sem tengist þessum panics er í lágmarki þar sem það er aðeins einn staður sem panics fremur en fullt í öllum einingunni.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}