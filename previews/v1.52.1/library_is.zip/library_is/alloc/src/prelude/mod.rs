//! Úthlutunin Prelude
//!
//! Tilgangur þessarar einingar er að draga úr innflutningi á algengum hlutum af `alloc` crate með því að bæta glob innflutningi efst á einingum:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;