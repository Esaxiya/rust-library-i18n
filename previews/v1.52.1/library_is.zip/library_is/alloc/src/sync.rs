#![stable(feature = "rust1", since = "1.0.0")]

//! Þráðávísanir tilvísunartalningar.
//!
//! Sjá [`Arc<T>`][Arc] skjöl fyrir frekari upplýsingar.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Mjúk takmörkun á magni tilvísana sem hægt er að gera í `Arc`.
///
/// Að fara yfir þessi mörk mun forrita forritið þitt (þó ekki endilega) við _exactly_ `MAX_REFCOUNT + 1` tilvísanir.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer styður ekki minnisgirðingar.
// Til að forðast rangar jákvæðar skýrslur í Arc/Weak útfærslu skaltu nota lotuálag til samstillingar í staðinn.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Þráður-öruggur vísir til að telja.'Arc' stendur fyrir 'Atomically Reference Counted'.
///
/// Tegundin `Arc<T>` veitir sameiginlegt eignarhald á gildi af gerðinni `T`, úthlutað í hrúgunni.Að kalla á [`clone`][clone] á `Arc` framleiðir nýtt `Arc` dæmi, sem bendir til sömu úthlutunar á hrúgunni og uppruninn `Arc`, en aukið viðmiðunartalningu.
/// Þegar síðasti `Arc` bendillinn að tiltekinni úthlutun er eyðilagður, fellur einnig úr gildi sem geymt er í þeirri úthlutun (oft nefnt "inner value").
///
/// Sameiginlegar tilvísanir í Rust leyfa sjálfgefið stökkbreytingu og `Arc` er engin undantekning: Þú getur almennt ekki fengið breytanlega tilvísun í eitthvað inni í `Arc`.Ef þú þarft að breyta í gegnum `Arc` skaltu nota [`Mutex`][mutex], [`RwLock`][rwlock] eða eina af [`Atomic`][atomic] tegundunum.
///
/// ## Þráður Öryggi
///
/// Ólíkt [`Rc<T>`] notar `Arc<T>` lotukerfisaðgerðir til viðmiðunartalningar.Þetta þýðir að það er þráðlaust.Ókosturinn er sá að atómaðgerðir eru dýrari en venjulegur minnisaðgangur.Ef þú deilir ekki tilvísunartöldum úthlutunum milli þráða skaltu íhuga að nota [`Rc<T>`] fyrir lægri kostnað.
/// [`Rc<T>`] er öruggt sjálfgefið, því þýðandinn grípur allar tilraunir til að senda [`Rc<T>`] á milli þráða.
/// Hins vegar gæti bókasafn valið `Arc<T>` til að veita bókasafnsneytendum meiri sveigjanleika.
///
/// `Arc<T>` mun innleiða [`Send`] og [`Sync`] svo framarlega sem `T` útfærir [`Send`] og [`Sync`].
/// Af hverju er ekki hægt að setja ekki þráðlausa gerð `T` í `Arc<T>` til að gera hana þráðlausa?Þetta gæti verið svolítið gagnlegt í fyrstu: þegar öllu er á botninn hvolft, er ekki tilgangur `Arc<T>` þráður öryggis?Lykillinn er þessi: `Arc<T>` gerir það að þræði öruggt að eiga mörg eignarhald á sömu gögnum, en það bætir ekki öryggi þráða við gögnin sín.
///
/// Lítum á " Arc <`[`RefCell<T>`]`> `.
/// [`RefCell<T>`] er ekki [`Sync`], og ef `Arc<T>` var alltaf [`Send`], " Arc <`[`RefCell<T>`]`> `væri það líka.
/// En þá værum við í vandræðum:
/// [`RefCell<T>`] er ekki þráður öruggur;það heldur utan um lántalningu með aðgerðum sem ekki eru atómum.
///
/// Að lokum þýðir þetta að þú gætir þurft að para `Arc<T>` við einhvers konar [`std::sync`] gerð, venjulega [`Mutex<T>`][mutex].
///
/// ## Brot hringrás með `Weak`
///
/// [`downgrade`][downgrade] aðferðina er hægt að nota til að búa til [`Weak`] bendi sem ekki er í eigu.[`Weak`] bendill getur verið [" uppfærsla`][uppfærsla] d í `Arc`, en það skilar [`None`] ef gildið sem er geymt í úthlutuninni hefur þegar verið fellt.
/// Með öðrum orðum, `Weak` ábendingar halda ekki gildi inni í úthlutuninni;þó *þeir* halda úthlutuninni (bakverði fyrir verðmæti) á lofti.
///
/// Hringrás milli `Arc` ábendinga verður aldrei úthlutað.
/// Af þessum sökum er [`Weak`] notað til að brjóta hringrásir.Til dæmis gæti tré haft sterk `Arc` vísbendingar frá foreldrahnútum til barna og [`Weak`] vísbendingar frá börnum aftur til foreldra sinna.
///
/// # Einræktun tilvísana
///
/// Að búa til nýja tilvísun úr núverandi tilvísunartöldum bendi er gert með því að nota `Clone` trait sem er útfærður fyrir [`Arc<T>`][Arc] og [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Setningafræði tvö hér að neðan eru jafngild.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b og foo eru allt Bogar sem vísa á sömu minnisstað
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` sjálfkrafa að vísa til `T` (í gegnum [`Deref`][deref] trait), svo þú getir hringt í aðferðir " T`á gildi af gerðinni `Arc<T>`.Til að forðast nafnárekstur með aðferðum " T` eru aðferðir `Arc<T>` sjálfra tengdar aðgerðir, kallaðar með [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// " Bogi<T>Útfærslur á traits eins og `Clone` má einnig kalla með fullgildri setningafræði.
/// Sumir kjósa að nota fullgilda setningafræði en aðrir kjósa að nota setningafræði aðferða.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Setningafræði aðferðarsímtala
/// let arc2 = arc.clone();
/// // Fullgild setningafræði
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] breytir ekki sjálfkrafa `T` vegna þess að innra gildi gæti hafa þegar verið lækkað.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Að deila nokkrum óbreytanlegum gögnum milli þráða:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Athugið að við ** keyrum ekki þessar prófanir hér.
// windows smiðirnir verða ofsalega óánægðir ef þráður er meiri en þráðurinn og fer síðan út á sama tíma (eitthvað læsist) svo við forðumst þetta bara alfarið með því að keyra ekki þessar prófanir.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Deilt með breytilegum [`AtomicUsize`]:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Sjá [`rc` documentation][rc_examples] fyrir fleiri dæmi um tilvísunartalningu almennt.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` er útgáfa af [`Arc`] sem hefur tilvísun sem ekki er í eigu úthlutunarinnar.
/// Úthlutunin er aðgengileg með því að hringja í [`upgrade`] á `Weak` bendilinn, sem skilar [`Valkost`]`<`[`Arc ']`<T>> `.
///
/// Þar sem `Weak` tilvísun telst ekki til eignarhalds mun það ekki koma í veg fyrir að verðmæti sem eru geymd í úthlutuninni falli niður og `Weak` sjálft gefur engar ábyrgðir fyrir því að verðmæti sé enn til staðar.
///
/// Þannig getur það skilað [`None`] þegar ["uppfærsla"] d.
/// Athugaðu þó að `Weak` tilvísun * kemur í veg fyrir að úthlutunin sjálf (bakverslunin) verði framseld.
///
/// `Weak` bendill er gagnlegur til að halda tímabundinni tilvísun í úthlutunina sem [`Arc`] stýrir án þess að koma í veg fyrir að innra gildi hans falli niður.
/// Það er einnig notað til að koma í veg fyrir hringlaga tilvísanir á milli [`Arc`] ábendinga, þar sem gagnkvæmar tilvísanir eiga aldrei að leyfa neinum að falla frá [`Arc`].
/// Til dæmis gæti tré haft sterka [`Arc`] vísbendingar frá foreldrahnútum til barna og `Weak` vísbendingar frá börnum aftur til foreldra sinna.
///
/// Dæmigerð leið til að fá `Weak` bendi er að hringja í [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Þetta er `NonNull` til að leyfa fínstillingu á stærð þessarar tegundar í enums, en það er ekki endilega gildur bendill.
    //
    // `Weak::new` stillir þetta á `usize::MAX` þannig að það þarf ekki að úthluta plássi á hrúgunni.
    // Það er ekki gildi sem raunverulegur bendill mun nokkru sinni hafa því RcBox er með jöfnun að minnsta kosti 2.
    // Þetta er aðeins mögulegt þegar `T: Sized`;óstærð `T` dingla aldrei.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Þetta er repr(C) til future-sönnun gegn mögulegri svæðisskipulagningu, sem myndi trufla annars öruggan [into|from]_raw() af breytanlegum innri gerðum.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // gildið usize::MAX virkar sem vakt fyrir tímabundið "locking" getu til að uppfæra veikburða eða lækka sterka;þetta er notað til að forðast hlaup í `make_mut` og `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Smíðar nýjan `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Byrjaðu veiku bendilinn að telja sem 1 sem er veiki bendillinn sem er haldinn af öllum sterku ábendingunum (kinda), sjá std/rc.rs fyrir frekari upplýsingar
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Smíðar nýjan `Arc<T>` með veikri tilvísun í sjálfan sig.
    /// Tilraun til að uppfæra veiku viðmiðunina áður en þessi aðgerð snýr aftur mun leiða til `None` gildi.
    /// Hins vegar er hægt að klóna veiku viðmiðunina að vild og geyma til notkunar seinna.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Byggðu innri í "uninitialized" ástandi með einni veikri tilvísun.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Það er mikilvægt að við gefum ekki upp eignarhald á veikum músinni, annars gæti minnið losnað þegar `data_fn` kemur aftur.
        // Ef við vildum virkilega fara framhjá eignarhaldi gætum við búið til viðbótar veikan bendi fyrir okkur, en þetta myndi leiða til viðbótar uppfærslna á veiku viðmiðunartalningu sem annars gæti ekki verið nauðsynleg.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Nú getum við frumstafað hið innra gildi og breytt veikri tilvísun okkar í sterka tilvísun.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Ofangreind skrif í gagnasviðið verður að vera sýnileg öllum þráðum sem fylgjast með sterkri tölu sem ekki er núll.
            // Þess vegna þurfum við að minnsta kosti "Release" pöntun til að samstilla við `compare_exchange_weak` í `Weak::upgrade`.
            //
            // "Acquire" pöntun er ekki krafist.
            // Þegar við hugsum um hugsanlega hegðun `data_fn` þurfum við aðeins að skoða hvað það gæti gert með tilvísun í `Weak` sem ekki er hægt að uppfæra:
            //
            // - Það getur *klónað*`Weak`, aukið veikt viðmiðunartalningu.
            // - Það getur sleppt þessum klónum og fækkað veiku viðmiðunartalningu (en aldrei í núll).
            //
            // Þessar aukaverkanir hafa ekki áhrif á okkur á neinn hátt og engar aðrar aukaverkanir eru mögulegar með öruggum kóða einum saman.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Sterkar tilvísanir ættu sameiginlega að eiga sameiginlega veika tilvísun, svo ekki keyra tortímandann fyrir gömlu veiku tilvísunina okkar.
        //
        mem::forget(weak);
        strong
    }

    /// Smíðar nýjan `Arc` með frumlausu innihaldi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Frestað frumstilling:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Smíðar nýjan `Arc` með frumlausu innihaldi, þar sem minnið er fyllt með `0` bæti.
    ///
    ///
    /// Sjá [`MaybeUninit::zeroed`][zeroed] fyrir dæmi um rétta og ranga notkun á þessari aðferð.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Smíðar nýjan `Pin<Arc<T>>`.
    /// Ef `T` innleiðir ekki `Unpin`, þá verður `data` fest í minni og ekki hægt að færa það.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Smíðar nýjan `Arc<T>` og skilar villu ef úthlutun mistekst.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Byrjaðu veiku bendilinn að telja sem 1 sem er veiki bendillinn sem er haldinn af öllum sterku ábendingunum (kinda), sjá std/rc.rs fyrir frekari upplýsingar
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Smíðar nýjan `Arc` með frumlausu innihaldi og skilar villu ef úthlutun mistekst.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Frestað frumstilling:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Smíðar nýjan `Arc` með einræktuðu innihaldi, þar sem minnið er fyllt með `0` bæti og skilar villu ef úthlutun mistekst.
    ///
    ///
    /// Sjá [`MaybeUninit::zeroed`][zeroed] fyrir dæmi um rétta og ranga notkun á þessari aðferð.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Skilar innra gildi ef `Arc` hefur nákvæmlega eina sterka tilvísun.
    ///
    /// Annars er [`Err`] skilað með sama `Arc` og var sent inn.
    ///
    ///
    /// Þetta mun ná árangri, jafnvel þó það séu framúrskarandi veikar tilvísanir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Búðu til veikan bendil til að hreinsa upp óbeina sterk-veika tilvísunina
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Smíðar nýja atómatilvísunartölu sneið með innihaldsefninu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Frestað frumstilling:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Býr til nýja atómatilvísaða sneið með innihaldslausu innihaldi, þar sem minnið er fyllt með `0` bæti.
    ///
    ///
    /// Sjá [`MaybeUninit::zeroed`][zeroed] fyrir dæmi um rétta og ranga notkun á þessari aðferð.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Breytir í `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Eins og með [`MaybeUninit::assume_init`], er það hringjandi að ábyrgjast að innra gildi sé raunverulega í frumstilltu ástandi.
    ///
    /// Að hringja í þetta þegar innihaldið er ekki enn frumstillt veldur óskilgreindri hegðun strax.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Frestað frumstilling:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Breytir í `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Eins og með [`MaybeUninit::assume_init`], er það hringjandi að ábyrgjast að innra gildi sé raunverulega í frumstilltu ástandi.
    ///
    /// Að hringja í þetta þegar innihaldið er ekki enn frumstillt veldur óskilgreindri hegðun strax.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Frestað frumstilling:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Eyðir `Arc` og skilar vafinn bendi.
    ///
    /// Til að koma í veg fyrir minnisleka verður að breyta bendlinum aftur í `Arc` með því að nota [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Býður upp á hráan bendil á gögnin.
    ///
    /// Talningin hefur ekki áhrif á neinn hátt og `Arc` er ekki neytt.
    /// Bendillinn gildir svo lengi sem það eru sterkar talningar í `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // ÖRYGGI: Þetta getur ekki farið í gegnum Deref::deref eða RcBoxPtr::inner vegna þess
        // þetta er krafist til að halda raw/mut uppruna þannig að td
        // `get_mut` getur skrifað í gegnum bendilinn eftir að Rc er endurheimtur í gegnum `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Smíðar `Arc<T>` úr hráum bendli.
    ///
    /// Hráa bendlinum verður að hafa verið skilað áður með símtali í [`Arc<U>::into_raw`][into_raw] þar sem `U` verður að hafa sömu stærð og röðun og `T`.
    /// Þetta er léttvægt ef `U` er `T`.
    /// Athugaðu að ef `U` er ekki `T` en hefur sömu stærð og aðlögun, þá er þetta í grundvallaratriðum eins og að vísa tilvísunum af mismunandi gerðum.
    /// Sjá [`mem::transmute`][transmute] til að fá frekari upplýsingar um hvaða takmarkanir eiga við í þessu tilfelli.
    ///
    /// Notandi `from_raw` þarf að ganga úr skugga um að tilteknu gildi `T` sé aðeins sleppt einu sinni.
    ///
    /// Þessi aðgerð er óörugg þar sem óviðeigandi notkun getur leitt til óöryggis í minni, jafnvel þótt aldrei sé farið í `Arc<T>` sem skilað er.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Breyttu aftur í `Arc` til að koma í veg fyrir leka.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Frekari símtöl til `Arc::from_raw(x_ptr)` væru minni en ekki örugg.
    /// }
    ///
    /// // Minningin var leyst þegar `x` fór úr gildissviðinu hér að ofan, svo `x_ptr` dinglar nú!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Snúðu móti til að finna upprunalegu ArcInner.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Býr til nýjan [`Weak`] bendil við þessa úthlutun.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Þetta slaka á er í lagi vegna þess að við erum að athuga gildi í CAS hér að neðan.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // athugaðu hvort veiki teljarinn er "locked" eins og er;ef svo er, snúðu.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: þessi kóði hunsar sem stendur möguleikann á flæði
            // inn í usize::MAX;almennt þarf að breyta bæði Rc og Arc til að takast á við flæði.
            //

            // Ólíkt Clone(), þá þurfum við að vera að afla lesa til að samstilla við skrif sem koma frá `is_unique`, svo að atburðirnir á undan þeirri skrifun gerist áður en þetta er lesið.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Gakktu úr skugga um að við búum ekki til dinglandi veika
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Fær fjölda [`Weak`] ábendinga við þessa úthlutun.
    ///
    /// # Safety
    ///
    /// Þessi aðferð út af fyrir sig er örugg, en að nota hana rétt krefst aukinnar varúðar.
    /// Annar þráður getur breytt veiku talningunni hvenær sem er, þar á meðal hugsanlega milli þess að kalla þessa aðferð og starfa eftir niðurstöðunni.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Þessi fullyrðing er afgerandi vegna þess að við höfum ekki deilt `Arc` eða `Weak` á milli þráða.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Ef veiki talningin er nú læst var gildi talningarinnar 0 rétt áður en læsingin var tekin.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Fær fjölda sterkra (`Arc`) vísbendinga við þessa úthlutun.
    ///
    /// # Safety
    ///
    /// Þessi aðferð út af fyrir sig er örugg, en að nota hana rétt krefst aukinnar varúðar.
    /// Annar þráður getur breytt sterkri talningu hvenær sem er, þar á meðal hugsanlega milli þess að kalla þessa aðferð og starfa eftir niðurstöðunni.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Þessi fullyrðing er afgerandi vegna þess að við höfum ekki deilt `Arc` milli þráða.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Hækkar sterka viðmiðunartalningu á `Arc<T>` sem fylgir bendinum sem fylgir með einum.
    ///
    /// # Safety
    ///
    /// Bendirinn verður að hafa verið fenginn í gegnum `Arc::into_raw` og tilheyrandi `Arc` tilvik verður að vera gilt (þ.e.
    /// sterka talningin verður að vera að minnsta kosti 1) meðan á þessari aðferð stendur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Þessi fullyrðing er afgerandi vegna þess að við höfum ekki deilt `Arc` milli þráða.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Haltu Arc, en ekki snerta endurtalningu með því að pakka inn ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Nú skaltu auka endurtalningu en ekki láta neina endurtalningu falla heldur
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Dregur úr sterkri viðmiðunartölu á `Arc<T>` sem fylgir bendinum sem fylgir með einum.
    ///
    /// # Safety
    ///
    /// Bendirinn verður að hafa verið fenginn í gegnum `Arc::into_raw` og tilheyrandi `Arc` tilvik verður að vera gilt (þ.e.
    /// sterka talningin verður að vera að minnsta kosti 1) þegar kallað er á þessa aðferð.
    /// Þessa aðferð er hægt að nota til að losa endanlega `Arc` og stuðningsgeymslu, en **ætti ekki að kalla** eftir að loka `Arc` hefur verið gefinn út.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Þessar fullyrðingar eru afgerandi vegna þess að við höfum ekki deilt `Arc` milli þráða.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Þessi óöryggi er í lagi vegna þess að meðan þessi boga er lifandi er okkur tryggt að innri bendillinn sé gildur.
        // Ennfremur vitum við að `ArcInner` uppbyggingin sjálf er `Sync` vegna þess að innri gögnin eru einnig `Sync`, þannig að okkur er í lagi að lána óbreytanlegan bendil á þetta innihald.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Ófóðraður hluti `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Eyðilegðu gögnin um þessar mundir, jafnvel þó að við losum kannski ekki við úthlutun kassans (það geta enn verið veikir ábendingar liggjandi).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Slepptu veikum dómara sameiginlega með öllum sterkum tilvísunum
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Skilar `true` ef báðir `Arc`s vísa til sömu úthlutunar (í svipuðum dúr og [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Úthlutar `ArcInner<T>` með nægu rými fyrir hugsanlega óstærð innra gildi þar sem gildið er með uppsetningunni.
    ///
    /// Aðgerðin `mem_to_arcinner` er kölluð með gagnabendlinum og verður að skila aftur (hugsanlega fitu) vísi fyrir `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Reiknið útlitið með því að nota uppgefið gildi.
        // Áður var útlit reiknað á tjáningu `&*(ptr as* const ArcInner<T>)`, en þetta skapaði ranga tilvísun (sjá #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Úthlutar `ArcInner<T>` með nægu rými fyrir hugsanlega óstærð innra gildi þar sem gildið hefur uppsetninguna, og skilar villu ef úthlutun mistekst.
    ///
    ///
    /// Aðgerðin `mem_to_arcinner` er kölluð með gagnabendlinum og verður að skila aftur (hugsanlega fitu) vísi fyrir `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Reiknið útlitið með því að nota uppgefið gildi.
        // Áður var útlit reiknað á tjáningu `&*(ptr as* const ArcInner<T>)`, en þetta skapaði ranga tilvísun (sjá #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Ræsið ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Úthlutar `ArcInner<T>` með nægu rými fyrir óstærð innra gildi.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Úthlutaðu fyrir `ArcInner<T>` með því að gefa upp gildi.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Afritaðu gildi sem bæti
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Frelsaðu úthlutunina án þess að sleppa innihaldi hennar
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Úthlutar `ArcInner<[T]>` með gefinni lengd.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Afritaðu þætti úr sneiðinni í nýúthlutað Arc <\[T\]>
    ///
    /// Óörugg vegna þess að sá sem hringir verður annað hvort að taka eignarhald eða binda `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Smíðar `Arc<[T]>` úr endurtekningu sem vitað er að er af ákveðinni stærð.
    ///
    /// Hegðun er óskilgreind ef stærðin væri röng.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic vörður meðan verið er að klóna T-þætti.
        // Ef um panic er að ræða, verða þættir sem hafa verið skrifaðir í nýja ArcInner sleppt og þá losnar minnið.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Bendir á fyrsta þáttinn
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Allt á hreinu.Gleymdu vörðunni svo hún losi ekki nýja ArcInner.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Sérhæfing trait notuð fyrir `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Gerir klón af `Arc` bendlinum.
    ///
    /// Þetta skapar annan vísi að sömu úthlutun og eykur sterka viðmiðunartalningu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Að nota slaka röð er í lagi hér, þar sem þekking á upphaflegu tilvísuninni kemur í veg fyrir að aðrir þræðir eyði hlutnum ranglega.
        //
        // Eins og útskýrt er í [Boost documentation][1], er alltaf hægt að auka viðmiðunarteljara með minni_röðun: slökun: Nýjar tilvísanir í hlut geta aðeins myndast úr tilvísun sem fyrir er og það að senda núverandi tilvísun frá einum þræði til annars verður nú þegar að veita alla nauðsynlega samstillingu.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // En við verðum að verja gegn stórfelldum endurtalningum ef einhver er 'mem: : gleymir' bogum.
        // Ef við gerum þetta ekki getur talningin flætt yfir og notendur munu nota ókeypis.
        // Við mettumst í `isize::MAX` með þeim forsendum að það séu ekki ~2 milljarðar þræðir sem auka viðmiðunartalningu í einu.
        //
        // Þessi branch verður aldrei tekin í neinu raunhæfu prógrammi.
        //
        // Við hættir vegna þess að slíkt forrit er ótrúlega úrkynjað og okkur er sama um að styðja það.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Gerir breytanlega tilvísun í tiltekna `Arc`.
    ///
    /// Ef það eru aðrir `Arc` eða [`Weak`] vísar að sömu úthlutun, þá mun `make_mut` búa til nýja úthlutun og ákalla [`clone`][clone] á innra gildi til að tryggja einstakt eignarhald.
    /// Þetta er einnig kallað klón við skrif.
    ///
    /// Athugið að þetta er frábrugðið hegðun [`Rc::make_mut`] sem aftengir allar `Weak` vísbendingar sem eftir eru.
    ///
    /// Sjá einnig [`get_mut`][get_mut], sem mun mistakast frekar en einræktun.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Mun ekki klóna neitt
    /// let mut other_data = Arc::clone(&data); // Mun ekki klóna innri gögn
    /// *Arc::make_mut(&mut data) += 1;         // Klónar innri gögn
    /// *Arc::make_mut(&mut data) += 1;         // Mun ekki klóna neitt
    /// *Arc::make_mut(&mut other_data) *= 2;   // Mun ekki klóna neitt
    ///
    /// // Nú benda `data` og `other_data` á mismunandi úthlutanir.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Athugaðu að við höfum bæði sterka tilvísun og veika tilvísun.
        // Þannig að sleppa sterkri tilvísun okkar eingöngu mun ekki út af fyrir sig valda því að minni verður deilt út.
        //
        // Notaðu Acquire til að tryggja að við sjáum öll skrif til `weak` sem gerast áður en útgáfa skrifar (þ.e. minnkun) í `strong`.
        // Þar sem við erum með veika tölu eru engar líkur á því að ArcInner sjálft gæti verið úthlutað.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Annar sterkur bendill er til, svo við verðum að klóna.
            // Úthlutaðu minni til að leyfa að skrifa klóna gildi beint.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Slakað nægir í ofangreindu vegna þess að þetta er í grundvallaratriðum hagræðing: við erum alltaf að keppa með veikum ábendingum sem falla.
            // Versta mál, við enduðum á því að úthluta nýjum boga að óþörfu.
            //

            // Við fjarlægðum síðasta sterka dómara en það eru fleiri veikir dómarar eftir.
            // Við munum flytja innihaldið í nýjan boga og ógilda hina veiku dómstólana.
            //

            // Athugaðu að það er ekki mögulegt fyrir lestur `weak` að skila usize::MAX (þ.e. læst), þar sem veiku talninguna er aðeins hægt að læsa með þræði með sterkri tilvísun.
            //
            //

            // Veruleika eigin óbeina veikburða bendi okkar, svo að hann geti hreinsað ArcInner eftir þörfum.
            //
            let _weak = Weak { ptr: this.ptr };

            // Getur bara stolið gögnunum, það eina sem eftir er Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Við vorum eina tilvísunin af hvorri tegundinni;stökkva aftur upp sterku dómaratalninguna.
            //
            this.inner().strong.store(1, Release);
        }

        // Eins og með `get_mut()` er óöryggið í lagi vegna þess að viðmiðun okkar var ýmist einstök til að byrja með eða varð ein við einræktun innihaldsins.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Skilar breytilegri tilvísun í tiltekna `Arc`, ef engir aðrir `Arc` eða [`Weak`] vísar eru að sömu úthlutun.
    ///
    ///
    /// Skilar [`None`] annars, vegna þess að það er ekki öruggt að stökkbreyta sameiginlegu gildi.
    ///
    /// Sjá einnig [`make_mut`][make_mut], sem mun [`clone`][clone] innra gildi þegar það eru aðrar vísbendingar.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Þessi óöryggi er í lagi vegna þess að okkur er tryggt að bendillinn sem er skilað er *eini* bendillinn sem einhvern tíma verður skilað til T.
            // Viðmiðunartalningin okkar er örugglega 1 á þessum tímapunkti og við krafðumst að Boginn sjálfur væri `mut`, svo við erum að skila einu mögulegu tilvísuninni í innri gögnin.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Skilar breytilegri tilvísun í tiltekna `Arc`, án nokkurrar athugunar.
    ///
    /// Sjá einnig [`get_mut`], sem er öruggt og gerir viðeigandi eftirlit.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Ekki má vísa til annarra `Arc` eða [`Weak`] vísbendinga um sömu úthlutun meðan lánið er skilað.
    ///
    /// Þetta er léttvægt ef engar slíkar ábendingar eru til, til dæmis strax eftir `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Við erum varkár að *ekki* búi til tilvísun sem nær yfir "count" reitina, þar sem þetta myndi alias með samtímis aðgangi að viðmiðunartölunum (t.d.
        // eftir `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Ákveðið hvort þetta sé einstök tilvísun (þar með talin veik viðmið) til undirliggjandi gagna.
    ///
    ///
    /// Athugið að þetta þarf að læsa veiku talningu dómara.
    fn is_unique(&mut self) -> bool {
        // læstu fjölda veikra bendla ef við virðumst vera eini veiki vísari handhafa.
        //
        // Kaupsmerkið hér tryggir að samband gerist áður en skrifað er til `strong` (sérstaklega í `Weak::upgrade`) áður en `weak` talningin lækkar (í gegnum `Weak::drop`, sem notar losun).
        // Ef uppfærða veikburða dómstólnum var aldrei sleppt mun CAS hér mistakast svo okkur er sama um að samstilla.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Þetta þarf að vera `Acquire` til að samstilla við lækkun `strong` teljarans í `drop`-eini aðgangurinn sem gerist þegar einhverri en síðustu tilvísun er sleppt.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Útgáfuskrifin hér samstillast við lestur í `downgrade` og kemur þannig í veg fyrir að ofangreindur lestur `strong` gerist eftir skrif.
            //
            //
            self.inner().weak.store(1, Release); // slepptu lásnum
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Sleppir `Arc`.
    ///
    /// Þetta mun lækka sterka viðmiðunartalningu.
    /// Ef sterk viðmiðunartala nær núlli þá eru einu tilvísanirnar (ef einhverjar) [`Weak`], þannig að við `drop` innra gildi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Prentar ekki neitt
    /// drop(foo2);   // Prentar "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Vegna þess að `fetch_sub` er þegar lotukerfi þurfum við ekki að samstilla við aðra þræði nema við ætlum að eyða hlutnum.
        // Þessi sama rökfræði á við `fetch_sub` hér að neðan til `weak` talningarinnar.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Þessi girðing er nauðsynleg til að koma í veg fyrir endurröðun á notkun gagna og eyðingu gagna.
        // Vegna þess að það er merkt `Release` samstillist lækkun á viðmiðunartalningu við þessa `Acquire` girðingu.
        // Þetta þýðir að notkun gagnanna gerist áður en viðmiðunartalningu er fækkað, sem gerist fyrir þessa girðingu, sem gerist áður en gögnunum er eytt.
        //
        // Eins og útskýrt er í [Boost documentation][1],
        //
        // > Það er mikilvægt að framfylgja öllum mögulegum aðgangi að hlutnum í einum
        // > þráður (í gegnum núverandi tilvísun) til að *gerast áður en* eytt
        // > hlutinn í öðrum þræði.Þetta næst með "release"
        // > aðgerð eftir að hafa vísað frá sér (aðgangur að hlutnum
        // > í gegnum þessa tilvísun verður augljóslega að gerast áður), og
        // > "acquire" aðgerð áður en hlutnum er eytt.
        //
        // Sérstaklega, þó að innihald boga sé venjulega óbreytanlegt, þá er mögulegt að láta skrifa inn í eitthvað eins og Mutex<T>.
        // Þar sem Mutex er ekki aflað þegar honum er eytt getum við ekki treyst á samstillingarrökfræði þess til að gera skrif í þræði A sýnilegri eyðileggjanda sem keyrir í þræði B.
        //
        //
        // Athugaðu einnig að Acquire girðinguna hér gæti líklega verið skipt út fyrir Acquire load, sem gæti bætt árangur í miklum deilum.Sjá [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Reyndu að fella `Arc<dyn Any + Send + Sync>` niður í steypu gerð.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Smíðar nýjan `Weak<T>`, án þess að úthluta minni.
    /// Að hringja í [`upgrade`] á skilagildinu gefur alltaf [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Hjálpargerð til að leyfa aðgang að tilvísunartölunum án þess að fullyrða um gagnareitinn.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Skilar hráum bendli á hlutinn `T` sem þessi `Weak<T>` bendir á.
    ///
    /// Bendillinn er aðeins gildur ef það eru nokkrar sterkar tilvísanir.
    /// Bendillinn getur verið dinglandi, ósamstilltur eða jafnvel [`null`] annars.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Báðir benda á sama hlutinn
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Hinn sterki hér heldur því lifandi, svo við getum enn nálgast hlutinn.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // En ekki meira.
    /// // Við getum gert weak.as_ptr() en aðgangur að bendlinum myndi leiða til óskilgreindrar hegðunar.
    /// // assert_eq! (" halló`, óöruggur {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Ef bendillinn er dinglandi skilar við sentinel beint.
            // Þetta getur ekki verið gilt álagsföng, þar sem álagið er að minnsta kosti jafnast á við ArcInner (usize).
            ptr as *const T
        } else {
            // ÖRYGGI: ef is_dangling skilar fölsku, þá er hægt að vísa bendilinn.
            // Notkunarálagið gæti fallið niður á þessum tímapunkti og við verðum að halda uppruna, svo notaðu hráan bendilinn.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Eyðir `Weak<T>` og breytir því í hráan bendil.
    ///
    /// Þetta breytir veikum músinni í hráan bendilinn, en samt sem áður varðveitir eignarhald einnar veikrar tilvísunar (veiku talningunni er ekki breytt með þessari aðgerð).
    /// Það er hægt að breyta því aftur í `Weak<T>` með [`from_raw`].
    ///
    /// Sömu takmarkanir á aðgangi að marki bendilsins og við [`as_ptr`] eiga við.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Breytir hráum bendli sem áður var búinn til af [`into_raw`] aftur í `Weak<T>`.
    ///
    /// Þetta er hægt að nota til að fá sterka tilvísun á öruggan hátt (með því að hringja í [`upgrade`] seinna) eða til að samræma veikan fjölda með því að sleppa `Weak<T>`.
    ///
    /// Það tekur eignarhald á einni veikri tilvísun (að undanskildum ábendingum búin til af [`new`], þar sem þessir eiga ekki neitt; aðferðin virkar ennþá á þeim).
    ///
    /// # Safety
    ///
    /// Bendillinn hlýtur að vera upprunninn frá [`into_raw`] og verður samt að eiga mögulega veikan tilvísun.
    ///
    /// Það er leyfilegt að sterka talningin sé 0 þegar hringt er í þetta.
    /// Engu að síður tekur þetta eignarhald á einni veikri tilvísun sem nú er táknað sem hrá bendill (veiku talningunni er ekki breytt með þessari aðgerð) og því verður að para hana við fyrra símtal í [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Lækkaðu síðustu veiku talninguna.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Sjá Weak::as_ptr fyrir samhengi um hvernig innsláttarbendillinn er fenginn.

        let ptr = if is_dangling(ptr as *mut T) {
            // Þetta er dinglandi veikt.
            ptr as *mut ArcInner<T>
        } else {
            // Annars er okkur tryggt að bendillinn kom frá ótengdum veikleika.
            // ÖRYGGI: óhætt er að hringja í data_offset, þar sem ptr vísar til raunverulegs (hugsanlega lækkaðs) T.
            let offset = unsafe { data_offset(ptr) };
            // Þannig snúum við mótinu við til að fá alla RcBox.
            // ÖRYGGI: bendillinn er upprunninn frá veiku, svo þessi offset er örugg.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // ÖRYGGI: við höfum nú endurheimt upprunalega Veika bendilinn, svo við getum búið til Veika.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Reynir að uppfæra `Weak` bendilinn í [`Arc`] og seinka lækkun á innra gildi ef vel tekst til.
    ///
    ///
    /// Skilar [`None`] ef innra gildi hefur síðan verið lækkað.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Eyðileggja allar sterkar ábendingar.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Við notum CAS lykkju til að auka sterkan fjölda í staðinn fyrir fetch_add þar sem þessi aðgerð ætti aldrei að taka viðmiðunartalningu frá núlli upp í eina.
        //
        //
        let inner = self.inner()?;

        // Slakað álag vegna þess að öll skrif af 0 sem við getum athugað skilur reitinn í varanlegu núllástandi (þannig að "stale" lestur af 0 er fínn) og öll önnur gildi eru staðfest með CAS hér að neðan.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Sjá athugasemdir í `Arc::clone` fyrir því hvers vegna við gerum þetta (fyrir `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Slakað er vel í bilun vegna þess að við höfum engar væntingar um nýja ríkið.
            // Fá er nauðsynlegt til að velgengnismálið samstillist við `Arc::new_cyclic` þegar hægt er að frumstilla innra gildi eftir að `Weak` tilvísanir hafa þegar verið búnar til.
            // Í því tilfelli reiknum við með að fylgjast með upphafsgildinu að fullu.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // núll athugað hér að ofan
                Err(old) => n = old,
            }
        }
    }

    /// Fær fjölda sterkra (`Arc`) ábendinga sem benda á þessa úthlutun.
    ///
    /// Ef `self` var búið til með því að nota [`Weak::new`] mun það skila 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Fær áætlun um fjölda `Weak` ábendinga sem benda á þessa úthlutun.
    ///
    /// Ef `self` var búið til með því að nota [`Weak::new`], eða ef engar sterkar vísbendingar eru eftir, þá skilar þetta 0.
    ///
    /// # Accuracy
    ///
    /// Vegna smáatriða um útfærslu getur skilagildið verið slökkt með 1 í hvora áttina þegar aðrir þræðir eru að vinna með einhverjar " bogabrautir`eða " veikar` sem benda til sömu úthlutunar.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Þar sem við sáum að það var að minnsta kosti einn sterkur bendill eftir að hafa lesið veiku talninguna, vitum við að óbeina veiku tilvísunin (til staðar þegar sterkar tilvísanir eru á lífi) var enn til staðar þegar við sáum veiku talninguna og getum því dregið hana örugglega frá.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Skilar `None` þegar bendillinn hangir og enginn `ArcInner` er úthlutað (þ.e. þegar þessi `Weak` var búinn til af `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Við erum varkár að *ekki* búa til tilvísun sem nær yfir "data" reitinn, þar sem mögulega er breytt stöður á svæðinu (til dæmis, ef síðasti `Arc` er sleppt, verður gagnareitnum sleppt á sínum stað).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Skilar `true` ef hinir " veiku` benda til sömu úthlutunar (svipað og [`ptr::eq`]), eða ef báðir benda ekki á neina úthlutun (vegna þess að þeir voru stofnaðir með `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Þar sem þetta ber saman ábendingar þýðir það að `Weak::new()` muni jafna hvort annað, jafnvel þó að þeir bendi ekki á neina úthlutun.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Samanburður á `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Býr til klón af `Weak` bendlinum sem vísar til sömu úthlutunar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Sjá athugasemdir í Arc::clone() fyrir því hvers vegna slakað er á þessu.
        // Þetta getur notað fetch_add (hunsað lásinn) vegna þess að veiki talningin er aðeins læst þar sem *engin önnur* veik vísbending er til.
        //
        // (Þannig að við getum ekki keyrt þennan kóða í því tilfelli).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Sjá athugasemdir í Arc::clone() fyrir því hvers vegna við gerum þetta (fyrir mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Smíðar nýjan `Weak<T>`, án þess að úthluta minni.
    /// Að hringja í [`upgrade`] á skilagildinu gefur alltaf [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Sleppir `Weak` bendlinum.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Prentar ekki neitt
    /// drop(foo);        // Prentar "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Ef við komumst að því að við vorum síðasti veiki vísirinn, þá er kominn tími til að deila gögnum alfarið.Sjá umfjöllun í Arc::drop() um minnispöntunina
        //
        // Það er ekki nauðsynlegt að athuga hvort það sé læst ástand hér, því að veiku talningin er aðeins hægt að læsa ef það var einmitt einn veikur dómari, sem þýðir að fall gæti aðeins síðan keyrt Á þeim veiku dómara sem eftir er, sem getur aðeins gerst eftir að lásnum er sleppt.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Við erum að gera þessa sérhæfingu hér, og ekki sem almennari hagræðing á `&T`, því það myndi annars bæta kostnaði við alla jafnréttisathuganir á dómstólum.
/// Við gerum ráð fyrir að `Arc`s séu notuð til að geyma stór gildi, sem eru sein til að klóna, en einnig þung til að kanna hvort jafnrétti er, sem veldur því að þessi kostnaður borgar sig auðveldara.
///
/// Það er líka líklegra að hafa tvö `Arc` einrækt, sem benda á sama gildi, en tvö `&T`.
///
/// Við getum aðeins gert þetta þegar `T: Eq` sem `PartialEq` gæti verið vísvitandi óbragð.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Jöfnuður fyrir tvo `Arc`s.
    ///
    /// Tveir `bogar` eru jafnir ef innri gildi þeirra eru jöfn, jafnvel þó að þau séu geymd í mismunandi úthlutun.
    ///
    /// Ef `T` útfærir einnig `Eq` (sem gefur í skyn viðbrögð við jafnrétti), þá eru alltaf tveir `Arc` sem vísa til sömu úthlutunar jafnir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Ójöfnuður fyrir tvo " Arc`s.
    ///
    /// Tveir `bogar` eru ójafnir ef innri gildi þeirra eru ójöfn.
    ///
    /// Ef `T` útfærir einnig `Eq` (sem gefur í skyn viðbrögð við jafnrétti), þá eru tveir `Arc` sem benda á sama gildi aldrei ójafnir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Hluti samanburður fyrir tvo `Arc`s.
    ///
    /// Þessir tveir eru bornir saman með því að hringja í `partial_cmp()` á innri gildi þeirra.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Minna en samanburður fyrir tvo `Arc`s.
    ///
    /// Þessir tveir eru bornir saman með því að kalla `<` á innri gildi þeirra.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'Minna en eða jafnt og' samanburður fyrir tvo `Arc`s.
    ///
    /// Þessir tveir eru bornir saman með því að hringja í `<=` á innri gildi þeirra.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Meiri en samanburður fyrir tvo `Arc`s.
    ///
    /// Þessir tveir eru bornir saman með því að hringja í `>` á innri gildi þeirra.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'Meiri en eða jafnt og' samanburður fyrir tvo 'Arc'.
    ///
    /// Þessir tveir eru bornir saman með því að hringja í `>=` á innri gildi þeirra.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Samanburður á tveimur `Arc`s.
    ///
    /// Þessir tveir eru bornir saman með því að hringja í `cmp()` á innri gildi þeirra.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Býr til nýjan `Arc<T>`, með `Default` gildi fyrir `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Úthlutaðu tilvísunartölu sneið og fylltu hana með því að klóna hlutina " v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Úthlutaðu tilvísunartölu `str` og afritaðu `v` í það.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Úthlutaðu tilvísunartölu `str` og afritaðu `v` í það.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Færðu hlut í kassa í nýja, tilvísunartalda úthlutun.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Úthluta tilvísunartölu sneið og færa hluti 'v' inn í hana.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Leyfðu Vec að losa minni sitt en eyðileggja ekki innihald þess
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Tekur hvert frumefni í `Iterator` og safnar því í `Arc<[T]>`.
    ///
    /// # Frammistaðaeinkenni
    ///
    /// ## Almenna málið
    ///
    /// Almennt er söfnun í `Arc<[T]>` gerð með því að safna fyrst í `Vec<T>`.Það er þegar skrifað er eftirfarandi:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// þetta hagar sér eins og við skrifuðum:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Fyrsta úthlutunin gerist hér.
    ///     .into(); // Önnur úthlutun fyrir `Arc<[T]>` gerist hér.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Þetta mun úthluta eins oft og þarf til að smíða `Vec<T>` og þá mun það úthluta einu sinni til að breyta `Vec<T>` í `Arc<[T]>`.
    ///
    ///
    /// ## Iterators af þekktri lengd
    ///
    /// Þegar `Iterator` innleiðir `TrustedLen` og er af nákvæmri stærð, verður úthlutað einni úthlutun fyrir `Arc<[T]>`.Til dæmis:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Hér gerist bara ein úthlutun.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Sérhæfing trait notað til að safna í `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Þetta á við um `TrustedLen` endurtekningu.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // ÖRYGGI: Við verðum að tryggja að endurtekningartækið hafi nákvæma lengd og það höfum við.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Falla aftur að eðlilegri framkvæmd.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Fáðu offset innan `ArcInner` fyrir álagið á bak við bendi.
///
/// # Safety
///
/// Bendillinn verður að benda á (og hafa gild lýsigögn fyrir) áður gilt dæmi um T, en leyfa að sleppa T.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Stilltu óstærða gildið að lokum ArcInner.
    // Þar sem RcBox er repr(C) verður það alltaf síðasti reiturinn í minni.
    // ÖRYGGI: þar sem einu óstærðu gerðirnar mögulegar eru sneiðar, trait hlutir,
    // og utanaðkomandi gerðir, kröfur um inntak öryggis nægja sem stendur til að fullnægja kröfum align_of_val_raw;þetta er útfærsluatriði tungumálsins sem ekki er hægt að reiða sig á utan std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}