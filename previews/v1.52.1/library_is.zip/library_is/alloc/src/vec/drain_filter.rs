use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// Íterator sem notar lokun til að ákvarða hvort frumefni ætti að fjarlægja.
///
/// Þessi uppbygging er búin til af [`Vec::drain_filter`].
/// Sjá skjöl hennar til að fá frekari upplýsingar.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// Vísitala hlutarins sem verður skoðaður með næsta símtali til `next`.
    pub(super) idx: usize,
    /// Fjöldi atriða sem hefur verið tæmd (removed) hingað til.
    pub(super) del: usize,
    /// Upprunaleg lengd `vec` áður en hún er tæmd.
    pub(super) old_len: usize,
    /// Prófík síunnar.
    pub(super) pred: F,
    /// Fáni sem gefur til kynna að panic hafi átt sér stað í forsíðu síuprófsins.
    /// Þetta er notað sem vísbending í dropaframkvæmdinni til að koma í veg fyrir neyslu afgangsins af `DrainFilter`.
    /// Öllum óunnum hlutum verður aftur breytt í `vec` en engum fleiri hlutum verður sleppt eða prófað með síuforvaranum.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// Skilar tilvísun í undirliggjandi úthlutara.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Uppfærðu vísitöluna *eftir að* forvalið er kallað.
                // Ef vísitalan er uppfærð áður og forskeytið panics myndi þátturinn í þessari vísitölu leka út.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // Þetta er ansi klúðrað ríki og það er í raun ekki augljóslega rétt að gera.
                        // Við viljum ekki halda áfram að reyna að framkvæma `pred`, svo við bakskyggjum bara alla óunnu þættina og segjum vec að þeir séu ennþá til.
                        //
                        // Bakskyggnin er krafist til að koma í veg fyrir að tvöfaldur dropi af síðasta tæmdum hlutnum falli áður en panic í forsendunni.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Reyndu að neyta allra þátta sem eftir eru ef síuforritið hefur ekki ennþá læti.
        // Við munum bakskyggja alla þætti sem eftir eru, hvort sem við höfum þegar panikkað eða ef neyslan hér panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}