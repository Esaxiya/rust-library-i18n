use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Sérhæfingarmerki til að safna endurtekningarleiðslu í Vec meðan endurnýta er upprunaúthlutun, þ.e.
/// framkvæmd leiðslunnar á sínum stað.
///
/// SourceIter foreldrið trait er nauðsynlegt fyrir sérhæfða aðgerðina til að fá aðgang að úthlutuninni sem á að endurnýta.
/// En það er ekki nægjanlegt að sérhæfingin sé gild.
/// Sjá viðbótarmörk á impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-innri SourceIter/InPlaceIterable traits er aðeins útfærður af keðjum af millistykki <Adapter<Adapter<IntoIter>>> (allt í eigu core/std).
// Viðbótarmörk við útfærslur millistykki (umfram `impl<I: Trait> Trait for Adapter<I>`) eru aðeins háð öðrum traits sem þegar eru merktar sem sérhæfing traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. merkið fer ekki eftir líftíma gerða sem notendur fá.Modulo the Copy hole, sem nokkrar aðrar sérhæfingar eru nú þegar háðar.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Viðbótarkröfur sem ekki geta komið fram í gegnum trait bounds.Við treystum á fastan hátt í staðinn:
        // a) engin ZST þar sem engin úthlutun er til að endurnýta og bendilreikningur myndi panic b) stærð samsvarar eins og krafist er í Alloc samningi c) uppröðun passar eins og krafist er í Alloc samningi
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // bakslag í almennari útfærslur
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // notaðu try-fold síðan
        // - það vektorar betur fyrir suma endurgerðar millistykki
        // - ólíkt flestum innri endurtekningaraðferðum þarf aðeins &mut sjálf
        // - það leyfir okkur að þræða skrifa bendilinn í gegnum innvortið og fá hann aftur að lokum
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // endurtekning tókst, ekki sleppa höfði
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // athugaðu hvort SourceIter samningurinn var haldinn fyrirvari: ef þeir voru það gætum við ekki einu sinni náð þessu stigi
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // athugaðu InPlaceIterable samning.Þetta er aðeins mögulegt ef endurtekningin framsækir heimildarbendilinn yfirleitt.
        // Ef það notar ómerktan aðgang um TrustedRandomAccess þá mun heimildarbendillinn vera í upphafsstöðu og við getum ekki notað hann sem tilvísun
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // slepptu öllum gildum sem eftir eru í skottinu á upptökum en komið í veg fyrir lækkun á úthlutuninni sjálfri þegar IntoIter fer úr gildissviði ef dropinn panics þá lekum við líka öllum þáttum sem safnað er í dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // InPlaceIterable samningurinn er ekki hægt að staðfesta nákvæmlega hér þar sem try_fold hefur einkarétt tilvísun í heimildarbendilinn allt sem við getum gert er að athuga hvort hann sé enn innan sviðs
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}