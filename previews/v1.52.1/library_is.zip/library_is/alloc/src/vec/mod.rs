//! Samliggjandi ræktanleg tegund fylkis með hrúguúthlutuðu innihaldi, skrifað `Vec<T>`.
//!
//! Vectors eru með `O(1)` flokkun, afskrifað `O(1)` ýta (til enda) og `O(1)` pop (frá lokum).
//!
//!
//! Vectors tryggja að þeir úthluta aldrei meira en `isize::MAX` bæti.
//!
//! # Examples
//!
//! Þú getur sérstaklega búið til [`Vec`] með [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... eða með því að nota [`vec!`] fjölvi:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // tíu núll
//! ```
//!
//! Þú getur [`push`] gildi í lok vector (sem mun vaxa vector eftir þörfum):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Popping gildi virka á svipaðan hátt:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors styðja einnig flokkun (í gegnum [`Index`] og [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Samliggjandi ræktanleg tegund fylkis, skrifuð sem `Vec<T>` og áberandi 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// [`vec!`] fjölvi er til staðar til að gera frumstillingu þægilegri:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Það getur einnig frumstillt hvern þátt `Vec<T>` með tilteknu gildi.
/// Þetta getur verið skilvirkara en að framkvæma úthlutun og frumstilling í aðskildum skrefum, sérstaklega þegar frumstillt er á vector með núllum:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Eftirfarandi er jafngilt en hugsanlega hægara:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Nánari upplýsingar eru í [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Notaðu `Vec<T>` sem skilvirkan stafla:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Prent 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// `Vec` gerð gerir kleift að fá aðgang að gildum með vísitölu, vegna þess að hún útfærir [`Index`] trait.Dæmi verður skýrara:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // það mun birta '2'
/// ```
///
/// Vertu samt varkár: Ef þú reynir að fá aðgang að vísitölu sem ekki er í `Vec` mun hugbúnaðurinn þinn panic!Þú getur ekki gert þetta:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Notaðu [`get`] og [`get_mut`] ef þú vilt athuga hvort vísitalan sé í `Vec`.
///
/// # Slicing
///
/// `Vec` getur verið breytilegt.Aftur á móti eru sneiðar skrifvarðar hlutir.
/// Notaðu [`&`] til að fá [slice][prim@slice].Dæmi:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... og það er allt!
/// // þú getur líka gert það svona:
/// let u: &[usize] = &v;
/// // eða svona:
/// let u: &[_] = &v;
/// ```
///
/// Í Rust er algengara að senda sneiðar sem rök frekar en vectors þegar þú vilt bara veita lesaðgang.Sama gildir um [`String`] og [`&str`].
///
/// # Geta og endurúthlutun
///
/// Afkastageta vector er það pláss sem úthlutað er fyrir alla future þætti sem verður bætt við vector.Þessu er ekki að rugla saman við *lengd* vector, sem tilgreinir fjölda raunverulegra þátta innan vector.
/// Ef lengd vector er meiri en getu hans, verður afköst hennar sjálfkrafa aukin, en þætti hennar verður að endurúthluta.
///
/// Til dæmis væri vector með getu 10 og lengd 0 tómt vector með pláss fyrir 10 atriði í viðbót.Að þrýsta 10 eða færri þáttum á vector mun ekki breyta getu þess eða valda endurúthlutun.
/// Ef lengd vector er aukin í 11 verður hún að endurúthluta, sem getur verið hægt.Af þessum sökum er mælt með því að nota [`Vec::with_capacity`] þegar mögulegt er til að tilgreina hversu stórt vector er búist við.
///
/// # Guarantees
///
/// Vegna ótrúlega grundvallar eðli þess, gerir `Vec` mikla ábyrgð varðandi hönnun sína.Þetta tryggir að það sé eins lág kostnaður og mögulegt er í almennu tilviki og hægt er að vinna með réttum hætti á frumstæðan hátt með óöruggum kóða.Athugið að þessar ábyrgðir vísa til óhæfs `Vec<T>`.
/// Ef viðbótartegundarbreytum er bætt við (td til að styðja við sérsniðna úthlutun), getur það að hegðun vanskila þeirra breytt hegðun.
///
/// Í grundvallaratriðum er `Vec` og verður alltaf (bendill, getu, lengd) þríburi.Ekki meira, ekki síður.Röð þessara reita er algjörlega ótilgreind og þú ættir að nota viðeigandi aðferðir til að breyta þessum.
/// Bendillinn verður aldrei enginn, þannig að þessi tegund er bjartsýni að engu.
///
/// Hins vegar getur bendillinn í raun ekki bent á úthlutað minni.
/// Sérstaklega, ef þú smíðar `Vec` með getu 0 í gegnum [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], eða með því að hringja í [`shrink_to_fit`] á tómt Vec, úthlutar það ekki minni.Á sama hátt, ef þú geymir núllstærðar gerðir inni í `Vec`, úthlutar það ekki plássi fyrir þær.
/// *Athugið að í þessu tilfelli gæti `Vec` ekki tilkynnt [`capacity`] um 0*.
/// `Vec` mun úthluta ef og aðeins ef [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Almennt eru úthlutunarupplýsingar " Vec` mjög lúmskar-ef þú ætlar að úthluta minni með `Vec` og nota það í eitthvað annað (annað hvort til að fara í óöruggan kóða eða til að byggja upp þitt eigið minnisstuðna safn), vertu viss til að umráða þetta minni með því að nota `from_raw_parts` til að endurheimta `Vec` og sleppa því.
///
/// Ef `Vec`*hefur* úthlutað minni, þá er minnið sem það bendir á á hrúgunni (eins og skilgreint er af úthlutaranum Rust er stillt til að nota sjálfgefið) og bendillinn bendir á [`len`] frumstillta, samfellda þætti í röð (það sem þú myndir gera sjáðu hvort þú neyddir það í sneið), á eftir [`getu`]`,`[`len`] rökrétt einræktað, samliggjandi þættir.
///
///
/// Hægt er að sjá vector sem inniheldur frumefni `'a'` og `'b'` með getu 4 eins og hér að neðan.Efsti hlutinn er `Vec` struct, hann inniheldur bendi á höfuð úthlutunarinnar í hrúgunni, lengd og getu.
/// Neðsti hlutinn er úthlutunin á hrúgunni, samfelld minni blokk.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** táknar minni sem ekki er frumstillt, sjá [`MaybeUninit`].
/// - Note: ABI er ekki stöðugt og `Vec` veitir engar ábyrgðir varðandi minniskipulag sitt (þ.m.t. röð reita).
///
/// `Vec` mun aldrei framkvæma "small optimization" þar sem þættir eru í raun geymdir á staflinum af tveimur ástæðum:
///
/// * Það myndi gera erfiðara fyrir óöruggan kóða að nota `Vec` rétt.Innihald `Vec` hefði ekki stöðugt heimilisfang ef það væri aðeins fært og það væri erfiðara að ákvarða hvort `Vec` hefði raunverulega úthlutað minni.
///
/// * Það myndi refsa almennu málinu og stofna til viðbótar branch við alla aðganga.
///
/// `Vec` mun aldrei sjálfkrafa skreppa saman, jafnvel þó að það sé tómt.Þetta tryggir að engar óþarfar úthlutanir eða samningar eiga sér stað.Að tæma `Vec` og fylla það aftur upp í sama [`len`] ætti ekki að hringja í úthlutarann.Ef þú vilt losa um ónotað minni skaltu nota [`shrink_to_fit`] eða [`shrink_to`].
///
/// [`push`] og [`insert`] mun aldrei (endur) úthluta ef tilkynnt getu er nægjanlegt.[`push`] og [`insert`]*munu*(endur) úthluta ef [`len`]`==`[`getu`].Það er, skýrslugetan er alveg nákvæm og hægt er að treysta á hana.Það er jafnvel hægt að losa handvirkt minnið sem `Vec` úthlutar ef þess er óskað.
/// Aðferðir við innsetningu magns *geta* endurúthlutað, jafnvel þegar ekki er nauðsynlegt.
///
/// `Vec` ábyrgist ekki neina sérstaka vaxtarstefnu við endurúthlutun þegar hún er full, né þegar [`reserve`] er kallað.Núverandi stefna er grunn og það getur reynst æskilegt að nota óstöðugan vaxtarþátt.Hvaða stefna sem er notuð mun að sjálfsögðu tryggja *O*(1) afskrifað [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]`, og [`Vec::with_capacity(n)`][`Vec::with_capacity`], munu allir framleiða `Vec` með nákvæmlega umbeðna getu.
/// Ef [`len`]`==`[`getu`], (eins og gildir um [`vec!`] fjölvi), þá er hægt að breyta `Vec<T>` til og frá [`Box<[T]>`][owned slice] án þess að endurúthluta eða færa frumefnin.
///
/// `Vec` mun ekki skrifa sérstaklega yfir öll gögn sem fjarlægð eru úr þeim, heldur varðveita þau ekki sérstaklega.Einrænt minni þess er klóra rými sem það getur notað hvernig sem það vill.Það mun almennt bara gera það sem er hagkvæmast eða á annan hátt auðvelt í framkvæmd.Ekki treysta á að fjarlægð gögn verði eytt í öryggisskyni.
/// Jafnvel ef þú sleppir `Vec` getur biðminni hans einfaldlega verið endurnýttur af öðrum `Vec`.
/// Jafnvel þó að þú núllir " Vec` minni fyrst, þá getur það í raun ekki gerst vegna þess að fínstillirinn telur þetta ekki aukaverkun sem verður að varðveita.
/// Það er eitt tilfelli sem við munum ekki brjóta, þó að nota `unsafe` kóða til að skrifa til umfram getu, og auka síðan lengdina til að passa, er alltaf gild.
///
/// Eins og er tryggir `Vec` ekki röðina sem þættir eru felldir í.
/// Pöntunin hefur breyst að undanförnu og getur breyst aftur.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Innbyggðar aðferðir
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Smíðar nýjan, tóman `Vec<T>`.
    ///
    /// vector úthlutar ekki fyrr en þætti er ýtt á það.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Smíðar nýjan, tóman `Vec<T>` með tilgreindum afköstum.
    ///
    /// vector mun geta geymt nákvæmlega `capacity` þætti án endurúthlutunar.
    /// Ef `capacity` er 0, þá úthlutar vector ekki.
    ///
    /// Það er mikilvægt að hafa í huga að þó að skilað vector hafi *getu* tilgreint, þá mun vector hafa núll *lengd*.
    ///
    /// Til að útskýra mismun á lengd og getu, sjá *[Stærð og endurúthlutun]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector inniheldur enga hluti, jafnvel þó að það hafi getu til meira
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Þetta er allt gert án þess að endurúthluta ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... en þetta getur gert vector endurúthlutað
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Býr til `Vec<T>` beint úr hráum hlutum annars vector.
    ///
    /// # Safety
    ///
    /// Þetta er mjög óöruggt vegna fjölda innflytjenda sem ekki er merktur við:
    ///
    /// * `ptr` þarf að hafa verið úthlutað áður í gegnum [`String`]/` Vec<T>" (að minnsta kosti, það er mjög líklegt að það sé rangt ef það var ekki).
    /// * `T` þarf að hafa sömu stærð og aðlögun og það sem `ptr` var úthlutað með.
    ///   (`T` með minna ströngri röðun er ekki nægjanleg, röðunin þarf virkilega að vera jöfn til að fullnægja [`dealloc`] kröfunni um að úthluta verði minni og skipta um sama skipulag.)
    ///
    /// * `length` þarf að vera minna en eða jafnt og `capacity`.
    /// * `capacity` þarf að vera getu sem bendillinn fékk úthlutað með.
    ///
    /// Brot gegn þessu getur valdið vandamálum eins og að spilla innri gagnaskipan úthlutunaraðilans.Til dæmis er **ekki** óhætt að byggja `Vec<u8>` frá bendi til C `char` fylkis með lengd `size_t`.
    /// Það er heldur ekki öruggt að smíða einn úr `Vec<u16>` og lengd þess, því að úthlutaranum er annt um röðunina og þessar tvær gerðir eru með mismunandi röðun.
    /// Stuðaranum var úthlutað með röðun 2 (fyrir `u16`) en eftir að hafa breytt honum í `Vec<u8>` verður honum skipt við röðun 1.
    ///
    /// Eignarhald `ptr` færist í raun yfir á `Vec<T>` sem getur þá framselt, endurúthlutað eða breytt innihaldi minni sem bendillinn bendir á að vild.
    /// Gakktu úr skugga um að ekkert annað noti bendilinn eftir að þú kallar á þessa aðgerð.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Uppfærðu þetta þegar vec_into_raw_parts er stöðugt.
    ///     // Koma í veg fyrir að keyra eyðileggjanda 'v' svo við höfum fullkomna stjórn á úthlutuninni.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Dragðu fram ýmsar mikilvægar upplýsingar um `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Yfirskrift minni með 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Settu allt saman aftur í Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Smíðar nýjan, tóman `Vec<T, A>`.
    ///
    /// vector úthlutar ekki fyrr en þætti er ýtt á það.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Smíðar nýjan, tóman `Vec<T, A>` með tilgreindum afköstum með úthlutaðri úthlutun.
    ///
    /// vector mun geta geymt nákvæmlega `capacity` þætti án endurúthlutunar.
    /// Ef `capacity` er 0, þá úthlutar vector ekki.
    ///
    /// Það er mikilvægt að hafa í huga að þó að skilað vector hafi *getu* tilgreint, þá mun vector hafa núll *lengd*.
    ///
    /// Til að útskýra mismun á lengd og getu, sjá *[Stærð og endurúthlutun]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector inniheldur enga hluti, jafnvel þó að það hafi getu til meira
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Þetta er allt gert án þess að endurúthluta ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... en þetta getur gert vector endurúthlutað
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Býr til `Vec<T, A>` beint úr hráum hlutum annars vector.
    ///
    /// # Safety
    ///
    /// Þetta er mjög óöruggt vegna fjölda innflytjenda sem ekki er merktur við:
    ///
    /// * `ptr` þarf að hafa verið úthlutað áður í gegnum [`String`]/` Vec<T>" (að minnsta kosti, það er mjög líklegt að það sé rangt ef það var ekki).
    /// * `T` þarf að hafa sömu stærð og aðlögun og það sem `ptr` var úthlutað með.
    ///   (`T` með minna ströngri röðun er ekki nægjanleg, röðunin þarf virkilega að vera jöfn til að fullnægja [`dealloc`] kröfunni um að úthluta verði minni og skipta um sama skipulag.)
    ///
    /// * `length` þarf að vera minna en eða jafnt og `capacity`.
    /// * `capacity` þarf að vera getu sem bendillinn fékk úthlutað með.
    ///
    /// Brot gegn þessu getur valdið vandamálum eins og að spilla innri gagnaskipan úthlutunaraðilans.Til dæmis er **ekki** óhætt að byggja `Vec<u8>` frá bendi til C `char` fylkis með lengd `size_t`.
    /// Það er heldur ekki öruggt að smíða einn úr `Vec<u16>` og lengd þess, því að úthlutaranum er annt um röðunina og þessar tvær gerðir eru með mismunandi röðun.
    /// Stuðaranum var úthlutað með röðun 2 (fyrir `u16`) en eftir að hafa breytt honum í `Vec<u8>` verður honum skipt við röðun 1.
    ///
    /// Eignarhald `ptr` færist í raun yfir á `Vec<T>` sem getur þá framselt, endurúthlutað eða breytt innihaldi minni sem bendillinn bendir á að vild.
    /// Gakktu úr skugga um að ekkert annað noti bendilinn eftir að þú kallar á þessa aðgerð.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Uppfærðu þetta þegar vec_into_raw_parts er stöðugt.
    ///     // Koma í veg fyrir að keyra eyðileggjanda 'v' svo við höfum fullkomna stjórn á úthlutuninni.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Dragðu fram ýmsar mikilvægar upplýsingar um `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Yfirskrift minni með 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Settu allt saman aftur í Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Niðurbrot `Vec<T>` í hráefni þess.
    ///
    /// Skilar hráum músinni í undirliggjandi gögn, lengd vector (í þætti) og úthlutað afkastagetu gagnanna (í þætti).
    /// Þetta eru sömu rökin í sömu röð og rökin við [`from_raw_parts`].
    ///
    /// Eftir að hringt hefur verið í þessa aðgerð ber gesturinn ábyrgð á minni sem `Vec` hafði áður stjórnað.
    /// Eina leiðin til að gera þetta er að umbreyta hráa bendlinum, lengd og getu aftur í `Vec` með [`from_raw_parts`] aðgerðinni, sem gerir eyðileggjandanum kleift að framkvæma hreinsunina.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Við getum nú gert breytingar á íhlutunum, svo sem að flytja hráa bendilinn í samhæfða gerð.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Niðurbrot `Vec<T>` í hráefni þess.
    ///
    /// Skilar hráa bendlinum að undirliggjandi gögnum, lengd vector (í þáttum), úthlutaðri getu gagnanna (í þáttum) og úthlutaranum.
    /// Þetta eru sömu rökin í sömu röð og rökin við [`from_raw_parts_in`].
    ///
    /// Eftir að hringt hefur verið í þessa aðgerð ber gesturinn ábyrgð á minni sem `Vec` hafði áður stjórnað.
    /// Eina leiðin til að gera þetta er að umbreyta hráa bendlinum, lengd og getu aftur í `Vec` með [`from_raw_parts_in`] aðgerðinni, sem gerir eyðileggjandanum kleift að framkvæma hreinsunina.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Við getum nú gert breytingar á íhlutunum, svo sem að flytja hráa bendilinn í samhæfða gerð.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Skilar fjölda þátta sem vector getur geymt án þess að endurúthluta.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Áskilur getu fyrir að minnsta kosti `additional` fleiri þætti til að setja inn í tiltekna `Vec<T>`.
    /// Söfnunin gæti áskilið sér meira pláss til að forðast tíð endurúthlutun.
    /// Eftir að hafa hringt í `reserve` verður afkastageta meiri en eða jöfn `self.len() + additional`.
    /// Gerir ekkert ef getu er þegar næg.
    ///
    /// # Panics
    ///
    /// Panics ef nýja afkastagetan fer yfir `isize::MAX` bæti.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Áskilur lágmarksgetu fyrir nákvæmlega `additional` fleiri þætti til að setja inn í tiltekna `Vec<T>`.
    ///
    /// Eftir að hafa hringt í `reserve_exact` verður afkastageta meiri en eða jöfn `self.len() + additional`.
    /// Gerir ekkert ef afkastagetan er þegar næg.
    ///
    /// Athugið að úthlutarinn gæti gefið safninu meira pláss en það biður um.
    /// Þess vegna er ekki hægt að treysta á getu til að vera nákvæmlega í lágmarki.
    /// Kjósa `reserve` ef búast er við future innsetningum.
    ///
    /// # Panics
    ///
    /// Panics ef nýja afkastið flæðir yfir `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Reynir að panta afköst fyrir að minnsta kosti `additional` fleiri þætti til að setja inn í tiltekna `Vec<T>`.
    /// Söfnunin gæti áskilið sér meira pláss til að forðast tíð endurúthlutun.
    /// Eftir að hafa hringt í `try_reserve` verður afkastageta meiri en eða jöfn `self.len() + additional`.
    /// Gerir ekkert ef getu er þegar næg.
    ///
    /// # Errors
    ///
    /// Ef afköstin flæða yfir, eða úthlutarinn tilkynnir um bilun, þá er villu skilað.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Pantaðu minnið fyrirfram og farðu ef við getum það ekki
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Nú vitum við að þetta getur ekki OOM í miðri flóknu vinnu okkar
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // mjög flókið
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Reynir að áskilja lágmarksgetu fyrir nákvæmlega `additional` þætti til að setja í tiltekna `Vec<T>`.
    /// Eftir að hafa hringt í `try_reserve_exact` verður afkastageta meiri en eða jafnt og `self.len() + additional` ef hún skilar `Ok(())`.
    ///
    /// Gerir ekkert ef afkastagetan er þegar næg.
    ///
    /// Athugið að úthlutarinn gæti gefið safninu meira pláss en það biður um.
    /// Þess vegna er ekki hægt að treysta á getu til að vera nákvæmlega í lágmarki.
    /// Kjósa `reserve` ef búast er við future innsetningum.
    ///
    /// # Errors
    ///
    /// Ef afköstin flæða yfir, eða úthlutarinn tilkynnir um bilun, þá er villu skilað.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Pantaðu minnið fyrirfram og farðu ef við getum það ekki
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Nú vitum við að þetta getur ekki OOM í miðri flóknu vinnu okkar
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // mjög flókið
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Minnkar getu vector eins mikið og mögulegt er.
    ///
    /// Það fellur niður eins nálægt lengdinni og mögulegt er en úthlutarinn gæti samt tilkynnt vector að það sé pláss fyrir nokkra þætti í viðbót.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Afkastagetan er aldrei minni en lengdin og það er ekkert að gera þegar þeir eru jafnir, þannig að við getum forðast panic málið í `RawVec::shrink_to_fit` með því að hringja aðeins í það með meiri getu.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Minnkar getu vector með lægri mörkum.
    ///
    /// Getan verður áfram að minnsta kosti jafn stór og bæði lengdin og verðið sem fylgir.
    ///
    ///
    /// Ef núverandi afkastageta er minni en neðri mörkin, er þetta neitunarleysi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Breytir vector í [`Box<[T]>`][owned slice].
    ///
    /// Athugaðu að þetta mun fella niður umfram getu.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Öll umframgeta er fjarlægð:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Styttir vector, heldur fyrstu `len` þættunum og sleppir afganginum.
    ///
    /// Ef `len` er meiri en núverandi lengd vector hefur það engin áhrif.
    ///
    /// [`drain`] aðferðin getur líkt eftir `truncate` en veldur því að umframefnum er skilað í stað þess að falla.
    ///
    ///
    /// Athugaðu að þessi aðferð hefur engin áhrif á úthlutaða getu vector.
    ///
    /// # Examples
    ///
    /// Að stytta fimm þætti vector í tvo þætti:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Engin stytting á sér stað þegar `len` er meiri en núverandi lengd vector:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Styttist þegar `len == 0` jafngildir því að kalla [`clear`] aðferðina.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Þetta er öruggt vegna þess að:
        //
        // * sneiðin sem send er til `drop_in_place` er gild;`len > self.len` málið forðast að búa til ógilda sneið, og
        // * `len` á vector er minnkað áður en hringt er í `drop_in_place`, þannig að ekkert gildi fellur tvisvar frá ef `drop_in_place` væri panic einu sinni (ef það panics tvisvar fellur forritið niður).
        //
        //
        //
        unsafe {
            // Note: Það er viljandi að þetta er `>` en ekki `>=`.
            //       Að breyta því í `>=` hefur neikvæð áhrif á árangur í sumum tilvikum.
            //       Sjá #78884 fyrir meira.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Útdráttur sneið sem inniheldur allan vector.
    ///
    /// Ígildi `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Dregur út breytanlega sneið af öllu vector.
    ///
    /// Ígildi `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Skilar hráum bendli í biðminni vector.
    ///
    /// Sá sem hringir verður að sjá til þess að vector lifi þeim bendi sem þessi aðgerð skilar, ella vísar það til sorps.
    /// Að breyta vector getur valdið því að biðminni hans sé endurúthlutað, sem myndi einnig gera einhverjar vísbendingar um hann ógilda.
    ///
    /// Sá sem hringir verður einnig að sjá til þess að minnið sem bendillinn (non-transitively) bendir á sé aldrei skrifað til (nema inni í `UnsafeCell`) með því að nota þennan bendil eða einhvern bendi sem fenginn er frá honum.
    /// Ef þú þarft að stökkbreyta innihaldi sneiðarinnar skaltu nota [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Við skyggum á sömu nöfnu sneiðaraðferðina til að forðast að fara í gegnum `deref`, sem skapar millivísun.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Skilar óöruggum breytanlegum músara í biðminni vector.
    ///
    /// Sá sem hringir verður að sjá til þess að vector lifi þeim bendi sem þessi aðgerð skilar, ella vísar það til sorps.
    ///
    /// Að breyta vector getur valdið því að biðminni hans sé endurúthlutað, sem myndi einnig gera einhverjar vísbendingar um hann ógilda.
    ///
    /// # Examples
    ///
    /// ```
    /// // Úthlutaðu vector nógu stórum fyrir 4 þætti.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Ræst frumefni með hráum bendilinn skrifar og stilltu síðan lengdina.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Við skyggum á sömu nöfnu sneiðaraðferðina til að forðast að fara í gegnum `deref_mut`, sem skapar millivísun.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Skilar tilvísun í undirliggjandi úthlutara.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Neyðir lengd vector til `new_len`.
    ///
    /// Þetta er lágstigs aðgerð sem heldur engum venjulegum innflytjendum af gerðinni.
    /// Venjulega er lengd vector breytt með því að nota öruggar aðgerðir í staðinn, svo sem [`truncate`], [`resize`], [`extend`] eða [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` verður að vera minna en eða jafnt og [`capacity()`].
    /// - Það þarf að frumstilla þætti `old_len..new_len`.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Þessi aðferð getur verið gagnleg við aðstæður þar sem vector þjónar sem biðminni fyrir annan kóða, sérstaklega yfir FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Þetta er bara lágmarks beinagrind fyrir doc dæmið;
    /// # // ekki nota þetta sem upphafspunkt fyrir alvöru bókasafn.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Samkvæmt skjölum FFI aðferðarinnar, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // ÖRYGGI: Þegar `deflateGetDictionary` skilar `Z_OK`, heldur það að:
    ///     // 1. `dict_length` frumefni voru frumstillt.
    ///     // 2.
    ///     // `dict_length` <=getu (32_768) sem gerir `set_len` öruggt að hringja.
    ///     unsafe {
    ///         // Hringdu í FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... og uppfærðu lengdina í það sem var frumstillt.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Þó að eftirfarandi dæmi sé hljóð, þá er minnisleki þar sem innri vectors var ekki leystur fyrir `set_len` símtalið:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` er tómt svo ekki þarf að frumstilla neina þætti.
    /// // 2. `0 <= capacity` geymir alltaf hvað sem `capacity` er.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Venjulega, hér, myndi maður nota [`clear`] í staðinn til að sleppa innihaldinu rétt og þannig ekki leka minni.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Fjarlægir þátt úr vector og skilar því.
    ///
    /// Í staðinn fyrir fjarlægða þáttinn kemur síðasti þátturinn í vector.
    ///
    /// Þetta varðveitir ekki pöntun en er O(1).
    ///
    /// # Panics
    ///
    /// Panics ef `index` er utan marka.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Við skiptum sjálf [vísitölu] út fyrir síðasta þáttinn.
            // Athugið að ef markatakmarkið hér að ofan tekst þá verður að vera síðasti þátturinn (sem getur verið sjálf [vísitala] sjálfur).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Setur frumefni í stöðu `index` innan vector og færir alla þætti eftir það til hægri.
    ///
    ///
    /// # Panics
    ///
    /// Panics ef `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // rými fyrir nýja frumefnið
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // óskeikull Bletturinn til að setja nýju gildi
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Skiptu öllu yfir til að búa til pláss.
                // (Afritun " vísitölu` þáttarins í tvo staði í röð.)
                ptr::copy(p, p.offset(1), len - index);
                // Skrifaðu það með því að skrifa yfir fyrsta eintakið af `index` frumefni.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Fjarlægir og skilar frumefninu í stöðu `index` innan vector og færir alla þætti eftir það til vinstri.
    ///
    ///
    /// # Panics
    ///
    /// Panics ef `index` er utan marka.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // staðinn sem við erum að taka frá.
                let ptr = self.as_mut_ptr().add(index);
                // afrita það út, með óöruggt afrit af verðmætinu á staflinum og í vector á sama tíma.
                //
                ret = ptr::read(ptr);

                // Flyttu öllu niður til að fylla í þann stað.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Heldur aðeins þeim þáttum sem tilgreindir eru í forsendunni.
    ///
    /// Með öðrum orðum, fjarlægðu alla þætti `e` þannig að `f(&e)` skili `false`.
    /// Þessi aðferð starfar á sínum stað, heimsækir hverja einingu nákvæmlega einu sinni í upphaflegri röð og varðveitir röð þeirra þátta sem haldið er eftir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Vegna þess að þættirnir eru heimsóttir nákvæmlega einu sinni í upphaflegri röð, má nota ytra ástand til að ákveða hvaða þætti á að halda.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Forðist tvöfalt fall ef dropavörnin er ekki framkvæmd, þar sem við gætum gert nokkrar göt meðan á ferlinu stendur.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-unnar len-> |^-næst að athuga
        //                  | <-eytt cnt-> |
        //      | <-original_len-> |Haldið: Þættir sem eru forsendu skilar sannleikanum.
        //
        // Gat: Fært eða sleppt frumrifa.
        // Ómerkt: Ómerkt gild atriði.
        //
        // Þessi fallvörður verður kallaður til þegar forboð eða `drop` frumefnis læti.
        // Það færir ómerkta þætti til að hylja holur og `set_len` í rétta lengd.
        // Í þeim tilvikum þegar predicate og `drop` læti aldrei verður það bjartsýni.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // ÖRYGGI: Að sleppa ómerktum hlutum verður að vera gildur þar sem við snertum þá aldrei.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // ÖRYGGI: Eftir að hafa fyllt holur eru allir hlutir í samliggjandi minni.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // ÖRYGGI: Ómerktur þáttur verður að vera gildur.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Farðu snemma fram til að forðast tvöfalt fall ef `drop_in_place` læti.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // ÖRYGGI: Við snertum aldrei þennan þátt aftur eftir að hafa lækkað.
                unsafe { ptr::drop_in_place(cur) };
                // Við komum nú þegar mælaborðinu áfram.
                continue;
            }
            if g.deleted_cnt > 0 {
                // ÖRYGGI: `deleted_cnt`> 0, þannig að gatarauf má ekki skarast við núverandi frumefni.
                // Við notum afrit til að færa okkur og snertum aldrei þennan þátt aftur.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Allur hlutur er unninn.Þetta er hægt að fínstilla í `set_len` með LLVM.
        drop(g);
    }

    /// Fjarlægir alla hluti nema í röð í vector í röð sem leysast að sama takka.
    ///
    ///
    /// Ef vector er flokkað fjarlægir þetta öll afrit.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Fjarlægir alla hluti nema í röð í vector sem uppfylla tiltekið jafnréttissamband.
    ///
    /// `same_bucket` aðgerðinni er vísað til tveggja þátta úr vector og verður að ákvarða hvort þættirnir séu jafnir.
    /// Þættirnir eru sendir í gagnstæðri röð frá röð þeirra í sneiðinni, þannig að ef `same_bucket(a, b)` skilar `true` er `a` fjarlægður.
    ///
    ///
    /// Ef vector er flokkað fjarlægir þetta öll afrit.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Bætir við þætti aftan í safni.
    ///
    /// # Panics
    ///
    /// Panics ef nýja afkastagetan fer yfir `isize::MAX` bæti.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Þetta mun panic eða hætta ef við myndum úthluta> isize::MAX bæti eða ef lengdartíminn myndi flæða yfir fyrir núllstærðar gerðir.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Fjarlægir síðasta þáttinn úr vector og skilar honum, eða [`None`] ef hann er tómur.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Færir alla þætti `other` yfir í `Self` og skilur `other` eftir tómt.
    ///
    /// # Panics
    ///
    /// Panics ef fjöldi þátta í vector flæðir yfir `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Bætir þætti við `Self` úr öðrum biðminni.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Býr til tæmandi endurtekningu sem fjarlægir tiltekið svið í vector og skilar hlutunum sem fjarlægðir voru.
    ///
    /// Þegar iterator **er látinn detta** eru allir þættir á bilinu fjarlægðir úr vector, jafnvel þó að iteratorinn hafi ekki verið neyttur að fullu.
    /// Ef endurtekningartæki **er ekki** sleppt (með [`mem::forget`] til dæmis) er ótilgreint hversu margir þættir eru fjarlægðir.
    ///
    /// # Panics
    ///
    /// Panics ef upphafspunkturinn er meiri en endapunkturinn eða ef endapunkturinn er meiri en lengd vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Fullt svið hreinsar vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Minniöryggi
        //
        // Þegar Drain er fyrst búinn til styttir það lengd uppsprettunnar vector til að ganga úr skugga um að einingar sem ekki eru frumstilltir eða fluttir frá séu yfirleitt aðgengilegir ef eyðileggjandi Drain fær aldrei að hlaupa.
        //
        //
        // Drain mun ptr::read út gildin sem á að fjarlægja.
        // Þegar því er lokið er afgangur hala vec afritaður aftur til að hylja gatið og vector lengdin er aftur komin í nýja lengd.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // stilltu self.vec lengdina til að byrja, til að vera öruggur ef Drain lekur
            self.set_len(start);
            // Notaðu lánið í IterMut til að sýna lántökuhegðun alls Drain endurtekningar (eins og &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Hreinsar vector og fjarlægir öll gildi.
    ///
    /// Athugaðu að þessi aðferð hefur engin áhrif á úthlutaða getu vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Skilar fjölda þátta í vector, einnig nefndur 'length' þess.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Skilar `true` ef vector inniheldur enga þætti.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Skiptir söfnuninni í tvennt við tiltekna vísitölu.
    ///
    /// Skilar nýúthlutuðu vector sem inniheldur þættina á bilinu `[at, len)`.
    /// Eftir símtalið verður upprunalega vector skilin eftir og inniheldur þættina `[0, at)` með fyrri getu sína óbreytt.
    ///
    ///
    /// # Panics
    ///
    /// Panics ef `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // nýi vector getur tekið yfir upprunalega biðminnið og forðast afritið
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Óöruggt `set_len` og afritaðu hluti í `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Breytir stærð `Vec` á sínum stað þannig að `len` sé jafnt og `new_len`.
    ///
    /// Ef `new_len` er stærra en `len` er `Vec` framlengt með mismuninum, með hverri rauf til viðbótar fyllt með afleiðingunni af því að kalla lokunina `f`.
    ///
    /// Skilagildin frá `f` munu enda í `Vec` í þeirri röð sem þau hafa verið mynduð.
    ///
    /// Ef `new_len` er minna en `len` er `Vec` einfaldlega styttur.
    ///
    /// Þessi aðferð notar lokun til að skapa ný gildi við hvert álag.Ef þú vilt frekar [`Clone`] tiltekið gildi, notaðu [`Vec::resize`].
    /// Ef þú vilt nota [`Default`] trait til að búa til gildi geturðu sent [`Default::default`] sem seinni rökin.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Eyðir og lekur `Vec` og skilar breytilegri tilvísun í innihaldið, `&'a mut [T]`.
    /// Athugið að gerð `T` verður að lifa yfir kjörtímann `'a`.
    /// Ef tegundin hefur aðeins kyrrstæðar tilvísanir, eða engar, þá getur verið að þetta sé `'static`.
    ///
    /// Þessi aðgerð er svipuð [`leak`][Box::leak] aðgerðinni á [`Box`] nema að það er engin leið til að endurheimta minnið sem lekið hefur verið.
    ///
    ///
    /// Þessi aðgerð er aðallega gagnleg fyrir gögn sem lifa það sem eftir er af lífi forritsins.
    /// Ef þú skilar tilvísuninni aftur mun það valda minnisleka.
    ///
    /// # Examples
    ///
    /// Einföld notkun:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Skilar afgangsafgangi vector sem sneið af `MaybeUninit<T>`.
    ///
    /// Senda sneiðina er hægt að nota til að fylla vector með gögnum (td
    /// með því að lesa úr skrá) áður en gögnin eru merkt sem frumstillt með [`set_len`] aðferðinni.
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Úthlutaðu vector nógu stórum fyrir 10 þætti.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Fylltu út fyrstu 3 þættina.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Merktu við fyrstu 3 þættina í vector sem upphafsstafi.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Þessi aðferð er ekki útfærð með tilliti til `split_at_spare_mut`, til að koma í veg fyrir ógildingu ábendinga í biðminni.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Skilar vector innihaldi sem sneið af `T` ásamt því sem eftir er afkastagetu vector sem sneið af `MaybeUninit<T>`.
    ///
    /// Hægt er að nota skila afkastagetu til að fylla vector af gögnum (td með því að lesa úr skrá) áður en gögnin eru merkt sem frumstillt með [`set_len`] aðferðinni.
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Athugaðu að þetta er lágstigs API sem ætti að nota með varúð í hagræðingarskyni.
    /// Ef þú þarft að bæta við gögnum við `Vec` geturðu notað [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] eða [`resize_with`], allt eftir þínum þörfum.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Pantaðu viðbótar pláss sem er nógu stórt fyrir 10 þætti.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Fylltu út næstu 4 þætti.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Merktu við 4 þætti vector sem upphafsstaf.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len er hunsuð og því aldrei breytt
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Öryggi: að breyta skilað .2 (&mut stærð) er talið það sama og að hringja í `.set_len(_)`.
    ///
    /// Þessi aðferð er notuð til að hafa sérstakan aðgang að öllum vec hlutum í einu í `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` er tryggt að það gildi fyrir `len` þætti
        // - `spare_ptr` er að benda einum þætti framhjá biðminni, svo það skarist ekki við `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Breytir stærð `Vec` á sínum stað þannig að `len` sé jafnt og `new_len`.
    ///
    /// Ef `new_len` er stærra en `len`, er `Vec` framlengt með mismuninum, með hverri viðbótar rauf fyllt með `value`.
    ///
    /// Ef `new_len` er minna en `len` er `Vec` einfaldlega styttur.
    ///
    /// Þessi aðferð krefst þess að `T` innleiði [`Clone`], til að geta klónað framhjá gildi.
    /// Ef þú þarft meiri sveigjanleika (eða vilt treysta á [`Default`] í stað [`Clone`]) skaltu nota [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Einræktir og bætir öllum þáttum í sneið við `Vec`.
    ///
    /// Snerist yfir sneiðina `other`, einræktir hvern þátt og bætir því síðan við þennan `Vec`.
    /// `other` vector er keyrður í röð.
    ///
    /// Athugaðu að þessi aðgerð er sú sama og [`extend`] nema að það er sérhæft að vinna með sneiðar í staðinn.
    ///
    /// Ef og þegar Rust fær sérhæfingu verður þessi aðgerð líklega úrelt (en samt tiltæk).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Afritar þætti frá `src` sviðinu til enda vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` ábyrgist að tiltekið svið gildi fyrir verðtryggingu sjálfsins
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Þessi kóði alhæfir `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Framlengdu vector um `n` gildi með því að nota tiltekna rafala.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Notaðu SetLenOnDrop til að vinna úr villum þar sem þýðandi kann að átta sig ekki á versluninni í gegnum `ptr` í gegnum self.set_len() ekki alias.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Skrifaðu alla þætti nema þann síðasta
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Auka lengdina í hverju skrefi ef next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Við getum skrifað síðasta þáttinn beint án þess að klóna að óþörfu
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len sett af umfangsvörð
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Fjarlægir endurtekna þætti í röð í vector samkvæmt [`PartialEq`] trait útfærslunni.
    ///
    ///
    /// Ef vector er flokkað fjarlægir þetta öll afrit.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Innri aðferðir og aðgerðir
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` þarf að vera gild vísitala
    /// - `self.capacity() - self.len()` verður að vera `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len er aukið aðeins eftir frumstilling frumþátta
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - kallinn ábyrgist að src sé gild vísitala
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Element var bara frumstillt með `MaybeUninit::write`, svo það er allt í lagi að auka len
            // - len er aukið eftir hvern þátt til að koma í veg fyrir leka (sjá útgáfu #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - hringir ábyrgist að `src` sé gild vísitala
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Báðir ábendingar eru búnar til úr einstökum sneiðtilvísunum (`&mut [_]`) svo þær eru gildar og skarast ekki.
            //
            // - Þættir eru: Afrita svo það er í lagi að afrita þau, án þess að gera neitt með upphaflegu gildunum
            // - `count` er jafnt len `source`, svo heimildin gildir fyrir `count` les
            // - `.reserve(count)` ábyrgist að `spare.len() >= count` svo vara er í gildi fyrir `count` skrifar
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Þættirnir voru bara frumstilltir af `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Algengar trait útfærslur fyrir Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): með cfg(test) er ekki tiltæk innbyggð `[T]::to_vec` aðferð, sem krafist er fyrir þessa skilgreiningu aðferðar.
    // Notaðu í staðinn `slice::to_vec` aðgerðina sem er aðeins fáanleg með cfg(test) NB sjá slice::hack mát í slice.rs fyrir frekari upplýsingar
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // slepptu neinu sem ekki verður skrifað yfir
        self.truncate(other.len());

        // self.len <= other.len vegna styttingarinnar hér að ofan, þannig að sneiðarnar hér eru alltaf innan marka.
        //
        let (init, tail) = other.split_at(self.len());

        // endurnotið innihaldsgildin allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Býr til neyslulegan endurtekning, það er sem færir hvert gildi út úr vector (frá upphafi til enda).
    /// Ekki er hægt að nota vector eftir að hafa hringt í þetta.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s hefur gerð String, ekki &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // laufaðferð sem ýmsar SpecFrom/SpecExtend útfærslur framselja þegar þeir hafa engar frekari hagræðingar við
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Þetta á við um almenna endurtekningu.
        //
        // Þessi aðgerð ætti að vera siðferðileg jafngildi:
        //
        //      fyrir hlut í endurtekningu {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB getur ekki flætt yfir þar sem við hefðum þurft að úthluta heimilisfangssvæðinu
                self.set_len(len + 1);
            }
        }
    }

    /// Býr til splicterterator sem kemur í stað tilgreinds sviðs í vector með tilteknu `replace_with` endurtekningu og skilar hlutunum sem fjarlægðir voru.
    ///
    /// `replace_with` þarf ekki að vera í sömu lengd og `range`.
    ///
    /// `range` er fjarlægður jafnvel þótt endurtekningin sé ekki neytt fyrr en í lokin.
    ///
    /// Það er ótilgreint hversu margir þættir eru fjarlægðir úr vector ef `Splice` gildi er lekið.
    ///
    /// Inntak ítóran `replace_with` er aðeins neytt þegar `Splice` gildi fellur niður.
    ///
    /// Þetta er ákjósanlegt ef:
    ///
    /// * Skottið (þættir í vector eftir `range`) er tómt,
    /// * eða `replace_with` skilar færri eða jöfnum þáttum en lengd " sviðs`
    /// * eða neðri mörk `size_hint()` þess eru nákvæm.
    ///
    /// Annars er tímabundið vector úthlutað og halinn færður tvisvar.
    ///
    /// # Panics
    ///
    /// Panics ef upphafspunkturinn er meiri en endapunkturinn eða ef endapunkturinn er meiri en lengd vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Býr til endurtekningu sem notar lokun til að ákvarða hvort frumefni ætti að fjarlægja.
    ///
    /// Ef lokunin skilar sönnu, þá er þátturinn fjarlægður og gefinn.
    /// Ef lokunin skilar engu, verður frumefnið áfram í vector og verður endurtekningunni ekki skilað.
    ///
    /// Að nota þessa aðferð jafngildir eftirfarandi kóða:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // kóðann þinn hér
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// En `drain_filter` er auðveldara að nota.
    /// `drain_filter` er einnig skilvirkari, vegna þess að það getur aftur breytt liðum fylkisins í lausu.
    ///
    /// Athugaðu að `drain_filter` leyfir þér einnig að breyta öllum þáttum í síulokuninni, óháð því hvort þú velur að geyma eða fjarlægja hana.
    ///
    ///
    /// # Examples
    ///
    /// Skipta fylki í jafnvægi og líkur og endurnota upprunalegu úthlutunina:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Varist því að okkur leki (lekamagnun)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Framlengdu framkvæmdina sem afritar þætti úr tilvísunum áður en þú ýtir þeim á Vec.
///
/// Þessi útfærsla er sérhæfð fyrir slice iterators, þar sem hún notar [`copy_from_slice`] til að bæta við allri sneiðinni í einu.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Framkvæmir samanburð á vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Útfærir pöntun á vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // notaðu drop fyrir [T] notaðu hráa sneið til að vísa til þáttanna í vector sem veikustu nauðsynlegu gerðinni;
            //
            // gæti forðast gildisspurningar í ákveðnum tilvikum
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec sér um samningsumboð
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Býr til tómt `Vec<T>`.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: próf dregur í libstd, sem veldur villum hér
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: próf dregur í libstd, sem veldur villum hér
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Fær allt innihald `Vec<T>` sem fylki, ef stærð þess passar nákvæmlega við umbeðið fylki.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Ef lengdin passar ekki kemur inntakið aftur í `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Ef þér líður vel með að fá bara forskeyti af `Vec<T>` geturðu hringt í [`.truncate(N)`](Vec::truncate) fyrst.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // ÖRYGGI: `.set_len(0)` er alltaf hljóð.
        unsafe { vec.set_len(0) };

        // ÖRYGGI: Bendill " Vec` er alltaf rétt stilltur, og
        // röðunin sem fylkið þarfnast er sú sama og hlutirnir.
        // Við athuguðum áðan að við höfum næga hluti.
        // Atriðin falla ekki tvöfalt þar sem `set_len` segir `Vec` að sleppa þeim ekki.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}