//! Dýnamískt útsýni í samfellda röð, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Sneiðar eru útsýni inn í minnisblokk táknað sem bendill og lengd.
//!
//! ```
//! // sneiða Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // þvinga fylki að sneið
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Sneiðar eru annað hvort breytilegar eða deilt.
//! Sameiginleg sneiðategund er `&[T]`, en breytanleg tegund sneiðar er `&mut [T]`, þar sem `T` táknar frumgerðina.
//! Þú getur til dæmis breytt stöðum minni sem breytanleg sneið vísar til:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Hér eru nokkur atriði sem þessi eining inniheldur:
//!
//! ## Structs
//!
//! Það eru nokkrir strengir sem eru gagnlegir fyrir sneiðar, svo sem [`Iter`], sem táknar endurtekningu yfir sneið.
//!
//! ## Trait Útfærslur
//!
//! Það eru nokkrar útfærslur á sameiginlegum traits fyrir sneiðar.Nokkur dæmi eru meðal annars:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], fyrir sneiðar þar sem frumgerð er [`Eq`] eða [`Ord`].
//! * [`Hash`] - fyrir sneiðar þar sem frumgerð er [`Hash`].
//!
//! ## Iteration
//!
//! Sneiðarnar innleiða `IntoIterator`.Ítórinn gefur tilvísanir í sneiðarþættina.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Breytilega sneiðin gefur breytilegar tilvísanir í frumefnin:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Þessi endurtekning gefur breytilegar tilvísanir í þætti sneiðarinnar, þannig að á meðan frumefnisgerð sneiðarinnar er `i32`, þá er frumefnisgerð endurtekningarinnar `&mut i32`.
//!
//!
//! * [`.iter`] og [`.iter_mut`] eru skýr aðferðir til að skila sjálfgefnum endurtekningum.
//! * Frekari aðferðir sem skila endurtekningum eru [`.split`], [`.splitn`], [`.chunks`], [`.windows`] og fleira.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Margar af notkununum í þessari einingu eru eingöngu notaðar í prófunarstillingum.
// Það er hreinna að slökkva bara á viðvöruninni unused_imports en að laga þau.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Grundvallaraðferðir við framlengingu sneiða
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) þörf fyrir framkvæmd `vec!` fjölva meðan á prófun stendur NB, sjá `hack` eininguna í þessari skrá til að fá frekari upplýsingar.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) þörf fyrir framkvæmd `Vec::clone` meðan á prófun stendur NB, sjá `hack` eininguna í þessari skrá til að fá frekari upplýsingar.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Með cfg(test) `impl [T]` er ekki í boði, þessar þrjár aðgerðir eru í raun aðferðir sem eru í `impl [T]` en ekki í `core::slice::SliceExt`, við þurfum að veita þessar aðgerðir fyrir `test_permutations` prófið
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Við ættum ekki að bæta innbyggðum eiginleikum við þetta þar sem þetta er aðallega notað í `vec!` makró og veldur fullkominni afturför.
    // Sjá #71204 til að ræða og ná árangri.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // hlutir voru merktir upphafnir í lykkjunni hér að neðan
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) er nauðsynlegt fyrir LLVM að fjarlægja markatékka og hefur betri kóðun en zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec var úthlutað og frumstillt hér að ofan í að minnsta kosti þessa lengd.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // úthlutað hér að ofan með getu `s`, og frumstilla í `s.len()` í ptr::copy_to_non_overlapping hér að neðan.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Flokkar sneiðina.
    ///
    /// Þessi tegund er stöðug (þ.e. endurskipuleggur ekki jafna þætti) og *O*(*n*\*log(* n*)) í versta falli.
    ///
    /// Þegar við á er óstöðug flokkun æskilegri vegna þess að hún er yfirleitt hraðari en stöðug flokkun og hún úthlutar ekki aukaminni.
    /// Sjá [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Núverandi framkvæmd
    ///
    /// Núverandi reiknirit er aðlögunarhæfur, endurtekinn sameiningarflokkur innblásinn af [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Það er hannað til að vera mjög hratt í tilfellum þar sem sneiðin er næstum raðað, eða samanstendur af tveimur eða fleiri raðaðri röð sem er samtengd hvert á eftir öðru.
    ///
    ///
    /// Einnig úthlutar það tímabundinni geymslu sem er helmingi stærri en `self`, en í stuttum sneiðum er ekki notað úthlutunarflokkun.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Flokkar sneiðina með samanburðaraðgerð.
    ///
    /// Þessi tegund er stöðug (þ.e. endurskipuleggur ekki jafna þætti) og *O*(*n*\*log(* n*)) í versta falli.
    ///
    /// Samanburðaraðgerðin verður að skilgreina heildarskipun fyrir þætti í sneiðinni.Ef pöntunin er ekki heild er röð frumefnanna ótilgreind.
    /// Pöntun er heildarpöntun ef hún er (fyrir alla `a`, `b` og `c`):
    ///
    /// * samtals og ósamhverf: nákvæmlega einn af `a < b`, `a == b` eða `a > b` er sannur, og
    /// * transitive, `a < b` og `b < c` felur í sér `a < c`.Sama verður að gilda bæði fyrir `==` og `>`.
    ///
    /// Til dæmis, á meðan [`f64`] framkvæmir ekki [`Ord`] vegna `NaN != NaN`, getum við notað `partial_cmp` sem flokkunaraðgerð okkar þegar við vitum að sneiðin inniheldur ekki `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Þegar við á er óstöðug flokkun æskilegri vegna þess að hún er yfirleitt hraðari en stöðug flokkun og hún úthlutar ekki aukaminni.
    /// Sjá [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Núverandi framkvæmd
    ///
    /// Núverandi reiknirit er aðlögunarhæfur, endurtekinn sameiningarflokkur innblásinn af [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Það er hannað til að vera mjög hratt í tilfellum þar sem sneiðin er næstum raðað, eða samanstendur af tveimur eða fleiri raðaðri röð sem er samtengd hvert á eftir öðru.
    ///
    /// Einnig úthlutar það tímabundinni geymslu sem er helmingi stærri en `self`, en í stuttum sneiðum er ekki notað úthlutunarflokkun.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // öfugri flokkun
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Flokkar sneiðina með lykilútdráttaraðgerð.
    ///
    /// Þessi tegund er stöðug (þ.e. endurraðar ekki jöfnum þáttum) og *O*(*m*\* * n *\* log(*n*)) í versta falli, þar sem lykilaðgerðin er *O*(*m*).
    ///
    /// Fyrir dýrar lykilaðgerðir (td
    /// aðgerðir sem eru ekki einfaldur aðgangur að eignum eða grunnaðgerðir), [`sort_by_cached_key`](slice::sort_by_cached_key) er líklega verulega hraðari, þar sem það endurreiknar ekki frumlyklana.
    ///
    ///
    /// Þegar við á er óstöðug flokkun æskilegri vegna þess að hún er yfirleitt hraðari en stöðug flokkun og hún úthlutar ekki aukaminni.
    /// Sjá [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Núverandi framkvæmd
    ///
    /// Núverandi reiknirit er aðlögunarhæfur, endurtekinn sameiningarflokkur innblásinn af [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Það er hannað til að vera mjög hratt í tilfellum þar sem sneiðin er næstum raðað, eða samanstendur af tveimur eða fleiri raðaðri röð sem er samtengd hvert á eftir öðru.
    ///
    /// Einnig úthlutar það tímabundinni geymslu sem er helmingi stærri en `self`, en í stuttum sneiðum er ekki notað úthlutunarflokkun.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Flokkar sneiðina með lykilútdráttaraðgerð.
    ///
    /// Við flokkun er lykilaðgerð aðeins kölluð einu sinni á hvern þátt.
    ///
    /// Þessi tegund er stöðug (þ.e. endurskipuleggur ekki jafna þætti) og *O*(*m*\* * n *+* n *\* log(*n*)) í versta falli, þar sem lykilaðgerðin er *O*(*m*) .
    ///
    /// Fyrir einfaldar lykilaðgerðir (td aðgerðir sem eru aðgangur að eignum eða grunnaðgerðir) er líklegt að [`sort_by_key`](slice::sort_by_key) sé hraðari.
    ///
    /// # Núverandi framkvæmd
    ///
    /// Núverandi reiknirit er byggt á [pattern-defeating quicksort][pdqsort] eftir Orson Peters, sem sameinar hratt meðaltalstilvik slembiraðaðs kvikkorts með hraðasta versta falli mikils, en nær línulegum tíma á sneiðum með ákveðnum mynstrum.
    /// Það notar nokkrar slembiröðun til að forðast úrkynjuð tilfelli, en með fasta seed til að veita alltaf afgerandi hegðun.
    ///
    /// Í versta falli úthlutar reikniritið tímabundinni geymslu í `Vec<(K, usize)>` lengd sneiðarinnar.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Hjálparmakkó til að verðtryggja vector okkar með minnstu mögulegu gerð, til að draga úr úthlutun.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Þættir `indices` eru einstakir, þar sem þeir eru verðtryggðir, þannig að hvers konar verður stöðugt með tilliti til upprunalegu sneiðarinnar.
                // Við notum `sort_unstable` hér vegna þess að það þarf minni minni úthlutun.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Afritar `self` í nýjan `Vec`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Hér er hægt að breyta `s` og `x` sjálfstætt.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Afritar `self` í nýjan `Vec` með úthlutunaraðila.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Hér er hægt að breyta `s` og `x` sjálfstætt.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, sjá `hack` eininguna í þessari skrá til að fá frekari upplýsingar.
        hack::to_vec(self, alloc)
    }

    /// Breytir `self` í vector án klóna eða úthlutunar.
    ///
    /// Hægt er að breyta vector sem myndast aftur í kassa með 'Vec<T>`into_boxed_slice` aðferðin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` er ekki hægt að nota lengur vegna þess að því hefur verið breytt í `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, sjá `hack` eininguna í þessari skrá til að fá frekari upplýsingar.
        hack::into_vec(self)
    }

    /// Býr til vector með því að endurtaka sneið `n` sinnum.
    ///
    /// # Panics
    ///
    /// Þessi aðgerð mun panic ef afkastagetan myndi flæða yfir.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// A panic við flæði:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Ef `n` er stærra en núll, má skipta því sem `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` er talan sem táknað er með '1' bita `n` lengst til vinstri og `rem` er sá hluti `n` sem eftir er.
        //
        //

        // Notar `Vec` til að fá aðgang að `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` endurtekning er gerð með því að tvöfalda `buf` `expn`-sinnum.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Ef `m > 0` eru eftir bitar upp í vinstri '1'.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` hefur getu `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) endurtekning er gerð með því að afrita fyrstu `rem` endurtekningar úr `buf` sjálfum.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Þetta er ekki skarast síðan `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` jafngildir `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Fletur sneið af `T` út í eitt gildi `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Fletur sneið af `T` út í eitt gildi `Self::Output` og setur tiltekinn aðskilnað á milli hvers.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Fletur sneið af `T` út í eitt gildi `Self::Output` og setur tiltekinn aðskilnað á milli hvers.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Skilar vector sem inniheldur afrit af þessari sneið þar sem hvert bæti er kortlagt til ASCII jafngildis.
    ///
    ///
    /// ASCII stafir 'a' til 'z' eru kortlagðir við 'A' til 'Z', en stafir sem ekki eru ASCII eru óbreyttir.
    ///
    /// Notaðu [`make_ascii_uppercase`] til að hástafa gildinu á sínum stað.
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Skilar vector sem inniheldur afrit af þessari sneið þar sem hvert bæti er kortlagt til jafngildis ASCII lágstafa.
    ///
    ///
    /// ASCII stafir 'A' til 'Z' eru kortlagðir við 'a' til 'z', en stafir sem ekki eru ASCII eru óbreyttir.
    ///
    /// Notaðu [`make_ascii_lowercase`] til að lágmarka gildi á staðnum.
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Eftirnafn traits fyrir sneiðar yfir tilteknar tegundir gagna
////////////////////////////////////////////////////////////////////////////////

/// Hjálpari trait fyrir [`[T]: : concat`](sneið::concat).
///
/// Note: `Item` gerðarfæribreytan er ekki notuð í þessari trait, en hún gerir leyfi til að vera almennari.
/// Án þess fáum við þessa villu:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Þetta er vegna þess að það gætu verið til `V` gerðir með mörgum `Borrow<[_]>` tækjum, svo að margar `T` gerðir ættu við:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Sú gerð sem myndast eftir samsöfnun
    type Output;

    /// Útfærsla á [`[T]: : concat`](sneið::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Hjálpar trait fyrir [`[T]: : join`](sneið::join)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Sú gerð sem myndast eftir samsöfnun
    type Output;

    /// Útfærsla á [`[T]: : join`](sneið::join)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Standard trait útfærslur fyrir sneiðar
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // slepptu neinu í miðið sem verður ekki skrifað yfir
        target.truncate(self.len());

        // target.len <= self.len vegna styttingarinnar hér að ofan, þannig að sneiðarnar hér eru alltaf innan marka.
        //
        let (init, tail) = self.split_at(target.len());

        // endurnotið innihaldsgildin allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Setur `v[0]` í forflokkaða röð `v[1..]` svo að allt `v[..]` verði raðað.
///
/// Þetta er óaðskiljanlegur undirþáttur tegundar innsetningar.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Það eru þrjár leiðir til að innleiða innsetningu hér:
            //
            // 1. Skiptu um aðliggjandi þætti þar til sá fyrsti kemst á lokastað.
            //    Hins vegar afritum við gögn um meira en nauðsyn krefur.
            //    Ef þættir eru stór mannvirki (kostnaðarsamt að afrita) mun þessi aðferð ganga hægt.
            //
            // 2. Iterate þar til rétti staðurinn fyrir fyrsta þáttinn er fundinn.
            // Færðu síðan frumefnin eftir það til að búa til pláss fyrir það og settu það loks í gatið sem eftir er.
            // Þetta er góð aðferð.
            //
            // 3. Afritaðu fyrsta þáttinn í tímabundna breytu.Iterate þar til rétti staðurinn fyrir það er fundinn.
            // Þegar við höldum áfram skaltu afrita alla þætti sem farið er yfir í raufina á undan.
            // Að lokum, afritaðu gögn frá tímabundnu breytunni í það gat sem eftir er.
            // Þessi aðferð er mjög góð.
            // Viðmið sýndu aðeins betri afköst en með 2. aðferðinni.
            //
            // Allar aðferðir voru metnar og sú þriðja sýndi bestan árangur.Svo við völdum þann.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Milliríki innsetningarferlisins er alltaf rakið af `hole`, sem þjónar tvennum tilgangi:
            // 1. Verndar heilleika `v` frá panics í `is_less`.
            // 2. Fyllir holuna sem eftir er í `v` að lokum.
            //
            // Panic öryggi:
            //
            // Ef `is_less` panics á einhverjum tímapunkti meðan á ferlinu stendur mun `hole` falla niður og fylla gatið í `v` með `tmp` og tryggja þannig að `v` heldur ennþá á hverjum hlut sem það hélt upphaflega nákvæmlega einu sinni.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` fellur niður og afritar þannig `tmp` í það gat sem eftir er í `v`.
        }
    }

    // Þegar það er fellt, afrit af `src` í `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Sameinir keyrslu `v[..mid]` og `v[mid..]` sem ekki minnkar og notar `buf` sem tímabundna geymslu og geymir niðurstöðuna í `v[..]`.
///
/// # Safety
///
/// Sneiðarnar tvær verða að vera tómar og `mid` verður að vera innan marka.
/// Buffer `buf` verður að vera nógu langur til að geyma afrit af styttri sneiðinni.
/// Einnig má `T` ekki vera núllstór tegund.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Sameiningarferlið afritar fyrst styttri keyrslu í `buf`.
    // Síðan er rakið nýafritaða hlaupið og lengra hlaupið fram á við (eða afturábak), borið saman næstu óneysluðu þætti þeirra og afritun minni (eða meiri) í `v`.
    //
    // Um leið og skemmri hlaupið er að fullu neytt er ferlinu lokið.Ef lengra hlaup verður neytt fyrst verðum við að afrita það sem eftir er af styttri hlaupinu í það gat sem eftir er í `v`.
    //
    // Milliríki ferlisins er alltaf rakið af `hole`, sem þjónar tvennum tilgangi:
    // 1. Verndar heilleika `v` frá panics í `is_less`.
    // 2. Fyllir holuna sem eftir er í `v` ef lengri keyrslan verður neytt fyrst.
    //
    // Panic öryggi:
    //
    // Ef `is_less` panics á einhverjum tímapunkti meðan á ferlinu stendur mun `hole` falla niður og fylla holuna í `v` með ónotaða sviðinu í `buf` og tryggja þannig að `v` heldur ennþá á hverjum hlut sem það hélt upphaflega nákvæmlega einu sinni.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Vinstri hlaupið er styttra.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Upphaflega benda þessar ábendingar á upphaf fylkja þeirra.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Neyta minni hliðar.
            // Ef það er jafnt skaltu frekar velja vinstri hlaupið til að viðhalda stöðugleika.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Rétt hlaup er styttra.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Upphaflega benda þessi ábendingar framhjá endum fylkja þeirra.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Neyta meiri hliðar.
            // Ef það er jafnt skaltu kjósa rétt hlaup til að viðhalda stöðugleika.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Að lokum fellur `hole` niður.
    // Ef skemmri hlaupið var ekki að fullu neytt, verður það sem eftir er af því nú afritað í holuna á `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Þegar það er sleppt, afritaðu sviðið `start..end` í `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` er ekki núllstór tegund, svo það er í lagi að deila eftir stærð hennar.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Þessi sameiningarflokkur fær nokkrar (en ekki allar) hugmyndir frá TimSort, sem lýst er í smáatriðum [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// Reikniritið skilgreinir strangt lækkandi og ekki lækkandi eftirfylgni, sem kallast náttúruleg hlaup.Það er stafli af bið keyrslum sem enn á að sameina.
/// Hvert nýfundið hlaup er ýtt á stafla og síðan eru nokkur pör af aðliggjandi hlaupum sameinuð þar til þessar tvær innflytjendur eru sáttar:
///
/// 1. fyrir hvern `i` í `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. fyrir hvern `i` í `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Innflytjendurnir tryggja að heildartíminn sé *O*(*n*\*log(* n*)) í versta falli.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Sneiðar allt að þessari lengd flokkast með innsetningarflokkun.
    const MAX_INSERTION: usize = 20;
    // Mjög stutt hlaup eru lengd með því að nota innsetningarflokk til að spanna að minnsta kosti þessa mörgu þætti.
    const MIN_RUN: usize = 10;

    // Flokkun hefur enga þýðingarmikla hegðun á núllstærðum gerðum.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Stuttum fylkjum er raðað á staðinn með innsetningarflokkun til að forðast úthlutun.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Úthlutaðu biðminni til að nota sem skrafminni.Við höldum lengdinni 0 svo við getum geymt í henni grunn afrit af innihaldi `v` án þess að hætta á að læknarnir keyri á eintökum ef `is_less` panics.
    //
    // Þegar sameinaðar eru tvær flokkaðar keyrslur, geymir þessi biðminni afrit af styttri hlaupinu, sem mun alltaf hafa lengd í mesta lagi `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Til að bera kennsl á náttúruleg hlaup í `v` förum við það afturábak.
    // Það gæti virst undarleg ákvörðun, en íhugaðu þá staðreynd að sameining fer oftar í gagnstæða átt (forwards).
    // Samkvæmt viðmiðum er sameining fram á við örlítið hraðari en að sameinast afturábak.
    // Að lokum bætir árangur að bera kennsl á hlaup með því að fara aftur á bak.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Finndu næsta náttúrulega hlaup og snúðu því við ef það er stranglega lækkandi.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Settu nokkur atriði í hlaupið ef það er of stutt.
        // Innsetningarflokkun er hraðvirkari en sameiningarflokkun í stuttum röð, þannig að þetta bætir afköst verulega.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Ýttu þessu hlaupi upp á stafla.
        runs.push(Run { start, len: end - start });
        end = start;

        // Sameina nokkur pör af aðliggjandi hlaupum til að fullnægja innflytjendum.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Að lokum verður nákvæmlega ein keyrsla að vera áfram í staflinum.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Kannar stafla hlaupa og auðkennir næsta hlaupapar sem sameinast.
    // Nánar tiltekið, ef `Some(r)` er skilað þýðir það að `runs[r]` og `runs[r + 1]` verði sameinuð næst.
    // Ef reikniritið ætti að halda áfram að byggja nýja keyrslu í staðinn er `None` skilað.
    //
    // TimSort er frægur fyrir útfærslur á galla, eins og lýst er hér:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Kjarni sögunnar er: við verðum að framfylgja innflytjendunum í fjórum efstu hlaupunum á staflinum.
    // Að framfylgja þeim á aðeins efstu þremur nægir ekki til að tryggja að innflytjendur haldi áfram í *öllum* hlaupum í staflinum.
    //
    // Þessi aðgerð leitar rétt að invariants fyrir fjórum efstu hlaupunum.
    // Að auki, ef efsta hlaupið byrjar á vísitölu 0, mun það alltaf krefjast sameiningaraðgerðar þar til stafli er að fullu hruninn, til þess að ljúka tegundinni.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}