use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Þetta er ekki stöðugt yfirborð, en hjálpar til við að halda `?` ódýru á milli þeirra, jafnvel þó að LLVM geti ekki alltaf nýtt sér það núna.
    //
    // (Því miður eru niðurstöður og valkostur ekki í samræmi, svo ControlFlow getur ekki passað bæði.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}