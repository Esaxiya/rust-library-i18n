//! Forritaskil fyrir úthlutun minni

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// `AllocError` villan gefur til kynna úthlutunarbilun sem getur verið vegna auðlindar auðlinda eða eitthvað rangt þegar sameinuð eru inntaksrökin við þennan úthlutara.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (við þurfum á þessu að halda vegna trait villu)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Útfærsla `Allocator` getur úthlutað, vaxið, minnkað og deilt handahófskenndum gagnablokkum sem lýst er í gegnum [`Layout`][].
///
/// `Allocator` er hannað til að verða útfærður á ZST, tilvísunum eða snjöllum ábendingum vegna þess að ekki er hægt að færa úthlutara eins og `MyAlloc([u8; N])` án þess að uppfæra vísbendingar í úthlutað minni.
///
/// Ólíkt [`GlobalAlloc`][] er úthlutað núllstórum í `Allocator`.
/// Ef undirliggjandi úthlutari styður þetta ekki (eins og jemalloc) eða skilar engum bendi (eins og til dæmis `libc::malloc`), verður framkvæmdin að taka þetta.
///
/// ### Nú úthlutað minni
///
/// Sumar aðferðirnar krefjast þess að minni blokk verði *úthlutað* í gegnum úthlutunaraðila.Þetta þýðir að:
///
/// * upphafsnetfangi þess minnisblokks var áður skilað af [`allocate`], [`grow`] eða [`shrink`], og
///
/// * minni blokkin hefur ekki verið framseld í kjölfarið, þar sem blokkum er annaðhvort deilt út beint með því að fara í [`deallocate`] eða var breytt með því að fara í [`grow`] eða [`shrink`] sem skilar `Ok`.
///
/// Ef `grow` eða `shrink` hafa skilað `Err` er áfram liðinn bendill gildur.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Minni mátun
///
/// Sumar aðferðir krefjast þess að skipulag *passi* við minnisblokk.
/// Það sem það þýðir fyrir skipulag til "fit" sem minnisblokk þýðir (eða jafngildir því fyrir minnisblokk að "fit" skipulag) er að eftirfarandi skilyrði verða að vera:
///
/// * Úthluta verður blokkinni með sömu röðun og [`layout.align()`], og
///
/// * [`layout.size()`] sem fylgir verður að falla á bilinu `min ..= max`, þar sem:
///   - `min` er stærðin á því skipulagi sem síðast var notað til að úthluta blokkinni, og
///   - `max` er nýjasta raunverulega stærðin sem skilað er frá [`allocate`], [`grow`] eða [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Minni blokkir sem skilað er frá úthlutunaraðila verða að benda á gilt minni og halda gildi sínu þar til viðburðurinn og allir einræktir þess falla niður,
///
/// * einræktun eða flutningur úthlutunaraðila má ekki ógilda minnisblokka sem skilað er frá þessum úthlutara.Klónaður úthlutari verður að haga sér eins og sami úthlutarinn og
///
/// * hvaða bendi sem er á minnisblokk sem er [*currently allocated*] má senda til hvaða annarrar aðferðar sem úthlutar er.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Tilraunir til að úthluta minnisblokk.
    ///
    /// Þegar vel tekst til skilar hann [`NonNull<[u8]>`][NonNull] sem uppfyllir stærð og jöfnunarábyrgðir `layout`.
    ///
    /// Sú blokk sem skilað er gæti verið stærri en tilgreind er af `layout.size()` og ef til vill hefur innihald hennar verið frumstillt.
    ///
    /// # Errors
    ///
    /// Að skila `Err` gefur til kynna að annað hvort minnið sé uppurið eða `layout` uppfyllir ekki stærð úthlutunaraðila eða takmarkanir á jöfnun.
    ///
    /// Framkvæmdir eru hvattar til að skila `Err` við minni þreytu frekar en að fara í læti eða fella brott, en þetta er ekki ströng krafa.
    /// (Nánar tiltekið: það er *löglegt* að innleiða þetta trait ofan á undirliggjandi innlent úthlutunarbókasafn sem eyðir við minnisleysi.)
    ///
    /// Viðskiptavinir sem vilja hætta við útreikninga til að bregðast við úthlutunarvillu eru hvattir til að hringja í [`handle_alloc_error`] aðgerðina, frekar en að kalla beint til `panic!` eða álíka.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Haga sér eins og `allocate`, en tryggir einnig að skilt minni sé núllstilla.
    ///
    /// # Errors
    ///
    /// Að skila `Err` gefur til kynna að annað hvort minnið sé uppurið eða `layout` uppfyllir ekki stærð úthlutunaraðila eða takmarkanir á jöfnun.
    ///
    /// Framkvæmdir eru hvattar til að skila `Err` við minni þreytu frekar en að fara í læti eða fella brott, en þetta er ekki ströng krafa.
    /// (Nánar tiltekið: það er *löglegt* að innleiða þetta trait ofan á undirliggjandi innlent úthlutunarbókasafn sem eyðir við minnisleysi.)
    ///
    /// Viðskiptavinir sem vilja hætta við útreikninga til að bregðast við úthlutunarvillu eru hvattir til að hringja í [`handle_alloc_error`] aðgerðina, frekar en að kalla beint til `panic!` eða álíka.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // ÖRYGGI: `alloc` skilar gildri minnisblokk
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Dreifir minni sem `ptr` vísar til.
    ///
    /// # Safety
    ///
    /// * `ptr` verður að tákna minnisblokk [*currently allocated*] í gegnum þennan úthlutara og
    /// * `layout` verður [*fit*] þessi minnisblokk.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Reynir að lengja minnisblokkina.
    ///
    /// Skilar nýjum [`NonNull<[u8]>`][NonNull] sem inniheldur bendi og raunverulega stærð úthlutaðs minni.Bendillinn er hentugur til að geyma gögn sem `new_layout` lýsir.
    /// Til að ná þessu fram getur úthlutarinn framlengt úthlutunina sem `ptr` vísar til þannig að hún passi við nýja skipulagið.
    ///
    /// Ef þetta skilar `Ok` hefur eignarhald á minni blokkinni sem `ptr` vísar til hefur verið fært til þessa úthlutunaraðila.
    /// Minni getur verið frelsað eða ekki og ætti að teljast ónothæft nema það hafi verið flutt aftur til þess sem hringir aftur með skilagildi þessarar aðferðar.
    ///
    /// Ef þessi aðferð skilar `Err`, þá hefur eignarhald á minnisblokkinni ekki verið flutt til þessa úthlutunaraðila og innihald minnisblokkarinnar er óbreytt.
    ///
    /// # Safety
    ///
    /// * `ptr` verður að tákna minnisblokk [*currently allocated*] í gegnum þennan úthlutara.
    /// * `old_layout` verður að [*fit*] þessi minnisblokk (`new_layout` rökin þurfa ekki að passa það.).
    /// * `new_layout.size()` verður að vera meira en eða jafnt og `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Skilar `Err` ef nýja skipulagið uppfyllir ekki stærð úthlutunar og takmörkun úthlutunar úthlutunaraðilans, eða ef vaxandi mistekst á annan hátt.
    ///
    /// Framkvæmdir eru hvattar til að skila `Err` við minni þreytu frekar en að fara í læti eða fella brott, en þetta er ekki ströng krafa.
    /// (Nánar tiltekið: það er *löglegt* að innleiða þetta trait ofan á undirliggjandi innlent úthlutunarbókasafn sem eyðir við minnisleysi.)
    ///
    /// Viðskiptavinir sem vilja hætta við útreikninga til að bregðast við úthlutunarvillu eru hvattir til að hringja í [`handle_alloc_error`] aðgerðina, frekar en að kalla beint til `panic!` eða álíka.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // ÖRYGGI: vegna þess að `new_layout.size()` verður að vera stærra en eða jafnt og
        // `old_layout.size()`, bæði gamla og nýja minniúthlutunin gildir fyrir lestur og ritun fyrir `old_layout.size()` bæti.
        // Einnig, vegna þess að gamla úthlutunin var ekki enn úthlutað, getur hún ekki skarast `new_ptr`.
        // Þannig er símtalið við `copy_nonoverlapping` öruggt.
        // Sá sem hringir þarf að standa við öryggissamninginn fyrir `dealloc`.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Haga sér eins og `grow`, en tryggir einnig að nýja innihaldið sé stillt á núll áður en því er skilað.
    ///
    /// Minni blokkin mun innihalda eftirfarandi innihald eftir að hringt hefur verið í
    /// `grow_zeroed`:
    ///   * Bytes `0..old_layout.size()` eru varðveitt frá upphaflegri úthlutun.
    ///   * Bytes `old_layout.size()..old_size` verður annað hvort varðveitt eða núllað, fer eftir úthlutun úthlutunaraðila.
    ///   `old_size` átt við stærð minni blokkar fyrir `grow_zeroed` símtalið, sem getur verið stærri en sú stærð sem upphaflega var beðið um þegar henni var úthlutað.
    ///   * Bytes `old_size..new_size` eru núllsett.`new_size` vísar til stærðar minni blokkar sem `grow_zeroed` símtalið skilaði.
    ///
    /// # Safety
    ///
    /// * `ptr` verður að tákna minnisblokk [*currently allocated*] í gegnum þennan úthlutara.
    /// * `old_layout` verður að [*fit*] þessi minnisblokk (`new_layout` rökin þurfa ekki að passa það.).
    /// * `new_layout.size()` verður að vera meira en eða jafnt og `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Skilar `Err` ef nýja skipulagið uppfyllir ekki stærð úthlutunar og takmörkun úthlutunar úthlutunaraðilans, eða ef vaxandi mistekst á annan hátt.
    ///
    /// Framkvæmdir eru hvattar til að skila `Err` við minni þreytu frekar en að fara í læti eða fella brott, en þetta er ekki ströng krafa.
    /// (Nánar tiltekið: það er *löglegt* að innleiða þetta trait ofan á undirliggjandi innlent úthlutunarbókasafn sem eyðir við minnisleysi.)
    ///
    /// Viðskiptavinir sem vilja hætta við útreikninga til að bregðast við úthlutunarvillu eru hvattir til að hringja í [`handle_alloc_error`] aðgerðina, frekar en að kalla beint til `panic!` eða álíka.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // ÖRYGGI: vegna þess að `new_layout.size()` verður að vera stærra en eða jafnt og
        // `old_layout.size()`, bæði gamla og nýja minniúthlutunin gildir fyrir lestur og ritun fyrir `old_layout.size()` bæti.
        // Einnig, vegna þess að gamla úthlutunin var ekki enn úthlutað, getur hún ekki skarast `new_ptr`.
        // Þannig er símtalið við `copy_nonoverlapping` öruggt.
        // Sá sem hringir þarf að standa við öryggissamninginn fyrir `dealloc`.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Reynir að minnka minnisblokkina.
    ///
    /// Skilar nýjum [`NonNull<[u8]>`][NonNull] sem inniheldur bendi og raunverulega stærð úthlutaðs minni.Bendillinn er hentugur til að geyma gögn sem `new_layout` lýsir.
    /// Til að ná þessu fram getur úthlutarinn dregið saman úthlutunina sem `ptr` vísar til svo hún passi við nýja skipulagið.
    ///
    /// Ef þetta skilar `Ok` hefur eignarhald á minni blokkinni sem `ptr` vísar til hefur verið fært til þessa úthlutunaraðila.
    /// Minni getur verið frelsað eða ekki og ætti að teljast ónothæft nema það hafi verið flutt aftur til þess sem hringir aftur með skilagildi þessarar aðferðar.
    ///
    /// Ef þessi aðferð skilar `Err`, þá hefur eignarhald á minnisblokkinni ekki verið flutt til þessa úthlutunaraðila og innihald minnisblokkarinnar er óbreytt.
    ///
    /// # Safety
    ///
    /// * `ptr` verður að tákna minnisblokk [*currently allocated*] í gegnum þennan úthlutara.
    /// * `old_layout` verður að [*fit*] þessi minnisblokk (`new_layout` rökin þurfa ekki að passa það.).
    /// * `new_layout.size()` verður að vera minni en eða jafn `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Skilar `Err` ef nýja skipulagið uppfyllir ekki stærð úthlutunar og takmörkun úthlutunar úthlutunaraðilans, eða ef samdráttur annars mistekst.
    ///
    /// Framkvæmdir eru hvattar til að skila `Err` við minni þreytu frekar en að fara í læti eða fella brott, en þetta er ekki ströng krafa.
    /// (Nánar tiltekið: það er *löglegt* að innleiða þetta trait ofan á undirliggjandi innlent úthlutunarbókasafn sem eyðir við minnisleysi.)
    ///
    /// Viðskiptavinir sem vilja hætta við útreikninga til að bregðast við úthlutunarvillu eru hvattir til að hringja í [`handle_alloc_error`] aðgerðina, frekar en að kalla beint til `panic!` eða álíka.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // ÖRYGGI: vegna þess að `new_layout.size()` verður að vera lægra en eða jafnt og
        // `old_layout.size()`, bæði gamla og nýja minniúthlutunin gildir fyrir lestur og ritun fyrir `new_layout.size()` bæti.
        // Einnig, vegna þess að gamla úthlutunin var ekki enn úthlutað, getur hún ekki skarast `new_ptr`.
        // Þannig er símtalið við `copy_nonoverlapping` öruggt.
        // Sá sem hringir þarf að standa við öryggissamninginn fyrir `dealloc`.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Býr til "by reference" millistykki fyrir þetta dæmi um `Allocator`.
    ///
    /// Millistykki sem skilað er útfærir einnig `Allocator` og mun einfaldlega fá þetta lánað.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // ÖRYGGI: kallinn verður að standa við öryggissamninginn
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ÖRYGGI: kallinn verður að standa við öryggissamninginn
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ÖRYGGI: kallinn verður að standa við öryggissamninginn
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ÖRYGGI: kallinn verður að standa við öryggissamninginn
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}