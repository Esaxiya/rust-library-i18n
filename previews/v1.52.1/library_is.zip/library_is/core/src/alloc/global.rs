use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Minni úthlutun sem hægt er að skrá sem sjálfgefið venjulegt bókasafn í gegnum `#[global_allocator]` eiginleikann.
///
/// Sumar aðferðirnar krefjast þess að minni blokk verði *úthlutað* í gegnum úthlutunaraðila.Þetta þýðir að:
///
/// * upphafsnetfangi þess minnisblokks var áður skilað með fyrra símtali í úthlutunaraðferð eins og `alloc` og
///
/// * minni blokkin hefur ekki verið framseld í kjölfarið, þar sem blokkum er úthlutað annaðhvort með því að fara til aðferðaraðferðar eins og `dealloc` eða með því að fara til endurúthlutunaraðferðar sem skilar bendli sem ekki er núll.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// `GlobalAlloc` trait er `unsafe` trait af ýmsum ástæðum og framkvæmdaraðilar verða að sjá til þess að þeir standist þessa samninga:
///
/// * Það er óskilgreint atferli ef alþjóðlegir úthlutarar slaka á.Þessari takmörkun má aflétta í future, en eins og er panic frá einhverjum af þessum aðgerðum getur það leitt til óöryggis í minni.
///
/// * `Layout` fyrirspurnir og útreikningar almennt verða að vera réttir.Hringjendur þessarar trait hafa heimild til að reiða sig á samningana sem skilgreindir eru í hverri aðferð og framkvæmdaraðilar verða að sjá til þess að slíkir samningar haldist sannir.
///
/// * Þú getur ekki treyst því að úthlutanir gerist í raun, jafnvel þó að það séu skýr hrúgaúthlutanir í upptökum.
/// Hagræðingartækið gæti greint ónýttar úthlutanir sem það getur annað hvort útrýmt að öllu leyti eða farið í stafla og þannig ekki kallað á úthlutarann.
/// Fínstillirinn getur ennfremur gert ráð fyrir að úthlutun sé óskeikul, þannig að númer sem áður mistókst vegna úthlutunar úthlutunaraðila gæti nú skyndilega virkað vegna þess að fínstillirinn vann í kringum þörfina fyrir úthlutun.
/// Nánar tiltekið er eftirfarandi kóðadæmi órólegt, óháð því hvort sérsniðni úthlutarinn þinn leyfir að telja hversu margar úthlutanir hafa gerst.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Athugaðu að hagræðingin sem nefnd er hér að ofan er ekki eina hagræðingin sem hægt er að beita.Þú getur almennt ekki treyst því að hrúgaúthlutanir gerist ef hægt er að fjarlægja þær án þess að breyta forriti.
///   Hvort úthlutun gerist eða ekki er ekki hluti af atferli forritsins, jafnvel þó að hægt væri að greina það með úthlutara sem rekur úthlutun með því að prenta eða á annan hátt hafa aukaverkanir.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Úthlutaðu minni eins og lýst er með gefnu `layout`.
    ///
    /// Skilar bendi í nýúthlutað minni, eða núll til að gefa til kynna úthlutunartilvik.
    ///
    /// # Safety
    ///
    /// Þessi aðgerð er óörugg vegna þess að óskilgreind hegðun getur orðið til ef sá sem hringir tryggir ekki að `layout` sé stærð sem ekki er núll.
    ///
    /// (Eftirnafn framlenginga gæti veitt sértækari mörk á hegðun, td tryggt netfang sent eða núllmerki sem svar við beiðni um úthlutun í núllstærð.)
    ///
    /// Úthlutað minni blokk getur verið frumstillt eða ekki.
    ///
    /// # Errors
    ///
    /// Að skila núll bendi gefur til kynna að annaðhvort minni sé uppurið eða `layout` uppfylli ekki stærð þessa eða úthlutunar takmarkana.
    ///
    /// Framkvæmdir eru hvattar til að skila núlli þegar minnið er klárað frekar en að eyða, en þetta er ekki ströng krafa.
    /// (Nánar tiltekið: það er *löglegt* að innleiða þetta trait ofan á undirliggjandi innlent úthlutunarbókasafn sem eyðir við minnisleysi.)
    ///
    /// Viðskiptavinir sem vilja hætta við útreikninga til að bregðast við úthlutunarvillu eru hvattir til að hringja í [`handle_alloc_error`] aðgerðina, frekar en að kalla beint til `panic!` eða álíka.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Dreifðu minnisblokkinni við tiltekinn `ptr` bendi með gefnum `layout`.
    ///
    /// # Safety
    ///
    /// Þessi aðgerð er óörugg vegna þess að óskilgreind hegðun getur orðið til ef sá sem hringir tryggir ekki allt eftirfarandi:
    ///
    ///
    /// * `ptr` verður að tákna minnisblokk sem nú er úthlutað í gegnum þennan úthlutara,
    ///
    /// * `layout` verður að vera sama skipulag og var notað til að úthluta þeim minnisblokk.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Haga sér eins og `alloc`, en tryggir einnig að innihaldið sé stillt á núll áður en því er skilað.
    ///
    /// # Safety
    ///
    /// Þessi aðgerð er óörugg af sömu ástæðum og `alloc` er.
    /// En úthlutað minni blokk er tryggt að frumstilla.
    ///
    /// # Errors
    ///
    /// Að skila núll bendi gefur til kynna að annað hvort sé minnislaust eða `layout` uppfyllir ekki stærð úthlutunaraðila eða takmörkunaraðlögunar, rétt eins og í `alloc`.
    ///
    /// Viðskiptavinir sem vilja hætta við útreikninga til að bregðast við úthlutunarvillu eru hvattir til að hringja í [`handle_alloc_error`] aðgerðina, frekar en að kalla beint til `panic!` eða álíka.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // ÖRYGGI: öryggissamningurinn fyrir `alloc` verður að vera staðfestur af þeim sem hringir.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // ÖRYGGI: þegar úthlutun tókst, svæðið frá `ptr`
            // af stærð `size` er tryggt að gildir fyrir skrif.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Minnkaðu eða stækkaðu minniskubb við gefinn `new_size`.
    /// Blokkinni er lýst með gefnum `ptr` bendli og `layout`.
    ///
    /// Ef þetta skilar bendli sem ekki er núll hefur eignarhald á minni blokk sem vísað er til af `ptr` verið flutt til þessa úthlutunaraðila.
    /// Minni gæti hafa verið úthlutað eða ekki og ætti að teljast ónothæft (nema auðvitað að það hafi verið flutt aftur til þess sem hringir í gegnum skilagildi þessarar aðferðar).
    /// Nýja minni blokkin er úthlutað með `layout`, en með `size` uppfærð í `new_size`.
    /// Þetta nýja skipulag ætti að nota þegar verið er að staðsetja nýja minnisblokkina við `dealloc`.
    /// Svæðið `0..min(layout.size(), new_size) `af nýja minnisblokknum er tryggt að hafa sömu gildi og upphaflega blokkin.
    ///
    /// Ef þessi aðferð skilar engu þá hefur eignarhald á minni blokkinni ekki verið flutt til þessa úthlutunaraðila og innihald minnisblokkarinnar er óbreytt.
    ///
    /// # Safety
    ///
    /// Þessi aðgerð er óörugg vegna þess að óskilgreind hegðun getur orðið til ef sá sem hringir tryggir ekki allt eftirfarandi:
    ///
    /// * `ptr` verður nú að úthluta í gegnum þennan úthlutara,
    ///
    /// * `layout` verður að vera sama skipulag og notað var til að úthluta minnisblokkinni,
    ///
    /// * `new_size` verður að vera stærra en núll.
    ///
    /// * `new_size`, þegar það er rúnað upp að næsta margfeldi `layout.align()`, má það ekki flæða yfir (þ.e. ávalið gildi verður að vera minna en `usize::MAX`).
    ///
    /// (Eftirnafn framlenginga gæti veitt sértækari mörk á hegðun, td tryggt netfang sent eða núllmerki sem svar við beiðni um úthlutun í núllstærð.)
    ///
    /// # Errors
    ///
    /// Skilar núlli ef nýja skipulagið uppfyllir ekki takmarkanir stærðar og jöfnunar úthlutunaraðilans, eða ef endurúthlutun mistekst að öðru leyti.
    ///
    /// Framkvæmdir eru hvattar til að skila núlli við minni örmögnun frekar en að örvænta eða hætta á, en þetta er ekki ströng krafa.
    /// (Nánar tiltekið: það er *löglegt* að innleiða þetta trait ofan á undirliggjandi innlent úthlutunarbókasafn sem eyðir við minnisleysi.)
    ///
    /// Viðskiptavinir sem vilja hætta við útreikning til að bregðast við endurúthlutunarvillu eru hvattir til að hringja í [`handle_alloc_error`] aðgerðina, frekar en að kalla beint til `panic!` eða álíka.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // ÖRYGGI: sá sem hringir þarf að sjá til þess að `new_size` flæði ekki yfir.
        // `layout.align()` kemur frá `Layout` og er þannig tryggt að það gildir.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // ÖRYGGI: sá sem hringir verður að tryggja að `new_layout` sé meiri en núll.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // ÖRYGGI: blokk sem áður var úthlutað getur ekki skarast við nýlega úthlutaða blokk.
            // Sá sem hringir þarf að standa við öryggissamninginn fyrir `dealloc`.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}