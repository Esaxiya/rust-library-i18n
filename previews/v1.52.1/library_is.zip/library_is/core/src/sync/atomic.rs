//! Atómgerðir
//!
//! Atómgerðir veita frumstæð samnýtt samskipti milli þráða og eru byggingarefni annarra samhliða tegunda.
//!
//! Þessi eining skilgreinir lotukerfisútgáfur af völdum fjölda frumstæðra gerða, þar á meðal [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`] osfrv.
//! Atómgerðir sýna aðgerðir sem, þegar þær eru notaðar á réttan hátt, samstilla uppfærslur milli þráða.
//!
//! Hver aðferð tekur [`Ordering`] sem táknar styrk minnishindrunar fyrir þá aðgerð.Þessar pantanir eru þær sömu og [C++20 atomic orderings][1].Nánari upplýsingar er að finna í [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Atómabreytum er óhætt að deila á milli þráða (þeir innleiða [`Sync`]) en þeir sjá sjálfir ekki fyrirkomulagið til að deila og fylgja [threading model](../../../std/thread/index.html#the-threading-model) af Rust.
//!
//! Algengasta leiðin til að deila lotukerfabreytu er að setja hana í [`Arc`][arc] (hluti sem bendir til atómískra tilvísana).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Atómgerðir geta verið geymdar í kyrrstæðum breytum, frumstilltar með því að nota stöðuga frumstilla eins og [`AtomicBool::new`].Atómstatík er oft notuð við latan frumstilling á heimsvísu.
//!
//! # Portability
//!
//! Örugglega eru allar lotukerfategundir í þessari einingu [lock-free] ef þær eru fáanlegar.Þetta þýðir að þeir eignast ekki alþjóðlegt mutex.Atómgerðir og aðgerðir eru ekki tryggðar að séu biðlausar.
//! Þetta þýðir að aðgerðir eins og `fetch_or` geta verið útfærðar með samanburðar-og-skipti lykkju.
//!
//! Atómaðgerðir geta verið framkvæmdar við leiðbeiningarlagið með stærri atómum.Til dæmis nota sumir pallar 4 bæti lotukerfaleiðbeiningar til að innleiða `AtomicI8`.
//! Athugaðu að þessi eftirlíking ætti ekki að hafa áhrif á réttleika kóða, það er bara eitthvað sem þú verður að vera meðvitaður um.
//!
//! Atómgerðirnar í þessari einingu eru hugsanlega ekki til á öllum pöllum.Atómgerðirnar hér eru allar víða fáanlegar, en almennt er hægt að treysta á þær.Nokkrar athyglisverðar undantekningar eru:
//!
//! * PowerPC og MIPS pallur með 32 bita ábendingum eru ekki með `AtomicU64` eða `AtomicI64` gerðir.
//! * ARM pallar eins og `armv5te` sem ekki eru fyrir Linux veita aðeins `load` og `store` aðgerðir og styðja ekki bera saman og skipta um (CAS) aðgerðir, svo sem `swap`, `fetch_add` osfrv.
//! Að auki á Linux eru þessar CAS aðgerðir útfærðar í gegnum [operating system support], sem getur fylgt frammistöðu.
//! * ARM skotmörk með `thumbv6m` veita aðeins `load` og `store` aðgerðir og styðja ekki bera saman og skipta um (CAS) aðgerðir, svo sem `swap`, `fetch_add` o.s.frv.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Athugið að bæta má við future pöllum sem hafa heldur ekki stuðning við sumar lotukerfisaðgerðir.Hámarks færanlegur kóði mun vilja fara varlega í hvaða lotukerfategundir eru notaðar.
//! `AtomicUsize` og `AtomicIsize` eru yfirleitt færanlegust en jafnvel þá eru þau ekki fáanleg alls staðar.
//! Til viðmiðunar þarf `std` bókasafnið atómstærð með bendilstærð, þó að `core` geri það ekki.
//!
//! Eins og er þarftu fyrst og fremst að nota `#[cfg(target_arch)]` til að setja saman skilmála í kóða með lotukerfinu.Það er líka óstöðugur `#[cfg(target_has_atomic)]` sem getur verið stöðugur í future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Einfaldur snúllás:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Bíddu eftir að hinn þráðurinn losi lásinn
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Haltu alþjóðlegum fjölda lifandi þráða:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Boolean gerð sem hægt er að deila á öruggan hátt milli þráða.
///
/// Þessi tegund hefur sömu framsetningu í minni og [`bool`].
///
/// **Athugasemd**: Þessi tegund er aðeins fáanleg á vettvangi sem styðja lotukerfi og geymslu `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Býr til `AtomicBool` frumstilltan í `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Send er óbeint útfært fyrir AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Hrá benditegund sem hægt er að deila á öruggan hátt milli þráða.
///
/// Þessi tegund hefur sömu framsetningu í minni og `*mut T`.
///
/// **Athugasemd**: Þessi tegund er aðeins fáanleg á pöllum sem styðja lotukerfi og geymslu ábendinga.
/// Stærð þess er háð stærð bendilsins.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Býr til null `AtomicPtr<T>`.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Atómísk minnispöntun
///
/// Minni röðun tilgreinir hvernig lotukerfisaðgerðir samstilla minni.
/// Í veikasta [`Ordering::Relaxed`] er aðeins minni sem aðgerðin snertir samstillt.
/// Á hinn bóginn samstillir geymsluhleðslupar [`Ordering::SeqCst`] aðgerða annað minni en að auki varðveitir heildar röð slíkra aðgerða yfir alla þræði.
///
///
/// Minnispantanir Rust eru [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// Nánari upplýsingar er að finna í [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Engar takmarkanir á röðun, aðeins atómaðgerðir.
    ///
    /// Samsvarar [`memory_order_relaxed`] í C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Þegar það er sett saman við verslun er öllum fyrri aðgerðum pantað áður en það er hlaðið af þessu gildi með [`Acquire`] (eða sterkari) pöntun.
    ///
    /// Sérstaklega verða öll fyrri skrif skrifuð sýnileg öllum þráðum sem framkvæma [`Acquire`] (eða sterkari) álag af þessu gildi.
    ///
    /// Takið eftir að notkun þessarar röðunar fyrir aðgerð sem sameinar álag og geymir leiðir til [`Relaxed`] álagsaðgerðar!
    ///
    /// Þessi pöntun á aðeins við um aðgerðir sem geta framkvæmt verslun.
    ///
    /// Samsvarar [`memory_order_release`] í C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Þegar það er ásamt álagi, ef hlaðið gildi var skrifað með verslun með [`Release`] (eða sterkari) pöntun, þá verða allar aðgerðir síðan pantaðar eftir þá verslun.
    /// Sérstaklega munu öll síðari álag sjá gögn skrifuð fyrir verslunina.
    ///
    /// Takið eftir því að nota þessa pöntun fyrir aðgerð sem sameinar álag og geymslu leiðir til [`Relaxed`] verslunaraðgerða!
    ///
    /// Þessi pöntun á aðeins við um aðgerðir sem geta framkvæmt álag.
    ///
    /// Samsvarar [`memory_order_acquire`] í C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Hefur áhrif bæði [`Acquire`] og [`Release`] saman:
    /// Fyrir hleðslur notar það [`Acquire`] pöntun.Fyrir verslanir notar það [`Release`] pöntunina.
    ///
    /// Takið eftir að þegar um `compare_and_swap` er að ræða er mögulegt að aðgerðin endi ekki í neinni verslun og þess vegna hafi hún bara [`Acquire`] pöntun.
    ///
    /// Samt sem áður mun `AcqRel` aldrei framkvæma [`Relaxed`] aðgang.
    ///
    /// Þessi pöntun á aðeins við um aðgerðir sem sameina bæði farm og verslanir.
    ///
    /// Samsvarar [`memory_order_acq_rel`] í C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Eins og [`Acquire`]/[`Release`]/[`AcqRel`](fyrir aðgerðir sem hlaða, geyma og hlaða með verslun), með viðbótarábyrgð að allir þræðir sjá allar röð í samræmi í sömu röð .
    ///
    ///
    /// Samsvarar [`memory_order_seq_cst`] í C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// [`AtomicBool`] frumstýrður í `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Býr til nýjan `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Skilar breytilegri tilvísun í undirliggjandi [`bool`].
    ///
    /// Þetta er öruggt vegna þess að hin breytanlega tilvísun tryggir að engir aðrir þræðir fái samtímis aðgang að atómgögnum.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // ÖRYGGI: breytileg viðmiðunin tryggir einstakt eignarhald.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Fáðu atómaðgang að `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // ÖRYGGI: breytileg tilvísun tryggir einstakt eignarhald, og
        // röðun bæði `bool` og `Self` er 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Eyðir atóminu og skilar innihaldsgildinu.
    ///
    /// Þetta er öruggt vegna þess að `self` er gefið eftir gildi tryggir að engir aðrir þræðir fái samtímis aðgang að atómgögnum.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Hleður gildi úr bool.
    ///
    /// `load` tekur [`Ordering`] rök sem lýsa minni röðun á þessari aðgerð.
    /// Möguleg gildi eru [`SeqCst`], [`Acquire`] og [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics ef `order` er [`Release`] eða [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // ÖRYGGI: hvers kyns kynþáttum er komið í veg fyrir í lotukerfinu og hráefni
        // bendill sem sendur er gildur vegna þess að við fengum hann frá tilvísun.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Geymir gildi í bool.
    ///
    /// `store` tekur [`Ordering`] rök sem lýsa minni röðun á þessari aðgerð.
    /// Möguleg gildi eru [`SeqCst`], [`Release`] og [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics ef `order` er [`Acquire`] eða [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // ÖRYGGI: hvers kyns kynþáttum er komið í veg fyrir í lotukerfinu og hráefni
        // bendill sem sendur er gildur vegna þess að við fengum hann frá tilvísun.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Geymir gildi í bool og skilar fyrra gildi.
    ///
    /// `swap` tekur [`Ordering`] rök sem lýsa minni röðun á þessari aðgerð.Allir pöntunarhættir eru mögulegir.
    /// Athugaðu að notkun [`Acquire`] gerir verslunina að hluta af þessari aðgerð [`Relaxed`] og notkun [`Release`] gerir álagshlutann [`Relaxed`].
    ///
    ///
    /// **Note:** Þessi aðferð er aðeins fáanleg á kerfum sem styðja lotukerfisaðgerðir á `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // ÖRYGGI: gagna kynþáttum er komið í veg fyrir í lotukerfinu.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Geymir gildi í [`bool`] ef núverandi gildi er það sama og `current` gildi.
    ///
    /// Skilagildið er alltaf fyrra gildi.Ef það er jafnt og `current`, þá var gildi uppfært.
    ///
    /// `compare_and_swap` tekur einnig [`Ordering`] rök sem lýsa minni röðun á þessari aðgerð.
    /// Takið eftir að jafnvel þegar [`AcqRel`] er notað gæti aðgerðin mistekist og þess vegna bara framkvæmt `Acquire` álag, en ekki haft `Release` merkingarfræði.
    /// Notkun [`Acquire`] gerir verslunina að hluta af þessari aðgerð [`Relaxed`] ef hún gerist og notkun [`Release`] gerir álagshlutann [`Relaxed`].
    ///
    /// **Note:** Þessi aðferð er aðeins fáanleg á kerfum sem styðja lotukerfisaðgerðir á `u8`.
    ///
    /// # Farið í `compare_exchange` og `compare_exchange_weak`
    ///
    /// `compare_and_swap` jafngildir `compare_exchange` með eftirfarandi kortlagningu fyrir minnispöntun:
    ///
    /// Frumlegt |Árangur |Bilun
    /// -------- | ------- | -------
    /// Afslappaður |Afslappaður |Slakað afla |Afla |Afla losunar |Slepptu |Afslappaður AcqRel |AcqRel |Afla SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` er leyft að mistakast ranglega jafnvel þegar samanburðurinn tekst, sem gerir þýðandanum kleift að búa til betri samsetningarkóða þegar samanburðurinn og skiptin er notuð í lykkju.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Geymir gildi í [`bool`] ef núverandi gildi er það sama og `current` gildi.
    ///
    /// Skilagildið er niðurstaða sem gefur til kynna hvort nýja gildið var skrifað og innihélt fyrra gildi.
    /// Þegar vel tekst til er þetta gildi tryggt að það sé jafnt og `current`.
    ///
    /// `compare_exchange` tekur tvö [`Ordering`] rök til að lýsa minni röðun á þessari aðgerð.
    /// `success` lýsir nauðsynlegri röðun fyrir lestrar-breyta-skrifaðgerðina sem á sér stað ef samanburður við `current` tekst.
    /// `failure` lýsir nauðsynlegri röðun fyrir álagsaðgerðina sem á sér stað þegar samanburðurinn misheppnast.
    /// Með því að nota [`Acquire`] sem pöntun á velgengni er verslunin hluti af þessari aðgerð [`Relaxed`] og notkun [`Release`] gerir farsæla álagið [`Relaxed`].
    ///
    /// Bilanapöntunin getur aðeins verið [`SeqCst`], [`Acquire`] eða [`Relaxed`] og verður að vera jafngild eða veikari en pöntunin á velgengni.
    ///
    /// **Note:** Þessi aðferð er aðeins fáanleg á kerfum sem styðja lotukerfisaðgerðir á `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // ÖRYGGI: gagna kynþáttum er komið í veg fyrir í lotukerfinu.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Geymir gildi í [`bool`] ef núverandi gildi er það sama og `current` gildi.
    ///
    /// Ólíkt [`AtomicBool::compare_exchange`] er þessari aðgerð leyft að mistakast ranglega jafnvel þegar samanburðurinn tekst, sem getur skilað skilvirkari kóða á sumum kerfum.
    ///
    /// Skilagildið er niðurstaða sem gefur til kynna hvort nýja gildið var skrifað og innihélt fyrra gildi.
    ///
    /// `compare_exchange_weak` tekur tvö [`Ordering`] rök til að lýsa minni röðun á þessari aðgerð.
    /// `success` lýsir nauðsynlegri röðun fyrir lestrar-breyta-skrifaðgerðina sem á sér stað ef samanburður við `current` tekst.
    /// `failure` lýsir nauðsynlegri röðun fyrir álagsaðgerðina sem á sér stað þegar samanburðurinn misheppnast.
    /// Með því að nota [`Acquire`] sem pöntun á velgengni er verslunin hluti af þessari aðgerð [`Relaxed`] og notkun [`Release`] gerir farsæla álagið [`Relaxed`].
    /// Bilanapöntunin getur aðeins verið [`SeqCst`], [`Acquire`] eða [`Relaxed`] og verður að vera jafngild eða veikari en pöntunin á velgengni.
    ///
    /// **Note:** Þessi aðferð er aðeins fáanleg á kerfum sem styðja lotukerfisaðgerðir á `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // ÖRYGGI: gagna kynþáttum er komið í veg fyrir í lotukerfinu.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Rökrétt "and" með boolískt gildi.
    ///
    /// Framkvæmir rökrétt "and" aðgerð á núverandi gildi og rökum `val` og stillir nýja gildið á niðurstöðuna.
    ///
    /// Skilar fyrra gildi.
    ///
    /// `fetch_and` tekur [`Ordering`] rök sem lýsa minni röðun á þessari aðgerð.Allir pöntunarhættir eru mögulegir.
    /// Athugaðu að notkun [`Acquire`] gerir verslunina að hluta af þessari aðgerð [`Relaxed`] og notkun [`Release`] gerir álagshlutann [`Relaxed`].
    ///
    ///
    /// **Note:** Þessi aðferð er aðeins fáanleg á kerfum sem styðja lotukerfisaðgerðir á `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // ÖRYGGI: gagna kynþáttum er komið í veg fyrir í lotukerfinu.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Rökrétt "nand" með boolískt gildi.
    ///
    /// Framkvæmir rökrétt "nand" aðgerð á núverandi gildi og rökum `val` og stillir nýja gildið á niðurstöðuna.
    ///
    /// Skilar fyrra gildi.
    ///
    /// `fetch_nand` tekur [`Ordering`] rök sem lýsa minni röðun á þessari aðgerð.Allir pöntunarhættir eru mögulegir.
    /// Athugaðu að notkun [`Acquire`] gerir verslunina að hluta af þessari aðgerð [`Relaxed`] og notkun [`Release`] gerir álagshlutann [`Relaxed`].
    ///
    ///
    /// **Note:** Þessi aðferð er aðeins fáanleg á kerfum sem styðja lotukerfisaðgerðir á `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Við getum ekki notað atomic_nand hér vegna þess að það getur leitt til bool með ógilt gildi.
        // Þetta gerist vegna þess að atómaðgerð er gerð með 8 bita heiltölu að innan, sem myndi stilla efri 7 bitana.
        //
        // Þannig að við notum bara fetch_xor eða skiptum í staðinn.
        if val {
            // ! (x&true)== !x Við verðum að snúa bool við.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==satt Við verðum að stilla bool á satt.
            //
            self.swap(true, order)
        }
    }

    /// Rökrétt "or" með boolískt gildi.
    ///
    /// Framkvæmir rökrétt "or" aðgerð á núverandi gildi og rökum `val` og stillir nýja gildið á niðurstöðuna.
    ///
    /// Skilar fyrra gildi.
    ///
    /// `fetch_or` tekur [`Ordering`] rök sem lýsa minni röðun á þessari aðgerð.Allir pöntunarhættir eru mögulegir.
    /// Athugaðu að notkun [`Acquire`] gerir verslunina að hluta af þessari aðgerð [`Relaxed`] og notkun [`Release`] gerir álagshlutann [`Relaxed`].
    ///
    ///
    /// **Note:** Þessi aðferð er aðeins fáanleg á kerfum sem styðja lotukerfisaðgerðir á `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // ÖRYGGI: gagna kynþáttum er komið í veg fyrir í lotukerfinu.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Rökrétt "xor" með boolískt gildi.
    ///
    /// Framkvæmir rökrétt "xor" aðgerð á núverandi gildi og rökum `val` og stillir nýja gildið á niðurstöðuna.
    ///
    /// Skilar fyrra gildi.
    ///
    /// `fetch_xor` tekur [`Ordering`] rök sem lýsa minni röðun á þessari aðgerð.Allir pöntunarhættir eru mögulegir.
    /// Athugaðu að notkun [`Acquire`] gerir verslunina að hluta af þessari aðgerð [`Relaxed`] og notkun [`Release`] gerir álagshlutann [`Relaxed`].
    ///
    ///
    /// **Note:** Þessi aðferð er aðeins fáanleg á kerfum sem styðja lotukerfisaðgerðir á `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // ÖRYGGI: gagna kynþáttum er komið í veg fyrir í lotukerfinu.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Skilar breytilegum bendli á undirliggjandi [`bool`].
    ///
    /// Að stunda lestur og atóm sem ekki er lotukerfinu á heiltölunni sem myndast getur verið gagnakapphlaup.
    /// Þessi aðferð er aðallega gagnleg fyrir FFI, þar sem aðgerð undirskrift getur notað `*mut bool` í stað `&AtomicBool`.
    ///
    /// Að skila `*mut` bendli úr sameiginlegri tilvísun í þetta atóm er öruggt vegna þess að atómgerðirnar vinna með innri breytileika.
    /// Allar breytingar á lotukerfinu breyta gildinu með sameiginlegri tilvísun og geta gert það á öruggan hátt svo framarlega sem þeir nota atómaðgerðir.
    /// Sérhver notkun á hráum bendlinum sem skilað er krefst `unsafe` kubb og þarf enn að viðhalda sömu takmörkun: aðgerðir á honum verða að vera lotukerfinu.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Sækir gildið og beitir aðgerð á það sem skilar valfrjálsu nýju gildi.Skilar `Result` af `Ok(previous_value)` ef aðgerðin skilaði `Some(_)`, annars `Err(previous_value)`.
    ///
    /// Note: Þetta getur kallað á aðgerðina mörgum sinnum ef gildinu hefur verið breytt frá öðrum þráðum í millitíðinni, svo framarlega sem aðgerðin skilar `Some(_)`, en aðgerðinni hefur aðeins verið beitt einu sinni á vistaða gildið.
    ///
    ///
    /// `fetch_update` tekur tvö [`Ordering`] rök til að lýsa minni röðun á þessari aðgerð.
    /// Sú fyrri lýsir nauðsynlegri pöntun fyrir þegar aðgerð tekst að lokum en sú síðari lýsir nauðsynlegri pöntun fyrir álag.
    /// Þetta samsvarar velgengni og misheppnaðri röðun [`AtomicBool::compare_exchange`].
    ///
    /// Með því að nota [`Acquire`] sem pöntun á velgengni er verslunin hluti af þessari aðgerð [`Relaxed`] og notkun [`Release`] gerir endanlegt farsælt álag [`Relaxed`].
    /// (failed) álagsröðunin getur aðeins verið [`SeqCst`], [`Acquire`] eða [`Relaxed`] og verður að vera jafngild eða veikari en árangursröðunin.
    ///
    /// **Note:** Þessi aðferð er aðeins fáanleg á kerfum sem styðja lotukerfisaðgerðir á `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Býr til nýjan `AtomicPtr`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Skilar breytilegri tilvísun í undirliggjandi bendi.
    ///
    /// Þetta er öruggt vegna þess að hin breytanlega tilvísun tryggir að engir aðrir þræðir fái samtímis aðgang að atómgögnum.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Fáðu atómaðgang að bendli.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - breytanlega tilvísunin tryggir einstakt eignarhald.
        //  - röðun `*mut T` og `Self` er sú sama á öllum pöllum sem eru studd af rust, eins og staðfest hefur verið hér að ofan.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Eyðir atóminu og skilar innihaldsgildinu.
    ///
    /// Þetta er öruggt vegna þess að `self` er gefið eftir gildi tryggir að engir aðrir þræðir fái samtímis aðgang að atómgögnum.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Hleður gildi frá bendlinum.
    ///
    /// `load` tekur [`Ordering`] rök sem lýsa minni röðun á þessari aðgerð.
    /// Möguleg gildi eru [`SeqCst`], [`Acquire`] og [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics ef `order` er [`Release`] eða [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // ÖRYGGI: gagna kynþáttum er komið í veg fyrir í lotukerfinu.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Geymir gildi í bendilinn.
    ///
    /// `store` tekur [`Ordering`] rök sem lýsa minni röðun á þessari aðgerð.
    /// Möguleg gildi eru [`SeqCst`], [`Release`] og [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics ef `order` er [`Acquire`] eða [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // ÖRYGGI: gagna kynþáttum er komið í veg fyrir í lotukerfinu.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Geymir gildi í bendi og skilar fyrra gildi.
    ///
    /// `swap` tekur [`Ordering`] rök sem lýsa minni röðun á þessari aðgerð.Allir pöntunarhættir eru mögulegir.
    /// Athugaðu að notkun [`Acquire`] gerir verslunina að hluta af þessari aðgerð [`Relaxed`] og notkun [`Release`] gerir álagshlutann [`Relaxed`].
    ///
    ///
    /// **Note:** Þessi aðferð er aðeins fáanleg á vettvangi sem styðja atómaðgerðir á ábendingum.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // ÖRYGGI: gagna kynþáttum er komið í veg fyrir í lotukerfinu.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Geymir gildi í bendi ef núverandi gildi er það sama og `current` gildi.
    ///
    /// Skilagildið er alltaf fyrra gildi.Ef það er jafnt og `current`, þá var gildi uppfært.
    ///
    /// `compare_and_swap` tekur einnig [`Ordering`] rök sem lýsa minni röðun á þessari aðgerð.
    /// Takið eftir að jafnvel þegar [`AcqRel`] er notað gæti aðgerðin mistekist og þess vegna bara framkvæmt `Acquire` álag, en ekki haft `Release` merkingarfræði.
    /// Notkun [`Acquire`] gerir verslunina að hluta af þessari aðgerð [`Relaxed`] ef hún gerist og notkun [`Release`] gerir álagshlutann [`Relaxed`].
    ///
    /// **Note:** Þessi aðferð er aðeins fáanleg á vettvangi sem styðja atómaðgerðir á ábendingum.
    ///
    /// # Farið í `compare_exchange` og `compare_exchange_weak`
    ///
    /// `compare_and_swap` jafngildir `compare_exchange` með eftirfarandi kortlagningu fyrir minnispöntun:
    ///
    /// Frumlegt |Árangur |Bilun
    /// -------- | ------- | -------
    /// Afslappaður |Afslappaður |Slakað afla |Afla |Afla losunar |Slepptu |Afslappaður AcqRel |AcqRel |Afla SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` er leyft að mistakast ranglega jafnvel þegar samanburðurinn tekst, sem gerir þýðandanum kleift að búa til betri samsetningarkóða þegar samanburðurinn og skiptin er notuð í lykkju.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Geymir gildi í bendi ef núverandi gildi er það sama og `current` gildi.
    ///
    /// Skilagildið er niðurstaða sem gefur til kynna hvort nýja gildið var skrifað og innihélt fyrra gildi.
    /// Þegar vel tekst til er þetta gildi tryggt að það sé jafnt og `current`.
    ///
    /// `compare_exchange` tekur tvö [`Ordering`] rök til að lýsa minni röðun á þessari aðgerð.
    /// `success` lýsir nauðsynlegri röðun fyrir lestrar-breyta-skrifaðgerðina sem á sér stað ef samanburður við `current` tekst.
    /// `failure` lýsir nauðsynlegri röðun fyrir álagsaðgerðina sem á sér stað þegar samanburðurinn misheppnast.
    /// Með því að nota [`Acquire`] sem pöntun á velgengni er verslunin hluti af þessari aðgerð [`Relaxed`] og notkun [`Release`] gerir farsæla álagið [`Relaxed`].
    ///
    /// Bilanapöntunin getur aðeins verið [`SeqCst`], [`Acquire`] eða [`Relaxed`] og verður að vera jafngild eða veikari en pöntunin á velgengni.
    ///
    /// **Note:** Þessi aðferð er aðeins fáanleg á vettvangi sem styðja atómaðgerðir á ábendingum.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // ÖRYGGI: gagna kynþáttum er komið í veg fyrir í lotukerfinu.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Geymir gildi í bendi ef núverandi gildi er það sama og `current` gildi.
    ///
    /// Ólíkt [`AtomicPtr::compare_exchange`] er þessari aðgerð leyft að mistakast, jafnvel þegar samanburðurinn tekst, sem getur skilað skilvirkari kóða á sumum kerfum.
    ///
    /// Skilagildið er niðurstaða sem gefur til kynna hvort nýja gildið var skrifað og innihélt fyrra gildi.
    ///
    /// `compare_exchange_weak` tekur tvö [`Ordering`] rök til að lýsa minni röðun á þessari aðgerð.
    /// `success` lýsir nauðsynlegri röðun fyrir lestrar-breyta-skrifaðgerðina sem á sér stað ef samanburður við `current` tekst.
    /// `failure` lýsir nauðsynlegri röðun fyrir álagsaðgerðina sem á sér stað þegar samanburðurinn misheppnast.
    /// Með því að nota [`Acquire`] sem pöntun á velgengni er verslunin hluti af þessari aðgerð [`Relaxed`] og notkun [`Release`] gerir farsæla álagið [`Relaxed`].
    /// Bilanapöntunin getur aðeins verið [`SeqCst`], [`Acquire`] eða [`Relaxed`] og verður að vera jafngild eða veikari en pöntunin á velgengni.
    ///
    /// **Note:** Þessi aðferð er aðeins fáanleg á vettvangi sem styðja atómaðgerðir á ábendingum.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // ÖRYGGI: Þetta innra er óöruggt vegna þess að það virkar á hráum bendli
        // en við vitum fyrir víst að bendillinn er gildur (við fengum hann bara frá `UnsafeCell` sem við höfum með tilvísun) og atómaðgerðin sjálf gerir okkur kleift að stökkbreyta `UnsafeCell` innihaldinu.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Sækir gildið og beitir aðgerð á það sem skilar valfrjálsu nýju gildi.Skilar `Result` af `Ok(previous_value)` ef aðgerðin skilaði `Some(_)`, annars `Err(previous_value)`.
    ///
    /// Note: Þetta getur kallað á aðgerðina mörgum sinnum ef gildinu hefur verið breytt frá öðrum þráðum í millitíðinni, svo framarlega sem aðgerðin skilar `Some(_)`, en aðgerðinni hefur aðeins verið beitt einu sinni á vistaða gildið.
    ///
    ///
    /// `fetch_update` tekur tvö [`Ordering`] rök til að lýsa minni röðun á þessari aðgerð.
    /// Sú fyrri lýsir nauðsynlegri pöntun fyrir þegar aðgerð tekst að lokum en sú síðari lýsir nauðsynlegri pöntun fyrir álag.
    /// Þetta samsvarar velgengni og misheppnaðri röðun [`AtomicPtr::compare_exchange`] í sömu röð.
    ///
    /// Með því að nota [`Acquire`] sem pöntun á velgengni er verslunin hluti af þessari aðgerð [`Relaxed`] og notkun [`Release`] gerir endanlegt farsælt álag [`Relaxed`].
    /// (failed) álagsröðunin getur aðeins verið [`SeqCst`], [`Acquire`] eða [`Relaxed`] og verður að vera jafngild eða veikari en árangursröðunin.
    ///
    /// **Note:** Þessi aðferð er aðeins fáanleg á vettvangi sem styðja atómaðgerðir á ábendingum.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Breytir `bool` í `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Þessi fjölvi endar með því að vera ónotaður í sumum arkitektúrum.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Heildargerð sem hægt er að deila á öruggan hátt milli þráða.
        ///
        /// Þessi tegund hefur sömu framsetningu í minni og undirliggjandi heiltölu gerð, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// Nánari upplýsingar um muninn á atómgerðum og tegundum sem ekki eru atómum og upplýsingar um færanleika þessarar tegundar er að finna í [module-level documentation].
        ///
        ///
        /// **Note:** Þessi tegund er aðeins fáanleg á vettvangi sem styðja lotukerfi og geymslur [[
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Heildartala atóms upphafin í `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Sending er óbein útfærð.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Býr til nýja lotuheildartölu.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Skilar breyttri tilvísun í undirliggjandi heiltölu.
            ///
            /// Þetta er öruggt vegna þess að hin breytanlega tilvísun tryggir að engir aðrir þræðir fái samtímis aðgang að atómgögnum.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// láttu mut sum_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// fullyrðing_eq! (sum_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - breytanlega tilvísunin tryggir einstakt eignarhald.
                //  - röðun `$int_type` og `Self` er sú sama, eins og lofað var af $cfg_align og staðfest hér að ofan.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Eyðir atóminu og skilar innihaldsgildinu.
            ///
            /// Þetta er öruggt vegna þess að `self` er gefið eftir gildi tryggir að engir aðrir þræðir fái samtímis aðgang að atómgögnum.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Hleður gildi frá atómheildinni.
            ///
            /// `load` tekur [`Ordering`] rök sem lýsa minni röðun á þessari aðgerð.
            /// Möguleg gildi eru [`SeqCst`], [`Acquire`] og [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics ef `order` er [`Release`] eða [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // ÖRYGGI: gagna kynþáttum er komið í veg fyrir í lotukerfinu.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Geymir gildi í atómheildinni.
            ///
            /// `store` tekur [`Ordering`] rök sem lýsa minni röðun á þessari aðgerð.
            ///  Möguleg gildi eru [`SeqCst`], [`Release`] og [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics ef `order` er [`Acquire`] eða [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // ÖRYGGI: gagna kynþáttum er komið í veg fyrir í lotukerfinu.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Geymir gildi í atómheildinni og skilar fyrra gildi.
            ///
            /// `swap` tekur [`Ordering`] rök sem lýsa minni röðun á þessari aðgerð.Allir pöntunarhættir eru mögulegir.
            /// Athugaðu að notkun [`Acquire`] gerir verslunina að hluta af þessari aðgerð [`Relaxed`] og notkun [`Release`] gerir álagshlutann [`Relaxed`].
            ///
            ///
            /// **Athugasemd**: Þessi aðferð er aðeins fáanleg á kerfum sem styðja lotukerfisaðgerðir á
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // ÖRYGGI: gagna kynþáttum er komið í veg fyrir í lotukerfinu.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Geymir gildi í lotuheildinni ef núverandi gildi er það sama og `current` gildi.
            ///
            /// Skilagildið er alltaf fyrra gildi.Ef það er jafnt og `current`, þá var gildi uppfært.
            ///
            /// `compare_and_swap` tekur einnig [`Ordering`] rök sem lýsa minni röðun á þessari aðgerð.
            /// Takið eftir að jafnvel þegar [`AcqRel`] er notað gæti aðgerðin mistekist og þess vegna bara framkvæmt `Acquire` álag, en ekki haft `Release` merkingarfræði.
            ///
            /// Notkun [`Acquire`] gerir verslunina að hluta af þessari aðgerð [`Relaxed`] ef hún gerist og notkun [`Release`] gerir álagshlutann [`Relaxed`].
            ///
            /// **Athugasemd**: Þessi aðferð er aðeins fáanleg á kerfum sem styðja lotukerfisaðgerðir á
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Farið í `compare_exchange` og `compare_exchange_weak`
            ///
            /// `compare_and_swap` jafngildir `compare_exchange` með eftirfarandi kortlagningu fyrir minnispöntun:
            ///
            /// Frumlegt |Árangur |Bilun
            /// -------- | ------- | -------
            /// Afslappaður |Afslappaður |Slakað afla |Afla |Afla losunar |Slepptu |Afslappaður AcqRel |AcqRel |Afla SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` er leyft að mistakast ranglega jafnvel þegar samanburðurinn tekst, sem gerir þýðandanum kleift að búa til betri samsetningarkóða þegar samanburðurinn og skiptin er notuð í lykkju.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Geymir gildi í lotuheildinni ef núverandi gildi er það sama og `current` gildi.
            ///
            /// Skilagildið er niðurstaða sem gefur til kynna hvort nýja gildið var skrifað og innihélt fyrra gildi.
            /// Þegar vel tekst til er þetta gildi tryggt að það sé jafnt og `current`.
            ///
            /// `compare_exchange` tekur tvö [`Ordering`] rök til að lýsa minni röðun á þessari aðgerð.
            /// `success` lýsir nauðsynlegri röðun fyrir lestrar-breyta-skrifaðgerðina sem á sér stað ef samanburður við `current` tekst.
            /// `failure` lýsir nauðsynlegri röðun fyrir álagsaðgerðina sem á sér stað þegar samanburðurinn misheppnast.
            /// Með því að nota [`Acquire`] sem pöntun á velgengni er verslunin hluti af þessari aðgerð [`Relaxed`] og notkun [`Release`] gerir farsæla álagið [`Relaxed`].
            ///
            /// Bilanapöntunin getur aðeins verið [`SeqCst`], [`Acquire`] eða [`Relaxed`] og verður að vera jafngild eða veikari en pöntunin á velgengni.
            ///
            /// **Athugasemd**: Þessi aðferð er aðeins fáanleg á kerfum sem styðja lotukerfisaðgerðir á
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // ÖRYGGI: gagna kynþáttum er komið í veg fyrir í lotukerfinu.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Geymir gildi í lotuheildinni ef núverandi gildi er það sama og `current` gildi.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// þessari aðgerð er leyft að mistakast, jafnvel þegar samanburðurinn tekst, sem getur skilað skilvirkari kóða á sumum kerfum.
            /// Skilagildið er niðurstaða sem gefur til kynna hvort nýja gildið var skrifað og innihélt fyrra gildi.
            ///
            /// `compare_exchange_weak` tekur tvö [`Ordering`] rök til að lýsa minni röðun á þessari aðgerð.
            /// `success` lýsir nauðsynlegri röðun fyrir lestrar-breyta-skrifaðgerðina sem á sér stað ef samanburður við `current` tekst.
            /// `failure` lýsir nauðsynlegri röðun fyrir álagsaðgerðina sem á sér stað þegar samanburðurinn misheppnast.
            /// Með því að nota [`Acquire`] sem pöntun á velgengni er verslunin hluti af þessari aðgerð [`Relaxed`] og notkun [`Release`] gerir farsæla álagið [`Relaxed`].
            ///
            /// Bilanapöntunin getur aðeins verið [`SeqCst`], [`Acquire`] eða [`Relaxed`] og verður að vera jafngild eða veikari en pöntunin á velgengni.
            ///
            /// **Athugasemd**: Þessi aðferð er aðeins fáanleg á kerfum sem styðja lotukerfisaðgerðir á
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// láta mut gamla= val.load(Ordering::Relaxed);
            /// lykkja {let new=old * 2;
            ///     passa val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // ÖRYGGI: gagna kynþáttum er komið í veg fyrir í lotukerfinu.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Bætir við núverandi gildi og skilar fyrra gildi.
            ///
            /// Þessi aðgerð vafist um á flæði.
            ///
            /// `fetch_add` tekur [`Ordering`] rök sem lýsa minni röðun á þessari aðgerð.Allir pöntunarhættir eru mögulegir.
            /// Athugaðu að notkun [`Acquire`] gerir verslunina að hluta af þessari aðgerð [`Relaxed`] og notkun [`Release`] gerir álagshlutann [`Relaxed`].
            ///
            ///
            /// **Athugasemd**: Þessi aðferð er aðeins fáanleg á kerfum sem styðja lotukerfisaðgerðir á
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // ÖRYGGI: gagna kynþáttum er komið í veg fyrir í lotukerfinu.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Dregur frá núverandi gildi og skilar fyrra gildi.
            ///
            /// Þessi aðgerð vafist um á flæði.
            ///
            /// `fetch_sub` tekur [`Ordering`] rök sem lýsa minni röðun á þessari aðgerð.Allir pöntunarhættir eru mögulegir.
            /// Athugaðu að notkun [`Acquire`] gerir verslunina að hluta af þessari aðgerð [`Relaxed`] og notkun [`Release`] gerir álagshlutann [`Relaxed`].
            ///
            ///
            /// **Athugasemd**: Þessi aðferð er aðeins fáanleg á kerfum sem styðja lotukerfisaðgerðir á
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // ÖRYGGI: gagna kynþáttum er komið í veg fyrir í lotukerfinu.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitvis "and" með núverandi gildi.
            ///
            /// Framkvæmir bitvisa "and" aðgerð á núverandi gildi og rökunum `val` og stillir nýja gildið á niðurstöðuna.
            ///
            /// Skilar fyrra gildi.
            ///
            /// `fetch_and` tekur [`Ordering`] rök sem lýsa minni röðun á þessari aðgerð.Allir pöntunarhættir eru mögulegir.
            /// Athugaðu að notkun [`Acquire`] gerir verslunina að hluta af þessari aðgerð [`Relaxed`] og notkun [`Release`] gerir álagshlutann [`Relaxed`].
            ///
            ///
            /// **Athugasemd**: Þessi aðferð er aðeins fáanleg á kerfum sem styðja lotukerfisaðgerðir á
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // ÖRYGGI: gagna kynþáttum er komið í veg fyrir í lotukerfinu.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitvis "nand" með núverandi gildi.
            ///
            /// Framkvæmir bitvisa "nand" aðgerð á núverandi gildi og rökunum `val` og stillir nýja gildið á niðurstöðuna.
            ///
            /// Skilar fyrra gildi.
            ///
            /// `fetch_nand` tekur [`Ordering`] rök sem lýsa minni röðun á þessari aðgerð.Allir pöntunarhættir eru mögulegir.
            /// Athugaðu að notkun [`Acquire`] gerir verslunina að hluta af þessari aðgerð [`Relaxed`] og notkun [`Release`] gerir álagshlutann [`Relaxed`].
            ///
            ///
            /// **Athugasemd**: Þessi aðferð er aðeins fáanleg á kerfum sem styðja lotukerfisaðgerðir á
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // ÖRYGGI: gagna kynþáttum er komið í veg fyrir í lotukerfinu.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitvis "or" með núverandi gildi.
            ///
            /// Framkvæmir bitvisa "or" aðgerð á núverandi gildi og rökunum `val` og stillir nýja gildið á niðurstöðuna.
            ///
            /// Skilar fyrra gildi.
            ///
            /// `fetch_or` tekur [`Ordering`] rök sem lýsa minni röðun á þessari aðgerð.Allir pöntunarhættir eru mögulegir.
            /// Athugaðu að notkun [`Acquire`] gerir verslunina að hluta af þessari aðgerð [`Relaxed`] og notkun [`Release`] gerir álagshlutann [`Relaxed`].
            ///
            ///
            /// **Athugasemd**: Þessi aðferð er aðeins fáanleg á kerfum sem styðja lotukerfisaðgerðir á
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // ÖRYGGI: gagna kynþáttum er komið í veg fyrir í lotukerfinu.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitvis "xor" með núverandi gildi.
            ///
            /// Framkvæmir bitvisa "xor" aðgerð á núverandi gildi og rökunum `val` og stillir nýja gildið á niðurstöðuna.
            ///
            /// Skilar fyrra gildi.
            ///
            /// `fetch_xor` tekur [`Ordering`] rök sem lýsa minni röðun á þessari aðgerð.Allir pöntunarhættir eru mögulegir.
            /// Athugaðu að notkun [`Acquire`] gerir verslunina að hluta af þessari aðgerð [`Relaxed`] og notkun [`Release`] gerir álagshlutann [`Relaxed`].
            ///
            ///
            /// **Athugasemd**: Þessi aðferð er aðeins fáanleg á kerfum sem styðja lotukerfisaðgerðir á
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // ÖRYGGI: gagna kynþáttum er komið í veg fyrir í lotukerfinu.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Sækir gildið og beitir aðgerð á það sem skilar valfrjálsu nýju gildi.Skilar `Result` af `Ok(previous_value)` ef aðgerðin skilaði `Some(_)`, annars `Err(previous_value)`.
            ///
            /// Note: Þetta getur kallað á aðgerðina mörgum sinnum ef gildinu hefur verið breytt frá öðrum þráðum í millitíðinni, svo framarlega sem aðgerðin skilar `Some(_)`, en aðgerðinni hefur aðeins verið beitt einu sinni á vistaða gildið.
            ///
            ///
            /// `fetch_update` tekur tvö [`Ordering`] rök til að lýsa minni röðun á þessari aðgerð.
            /// Sú fyrri lýsir nauðsynlegri pöntun fyrir þegar aðgerð tekst að lokum en sú síðari lýsir nauðsynlegri pöntun fyrir álag.Þetta samsvarar velgengni og misheppnaðri röðun
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Með því að nota [`Acquire`] sem pöntun á velgengni er verslunin hluti af þessari aðgerð [`Relaxed`] og notkun [`Release`] gerir endanlegt farsælt álag [`Relaxed`].
            /// (failed) álagsröðunin getur aðeins verið [`SeqCst`], [`Acquire`] eða [`Relaxed`] og verður að vera jafngild eða veikari en árangursröðunin.
            ///
            /// **Athugasemd**: Þessi aðferð er aðeins fáanleg á kerfum sem styðja lotukerfisaðgerðir á
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Pöntun: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Pöntun: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Hámark með núverandi gildi.
            ///
            /// Finnur hámark núverandi gildi og rök `val` og stillir nýja gildið á niðurstöðuna.
            ///
            /// Skilar fyrra gildi.
            ///
            /// `fetch_max` tekur [`Ordering`] rök sem lýsa minni röðun á þessari aðgerð.Allir pöntunarhættir eru mögulegir.
            /// Athugaðu að notkun [`Acquire`] gerir verslunina að hluta af þessari aðgerð [`Relaxed`] og notkun [`Release`] gerir álagshlutann [`Relaxed`].
            ///
            ///
            /// **Athugasemd**: Þessi aðferð er aðeins fáanleg á kerfum sem styðja lotukerfisaðgerðir á
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// láta bar=42;
            /// láttu max_foo=foo.fetch_max (bar, Ordering::SeqCst).max(bar);
            /// fullyrða! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // ÖRYGGI: gagna kynþáttum er komið í veg fyrir í lotukerfinu.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Lágmark með núverandi gildi.
            ///
            /// Finnur lágmark núverandi gildi og rök `val` og stillir nýja gildið á niðurstöðuna.
            ///
            /// Skilar fyrra gildi.
            ///
            /// `fetch_min` tekur [`Ordering`] rök sem lýsa minni röðun á þessari aðgerð.Allir pöntunarhættir eru mögulegir.
            /// Athugaðu að notkun [`Acquire`] gerir verslunina að hluta af þessari aðgerð [`Relaxed`] og notkun [`Release`] gerir álagshlutann [`Relaxed`].
            ///
            ///
            /// **Athugasemd**: Þessi aðferð er aðeins fáanleg á kerfum sem styðja lotukerfisaðgerðir á
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// láta bar=12;
            /// láttu min_foo=foo.fetch_min (bar, Ordering::SeqCst).min(bar);
            /// fullyrðing_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // ÖRYGGI: gagna kynþáttum er komið í veg fyrir í lotukerfinu.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Skilar breytilegum bendli að undirliggjandi heiltölu.
            ///
            /// Að stunda lestur og atóm sem ekki er lotukerfinu á heiltölunni sem myndast getur verið gagnakapphlaup.
            /// Þessi aðferð er að mestu gagnleg fyrir FFI, þar sem aðgerð undirskrift getur notað
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Að skila `*mut` bendli úr sameiginlegri tilvísun í þetta atóm er öruggt vegna þess að atómgerðirnar vinna með innri breytileika.
            /// Allar breytingar á lotukerfinu breyta gildinu með sameiginlegri tilvísun og geta gert það á öruggan hátt svo framarlega sem þeir nota atómaðgerðir.
            /// Sérhver notkun á hráum bendlinum sem skilað er krefst `unsafe` kubb og þarf enn að viðhalda sömu takmörkun: aðgerðir á honum verða að vera lotukerfinu.
            ///
            ///
            /// # Examples
            ///
            /// " hunsa (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// utanaðkomandi "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // ÖRYGGI: Öruggt svo framarlega sem `my_atomic_op` er lotukerfi.
            /// óöruggur {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `atomic_store`.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `atomic_load`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `atomic_swap`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Skilar fyrra gildi (eins og __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `atomic_add`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Skilar fyrra gildi (eins og __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `atomic_sub`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `atomic_compare_exchange`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `atomic_compare_exchange_weak`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// skilar hámarksgildinu (undirritaður samanburður)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// skilar lágmarksgildinu (undirritaður samanburður)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// skilar hámarksgildinu (óundirritaður samanburður)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// skilar lágmarksgildinu (óundirritaður samanburður)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Atómgirðing.
///
/// Það fer eftir tilgreindri röð, girðing kemur í veg fyrir að þýðandinn og örgjörvan geti endurraðað ákveðnar tegundir af minnisaðgerðum í kringum það.
/// Það skapar samstillingu við tengsl milli þess og lotukerfisins eða girðingar í öðrum þráðum.
///
/// Girðing 'A' sem hefur (að minnsta kosti) [`Release`] röðun merkingarfræði, samstillist við girðingu 'B' við (að minnsta kosti) [`Acquire`] merkingarfræði, ef og aðeins ef til eru aðgerðir X og Y, sem báðar starfa á einhverjum lotuhluti 'M' þannig að A er raðgreind fyrir X, Y er samstillt áður en B og Y fylgist með breytingunni í M.
/// Þetta veitir háð-áður-ósjálfstæði milli A og B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Atómaðgerðir með [`Release`] eða [`Acquire`] merkingarfræði geta einnig samstillst við girðingu.
///
/// Girðing sem er með [`SeqCst`] röðun, auk þess að hafa bæði [`Acquire`] og [`Release`] merkingarfræði, tekur þátt í alþjóðlegri dagskrárröð hinna [`SeqCst`] aðgerða og/eða girðinga.
///
/// Tekur við [`Acquire`], [`Release`], [`AcqRel`] og [`SeqCst`] pöntunum.
///
/// # Panics
///
/// Panics ef `order` er [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Gagnkvæm útilokun frumstæð byggð á snúningslás.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Bíddu þar til gamla gildið er `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Þessi girðing samstillist við verslun í `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // ÖRYGGI: notkun lotukerfisins er örugg.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Minni girðing þýðanda.
///
/// `compiler_fence` sendir ekki frá sér neinn vélarkóða, heldur takmarkar hvers konar minni endurpöntun þýðanda er heimilt að gera.Sérstaklega, eftir því hvaða [`Ordering`] merkingarfræði er gefin, er hægt að meina þýðandann frá því að flytja lestur eða skrifa frá eða fyrir símtalið til hinnar hliðar símtalsins í `compiler_fence`.Athugaðu að það kemur ekki í veg fyrir að *vélbúnaðurinn* geri slíka endurpöntun.
///
/// Þetta er ekki vandamál í eins þræðis, framkvæmdarsamhengi, en þegar aðrir þræðir geta breytt minni á sama tíma, er krafist sterkari frumstillingar á samstillingu eins og [`fence`].
///
/// Endurpöntunin sem kemur í veg fyrir mismunandi merkingarfræði er:
///
///  - með [`SeqCst`] er ekki leyfð endurpöntun á lestri og skrifum yfir þennan punkt.
///  - með [`Release`] er ekki hægt að færa á undan lestri og skrifum framhjá síðari skrifum.
///  - með [`Acquire`], síðari lestur og skrif er ekki hægt að færa á undan lestri á undan.
///  - með [`AcqRel`] er báðum ofangreindum reglum framfylgt.
///
/// `compiler_fence` er yfirleitt aðeins gagnlegt til að koma í veg fyrir að þráður kappaksturs *við sig*.Það er að segja ef tiltekinn þráður er að framkvæma eitt stykki kóða og er þá rofinn og byrjar að framkvæma kóða annars staðar (meðan hann er enn í sama þræði og hugmyndalega enn á sama kjarna).Í hefðbundnum forritum getur þetta aðeins komið fram þegar merki meðhöndlun er skráð.
/// Í meira lágstigs kóða geta slíkar aðstæður einnig komið upp þegar truflanir eru meðhöndlaðar, þegar grænir þræðir eru framkvæmdir með forkaupsrétti osfrv
/// Forvitnir lesendur eru hvattir til að lesa umfjöllun Linux kjarna um [memory barriers].
///
/// # Panics
///
/// Panics ef `order` er [`Relaxed`].
///
/// # Examples
///
/// Án `compiler_fence` er ekki tryggt að `assert_eq!` í eftirfarandi kóða nái árangri þrátt fyrir að allt gerist í einum þræði.
/// Til að sjá hvers vegna, mundu að þýðandanum er frjálst að skipta verslunum yfir í `IMPORTANT_VARIABLE` og `IS_READ` þar sem þær eru báðar `Ordering::Relaxed`.Ef það gerist og boðaðilar eru kallaðir til strax eftir að `IS_READY` er uppfærður, mun merki meðhöndlunin sjá `IS_READY=1`, en `IMPORTANT_VARIABLE=0`.
/// Með því að nota `compiler_fence` er bætt úr þessum aðstæðum.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // koma í veg fyrir að fyrri skrif séu færð út fyrir þennan punkt
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // ÖRYGGI: notkun lotukerfisins er örugg.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Merkir örgjörvann um að hann sé inni í uppteknum bið-snúða lykkju (" snúningslás`).
///
/// Þessi aðgerð er úrelt í þágu [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}