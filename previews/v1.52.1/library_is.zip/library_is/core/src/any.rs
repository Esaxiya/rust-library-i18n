//! Þessi eining útfærir `Any` trait, sem gerir kleift að hreyfa vélritun af hvaða `'static` gerð sem er með endurspeglun í keyrslu.
//!
//! `Any` sjálft er hægt að nota til að fá `TypeId`, og hefur fleiri eiginleika þegar það er notað sem trait hlutur.
//! Sem `&dyn Any` (að láni trait hlutur) hefur það `is` og `downcast_ref` aðferðirnar til að prófa hvort innihaldsgildið sé af tiltekinni gerð og til að fá tilvísun í innra gildi sem gerð.
//! Sem `&mut dyn Any` er einnig til `downcast_mut` aðferðin til að fá breytanlega tilvísun í innra gildi.
//! `Box<dyn Any>` bætir við `downcast` aðferðinni, sem reynir að breyta í `Box<T>`.
//! Sjá [`Box`] skjölin fyrir allar upplýsingar.
//!
//! Athugaðu að `&dyn Any` er takmarkað við að prófa hvort gildi sé af tilgreindri steypu gerð og ekki er hægt að nota það til að prófa hvort tegund útfærir trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Snjallbendir og `dyn Any`
//!
//! Eitt atferli sem þarf að hafa í huga þegar `Any` er notað sem trait hlutur, sérstaklega með gerðum eins og `Box<dyn Any>` eða `Arc<dyn Any>`, er að einfaldlega að hringja í `.type_id()` á gildinu mun framleiða `TypeId` af *ílátinu*, ekki undirliggjandi trait hlut.
//!
//! Þetta er hægt að forðast með því að breyta snjalla músinni í `&dyn Any` í staðinn, sem skilar `TypeId` hlutarins.
//! Til dæmis:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Þú ert líklegri til að vilja þetta:
//! let actual_id = (&*boxed).type_id();
//! // ... en þetta:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Hugleiddu aðstæður þar sem við viljum skrá þig út gildi sem er sent til aðgerðar.
//! Við vitum hvaða gildi við erum að vinna við útfærslur á Debug, en við vitum ekki hvaða steypa gerð það er.Við viljum veita sérstökum tegundum sérstaka meðferð: í þessu tilfelli er prentað út lengd strengjagildis áður en gildi þeirra er.
//! Við vitum ekki áþreifanlega gerð gildi okkar á samantektartíma og því þurfum við að nota speglun í keyrslu í staðinn.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Skógarhöggsaðgerð fyrir allar gerðir sem útfærir kembiforrit.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Reyndu að breyta gildi okkar í `String`.
//!     // Ef vel tekst til viljum við framleiða lengd strengsins sem og gildi þess.
//!     // Ef ekki, þá er það önnur gerð: prentaðu hana bara óskreytt.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Þessi aðgerð vill skrá breytu sína út áður en hún vinnur með henni.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... vinna einhverja aðra vinnu
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Allir trait
///////////////////////////////////////////////////////////////////////////////

/// A trait til að líkja eftir kraftmikilli vélritun.
///
/// Flestar gerðir innleiða `Any`.Engar gerðir sem innihalda tilvísun sem ekki er " staðbundin` gerir það hins vegar ekki.
/// Sjá [module-level documentation][mod] fyrir frekari upplýsingar.
///
/// [mod]: crate::any
// Þessi trait er ekki óöruggur, þó að við treystum á sérstöðu `type_id` aðgerðina eina í óöruggum kóða (td `downcast`).Venjulega væri það vandamál, en þar sem eina implant `Any` er teppi, getur enginn annar kóði innleitt `Any`.
//
// Við gætum áreiðanlega gert þennan trait óöruggan-það myndi ekki valda broti, þar sem við stjórnum öllum útfærslum-en við kjósum að gera það ekki þar sem það er bæði í raun ekki nauðsynlegt og getur ruglað notendur um aðgreiningu á óöruggum traits og óöruggum aðferðum (þ.e. `type_id` væri samt óhætt að hringja, en við myndum líklega vilja tilgreina sem slíkt í skjölum).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Fær `TypeId` af `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Framlengingaraðferðir fyrir alla trait hluti.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Gakktu úr skugga um að hægt sé að prenta útkomuna af því að sameina þráð og nota það því með `unwrap`.
// Gæti að lokum ekki lengur verið þörf ef sending vinnur með uppkast.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Skilar `true` ef kassa gerð er sú sama og `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Fáðu `TypeId` af þeirri gerð sem þessi aðgerð er tafarlaus með.
        let t = TypeId::of::<T>();

        // Fáðu `TypeId` af gerðinni í trait hlutnum (`self`).
        let concrete = self.type_id();

        // Berðu saman bæði " TypeId`s um jafnrétti.
        t == concrete
    }

    /// Skilar tilvísun í gildið í reit ef það er af gerðinni `T`, eða `None` ef það er ekki.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // ÖRYGGI: bara athugað hvort við erum að benda á rétta gerð og við getum treyst á
            // sem athugar hvort öryggi sé í minni vegna þess að við höfum innleitt Any fyrir allar gerðir;engin önnur tækjabúnaður getur verið til þar sem þau stangast á við okkar.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Skilar einhverri breytilegri tilvísun í kassagildið ef það er af gerðinni `T`, eða `None` ef það er ekki.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // ÖRYGGI: bara athugað hvort við erum að benda á rétta gerð og við getum treyst á
            // sem athugar hvort öryggi sé í minni vegna þess að við höfum innleitt Any fyrir allar gerðir;engin önnur tækjabúnaður getur verið til þar sem þau stangast á við okkar.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Fram til aðferðarinnar sem skilgreind er á gerð `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Fram til aðferðarinnar sem skilgreind er á gerð `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Fram til aðferðarinnar sem skilgreind er á gerð `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Fram til aðferðarinnar sem skilgreind er á gerð `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Fram til aðferðarinnar sem skilgreind er á gerð `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Fram til aðferðarinnar sem skilgreind er á gerð `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID og aðferðir þess
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` táknar alþjóðlegt auðkenni fyrir gerð.
///
/// Hver `TypeId` er ógagnsæ hlutur sem leyfir ekki skoðun á því sem er inni en leyfir grunnaðgerðir eins og einrækt, samanburð, prentun og sýningu.
///
///
/// `TypeId` er eins og er aðeins í boði fyrir gerðir sem þakka `'static` en þessa takmörkun er hægt að fjarlægja í future.
///
/// Þó að `TypeId` útfærir `Hash`, `PartialOrd` og `Ord`, er rétt að hafa í huga að kjötkássa og röðun er breytileg milli Rust útgáfa.
/// Varist að treysta á þá inni í kóðanum þínum!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Skilar `TypeId` af þeirri gerð sem þessari almennu aðgerð hefur verið komið á.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Skilar heiti tegundar sem strengjasneið.
///
/// # Note
///
/// Þetta er ætlað til greiningar.
/// Nákvæmt innihald og snið strengsins sem skilað er er ekki tilgreint, að öðru leyti en því að vera lýsing af bestu gerð.
/// Til dæmis, meðal strengjanna sem `type_name::<Option<String>>()` gæti skilað eru `"Option<String>"` og `"std::option::Option<std::string::String>"`.
///
///
/// Skilinn strengur má ekki líta á sem einstakt auðkenni af gerðinni þar sem margar gerðir geta kortað í sama tegundarheiti.
/// Að sama skapi er engin trygging fyrir því að allir hlutar gerðar birtist í skilaðri streng: til dæmis eru líftímaskilgreiningar ekki með í augnablikinu.
/// Að auki getur framleiðslan breyst milli útgáfa af þýðandanum.
///
/// Núverandi útfærsla notar sömu innviði og greining á þýðanda og villuleiðbeiningar, en það er ekki tryggt.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Skilar heiti gerðarinnar sem bent er á sem strengsneið.
/// Þetta er það sama og `type_name::<T>()` en er hægt að nota þar sem gerð breytu er ekki auðvelt að fá.
///
/// # Note
///
/// Þetta er ætlað til greiningar.Nákvæmt innihald og snið strengsins er ekki tilgreint, að öðru leyti en því að vera gerð besta fyrirhöfn af gerðinni.
/// Til dæmis gæti `type_name_of_val::<Option<String>>(None)` skilað `"Option<String>"` eða `"std::option::Option<std::string::String>"`, en ekki `"foobar"`.
///
/// Að auki getur framleiðslan breyst milli útgáfa af þýðandanum.
///
/// Þessi aðgerð leysir ekki trait hluti, sem þýðir að `type_name_of_val(&7u32 as &dyn Debug)` getur skilað `"dyn Debug"`, en ekki `"u32"`.
///
/// Tegundarheitið ætti ekki að teljast einstakt auðkenni tegundar;
/// margar tegundir geta deilt sama tegundarheiti.
///
/// Núverandi útfærsla notar sömu innviði og greining á þýðanda og villuleiðbeiningar, en það er ekki tryggt.
///
/// # Examples
///
/// Prentar sjálfgefnar heiltölur og flotgerðir.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}