// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Snýr sviðinu `[mid-left, mid+right)` þannig að frumefnið við `mid` verði fyrsti þátturinn.Jafnframt snýr svið `left` þætti til vinstri eða `right` þætti til hægri.
///
/// # Safety
///
/// Tilgreint svið verður að vera gilt til að lesa og skrifa.
///
/// # Algorithm
///
/// Reiknirit 1 er notað fyrir lítil gildi `left + right` eða fyrir stór `T`.
/// Þættirnir eru færðir í lokastöðu sína í einu og byrja á `mid - left` og komast áfram með `right` þrepum modulo `left + right`, þannig að aðeins eitt tímabundið þarf.
/// Að lokum komum við aftur til `mid - left`.
/// Hins vegar, ef `gcd(left + right, right)` er ekki 1, þá var ofangreindum skrefum sleppt yfir þætti.
/// Til dæmis:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Sem betur fer er fjöldinn sem sleppt er yfir þætti milli lokaþáttanna alltaf jafn, þannig að við getum bara vegið á móti upphafsstöðu okkar og gert fleiri umferðir (heildarfjöldi umferða er `gcd(left + right, right)` value).
///
/// Lokaniðurstaðan er sú að allir þættir eru frágengnir einu sinni og aðeins einu sinni.
///
/// Reiknirit 2 er notað ef `left + right` er stór en `min(left, right)` er nógu lítill til að passa í stafla biðminni.
/// `min(left, right)` þættirnir eru afritaðir á biðminnið, `memmove` er beitt á hina og þeir sem eru á biðminni eru færðir aftur í gatið á gagnstæða hlið þess sem þeir áttu uppruna sinn.
///
/// Reiknirit sem hægt er að grípa til vektor geta staðið sig ofar hér að ofan þegar `left + right` verður nógu stór.
/// Reiknirit 1 er hægt að mynda með því að kljúfa og framkvæma margar umferðir í einu, en það eru of fáir hringir að meðaltali þar til `left + right` er gífurlegur og versta tilfelli einnar umferðar er alltaf til staðar.
/// Þess í stað notar reiknirit 3 endurtekið skipti á `min(left, right)` þætti þar til minni snúnings vandamál er eftir.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// þegar `left < right` gerast skiptin frá vinstri í staðinn.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. neðangreindar reiknirit geta mistekist ef þessi tilvik eru ekki merkt
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Reiknirit 1 örmerki benda til þess að meðalárangur handahófskenndra vakta sé betri alla leið þangað til um `left + right == 32`, en versta fall frammistöðu brestur jafnvel í kringum 16.
            // 24 var valinn sem millivegur.
            // Ef stærðin á `T` er stærri en 4 'stærðir', er þessi reiknirit einnig betri en aðrar reiknirit.
            //
            //
            let x = unsafe { mid.sub(left) };
            // upphaf fyrstu umferðar
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` er hægt að finna fyrir hönd með því að reikna `gcd(left + right, right)`, en það er fljótlegra að gera eina lykkju sem reiknar út gcd sem aukaverkun og gerir síðan restina af klumpnum
            //
            //
            let mut gcd = right;
            // viðmið sýna að það er fljótlegra að skipta tímabundið alla leið í stað þess að lesa einu sinni tímabundið, afrita afturábak og skrifa það tímabundið alveg í lokin.
            // Þetta stafar hugsanlega af því að skipta eða skipta um tímabundið notar aðeins eitt minnisfang í lykkjunni í stað þess að þurfa að stjórna tveimur.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // í stað þess að auka `i` og athuga síðan hvort það sé utan markanna, athugum við hvort `i` fari utan markanna í næstu aukningu.
                // Þetta kemur í veg fyrir umbúðir ábendinga eða `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // lok fyrstu umferðar
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // þetta skilyrta verður að vera hér ef `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // klára klumpinn með fleiri umferðum
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` er ekki núllstór tegund, svo það er í lagi að deila eftir stærð hennar.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Reiknirit 2 `[T; 0]` hér er til að tryggja að þetta sé rétt stillt fyrir T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Reiknirit 3 Það er til önnur leið til að skipta sem felur í sér að finna hvar síðasta skiptin á þessari reiknirit væri, og að skipta með því að nota þennan síðasta klump í stað þess að skipta aðliggjandi klumpum eins og þessi reiknirit er að gera, en þessi leið er samt hraðari.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Reiknirit 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}