//! Sneiðaflokkun
//!
//! Þessi eining inniheldur flokkunaralgoritma sem byggir á mynstri sem sigrar mynstur sem sigrar mynstur, birt á: <https://github.com/orlp/pdqsort>
//!
//!
//! Óstöðug flokkun er samhæf við libcore vegna þess að hún úthlutar ekki minni, ólíkt stöðugri flokkunarútfærslu okkar.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Þegar það er fellt, afrit af `src` í `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // ÖRYGGI: Þetta er hjálparstétt.
        //          Vinsamlegast vísaðu til notkunar þess til að vera rétt.
        //          Maður verður nefnilega að vera viss um að `src` og `dst` skarast ekki eins og `ptr::copy_nonoverlapping` krefst.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Færir fyrsta þáttinn til hægri þar til hann lendir í meiri eða jöfnum frumefni.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // ÖRYGGI: Óöruggar aðgerðir hér að neðan fela í sér verðtryggingu án bundins ávísunar (`get_unchecked` og `get_unchecked_mut`)
    // og afrita minni (`ptr::copy_nonoverlapping`).
    //
    // a.Verðtrygging:
    //  1. Við athuguðum stærð fylkisins til>=2.
    //  2. Öll verðtryggingin sem við munum gera er alltaf mest á milli {0 <= index < len}.
    //
    // b.Minni afritun
    //  1. Við erum að fá ábendingar um tilvísanir sem eru öruggar gildar.
    //  2. Þeir geta ekki skarast vegna þess að við fáum vísbendingar um mismunandi vísitölur sneiðarinnar.
    //     Nefnilega `i` og `i-1`.
    //  3. Ef sneiðin er rétt stillt eru þættirnir rétt samstilltir.
    //     Það er á ábyrgð þess sem hringir að sjá til þess að sneiðin sé rétt stillt.
    //
    // Sjá athugasemdir hér að neðan til að fá frekari upplýsingar.
    unsafe {
        // Ef fyrstu tveir þættirnir eru í ólagi ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Lestu fyrsta þáttinn í staflaúthlutaða breytu.
            // Ef eftirfarandi samanburðaraðgerð panics fellur `hole` niður og skrifar frumefnið sjálfkrafa aftur í sneiðina.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Færðu " i`-þáttinn einn stað til vinstri og færðu holuna þannig til hægri.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` fellur niður og afritar þannig `tmp` í það gat sem eftir er í `v`.
        }
    }
}

/// Færir síðasta þáttinn til vinstri þar til hann lendir í minni eða jöfnum frumefni.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // ÖRYGGI: Óöruggar aðgerðir hér að neðan fela í sér verðtryggingu án bundins ávísunar (`get_unchecked` og `get_unchecked_mut`)
    // og afrita minni (`ptr::copy_nonoverlapping`).
    //
    // a.Verðtrygging:
    //  1. Við athuguðum stærð fylkisins til>=2.
    //  2. Öll verðtryggingin sem við munum gera er alltaf mest á milli `0 <= index < len-1`.
    //
    // b.Minni afritun
    //  1. Við erum að fá ábendingar um tilvísanir sem eru öruggar gildar.
    //  2. Þeir geta ekki skarast vegna þess að við fáum vísbendingar um mismunandi vísitölur sneiðarinnar.
    //     Nefnilega `i` og `i+1`.
    //  3. Ef sneiðin er rétt stillt eru þættirnir rétt samstilltir.
    //     Það er á ábyrgð þess sem hringir að sjá til þess að sneiðin sé rétt stillt.
    //
    // Sjá athugasemdir hér að neðan til að fá frekari upplýsingar.
    unsafe {
        // Ef síðustu tveir þættirnir eru ekki í röð ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Lestu síðasta þáttinn í staflaúthlutaða breytu.
            // Ef eftirfarandi samanburðaraðgerð panics fellur `hole` niður og skrifar frumefnið sjálfkrafa aftur í sneiðina.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Færðu " i`-þáttinn einn stað til hægri og færðu holuna þannig til vinstri.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` fellur niður og afritar þannig `tmp` í það gat sem eftir er í `v`.
        }
    }
}

/// Flokkar sneið að hluta með því að færa nokkra hluti utan röð.
///
/// Skilar `true` ef sneiðin er flokkuð í lokin.Þessi aðgerð er *O*(*n*) í versta falli.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Hámarksfjöldi samliggjandi para sem ekki eru í röð sem færist til.
    const MAX_STEPS: usize = 5;
    // Ef sneiðin er styttri en þessi, ekki færa neina þætti.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // ÖRYGGI: Við gerðum þegar gagngert athugun með `i < len`.
        // Öll síðari flokkun okkar er aðeins á bilinu `0 <= index < len`
        unsafe {
            // Finndu næsta par aðliggjandi þátta sem ekki eru í röð.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Erum við búin?
        if i == len {
            return true;
        }

        // Ekki breyta hlutum á stuttum fylkjum, það hefur árangurskostnað.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Skiptu um fundna frumefni.Þetta setur þá í rétta röð.
        v.swap(i - 1, i);

        // Færðu minni þáttinn til vinstri.
        shift_tail(&mut v[..i], is_less);
        // Færðu stærri þáttinn til hægri.
        shift_head(&mut v[i..], is_less);
    }

    // Náði ekki að raða sneiðinni í takmarkaðan fjölda skrefa.
    false
}

/// Flokkar sneið með því að nota innsetningarflokkun, sem er *O*(*n*^ 2) í versta falli.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Flokkar `v` með heapsort, sem tryggir *O*(*n*\*log(* n*)) í versta falli.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Þessi tvöfalda hrúga virðir óbreytanlegt `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Börn `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Veldu stærra barnið.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Hættu ef óbreytan heldur á `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Skiptu um `node` við stærra barnið, færðu eitt skref niður og haltu áfram að sigta.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Byggðu hrúguna á línulegum tíma.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Poppaðu hámarksþætti úr hrúgunni.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Skipting `v` í þætti sem eru minni en `pivot` og síðan þættir sem eru stærri eða jafnir og `pivot`.
///
///
/// Skilar fjölda þætti sem eru minni en `pivot`.
///
/// Skipting er framkvæmd blokk-fyrir-blokk til að lágmarka kostnað við útibú.
/// Þessi hugmynd er sett fram í [BlockQuicksort][pdf] greininni.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Fjöldi þátta í dæmigerðri blokk.
    const BLOCK: usize = 128;

    // Skiptingaralgoritminn endurtekur eftirfarandi skref þar til því er lokið:
    //
    // 1. Rekja blokk frá vinstri hlið til að bera kennsl á þætti sem eru stærri eða jafnir snúningi.
    // 2. Rekja blokk frá hægri hlið til að bera kennsl á þætti sem eru minni en snúningur.
    // 3. Skiptu um greindu þættina milli vinstri og hægri hliðar.
    //
    // Við geymum eftirfarandi breytur fyrir frumefni:
    //
    // 1. `block` - Fjöldi þátta í blokkinni.
    // 2. `start` - Byrjaðu bendilinn í `offsets` fylkið.
    // 3. `end` - Enda bendi í `offsets` fylkið.
    // 4. `móti, Vísitölur um óhlutbundna þætti innan reitsins.

    // Núverandi blokk vinstra megin (frá `l` til `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Núverandi blokk hægra megin (frá `r.sub(block_r)` to `r`).
    // ÖRYGGI: Í skjölunum fyrir .add() er sérstaklega getið að `vec.as_ptr().add(vec.len())` sé alltaf öruggt `
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Þegar við fáum VLA, reyndu frekar að búa til eina lengd `min(v.len(), 2 * BLOCK) `frekar
    // en tvö fylki í föstum stærð að lengd `BLOCK`.VLA geta verið skyndiminni skilvirkari.

    // Skilar fjölda þátta milli ábendinga `l` (inclusive) og `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Við erum búin með að skiptast á milli reita þegar `l` og `r` komast mjög nálægt.
        // Síðan vinnum við smá plástur til að skipta þeim þáttum sem eftir eru á milli.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Fjöldi þátta sem eftir eru (samt ekki miðað við snúninginn).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Stilltu kubbastærðir þannig að vinstri og hægri kubbur skarast ekki heldur aðlagast fullkomlega til að hylja allt bilið sem eftir er.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Rekja `block_l` þætti frá vinstri hlið.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // ÖRYGGI: Óöryggisaðgerðirnar hér að neðan fela í sér notkun `offset`.
                //         Samkvæmt skilyrðunum sem aðgerðin krefst fullnægjum við þeim vegna þess að:
                //         1. `offsets_l` er staflaúthlutað og telst þannig aðskildur úthlutaður hlutur.
                //         2. Aðgerðin `is_less` skilar `bool`.
                //            Að steypa `bool` flæðir aldrei yfir `isize`.
                //         3. Við höfum ábyrgst að `block_l` verði `<= BLOCK`.
                //            Auk þess var `end_l` upphaflega stillt á upphafsbendil `offsets_` sem var lýst yfir á stafla.
                //            Þannig vitum við að jafnvel í versta falli (allar ákall á `is_less` skila fölsku) verðum við í mesta lagi 1 bæti framhjá endanum.
                //        Önnur óöryggisaðgerð hér er dereferencing `elem`.
                //        `elem` var þó upphaflega upphafsbendillinn að sneiðinni sem er alltaf gild.
                unsafe {
                    // Útibúalaus samanburður.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Rekja `block_r` þætti frá hægri hlið.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // ÖRYGGI: Óöryggisaðgerðirnar hér að neðan fela í sér notkun `offset`.
                //         Samkvæmt skilyrðunum sem aðgerðin krefst fullnægjum við þeim vegna þess að:
                //         1. `offsets_r` er staflaúthlutað og telst þannig aðskildur úthlutaður hlutur.
                //         2. Aðgerðin `is_less` skilar `bool`.
                //            Að steypa `bool` flæðir aldrei yfir `isize`.
                //         3. Við höfum ábyrgst að `block_r` verði `<= BLOCK`.
                //            Auk þess var `end_r` upphaflega stillt á upphafsbendil `offsets_` sem var lýst yfir á stafla.
                //            Þannig vitum við að jafnvel í versta falli (allar ákall á `is_less` skila sönnu) verðum við í mesta lagi 1 bæti framhjá endanum.
                //        Önnur óöryggisaðgerð hér er dereferencing `elem`.
                //        Hins vegar var `elem` upphaflega `1 *sizeof(T)` fram yfir lokin og við minnkum það með `1* sizeof(T)` áður en við höfum aðgang að því.
                //        Auk þess var fullyrt að `block_r` væri minna en `BLOCK` og `elem` myndi því í mesta lagi benda á upphaf sneiðarinnar.
                unsafe {
                    // Útibúalaus samanburður.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Fjöldi þátta sem ekki eru í röð sem skipta á milli vinstri og hægri hliðar.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Í stað þess að skipta um eitt par í einu er hagkvæmara að framkvæma hringrásar umbreytingu.
            // Þetta er ekki nákvæmlega jafngilt skiptimynt, en gefur svipaða niðurstöðu með því að nota minni aðgerðir í minni.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Allir þættir utan röð í vinstri blokkinni voru færðir.Fara í næstu blokk.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Allir þættir sem ekki voru í röð í hægri blokk voru færðir til.Fara í fyrri blokk.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Allt sem eftir er núna er í mesta lagi ein blokk (annaðhvort til vinstri eða hægri) með óreglulegum þáttum sem þarf að færa.
    // Slíkum þáttum sem eftir eru er einfaldlega hægt að færa til enda innan ramma þeirra.
    //

    if start_l < end_l {
        // Vinstri kaflinn er eftir.
        // Færðu eftirstöðvar sínar sem ekki eru í röð lengst til hægri.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Hægri blokkin er eftir.
        // Færðu eftirstöðvar þess sem ekki eru í röð lengst til vinstri.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Ekkert annað að gera, við erum búin.
        width(v.as_mut_ptr(), l)
    }
}

/// Skipting `v` í þætti sem eru minni en `v[pivot]` og síðan þættir sem eru stærri eða jafnir og `v[pivot]`.
///
///
/// Skilar túpu af:
///
/// 1. Fjöldi þátta minni en `v[pivot]`.
/// 2. Satt ef `v` var þegar skipt upp.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Settu snúninginn í byrjun sneiðar.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Lestu snúninginn í staflaúthlutaða breytu til skilvirkni.
        // Ef eftirfarandi samanburðaraðgerð panics verður snúningurinn sjálfkrafa skrifaður aftur í sneiðina.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Finndu fyrsta parið sem ekki er í röð.
        let mut l = 0;
        let mut r = v.len();

        // ÖRYGGI: Óöryggið hér að neðan felur í sér flokkun fylkis.
        // Í fyrsta lagi: Við gerum nú þegar mörkin hér með `l < r`.
        // Fyrir þann seinni: Við höfum upphaflega `l == 0` og `r == v.len()` og við athuguðum hvort `l < r` við hverja flokkunaraðgerð.
        //                     Héðan frá vitum við að `r` verður að vera að minnsta kosti `r == l` sem sýnt var að gilti frá þeim fyrsta.
        unsafe {
            // Finndu fyrsta þáttinn meiri en eða jafnt og snúningur.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Finndu síðasta þáttinn sem er minni sem snúningur.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` fer utan sviðs og skrifar snúninginn (sem er staflaúthlutað breytu) aftur í sneiðina þar sem hún var upphaflega.
        // Þetta skref er mikilvægt til að tryggja öryggi!
        //
    };

    // Settu snúninginn á milli tveggja skiptinganna.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Skipting `v` í frumefni jafnt og `v[pivot]` fylgt eftir með stærðum stærri en `v[pivot]`.
///
/// Skilar fjölda þátta sem eru jafnt snúningi.
/// Gert er ráð fyrir að `v` innihaldi ekki þætti sem eru minni en snúningur.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Settu snúninginn í byrjun sneiðar.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Lestu snúninginn í staflaúthlutaða breytu til skilvirkni.
    // Ef eftirfarandi samanburðaraðgerð panics verður snúningurinn sjálfkrafa skrifaður aftur í sneiðina.
    // ÖRYGGI: Bendillinn hér er gildur vegna þess að hann er fenginn með tilvísun í sneið.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Skiptið nú sneiðinni.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // ÖRYGGI: Óöryggið hér að neðan felur í sér flokkun fylkis.
        // Í fyrsta lagi: Við gerum nú þegar mörkin hér með `l < r`.
        // Fyrir þann seinni: Við höfum upphaflega `l == 0` og `r == v.len()` og við athuguðum hvort `l < r` við hverja flokkunaraðgerð.
        //                     Héðan frá vitum við að `r` verður að vera að minnsta kosti `r == l` sem sýnt var að gilti frá þeim fyrsta.
        unsafe {
            // Finndu fyrsta þáttinn meiri en snúninginn.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Finndu síðasta atriðið sem er jafnt snúningi.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Erum við búin?
            if l >= r {
                break;
            }

            // Skiptu um fundið par af óeðlilegum þáttum.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Við fundum `l` frumefni jafnt og snúningi.Bættu 1 við reikninginn fyrir snúninginn sjálfan.
    l + 1

    // `_pivot_guard` fer utan sviðs og skrifar snúninginn (sem er staflaúthlutað breytu) aftur í sneiðina þar sem hún var upphaflega.
    // Þetta skref er mikilvægt til að tryggja öryggi!
}

/// Dreifir nokkrum þáttum í kringum til að reyna að brjóta mynstur sem gætu valdið ójafnvægi skipting í kviku sorti.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Pseudorandom númer rafall úr "Xorshift RNGs" pappír eftir George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Taktu slembitölur modulo þessa tölu.
        // Talan passar inn í `usize` vegna þess að `len` er ekki meiri en `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Sumir frambjóðendur verða í næsta nágrenni við þessa vísitölu.Sláum þeim af handahófi.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Búðu til slembitölu modulo `len`.
            // Hins vegar, til að koma í veg fyrir kostnaðarsamar aðgerðir, tökum við það fyrst modulo afl tvö og lækkum síðan um `len` þar til það passar inn á sviðið `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` er tryggt að það sé minna en `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Velur snúning í `v` og skilar vísitölunni og `true` ef sneiðin er líklega þegar raðað.
///
/// Þætti í `v` gæti verið endurraðað í því ferli.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Lágmarkslengd til að velja miðgildi miðgildisaðferðar.
    // Styttri sneiðar nota einföldu miðgildi af þremur aðferðinni.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Hámarksfjöldi skiptasamninga sem hægt er að framkvæma í þessari aðgerð.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Þrjár vísitölur sem við ætlum að velja snúning við.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Telur heildarfjölda skiptasamninga sem við erum að fara að framkvæma við flokkun vísitölu.
    let mut swaps = 0;

    if len >= 8 {
        // Skiptir um vísitölur þannig að `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Skiptir um vísitölur þannig að `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Finnur miðgildi `v[a - 1], v[a], v[a + 1]` og geymir vísitöluna í `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Finndu miðgildi í hverfunum `a`, `b` og `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Finndu miðgildi meðal `a`, `b` og `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Hámarksfjöldi skiptasamninga var gerður.
        // Líkurnar eru á að sneiðin sé að lækka eða að mestu leyti að lækka, þannig að afturköllun mun líklega hjálpa til við að flokka hana hraðar.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Flokkar `v` endurkvæmanlega.
///
/// Ef sneiðin átti forvera í upprunalega fylkingunni er hún tilgreind sem `pred`.
///
/// `limit` er fjöldi leyfilegra ójafnvægis skiptinga áður en skipt er yfir í `heapsort`.
/// Ef núll, þessi aðgerð mun strax skipta yfir í hrúga.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Sneiðar allt að þessari lengd flokkast með innsetningarflokkun.
    const MAX_INSERTION: usize = 20;

    // Satt ef síðasta skiptingin var hæfilega í jafnvægi.
    let mut was_balanced = true;
    // Satt ef síðasta skiptingin stokkaði ekki upp á þætti (sneiðin var þegar skipt upp).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Mjög stuttar sneiðar verða flokkaðar með innsetningarflokkun.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Ef of margir slæmir snúningsvalkostir voru gerðir skaltu einfaldlega falla aftur í mikinn fjölda til að tryggja `O(n * log(n))` versta fallið.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Ef síðasta skiptingin var ekki í jafnvægi skaltu prófa að brjóta mynstur í sneiðinni með því að stokka nokkrum þáttum í kring.
        // Vonandi veljum við betri snúning að þessu sinni.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Veldu snúning og reyndu að giska á hvort sneiðin sé þegar raðað.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Ef síðasta skiptingin var sómasamlega í jafnvægi og ekki stokkuð upp á þætti og ef snúningsval spáir er sneiðin líklega þegar raðað ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Reyndu að bera kennsl á nokkra hluti sem ekki eru í röð og færa þá á réttar stöður.
            // Ef sneiðin endar með því að vera alveg flokkuð erum við búin.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Ef valt snúningur er jafnt og forverinn, þá er það minnsti þátturinn í sneiðinni.
        // Skiptið sneiðinni í þætti jafna og þætti stærri en snúninginn.
        // Þetta mál er venjulega slegið þegar sneiðin inniheldur mörg afrit.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Haltu áfram að flokka þætti sem eru stærri en snúningur.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Skiptið sneiðinni.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Skiptu sneiðinni í `left`, `pivot` og `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Haltu þér aðeins aftur í styttri hliðina til að lágmarka heildarfjölda endurtekinna símtala og neyta minna pláss.
        // Síðan er bara að halda áfram með lengri hliðina (þetta er í ætt við endurhalun hala).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Flokkar `v` með því að nota mynstur sem sigrar fljótlega, sem er *O*(*n*\*log(* n*)) í versta falli.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Flokkun hefur enga þýðingarmikla hegðun á núllstærðum gerðum.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Takmarkaðu fjölda ójafnvægis skiptinga við `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Fyrir sneiðar allt að þessari lengd er líklega fljótlegra að raða þeim einfaldlega.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Veldu snúning
        let (pivot, _) = choose_pivot(v, is_less);

        // Ef valt snúningur er jafnt og forverinn, þá er það minnsti þátturinn í sneiðinni.
        // Skiptið sneiðinni í þætti jafna og þætti stærri en snúninginn.
        // Þetta mál er venjulega slegið þegar sneiðin inniheldur mörg afrit.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Ef við höfum staðist vísitöluna okkar, þá erum við góðir.
                if mid > index {
                    return;
                }

                // Annars skaltu halda áfram að flokka þætti sem eru stærri en snúningur.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Skiptu sneiðinni í `left`, `pivot` og `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Ef miðjan==vísitalan, þá erum við búin, þar sem partition() ábyrgðist að allir þættir eftir miðju eru meiri en eða jafnt og miðjan.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Flokkun hefur enga þýðingarmikla hegðun á núllstærðum gerðum.Gera ekkert.
    } else if index == v.len() - 1 {
        // Finndu hámarksþáttinn og settu hann í síðustu stöðu fylkisins.
        // Okkur er frjálst að nota `unwrap()` hér vegna þess að við vitum að v má ekki vera autt.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Finndu mín frumefni og settu það í fyrstu stöðu fylkisins.
        // Okkur er frjálst að nota `unwrap()` hér vegna þess að við vitum að v má ekki vera autt.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}