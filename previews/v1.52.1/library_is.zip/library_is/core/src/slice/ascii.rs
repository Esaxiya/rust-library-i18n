//! Aðgerðir á ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Athugar hvort öll bæti í þessari sneið séu innan ASCII sviðsins.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Athugar að tvær sneiðar séu ASCII mál-ónæmir samsvörun.
    ///
    /// Sama og `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, en án þess að úthluta og afrita tímabundið.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Breytir þessari sneið í ASCII jafngildi þess í stað.
    ///
    /// ASCII stafir 'a' til 'z' eru kortlagðir við 'A' til 'Z', en stafir sem ekki eru ASCII eru óbreyttir.
    ///
    /// Notaðu [`to_ascii_uppercase`] til að skila nýju hástöfuðu gildi án þess að breyta því sem fyrir er.
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Breytir þessari sneið í ASCII smærri jafngildi þess í stað.
    ///
    /// ASCII stafir 'A' til 'Z' eru kortlagðir við 'a' til 'z', en stafir sem ekki eru ASCII eru óbreyttir.
    ///
    /// Notaðu [`to_ascii_lowercase`] til að skila nýju lágmarksgildi án þess að breyta því sem fyrir er.
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Skilar `true` ef eitthvað bæti í orðinu `v` er nonascii (>=128).
/// Snarfed frá `../str/mod.rs`, sem gerir eitthvað svipað fyrir utf8 löggildingu.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Bjartsýni ASCII próf sem mun nota notkunarstærð í einu í stað bæti í senn (þegar mögulegt er).
///
/// Reikniritið sem við notum hér er frekar einfalt.Ef `s` er of stutt, athugum við bara hvert bæti og erum búin með það.Annars:
///
/// - Lestu fyrsta orðið með ósamstilltu álagi.
/// - Réttu bendilinn, lestu síðari orð þar til í lok með taktu álagi.
/// - Lestu síðasta `usize` frá `s` með ójöfnuðu álagi.
///
/// Ef eitthvað af þessum álagi framleiðir eitthvað sem `contains_nonascii` (above) skilar satt, þá vitum við að svarið er rangt.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Ef við myndum ekki græða neitt á orði-í-einu útfærslunni, fallið aftur að stærðar lykkju.
    //
    // Við gerum þetta líka fyrir arkitektúr þar sem `size_of::<usize>()` er ekki nægjanleg jöfnun fyrir `usize`, því það er skrýtið edge mál.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Við lesum alltaf fyrsta orðið ósamræmt, sem þýðir að `align_offset` er
    // 0, við myndum lesa sama gildi aftur fyrir samstilltan lestur.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // ÖRYGGI: Við staðfestum `len < USIZE_SIZE` hér að ofan.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Við athuguðum þetta hér að ofan, nokkuð óbeint.
    // Athugaðu að `offset_to_aligned` er annað hvort `align_offset` eða `USIZE_SIZE`, báðir eru sérstaklega merktir hér að ofan.
    //
    debug_assert!(offset_to_aligned <= len);

    // ÖRYGGI: word_ptr er (rétt stillt) notastærð sem við notum til að lesa
    // miðjubita af sneiðinni.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` er bæti vísitala `word_ptr`, notuð við lokaathuganir.
    let mut byte_pos = offset_to_aligned;

    // Ofsóknarbrjálæði kannast við aðlögun, þar sem við erum að fara að gera fullt af óaðlöguðu álagi.
    // Í reynd ætti þetta að vera ómögulegt að hindra villu í `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Lestu síðari orð þar til síðasta samstillta orðið, að undanskildu síðasta samstillta orðinu sjálfu til að gera í halaskoðun seinna, til að tryggja að skottið sé í mesta lagi eitt `usize` til viðbótar við branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Geðheilsa athuga hvort lesturinn er í mörkum
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Og að forsendur okkar um `byte_pos` standist.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // ÖRYGGI: Við vitum að `word_ptr` er rétt stillt (vegna
        // 'align_offset'), og við vitum að við höfum nóg bæti á milli `word_ptr` og loka
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // ÖRYGGI: Við vitum að `byte_pos <= len - USIZE_SIZE`, sem þýðir það
        // eftir þennan `add` verður `word_ptr` í mesta lagi einn-fort-the-endir.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Heilbrigðiseftirlit til að tryggja að það sé aðeins einn `usize` eftir.
    // Þetta ætti að vera tryggt með lykkjuástandi okkar.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // ÖRYGGI: Þetta reiðir sig á `len >= USIZE_SIZE`, sem við athugum í byrjun.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}