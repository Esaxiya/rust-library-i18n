//! Fjölvi sem notaður er af endurteknum sneiðum.

// Inlining er_empty og len munar miklu um frammistöðu
macro_rules! is_empty {
    // Eins og við umræðum lengd ZST endurtekningar, þetta virkar bæði fyrir ZST og ekki ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Til að losna við nokkur markatékk (sjá `position`) reiknum við lengdina á nokkuð óvæntan hátt.
// (Prófað með 'codegen/slice-position-bounds-check'.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // við erum stundum notuð innan óöruggrar blokkar

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Þessi _cannot_ notar `unchecked_sub` vegna þess að við erum háð umbúðum til að tákna lengdina á löngum ZST sneiðgerðunum.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Við vitum að `start <= end`, svo það getur gert betur en `offset_from`, sem þarf að takast á við undirritað.
            // Með því að setja viðeigandi fána hér getum við sagt LLVM þetta, sem hjálpar því að fjarlægja markatakmarkanir.
            // ÖRYGGI: Eftir tegundinni óbreytanlegur, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Með því að segja LLVM einnig að ábendingarnar séu aðskildar með nákvæmri margfeldi af gerðarstærðinni, getur það fínstillt `len() == 0` niður í `start == end` í stað `(end - start) < size`.
            //
            // ÖRYGGI: Eftir tegundinni óbreytanlegu eru ábendingar stilltar þannig að
            //         fjarlægðin á milli þeirra verður að vera margfeldi af stærð pointees
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Sameiginleg skilgreining á `Iter` og `IterMut` endurtekningum
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Skilar fyrsta þættinum og færir upphaf endurtekningarinnar áfram um 1.
        // Bætir mjög frammistöðu miðað við innfellda aðgerð.
        // Ítórinn má ekki vera tómur.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Skilar síðasta þætti og færir enda endurtekningarinnar aftur um 1.
        // Bætir mjög frammistöðu miðað við innfellda aðgerð.
        // Ítórinn má ekki vera tómur.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Minnkar endurtekninguna þegar T er ZST, með því að færa endann á endurtekningunni afturábak um `n`.
        // `n` má ekki fara yfir `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Hjálparaðgerð til að búa til sneið úr endurtekningunni.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // ÖRYGGI: endurtekningin var búin til úr sneið með bendi
                // `self.ptr` og lengd `len!(self)`.
                // Þetta tryggir að allar forsendur `from_raw_parts` séu uppfylltar.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Hjálparaðgerð til að færa upphaf endurtekningarinnar áfram með `offset` þætti, skila gamla byrjuninni.
            //
            // Óörugg vegna þess að móti má ekki fara yfir `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // ÖRYGGI: kallinn ábyrgist að `offset` fari ekki yfir `self.len()`,
                    // svo þessi nýi bendill er inni í `self` og þar með tryggður að hann er ekki núll.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Hjálparaðgerð til að færa enda endurtekningarinnar afturábak með `offset` þáttum, skila nýja endanum.
            //
            // Óörugg vegna þess að móti má ekki fara yfir `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // ÖRYGGI: kallinn ábyrgist að `offset` fari ekki yfir `self.len()`,
                    // sem er tryggt að flæða ekki yfir `isize`.
                    // Bendirinn sem myndast er einnig innan marka `slice`, sem uppfyllir aðrar kröfur um `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // gæti verið hrint í framkvæmd með sneiðum, en með því er forðast mörkin

                // ÖRYGGI: `assume` símtöl eru örugg þar sem byrjunarbendill sneiðar er
                // verður að vera ekki núll og sneiðar yfir non-ZST verða einnig að hafa ekki bendil.
                // Símtalið til `next_unchecked!` er öruggt þar sem við athugum hvort endurtekningartækið sé tómt fyrst.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Þessi endurtekning er nú tóm.
                    if mem::size_of::<T>() == 0 {
                        // Við verðum að gera það með þessum hætti þar sem `ptr` getur aldrei verið 0, en `end` gæti verið (vegna umbúða).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // ÖRYGGI: endir geta ekki verið 0 ef T er ekki ZST vegna þess að ptr er ekki 0 og endir>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // ÖRYGGI: Við erum í mörkum.`post_inc_start` gerir það rétta jafnvel fyrir ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Við víkjum fyrir sjálfgefinni útfærslu, sem notar `try_fold`, vegna þess að þessi einfalda útfærsla býr til minna LLVM IR og er fljótlegra að setja saman.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Við víkjum fyrir sjálfgefinni útfærslu, sem notar `try_fold`, vegna þess að þessi einfalda útfærsla býr til minna LLVM IR og er fljótlegra að setja saman.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Við víkjum fyrir sjálfgefinni útfærslu, sem notar `try_fold`, vegna þess að þessi einfalda útfærsla býr til minna LLVM IR og er fljótlegra að setja saman.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Við víkjum fyrir sjálfgefinni útfærslu, sem notar `try_fold`, vegna þess að þessi einfalda útfærsla býr til minna LLVM IR og er fljótlegra að setja saman.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Við víkjum fyrir sjálfgefinni útfærslu, sem notar `try_fold`, vegna þess að þessi einfalda útfærsla býr til minna LLVM IR og er fljótlegra að setja saman.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Við víkjum fyrir sjálfgefinni útfærslu, sem notar `try_fold`, vegna þess að þessi einfalda útfærsla býr til minna LLVM IR og er fljótlegra að setja saman.
            // Einnig forðast `assume` takmarkanir.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // ÖRYGGI: okkur er tryggt að vera í mörkum með lykkjunni óbreytanlegu:
                        // þegar `i >= n`, `self.next()` skilar `None` og lykkjan brotnar.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Við víkjum fyrir sjálfgefinni útfærslu, sem notar `try_fold`, vegna þess að þessi einfalda útfærsla býr til minna LLVM IR og er fljótlegra að setja saman.
            // Einnig forðast `assume` takmarkanir.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // ÖRYGGI: `i` verður að vera lægra en `n` þar sem það byrjar á `n`
                        // og er aðeins að lækka.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // ÖRYGGI: sá sem hringir þarf að ábyrgjast að `i` sé innan marka
                // undirliggjandi sneið, þannig að `i` getur ekki flætt yfir `isize`, og skilað tilvísun er tryggt að vísa til þáttar í sneiðinni og þannig tryggt að hún sé gild.
                //
                // Athugaðu einnig að sá sem hringir tryggir líka að við verðum aldrei aftur hringt með sömu vísitölu og að engar aðrar aðferðir sem fá aðgang að þessari undirsíðu eru kallaðar, svo það gildir að skilað tilvísun sé breytilegt ef um er að ræða
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // gæti verið hrint í framkvæmd með sneiðum, en með því er forðast mörkin

                // ÖRYGGI: `assume` símtöl eru örugg þar sem byrjunarbendill sneiðar verður að vera ekki núll,
                // og sneiðar yfir non-ZST verða einnig að hafa bendilinn sem er ekki núll.
                // Símtalið til `next_back_unchecked!` er öruggt þar sem við athugum hvort endurtekningartækið sé tómt fyrst.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Þessi endurtekning er nú tóm.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // ÖRYGGI: Við erum í mörkum.`pre_dec_end` gerir það rétta jafnvel fyrir ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}