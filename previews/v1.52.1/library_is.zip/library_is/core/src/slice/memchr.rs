// Upprunaleg útfærsla tekin af rust-memchr.
// Copyright 2015 Andrew Gallant, bluss og Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Notaðu styttingu.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Skilar `true` ef `x` inniheldur eitthvert núll bæti.
///
/// Úr *Matters Computational*, J. Arndt:
///
/// " Hugmyndin er að draga eitt frá hverju bæti og leita síðan að bítum þar sem lánið breiddist út að því markverðasta
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Skilar fyrstu vísitölunni sem passar við bæti `x` í `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Hröð leið fyrir litlar sneiðar
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Leitaðu að einu bæti gildi með því að lesa tvö `usize` orð í einu.
    //
    // Skiptu `text` í þremur hlutum
    // - ósamstilltur upphafshluti, á undan fyrsta orðaréttaða heimilisfangi í texta
    // - líkami, skannaðu með 2 orðum í einu
    // - síðasti hlutinn sem eftir er, <2 orðstærð

    // leitaðu að jöfnum mörkum
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // leita í meginmáli textans
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // ÖRYGGI: forskeyti stundarinnar tryggir að lágmarki 2 * usize_bytes
        // milli offset og enda sneiðarinnar.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // brot ef það er samsvarandi bæti
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Finndu bæti eftir punktinn sem líkamslykkjan stöðvaðist.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Skilar síðustu vísitölunni sem passar við bæti `x` í `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Leitaðu að einu bæti gildi með því að lesa tvö `usize` orð í einu.
    //
    // Skiptu `text` í þremur hlutum:
    // - óskorað skott, á eftir síðasta orðaréttaða heimilisfangi í texta,
    // - líkami, skannaður með 2 orðum í einu,
    // - fyrstu bætin sem eftir eru, <2 orða stærð.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Við köllum þetta bara til að fá lengd forskeytis og viðskeytis.
        // Í miðjunni vinnum við alltaf tvo bita í einu.
        // ÖRYGGI: Að flytja `[u8]` til `[usize]` er öruggt nema stærðarmunur sem `align_to` sér um.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Leitaðu í meginmáli textans, vertu viss um að við förum ekki yfir min_aligned_offset.
    // offset er alltaf samstillt, svo það er nóg að prófa `>` og forðast mögulegt flæði.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // ÖRYGGI: móti byrjar við len, suffix.len(), svo framarlega sem það er stærra en
        // min_aligned_offset (prefix.len()) eftirstandandi vegalengd er að minnsta kosti 2 * klump_bæti.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Brot ef það er samsvarandi bæti.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Finndu bætið áður en líkamshringurinn stöðvaðist.
    text[..offset].iter().rposition(|elt| *elt == x)
}